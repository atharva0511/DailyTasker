"""Editor-side ur_rtde API: every call runs in the robot SDK helper process.

Same function names as ``universal_robot_sdk`` so the UniversalRobot worker
thread keeps its flow; ``UrRemoteSession`` replaces the in-process
``UrRtdeSession``. One helper process per connection: it is started by
``open_session`` / ``connect_robot`` and stopped by ``disconnect_robot``. If it dies (native
crash in ur_rtde) or stops answering, calls raise ``UniversalRobotSdkError``
starting with "Connection lost" and the worker drops the session.
"""

from __future__ import annotations

import importlib.util
from typing import Any, Optional, Tuple

from MotionStudio.core.hardwares.sdk_host import SdkHostClient, SdkHostCrashed, SdkHostError, SdkRemoteError
from MotionStudio.core.hardwares.universal_robot_sdk import (
	RECONNECT_ATTEMPTS,
	RECONNECT_DELAY_S,
	UniversalRobotSdkError,
	io_type_is_input,
	sdk_missing_message,
)

__all__ = [
	"UniversalRobotSdkError",
	"UrRemoteSession",
	"apply_digital_io",
	"connect_robot",
	"connect_session",
	"disconnect_robot",
	"get_joints",
	"get_tcp_pose",
	"io_type_is_input",
	"is_program_running",
	"kill_session",
	"open_session",
	"reconnect_receive",
	"robot_not_ready_message",
	"safety_fault_message",
	"sdk_available",
	"sdk_missing_message",
	"send_halt",
	"send_movel",
	"send_script_file",
	"session_is_connected",
]

_SERVICE = "MotionStudio.core.hardwares.universal_robot_sdk:UrRtdeService"
# Upper bounds for one helper call. They only matter when the helper is wedged
# in native code; normal calls return far sooner.
_QUERY_TIMEOUT_S = 10.0
_DISCONNECT_TIMEOUT_S = 10.0
_IO_TIMEOUT_S = 30.0
# 30002 send (5 s socket) + RTDE recovery (RECONNECT_ATTEMPTS x (delay + 2 s handshake)).
_SCRIPT_TIMEOUT_S = 15.0 + RECONNECT_ATTEMPTS * (RECONNECT_DELAY_S + 3.0)
_CONNECT_MARGIN_S = 15.0


class UrRemoteSession:
	"""Handle to one controller session living in a helper process."""

	__slots__ = ("client", "ip_address")

	def __init__(self, client: SdkHostClient, ip_address: str) -> None:
		self.client = client
		self.ip_address = str(ip_address or "")


def sdk_available() -> bool:
	"""ur_rtde is installed (checked without importing it into the editor)."""
	try:
		return all(importlib.util.find_spec(m) is not None for m in ("rtde_receive", "rtde_control"))
	except (ImportError, ValueError):
		return False


def _call(session: Optional[UrRemoteSession], method: str, *args: Any, timeout_s: float, **kwargs: Any) -> Any:
	if session is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		return session.client.call(method, *args, timeout_s=timeout_s, **kwargs)
	except SdkRemoteError as exc:
		raise UniversalRobotSdkError(str(exc)) from exc
	except SdkHostError as exc:
		text = str(exc)
		if not text.lower().startswith("connection lost"):
			text = f"Connection lost: {text}"
		raise UniversalRobotSdkError(text) from exc


def open_session(ip_address: str) -> UrRemoteSession:
	"""Start the helper process for ``ip_address`` (no controller I/O yet)."""
	ip = str(ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	client = SdkHostClient("ur", _SERVICE)
	try:
		client.start()
	except SdkHostError as exc:
		raise UniversalRobotSdkError(str(exc)) from exc
	return UrRemoteSession(client, ip)


def connect_session(session: UrRemoteSession, timeout_ms: int) -> None:
	"""Open RTDE receive in the helper. Stops the helper if that fails."""
	try:
		timeout_s = max(1, int(timeout_ms)) / 1000.0
	except Exception:
		timeout_s = 10.0
	limit_s = timeout_s + _CONNECT_MARGIN_S
	try:
		session.client.call("connect", session.ip_address, timeout_ms, timeout_s=limit_s)
	except SdkRemoteError as exc:
		session.client.close()
		raise UniversalRobotSdkError(str(exc)) from exc
	except SdkHostCrashed as exc:
		session.client.close()
		raise UniversalRobotSdkError(str(exc)) from exc
	except SdkHostError as exc:
		# ur_rtde's constructor sits in the OS TCP connect (~21 s) on an
		# unreachable host regardless of timeout_ms.
		session.client.close()
		raise UniversalRobotSdkError(
			f"Connect timed out: no RTDE answer from {session.ip_address} within {limit_s:.0f} s. "
			"Check the IP address and network cable."
		) from exc
	except BaseException:
		session.client.close()
		raise


def connect_robot(ip_address: str, timeout_ms: int) -> UrRemoteSession:
	"""Start a helper process and open RTDE receive in it."""
	session = open_session(ip_address)
	connect_session(session, timeout_ms)
	return session


def disconnect_robot(session: Optional[UrRemoteSession]) -> None:
	"""Close the controller session and stop its helper process."""
	if session is None:
		return
	try:
		session.client.call("disconnect", timeout_s=_DISCONNECT_TIMEOUT_S)
	except SdkHostError:
		pass
	session.client.close()


def kill_session(session: Optional[UrRemoteSession]) -> None:
	"""Terminate the helper now (any thread); a worker blocked on it fails fast."""
	if session is not None:
		session.client.kill()


def session_is_connected(session: Optional[UrRemoteSession], *, probe_host: bool = False) -> bool:
	del probe_host
	try:
		return bool(_call(session, "is_connected", timeout_s=_QUERY_TIMEOUT_S))
	except UniversalRobotSdkError:
		return False


def reconnect_receive(
	session: Optional[UrRemoteSession],
	*,
	attempts: int = RECONNECT_ATTEMPTS,
	delay_s: float = RECONNECT_DELAY_S,
) -> bool:
	timeout_s = 10.0 + max(1, int(attempts)) * (max(0.2, float(delay_s)) + 3.0)
	try:
		return bool(
			_call(session, "reconnect_receive", attempts=attempts, delay_s=delay_s, timeout_s=timeout_s)
		)
	except UniversalRobotSdkError:
		return False


def send_script_file(session: Optional[UrRemoteSession], abs_script_path: str) -> None:
	_call(session, "send_script_file", str(abs_script_path), timeout_s=_SCRIPT_TIMEOUT_S)


def send_movel(
	session: Optional[UrRemoteSession],
	pose_m_rotvec: Tuple[float, float, float, float, float, float],
	*,
	speed_m_s: float = 0.25,
	accel_m_s2: float = 1.2,
) -> None:
	pose = tuple(float(v) for v in pose_m_rotvec)
	_call(session, "send_movel", pose, float(speed_m_s), float(accel_m_s2), timeout_s=_SCRIPT_TIMEOUT_S)


def send_halt(session: Optional[UrRemoteSession]) -> None:
	_call(session, "send_halt", timeout_s=_SCRIPT_TIMEOUT_S)


def apply_digital_io(
	session: Optional[UrRemoteSession],
	io_type: str,
	index: int,
	value: bool,
	*,
	read: bool = False,
) -> bool:
	return bool(
		_call(
			session,
			"apply_digital_io",
			str(io_type),
			int(index),
			bool(value),
			read=bool(read),
			timeout_s=_IO_TIMEOUT_S + _SCRIPT_TIMEOUT_S,
		)
	)


def is_program_running(session: Optional[UrRemoteSession]) -> bool:
	try:
		return bool(_call(session, "is_program_running", timeout_s=_QUERY_TIMEOUT_S))
	except UniversalRobotSdkError:
		return False


def safety_fault_message(session: Optional[UrRemoteSession]) -> str:
	try:
		return str(_call(session, "safety_fault_message", timeout_s=_QUERY_TIMEOUT_S) or "")
	except UniversalRobotSdkError:
		return ""


def robot_not_ready_message(session: Optional[UrRemoteSession]) -> str:
	if session is None:
		return "Robot is not connected."
	try:
		return str(_call(session, "robot_not_ready_message", timeout_s=_QUERY_TIMEOUT_S) or "")
	except UniversalRobotSdkError as exc:
		return str(exc)


def get_tcp_pose(session: Optional[UrRemoteSession]) -> Tuple[float, ...]:
	return tuple(float(v) for v in _call(session, "get_tcp_pose", timeout_s=_QUERY_TIMEOUT_S))


def get_joints(session: Optional[UrRemoteSession]) -> Tuple[float, ...]:
	return tuple(float(v) for v in _call(session, "get_joints", timeout_s=_QUERY_TIMEOUT_S))

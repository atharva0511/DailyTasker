# Implementing a play routine

A **play routine** is a per-frame loop that runs in **Edit Mode**. Use it for live preview, search, lift, or simulate — work that needs one step per viewport frame **without** entering Play Mode.

Play Mode snapshots and restores the whole scene. A play routine does **not**. Changes you make in the loop stay.

The top ribbon **Play** / **Stop** run the Sequencer, not Play Mode. Per-frame previews belong on a component button (`Simulate`, `Lift to safety`, …) that starts a play routine.

Existing examples: `TestComponent` (Print Loop 100), `LiftToSafetyComponent`, `ToolTraceComponent.simulate_trace`, `MotionPlannerComponent.simulate_playback`, `GPLeakPathGeneratorComponent`.

---

## When to use one

| Need | Use |
|---|---|
| Animate / search / lift **now**, keep the result | Play routine (`start_play_routine`) |
| Throwaway Play Mode experiment that reverts on Stop | `Component.update()` (Play Mode is unused from the ribbon today) |
| Ordered Inspector commands (`RUN` / `EDIT` / `GET` / `WAIT`) | Sequencer dock / TCP |

Do **not** start a play routine from `update()`. Do **not** call `dispatcher.execute()` from the loop (that deadlocks the Qt thread).

---

## Contract

```text
loop_fn(delta_time: float) -> bool
```

- `delta_time` is seconds since the last tick, clamped to `[0, 0.1]`.
- Return `True` to run again next frame.
- Return `False` to unregister (success, give-up, or you already called cleanup).
- `handle.stop()` unregisters immediately (Cancel / Stop simulate). The loop is **not** called again.

Each tick, after every active loop:

1. `scene.collision_system.check_all()`
2. Viewport refresh (`frame_ready`)

So a loop that inspects collision is seeing **last frame’s** `check_all`, unless the start button ran `check_all()` itself (Lift to safety does this).

Pass a **bound method** (`self._loop`), not a lambda that the runner cannot keep alive with the component.

---

## Minimal component

```python
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import inspector_button


@register_component
class DemoSweepComponent(Component):
    type_name = "DemoSweep"
    category = "Others"

    def __init__(self) -> None:
        self._handle = None
        self._iters = 0

    @inspector_button("Sweep", tooltip="Edit-mode play routine", order=0)
    def start_sweep(self):
        if self._handle is not None and self._handle.is_running:
            return False, "already running"
        self._iters = 0
        self._handle = self.start_play_routine(self._sweep_loop, name="demo_sweep")
        if self._handle is None or not self._handle.is_running:
            return False, "did not start"
        return True  # started; see “TCP / Sequencer” if RUN must wait

    @inspector_button("Cancel sweep", tooltip="Stop the play routine", order=5)
    def cancel_sweep(self) -> None:
        if self._handle is not None:
            self._handle.stop()
            self._handle = None

    def _sweep_loop(self, delta_time: float) -> bool:
        self._iters += 1
        # mutate scene / IK target / joints here
        if self._done():
            self._handle = None
            return False
        return self._iters < 100
```

`Component.start_play_routine(loop_fn, name="")` is the only start API you need. It returns a `PlayRoutineHandle`. A handle with `routine_id < 0` is dead (`is_running` is always `False`; `stop()` is a no-op) — that happens if the component has no entity/scene, or Play Mode is active.

Store the handle on `self`. Prefix runtime fields with `_` so they are not serialized.

---

## Checklist

1. **Start button** (`@inspector_button`)
   - Refuse if `handle.is_running`.
   - Validate inputs; return `(False, "reason")` on a hard fail.
   - Reset loop state, then `self._handle = self.start_play_routine(self._loop, name="unique_name")`.
   - If `not handle.is_running`, restore any side effects and return `(False, "did not start")`.
   - Return `True` if the loop started (async), or `None` if the work was already done (Lift returns `None` when already collision-free).

2. **Loop** (`def _loop(self, delta_time: float) -> bool`)
   - One increment of work per call (nudge a target, advance a sample, interpolate a pose).
   - Use `delta_time` for speed-based motion; ignore it for “one step per frame”.
   - Return `False` when finished. Clear `_handle` and restore temporary state **before** that return if you have cleanup.

3. **Cancel button**
   - `handle.stop()` then `_handle = None`.
   - Restore anything you disabled (e.g. `RobotIK.enabled`).
   - If TCP/Sequencer waits on this routine, notify listeners with `(False, "cancelled")`.
   - Sequencer ribbon **Stop** does **not** discover this automatically — see **Sequencer Stop / `job.cancel`**.

4. **Cleanup**
   - Play Mode start calls `play_routine_runner.stop_all()` — your loop will not run again. Restore IK / flags in Cancel **and** when the loop exits, or they stay wrong after Stop.
   - If the owning component is deleted, the runner drops the entry (`weakref`). Still restore in Cancel / finish so a live scene is consistent.

---

## Rules the runner enforces

- **Refused while Play Mode is active.** Use `component.update()` in that case. The start call prints a warning and returns a dead handle.
- **Entering Play Mode** stops every routine (`stop_all()`).
- Exceptions in the loop are caught, printed as `PlayRoutineRunner: error in loop 'name': …`, and the routine is stopped (`keep = False`).
- Several routines can run at once. The ribbon stays “busy” until the **last** one ends.

Access the runner only when needed: `self.entity.scene.play_routine_runner`. Prefer `start_play_routine` / `handle.stop()`.

---

## Ribbon

| Situation | Ribbon |
|---|---|
| Sequence playing (even if the current `RUN` is a play routine) | **Green**. Stop stays enabled. First Stop interrupts Main (cancels `WAIT` **and** an in-flight async `RUN` that registered `job.cancel`) then runs the Stop Sequence; Stop again aborts. Hardware Connect / Plan Motion still wait until they finish or time out. |
| Play routine active, no sequence | **Blue**. Play / Pause / Stop disabled until every routine returns `False` or `handle.stop()`. Inspector Cancel / Stop simulate still work. |
| Idle | Normal. Play starts the Sequencer. |

Inspector buttons are how the user (and `RUN`) start and cancel the routine. Ribbon Stop during a **standalone** (no sequence) play routine does **not** cancel it — use the Inspector Cancel button. During a sequence, Stop only cancels the current `RUN` if that action registered `job.cancel` (see below).

---

## Collision and IK

- After all loops in a tick, `check_all()` runs. Do **not** call `check_all()` every loop unless you need same-frame results (it is already on the tick).
- Poll collision with `entity_is_colliding` / the collision matrix — see `MotionStudio/core/collision/utils.py`.
- For robot motion that must not fight `RobotIK`, save `ik.enabled`, set it `False` for the duration, restore on finish **and** cancel (MotionPlanner Simulate, Lift to safety).
- Synchronous IK inside a loop: `RobotIKComponent.solve_ik_now()` (safe from a play-routine tick).

---

## Button return values

`@inspector_button` methods are what TCP `RUN` and the Sequencer call. `interpret_button_result` maps the return to PASS/FAIL:

| Return | Meaning |
|---|---|
| `None` | Immediate **PASS** (nothing to report). Use when the goal is already met. |
| `True` | Immediate **PASS** *unless* a waiter is registered — then it means **started**, and the reply waits. |
| `False` or `(False, "reason")` | Immediate **FAIL**. |
| `"text"` / other | Immediate **PASS** with that `return` payload. |

Without a waiter, `return True` from Start answers `PASS` as soon as the loop is registered — the Sequencer moves to the next line while Simulate is still running. That is usually wrong.

---

## TCP / Sequencer: wait until the routine finishes

For `RUN,Entity,YourType,Your Button` to block until the preview ends:

1. Keep a listener list on the component (`add_*_listener` / `remove_*_listener`).
2. Call listeners with `(success: bool, message: str)` when the loop exits **and** when Cancel stops it.
3. Return `True` from the start button after the handle is running.
4. Register a waiter on `(type_name, method_name)` in `MotionStudio/core/remote/dispatcher.py` `_ASYNC_HANDLERS`.

The shared helper is `_wait_for_done_listener`. Pass `cancel_attr` so Sequencer Stop can abort the routine (same callable as the Inspector Cancel button):

```python
("YourType", "start_sweep"): _wait_for_done_listener(
    "add_sweep_listener",
    "remove_sweep_listener",
    "start_sweep",
    "sweep listeners unavailable",
    cancel_attr="cancel_sweep",
),
```

Lift and GP leak path use dedicated waiters (`_wait_for_lift`, `_wait_for_gp_leak_generate`) that set `job.cancel` the same way (`cancel_lift`, `cancel_generate`).

Listener pattern (same as ToolTrace / MotionPlanner):

```python
def add_sweep_listener(self, callback) -> None:
    if callback not in self._listeners:
        self._listeners.append(callback)

def remove_sweep_listener(self, callback) -> None:
    try:
        self._listeners.remove(callback)
    except ValueError:
        pass

def _notify_done(self, success: bool, message: str = "") -> None:
    for callback in list(self._listeners):
        try:
            callback(bool(success), str(message or ""))
        except Exception:
            pass
```

Notify from the loop’s exit path and from Cancel. If you only notify on `return False`, Cancel (`handle.stop()`) leaves TCP/Sequencer waiting until timeout.

`type_name` is the component’s `type_name` string. `method_name` is the Python method (`start_sweep`), not the button label. `RUN` accepts either the label (`Sweep`) or the method name.

### Sequencer Stop / `job.cancel`

Ribbon **Stop** does **not** cancel every play routine. `start_play_routine` alone is not enough.

The dispatcher polls the sequencer `stop_event` while an async `RUN` is in flight. If that job set `job.cancel`, Stop invokes it on the main thread (the Inspector Cancel method). The waiter then finishes (`FAIL` / `cancelled`), the Main step returns, and the **Stop Sequence** can run (a second Cancel is a no-op).

A new play routine is **not** picked up automatically. Wire all of:

1. **`_ASYNC_HANDLERS`** so TCP/Sequencer **wait** until the loop ends (otherwise `RUN` returns `PASS` as soon as Start returns `True` and the sequence already moved on).
2. **`job.cancel`** (or `_wait_for_done_listener(..., cancel_attr="cancel_sweep")`) pointing at the Cancel / Stop simulate method.
3. That method **`handle.stop()`**, restore hijacked state, and **notify listeners** so the waiter completes.

Putting **Cancel …** only in the Stop Sequence is not enough: Stop still has to abort the **current** Main `RUN` first, or the dispatcher lock stays held until the routine ends.

Wired today: Generate leak path, Lift to safety, MotionPlanner Simulate, ToolTrace Simulate, UniversalRobot RUN / Move To Target (`job.cancel` → **STOP**), Scan Mission (`job.cancel` → **Stop Scan Mission**), Path Mission (`job.cancel` → **Stop Path Mission**). **Not** wired: hardware Connect / Disconnect / Capture, Plan Motion — Stop waits those out (or times out), then runs the Stop Sequence.

---

## Reference implementations

| Component | Start / cancel | Notes |
|---|---|---|
| `TestComponent` | Print Loop 100 | Smallest loop (`name="print_100"`). No listeners / no sequencer wait. |
| `LiftToSafetyComponent` | Lift to safety / Cancel lift | Collision poll; restores `RobotIK.enabled`; `add_lift_listener`; `job.cancel`. |
| `ToolTraceComponent` | Simulate / Stop simulate | One waypoint pass; `add_trace_listener`; `cancel_attr="stop_simulate_trace"`. |
| `MotionPlannerComponent` | Simulate / Stop simulate | Joint trajectory + FK; `add_playback_listener`; `cancel_attr="stop_simulate_playback"`. |
| `GPLeakPathGeneratorComponent` | Generate leak path / Cancel generate | Poses RobotIK Target; `add_generate_listener`; `job.cancel`. |
| `ScanMissionComponent` | Run Scan Mission / Stop Scan Mission | Grid `movel` + Capture; `add_mission_listener`; `cancel_attr="stop_scan_mission"`. |
| `PathMissionComponent` | Run Path Mission / Stop Path Mission | Path waypoints + actions; `add_mission_listener`; `cancel_attr="stop_path_mission"`. |

Engine: `MotionStudio/core/scene/play_routine.py` (`PlayRoutineRunner`, `PlayRoutineHandle`). Hook: `Component.start_play_routine` in `MotionStudio/core/ecs/component.py`.

---

## Pitfalls

- **Do not snapshot-restore.** Whatever the loop writes is the scene. Copy poses you need to revert, or document that Simulate leaves the robot at the last sample.
- **Do not start from the Qt-thread `execute()` path.** Buttons run on the main thread; that is correct. The *dispatcher* `execute()` must stay on a worker (TCP / Sequencer).
- **Name the routine.** The `name=` shows up in runner error logs.
- **Guard re-entry.** A second click while running should `return False, "already running"`, not start a second loop.
- **Blue ribbon is not broken Stop.** Cancel lives on the Inspector button for a standalone routine. During a sequence, ribbon Stop interrupts Main and runs the Stop Sequence; it cancels the current play-routine `RUN` **only** if that action registered `job.cancel` (see **Sequencer Stop / `job.cancel`**).
- **`WAIT` is unrelated.** Sequencer `WAIT,<seconds>` is a protocol command, not a play routine.

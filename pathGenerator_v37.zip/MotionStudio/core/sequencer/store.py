"""Persist sequencer programs as JSON ``.seq`` files under ``<project>/sequence/``."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

SEQUENCE_DIR_NAME = "sequence"
DEFAULT_SEQUENCE_NAME = "default"
SEQ_SUFFIX = ".seq"
ACTIVE_FILE_NAME = "active.json"

_INVALID_NAME_CHARS = '<>:"/\\|?*'


@dataclass
class SequenceStep:
	command: str = ""
	continue_on_fail: bool = False

	def to_dict(self) -> Dict[str, Any]:
		return {
			"command": str(self.command or ""),
			"continue_on_fail": bool(self.continue_on_fail),
		}

	@classmethod
	def from_dict(cls, data: Any) -> "SequenceStep":
		raw = data if isinstance(data, dict) else {}
		return cls(
			command=str(raw.get("command", "") or ""),
			continue_on_fail=bool(raw.get("continue_on_fail", False)),
		)


def _steps_from_raw(raw: Any) -> List[SequenceStep]:
	steps: List[SequenceStep] = []
	if isinstance(raw, list):
		for entry in raw:
			steps.append(SequenceStep.from_dict(entry))
	return steps


@dataclass
class Sequence:
	name: str = DEFAULT_SEQUENCE_NAME
	steps: List[SequenceStep] = field(default_factory=list)
	stop_steps: List[SequenceStep] = field(default_factory=list)

	def to_dict(self) -> Dict[str, Any]:
		return {
			"name": str(self.name or DEFAULT_SEQUENCE_NAME),
			"steps": [s.to_dict() for s in self.steps],
			"stop_steps": [s.to_dict() for s in self.stop_steps],
		}

	@classmethod
	def from_dict(cls, data: Any, *, fallback_name: str = DEFAULT_SEQUENCE_NAME) -> "Sequence":
		raw = data if isinstance(data, dict) else {}
		name = str(raw.get("name", "") or fallback_name).strip() or fallback_name
		return cls(
			name=name,
			steps=_steps_from_raw(raw.get("steps", [])),
			stop_steps=_steps_from_raw(raw.get("stop_steps", [])),
		)


def sanitize_sequence_name(name: str) -> str:
	text = str(name or "").strip()
	for ch in _INVALID_NAME_CHARS:
		text = text.replace(ch, "_")
	text = text.strip(". ")
	return text or DEFAULT_SEQUENCE_NAME


def sequence_dir(project_root: Path) -> Path:
	return Path(project_root) / SEQUENCE_DIR_NAME


def sequence_path(project_root: Path, name: str) -> Path:
	safe = sanitize_sequence_name(name)
	return sequence_dir(project_root) / f"{safe}{SEQ_SUFFIX}"


def ensure_sequence_dir(project_root: Path) -> Path:
	folder = sequence_dir(project_root)
	folder.mkdir(parents=True, exist_ok=True)
	return folder


def list_sequence_names(project_root: Path) -> List[str]:
	folder = sequence_dir(project_root)
	if not folder.is_dir():
		return [DEFAULT_SEQUENCE_NAME]
	names = sorted(
		p.stem for p in folder.glob(f"*{SEQ_SUFFIX}") if p.is_file()
	)
	if DEFAULT_SEQUENCE_NAME not in names:
		names.insert(0, DEFAULT_SEQUENCE_NAME)
	return names or [DEFAULT_SEQUENCE_NAME]


def load_sequence(project_root: Path, name: str) -> Sequence:
	path = sequence_path(project_root, name)
	safe = sanitize_sequence_name(name)
	if not path.is_file():
		return Sequence(name=safe, steps=[])
	try:
		raw = json.loads(path.read_text(encoding="utf-8"))
	except (OSError, json.JSONDecodeError):
		return Sequence(name=safe, steps=[])
	seq = Sequence.from_dict(raw, fallback_name=safe)
	seq.name = safe
	return seq


def save_sequence(project_root: Path, sequence: Sequence) -> Path:
	ensure_sequence_dir(project_root)
	safe = sanitize_sequence_name(sequence.name)
	sequence.name = safe
	path = sequence_path(project_root, safe)
	path.write_text(json.dumps(sequence.to_dict(), indent=2) + "\n", encoding="utf-8")
	return path


def create_sequence(project_root: Path, name: str) -> Tuple[Optional[Sequence], str]:
	safe = sanitize_sequence_name(name)
	path = sequence_path(project_root, safe)
	if path.is_file():
		return None, f"sequence already exists: {safe}"
	seq = Sequence(name=safe, steps=[])
	save_sequence(project_root, seq)
	return seq, ""


def delete_sequence(project_root: Path, name: str) -> str:
	safe = sanitize_sequence_name(name)
	path = sequence_path(project_root, safe)
	if not path.is_file():
		return f"sequence not found: {safe}"
	try:
		path.unlink()
	except OSError as exc:
		return str(exc)
	if safe == DEFAULT_SEQUENCE_NAME:
		save_sequence(project_root, Sequence(name=DEFAULT_SEQUENCE_NAME, steps=[]))
	return ""


def load_active_name(project_root: Path) -> str:
	meta = sequence_dir(project_root) / ACTIVE_FILE_NAME
	if not meta.is_file():
		return DEFAULT_SEQUENCE_NAME
	try:
		raw = json.loads(meta.read_text(encoding="utf-8"))
	except (OSError, json.JSONDecodeError):
		return DEFAULT_SEQUENCE_NAME
	if not isinstance(raw, dict):
		return DEFAULT_SEQUENCE_NAME
	name = sanitize_sequence_name(str(raw.get("current", "") or DEFAULT_SEQUENCE_NAME))
	names = list_sequence_names(project_root)
	return name if name in names else DEFAULT_SEQUENCE_NAME


def save_active_name(project_root: Path, name: str) -> None:
	ensure_sequence_dir(project_root)
	safe = sanitize_sequence_name(name)
	meta = sequence_dir(project_root) / ACTIVE_FILE_NAME
	meta.write_text(json.dumps({"current": safe}, indent=2) + "\n", encoding="utf-8")


def ensure_default_sequence(project_root: Path) -> Sequence:
	"""Create ``default.seq`` if missing; return the active sequence."""
	ensure_sequence_dir(project_root)
	default_path = sequence_path(project_root, DEFAULT_SEQUENCE_NAME)
	if not default_path.is_file():
		save_sequence(project_root, Sequence(name=DEFAULT_SEQUENCE_NAME, steps=[]))
	current = load_active_name(project_root)
	if not sequence_path(project_root, current).is_file():
		current = DEFAULT_SEQUENCE_NAME
	save_active_name(project_root, current)
	return load_sequence(project_root, current)

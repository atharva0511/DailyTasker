"""Path Mission: play a PathGeneration program on a live Robot."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Annotated, Any, Dict, List, Optional, Tuple

from PyQt6.QtGui import QVector3D

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.robot import Robot
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.path.actions import (
	KIND_SET,
	KIND_WAIT_SIGNAL,
	KIND_WAIT_TIME,
	PathAction,
	resolve_waypoint_indices,
	summary_text,
)
from MotionStudio.core.path.exporters.urscript_exporter import euler_to_rotation_vector
from MotionStudio.core.remote.protocol import interpret_button_result
from MotionStudio.ui.inspector.metadata import (
	ConnectionStatus,
	Order,
	ReadOnly,
	Tooltip,
	inspector_button,
)


STATUS_IDLE = "Idle"
STATUS_RUNNING = "Running…"
STATUS_STOPPING = "Stopping…"


@dataclass
class _Step:
	kind: str
	pos_mm: Optional[QVector3D] = None
	rotvec_deg: Optional[QVector3D] = None
	speed_m_s: float = 0.25
	accel_m_s2: float = 1.2
	world_pos: Optional[QVector3D] = None
	action: Optional[PathAction] = None
	wp_index: int = 0
	wp_count: int = 0


def _rotvec_rad_to_deg(rx: float, ry: float, rz: float) -> QVector3D:
	return QVector3D(math.degrees(float(rx)), math.degrees(float(ry)), math.degrees(float(rz)))


def _hw_connected(component: Any) -> bool:
	return bool(getattr(component, "_was_connected", False))


def _actions_by_waypoint(
	actions: Optional[List[PathAction]],
	waypoint_count: int,
) -> Dict[int, List[PathAction]]:
	mapping: Dict[int, List[PathAction]] = {}
	for action in actions or []:
		if not getattr(action, "enabled", True):
			continue
		for w_idx in resolve_waypoint_indices(action, waypoint_count):
			mapping.setdefault(w_idx, []).append(action)
	return mapping


@register_component
class PathMissionComponent(Component):
	type_name = "PathMission"
	category = "Path generation and planning"
	description = (
		"<p><b>Path Mission</b></p>"
		"<p>Runs a <b>PathGeneration</b> program on a connected <b>Robot</b>: "
		"<code>movel</code> each waypoint, then that waypoint's path actions "
		"(Set Output, Wait Time, Wait Signal).</p>"
		"<p>Not a 1:1 replay of exported URScript — every waypoint is a discrete "
		"Move To Target (no <code>movep</code> / CNT blend).</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Assign <b>path</b> (PathGeneration) and <b>robot</b> (UniversalRobot). "
		"Connect the robot. Bind <b>RobotDescription</b> on the UniversalRobot "
		"<b>robot</b> field so poses are in the arm base frame.</li>"
		"<li><b>Run Path Mission</b> / <b>Stop Path Mission</b>. Stop aborts the "
		"routine and UR motion; an in-flight Apply I/O still finishes.</li>"
		"</ul>"
	)

	path: Annotated[
		Optional[PathComponent],
		Order(0),
		Tooltip("PathGeneration program to execute (waypoints + segment actions)."),
	]
	robot: Annotated[
		Optional[Robot],
		Order(10),
		Tooltip("Hardware robot controller (UniversalRobot or other Robot subclass)."),
	]
	mission_status: Annotated[
		str,
		ConnectionStatus(connected=(STATUS_IDLE,), busy=(STATUS_RUNNING, STATUS_STOPPING)),
		ReadOnly(),
		Order(20),
		Tooltip("Live mission state. Not restored from the scene file."),
	]
	fail_on_wait_timeout: Annotated[
		bool,
		Order(30),
		Tooltip(
			"When true (default), a Wait Signal that exceeds timeout_s aborts the "
			"mission. When false, the action is skipped (exported URScript only logs)."
		),
	] = True

	def __init__(self) -> None:
		self.path = None
		self.robot = None
		self.mission_status = STATUS_IDLE
		self.fail_on_wait_timeout = True
		self._handle = None
		self._listeners: list = []
		self._notified = False
		self._cancel = False
		self._steps: List[_Step] = []
		self._step_index = 0
		self._phase = "idle"
		self._await_kind = ""
		self._job_done = False
		self._job_ok = False
		self._job_message = ""
		self._wait_elapsed = 0.0
		self._bound_robot: Optional[Robot] = None
		self._current_world_pos: Optional[QVector3D] = None

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "PathMissionComponent":
		inst = super().from_dict(data)
		inst.force_setattr("mission_status", STATUS_IDLE)
		return inst

	def add_mission_listener(self, callback) -> None:
		if callback not in self._listeners:
			self._listeners.append(callback)

	def remove_mission_listener(self, callback) -> None:
		try:
			self._listeners.remove(callback)
		except ValueError:
			pass

	def _notify_done(self, success: bool, message: str = "") -> None:
		if self._notified:
			return
		self._notified = True
		for callback in list(self._listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	@inspector_button(
		"Run Path Mission",
		tooltip="movel each path waypoint and run its actions (requires connected Robot)",
		order=200,
	)
	def run_path_mission(self):
		if self._handle is not None and self._handle.is_running:
			return False, "path mission is already running"
		entity = self.entity
		if entity is None:
			return False, "no entity"
		scene = entity.scene
		if scene is None:
			return False, "entity is not in a scene"
		pm = getattr(scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			return False, "refused while Play Mode is active"

		path = self._resolved_path()
		if path is None:
			return False, "assign a PathGeneration"
		mover = self._resolved_robot()
		if mover is None:
			return False, "assign a Robot"
		if not _hw_connected(mover):
			return False, "robot is not connected"

		rd = self._resolved_robot_description(mover)
		if rd is None:
			return False, "bind RobotDescription on the UniversalRobot robot field"

		steps, build_err = self._build_steps(path, rd)
		if build_err:
			return False, build_err
		if not steps:
			return False, "path has no waypoints"

		self._steps = steps
		self._step_index = 0
		self._phase = "start_step"
		self._cancel = False
		self._notified = False
		self._await_kind = ""
		self._job_done = False
		self._wait_elapsed = 0.0
		self._current_world_pos = None
		self._bound_robot = mover
		mover.add_job_listener(self._on_hw_job)
		self.mission_status = STATUS_RUNNING
		self._handle = self.start_play_routine(self._loop, name="path_mission")
		if self._handle is None or not self._handle.is_running:
			self._teardown_hw()
			self.mission_status = STATUS_IDLE
			return False, "path mission did not start"
		return True

	@inspector_button(
		"Stop Path Mission",
		tooltip="Abort the path walk and halt the robot (in-flight Apply I/O still finishes)",
		order=210,
	)
	def stop_path_mission(self) -> None:
		running = self._handle is not None and self._handle.is_running
		if not running and self._bound_robot is None:
			return
		self._cancel = True
		self.mission_status = STATUS_STOPPING
		mover = self._bound_robot
		if mover is not None:
			try:
				mover.stop_robot()
			except Exception:
				pass
		if self._handle is not None:
			self._handle.stop()
			self._handle = None
		self._teardown_hw()
		self.mission_status = STATUS_IDLE
		self._notify_done(False, "cancelled")

	def _loop(self, delta_time: float) -> bool:
		if self._cancel:
			self._finish(False, "cancelled")
			return False
		mover = self._bound_robot
		if mover is None:
			self._finish(False, "robot unbound")
			return False

		if self._phase in ("wait_move", "wait_io", "wait_signal"):
			if self._phase == "wait_signal":
				self._wait_elapsed += max(0.0, float(delta_time))
			if not self._job_done:
				return True
			if not self._job_ok:
				label = "move" if self._phase == "wait_move" else "I/O"
				self._finish(False, self._job_message or f"{label} failed")
				return False
			if self._phase == "wait_signal":
				keep = self._advance_wait_signal(mover)
				if self._phase != "start_step":
					return keep
			else:
				self._step_index += 1
				self._phase = "start_step"

		if self._phase == "wait_time":
			self._wait_elapsed += max(0.0, float(delta_time))
			step = self._current_step()
			duration = float(getattr(step.action, "duration_s", 0.0) or 0.0) if step else 0.0
			if self._wait_elapsed + 1e-9 < duration:
				return True
			self._step_index += 1
			self._phase = "start_step"

		if self._phase == "start_step":
			return self._start_next_step(mover)

		self._finish(False, f"unknown phase: {self._phase}")
		return False

	def _start_next_step(self, mover: Robot) -> bool:
		while self._step_index < len(self._steps):
			step = self._steps[self._step_index]
			kind = str(step.kind or "")
			if kind == "move":
				return self._start_move(mover, step)
			if kind == KIND_SET:
				return self._start_io(mover, step, phase="wait_io")
			if kind == KIND_WAIT_TIME:
				duration = float(getattr(step.action, "duration_s", 0.0) or 0.0) if step.action else 0.0
				if duration <= 1e-9:
					self._step_index += 1
					continue
				self._wait_elapsed = 0.0
				self._phase = "wait_time"
				return True
			if kind == KIND_WAIT_SIGNAL:
				self._wait_elapsed = 0.0
				return self._start_io(mover, step, phase="wait_signal")
			self._finish(False, f"unknown step: {kind}")
			return False
		n = 0
		if self._steps:
			n = int(self._steps[-1].wp_count)
		self._finish(True, f"ran {n} waypoint{'s' if n != 1 else ''}")
		return False

	def _start_move(self, mover: Robot, step: _Step) -> bool:
		if step.pos_mm is None or step.rotvec_deg is None:
			self._finish(False, "move step is missing a pose")
			return False
		self._current_world_pos = (
			QVector3D(step.world_pos) if step.world_pos is not None else None
		)
		Debug.log(
			f"PathMission: waypoint {step.wp_index + 1}/{step.wp_count}"
		)
		if hasattr(mover, "move_speed_m_s"):
			try:
				mover.move_speed_m_s = float(step.speed_m_s)
			except Exception:
				pass
		if hasattr(mover, "move_accel_m_s2"):
			try:
				mover.move_accel_m_s2 = float(step.accel_m_s2)
			except Exception:
				pass
		try:
			mover.set_move_target(QVector3D(step.pos_mm), QVector3D(step.rotvec_deg))
		except Exception as exc:
			self._finish(False, f"set_move_target failed ({exc})")
			return False
		self._arm_wait("move_to_target")
		result = mover.move_to_target()
		if result is True:
			self._phase = "wait_move"
			return True
		_ok, output = interpret_button_result(result)
		self._finish(False, output or "move_to_target did not start")
		return False

	def _start_io(self, mover: Robot, step: _Step, *, phase: str) -> bool:
		action = step.action
		if action is None:
			self._finish(False, "I/O step is missing an action")
			return False
		try:
			mover.set_io_target(str(action.bank), int(action.port), bool(action.state))
		except Exception as exc:
			self._finish(False, f"set_io_target failed ({exc})")
			return False
		self._arm_wait("set_io")
		result = mover.apply_io()
		if result is True:
			self._phase = phase
			return True
		_ok, output = interpret_button_result(result)
		self._finish(False, output or "apply_io did not start")
		return False

	def _advance_wait_signal(self, mover: Robot) -> bool:
		step = self._current_step()
		if step is None or step.action is None:
			self._finish(False, "Wait Signal step is missing an action")
			return False
		level = bool(getattr(mover, "io_value", False))
		expected = bool(step.action.state)
		if level == expected:
			self._step_index += 1
			self._phase = "start_step"
			return True
		timeout = float(getattr(step.action, "timeout_s", 0.0) or 0.0)
		if timeout > 1e-9 and self._wait_elapsed + 1e-9 >= timeout:
			if bool(self.fail_on_wait_timeout):
				self._finish(
					False,
					f"Wait Signal timed out ({summary_text(step.action)})",
				)
				return False
			self._step_index += 1
			self._phase = "start_step"
			return True
		return self._start_io(mover, step, phase="wait_signal")

	def _current_step(self) -> Optional[_Step]:
		if 0 <= self._step_index < len(self._steps):
			return self._steps[self._step_index]
		return None

	def _arm_wait(self, kind: str) -> None:
		self._await_kind = kind
		self._job_done = False
		self._job_ok = False
		self._job_message = ""

	def _on_hw_job(self, kind: str, success: bool, message: str) -> None:
		if kind != self._await_kind:
			return
		self._job_done = True
		self._job_ok = bool(success)
		self._job_message = str(message or "")

	def _finish(self, success: bool, message: str) -> None:
		self._handle = None
		self._teardown_hw()
		self.mission_status = STATUS_IDLE
		self._notify_done(success, message)

	def _teardown_hw(self) -> None:
		mover = self._bound_robot
		self._bound_robot = None
		self._await_kind = ""
		self._phase = "idle"
		self._steps = []
		self._current_world_pos = None
		if mover is not None:
			try:
				mover.remove_job_listener(self._on_hw_job)
			except Exception:
				pass

	def on_viewport_draw(self) -> None:
		if str(self.mission_status) != STATUS_RUNNING:
			return
		pos = self._current_world_pos
		if pos is None:
			return
		Debug.draw_point(pos, size=12.0, color=(1.0, 0.25, 0.2), opacity=0.95)

	def _build_steps(
		self,
		path: PathComponent,
		rd: RobotDescriptionComponent,
	) -> Tuple[List[_Step], str]:
		try:
			poses_by_seg = path.get_waypoints_in_robot_frame(rd)
			world_by_seg = path.get_world_waypoints_by_segment()
		except Exception as exc:
			return [], str(exc)
		segments = list(getattr(path, "segments", None) or [])
		total = sum(len(s) for s in poses_by_seg)
		if total <= 0:
			return [], "path has no waypoints"
		program_speed = float(getattr(path, "speed", 0.25) or 0.25)
		program_accel = float(getattr(path, "acceleration", 1.2) or 1.2)
		steps: List[_Step] = []
		global_i = 0
		for seg_idx, segment in enumerate(segments):
			poses = poses_by_seg[seg_idx] if seg_idx < len(poses_by_seg) else []
			worlds = world_by_seg[seg_idx] if seg_idx < len(world_by_seg) else []
			mult = float(getattr(segment, "speed_multiplier", 1.0) or 1.0)
			speed = max(1e-4, program_speed * mult)
			accel = max(1e-4, program_accel)
			amap = _actions_by_waypoint(getattr(segment, "actions", None), len(poses))
			for w_idx, pose in enumerate(poses):
				x, y, z, rx, ry, rz = (float(v) for v in pose)
				rv = euler_to_rotation_vector(rx, ry, rz)
				world_pos = None
				if w_idx < len(worlds):
					wx, wy, wz = worlds[w_idx][:3]
					world_pos = QVector3D(float(wx), float(wy), float(wz))
				steps.append(
					_Step(
						kind="move",
						pos_mm=QVector3D(x, y, z),
						rotvec_deg=_rotvec_rad_to_deg(rv[0], rv[1], rv[2]),
						speed_m_s=speed,
						accel_m_s2=accel,
						world_pos=world_pos,
						wp_index=global_i,
						wp_count=total,
					)
				)
				for action in amap.get(w_idx, []):
					steps.append(
						_Step(
							kind=str(action.kind),
							action=action,
							wp_index=global_i,
							wp_count=total,
							world_pos=world_pos,
						)
					)
				global_i += 1
		return steps, ""

	def _resolve_ref(self, value: Any, cls: type) -> Any:
		if isinstance(value, cls):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(cls)
				if comp is not None:
					return comp
		return None

	def _resolved_path(self) -> Optional[PathComponent]:
		comp = self._resolve_ref(self.path, PathComponent)
		if isinstance(comp, PathComponent):
			self.path = comp
			return comp
		return None

	def _resolved_robot(self) -> Optional[Robot]:
		comp = self._resolve_ref(self.robot, Robot)
		if isinstance(comp, Robot):
			self.robot = comp
			return comp
		return None

	def _resolved_robot_description(self, mover: Robot) -> Optional[RobotDescriptionComponent]:
		value = getattr(mover, "robot", None)
		if isinstance(value, RobotDescriptionComponent):
			return value
		entity = getattr(mover, "entity", None)
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if comp is not None:
					mover.robot = comp
					return comp
		return None

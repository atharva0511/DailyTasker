"""Brand-agnostic area scanner.

Not ``@register_component`` — it does not appear in Add Component. Bind
``Optional[Scanner]`` on a job component to accept MechmindScanner or a
future Photoneo (or other) subclass. ``Entity.get_component(Scanner)`` uses
``isinstance``, so those concrete drivers match.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from MotionStudio.core.ecs.component import Component
from MotionStudio.core.hardwares.hardware_runtime import HardwareJobListener


class Scanner(Component, ABC):
	"""Camera that can capture a point cloud onto a Target.

	Concrete classes keep their own ``type_name`` (e.g. ``MechmindScanner``).
	"""

	type_name: ClassVar[str] = "Scanner"
	category: ClassVar[str] = "Hardware/Scanners"
	description: ClassVar[str] = (
		"Abstract hardware scanner. Assign a MechmindScanner (or other Scanner "
		"subclass) entity; do not add this type from the Inspector."
	)

	@abstractmethod
	def add_job_listener(self, callback: HardwareJobListener) -> None:
		"""Register ``callback(kind, success, message)`` for worker jobs."""

	@abstractmethod
	def remove_job_listener(self, callback: HardwareJobListener) -> None:
		"""Unregister a listener added with ``add_job_listener``."""

	@abstractmethod
	def capture_scan(self) -> Any:
		"""Queue one capture onto the configured Target / scan file."""

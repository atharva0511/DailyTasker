"""Executes remote commands on the Qt main thread and reports the result.

Connection threads call :meth:`RemoteCommandDispatcher.execute`, which hands the
job to the main thread through a queued signal and blocks on a
:class:`threading.Event` until the job finishes. The Qt event loop therefore
stays responsive while the client socket waits.

``RUN`` can only reach methods decorated with ``@inspector_button``, ``EDIT``
only writable Inspector fields, and ``GET`` any Inspector-visible field
(including read-only ones), so the remote surface is exactly what a user
could click, type, or read in the Inspector. ``WAIT`` sleeps on the calling
thread and does not take the scene lock.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Tuple

from PyQt6.QtCore import QObject, Qt, pyqtSignal

from MotionStudio.core.remote.protocol import (
	EDIT_OP,
	GET_OP,
	WAIT_OP,
	RemoteCommand,
	interpret_button_result,
	sanitize_output,
)

if TYPE_CHECKING:
	from PyQt6.QtGui import QUndoStack

	from MotionStudio.core.ecs.component import Component
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene
	from MotionStudio.ui.inspector.reflection import FieldSpec


@dataclass
class _Job:
	"""One in-flight remote command."""

	command: RemoteCommand
	done: threading.Event = field(default_factory=threading.Event)
	ok: bool = False
	output: str = ""
	# Set while an asynchronous action (e.g. Plan Motion) is still running so
	# ``_run_job`` knows not to complete the job itself.
	pending: bool = False
	# Kept alive for the duration of an async wait (listener de-registration).
	cleanup: Optional[Callable[[], None]] = None
	# Optional Inspector-click hook; TCP jobs leave this unset.
	on_finished: Optional[Callable[[bool, str], None]] = None
	# Main-thread callable that aborts an in-flight async RUN (Sequencer Stop).
	cancel: Optional[Callable[[], None]] = None
	cancel_requested: bool = False

	def finish(self, ok: bool, output: object = None) -> None:
		if self.done.is_set():
			return
		self.ok = bool(ok)
		self.output = sanitize_output(output)
		cleanup = self.cleanup
		self.cleanup = None
		if cleanup is not None:
			try:
				cleanup()
			except Exception:
				pass
		self.done.set()
		callback = self.on_finished
		self.on_finished = None
		if callback is not None:
			try:
				callback(self.ok, self.output)
			except Exception:
				pass


def _normalize_label(text: str) -> str:
	"""Fold a method name or button label for tolerant matching."""
	return "".join(ch for ch in str(text or "").lower() if ch.isalnum())


class RemoteCommandDispatcher(QObject):
	"""Resolves and runs ``RUN`` / ``EDIT`` / ``GET`` commands against the live scene."""

	_job_ready = pyqtSignal(object)
	_job_cancel = pyqtSignal(object)

	def __init__(
		self,
		scene: "Scene",
		parent: Optional[QObject] = None,
		*,
		undo_stack: Optional["QUndoStack"] = None,
	) -> None:
		super().__init__(parent)
		self._scene = scene
		self._undo_stack = undo_stack
		# TCP and the Sequencer both call ``execute`` from worker threads.
		# One lock so they cannot interleave scene mutations.
		self._execute_lock = threading.RLock()
		self._job_ready.connect(self._run_job, Qt.ConnectionType.QueuedConnection)
		self._job_cancel.connect(self._run_job_cancel, Qt.ConnectionType.QueuedConnection)

	def set_undo_stack(self, undo_stack: Optional["QUndoStack"]) -> None:
		"""Route ``EDIT`` through the editor's undo stack so Ctrl+Z reverts it."""
		self._undo_stack = undo_stack

	# ------------------------------------------------------------------ public

	def execute(
		self,
		command: RemoteCommand,
		timeout_s: float,
		stop_event: Optional[threading.Event] = None,
	) -> Tuple[bool, str]:
		"""Run ``command`` on the main thread; blocks the calling thread.

		Must not be called from the Qt main thread: it waits on ``job.done``
		while ``_run_job`` also needs that thread.

		``WAIT`` sleeps on the calling thread and does not take the scene lock.
		``stop_event`` (Sequencer Stop) cancels an in-flight wait **and** an
		in-flight async ``RUN`` that registered ``job.cancel`` (Generate leak
		path, Lift to safety, Simulate).

		Returns ``(ok, output)``. A command that outlives ``timeout_s`` reports
		failure, but the underlying action is not cancelled unless Stop already
		invoked ``job.cancel``. Callers are serialized so a TCP client and the
		Sequencer cannot overlap.
		"""
		if command.op == WAIT_OP:
			return self._execute_wait(command, timeout_s, stop_event)
		with self._execute_lock:
			job = _Job(command=command)
			self._job_ready.emit(job)
			slice_s = 0.05
			deadline = time.monotonic() + float(timeout_s)
			while not job.done.is_set():
				remaining = deadline - time.monotonic()
				if remaining <= 0.0:
					return False, f"timeout after {float(timeout_s):.0f}s: {command.describe()}"
				if (
					stop_event is not None
					and stop_event.is_set()
					and not job.cancel_requested
				):
					job.cancel_requested = True
					self._job_cancel.emit(job)
				job.done.wait(min(slice_s, remaining))
			return job.ok, job.output

	@staticmethod
	def _execute_wait(
		command: RemoteCommand,
		timeout_s: float,
		stop_event: Optional[threading.Event],
	) -> Tuple[bool, str]:
		raw = str(command.value or "").strip()
		try:
			seconds = float(raw)
		except ValueError:
			return False, "WAIT duration must be a number of seconds"
		if seconds != seconds or seconds < 0.0:
			return False, "WAIT duration must be >= 0"
		limit = float(timeout_s)
		if seconds > limit:
			return False, f"timeout after {limit:.0f}s: {command.describe()}"
		deadline = time.monotonic() + seconds
		slice_s = 0.05
		while True:
			if stop_event is not None and stop_event.is_set():
				return False, "wait cancelled"
			remaining = deadline - time.monotonic()
			if remaining <= 0.0:
				return True, ""
			wait_for = min(slice_s, remaining)
			if stop_event is not None:
				if stop_event.wait(wait_for):
					return False, "wait cancelled"
			else:
				time.sleep(wait_for)

	# ------------------------------------------------------------- main thread

	def _run_job(self, job: _Job) -> None:
		try:
			self._dispatch(job)
		except Exception as exc:
			job.finish(False, f"internal error: {exc}")
		if not job.pending and not job.done.is_set():
			job.finish(False, "command produced no result")

	def _run_job_cancel(self, job: _Job) -> None:
		"""Main-thread abort for an in-flight async RUN (Sequencer Stop)."""
		fn = getattr(job, "cancel", None)
		if not callable(fn):
			return
		try:
			fn()
		except Exception:
			pass

	def _dispatch(self, job: _Job) -> None:
		cmd = job.command

		entity, error = self._resolve_entity(cmd.entity)
		if entity is None:
			job.finish(False, error)
			return

		component, error = self._resolve_component(entity, cmd.component)
		if component is None:
			job.finish(False, error)
			return

		if cmd.op == EDIT_OP:
			self._dispatch_edit(job, entity, component)
			return
		if cmd.op == GET_OP:
			self._dispatch_get(job, component)
			return
		self._dispatch_run(job, entity, component)

	def _dispatch_run(self, job: _Job, entity: "Entity", component: "Component") -> None:
		method, error = self._resolve_button(component, job.command.member)
		if method is None:
			job.finish(False, error)
			return
		_execute_inspector_button(self._scene, entity, method, job)

	def _dispatch_edit(self, job: _Job, entity: "Entity", component: "Component") -> None:
		from MotionStudio.core.remote.value_parser import coerce_value

		cmd = job.command
		spec, error = self._resolve_field(component, cmd.member)
		if spec is None:
			job.finish(False, error)
			return

		value, error = coerce_value(spec, cmd.value or "", self._scene)
		if error:
			job.finish(False, error)
			return

		try:
			self._apply_field_change(entity, component, spec, value)
		except Exception as exc:
			job.finish(False, f"could not set {cmd.member}: {exc}")
			return

		job.finish(True, None)

	def _dispatch_get(self, job: _Job, component: "Component") -> None:
		from MotionStudio.core.remote.value_parser import format_field_value

		cmd = job.command
		spec, error = self._resolve_field(component, cmd.member, writable=False)
		if spec is None:
			job.finish(False, error)
			return

		try:
			raw = spec.getter()
		except Exception as exc:
			job.finish(False, f"could not read {cmd.member}: {exc}")
			return

		text, error = format_field_value(spec, raw, self._scene)
		if error:
			job.finish(False, error)
			return
		job.finish(True, text)

	def _apply_field_change(
		self,
		entity: "Entity",
		component: "Component",
		spec: "FieldSpec",
		value: Any,
	) -> None:
		"""Write the field the same way the Inspector does (undoable when possible)."""
		from MotionStudio.core.undo.commands import PropertyChangeCommand
		from MotionStudio.ui.inspector.reflection import clone_value

		old = clone_value(spec.getter())
		if old == value:
			return
		if self._undo_stack is None:
			spec.setter(value)
			return
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		self._undo_stack.push(
			PropertyChangeCommand(
				self._scene,
				entity.id,
				comp_type,
				spec.name,
				old,
				clone_value(value),
				text=f"{comp_type}.{spec.name}",
			)
		)

	# -------------------------------------------------------------- resolution

	def _resolve_entity(self, key: str) -> Tuple[Optional["Entity"], str]:
		matches = [e for e in self._scene.entities() if e.name == key]
		if len(matches) == 1:
			return matches[0], ""
		if len(matches) > 1:
			return None, f"multiple entities named {key}"
		by_id = self._scene.find_by_id(key)
		if by_id is not None:
			return by_id, ""
		return None, f"entity not found: {key}"

	@staticmethod
	def _resolve_component(
		entity: "Entity", type_name: str
	) -> Tuple[Optional["Component"], str]:
		wanted = _normalize_label(type_name)
		for comp in entity.components:
			if _normalize_label(getattr(comp, "type_name", comp.__class__.__name__)) == wanted:
				return comp, ""
		return None, f"component not found: {type_name} on {entity.name}"

	@staticmethod
	def _resolve_button(
		component: "Component", function: str
	) -> Tuple[Optional[Callable[[], Any]], str]:
		from MotionStudio.ui.inspector.metadata import collect_inspector_buttons

		buttons = collect_inspector_buttons(component)
		wanted = _normalize_label(function)
		for method_name, (spec, bound) in buttons.items():
			if _normalize_label(method_name) == wanted:
				return bound, ""
		for method_name, (spec, bound) in buttons.items():
			if _normalize_label(spec.label) == wanted:
				return bound, ""
		type_name = getattr(component, "type_name", component.__class__.__name__)
		return None, f"function not found: {function} on {type_name}"

	@staticmethod
	def _resolve_field(
		component: "Component",
		property_name: str,
		*,
		writable: bool = True,
	) -> Tuple[Optional["FieldSpec"], str]:
		from MotionStudio.ui.inspector.metadata import ConnectionStatus, ReadOnly
		from MotionStudio.ui.inspector.reflection import iter_editable_fields

		type_name = getattr(component, "type_name", component.__class__.__name__)
		wanted = _normalize_label(property_name)
		# Hidden fields never appear here, matching what the Inspector shows.
		for spec in iter_editable_fields(component):
			if _normalize_label(spec.name) != wanted:
				continue
			if writable:
				if any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata):
					return None, f"property is read-only: {spec.name} on {type_name}"
				if any(isinstance(m, ConnectionStatus) for m in spec.metadata):
					return None, f"property is read-only: {spec.name} on {type_name}"
				if spec.setter is None:
					return None, f"property is not writable: {spec.name} on {type_name}"
			return spec, ""
		return None, f"property not found: {property_name} on {type_name}"


# --------------------------------------------------------------------- async

def _wait_for_plan(
	scene: "Scene",
	entity: "Entity",
	component: "Component",
	method: Callable[[], Any],
	job: _Job,
) -> None:
	"""Run Plan Motion and keep the job open until the planner reports back."""
	system = getattr(scene, "motion_planning_system", None)
	if system is None:
		job.finish(False, "motion planning system unavailable")
		return

	job_entity_id = entity.id

	def _on_plan_finished(finished_id: str, success: bool, message: str) -> None:
		if finished_id != job_entity_id:
			return
		job.finish(bool(success), message)

	system.add_plan_listener(_on_plan_finished)
	job.cleanup = lambda: system.remove_plan_listener(_on_plan_finished)
	job.pending = True

	try:
		result = method()
	except Exception as exc:
		job.pending = False
		job.finish(False, f"plan_motion raised: {exc}")
		return

	if job.done.is_set():
		job.pending = False
		return

	if result is False or (
		isinstance(result, tuple) and len(result) == 2 and result[0] is False
	):
		job.pending = False
		_ok, output = interpret_button_result(result)
		job.finish(False, output or "planning did not start")
		return

	# ``submit_plan`` rejects invalid setups synchronously (no worker started),
	# in which case the listener will never fire.
	if not system.is_busy(job_entity_id):
		job.pending = False
		job.finish(False, "planning did not start (see Motion Studio for details)")


def _wait_for_hardware_job(expected_kind: str, cancel_attr: str = ""):
	"""Wait until a hardware worker reports the given job kind."""

	def waiter(
		scene: "Scene",
		entity: "Entity",
		component: "Component",
		method: Callable[..., Any],
		job: _Job,
	) -> None:
		def _on_done(kind: str, success: bool, message: str) -> None:
			if kind != expected_kind:
				return
			job.finish(bool(success), None if success else (message or "failed"))

		add = getattr(component, "add_job_listener", None)
		remove = getattr(component, "remove_job_listener", None)
		if not callable(add) or not callable(remove):
			job.finish(False, "hardware job listeners unavailable")
			return

		add(_on_done)
		job.cleanup = lambda: remove(_on_done)
		job.pending = True
		if cancel_attr:
			cancel = getattr(component, cancel_attr, None)
			if callable(cancel):
				job.cancel = cancel

		try:
			result = method()
		except Exception as exc:
			job.pending = False
			job.finish(False, f"{method.__name__} raised: {exc}")
			return

		if job.done.is_set():
			job.pending = False
			return

		# ``True`` means the worker was queued; wait for ``_on_done``.
		if result is True:
			return

		job.pending = False
		ok, output = interpret_button_result(result)
		job.finish(ok, output)

	return waiter


def _wait_for_lift(
	scene: "Scene",
	entity: "Entity",
	component: "Component",
	method: Callable[..., Any],
	job: _Job,
) -> None:
	"""Hold the reply until Lift to safety stops (collision-free or gave up)."""

	def _on_done(success: bool, message: str) -> None:
		job.finish(bool(success), None if success else (message or "lift failed"))

	add = getattr(component, "add_lift_listener", None)
	remove = getattr(component, "remove_lift_listener", None)
	if not callable(add) or not callable(remove):
		job.finish(False, "lift listeners unavailable")
		return

	add(_on_done)
	job.cleanup = lambda: remove(_on_done)
	job.pending = True
	cancel = getattr(component, "cancel_lift", None)
	if callable(cancel):
		job.cancel = cancel

	try:
		result = method()
	except Exception as exc:
		job.pending = False
		job.finish(False, f"lift_to_safety raised: {exc}")
		return

	if job.done.is_set():
		job.pending = False
		return

	if result is True:
		return

	job.pending = False
	ok, output = interpret_button_result(result)
	job.finish(ok, output)


def _wait_for_done_listener(
	add_attr: str,
	remove_attr: str,
	method_label: str,
	missing_msg: str,
	cancel_attr: str = "",
):
	"""Hold the reply until a (success, message) play-routine listener fires."""

	def waiter(
		scene: "Scene",
		entity: "Entity",
		component: "Component",
		method: Callable[..., Any],
		job: _Job,
	) -> None:
		def _on_done(success: bool, message: str) -> None:
			job.finish(bool(success), None if success else (message or "failed"))

		add = getattr(component, add_attr, None)
		remove = getattr(component, remove_attr, None)
		if not callable(add) or not callable(remove):
			job.finish(False, missing_msg)
			return

		add(_on_done)
		job.cleanup = lambda: remove(_on_done)
		job.pending = True
		if cancel_attr:
			cancel = getattr(component, cancel_attr, None)
			if callable(cancel):
				job.cancel = cancel

		try:
			result = method()
		except Exception as exc:
			job.pending = False
			job.finish(False, f"{method_label} raised: {exc}")
			return

		if job.done.is_set():
			job.pending = False
			return

		if result is True:
			return

		job.pending = False
		ok, output = interpret_button_result(result)
		job.finish(ok, output)

	return waiter


def _wait_for_gp_leak_generate(
	scene: "Scene",
	entity: "Entity",
	component: "Component",
	method: Callable[..., Any],
	job: _Job,
) -> None:
	"""Hold the reply until GP leak-path generation finishes or is cancelled."""

	def _on_done(success: bool, message: str) -> None:
		job.finish(bool(success), None if success else (message or "generate failed"))

	add = getattr(component, "add_generate_listener", None)
	remove = getattr(component, "remove_generate_listener", None)
	if not callable(add) or not callable(remove):
		job.finish(False, "generate listeners unavailable")
		return

	add(_on_done)
	job.cleanup = lambda: remove(_on_done)
	job.pending = True
	cancel = getattr(component, "cancel_generate", None)
	if callable(cancel):
		job.cancel = cancel

	try:
		result = method()
	except Exception as exc:
		job.pending = False
		job.finish(False, f"generate_leak_path raised: {exc}")
		return

	if job.done.is_set():
		job.pending = False
		return

	if result is True:
		return

	job.pending = False
	ok, output = interpret_button_result(result)
	job.finish(ok, output)


_ASYNC_HANDLERS: Dict[Tuple[str, str], Callable[..., None]] = {
	("MotionPlanner", "plan_motion"): _wait_for_plan,
	("MechmindScanner", "connect_scanner"): _wait_for_hardware_job("connect"),
	("MechmindScanner", "disconnect_scanner"): _wait_for_hardware_job("disconnect"),
	("MechmindScanner", "capture_scan"): _wait_for_hardware_job("capture"),
	("UniversalRobot", "connect_robot"): _wait_for_hardware_job("connect"),
	("UniversalRobot", "disconnect_robot"): _wait_for_hardware_job("disconnect"),
	("UniversalRobot", "run_script"): _wait_for_hardware_job(
		"run_script", cancel_attr="stop_robot"
	),
	("UniversalRobot", "move_to_target"): _wait_for_hardware_job(
		"move_to_target", cancel_attr="stop_robot"
	),
	("UniversalRobot", "stop_robot"): _wait_for_hardware_job("stop"),
	("UniversalRobot", "apply_io"): _wait_for_hardware_job("set_io"),
	("LiftToSafety", "lift_to_safety"): _wait_for_lift,
	("GPLeakPathGenerator", "generate_leak_path"): _wait_for_gp_leak_generate,
	("MotionPlanner", "simulate_playback"): _wait_for_done_listener(
		"add_playback_listener",
		"remove_playback_listener",
		"simulate_playback",
		"playback listeners unavailable",
		cancel_attr="stop_simulate_playback",
	),
	("ToolTrace", "simulate_trace"): _wait_for_done_listener(
		"add_trace_listener",
		"remove_trace_listener",
		"simulate_trace",
		"trace listeners unavailable",
		cancel_attr="stop_simulate_trace",
	),
	("ScanMission", "run_scan_mission"): _wait_for_done_listener(
		"add_mission_listener",
		"remove_mission_listener",
		"run_scan_mission",
		"scan mission listeners unavailable",
		cancel_attr="stop_scan_mission",
	),
	("PathMission", "run_path_mission"): _wait_for_done_listener(
		"add_mission_listener",
		"remove_mission_listener",
		"run_path_mission",
		"path mission listeners unavailable",
		cancel_attr="stop_path_mission",
	),
}


def _execute_inspector_button(
	scene: "Scene",
	entity: "Entity",
	method: Callable[..., Any],
	job: _Job,
	*,
	print_traceback: bool = False,
	notify: bool = True,
) -> None:
	"""Run a resolved ``@inspector_button`` method with TCP ``RUN`` completion rules."""
	component = getattr(method, "__self__", None)
	type_name = str(getattr(component, "type_name", "") if component is not None else "")
	waiter = _ASYNC_HANDLERS.get((type_name, method.__name__))
	if waiter is not None:
		waiter(scene, entity, component, method, job)
		return

	try:
		result = method()
	except Exception as exc:
		if print_traceback:
			import traceback

			traceback.print_exc()
		job.finish(False, f"{job.command.member} raised: {exc}")
		return

	if notify:
		try:
			scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass
	ok, output = interpret_button_result(result)
	job.finish(ok, output)


def run_inspector_button(
	scene: "Scene",
	entity: "Entity",
	method: Callable[..., Any],
	*,
	on_finished: Optional[Callable[[bool, str], None]] = None,
	print_traceback: bool = False,
	notify: bool = True,
) -> None:
	"""Invoke an ``@inspector_button`` method the same way TCP ``RUN`` does.

	``on_finished(ok, output)`` fires when the TCP-equivalent reply is ready.
	``ok`` is True only if the button's intent succeeded (connected, planned,
	aligned, …), not merely because the method returned. For Plan Motion /
	hardware Connect / Capture / UR RUN / Move To Target / Apply I/O / STOP / Lift to safety
	that is after the worker reports, not when the method queues the job.
	"""
	from MotionStudio.core.remote.protocol import RUN_OP, RemoteCommand

	component = getattr(method, "__self__", None)
	type_name = str(getattr(component, "type_name", "") if component is not None else "")
	job = _Job(
		command=RemoteCommand(
			RUN_OP,
			str(getattr(entity, "name", "") or ""),
			type_name,
			method.__name__,
		),
		on_finished=on_finished,
	)
	_execute_inspector_button(
		scene,
		entity,
		method,
		job,
		print_traceback=print_traceback,
		notify=notify,
	)

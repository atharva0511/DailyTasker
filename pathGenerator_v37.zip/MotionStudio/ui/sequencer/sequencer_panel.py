"""Sequencer dock: ordered RUN / EDIT / GET / WAIT lines against the command dispatcher."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from PyQt6.QtCore import QSize, Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import (
	QComboBox,
	QHBoxLayout,
	QInputDialog,
	QLabel,
	QLineEdit,
	QMessageBox,
	QPushButton,
	QScrollArea,
	QSizePolicy,
	QStyle,
	QTabBar,
	QToolButton,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.core.remote.protocol import STATUS_FAIL, STATUS_PASS
from MotionStudio.core.sequencer.runner import SequencerRunner
from MotionStudio.core.sequencer.store import (
	DEFAULT_SEQUENCE_NAME,
	Sequence,
	SequenceStep,
	create_sequence,
	delete_sequence,
	ensure_default_sequence,
	list_sequence_names,
	load_active_name,
	load_sequence,
	sanitize_sequence_name,
	save_active_name,
	save_sequence,
)
from MotionStudio.ui.theme import mark_bordered_tool_button

if TYPE_CHECKING:
	from MotionStudio.core.logging.command_logger import CommandLogger
	from MotionStudio.core.remote.dispatcher import RemoteCommandDispatcher

_AUTOSAVE_MS = 300
_ICON_PX = 22

_ROW_STYLE_IDLE = ""
_ROW_STYLE_ACTIVE = "background-color: rgba(56, 139, 253, 70);"
_ROW_STYLE_PASS = "background-color: rgba(46, 160, 67, 70);"
_ROW_STYLE_FAIL = "background-color: rgba(248, 81, 73, 70);"

_TAB_MAIN = 0
_TAB_STOP = 1


class _StepRow(QWidget):
	"""One command line plus Continue-on-fail toggle and remove."""

	_TIP_STOP = "Stop the sequence if this step returns FAIL (Click to change)"
	_TIP_CONTINUE = "Continue to the next step even if this step returns FAIL (Click to change)"

	def __init__(self, panel: "SequencerPanel", step: SequenceStep) -> None:
		super().__init__(panel)
		self._panel = panel
		layout = QHBoxLayout(self)
		layout.setContentsMargins(4, 2, 4, 2)
		layout.setSpacing(6)

		self.index_label = QLabel(self)
		self.index_label.setAlignment(
			Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
		)
		self.index_label.setFixedWidth(28)
		self.index_label.setToolTip("Step number")
		layout.addWidget(self.index_label, 0)

		self.command_edit = QLineEdit(self)
		self.command_edit.setPlaceholderText("RUN,… / EDIT,… / GET,… / WAIT,…")
		self.command_edit.setText(str(step.command or ""))
		self.command_edit.setClearButtonEnabled(True)
		self.command_edit.textChanged.connect(panel._on_row_text_changed)
		self.command_edit.editingFinished.connect(panel._on_row_editing_finished)
		layout.addWidget(self.command_edit, 1)

		self.continue_btn = QToolButton(self)
		self.continue_btn.setCheckable(True)
		self.continue_btn.setChecked(bool(step.continue_on_fail))
		self.continue_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
		self.continue_btn.setAutoRaise(False)
		mark_bordered_tool_button(self.continue_btn)
		self.continue_btn.setFixedSize(_ICON_PX, _ICON_PX)
		self.continue_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
		self.continue_btn.toggled.connect(self._on_continue_toggled)
		self._sync_continue_chrome()
		layout.addWidget(self.continue_btn, 0)

		self.remove_btn = QToolButton(self)
		self.remove_btn.setIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_TrashIcon))
		self.remove_btn.setToolTip("Remove this step")
		self.remove_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
		self.remove_btn.setAutoRaise(False)
		mark_bordered_tool_button(self.remove_btn)
		self.remove_btn.setFixedSize(_ICON_PX, _ICON_PX)
		self.remove_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
		self.remove_btn.clicked.connect(lambda: panel._remove_row(self))
		layout.addWidget(self.remove_btn, 0)

	def continue_on_fail(self) -> bool:
		return self.continue_btn.isChecked()

	def set_continue_on_fail(self, value: bool) -> None:
		self.continue_btn.setChecked(bool(value))

	def set_index(self, number: int) -> None:
		self.index_label.setText(str(int(number)))

	def to_step(self) -> SequenceStep:
		return SequenceStep(
			command=self.command_edit.text(),
			continue_on_fail=self.continue_on_fail(),
		)

	def set_row_enabled(self, enabled: bool) -> None:
		self.command_edit.setEnabled(enabled)
		self.continue_btn.setEnabled(enabled)
		self.remove_btn.setEnabled(enabled)

	def set_run_style(self, kind: str) -> None:
		if kind == "active":
			self.setStyleSheet(_ROW_STYLE_ACTIVE)
		elif kind == "pass":
			self.setStyleSheet(_ROW_STYLE_PASS)
		elif kind == "fail":
			self.setStyleSheet(_ROW_STYLE_FAIL)
		else:
			self.setStyleSheet(_ROW_STYLE_IDLE)

	def _on_continue_toggled(self, _checked: bool) -> None:
		self._sync_continue_chrome()
		self._panel._on_row_continue_toggled()

	def _sync_continue_chrome(self) -> None:
		style = self.style()
		if self.continue_btn.isChecked():
			self.continue_btn.setIcon(
				style.standardIcon(QStyle.StandardPixmap.SP_MediaSkipForward)
			)
			self.continue_btn.setToolTip(self._TIP_CONTINUE)
		else:
			self.continue_btn.setIcon(
				style.standardIcon(QStyle.StandardPixmap.SP_MediaStop)
			)
			self.continue_btn.setToolTip(self._TIP_STOP)


class SequencerPanel(QWidget):
	"""Editor and player for project ``sequence/*.seq`` files."""

	runStarted = pyqtSignal()
	runFinished = pyqtSignal(str)
	runPhaseChanged = pyqtSignal(str, str)

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._dispatcher: Optional["RemoteCommandDispatcher"] = None
		self._command_logger: Optional["CommandLogger"] = None
		self._timeout_s: float = 300.0
		self._project_root: Optional[Path] = None
		self._current_name: str = DEFAULT_SEQUENCE_NAME
		self._loading = False
		self._ignore_run = False
		self._sequence = Sequence(name=DEFAULT_SEQUENCE_NAME)
		self._run_phase = ""
		self._rows_tab = _TAB_MAIN
		self._step_rows: List[_StepRow] = []

		self._save_timer = QTimer(self)
		self._save_timer.setSingleShot(True)
		self._save_timer.setInterval(_AUTOSAVE_MS)
		self._save_timer.timeout.connect(self.flush_save)

		self._runner = SequencerRunner(self)
		self._runner.phaseChanged.connect(self._on_phase_changed)
		self._runner.stepStarted.connect(self._on_step_started)
		self._runner.stepFinished.connect(self._on_step_finished)
		self._runner.runFinished.connect(self._on_run_finished)

		root = QVBoxLayout(self)
		root.setContentsMargins(6, 6, 6, 6)
		root.setSpacing(6)

		toolbar = QHBoxLayout()
		toolbar.setSpacing(6)
		self._info_btn = self._make_info_button()
		toolbar.addWidget(self._info_btn, 0)
		self._combo = QComboBox(self)
		self._combo.setMinimumWidth(140)
		self._combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		self._combo.currentTextChanged.connect(self._on_combo_changed)
		toolbar.addWidget(self._combo, 1)

		self._new_btn = QPushButton("New…", self)
		self._new_btn.setToolTip("Create an empty sequence file")
		self._new_btn.clicked.connect(self._on_new)
		toolbar.addWidget(self._new_btn)

		self._delete_btn = QPushButton("Delete", self)
		self._delete_btn.setToolTip("Delete the selected sequence file")
		self._delete_btn.clicked.connect(self._on_delete)
		toolbar.addWidget(self._delete_btn)
		root.addLayout(toolbar)

		self._tabs = QTabBar(self)
		self._tabs.setExpanding(True)
		self._tabs.setDocumentMode(True)
		self._tabs.setDrawBase(False)
		self._tabs.addTab("Main Sequence")
		self._tabs.addTab("Stop Sequence")
		self._tabs.setTabToolTip(
			_TAB_MAIN, "Commands that ribbon Play runs, in order"
		)
		self._tabs.setTabToolTip(
			_TAB_STOP,
			"Commands that ribbon Stop runs after the main sequence is interrupted",
		)
		self._tabs.currentChanged.connect(self._on_tab_changed)
		root.addWidget(self._tabs)

		self._scroll = QScrollArea(self)
		self._scroll.setWidgetResizable(True)
		self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
		self._list_host = QWidget(self._scroll)
		self._list_layout = QVBoxLayout(self._list_host)
		self._list_layout.setContentsMargins(0, 0, 0, 0)
		self._list_layout.setSpacing(0)
		self._list_layout.addStretch(1)
		self._scroll.setWidget(self._list_host)
		root.addWidget(self._scroll, 1)

		self._status = QLabel("Ready", self)
		self._status.setWordWrap(True)
		self._status.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
		root.addWidget(self._status)

		self._rebuild_rows([])

	def _make_info_button(self) -> QToolButton:
		btn = QToolButton(self)
		btn.setIcon(btn.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxInformation))
		btn.setIconSize(QSize(14, 14))
		btn.setAutoRaise(True)
		btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
		btn.setCursor(Qt.CursorShape.WhatsThisCursor)
		btn.setToolTip(self._info_tooltip_html())
		btn.setToolTipDuration(60000)
		return btn

	@staticmethod
	def _info_tooltip_html() -> str:
		inner = (
			"<p><b>Sequencer</b></p>"
			"<p>Runs Inspector command lines in order — the same "
			"<b>RUN</b> / <b>EDIT</b> / <b>GET</b> / <b>WAIT</b> lines as the "
			"TCP server, without opening a socket. Each sequence file has a "
			"<b>Main Sequence</b> and a <b>Stop Sequence</b>. Ribbon <b>Play</b> "
			"runs Main; each line waits for the previous one to finish. "
			"Ribbon <b>Stop</b> skips the rest of Main (cancelling an in-flight "
			"<b>WAIT</b>) and then runs Stop — shutdown or cancel calls for "
			"that program. Stop again aborts the stop sequence.</p>"
			"<p><b>How to use</b></p>"
			"<ul>"
			"<li>Select one entity. Right-click an Inspector <b>field name</b> → "
			"<b>Copy GET command</b> or <b>Copy EDIT command</b> (EDIT is filled "
			"with the live value). Read-only fields offer GET only.</li>"
			"<li>Right-click an Inspector <b>action button</b> → "
			"<b>Copy RUN command</b>. Left-click still runs the action.</li>"
			"<li>Paste the line into a Sequencer row, or type it. Use the "
			"<b>Main Sequence</b> / <b>Stop Sequence</b> tabs to edit each "
			"list. Blank lines are skipped.</li>"
			"<li>Ribbon <b>Play</b> always runs Main, even if the Stop tab is "
			"visible. <b>Stop</b> then runs the Stop Sequence. A second Stop "
			"aborts without further lines. An in-flight <b>WAIT</b> or "
			"Generate leak path / Lift / Simulate is cancelled immediately.</li>"
			"<li>The stop icon on a row halts the sequence on FAIL; the "
			"skip-forward icon continues to the next line.</li>"
			"</ul>"
			"<p><b>Commands</b></p>"
			"<ul>"
			"<li><b>RUN</b>,entity,component,button — press an Inspector action "
			"(Plan Motion, Connect, Simulate, …).</li>"
			"<li><b>EDIT</b>,entity,component,property,value — write an Inspector field.</li>"
			"<li><b>GET</b>,entity,component,property — read an Inspector field.</li>"
			"<li><b>WAIT</b>,seconds — pause (e.g. <code>WAIT,1.5</code>). Stop cancels the wait.</li>"
			"</ul>"
		)
		return (
			'<html><head/><body>'
			'<table border="0" cellspacing="0" cellpadding="2"><tr>'
			f'<td width="340">{inner}</td>'
			"</tr></table></body></html>"
		)

	# ---------------------------------------------------------------- binding

	def bind_dispatcher(self, dispatcher: Optional["RemoteCommandDispatcher"]) -> None:
		self._dispatcher = dispatcher

	def bind_command_logger(self, logger: Optional["CommandLogger"]) -> None:
		self._command_logger = logger

	def set_timeout_s(self, timeout_s: float) -> None:
		self._timeout_s = max(1.0, float(timeout_s))

	def load_from_project(self, project_root: Path) -> None:
		"""Point at ``<project>/sequence/``, ensure ``default.seq``, restore active."""
		still_running = self._runner.is_running
		if still_running:
			self._ignore_run = True
			self._runner.abort()
		new_root = Path(project_root)
		if self._project_root is not None:
			self.flush_save()
		self._project_root = new_root
		seq = ensure_default_sequence(new_root)
		self._refresh_combo(select=seq.name)
		self._load_named(seq.name, persist_active=False)
		self._set_editing_enabled(not still_running)

	def flush_save(self) -> None:
		"""Write the current sequence to disk immediately."""
		self._save_timer.stop()
		if self._project_root is None or self._loading:
			return
		self._capture_visible_steps()
		self._sequence.name = self._current_name
		try:
			save_sequence(self._project_root, self._sequence)
			save_active_name(self._project_root, self._current_name)
		except OSError as exc:
			self._status.setText(f"Could not save sequence: {exc}")

	@property
	def is_running(self) -> bool:
		return self._runner.is_running

	def play(self) -> None:
		"""Run the main sequence (ribbon Play)."""
		if self._runner.is_running:
			return
		if self._dispatcher is None:
			self._status.setText("Sequencer is not connected to the command dispatcher.")
			return
		self.flush_save()
		main_specs = self._specs_from_steps(self._sequence.steps)
		if not main_specs:
			self._status.setText("No commands to run.")
			return
		stop_specs = self._specs_from_steps(self._sequence.stop_steps)
		self._ignore_run = False
		self._run_phase = "main"
		self._show_tab(_TAB_MAIN, capture=False)
		self._clear_run_styles()
		self._set_editing_enabled(False)
		self._status.setText("Running…")
		if not self._runner.start(
			self._dispatcher,
			self._timeout_s,
			main_specs,
			self._command_logger,
			stop_steps=stop_specs,
		):
			self._set_editing_enabled(True)
			self._status.setText("Already running.")
			return
		self.runStarted.emit()
		self.runPhaseChanged.emit(self._current_name, "main")

	def stop(self) -> None:
		"""Interrupt Main, then run the Stop Sequence (ribbon Stop)."""
		if not self._runner.is_running:
			return
		already_stopping = self._runner.is_stop_sequence or self._runner.stop_requested
		self._runner.request_stop()
		if already_stopping:
			self._status.setText("Stopping immediately…")
			return
		if self._has_stop_commands():
			self._status.setText("Stopping — then running the stop sequence…")
		else:
			self._status.setText("Stopping after the current command…")

	def abort(self) -> None:
		"""Skip remaining lines and do not run the stop sequence."""
		if not self._runner.is_running:
			return
		self._runner.abort()
		self._status.setText("Stopping after the current command…")

	# ---------------------------------------------------------------- rows

	def _capture_visible_steps(self) -> None:
		steps = self._collect_visible_steps()
		if self._rows_tab == _TAB_STOP:
			self._sequence.stop_steps = steps
		else:
			self._sequence.steps = steps

	def _collect_visible_steps(self) -> List[SequenceStep]:
		"""Persist every authored row except the trailing empty placeholder."""
		rows = list(self._step_rows)
		if rows and not rows[-1].command_edit.text().strip():
			rows = rows[:-1]
		return [row.to_step() for row in rows]

	@staticmethod
	def _specs_from_steps(steps: List[SequenceStep]) -> List[tuple]:
		out = []
		for index, step in enumerate(steps):
			text = str(step.command or "").strip()
			if not text:
				continue
			out.append((index, text, bool(step.continue_on_fail)))
		return out

	def _has_stop_commands(self) -> bool:
		self._capture_visible_steps()
		return any(str(step.command or "").strip() for step in self._sequence.stop_steps)

	def _steps_for_tab(self, index: int) -> List[SequenceStep]:
		if int(index) == _TAB_STOP:
			return list(self._sequence.stop_steps)
		return list(self._sequence.steps)

	def _show_tab(self, index: int, *, capture: bool) -> None:
		want = _TAB_STOP if int(index) == _TAB_STOP else _TAB_MAIN
		if capture:
			self._capture_visible_steps()
		self._rows_tab = want
		if self._tabs.currentIndex() == want:
			self._rebuild_rows(self._steps_for_tab(want))
			return
		blocked = self._tabs.blockSignals(True)
		try:
			self._tabs.setCurrentIndex(want)
		finally:
			self._tabs.blockSignals(blocked)
		self._rebuild_rows(self._steps_for_tab(want))

	def _on_tab_changed(self, index: int) -> None:
		if self._loading:
			return
		self._capture_visible_steps()
		self._rows_tab = _TAB_STOP if int(index) == _TAB_STOP else _TAB_MAIN
		self._rebuild_rows(self._steps_for_tab(self._rows_tab))
		if self._runner.is_running:
			return
		self.flush_save()

	def _visible_tab_matches_run(self) -> bool:
		if self._run_phase == "stop":
			return self._rows_tab == _TAB_STOP
		return self._rows_tab == _TAB_MAIN

	def _blank_step(self) -> SequenceStep:
		"""New empty row. Stop Sequence defaults Continue-on-fail on."""
		return SequenceStep(continue_on_fail=self._rows_tab == _TAB_STOP)

	def _rebuild_rows(self, steps: List[SequenceStep]) -> None:
		self._loading = True
		try:
			for row in list(self._step_rows):
				self._list_layout.removeWidget(row)
				row.deleteLater()
			self._step_rows.clear()
			for step in steps:
				self._insert_row(step)
			self._insert_row(self._blank_step())
		finally:
			self._loading = False
		if self._runner.is_running:
			for row in self._step_rows:
				row.set_row_enabled(False)

	def _insert_row(self, step: SequenceStep) -> _StepRow:
		row = _StepRow(self, step)
		stretch = self._list_layout.count() - 1
		self._list_layout.insertWidget(max(0, stretch), row)
		self._step_rows.append(row)
		self._renumber_rows()
		return row

	def _renumber_rows(self) -> None:
		for i, row in enumerate(self._step_rows):
			row.set_index(i + 1)

	def _ensure_trailing_empty(self) -> None:
		if self._loading:
			return
		if not self._step_rows or self._step_rows[-1].command_edit.text().strip():
			was = self._loading
			self._loading = True
			try:
				self._insert_row(self._blank_step())
			finally:
				self._loading = was

	def _remove_row(self, row: _StepRow) -> None:
		if self._runner.is_running:
			return
		if row not in self._step_rows:
			return
		# Keep at least the trailing empty row.
		if len(self._step_rows) <= 1:
			row.command_edit.clear()
			row.set_continue_on_fail(self._rows_tab == _TAB_STOP)
			self.flush_save()
			return
		index = self._step_rows.index(row)
		is_trailing_empty = (
			index == len(self._step_rows) - 1 and not row.command_edit.text().strip()
		)
		if is_trailing_empty:
			return
		self._step_rows.pop(index)
		self._list_layout.removeWidget(row)
		row.deleteLater()
		self._ensure_trailing_empty()
		self._renumber_rows()
		self.flush_save()

	def _clear_run_styles(self) -> None:
		for row in self._step_rows:
			row.set_run_style("idle")

	def _set_editing_enabled(self, enabled: bool) -> None:
		self._combo.setEnabled(enabled)
		self._new_btn.setEnabled(enabled)
		self._delete_btn.setEnabled(enabled)
		for row in self._step_rows:
			row.set_row_enabled(enabled)

	# ---------------------------------------------------------------- combo / files

	def _refresh_combo(self, select: Optional[str] = None) -> None:
		self._loading = True
		try:
			self._combo.blockSignals(True)
			self._combo.clear()
			names = [DEFAULT_SEQUENCE_NAME]
			if self._project_root is not None:
				names = list_sequence_names(self._project_root)
			for name in names:
				self._combo.addItem(name)
			target = select or self._current_name
			idx = self._combo.findText(target)
			if idx < 0:
				idx = self._combo.findText(DEFAULT_SEQUENCE_NAME)
			self._combo.setCurrentIndex(max(0, idx))
			self._current_name = self._combo.currentText() or DEFAULT_SEQUENCE_NAME
		finally:
			self._combo.blockSignals(False)
			self._loading = False

	def _load_named(self, name: str, *, persist_active: bool = True) -> None:
		safe = sanitize_sequence_name(name)
		self._current_name = safe
		if self._project_root is None:
			self._sequence = Sequence(name=safe)
		else:
			self._sequence = load_sequence(self._project_root, safe)
		self._show_tab(_TAB_MAIN, capture=False)
		if persist_active and self._project_root is not None:
			try:
				save_active_name(self._project_root, safe)
			except OSError:
				pass
		self._status.setText(f"Loaded {safe}")

	def _on_combo_changed(self, name: str) -> None:
		if self._loading or self._runner.is_running:
			return
		text = str(name or "").strip()
		if not text or text == self._current_name:
			return
		self.flush_save()
		self._load_named(text)

	def _on_new(self) -> None:
		if self._runner.is_running or self._project_root is None:
			return
		name, ok = QInputDialog.getText(self, "New Sequence", "Sequence name:")
		if not ok:
			return
		safe = sanitize_sequence_name(name)
		if not str(name or "").strip():
			QMessageBox.warning(self, "New Sequence", "Name cannot be empty.")
			return
		self.flush_save()
		seq, error = create_sequence(self._project_root, safe)
		if seq is None:
			QMessageBox.warning(self, "New Sequence", error or "Could not create sequence.")
			return
		self._refresh_combo(select=seq.name)
		self._load_named(seq.name)

	def _on_delete(self) -> None:
		if self._runner.is_running or self._project_root is None:
			return
		name = self._current_name
		reply = QMessageBox.question(
			self,
			"Delete Sequence",
			f"Delete sequence '{name}'?",
			QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
			QMessageBox.StandardButton.No,
		)
		if reply != QMessageBox.StandardButton.Yes:
			return
		self._save_timer.stop()
		error = delete_sequence(self._project_root, name)
		if error:
			QMessageBox.warning(self, "Delete Sequence", error)
			return
		next_name = DEFAULT_SEQUENCE_NAME
		self._refresh_combo(select=next_name)
		self._load_named(next_name)

	# ---------------------------------------------------------------- play

	def _on_phase_changed(self, phase: str) -> None:
		self._run_phase = str(phase or "")
		if not self._ignore_run:
			self.runPhaseChanged.emit(self._current_name, self._run_phase)
		if self._ignore_run:
			return
		if self._run_phase != "stop":
			return
		self._show_tab(_TAB_STOP, capture=True)
		self._clear_run_styles()
		self._set_editing_enabled(False)
		self._status.setText("Running stop sequence…")

	def _step_status_prefix(self) -> str:
		return "Stop step" if self._run_phase == "stop" else "Step"

	def _on_step_started(self, index: int) -> None:
		if self._ignore_run:
			return
		if self._visible_tab_matches_run() and 0 <= index < len(self._step_rows):
			self._step_rows[index].set_run_style("active")
		self._status.setText(f"{self._step_status_prefix()} {index + 1} running…")

	def _on_step_finished(self, index: int, ok: bool, output: str) -> None:
		if self._ignore_run:
			return
		if self._visible_tab_matches_run() and 0 <= index < len(self._step_rows):
			self._step_rows[index].set_run_style("pass" if ok else "fail")
		status = STATUS_PASS if ok else STATUS_FAIL
		detail = str(output or "")
		shown = f"{self._step_status_prefix()} {index + 1} {status}"
		if detail:
			shown = f"{shown}: {detail}"
		self._status.setText(shown)

	def _on_run_finished(self, reason: str) -> None:
		ignored = self._ignore_run
		self._ignore_run = False
		self._run_phase = ""
		self._set_editing_enabled(True)
		self._ensure_trailing_empty()
		self.runPhaseChanged.emit("", "")
		self.runFinished.emit(str(reason or ""))
		if ignored:
			return
		label = {
			"completed": "Sequence finished.",
			"stopped": "Sequence stopped.",
			"failed": "Sequence stopped on FAIL.",
			"aborted": "Sequence stopped.",
			"stop_completed": "Stop sequence finished.",
			"stop_failed": "Stop sequence stopped on FAIL.",
			"stop_stopped": "Stop sequence stopped.",
		}.get(str(reason), str(reason))
		current = self._status.text()
		keep_detail = (
			current
			and current != "Running…"
			and current != "Running stop sequence…"
			and not current.startswith("Stopping")
		)
		if keep_detail:
			self._status.setText(f"{current} — {label}")
		else:
			self._status.setText(label)

	# ---------------------------------------------------------------- autosave

	def _schedule_save(self) -> None:
		if self._loading or self._project_root is None or self._runner.is_running:
			return
		self._save_timer.start()

	def _on_row_text_changed(self, _text: str = "") -> None:
		self._ensure_trailing_empty()
		self._schedule_save()

	def _on_row_editing_finished(self) -> None:
		self.flush_save()

	def _on_row_continue_toggled(self, _checked: bool = False) -> None:
		if self._loading or self._runner.is_running:
			return
		self.flush_save()

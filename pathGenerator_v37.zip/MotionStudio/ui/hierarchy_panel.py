from __future__ import annotations

from pathlib import Path
from typing import Any, List, Optional

from PyQt6.QtCore import QAbstractItemModel, QItemSelection, QItemSelectionModel, QMimeData, QModelIndex, Qt
from PyQt6.QtWidgets import QAbstractItemView, QMenu, QTreeView, QVBoxLayout, QWidget, QFileDialog, QMessageBox
from PyQt6.QtGui import QColor, QDragEnterEvent, QDragMoveEvent, QDropEvent, QFont, QPalette, QUndoStack

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.undo.commands import (
	CreateEntityCommand,
	DeleteEntityCommand,
	DuplicateEntityCommand,
	ImportUrdfCommand,
	LoadEntityPresetCommand,
	ReparentEntityCommand,
)

from typing import TYPE_CHECKING

if TYPE_CHECKING:
	from MotionStudio.ui.loading_controller import LoadingController
	from MotionStudio.render.vtk.scene_root import VtkSceneRoot

MIME_ENTITY_ID = "application/x-pyengine-entity-id"

# Match active Qt selection when the tree does not have focus (e.g. pick in 3D view).
_HIERARCHY_SEL_BG = "#2f5f9e"
_HIERARCHY_SEL_FG = "#f0f0f0"
_HIERARCHY_SEL_CURRENT_BG = "#3a7bd5"


def _apply_hierarchy_tree_selection_style(tree: QTreeView) -> None:
	"""Use the same highlight colors for active and inactive selection states."""
	pal = tree.palette()
	highlight = QColor(_HIERARCHY_SEL_BG)
	highlight_text = QColor(_HIERARCHY_SEL_FG)
	for group in (
		QPalette.ColorGroup.Active,
		QPalette.ColorGroup.Inactive,
		QPalette.ColorGroup.Disabled,
	):
		pal.setColor(group, QPalette.ColorRole.Highlight, highlight)
		pal.setColor(group, QPalette.ColorRole.HighlightedText, highlight_text)
	tree.setPalette(pal)
	tree.setStyleSheet(
		f"""
		QTreeView::item:selected {{
			background-color: {_HIERARCHY_SEL_BG};
			color: {_HIERARCHY_SEL_FG};
		}}
		QTreeView::item:selected:!active {{
			background-color: {_HIERARCHY_SEL_BG};
			color: {_HIERARCHY_SEL_FG};
		}}
		QTreeView::item:selected:active:focus {{
			background-color: {_HIERARCHY_SEL_CURRENT_BG};
			color: {_HIERARCHY_SEL_FG};
		}}
		"""
	)


def _pre_paths_from_mime(mime: QMimeData) -> List[str]:
	"""Local file paths ending in .pre from a drag (e.g. Explorer)."""
	if not mime.hasUrls():
		return []
	out: List[str] = []
	for u in mime.urls():
		if u.isLocalFile():
			p = u.toLocalFile()
			if p.lower().endswith(".pre"):
				out.append(p)
	return out


class _HierarchyTreeView(QTreeView):
	"""QTreeView that accepts internal entity moves and external .pre file drops."""

	def __init__(self, on_preset_drop, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._on_preset_drop = on_preset_drop
		self.setAcceptDrops(True)

	def dragEnterEvent(self, event: QDragEnterEvent) -> None:
		if _pre_paths_from_mime(event.mimeData()):
			event.acceptProposedAction()
			return
		super().dragEnterEvent(event)

	def dragMoveEvent(self, event: QDragMoveEvent) -> None:
		if _pre_paths_from_mime(event.mimeData()):
			event.acceptProposedAction()
			return
		super().dragMoveEvent(event)

	def dropEvent(self, event: QDropEvent) -> None:
		paths = _pre_paths_from_mime(event.mimeData())
		if paths:
			event.setDropAction(Qt.DropAction.CopyAction)
			event.accept()
			vp = self.viewport()
			pos = vp.mapFrom(self, event.position().toPoint())
			idx = self.indexAt(pos)
			self._on_preset_drop(paths, idx)
			return
		super().dropEvent(event)


class _EntityTreeModel(QAbstractItemModel):
	def __init__(self, scene: Scene, undo_stack: Optional[QUndoStack] = None) -> None:
		super().__init__()
		self._scene = scene
		self._undo_stack = undo_stack
		scene.events.entity_added.connect(self._on_refresh)
		scene.events.entity_removed.connect(self._on_refresh)
		scene.events.entity_reparented.connect(self._on_refresh)
		scene.events.entity_changed.connect(self._on_entity_changed)

	def _on_refresh(self, *args: Any) -> None:
		self.beginResetModel()
		self.endResetModel()

	def _on_entity_changed(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity:
			idx = self.index_for_entity(entity)
			if idx.isValid():
				# Notify that data (name) might have changed, without resetting the entire model structure.
				# This preserves the tree selection during transform updates.
				self.dataChanged.emit(idx, idx, [Qt.ItemDataRole.DisplayRole])

	def index(self, row: int, column: int, parent: QModelIndex = QModelIndex()) -> QModelIndex:
		if not parent.isValid():
			roots = self._scene.root_entities()
			if 0 <= row < len(roots):
				return self.createIndex(row, column, roots[row])
			return QModelIndex()
		parent_entity: Entity = parent.internalPointer()  # type: ignore[assignment]
		if 0 <= row < len(parent_entity.children):
			return self.createIndex(row, column, parent_entity.children[row])
		return QModelIndex()

	def parent(self, child: QModelIndex) -> QModelIndex:
		if not child.isValid():
			return QModelIndex()
		entity: Entity = child.internalPointer()  # type: ignore[assignment]
		if entity.parent is None:
			return QModelIndex()
		# parent row among its siblings
		if entity.parent.parent is None:
			row = self._scene.root_entities().index(entity.parent)
		else:
			row = entity.parent.parent.children.index(entity.parent)
		return self.createIndex(row, 0, entity.parent)

	def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:
		if not parent.isValid():
			return len(self._scene.root_entities())
		entity: Entity = parent.internalPointer()  # type: ignore[assignment]
		return len(entity.children)

	def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
		return 1

	def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole) -> Any:
		if not index.isValid():
			return None
		entity: Entity = index.internalPointer()  # type: ignore[assignment]
		if role in (Qt.ItemDataRole.DisplayRole, Qt.ItemDataRole.EditRole):
			return entity.name
		return None

	def flags(self, index: QModelIndex) -> Qt.ItemFlag:
		default = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsDragEnabled
		if index.isValid():
			return default | Qt.ItemFlag.ItemIsDropEnabled
		return default | Qt.ItemFlag.ItemIsDropEnabled

	def supportedDragActions(self) -> Qt.DropAction:
		return Qt.DropAction.MoveAction

	def supportedDropActions(self) -> Qt.DropAction:
		return Qt.DropAction.MoveAction

	def mimeTypes(self) -> List[str]:
		return [MIME_ENTITY_ID]

	def mimeData(self, indexes: List[QModelIndex]) -> QMimeData:
		mime = QMimeData()
		if indexes:
			entity: Entity = indexes[0].internalPointer()  # type: ignore[assignment]
			mime.setData(MIME_ENTITY_ID, entity.id.encode("utf-8"))
		return mime

	def dropMimeData(self, data: QMimeData, action: Qt.DropAction, row: int, column: int, parent: QModelIndex) -> bool:
		if action != Qt.DropAction.MoveAction:
			return False
		if not data.hasFormat(MIME_ENTITY_ID):
			return False
		child_id = bytes(data.data(MIME_ENTITY_ID)).decode("utf-8")
		child = self._scene.find_by_id(child_id)
		if child is None:
			return False
		new_parent: Optional[Entity]
		if parent.isValid():
			new_parent = parent.internalPointer()  # type: ignore[assignment]
		else:
			new_parent = None
		if new_parent is child:
			return False
		walk = new_parent
		while walk is not None:
			if walk is child:
				return False
			walk = walk.parent

		old_parent = child.parent
		try:
			old_index = (
				self._scene.root_entities().index(child)
				if old_parent is None
				else old_parent.children.index(child)
			)
		except ValueError:
			return False
		new_index: Optional[int] = int(row) if row >= 0 else None
		if new_parent is old_parent and new_index is None:
			return False
		if new_parent is old_parent and new_index is not None:
			if new_index == old_index or new_index == old_index + 1:
				return False

		new_parent_id = new_parent.id if new_parent is not None else None
		old_parent_id = old_parent.id if old_parent is not None else None
		if self._undo_stack is not None:
			self._undo_stack.push(
				ReparentEntityCommand(
					self._scene,
					child.id,
					new_parent_id,
					old_parent_id=old_parent_id,
					old_index=old_index,
					new_index=new_index,
				)
			)
		else:
			self._scene.reparent(child, new_parent, index=new_index)
		return True

	def index_for_entity(self, entity: Optional[Entity]) -> QModelIndex:
		"""
		Return a QModelIndex for the given Entity (or invalid index if not found).
		"""
		if entity is None:
			return QModelIndex()
		# Root
		if entity.parent is None:
			try:
				row = self._scene.root_entities().index(entity)
			except ValueError:
				return QModelIndex()
			return self.createIndex(row, 0, entity)
		# Child
		parent_idx = self.index_for_entity(entity.parent)
		if not parent_idx.isValid():
			return QModelIndex()
		try:
			row = entity.parent.children.index(entity)
		except ValueError:
			return QModelIndex()
		return self.createIndex(row, 0, entity)


class HierarchyPanel(QWidget):
	def __init__(
		self,
		scene: Scene,
		parent: Optional[QWidget] = None,
		selection: Optional[SelectionModel] = None,
		undo_stack: Optional[QUndoStack] = None,
		*,
		loading: Optional["LoadingController"] = None,
		scene_root: Optional["VtkSceneRoot"] = None,
	) -> None:
		super().__init__(parent)
		self._scene = scene
		self._loading = loading
		self._scene_root = scene_root
		self._tree = _HierarchyTreeView(self._on_preset_files_dropped, self)
		self._tree.installEventFilter(self)
		self._tree.setHeaderHidden(True)
		self._tree.setDragEnabled(True)
		self._tree.setDropIndicatorShown(True)
		self._tree.setDragDropMode(QAbstractItemView.DragDropMode.DragDrop)
		self._tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
		_apply_hierarchy_tree_selection_style(self._tree)
		self._model = _EntityTreeModel(scene, undo_stack)
		self._tree.setModel(self._model)
		self._tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
		self._tree.customContextMenuRequested.connect(self._on_context_menu)
		layout = QVBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.addWidget(self._tree)
		self._selection = selection
		self._undo_stack = undo_stack
		self._updating_tree_selection: bool = False
		self._suppress_tree_sync: bool = False
		if self._selection is not None:
			self._tree.selectionModel().selectionChanged.connect(self._on_tree_selection_changed)
			self._selection.selection_changed.connect(self._on_external_selection_changed)

	def _load_preset_at(self, path: str, target: Optional[Entity]) -> bool:
		"""
		Validate and load a .pre under target (None = scene root).
		Returns True if loading succeeded.
		"""
		from MotionStudio.core.serialization.json_io import (
			load_entity_preset,
			read_preset_entities,
		)

		try:
			entities = read_preset_entities(path)
			if not entities:
				QMessageBox.warning(self, "Load Preset", "Invalid or empty preset file.")
				return False
		except Exception as e:
			QMessageBox.warning(self, "Load Preset", f"Could not read preset:\n{e}")
			return False

		parent_id = target.id if target is not None else None
		if self._undo_stack is not None:
			self._undo_stack.push(
				LoadEntityPresetCommand(self._scene, path, parent_id, self._selection)
			)
		else:
			attach = self._scene.find_by_id(parent_id) if parent_id else None
			roots = load_entity_preset(self._scene, path, attach)
			if not roots:
				QMessageBox.warning(self, "Load Preset", "Could not instantiate preset.")
				return False
			if self._selection is not None:
				self._selection.set_current(roots[0])
		return True

	def _on_preset_files_dropped(self, paths: List[str], index: QModelIndex) -> None:
		"""Load one or more .pre files from Explorer; parent is the row under the cursor, or scene root."""
		existing = [p for p in paths if Path(p).is_file() and p.lower().endswith(".pre")]
		if not existing:
			return
		target: Optional[Entity] = index.internalPointer() if index.isValid() else None  # type: ignore[assignment]
		if len(existing) > 1 and self._undo_stack is not None:
			self._undo_stack.beginMacro("Load entity presets")
		try:
			for p in existing:
				self._load_preset_at(p, target)
		finally:
			if len(existing) > 1 and self._undo_stack is not None:
				self._undo_stack.endMacro()

	def _import_model(self, file_path: str, target: Optional[Entity]) -> None:
		from MotionStudio.core.components.transform_component import TransformComponent
		from MotionStudio.core.components.mesh_component import MeshComponent
		from PyQt6.QtGui import QColor
		from MotionStudio.utils.mesh_assets import (
			ingest_mesh_source,
			has_source_material_sidecar,
			is_step_mesh,
		)

		def _create_entity_with_mesh(stored_path: str) -> None:
			entity_name = Path(stored_path).stem
			parent_id = target.id if target is not None else None
			source_material = False
			try:
				if self._scene.project_root is not None:
					source_material = has_source_material_sidecar(self._scene.project_root, stored_path)
			except Exception:
				source_material = False
			mesh_comp = MeshComponent(
				shape="custom",
				custom_path=stored_path,
				source_material=source_material,
				color=QColor(200, 200, 200),
			)
			initial_components = [
				{"type": "Transform", "data": TransformComponent().to_dict()},
				{"type": "Mesh", "data": mesh_comp.to_dict()},
			]
			if self._undo_stack is not None:
				self._undo_stack.push(
					CreateEntityCommand(
						self._scene,
						name=entity_name,
						parent_id=parent_id,
						initial_components=initial_components,
						selection=self._selection,
					)
				)
			else:
				ent = self._scene.create_entity(entity_name, target)
				ent.add_component(TransformComponent())
				ent.add_component(mesh_comp)
				self._scene.events.entity_changed.emit(ent.id)

		if self._scene.project_root is None and not is_step_mesh(file_path):
			_create_entity_with_mesh(file_path)
			return

		project_root = self._scene.project_root
		message = "Converting STEP to STL..." if is_step_mesh(file_path) else "Importing model..."

		if self._loading is None:
			try:
				stored_path = ingest_mesh_source(project_root, file_path)
			except (FileNotFoundError, OSError) as e:
				QMessageBox.warning(self, "Import Model", str(e))
				return
			_create_entity_with_mesh(stored_path)
			return

		def _background():
			return ingest_mesh_source(project_root, file_path)

		def _apply(stored_path: str) -> None:
			_create_entity_with_mesh(stored_path)

		def _on_error(exc: Exception) -> None:
			QMessageBox.warning(self, "Import Model", str(exc))

		if not self._loading.run(message, _background, _apply, on_error=_on_error):
			QMessageBox.warning(self, "Import Model", "Another load operation is already in progress.")

	def _import_point_cloud(self, file_path: str, target: Optional[Entity]) -> None:
		from MotionStudio.core.components.transform_component import TransformComponent
		from MotionStudio.core.components.point_cloud_component import PointCloudComponent
		from PyQt6.QtGui import QColor
		from MotionStudio.utils.mesh_assets import import_mesh_into_project

		def _create_entity_with_cloud(stored_path: str) -> None:
			entity_name = Path(stored_path).stem
			parent_id = target.id if target is not None else None
			cloud_comp = PointCloudComponent(
				file_path=stored_path,
				color=QColor(200, 200, 200),
			)
			initial_components = [
				{"type": "Transform", "data": TransformComponent().to_dict()},
				{"type": "PointCloud", "data": cloud_comp.to_dict()},
			]
			if self._undo_stack is not None:
				self._undo_stack.push(
					CreateEntityCommand(
						self._scene,
						name=entity_name,
						parent_id=parent_id,
						initial_components=initial_components,
						selection=self._selection,
					)
				)
			else:
				ent = self._scene.create_entity(entity_name, target)
				ent.add_component(TransformComponent())
				ent.add_component(cloud_comp)
				self._scene.events.entity_changed.emit(ent.id)

		if self._scene.project_root is None:
			_create_entity_with_cloud(file_path)
			return

		if self._loading is None:
			try:
				stored_path = import_mesh_into_project(self._scene.project_root, file_path)
			except (FileNotFoundError, OSError) as e:
				QMessageBox.warning(self, "Import Point Cloud", str(e))
				return
			_create_entity_with_cloud(stored_path)
			return

		project_root = self._scene.project_root

		def _background():
			return import_mesh_into_project(project_root, file_path)

		def _apply(stored_path: str) -> None:
			_create_entity_with_cloud(stored_path)

		def _on_error(exc: Exception) -> None:
			QMessageBox.warning(self, "Import Point Cloud", str(exc))

		if not self._loading.run(
			"Importing point cloud...", _background, _apply, on_error=_on_error
		):
			QMessageBox.warning(
				self,
				"Import Point Cloud",
				"Another load operation is already in progress.",
			)

	def _end_bulk_load_if_needed(self, *, on_complete=None) -> None:
		if self._scene_root is not None:
			try:
				self._scene_root.end_bulk_load(
					on_progress=(
						self._loading.set_message
						if self._loading is not None
						else None
					),
					on_complete=on_complete,
				)
			except Exception:
				if on_complete is not None:
					on_complete()
		elif on_complete is not None:
			on_complete()

	def _import_urdf(self, target: Optional[Entity]) -> None:
		"""Import a URDF robot, optionally parented under the context-menu target."""
		if self._scene.project_root is None:
			QMessageBox.warning(
				self,
				"Import URDF",
				"Open or create a project before importing a URDF file.",
			)
			return
		path, _ = QFileDialog.getOpenFileName(
			self,
			"Import URDF",
			"",
			"URDF Files (*.urdf);;All Files (*.*)",
		)
		if not path:
			return
		if self._loading is None:
			self._import_urdf_sync(path, target)
			return

		project_root = self._scene.project_root
		attach_under_id = target.id if target is not None else None

		def _background():
			from MotionStudio.core.robot.urdf_importer import prepare_urdf_import

			return prepare_urdf_import(project_root, path)

		def _apply(prepared) -> None:
			if self._scene_root is not None:
				try:
					self._scene_root.begin_bulk_load()
				except Exception:
					pass
			try:
				if self._undo_stack is not None:
					self._undo_stack.push(
						ImportUrdfCommand(
							self._scene,
							path,
							attach_under_id=attach_under_id,
							selection=self._selection,
							prepared=prepared,
						)
					)
				else:
					from MotionStudio.core.robot.urdf_importer import apply_urdf_import

					root = apply_urdf_import(self._scene, prepared, attach_under=target)
					if self._selection is not None:
						self._selection.set_current(root)
			finally:
				self._end_bulk_load_if_needed(on_complete=self._loading.hide)

		def _on_error(exc: Exception) -> None:
			self._loading.hide()
			QMessageBox.critical(self, "Import URDF", f"Failed to import URDF:\n{exc}")

		if not self._loading.run(
			"Importing URDF...",
			_background,
			_apply,
			on_error=_on_error,
			hide_when_apply_returns=False,
		):
			QMessageBox.warning(self, "Import URDF", "Another load operation is already in progress.")

	def _import_urdf_sync(self, path: str, target: Optional[Entity]) -> None:
		attach_under_id = target.id if target is not None else None
		try:
			if self._undo_stack is not None:
				self._undo_stack.push(
					ImportUrdfCommand(
						self._scene,
						path,
						attach_under_id=attach_under_id,
						selection=self._selection,
					)
				)
			else:
				from MotionStudio.core.robot.urdf_importer import import_urdf_into_scene

				root = import_urdf_into_scene(self._scene, path, attach_under=target)
				if self._selection is not None:
					self._selection.set_current(root)
		except Exception as e:
			QMessageBox.critical(self, "Import URDF", f"Failed to import URDF:\n{e}")

	def _on_context_menu(self, pos) -> None:
		index = self._tree.indexAt(pos)
		target: Optional[Entity] = index.internalPointer() if index.isValid() else None  # type: ignore[assignment]
		menu = QMenu(self)
		create_empty = menu.addAction("Create Empty")
		import_model = menu.addAction("Import Model")
		import_point_cloud = menu.addAction("Import Point Cloud")
		import_urdf = menu.addAction("Import URDF...")
		menu.addSeparator()
		delete_act = menu.addAction("Delete")
		duplicate_act = menu.addAction("Duplicate")
		menu.addSeparator()
		save_preset_act = menu.addAction("Save Preset...")
		save_preset_act.setEnabled(target is not None)
		load_preset_act = menu.addAction("Load Preset...")
		action = menu.exec(self._tree.viewport().mapToGlobal(pos))
		if action == create_empty:
			# Create via undo command
			from MotionStudio.core.components.transform_component import TransformComponent

			parent_id = target.id if target is not None else None
			initial_components = [{"type": "Transform", "data": TransformComponent().to_dict()}]
			if self._undo_stack is not None:
				self._undo_stack.push(
					CreateEntityCommand(
						self._scene,
						name="Empty",
						parent_id=parent_id,
						initial_components=initial_components,
						selection=self._selection,
					)
				)
			else:
				ent = self._scene.create_entity("Empty", target)
				ent.add_component(TransformComponent())
				self._scene.events.entity_changed.emit(ent.id)
		elif action == import_model:
			from MotionStudio.utils.mesh_assets import MESH_FILE_FILTER

			file_path, _ = QFileDialog.getOpenFileName(
				self,
				"Import Model",
				"",
				MESH_FILE_FILTER,
			)
			if file_path:
				self._import_model(file_path, target)
		elif action == import_point_cloud:
			file_path, _ = QFileDialog.getOpenFileName(
				self,
				"Import Point Cloud",
				"",
				"Point Clouds (*.ply *.pcd);;All Files (*.*)",
			)
			if file_path:
				self._import_point_cloud(file_path, target)
		elif action == import_urdf:
			self._import_urdf(target)
		elif action == delete_act:
			self.delete_selected(target)
		elif action == duplicate_act:
			self.duplicate_selected(target)
		elif action == save_preset_act and target is not None:
			from MotionStudio.core.serialization.json_io import save_entity_preset

			presets_dir = (self._scene.project_root / "presets") if self._scene.project_root is not None else Path.cwd() / "presets"
			presets_dir.mkdir(parents=True, exist_ok=True)
			safe_stem = "".join(ch if ch not in '<>:"/\\|?*' else "_" for ch in target.name).strip() or "preset"
			default_path = str(presets_dir / f"{safe_stem}.pre")
			path, _ = QFileDialog.getSaveFileName(
				self,
				"Save Entity Preset",
				default_path,
				"Entity Preset (*.pre);;All Files (*.*)",
			)
			if path:
				if not path.lower().endswith(".pre"):
					path += ".pre"
				try:
					save_entity_preset(target, path, self._scene.project_root)
				except OSError as e:
					QMessageBox.critical(self, "Save Preset", str(e))
		elif action == load_preset_act:
			presets_dir = (self._scene.project_root / "presets") if self._scene.project_root is not None else Path.cwd() / "presets"
			presets_dir.mkdir(parents=True, exist_ok=True)
			path, _ = QFileDialog.getOpenFileName(
				self,
				"Load Entity Preset",
				str(presets_dir),
				"Entity Preset (*.pre);;All Files (*.*)",
			)
			if path:
				self._load_preset_at(path, target)

	def _entities_from_tree_indexes(self, indexes: List[QModelIndex]) -> List[Entity]:
		seen: set[str] = set()
		out: List[Entity] = []
		for idx in indexes:
			if not idx.isValid() or idx.column() != 0:
				continue
			ent: Entity = idx.internalPointer()  # type: ignore[assignment]
			if ent.id in seen:
				continue
			seen.add(ent.id)
			out.append(ent)
		return out

	def _delete_duplicate_targets(self, context_target: Optional[Entity]) -> List[Entity]:
		"""Context menu targets: multi-selection if any, else row under cursor."""
		if self._selection is not None:
			selected = self._selection.selected_entities()
			if len(selected) > 1:
				return selected
			if len(selected) == 1:
				return selected
		if context_target is not None:
			return [context_target]
		return []

	def delete_selected(self, context_target: Optional[Entity] = None) -> None:
		"""
		Delete the current multi-selection (or ``context_target`` when nothing is
		selected). Safe to call from menu, context menu, and keyboard shortcut;
		no-op when neither is available.
		"""
		targets = self._delete_duplicate_targets(context_target)
		if not targets:
			return
		if self._undo_stack is not None:
			if len(targets) > 1:
				self._undo_stack.beginMacro(f"Delete {len(targets)} entities")
			try:
				for ent in targets:
					self._undo_stack.push(
						DeleteEntityCommand(self._scene, ent, selection=self._selection)
					)
			finally:
				if len(targets) > 1:
					self._undo_stack.endMacro()
		else:
			for ent in targets:
				self._scene.delete_entity(ent)

	def duplicate_selected(self, context_target: Optional[Entity] = None) -> None:
		"""
		Duplicate the current multi-selection (or ``context_target`` when nothing
		is selected). Each duplicate is parented under the source entity's own
		parent. Safe to call from menu, context menu, and keyboard shortcut;
		no-op when neither is available.
		"""
		targets = self._delete_duplicate_targets(context_target)
		if not targets:
			return
		if self._undo_stack is not None:
			if len(targets) > 1:
				self._undo_stack.beginMacro(f"Duplicate {len(targets)} entities")
			try:
				for ent in targets:
					parent_id = ent.parent.id if ent.parent is not None else None
					self._undo_stack.push(
						DuplicateEntityCommand(
							self._scene,
							ent,
							parent_id=parent_id,
							selection=self._selection,
						)
					)
			finally:
				if len(targets) > 1:
					self._undo_stack.endMacro()
		else:
			for ent in targets:
				self._scene.duplicate_entity(ent, ent.parent)

	def _on_tree_selection_changed(self, selected, deselected) -> None:
		if self._selection is None:
			return
		if self._updating_tree_selection:
			return
		sm = self._tree.selectionModel()
		entities = self._entities_from_tree_indexes(sm.selectedRows(0) if sm is not None else [])
		selected_ids = {e.id for e in entities}
		primary: Optional[Entity] = None
		current_idx = self._tree.currentIndex()
		if current_idx.isValid() and current_idx.column() == 0:
			candidate: Entity = current_idx.internalPointer()  # type: ignore[assignment]
			# Ctrl+click deselect leaves currentIndex on the row; do not treat as primary.
			if candidate.id in selected_ids:
				primary = candidate
		# Tree is already correct; do not echo selection_changed back via ClearAndSelect
		# (that can drop items when parent/child rows were both selected).
		self._suppress_tree_sync = True
		try:
			if not entities:
				self._selection.clear()
			else:
				self._selection.set_selection(entities, primary=primary)
		finally:
			self._suppress_tree_sync = False

	def _on_external_selection_changed(self) -> None:
		"""Sync Qt tree selection when selection changes outside the tree (e.g. viewport)."""
		if self._selection is None or self._suppress_tree_sync:
			return
		try:
			self._updating_tree_selection = True
			entities = self._selection.selected_entities()
			if not entities:
				self._tree.clearSelection()
				return
			sm = self._tree.selectionModel()
			if sm is None:
				return
			select_flags = QItemSelectionModel.SelectionFlag.Select | QItemSelectionModel.SelectionFlag.Rows
			sm.clearSelection()
			for ent in entities:
				idx = self._model.index_for_entity(ent)
				if not idx.isValid():
					continue
				self._tree.expand(idx.parent())
				sm.select(idx, select_flags)
			primary = self._selection.current
			if primary is not None:
				pidx = self._model.index_for_entity(primary)
				if pidx.isValid():
					sm.setCurrentIndex(pidx, QItemSelectionModel.SelectionFlag.Current)
					self._tree.scrollTo(pidx)
		finally:
			self._updating_tree_selection = False

	def eventFilter(self, watched, event):
		if watched is self._tree and event.type() == event.Type.MouseButtonPress:
			index = self._tree.indexAt(event.pos())
			if not index.isValid() and self._selection is not None:
				self._tree.clearSelection()
				self._selection.clear()
				return True
		return super().eventFilter(watched, event)


from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QToolBar, QWidget

from MotionStudio.ui.theme import play_ribbon_stylesheet


class PlayModeRibbon(QWidget):
	"""Top Play / Stop strip. Play runs the Sequencer; Pause is unused."""

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._on_play_clicked: Optional[Callable[[], None]] = None
		self._on_stop_clicked: Optional[Callable[[], None]] = None
		self._on_pause_clicked: Optional[Callable[[], None]] = None
		self._on_resume_clicked: Optional[Callable[[], None]] = None
		self._ribbon_mode = "default"
		self._is_playing = False
		self._is_paused = False
		self._routine_running = False

		layout = QHBoxLayout(self)
		layout.setContentsMargins(8, 6, 8, 6)
		layout.setSpacing(8)

		self._status_label = QLabel("Idle", self)
		self._status_label.setObjectName("play_sequence_status")
		self._status_label.setAlignment(
			Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
		)
		self._status_label.setSizePolicy(
			QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
		)
		self._status_label.setMinimumWidth(160)
		self._status_label.setToolTip("Sequencer run status")
		layout.addWidget(self._status_label, 1)

		self._play_button = QPushButton("▶ Play", self)
		self._play_button.setObjectName("play_button")
		self._play_button.setToolTip("Run the current Sequencer Main Sequence")
		self._play_button.clicked.connect(self._on_play_button_clicked)
		layout.addWidget(self._play_button)

		self._pause_button = QPushButton("⏸ Pause", self)
		self._pause_button.setObjectName("pause_button")
		self._pause_button.setEnabled(False)
		self._pause_button.setToolTip(
			"Pause is not used for sequences. Stop runs the Stop Sequence after interrupting Main."
		)
		self._pause_button.clicked.connect(self._on_pause_button_clicked)
		layout.addWidget(self._pause_button)

		self._stop_button = QPushButton("⏹ Stop", self)
		self._stop_button.setObjectName("stop_button")
		self._stop_button.setEnabled(False)
		self._stop_button.setToolTip(
			"Interrupt the Main Sequence, then run this file's Stop Sequence. Stop again aborts."
		)
		self._stop_button.clicked.connect(self._on_stop_button_clicked)
		layout.addWidget(self._stop_button)

		layout.addStretch(1)

		self.apply_theme_stylesheet()

	def set_play_callbacks(
		self,
		on_play: Callable[[], None],
		on_stop: Callable[[], None],
		on_pause: Optional[Callable[[], None]] = None,
		on_resume: Optional[Callable[[], None]] = None,
	) -> None:
		"""Set callbacks for Play, Stop, Pause, and Resume button clicks."""
		self._on_play_clicked = on_play
		self._on_stop_clicked = on_stop
		self._on_pause_clicked = on_pause
		self._on_resume_clicked = on_resume

	def apply_theme_stylesheet(self) -> None:
		"""Re-apply ribbon QSS for the current UI theme and play state."""
		stylesheet = play_ribbon_stylesheet(self._ribbon_mode)
		self.setStyleSheet(stylesheet)
		parent = self.parent()
		if isinstance(parent, QToolBar):
			parent.setStyleSheet(stylesheet)
		self.update()
		if isinstance(parent, QToolBar):
			parent.update()

	def set_play_mode(self, is_playing: bool, is_paused: bool = False) -> None:
		"""Green chrome while the Sequencer is running. Pause is ignored."""
		self._is_playing = bool(is_playing)
		self._is_paused = bool(is_paused)
		self._apply_ribbon_state()

	def set_routine_running(self, running: bool) -> None:
		"""Blue ribbon while an edit-mode play routine runs and no sequence is playing."""
		self._routine_running = bool(running)
		self._apply_ribbon_state()

	def set_sequence_run(self, name: str, phase: str = "") -> None:
		"""Update the left status: Idle, running, or stopping a named sequence."""
		kind = str(phase or "").strip().lower()
		seq = str(name or "").strip()
		if kind == "stop" and seq:
			text = f"Stopping {seq} sequence"
		elif kind in ("main", "running") and seq:
			text = f"Running {seq} sequence"
		elif kind and seq:
			text = f"Running {seq} sequence"
		else:
			text = "Idle"
		self._status_label.setText(text)
		self._status_label.setToolTip(text)

	def _apply_ribbon_state(self) -> None:
		self._pause_button.setEnabled(False)
		self._pause_button.setText("⏸ Pause")

		# Sequencer owns the ribbon: Stop stays enabled even if a play routine
		# (Simulate / Lift / Generate) is the in-flight sequence step.
		if self._is_playing:
			self._play_button.setEnabled(False)
			self._stop_button.setEnabled(True)
			self._ribbon_mode = "active"
			self.apply_theme_stylesheet()
			return

		if self._routine_running:
			self._play_button.setEnabled(False)
			self._stop_button.setEnabled(False)
			self._ribbon_mode = "routine"
			self.apply_theme_stylesheet()
			return

		self._play_button.setEnabled(True)
		self._stop_button.setEnabled(False)
		self._ribbon_mode = "default"
		self.apply_theme_stylesheet()

	def _on_play_button_clicked(self) -> None:
		if self._on_play_clicked:
			self._on_play_clicked()

	def _on_stop_button_clicked(self) -> None:
		if self._on_stop_clicked:
			self._on_stop_clicked()

	def _on_pause_button_clicked(self) -> None:
		if self._pause_button.text() == "⏸ Pause":
			if self._on_pause_clicked:
				self._on_pause_clicked()
		else:
			if self._on_resume_clicked:
				self._on_resume_clicked()

"""Editor-side Mech-Eye API: camera calls run in the ``mecheye`` SDK helper process.

``MechEyeRemoteSession`` replaces the in-process ``Camera`` handle. One helper
process per connection: started by ``open_camera_session`` and stopped by
``disconnect_camera``. If it dies (native crash in the SDK) or stops
answering, calls raise ``MechmindSdkError`` starting with "Connection lost".
The world-scan merge stays in-process (numpy only).
"""

from __future__ import annotations

import importlib.util
from typing import Any, Optional

from MotionStudio.core.hardwares.mechmind_scanner_sdk import (
	MechmindSdkError,
	merge_camera_ply_into_world_scan,
	sdk_missing_message,
)
from MotionStudio.core.hardwares.sdk_host import SdkHostClient, SdkHostError, SdkRemoteError

__all__ = [
	"MechEyeRemoteSession",
	"MechmindSdkError",
	"capture_to_ply",
	"connect_camera_session",
	"disconnect_camera",
	"kill_camera_session",
	"merge_camera_ply_into_world_scan",
	"open_camera_session",
	"sdk_available",
	"sdk_missing_message",
]

_SERVICE = "MotionStudio.core.hardwares.mechmind_scanner_sdk:MechEyeService"
# Margins on top of the SDK's own timeout_ms; they only matter when the helper
# is wedged in native code.
_CONNECT_MARGIN_S = 15.0
_CAPTURE_MARGIN_S = 30.0  # SDK saves the PLY after the capture returns
_DISCONNECT_TIMEOUT_S = 15.0


class MechEyeRemoteSession:
	"""Handle to one camera session living in a helper process."""

	__slots__ = ("client",)

	def __init__(self, client: SdkHostClient) -> None:
		self.client = client


def sdk_available() -> bool:
	"""MechEyeAPI is installed (checked without importing it into the editor)."""
	try:
		return importlib.util.find_spec("mecheye") is not None
	except (ImportError, ValueError):
		return False


def _timeout_s(timeout_ms: Any, default_s: float = 60.0) -> float:
	try:
		return max(1, int(timeout_ms)) / 1000.0
	except Exception:
		return default_s


def _call(session: Optional[MechEyeRemoteSession], method: str, *args: Any, timeout_s: float, **kwargs: Any) -> Any:
	if session is None:
		raise MechmindSdkError("Camera is not connected.")
	try:
		return session.client.call(method, *args, timeout_s=timeout_s, **kwargs)
	except SdkRemoteError as exc:
		raise MechmindSdkError(str(exc)) from exc
	except SdkHostError as exc:
		text = str(exc)
		if not text.lower().startswith("connection lost"):
			text = f"Connection lost: {text}"
		raise MechmindSdkError(text) from exc


def open_camera_session() -> MechEyeRemoteSession:
	"""Start the helper process (no camera I/O yet)."""
	client = SdkHostClient("mecheye", _SERVICE)
	try:
		client.start()
	except SdkHostError as exc:
		raise MechmindSdkError(str(exc)) from exc
	return MechEyeRemoteSession(client)


def connect_camera_session(session: MechEyeRemoteSession, ip_address: str, timeout_ms: int) -> None:
	"""Connect the camera inside the helper. Stops the helper if that fails."""
	try:
		_call(
			session,
			"connect",
			str(ip_address or ""),
			timeout_ms,
			timeout_s=_timeout_s(timeout_ms, 10.0) + _CONNECT_MARGIN_S,
		)
	except BaseException:
		session.client.close()
		raise


def disconnect_camera(session: Optional[MechEyeRemoteSession]) -> None:
	"""Disconnect the camera and stop its helper (helper stops even if disconnect fails)."""
	if session is None:
		return
	try:
		_call(session, "disconnect", timeout_s=_DISCONNECT_TIMEOUT_S)
	finally:
		session.client.close()


def kill_camera_session(session: Optional[MechEyeRemoteSession]) -> None:
	"""Terminate the helper now (any thread); a worker blocked on it fails fast."""
	if session is not None:
		session.client.kill()


def capture_to_ply(
	session: Optional[MechEyeRemoteSession],
	abs_ply_path: str,
	capture_color: bool,
	timeout_ms: int = 60000,
) -> None:
	"""Capture one frame in the helper; it writes ``abs_ply_path`` as PLY."""
	_call(
		session,
		"capture_to_ply",
		str(abs_ply_path or ""),
		bool(capture_color),
		timeout_ms,
		timeout_s=_timeout_s(timeout_ms) + _CAPTURE_MARGIN_S,
	)

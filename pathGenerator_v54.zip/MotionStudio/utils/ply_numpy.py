"""PLY vertex I/O with numpy only (no VTK).

Used for the Mech-Eye capture merge on the scanner worker thread: VTK must not
run there while the viewport renders on the GUI thread. Handles ``ascii``,
``binary_little_endian`` and ``binary_big_endian`` files whose vertex element
has scalar properties (Mech-Eye, vtkPLYWriter and our own writer all qualify).
Elements before ``vertex`` may not contain list properties; faces after it are
ignored.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

_PLY_TYPES = {
	"char": "i1",
	"int8": "i1",
	"uchar": "u1",
	"uint8": "u1",
	"short": "i2",
	"int16": "i2",
	"ushort": "u2",
	"uint16": "u2",
	"int": "i4",
	"int32": "i4",
	"uint": "u4",
	"uint32": "u4",
	"float": "f4",
	"float32": "f4",
	"double": "f8",
	"float64": "f8",
}
_COLOR_NAME_SETS = (
	("red", "green", "blue"),
	("r", "g", "b"),
	("diffuse_red", "diffuse_green", "diffuse_blue"),
)
_MAX_HEADER_LINES = 4096


class PlyFormatError(ValueError):
	"""The file is not a PLY this reader supports (caller may fall back)."""


class _Element:
	__slots__ = ("name", "count", "props", "has_list")

	def __init__(self, name: str, count: int) -> None:
		self.name = name
		self.count = count
		self.props: List[Tuple[str, str]] = []
		self.has_list = False


def read_ply_vertices(path: str | Path) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	"""Return ``(points (N,3) float64, colors (N,3) float64 in [0,1] or None)``."""
	p = Path(path)
	with p.open("rb") as f:
		fmt, elements = _read_header(f)
		vertex_idx = next((i for i, e in enumerate(elements) if e.name == "vertex"), -1)
		if vertex_idx < 0:
			raise PlyFormatError(f"PLY has no vertex element: {p}")
		vertex = elements[vertex_idx]
		if vertex.has_list:
			raise PlyFormatError(f"PLY vertex element has list properties: {p}")
		names = [name for name, _ in vertex.props]
		if not {"x", "y", "z"}.issubset(names):
			raise PlyFormatError(f"PLY vertex element has no x/y/z: {p}")
		for elem in elements[:vertex_idx]:
			if elem.has_list:
				raise PlyFormatError(f"PLY element '{elem.name}' before vertex has list properties: {p}")
		if fmt == "ascii":
			data = _read_ascii_vertices(f, elements[:vertex_idx], vertex, p)
		else:
			endian = "<" if fmt == "binary_little_endian" else ">"
			for elem in elements[:vertex_idx]:
				f.seek(elem.count * _element_dtype(elem, endian).itemsize, os.SEEK_CUR)
			dtype = _element_dtype(vertex, endian)
			data = np.fromfile(f, dtype=dtype, count=vertex.count)
			if data.shape[0] != vertex.count:
				raise PlyFormatError(f"PLY vertex data truncated ({data.shape[0]}/{vertex.count}): {p}")
	points = np.column_stack(
		[np.asarray(data["x"], dtype=np.float64), np.asarray(data["y"], dtype=np.float64), np.asarray(data["z"], dtype=np.float64)]
	)
	return np.ascontiguousarray(points), _colors_from(data, names)


def write_ply_vertices(path: str | Path, points: np.ndarray, colors: Optional[np.ndarray] = None) -> None:
	"""Write binary little-endian PLY: float x/y/z plus optional uchar red/green/blue.

	Written to a sibling temp file and swapped in, so readers never see a
	half-written cloud.
	"""
	pts = np.asarray(points, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3 or pts.shape[0] == 0:
		raise ValueError("Cannot save an empty point cloud.")
	n = int(pts.shape[0])
	rgb = None
	if colors is not None:
		c = np.asarray(colors, dtype=np.float64)
		if c.ndim == 2 and c.shape[0] == n and c.shape[1] >= 3:
			rgb = (np.clip(c[:, :3], 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
	fields = [("x", "<f4"), ("y", "<f4"), ("z", "<f4")]
	if rgb is not None:
		fields += [("red", "u1"), ("green", "u1"), ("blue", "u1")]
	data = np.empty(n, dtype=np.dtype(fields))
	data["x"], data["y"], data["z"] = pts[:, 0], pts[:, 1], pts[:, 2]
	if rgb is not None:
		data["red"], data["green"], data["blue"] = rgb[:, 0], rgb[:, 1], rgb[:, 2]
	header = ["ply", "format binary_little_endian 1.0", "comment iMOVE", f"element vertex {n}"]
	header += ["property float x", "property float y", "property float z"]
	if rgb is not None:
		header += ["property uchar red", "property uchar green", "property uchar blue"]
	header.append("end_header")
	dest = Path(path)
	dest.parent.mkdir(parents=True, exist_ok=True)
	tmp = dest.with_name(dest.name + ".tmp")
	with tmp.open("wb") as f:
		f.write(("\n".join(header) + "\n").encode("ascii"))
		data.tofile(f)
	try:
		os.replace(tmp, dest)
	except PermissionError:
		# Destination briefly locked by a reader: overwrite in place instead.
		with dest.open("wb") as out, tmp.open("rb") as src:
			out.write(src.read())
		tmp.unlink(missing_ok=True)


# ---------------------------------------------------------------------- internals


def _read_header(f) -> Tuple[str, List[_Element]]:
	if f.readline().strip() != b"ply":
		raise PlyFormatError("Not a PLY file (missing 'ply' magic).")
	fmt = ""
	elements: List[_Element] = []
	for _ in range(_MAX_HEADER_LINES):
		raw = f.readline()
		if not raw:
			raise PlyFormatError("Unexpected end of PLY header.")
		parts = raw.decode("ascii", errors="replace").split()
		if not parts or parts[0] in ("comment", "obj_info"):
			continue
		key = parts[0]
		if key == "end_header":
			if not fmt:
				raise PlyFormatError("PLY header has no format line.")
			return fmt, elements
		if key == "format" and len(parts) >= 2:
			fmt = parts[1]
			if fmt not in ("ascii", "binary_little_endian", "binary_big_endian"):
				raise PlyFormatError(f"Unsupported PLY format '{fmt}'.")
		elif key == "element" and len(parts) >= 3:
			elements.append(_Element(parts[1], int(parts[2])))
		elif key == "property" and elements:
			elem = elements[-1]
			if len(parts) >= 5 and parts[1] == "list":
				elem.has_list = True
				elem.props.append((parts[4], "list"))
			elif len(parts) >= 3:
				code = _PLY_TYPES.get(parts[1])
				if code is None:
					raise PlyFormatError(f"Unsupported PLY property type '{parts[1]}'.")
				elem.props.append((parts[2], code))
	raise PlyFormatError("PLY header too long.")


def _element_dtype(elem: _Element, endian: str) -> np.dtype:
	return np.dtype([(name, endian + code) for name, code in elem.props])


def _read_ascii_vertices(f, before: List[_Element], vertex: _Element, p: Path) -> np.ndarray:
	for elem in before:
		for _ in range(elem.count):
			f.readline()
	dtype = _element_dtype(vertex, "<")
	rows = np.loadtxt(f, dtype=np.float64, max_rows=vertex.count, ndmin=2)
	if rows.shape[0] != vertex.count or rows.shape[1] < len(vertex.props):
		raise PlyFormatError(f"PLY ASCII vertex data truncated: {p}")
	data = np.empty(vertex.count, dtype=dtype)
	for i, (name, _code) in enumerate(vertex.props):
		data[name] = rows[:, i]
	return data


def _colors_from(data: np.ndarray, names: List[str]) -> Optional[np.ndarray]:
	for r, g, b in _COLOR_NAME_SETS:
		if r in names and g in names and b in names:
			rgb = np.column_stack(
				[np.asarray(data[r], dtype=np.float64), np.asarray(data[g], dtype=np.float64), np.asarray(data[b], dtype=np.float64)]
			)
			if rgb.size and (data.dtype[r].kind in "iu" or np.nanmax(rgb) > 1.5):
				rgb = rgb / 255.0
			return np.clip(np.ascontiguousarray(rgb), 0.0, 1.0)
	return None

#!/usr/bin/env python3
"""
Main entry point for the PyEngine application.
This file works both in development and when packaged with PyInstaller.
"""
import sys
import os
from pathlib import Path

# Must be set before MotionStudio.app imports qdarktheme.
os.environ.setdefault("QT_API", "pyqt6")

# Determine if we're running as a packaged executable (PyInstaller)
# PyInstaller sets sys.frozen to True and sys._MEIPASS to the temp extraction directory
is_frozen = getattr(sys, 'frozen', False)
if not is_frozen and hasattr(sys, '_MEIPASS'):
    # Sometimes _MEIPASS is set even if frozen is False
    is_frozen = True

if is_frozen:
    # Running as a compiled executable
    # PyInstaller sets sys.frozen and sys._MEIPASS
    if hasattr(sys, '_MEIPASS'):
        # Add the temporary extraction directory to path (PyInstaller)
        sys.path.insert(0, sys._MEIPASS)
        # Set up environment for PyQt6 to find DLLs
        os.environ['QT_PLUGIN_PATH'] = os.path.join(sys._MEIPASS, 'PyQt6', 'Qt6', 'plugins')
    # The base path is where the executable is located
    BASE_DIR = Path(sys.executable).parent
else:
    # Running as a script in development
    # Get the directory containing this main.py file
    BASE_DIR = Path(__file__).parent
    # Add project root to Python path if not already there
    if str(BASE_DIR) not in sys.path:
        sys.path.insert(0, str(BASE_DIR))

# NVIDIA's threaded GL dispatch and MSAA buffers were implicated in the IPC
# (RTX A5000) viewport crashes; both must be decided before the GL context exists.
os.environ.setdefault("__GL_THREADED_OPTIMIZATIONS", "0")
os.environ.setdefault("PYVISTA_MULTI_SAMPLES", "0")


def _run_app():
    try:
        from MotionStudio.utils.crash_log import (
            install_crash_logging,
            install_qt_message_handler,
            redirect_std_streams_to_log,
        )

        # Windowed exe has no console: print() goes to imove-console.log instead.
        redirect_std_streams_to_log()
        install_crash_logging()
        install_qt_message_handler()
    except Exception as _crash_log_exc:
        print(f"Crash logging setup failed: {_crash_log_exc!r}", file=sys.stderr)

    from MotionStudio.app import main
    main()


def _report_startup_error(e):
    import traceback
    error_msg = f"Error: {e}\n"
    error_msg += f"Python path: {sys.path}\n"
    error_msg += f"Base directory: {BASE_DIR}\n"
    error_msg += f"Frozen: {getattr(sys, 'frozen', False)}\n"
    if hasattr(sys, '_MEIPASS'):
        error_msg += f"MEIPASS: {sys._MEIPASS}\n"
    error_msg += "\nTraceback:\n"
    error_msg += traceback.format_exc()

    # Always print to stderr (imove-console.log in the windowed exe)
    print(error_msg, file=sys.stderr)

    # Frozen builds have no console, so also show a message box
    if is_frozen:
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            app = QApplication.instance() or QApplication(sys.argv)
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Critical)
            msg.setWindowTitle("Application Error")
            msg.setText(f"An error occurred:\n\n{str(e)}")
            msg.setDetailedText(traceback.format_exc())
            msg.exec()
        except Exception:
            pass  # If we can't show a message box, at least we tried


# SDK helper processes (core/hardwares/sdk_host.py) are multiprocessing "spawn"
# children: the frozen exe re-runs this file and freeze_support() turns it into
# the helper; in dev the child imports this file as __mp_main__. Either way
# nothing below may run in a helper.
if __name__ == "__main__":
    import multiprocessing

    multiprocessing.freeze_support()
    try:
        _run_app()
    except Exception as e:
        _report_startup_error(e)
        sys.exit(1)

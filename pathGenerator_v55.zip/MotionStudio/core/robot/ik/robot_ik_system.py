from __future__ import annotations

import time
from contextlib import contextmanager
from typing import TYPE_CHECKING, Dict, Iterator, List, Optional

import numpy as np
from PyQt6.QtCore import QMutex, QMutexLocker, QThread, QWaitCondition, pyqtSignal

from MotionStudio.core.robot.ik.ik_backend import IKBackend, IKSolveRequest, IKSolveResult
from MotionStudio.utils.thread_guard import stop_and_retire
from MotionStudio.core.robot.ik.backend_runtime import (
	IKBackendError,
	solve_ik_request,
)
from MotionStudio.core.robot.ik.ik_frames import (
	goal_in_base_frame,
	project_to_se3,
	relative_offset_m,
)

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
	from MotionStudio.core.components.robot_ik_component import RobotIKComponent
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


class _IKWorker(QThread):
	"""Background solver loop.

	Holds one pending request per robot (latest-wins) so a fast gizmo drag only
	ever resolves the most recent goal. Results are delivered on the main thread
	through the queued ``solved`` signal.
	"""

	solved = pyqtSignal(str, object)  # robot_entity_id, IKSolveResult

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		# robot_entity_id -> (backend_name, request); latest-wins per robot.
		self._pending: Dict[str, tuple[str, IKSolveRequest]] = {}
		self._stop = False
		self._backends: Dict[str, IKBackend] = {}

	def submit(self, backend_name: str, request: IKSolveRequest) -> None:
		with QMutexLocker(self._mutex):
			self._pending[request.robot_entity_id] = (backend_name, request)
			self._wait.wakeOne()

	def clear_pending(self, robot_entity_id: Optional[str] = None) -> None:
		"""Drop pending worker jobs (one robot, or all)."""
		with QMutexLocker(self._mutex):
			if robot_entity_id is None:
				self._pending.clear()
			else:
				self._pending.pop(str(robot_entity_id), None)

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._wait.wakeOne()
		stop_and_retire(self, "IK worker", 2000)

	def run(self) -> None:  # noqa: D401 - QThread entry point
		while True:
			with QMutexLocker(self._mutex):
				while not self._pending and not self._stop:
					self._wait.wait(self._mutex)
				if self._stop:
					return
				_robot_id, (backend_name, request) = self._pending.popitem()

			try:
				result = solve_ik_request(backend_name, request, self._backends)
			except IKBackendError as exc:
				print(f"[IK] {exc}", flush=True)
				continue
			self.solved.emit(request.robot_entity_id, result)


class RobotIKSystem:
	"""Scene service that drives IK from target/base transform changes.

	Mirrors the ownership pattern of ``CollisionSystem``: created by ``Scene``
	and reachable via ``scene.robot_ik_system``.
	"""

	def __init__(self, scene: "Scene") -> None:
		self._scene = scene
		self._applying_ik = False
		self._suppress_async = 0
		self._last_submit: Dict[str, float] = {}
		self._worker = _IKWorker()
		self._worker.solved.connect(self._on_ik_solved)
		self._worker.start()
		# Main-thread backend cache for synchronous solves (play routines / Solve IK Now).
		self._sync_backends: Dict[str, IKBackend] = {}
		# Cached RobotIK components on robot roots; invalidated when the scene graph changes.
		self._ik_cache: Optional[List["RobotIKComponent"]] = None

		events = scene.events
		events.entity_transform_changed.connect(self._on_transform_changed)
		events.entity_added.connect(lambda _e: self._invalidate_ik_cache())
		events.entity_removed.connect(lambda _eid: self._invalidate_ik_cache())
		events.entity_reparented.connect(lambda _c, _p: self._invalidate_ik_cache())

	# ------------------------------------------------------------------ helpers

	def _invalidate_ik_cache(self) -> None:
		self._ik_cache = None

	def _ik_components(self) -> List["RobotIKComponent"]:
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		if self._ik_cache is not None:
			return self._ik_cache
		out: List["RobotIKComponent"] = []
		for ent in self._scene.entities():
			comp = ent.get_component(RobotIKComponent)
			if comp is not None:
				out.append(comp)
		self._ik_cache = out
		return out

	def _iks_for_changed(self, changed_id: str) -> List["RobotIKComponent"]:
		"""All enabled IK components affected by this transform (supports shared targets)."""
		out: List["RobotIKComponent"] = []
		for ik in self._ik_components():
			if not getattr(ik, "enabled", False):
				continue
			if self._affects(ik, changed_id):
				out.append(ik)
		return out

	@staticmethod
	def _is_self_or_ancestor(candidate_id: str, entity: Optional["Entity"]) -> bool:
		cur = entity
		while cur is not None:
			if cur.id == candidate_id:
				return True
			cur = cur.parent
		return False

	def _resolve_transform_ref(
		self, ik: "RobotIKComponent", attr: str
	) -> Optional["Entity"]:
		"""Resolve a ``TransformComponent`` reference field to its Entity,
		tolerating both a resolved component and an unresolved ``entity_id`` string.

		The reference resolver only runs on scene load, so paths like
		``Scene.duplicate_entity`` (to_dict/from_dict round-trip) can leave the
		field as a raw id string. When that happens, rebind it to the actual
		component so later access and re-serialization stay consistent.
		"""
		from MotionStudio.core.components.transform_component import TransformComponent

		value = getattr(ik, attr, None)
		if value is None:
			return None
		ent = getattr(value, "entity", None)
		if ent is not None:
			return ent
		if isinstance(value, str):
			resolved = self._scene.find_by_id(value)
			if resolved is not None:
				comp = resolved.get_component(TransformComponent)
				if comp is not None:
					setattr(ik, attr, comp)  # rebind string id -> component
					return resolved
		return None

	def _target_entity(self, ik: "RobotIKComponent") -> Optional["Entity"]:
		return self._resolve_transform_ref(ik, "target")

	def _affects(self, ik: "RobotIKComponent", changed_id: str) -> bool:
		robot_ent = ik.entity
		if robot_ent is None:
			return False
		target_ent = self._target_entity(ik)
		if target_ent is None:
			return False
		if self._is_self_or_ancestor(changed_id, target_ent) or self._is_self_or_ancestor(
			changed_id, robot_ent
		):
			return True
		# Re-solve if the user re-positions the TCP entity (changes the offset),
		# unless it's just a descendant of the robot already covered above.
		tcp_ent = self._resolve_transform_ref(ik, "tcp")
		if tcp_ent is not None and self._is_self_or_ancestor(changed_id, tcp_ent):
			return True
		return False

	# ------------------------------------------------------------------ events

	@contextmanager
	def suppress_async(self) -> Iterator[None]:
		"""Block transform-triggered worker solves (Scan Mission uses ``solve_sync``)."""
		self._suppress_async += 1
		try:
			yield
		finally:
			self._suppress_async = max(0, self._suppress_async - 1)

	def _on_transform_changed(self, changed_id: str) -> None:
		if self._applying_ik or self._suppress_async:
			return
		for ik in self._iks_for_changed(changed_id):
			self._enqueue(ik)

	def _enqueue(self, ik: "RobotIKComponent") -> None:
		request = self.build_request(ik)
		if request is None:
			return
		# Throttle to the component's solve rate; the worker also drops stale
		# requests, but this avoids spamming the queue during fast drags.
		hz = max(1.0, float(getattr(ik, "solve_hz", 20.0)))
		now = time.monotonic()
		robot_id = request.robot_entity_id
		last = self._last_submit.get(robot_id, 0.0)
		backend_name = str(getattr(ik, "backend", "analytic") or "analytic")
		if (now - last) < (1.0 / hz):
			# Still update the pending goal so the latest target is honoured.
			self._worker.submit(backend_name, request)
			return
		self._last_submit[robot_id] = now
		self._worker.submit(backend_name, request)

	def build_request(self, ik: "RobotIKComponent") -> Optional[IKSolveRequest]:
		"""Build an IK request from live scene state (call on the main thread)."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read

		robot_ent = ik.entity
		if robot_ent is None:
			return None
		target_ent = self._target_entity(ik)
		if target_ent is None:
			return None
		rd = robot_ent.get_component(RobotDescriptionComponent)
		if rd is None or not rd.urdf_path:
			return None

		project_root = self._scene.project_root
		abs_urdf = resolve_mesh_path_for_read(project_root, rd.urdf_path)
		if not abs_urdf:
			return None

		analytic_solver_path = str(getattr(ik, "analytic_solver_path", "") or "").strip()
		if not analytic_solver_path:
			analytic_solver_path = str(getattr(rd, "analytic_solver_path", "") or "").strip()
		abs_analytic_solver = resolve_mesh_path_for_read(project_root, analytic_solver_path)

		base_ent = self._resolve_base_entity(rd, robot_ent)
		try:
			t_goal = goal_in_base_frame(base_ent, target_ent)
		except Exception:
			return None

		# Custom Tool Control Point: solve so the TCP entity (not the raw tool
		# link) reaches the target. We capture the rigid offset T_ee_tcp between
		# the tool-link frame and the TCP, then aim the solver's ee frame at
		# T_goal * inv(T_ee_tcp) so that ee * T_ee_tcp == target.
		tcp_ent = self._resolve_transform_ref(ik, "tcp")
		if tcp_ent is not None:
			ee_id = rd.find_link_entity_id(rd.tool_link)
			ee_ent = self._scene.find_by_id(ee_id) if ee_id else None
			if ee_ent is not None:
				try:
					t_ee_tcp = relative_offset_m(ee_ent, tcp_ent)
					t_goal = project_to_se3(t_goal @ np.linalg.inv(t_ee_tcp))
				except Exception:
					pass

		joint_names = list(rd.actuated_joint_names)
		q_seed = np.array(
			[float(rd.joint_positions.get(n, 0.0)) for n in joint_names],
			dtype=np.float64,
		)
		return IKSolveRequest(
			robot_entity_id=robot_ent.id,
			urdf_path=str(abs_urdf),
			joint_names=joint_names,
			q_seed=q_seed,
			T_goal_base=t_goal,
			ee_link=rd.tool_link,
			position_tolerance_m=float(getattr(ik, "position_tolerance_m", 1e-3)),
			orientation_tolerance_rad=float(getattr(ik, "orientation_tolerance_rad", 1e-2)),
			max_iterations=int(getattr(ik, "max_iterations", 100)),
			root_link=str(rd.root_link),
			joints=[dict(j) for j in rd.joints],
			analytic_solver_path=str(abs_analytic_solver or ""),
		)

	def _resolve_base_entity(
		self, rd: "RobotDescriptionComponent", robot_ent: "Entity"
	) -> "Entity":
		"""Return the entity whose frame matches the URDF root link."""
		root_id = rd.find_link_entity_id(rd.root_link)
		if root_id:
			base = self._scene.find_by_id(root_id)
			if base is not None:
				return base
		return robot_ent

	# ------------------------------------------------------------------ apply

	def solve_sync(self, ik: "RobotIKComponent") -> Optional[IKSolveResult]:
		"""Solve IK and apply joints on the calling thread.

		Does **not** use the background worker. Clears any pending async job for
		this robot so a later worker result cannot overwrite the sync pose.
		Safe to call from edit-mode play-routine loops.
		"""
		request = self.build_request(ik)
		if request is None:
			return None

		self._worker.clear_pending(request.robot_entity_id)
		backend_name = str(getattr(ik, "backend", "analytic") or "analytic")
		try:
			result = solve_ik_request(backend_name, request, self._sync_backends)
		except IKBackendError as exc:
			return IKSolveResult(False, {}, str(exc))

		if result.joint_values:
			self.apply_solution(request.robot_entity_id, result.joint_values)
		return result

	def _on_ik_solved(self, robot_entity_id: str, result: IKSolveResult) -> None:
		if not result.success:
			return
		self.apply_solution(robot_entity_id, result.joint_values)

	def apply_solution(self, robot_entity_id: str, joint_values: Dict[str, float]) -> None:
		"""Write a solved configuration onto the robot and refresh FK (main thread)."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.robot.robot_kinematics import update_robot_fk

		robot_ent = self._scene.find_by_id(robot_entity_id)
		if robot_ent is None:
			return
		rd = robot_ent.get_component(RobotDescriptionComponent)
		if rd is None or not joint_values:
			return

		self._applying_ik = True
		rd._ik_updating = True
		try:
			for name, value in joint_values.items():
				if name in rd.joint_positions or name in rd.actuated_joint_names:
					rd.joint_positions[name] = float(value)
			update_robot_fk(rd)
		finally:
			rd._ik_updating = False
			self._applying_ik = False

	def apply_fk_from_joints(self, robot_entity: "Entity") -> None:
		"""Apply current ``joint_positions`` via FK (main thread).

		When this robot has an enabled ``RobotIK`` with a Target, the Target is
		snapped to the controlled frame (TCP if set, otherwise ``tool_link``)
		so continuous IK does not overwrite the manual joint edit. Transform
		events from FK/target writes are suppressed via ``_applying_ik``;
		``entity_changed`` is emitted under ``_ik_updating`` so
		``RobotDescription.on_entity_changed`` does not re-run FK.
		"""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent
		from MotionStudio.core.robot.robot_kinematics import update_robot_fk

		rd = robot_entity.get_component(RobotDescriptionComponent)
		if rd is None:
			return
		ik = robot_entity.get_component(RobotIKComponent)
		should_sync = (
			ik is not None
			and bool(getattr(ik, "enabled", False))
			and self._target_entity(ik) is not None
		)

		self._applying_ik = True
		rd._ik_updating = True
		try:
			update_robot_fk(rd)
			if should_sync and ik is not None:
				self._sync_target_to_controlled_frame(ik)
			try:
				self._scene.events.entity_changed.emit(robot_entity.id)
			except Exception:
				pass
		finally:
			rd._ik_updating = False
			self._applying_ik = False

	def _sync_target_to_controlled_frame(self, ik: "RobotIKComponent") -> None:
		"""Move Target so its world pose matches TCP (or tool_link if no TCP)."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.transform.utils import (
			set_world_position,
			set_world_rotation_quat,
			world_position,
			world_rotation_quat,
		)

		target_ent = self._target_entity(ik)
		if target_ent is None:
			return

		controlled = self._resolve_transform_ref(ik, "tcp")
		if controlled is None:
			robot_ent = ik.entity
			if robot_ent is None:
				return
			rd = robot_ent.get_component(RobotDescriptionComponent)
			if rd is None or not rd.tool_link:
				return
			link_id = rd.find_link_entity_id(rd.tool_link)
			if not link_id:
				return
			controlled = self._scene.find_by_id(link_id)
		if controlled is None:
			return

		set_world_position(target_ent, world_position(controlled))
		set_world_rotation_quat(target_ent, world_rotation_quat(controlled))

	# ------------------------------------------------------------------ teardown

	def shutdown(self) -> None:
		try:
			self._worker.stop()
		except Exception:
			pass

#!/usr/bin/env python3
"""
Main entry point for the PyEngine application.
This file works both in development and when packaged with PyInstaller.
"""
import sys
import os
from pathlib import Path

# Must be set before MotionStudio.app imports qdarktheme.
os.environ.setdefault("QT_API", "pyqt6")

# Determine if we're running as a packaged executable (PyInstaller)
# PyInstaller sets sys.frozen to True and sys._MEIPASS to the temp extraction directory
is_frozen = getattr(sys, 'frozen', False)
if not is_frozen and hasattr(sys, '_MEIPASS'):
    # Sometimes _MEIPASS is set even if frozen is False
    is_frozen = True

if is_frozen:
    # Running as a compiled executable
    # PyInstaller sets sys.frozen and sys._MEIPASS
    if hasattr(sys, '_MEIPASS'):
        # Add the temporary extraction directory to path (PyInstaller)
        sys.path.insert(0, sys._MEIPASS)
        # Set up environment for PyQt6 to find DLLs
        os.environ['QT_PLUGIN_PATH'] = os.path.join(sys._MEIPASS, 'PyQt6', 'Qt6', 'plugins')
    # The base path is where the executable is located
    BASE_DIR = Path(sys.executable).parent
else:
    # Running as a script in development
    # Get the directory containing this main.py file
    BASE_DIR = Path(__file__).parent
    # Add project root to Python path if not already there
    if str(BASE_DIR) not in sys.path:
        sys.path.insert(0, str(BASE_DIR))

# Now import and run the application
try:
    from MotionStudio.app import main
    
    if __name__ == "__main__":
        main()
except Exception as e:
    # Catch all exceptions and display them
    import traceback
    error_msg = f"Error: {e}\n"
    error_msg += f"Python path: {sys.path}\n"
    error_msg += f"Base directory: {BASE_DIR}\n"
    error_msg += f"Frozen: {getattr(sys, 'frozen', False)}\n"
    if hasattr(sys, '_MEIPASS'):
        error_msg += f"MEIPASS: {sys._MEIPASS}\n"
    error_msg += "\nTraceback:\n"
    error_msg += traceback.format_exc()
    
    # Always print to stderr (will show in console if console=True)
    print(error_msg, file=sys.stderr)
    
    # If frozen and no console, try to show a message box
    if is_frozen and not sys.stdout:
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            app = QApplication(sys.argv)
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Critical)
            msg.setWindowTitle("Application Error")
            msg.setText(f"An error occurred:\n\n{str(e)}")
            msg.setDetailedText(traceback.format_exc())
            msg.exec()
        except Exception:
            pass  # If we can't show a message box, at least we tried
    
    sys.exit(1)


# -*- mode: python ; coding: utf-8 -*-

import os

# pyqtdarktheme auto-detects Qt bindings at import time; force PyQt6 for Analysis.
os.environ.setdefault("QT_API", "pyqt6")

from PyInstaller.utils.hooks import collect_all

# Package is installed as pyqtdarktheme but imported as qdarktheme.
_qdarktheme_datas, _qdarktheme_binaries, _qdarktheme_hidden = collect_all("qdarktheme")
_darkdetect_datas, _darkdetect_binaries, _darkdetect_hidden = collect_all("darkdetect")

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=_qdarktheme_binaries + _darkdetect_binaries,
    datas=[
        ("resources", "resources"),
    ]
    + _qdarktheme_datas
    + _darkdetect_datas,
    hiddenimports=[
        "resources.resources_rc",
        "qdarktheme",
        "darkdetect",
        "PyQt6.QtSvg",
    ]
    + _qdarktheme_hidden
    + _darkdetect_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["PySide6"],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="MotionStudio",
    icon="resources/icon.ico",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

from __future__ import annotations

import sys

# Stable ID so Windows uses this app's window icon on the taskbar instead of python.exe.
_WINDOWS_APP_USER_MODEL_ID = "MotionStudio.Editor.1"


def configure_windows_taskbar_identity() -> None:
	"""
	On Windows, assign an explicit AppUserModelID before any UI is created.

	Without this, running via ``python main.py`` shows the Python launcher icon on
	the taskbar even when the window title-bar icon is set correctly.
	"""
	if sys.platform != "win32":
		return
	try:
		import ctypes

		ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(  # type: ignore[attr-defined]
			_WINDOWS_APP_USER_MODEL_ID
		)
	except Exception:
		pass

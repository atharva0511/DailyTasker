from __future__ import annotations

from typing import Callable, List

_Callback = Callable[[], None]


def _callbacks(plotter) -> List[_Callback]:
	lst = getattr(plotter, "_pyengine_camera_view_sync_callbacks", None)
	if lst is None:
		lst = []
		plotter._pyengine_camera_view_sync_callbacks = lst  # type: ignore[attr-defined]
	return lst


def register_camera_view_sync(plotter, callback: _Callback) -> None:
	"""
	Register a callback to refresh screen-space-sized viewport props (gizmos,
	origin axes, waypoint markers, vertex pick highlights, etc.).
	"""
	lst = _callbacks(plotter)
	if callback not in lst:
		lst.append(callback)


def notify_camera_view_changed(plotter) -> None:
	"""Invoke all registered screen-space sync callbacks (no render)."""
	for cb in list(_callbacks(plotter)):
		try:
			cb()
		except Exception:
			pass

from __future__ import annotations

from MotionStudio.core.debug import _runtime
from MotionStudio.core.ecs.viewport_lifecycle import invoke_on_viewport_draw
from MotionStudio.render.vtk.debug_draw_bridge import VtkDebugDrawBridge


class VtkViewportFrameBridge:
	"""
	Runs viewport lifecycle hooks and debug draw consumption on each VTK render pass.
	"""

	def __init__(self, plotter, scene, debug_draw_bridge: VtkDebugDrawBridge) -> None:
		self._plotter = plotter
		self._scene = scene
		self._debug_draw_bridge = debug_draw_bridge
		self._in_cycle: bool = False
		self._render_window = getattr(plotter, "ren_win", None)
		iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if self._render_window is None and iren is not None:
			try:
				self._render_window = iren.GetRenderWindow()
			except Exception:
				self._render_window = None
		if self._render_window is not None:
			try:
				self._render_window.AddObserver("StartEvent", self._on_render_start, 2.0)
			except Exception:
				pass

	def _on_render_start(self, _obj, _ev) -> None:
		if self._in_cycle:
			return
		self._in_cycle = True
		try:
			_runtime.begin_render_pass()
			try:
				invoke_on_viewport_draw(self._scene)
			finally:
				self._debug_draw_bridge.render_cycle()
		finally:
			_runtime.end_render_pass()
			self._in_cycle = False

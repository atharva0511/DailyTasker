"""
VTK/PyVista rendering backend for PyEngine.

This package provides an embedded PyVista/VTK viewport for the editor and
an ECS-to-VTK mirroring layer.
"""

__all__ = [
	"window",
	"scene_root",
	"picking",
	"interaction",
	"gizmo",
	"debug_draw_bridge",
	"viewport_frame_bridge",
]



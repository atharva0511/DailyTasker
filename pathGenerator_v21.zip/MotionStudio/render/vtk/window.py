from __future__ import annotations

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import QWidget

from pyvistaqt import QtInteractor  # type: ignore
import vtk  # type: ignore

from MotionStudio.render.vtk.camera_controller import VtkCameraController
from MotionStudio.render.vtk.origin_axes import install_world_origin_axes
from MotionStudio.render.vtk.view_controls import reset_camera, set_solid, set_wireframe


def create_vtk_container(parent: QWidget | None = None) -> tuple[QWidget, QtInteractor]:
	"""
	Create an embedded VTK/PyVista viewport suitable as a central widget.

	Returns (container_widget, interactor_widget).
	"""
	plotter = QtInteractor(parent=parent)
	plotter.setMinimumSize(400, 300)

	# Match old Qt3D dark background vibe
	try:
		# Dark blue gradient (bottom -> top)
		# PyVista supports gradients via (color, top=...)
		plotter.set_background((10 / 255, 12 / 255, 28 / 255), top=(12 / 255, 15 / 255, 32 / 255))
		# pass
	except Exception:
		pass
	# VTK-level gradient fallback (in case PyVista gradient API isn't available)
	try:
		base_renderer = getattr(plotter, "renderer", None)
		if base_renderer is not None:
			base_renderer.SetGradientBackground(True)
			base_renderer.SetBackground(10 / 255, 12 / 255, 28 / 255)   # bottom
			base_renderer.SetBackground2(20 / 255, 35 / 255, 50 / 255)  # top
	except Exception:
		pass

	# Prefer Z-up navigation
	try:
		plotter.camera.up = (0.0, 0.0, 1.0)
	except Exception:
		try:
			plotter.camera.up_vector = (0.0, 0.0, 1.0)
		except Exception:
			pass
	# Also enforce Z-up at the VTK camera level (the wrapper can be overwritten by styles)
	try:
		base_renderer = getattr(plotter, "renderer", None)
		if base_renderer is not None:
			cam = base_renderer.GetActiveCamera()
			if cam is not None:
				cam.SetViewUp(0.0, 0.0, 1.0)
				cam.OrthogonalizeViewUp()
				# Set Draw Distance (Near/Far clipping range)
				print("Setting clipping range")
				cam.SetClippingRange(0.001, 10000.0)
				# Disable auto-clipping resets that cause flicker during drag
				base_renderer.SetPreserveCameraClippingRange(True)
	except Exception:
		pass
	# Custom camera controller (enforced): RMB orbit, MMB pan, wheel zoom, LMB drag no-op.
	def _install_camera_controller() -> None:
		try:
			if getattr(plotter, "_pyengine_camera_controller", None) is None:  # type: ignore[attr-defined]
				plotter._pyengine_camera_controller = VtkCameraController(plotter)  # type: ignore[attr-defined]
				print("Camera controller installed (custom handlers)", flush=True)
		except Exception as e:
			print(f"Camera controller install failed: {e!r}", flush=True)

	# Install immediately and retry on a few ticks (QtInteractor may replace styles during init)
	_install_camera_controller()
	QTimer.singleShot(0, _install_camera_controller)
	QTimer.singleShot(50, _install_camera_controller)
	QTimer.singleShot(200, _install_camera_controller)

	# Overlay renderer for gizmos (always-on-top)
	# Setup synchronously so that systems created immediately after (like Gizmos) 
	# can find it.
	try:
		iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		rw = getattr(plotter, "ren_win", None)
		if rw is None and iren is not None:
			rw = iren.GetRenderWindow()
		base_renderer = getattr(plotter, "renderer", None)
		if rw is not None and base_renderer is not None:
			rw.SetNumberOfLayers(2)
			base_renderer.SetLayer(0)

			overlay = vtk.vtkRenderer()
			overlay.SetLayer(1)  # also sets PreserveColorBuffer=1 for non-zero layers
			overlay.SetInteractive(False)
			# Always-on-top: composite over layer-0 color but clear depth so overlay
			# props are not tested against scene geometry (SetErase(0) kept layer-0 depth).
			overlay.SetErase(1)
			overlay.SetPreserveColorBuffer(1)
			overlay.SetPreserveDepthBuffer(0)
			overlay.SetActiveCamera(base_renderer.GetActiveCamera())
			overlay.SetBackground(0.0, 0.0, 0.0)
			overlay.SetBackgroundAlpha(0.0)

			rw.AddRenderer(overlay)
			plotter._pyengine_overlay_renderer = overlay  # type: ignore[attr-defined]
	except Exception as e:
		print(f"Overlay renderer setup failed: {e!r}", flush=True)

	try:
		install_world_origin_axes(plotter)
	except Exception as e:
		print(f"World origin axes setup failed: {e!r}", flush=True)

	# VTK keybinds (work when viewport has focus): w=wireframe, s=solid, r=reset camera
	try:
		iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if iren is not None:
			def _on_keypress(_obj, _ev):
				try:
					key = str(iren.GetKeySym() or "").lower()
				except Exception:
					key = ""
				if key == "w":
					set_wireframe(plotter)
				elif key == "s":
					set_solid(plotter)
				elif key == "r":
					reset_camera(plotter)
			iren.AddObserver("KeyPressEvent", _on_keypress, 0.0)
	except Exception:
		pass

	return plotter, plotter



from __future__ import annotations

import math
from typing import List, Optional, Tuple

import vtk  # type: ignore

from MotionStudio.core.debug import _runtime


class VtkDebugDrawBridge:
	"""
	Consumes one-frame primitives from MotionStudio.core.debug.Debug and renders
	them in the viewport (overlay renderer when available).

	Invoked by VtkViewportFrameBridge on each render pass (not via its own observer).
	"""

	def __init__(self, plotter) -> None:
		self._plotter = plotter
		self._overlay = getattr(plotter, "_pyengine_overlay_renderer", None)
		self._actors: List[object] = []

	def render_cycle(self) -> None:
		"""
		One cycle:
		1) clear previously rendered debug actors
		2) consume queued primitives for this frame
		3) render new actors
		"""
		self.clear_actors()
		lines, spheres, boxes, axes_list, points, labels = _runtime.consume_for_render()
		for ln in lines:
			self._add_actor(self._make_line_actor(
				ln.start.x(), ln.start.y(), ln.start.z(),
				ln.end.x(), ln.end.y(), ln.end.z(),
				ln.color_rgb,
				ln.width,
			))
		for sph in spheres:
			self._add_actor(self._make_sphere_actor(
				sph.center.x(), sph.center.y(), sph.center.z(),
				sph.radius,
				sph.color_rgb,
				sph.filled,
				sph.opacity,
			))
		for box in boxes:
			self._add_actor(self._make_box_actor(
				box.center.x(), box.center.y(), box.center.z(),
				box.size.x(), box.size.y(), box.size.z(),
				box.color_rgb,
				box.width,
			))
		for axes in axes_list:
			self._add_axes(axes)
		for pt in points:
			self._add_actor(self._make_point_actor(
				pt.position.x(), pt.position.y(), pt.position.z(),
				pt.size,
				pt.screen_space,
				pt.color_rgb,
				pt.opacity,
			))
		for lbl in labels:
			self._add_actor(self._make_label_actor(
				lbl.position.x(), lbl.position.y(), lbl.position.z(),
				lbl.text,
				lbl.color_rgb,
				lbl.font_size,
			))

	def clear_actors(self) -> None:
		if not self._actors:
			return
		for a in self._actors:
			try:
				if self._overlay is not None:
					self._overlay.RemoveActor(a)
				else:
					self._plotter.remove_actor(a, reset_camera=False)
			except Exception:
				pass
		self._actors.clear()

	def _renderer(self):
		if self._overlay is not None:
			return self._overlay
		try:
			return self._plotter.renderer
		except Exception:
			return None

	def _active_camera(self):
		ren = self._renderer()
		if ren is None:
			return None
		try:
			return ren.GetActiveCamera()
		except Exception:
			return None

	def _add_actor(self, actor) -> None:
		try:
			if self._overlay is not None:
				self._overlay.AddActor(actor)
			else:
				self._plotter.add_actor(actor, pickable=False, reset_camera=False)
			self._actors.append(actor)
		except Exception:
			pass

	def _add_axes(self, axes) -> None:
		ox, oy, oz = axes.origin.x(), axes.origin.y(), axes.origin.z()
		length = axes.length
		basis = (
			(1.0, 0.0, 0.0, axes.x_color_rgb),
			(0.0, 1.0, 0.0, axes.y_color_rgb),
			(0.0, 0.0, 1.0, axes.z_color_rgb),
		)
		for bx, by, bz, rgb in basis:
			ex, ey, ez = bx * length, by * length, bz * length
			if axes.rotation is not None:
				ex, ey, ez = self._rotate_vector(axes.rotation, ex, ey, ez)
			self._add_actor(self._make_line_actor(
				ox, oy, oz,
				ox + ex, oy + ey, oz + ez,
				rgb,
				axes.width,
			))

	@staticmethod
	def _rotate_vector(
		quat_wxyz: Tuple[float, float, float, float],
		x: float, y: float, z: float,
	) -> Tuple[float, float, float]:
		w, qx, qy, qz = quat_wxyz
		ix = w * x + qy * z - qz * y
		iy = w * y + qz * x - qx * z
		iz = w * z + qx * y - qy * x
		iw = -qx * x - qy * y - qz * z
		rx = ix * w + iw * -qx + iy * -qz - iz * -qy
		ry = iy * w + iw * -qy + iz * -qx - ix * -qz
		rz = iz * w + iw * -qz + ix * -qy - iy * -qx
		return float(rx), float(ry), float(rz)

	@staticmethod
	def _apply_debug_surface_props(prop, rgb, opacity: float = 1.0, *, wireframe: bool = False) -> None:
		prop.SetColor(float(rgb[0]), float(rgb[1]), float(rgb[2]))
		prop.SetOpacity(float(opacity))
		if wireframe:
			prop.SetRepresentationToWireframe()
		else:
			prop.SetRepresentationToSurface()
		prop.SetAmbient(1.0)
		prop.SetDiffuse(0.0)
		prop.SetSpecular(0.0)
		prop.SetLighting(False)
		prop.SetDepthTest(False)

	@staticmethod
	def _make_line_actor(
		x0: float, y0: float, z0: float,
		x1: float, y1: float, z1: float,
		rgb, width: float,
	) -> vtk.vtkActor:
		src = vtk.vtkLineSource()
		src.SetPoint1(float(x0), float(y0), float(z0))
		src.SetPoint2(float(x1), float(y1), float(z1))
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		actor = vtk.vtkActor()
		actor.SetMapper(mapper)
		actor.SetPickable(False)
		try:
			prop = actor.GetProperty()
			prop.SetColor(float(rgb[0]), float(rgb[1]), float(rgb[2]))
			prop.SetLineWidth(float(width))
			prop.SetAmbient(1.0)
			prop.SetDiffuse(0.0)
			prop.SetSpecular(0.0)
			prop.SetLighting(False)
			prop.SetDepthTest(False)
		except Exception:
			pass
		return actor

	@staticmethod
	def _make_sphere_actor(
		x: float, y: float, z: float,
		radius: float, rgb, filled: bool, opacity: float,
	) -> vtk.vtkActor:
		src = vtk.vtkSphereSource()
		src.SetCenter(float(x), float(y), float(z))
		src.SetRadius(float(radius))
		src.SetThetaResolution(18)
		src.SetPhiResolution(18)
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		actor = vtk.vtkActor()
		actor.SetMapper(mapper)
		actor.SetPickable(False)
		try:
			prop = actor.GetProperty()
			VtkDebugDrawBridge._apply_debug_surface_props(
				prop, rgb, opacity, wireframe=not filled,
			)
			prop.SetLineWidth(2.0)
		except Exception:
			pass
		return actor

	@staticmethod
	def _make_box_actor(
		cx: float, cy: float, cz: float,
		sx: float, sy: float, sz: float,
		rgb, width: float,
	) -> vtk.vtkActor:
		src = vtk.vtkCubeSource()
		src.SetCenter(float(cx), float(cy), float(cz))
		src.SetXLength(float(sx))
		src.SetYLength(float(sy))
		src.SetZLength(float(sz))
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		actor = vtk.vtkActor()
		actor.SetMapper(mapper)
		actor.SetPickable(False)
		try:
			prop = actor.GetProperty()
			VtkDebugDrawBridge._apply_debug_surface_props(prop, rgb, wireframe=True)
			prop.SetLineWidth(float(width))
		except Exception:
			pass
		return actor

	def _pixel_radius_to_world(self, x: float, y: float, z: float, pixel_radius: float) -> float:
		"""Convert a desired on-screen radius (pixels) to world-space disc radius."""
		camera = self._active_camera()
		ren = self._renderer()
		h = 720
		if ren is not None:
			try:
				rw = ren.GetRenderWindow()
				if rw is not None:
					_, hv = rw.GetSize()
					h = max(1, int(hv))
			except Exception:
				pass
		if camera is None:
			return max(1e-6, pixel_radius * 0.001)
		try:
			cam_pos = camera.GetPosition()
			dx = float(x) - float(cam_pos[0])
			dy = float(y) - float(cam_pos[1])
			dz = float(z) - float(cam_pos[2])
			dist = math.sqrt(dx * dx + dy * dy + dz * dz)
			if camera.GetParallelProjection():
				world_height = 2.0 * float(camera.GetParallelScale())
			else:
				view_angle_rad = math.radians(float(camera.GetViewAngle()))
				world_height = 2.0 * dist * math.tan(view_angle_rad * 0.5)
			world_per_pixel = world_height / float(h)
			return max(1e-6, float(pixel_radius) * world_per_pixel)
		except Exception:
			return max(1e-6, pixel_radius * 0.001)

	def _make_point_actor(
		self,
		x: float, y: float, z: float,
		size: float,
		screen_space: bool,
		rgb, opacity: float,
	):
		"""
		Camera-facing filled disc at a world-space position.

		Geometry is centered on the actor origin; world position is applied via
		SetPosition. When ``screen_space`` is True, ``size`` is radius in pixels and
		is converted to world units from the active camera each render pass.
		"""
		radius = float(size)
		if screen_space:
			radius = self._pixel_radius_to_world(x, y, z, size)
		src = vtk.vtkDiskSource()
		src.SetInnerRadius(0.0)
		src.SetOuterRadius(radius)
		src.SetCircumferentialResolution(8)
		src.SetCenter(0.0, 0.0, 0.0)
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		camera = self._active_camera()
		if camera is not None:
			follower = vtk.vtkFollower()
			follower.SetMapper(mapper)
			follower.SetCamera(camera)
			follower.SetPosition(float(x), float(y), float(z))
			follower.SetPickable(False)
			try:
				prop = follower.GetProperty()
				VtkDebugDrawBridge._apply_debug_surface_props(prop, rgb, opacity)
			except Exception:
				pass
			return follower
		actor = vtk.vtkActor()
		actor.SetMapper(mapper)
		actor.SetPosition(float(x), float(y), float(z))
		actor.SetPickable(False)
		try:
			prop = actor.GetProperty()
			VtkDebugDrawBridge._apply_debug_surface_props(prop, rgb, opacity)
		except Exception:
			pass
		return actor

	@staticmethod
	def _make_label_actor(
		x: float, y: float, z: float,
		text: str, rgb, font_size: int,
	):
		actor = vtk.vtkBillboardTextActor3D()
		actor.SetInput(str(text))
		actor.SetPosition(float(x), float(y), float(z))
		actor.SetPickable(False)
		try:
			tp = actor.GetTextProperty()
			tp.SetFontSize(int(font_size))
			tp.SetColor(float(rgb[0]), float(rgb[1]), float(rgb[2]))
			tp.SetBold(False)
			tp.SetItalic(False)
			tp.SetShadow(False)
			tp.SetAmbient(1.0)
			tp.SetDiffuse(0.0)
		except Exception:
			pass
		return actor

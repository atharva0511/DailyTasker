from __future__ import annotations

import vtk  # type: ignore

from MotionStudio.render.vtk.camera_view_sync import notify_camera_view_changed
from MotionStudio.render.vtk.origin_axes import origin_axes_actor


def _base_renderer(plotter):
	r = getattr(plotter, "renderer", None)
	if r is not None:
		return r
	try:
		iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		rw = iren.GetRenderWindow() if iren is not None else None
		if rw is None:
			return None
		renderers = rw.GetRenderers()
		return renderers.GetFirstRenderer() if renderers is not None else None
	except Exception:
		return None


def _iter_actors(renderer):
	if renderer is None:
		return []
	actors = renderer.GetActors()
	if actors is None:
		return []
	out = []
	actors.InitTraversal()
	while True:
		a = actors.GetNextActor()
		if a is None:
			break
		out.append(a)
	return out


def _actors_excluded_from_camera_reset(plotter) -> set[vtk.vtkActor]:
	"""Props that should not affect Reset Camera framing (e.g. HUD origin axes)."""
	excluded: set[vtk.vtkActor] = set()
	axes = origin_axes_actor(plotter)
	if axes is not None:
		excluded.add(axes)
	return excluded


def _valid_actor_bounds(bounds) -> bool:
	if bounds is None or len(bounds) < 6:
		return False
	return bounds[1] >= bounds[0] and bounds[3] >= bounds[2] and bounds[5] >= bounds[4]


def _union_bounds(parts: list) -> list[float]:
	xmin = ymin = zmin = float("inf")
	xmax = ymax = zmax = float("-inf")
	for b in parts:
		xmin = min(xmin, float(b[0]))
		xmax = max(xmax, float(b[1]))
		ymin = min(ymin, float(b[2]))
		ymax = max(ymax, float(b[3]))
		zmin = min(zmin, float(b[4]))
		zmax = max(zmax, float(b[5]))
	return [xmin, xmax, ymin, ymax, zmin, zmax]


def _scene_bounds(renderer, exclude: set[vtk.vtkActor]) -> list[float] | None:
	parts: list = []
	for actor in _iter_actors(renderer):
		if actor in exclude:
			continue
		try:
			if not actor.GetVisibility():
				continue
		except Exception:
			pass
		try:
			bounds = actor.GetBounds()
		except Exception:
			continue
		if _valid_actor_bounds(bounds):
			parts.append(bounds)
	if not parts:
		return None
	return _union_bounds(parts)


def set_wireframe(plotter) -> None:
	"""
	Set all base-renderer actors to wireframe representation.
	"""
	r = _base_renderer(plotter)
	for a in _iter_actors(r):
		try:
			a.GetProperty().SetRepresentationToWireframe()
		except Exception:
			pass
	try:
		plotter.render()
	except Exception:
		pass


def set_solid(plotter) -> None:
	"""
	Set all base-renderer actors to solid surface representation.
	"""
	r = _base_renderer(plotter)
	for a in _iter_actors(r):
		try:
			a.GetProperty().SetRepresentationToSurface()
		except Exception:
			pass
	try:
		plotter.render()
	except Exception:
		pass


def reset_camera(plotter) -> None:
	"""
	Reset camera framing while preserving Z-up.

	World origin axes (and other HUD props registered for exclusion) are omitted
	from the bounds so a small screen-space triad at (0,0,0) does not pull the
	frame when pressing **R** or using View → Reset Camera.
	"""
	r = _base_renderer(plotter)
	if r is None:
		return
	exclude = _actors_excluded_from_camera_reset(plotter)
	bounds = _scene_bounds(r, exclude)
	try:
		if bounds is not None:
			r.ResetCamera(bounds)
		else:
			r.ResetCamera()
	except Exception:
		pass
	try:
		if bounds is not None:
			r.ResetCameraClippingRange(bounds)
		else:
			r.ResetCameraClippingRange()
	except Exception:
		pass
	try:
		cam = r.GetActiveCamera()
		if cam is not None:
			cam.SetViewUp(0.0, 0.0, 1.0)
			cam.OrthogonalizeViewUp()
	except Exception:
		pass
	try:
		notify_camera_view_changed(plotter)
	except Exception:
		pass
	try:
		plotter.render()
	except Exception:
		pass

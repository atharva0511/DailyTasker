from __future__ import annotations

from typing import Optional, Tuple

import vtk  # type: ignore
from PyQt6.QtGui import QVector3D

from MotionStudio.core.scene.viewport import CameraState
from MotionStudio.render.vtk.gizmo import utils as gizmo_utils


class VtkViewportService:
	"""
	VTK-backed viewport queries for component scripts (via Scene.viewport).
	"""

	def __init__(self, plotter) -> None:
		self._plotter = plotter

	def _renderer(self) -> Optional[vtk.vtkRenderer]:
		overlay = getattr(self._plotter, "_pyengine_overlay_renderer", None)
		if overlay is not None:
			return overlay
		try:
			return self._plotter.renderer
		except Exception:
			return None

	def world_to_display(self, world: QVector3D) -> Tuple[float, float, float]:
		ren = self._renderer()
		if ren is None:
			return 0.0, 0.0, 0.0
		return gizmo_utils._world_to_display(ren, world)

	def display_to_world(self, x: float, y: float, depth: float = 0.0) -> QVector3D:
		ren = self._renderer()
		if ren is None:
			return QVector3D()
		return gizmo_utils._display_to_world(ren, x, y, depth)

	def viewport_size(self) -> Tuple[int, int]:
		ren = self._renderer()
		if ren is None:
			return 1, 1
		try:
			rw = ren.GetRenderWindow()
			if rw is not None:
				w, h = rw.GetSize()
				return max(1, int(w)), max(1, int(h))
		except Exception:
			pass
		return 1, 1

	def camera_state(self) -> Optional[CameraState]:
		ren = self._renderer()
		if ren is None:
			return None
		try:
			cam = ren.GetActiveCamera()
			if cam is None:
				return None
			pos = cam.GetPosition()
			focal = cam.GetFocalPoint()
			up = cam.GetViewUp()
			return CameraState(
				position=QVector3D(float(pos[0]), float(pos[1]), float(pos[2])),
				focal_point=QVector3D(float(focal[0]), float(focal[1]), float(focal[2])),
				view_up=QVector3D(float(up[0]), float(up[1]), float(up[2])),
				view_angle_deg=float(cam.GetViewAngle()),
				parallel_projection=bool(cam.GetParallelProjection()),
				parallel_scale=float(cam.GetParallelScale()),
			)
		except Exception:
			return None

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import vtk  # type: ignore
from PyQt6.QtGui import QMatrix4x4, QVector3D, QVector4D

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.transform.matrix import qmatrix_from_prs
from MotionStudio.core.components.transform_component import TransformComponent


def overlay_renderer(plotter) -> Optional[vtk.vtkRenderer]:
	"""Layer-1 renderer for gizmos, debug draws, and other on-top 3D props."""
	return getattr(plotter, "_pyengine_overlay_renderer", None)


def pick_renderer(plotter, fallback: vtk.vtkRenderer) -> vtk.vtkRenderer:
	"""Renderer that owns overlay actors (for vtkPicker.Pick)."""
	return overlay_renderer(plotter) or fallback


def configure_overlay_3d_actor(actor: vtk.vtkActor, *, opacity: float = 1.0) -> None:
	"""
	Flat, unlit surface props intended for the overlay renderer.
	Always-on-top comes from the layer-1 depth buffer reset, not vtkProperty::SetDepthTest
	(not available on vtkOpenGLProperty in VTK 9.5).
	"""
	prop = actor.GetProperty()
	prop.SetAmbient(1.0)
	prop.SetDiffuse(0.0)
	prop.SetSpecular(0.0)
	prop.SetLighting(False)
	if opacity < 1.0:
		prop.SetOpacity(float(opacity))


@dataclass
class Ray:
	origin: QVector3D
	dir: QVector3D  # normalized


def _qv3(x: float, y: float, z: float) -> QVector3D:
	return QVector3D(float(x), float(y), float(z))


def _norm(v: QVector3D) -> QVector3D:
	l = max(1e-9, v.length())
	return QVector3D(v.x() / l, v.y() / l, v.z() / l)


def screen_ray(renderer: vtk.vtkRenderer, x: int, y: int) -> Ray:
	"""
	Compute a world-space ray from display coords (x,y).
	Uses DisplayToWorld at z=0 (near) and z=1 (far).
	"""
	renderer.SetDisplayPoint(float(x), float(y), 0.0)
	renderer.DisplayToWorld()
	near = renderer.GetWorldPoint()
	renderer.SetDisplayPoint(float(x), float(y), 1.0)
	renderer.DisplayToWorld()
	far = renderer.GetWorldPoint()

	o = _qv3(near[0], near[1], near[2])
	f = _qv3(far[0], far[1], far[2])
	d = _norm(f - o)
	return Ray(origin=o, dir=d)

def _world_to_display(renderer: vtk.vtkRenderer, p: QVector3D) -> Tuple[float, float, float]:
	renderer.SetWorldPoint(float(p.x()), float(p.y()), float(p.z()), 1.0)
	renderer.WorldToDisplay()
	d = renderer.GetDisplayPoint()
	return float(d[0]), float(d[1]), float(d[2])


def _display_to_world(renderer: vtk.vtkRenderer, x: float, y: float, z: float) -> QVector3D:
	renderer.SetDisplayPoint(float(x), float(y), float(z))
	renderer.DisplayToWorld()
	w = renderer.GetWorldPoint()  # (x,y,z,w)
	ww = float(w[3]) if len(w) > 3 else 1.0
	if abs(ww) < 1e-9:
		ww = 1.0
	return _qv3(float(w[0]) / ww, float(w[1]) / ww, float(w[2]) / ww)


def world_length_for_pixels(renderer: vtk.vtkRenderer, world_point: QVector3D, pixels: float) -> float:
	"""
	Return world-space distance corresponding to `pixels` at the depth of `world_point`.
	"""
	dx, dy, dz = _world_to_display(renderer, world_point)
	p2 = _display_to_world(renderer, dx + float(pixels), dy, dz)
	return float((p2 - world_point).length())


def closest_axis_t(ray: Ray, axis_origin: QVector3D, axis_dir: QVector3D) -> float:
	"""
	Returns scalar t such that point = axis_origin + axis_dir*t is closest to the ray.
	axis_dir should be normalized.
	"""
	p = ray.origin
	r = ray.dir
	q = axis_origin
	s = axis_dir

	# Solve closest points between two lines:
	# L1: p + r*u, L2: q + s*t
	# Using formula based on dot products.
	w0 = p - q
	a = QVector3D.dotProduct(r, r)  # 1
	b = QVector3D.dotProduct(r, s)
	c = QVector3D.dotProduct(s, s)  # 1
	d = QVector3D.dotProduct(r, w0)
	e = QVector3D.dotProduct(s, w0)

	den = (a * c - b * b)
	if abs(den) < 1e-9:
		# Nearly parallel; project w0 onto axis
		return -e

	# u = (b*e - c*d)/den
	# t = (a*e - b*d)/den
	t = (a * e - b * d) / den
	return float(t)


def world_matrix_from_ecs(entity: Entity) -> QMatrix4x4:
	stack: list[QMatrix4x4] = []
	curr: Optional[Entity] = entity
	while curr is not None:
		t = curr.get_component(TransformComponent)
		if t is None:
			stack.append(QMatrix4x4())
		else:
			stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
		curr = curr.parent
	world = QMatrix4x4()
	for m in reversed(stack):
		world = world * m
	return world


def parent_world_matrix(entity: Entity) -> QMatrix4x4:
	if entity.parent is None:
		return QMatrix4x4()
	return world_matrix_from_ecs(entity.parent)


def world_position(entity: Entity) -> QVector3D:
	m = world_matrix_from_ecs(entity)
	return QVector3D(m.column(3).toVector3D())


def local_position_from_world(entity: Entity, world_pos: QVector3D) -> QVector3D:
	"""
	Convert a world-space position into the entity's parent-local space.
	If no parent, returns world_pos unchanged.
	"""
	if entity.parent is None:
		return world_pos
	pm = parent_world_matrix(entity)
	inv, ok = pm.inverted()
	if not ok:
		return world_pos
	p4 = inv * QVector4D(world_pos, 1.0)
	return QVector3D(p4.x(), p4.y(), p4.z())


def world_axis_dirs_local(entity: Entity) -> Tuple[QVector3D, QVector3D, QVector3D]:
	"""
	Return world-space directions corresponding to the entity's local X/Y/Z axes.
	"""
	m = world_matrix_from_ecs(entity)
	x = _norm(QVector3D(m.column(0).toVector3D()))
	y = _norm(QVector3D(m.column(1).toVector3D()))
	z = _norm(QVector3D(m.column(2).toVector3D()))
	return x, y, z


def basis_and_origin_from_vtk_actor(actor: vtk.vtkActor) -> Tuple[QVector3D, Tuple[QVector3D, QVector3D, QVector3D]]:
	"""
	Extract world origin + basis vectors from a vtkActor's transform/matrix.

	We prefer the actor's effective matrix (including UserTransform).
	Handles both common conventions by probing translation location.
	"""
	m4 = vtk.vtkMatrix4x4()
	try:
		actor.GetMatrix(m4)
	except Exception:
		# Fallback: try user transform matrix
		ut = actor.GetUserTransform()
		if ut is not None:
			m4.DeepCopy(ut.GetMatrix())

	# Try translation in last column (VTK common)
	ox_c = QVector3D(m4.GetElement(0, 3), m4.GetElement(1, 3), m4.GetElement(2, 3))
	# Alternate: translation in last row (some transposed cases)
	ox_r = QVector3D(m4.GetElement(3, 0), m4.GetElement(3, 1), m4.GetElement(3, 2))
	origin = ox_c if ox_c.length() > 1e-8 else ox_r

	# Basis vectors: take columns (x,y,z) by default
	x = _norm(QVector3D(m4.GetElement(0, 0), m4.GetElement(1, 0), m4.GetElement(2, 0)))
	y = _norm(QVector3D(m4.GetElement(0, 1), m4.GetElement(1, 1), m4.GetElement(2, 1)))
	z = _norm(QVector3D(m4.GetElement(0, 2), m4.GetElement(1, 2), m4.GetElement(2, 2)))

	# If axes are degenerate, fall back to rows
	if x.length() < 1e-6 or y.length() < 1e-6 or z.length() < 1e-6:
		x = _norm(QVector3D(m4.GetElement(0, 0), m4.GetElement(0, 1), m4.GetElement(0, 2)))
		y = _norm(QVector3D(m4.GetElement(1, 0), m4.GetElement(1, 1), m4.GetElement(1, 2)))
		z = _norm(QVector3D(m4.GetElement(2, 0), m4.GetElement(2, 1), m4.GetElement(2, 2)))

	return origin, (x, y, z)



from __future__ import annotations

from typing import Optional, Tuple

import vtk  # type: ignore

from PyQt6.QtCore import QObject
from PyQt6.QtGui import QVector3D, QQuaternion, QUndoStack

from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.render.vtk.scene_root import VtkSceneRoot
from MotionStudio.render.vtk.gizmo.translate_gizmo import VtkTranslateGizmo
from MotionStudio.render.vtk.gizmo.rotate_gizmo import VtkRotateGizmo
from MotionStudio.render.vtk.gizmo.utils import basis_and_origin_from_vtk_actor, world_length_for_pixels, world_position, world_axis_dirs_local
from MotionStudio.core.transform.utils import world_rotation_quat
from MotionStudio.core.undo.commands import WaypointPositionChangeCommand, WaypointRotationChangeCommand


class VtkWaypointGizmo:
	"""
	Gizmo for editing individual waypoints in path features.
	Combines translate and rotate gizmos positioned at the selected waypoint.
	"""
	
	def __init__(self, plotter, scene: Scene, selection: SelectionModel, scene_root: VtkSceneRoot, 
	             translate_gizmo: VtkTranslateGizmo, rotate_gizmo: VtkRotateGizmo, 
	             undo_stack: Optional[QUndoStack] = None) -> None:
		self._plotter = plotter
		self._scene = scene
		self._selection = selection
		self._scene_root = scene_root
		self._translate_gizmo = translate_gizmo
		self._rotate_gizmo = rotate_gizmo
		self._undo_stack = undo_stack
		
		self._renderer = getattr(plotter, "renderer", None)
		if self._renderer is None:
			iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
			if iren:
				rw = iren.GetRenderWindow()
				if rw:
					renderers = rw.GetRenderers()
					self._renderer = renderers.GetFirstRenderer() if renderers else None
		
		self._current_waypoint: Optional[Tuple[int, int]] = None  # (feature_idx, waypoint_idx)
		self._current_entity_id: Optional[str] = None
		self._waypoint_position: Optional[QVector3D] = None
		self._waypoint_rotation: Optional[QQuaternion] = None
		
		# Connect to selection changes
		self._selection.current_waypoint_changed.connect(self._on_waypoint_selection_changed)
		self._selection.current_entity_changed.connect(self._on_entity_changed)
		self._selection.interaction_active_changed.connect(self._on_interaction_active_changed)
		
		# Track gizmo drag state
		self._is_dragging = False
		self._drag_start_position: Optional[QVector3D] = None
		self._drag_start_rotation: Optional[QQuaternion] = None
		self._waypoint_proxy_entity: Optional[Entity] = None
		
		# Connect to entity transform changes to intercept gizmo updates
		self._scene.events.entity_transform_changed.connect(self._on_entity_transform_changed)
		
		# Connect to gizmo drag events via interactor
		self._iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if self._iren:
			# Monitor left button press/release to track drag state
			self._iren.AddObserver("LeftButtonPressEvent", self._on_left_press, 2.0)  # Higher priority than gizmos
			self._iren.AddObserver("LeftButtonReleaseEvent", self._on_left_release, 2.0)
		
		# Store original gizmo enabled state
		self._original_gizmo_enabled = True
		self._pending_position_command: Optional[WaypointPositionChangeCommand] = None
		self._pending_rotation_command: Optional[WaypointRotationChangeCommand] = None
	
	def _on_waypoint_selection_changed(self, waypoint: Optional[Tuple[int, int]]) -> None:
		"""Handle waypoint selection changes."""
		self._current_waypoint = waypoint
		if waypoint is None:
			self._hide_gizmos()
			self._cleanup_proxy_entity()
			return
		owner_id = getattr(self._selection, "current_waypoint_entity_id", None)
		if isinstance(owner_id, str):
			self._current_entity_id = owner_id
		
		# Create/update proxy entity for gizmo positioning
		self._update_proxy_entity()
		# Update gizmo position and orientation
		self._update_gizmo_position()
	
	def _on_entity_changed(self, entity) -> None:
		"""Handle entity selection changes."""
		if entity is None:
			self._current_entity_id = None
			self._hide_gizmos()
			self._cleanup_proxy_entity()
			self._is_dragging = False
			self._drag_start_position = None
			self._drag_start_rotation = None
			return
		# Ignore internal proxy selection changes; owner entity stays the same.
		if getattr(entity, "name", "") == "__waypoint_proxy__":
			return
		self._current_entity_id = entity.id
		if self._current_waypoint is not None:
			self._update_proxy_entity()
			self._update_gizmo_position()
		else:
			self._cleanup_proxy_entity()

	def _on_interaction_active_changed(self, active: bool) -> None:
		"""
		Reliably begin/end waypoint drag alongside translate/rotate gizmo interaction.
		"""
		if self._waypoint_proxy_entity is None:
			return
		if self._selection.current != self._waypoint_proxy_entity:
			return
		if active and not self._is_dragging:
			self._is_dragging = True
			self._start_waypoint_drag()
		elif (not active) and self._is_dragging:
			self._end_waypoint_drag()
			self._is_dragging = False
	
	def _cleanup_proxy_entity(self) -> None:
		"""Remove the proxy entity if it exists."""
		if self._waypoint_proxy_entity is not None:
			# Clear selection if it's the proxy
			if self._selection.current == self._waypoint_proxy_entity:
				# Restore original entity selection
				if self._current_entity_id:
					entity = self._scene.find_by_id(self._current_entity_id)
					if entity:
						self._selection.set_current(entity)
					else:
						self._selection.set_current(None)
			# Remove proxy from scene
			try:
				if hasattr(self._scene, '_entities_by_id'):
					if self._waypoint_proxy_entity.id in self._scene._entities_by_id:
						del self._scene._entities_by_id[self._waypoint_proxy_entity.id]
			except Exception:
				pass
			self._waypoint_proxy_entity = None
	
	def _ensure_gizmos_visible(self) -> None:
		"""Ensure gizmos are visible for the proxy entity."""
		if self._waypoint_proxy_entity is None:
			return
		# Force gizmos to update by triggering a reposition
		# The translate and rotate gizmos should automatically show when proxy is selected
		# But we need to ensure they're enabled
		try:
			self._translate_gizmo.set_enabled(True)
			self._rotate_gizmo.set_enabled(True)
		except Exception:
			pass
	
	def _update_proxy_entity(self) -> None:
		"""Create or update a proxy entity that represents the waypoint for gizmo positioning."""
		if self._current_waypoint is None or self._current_entity_id is None:
			self._cleanup_proxy_entity()
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			self._cleanup_proxy_entity()
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			self._cleanup_proxy_entity()
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			self._cleanup_proxy_entity()
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get mesh actor for transform
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		if mesh_actor is None:
			self._cleanup_proxy_entity()
			return
		
		# Generate waypoints to get current state
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx < 0 or waypoint_idx >= len(waypoints):
			self._cleanup_proxy_entity()
			return
		
		waypoint = waypoints[waypoint_idx]
		
		# Transform waypoint to world space
		mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
		local_pos = waypoint.position
		local_rot = waypoint.rotation
		
		if mesh_matrix:
			# Transform position via the mesh actor's user matrix.
			out = [0.0, 0.0, 0.0, 1.0]
			mesh_matrix.MultiplyPoint([float(local_pos.x()), float(local_pos.y()), float(local_pos.z()), 1.0], out)
			world_pos = QVector3D(
				out[0] / out[3] if abs(out[3]) > 1e-9 else out[0],
				out[1] / out[3] if abs(out[3]) > 1e-9 else out[1],
				out[2] / out[3] if abs(out[3]) > 1e-9 else out[2]
			)
			# Compose rotation: q_world = q_entity_world * q_waypoint_local. This is
			# what makes the gizmo handles align with the rotated waypoint frame when
			# the owning entity has a non-identity world rotation.
			world_rot = (world_rotation_quat(entity) * local_rot).normalized()
		else:
			world_pos = local_pos
			world_rot = local_rot
		
		# Create or update proxy entity
		if self._waypoint_proxy_entity is None:
			from MotionStudio.core.ecs.entity import Entity
			from MotionStudio.utils.ids import generate_uuid
			self._waypoint_proxy_entity = Entity(name="__waypoint_proxy__")
			# Set the ID manually after creation
			self._waypoint_proxy_entity.id = generate_uuid()
			transform = TransformComponent()
			self._waypoint_proxy_entity.add_component(transform)
			# Set scene reference so entity can work properly
			self._waypoint_proxy_entity._scene = self._scene
			# Add to scene entities dict (but not to root, so it's invisible in hierarchy)
			try:
				if hasattr(self._scene, '_entities_by_id'):
					self._scene._entities_by_id[self._waypoint_proxy_entity.id] = self._waypoint_proxy_entity
			except Exception:
				pass
		
		# Update proxy transform to match waypoint
		transform = self._waypoint_proxy_entity.get_component(TransformComponent)
		if transform:
			transform.position = world_pos
			transform.rotation_quat = world_rot
		
		# Temporarily select proxy entity so gizmos position at it
		if self._selection.current != self._waypoint_proxy_entity:
			# Keep waypoint selection while redirecting transform gizmos to proxy.
			self._selection.set_current(self._waypoint_proxy_entity, clear_subselection=False)
			# Ensure gizmos are visible
			self._ensure_gizmos_visible()
	
	def _update_gizmo_position(self) -> None:
		"""Update gizmo position and orientation to match selected waypoint."""
		if self._current_waypoint is None or self._current_entity_id is None:
			self._hide_gizmos()
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			self._hide_gizmos()
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			self._hide_gizmos()
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			self._hide_gizmos()
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get mesh actor for transform
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		if mesh_actor is None:
			self._hide_gizmos()
			return
		
		# Generate waypoints to get current state
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx < 0 or waypoint_idx >= len(waypoints):
			self._hide_gizmos()
			return
		
		waypoint = waypoints[waypoint_idx]
		
		# Transform waypoint to world space
		mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
		local_pos = waypoint.position
		local_rot = waypoint.rotation
		
		if mesh_matrix:
			# Transform position via the mesh actor's user matrix.
			out = [0.0, 0.0, 0.0, 1.0]
			mesh_matrix.MultiplyPoint([float(local_pos.x()), float(local_pos.y()), float(local_pos.z()), 1.0], out)
			world_pos = QVector3D(
				out[0] / out[3] if abs(out[3]) > 1e-9 else out[0],
				out[1] / out[3] if abs(out[3]) > 1e-9 else out[1],
				out[2] / out[3] if abs(out[3]) > 1e-9 else out[2]
			)
			# Compose rotation: q_world = q_entity_world * q_waypoint_local so the
			# gizmo handles align with the rotated waypoint frame.
			world_rot = (world_rotation_quat(entity) * local_rot).normalized()
		else:
			world_pos = local_pos
			world_rot = local_rot
		
		self._waypoint_position = world_pos
		self._waypoint_rotation = world_rot
		
		# Position gizmos at waypoint
		# We need to create a temporary entity-like object for the gizmos
		# For now, we'll directly position the gizmo actors
		self._position_gizmos(world_pos, world_rot)
	
	def _position_gizmos(self, position: QVector3D, rotation: QQuaternion) -> None:
		"""Position translate and rotate gizmos at the waypoint."""
		# Gizmos are positioned automatically via proxy entity selection
		# This method is kept for compatibility but the actual positioning
		# happens through the proxy entity
		pass
	
	def _hide_gizmos(self) -> None:
		"""Hide waypoint gizmos."""
		# Gizmos are hidden automatically when proxy entity is deselected
		pass
	
	def _on_entity_transform_changed(self, entity_id: str) -> None:
		"""Intercept transform changes to update waypoints instead of entity transforms."""
		# Check if this is the proxy entity being transformed
		if self._waypoint_proxy_entity is None or self._waypoint_proxy_entity.id != entity_id:
			return
		
		# We must update when:
		# - dragging via gizmo handles (self._is_dragging / interaction_active)
		# - or when the user edits proxy Transform in the Inspector (selection.current == proxy)
		# Otherwise we'd skip waypoint updates and the waypoint would appear unchanged.
		should_update = (
			self._is_dragging
			or self._selection.interaction_active
			or (self._selection.current == self._waypoint_proxy_entity)
		)
		if not should_update:
			return
		
		# Get the transform from proxy entity
		transform = self._waypoint_proxy_entity.get_component(TransformComponent)
		if transform is None:
			return
		
		# Update waypoint with new transform
		if self._current_waypoint is None or self._current_entity_id is None:
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		from MotionStudio.core.components.feature import CustomFeature
		if not isinstance(feature, CustomFeature):
			return
		if waypoint_idx < 0 or waypoint_idx >= len(feature.waypoints):
			return
		waypoint = feature.waypoints[waypoint_idx]
		
		# Get mesh actor for transform
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		if mesh_actor is None:
			return
		
		# Transform world position/rotation back to local space
		mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
		world_pos = transform.position
		world_rot = transform.rotation_quat
		
		if mesh_matrix:
			# Invert matrix to get local position
			inv_matrix = vtk.vtkMatrix4x4()
			vtk.vtkMatrix4x4.Invert(mesh_matrix, inv_matrix)
			out = [0.0, 0.0, 0.0, 1.0]
			inv_matrix.MultiplyPoint([float(world_pos.x()), float(world_pos.y()), float(world_pos.z()), 1.0], out)
			local_pos = QVector3D(
				out[0] / out[3] if abs(out[3]) > 1e-9 else out[0],
				out[1] / out[3] if abs(out[3]) > 1e-9 else out[1],
				out[2] / out[3] if abs(out[3]) > 1e-9 else out[2]
			)
			# Inverse of the local->world composition done in _update_proxy_entity:
			#   q_world = q_entity_world * q_waypoint_local
			#   => q_waypoint_local = q_entity_world^-1 * q_world
			local_rot = (world_rotation_quat(entity).inverted() * world_rot).normalized()
		else:
			local_pos = world_pos
			local_rot = world_rot
		
		# Only apply the epsilon early-exit during interactive drag.
		# For Inspector edits we always write back (writes are infrequent and correctness matters).
		if self._is_dragging or self._selection.interaction_active:
			try:
				pos_delta = (waypoint.position - local_pos).length()
			except Exception:
				pos_delta = 1e9

			try:
				dot = float(
					waypoint.rotation.scalar() * local_rot.scalar()
					+ waypoint.rotation.x() * local_rot.x()
					+ waypoint.rotation.y() * local_rot.y()
					+ waypoint.rotation.z() * local_rot.z()
				)
				rot_delta = 1.0 - abs(dot)
			except Exception:
				rot_delta = 1e9

			if pos_delta < 1e-6 and rot_delta < 1e-6:
				return

		waypoint.position = local_pos
		waypoint.rotation = local_rot
		# During drag we prefer transform-only updates for responsiveness.
		# For inspector edits (non-drag), we need a full rebuild for path geometry.
		try:
			if self._is_dragging or self._selection.interaction_active:
				self._scene.events.entity_transform_changed.emit(self._current_entity_id)
			else:
				self._scene.events.entity_changed.emit(self._current_entity_id)
		except Exception:
			pass
	
	def _on_left_press(self, obj, ev) -> None:
		"""Track when drag starts on waypoint proxy entity."""
		if self._waypoint_proxy_entity is None:
			return
		if self._selection.current != self._waypoint_proxy_entity:
			return
		
		# Check if gizmo is being dragged
		x, y = self._iren.GetEventPosition()
		try:
			# Check if translate or rotate gizmo is being picked
			translate_picker = self._translate_gizmo._picker
			rotate_picker = self._rotate_gizmo._picker
			
			translate_picker.Pick(x, y, 0, self._renderer)
			rotate_picker.Pick(x, y, 0, self._renderer)
			
			translate_actor = translate_picker.GetActor()
			rotate_actor = rotate_picker.GetActor()
			
			if translate_actor is not None or rotate_actor is not None:
				# Gizmo drag starting on waypoint proxy
				if not self._is_dragging:
					self._is_dragging = True
					self._start_waypoint_drag()
		except Exception:
			pass
	
	def _on_left_release(self, obj, ev) -> None:
		"""Track when drag ends on waypoint proxy entity."""
		if self._is_dragging and (not self._selection.interaction_active):
			self._end_waypoint_drag()
			self._is_dragging = False
	
	def _start_waypoint_drag(self) -> None:
		"""Start a waypoint drag operation."""
		if self._current_waypoint is None or self._current_entity_id is None:
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get current waypoint values
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx >= len(waypoints):
			return
		
		waypoint = waypoints[waypoint_idx]
		self._drag_start_position = QVector3D(waypoint.position)
		self._drag_start_rotation = QQuaternion(waypoint.rotation)
	
	def _end_waypoint_drag(self) -> None:
		"""End a waypoint drag operation and commit undo command."""
		if self._current_waypoint is None or self._current_entity_id is None:
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get current waypoint values
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx >= len(waypoints):
			return
		
		waypoint = waypoints[waypoint_idx]
		current_position = QVector3D(waypoint.position)
		current_rotation = QQuaternion(waypoint.rotation)
		
		# Create undo commands if values changed
		if self._drag_start_position is not None and current_position != self._drag_start_position:
			cmd = WaypointPositionChangeCommand(
				self._scene, self._current_entity_id, feature_idx, waypoint_idx,
				self._drag_start_position, current_position
			)
			if self._undo_stack is not None:
				self._undo_stack.push(cmd)
			else:
				cmd.redo()
		
		if self._drag_start_rotation is not None and current_rotation != self._drag_start_rotation:
			cmd = WaypointRotationChangeCommand(
				self._scene, self._current_entity_id, feature_idx, waypoint_idx,
				self._drag_start_rotation, current_rotation
			)
			if self._undo_stack is not None:
				self._undo_stack.push(cmd)
			else:
				cmd.redo()
		
		self._drag_start_position = None
		self._drag_start_rotation = None
	
	def update_waypoint_position(self, new_position: QVector3D) -> None:
		"""Update waypoint position (called during gizmo drag)."""
		if self._current_waypoint is None or self._current_entity_id is None:
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get mesh actor for transform
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		if mesh_actor is None:
			return
		
		# Transform world position back to local space
		mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
		if mesh_matrix:
			# Invert matrix to get local position
			inv_matrix = vtk.vtkMatrix4x4()
			vtk.vtkMatrix4x4.Invert(mesh_matrix, inv_matrix)
			out = [0.0, 0.0, 0.0, 1.0]
			inv_matrix.MultiplyPoint([float(new_position.x()), float(new_position.y()), float(new_position.z()), 1.0], out)
			local_pos = QVector3D(
				out[0] / out[3] if abs(out[3]) > 1e-9 else out[0],
				out[1] / out[3] if abs(out[3]) > 1e-9 else out[1],
				out[2] / out[3] if abs(out[3]) > 1e-9 else out[2]
			)
		else:
			local_pos = new_position
		
		# Update waypoint
		# Ensure waypoints are generated/available
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx < len(waypoints):
			waypoints[waypoint_idx].position = local_pos
			try:
				self._scene.events.entity_transform_changed.emit(self._current_entity_id)
			except Exception:
				pass
	
	def update_waypoint_rotation(self, new_rotation: QQuaternion) -> None:
		"""Update waypoint rotation (called during gizmo drag)."""
		if self._current_waypoint is None or self._current_entity_id is None:
			return
		
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			return
		
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		feature_idx, waypoint_idx = self._current_waypoint
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		
		# Get mesh actor for transform
		mesh_actor = self._scene_root.actor_for(self._current_entity_id)
		if mesh_actor is None:
			return
		
		# Account for the entity's world rotation: world = entity_world * local
		# so local = entity_world^-1 * world.
		local_rot = (world_rotation_quat(entity).inverted() * new_rotation).normalized()
		
		# Update waypoint
		mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
		global_offsets = {}
		waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
		
		if waypoint_idx < len(waypoints):
			waypoints[waypoint_idx].rotation = local_rot
			try:
				self._scene.events.entity_transform_changed.emit(self._current_entity_id)
			except Exception:
				pass


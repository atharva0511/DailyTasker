from __future__ import annotations

from typing import Optional

import vtk  # type: ignore
from PyQt6.QtGui import QVector3D

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QUndoStack
from MotionStudio.render.vtk.gizmo.utils import (
	basis_and_origin_from_vtk_actor,
	closest_axis_t,
	configure_overlay_3d_actor,
	local_position_from_world,
	overlay_renderer,
	pick_renderer,
	screen_ray,
	world_length_for_pixels,
	world_position,
	world_axis_dirs_local,
)
from MotionStudio.render.vtk.camera_view_sync import register_camera_view_sync
from MotionStudio.render.vtk.scene_root import VtkSceneRoot
from MotionStudio.core.undo.commands import PropertyChangeCommand


class VtkTranslateGizmo:
	"""
	Local-space translate gizmo with X/Y/Z handles.
	Left-click and drag a handle to move the selected entity along that local axis.
	"""

	def __init__(self, plotter, scene: Scene, selection: SelectionModel, scene_root: VtkSceneRoot, undo_stack: Optional[QUndoStack] = None) -> None:
		self._plotter = plotter
		self._scene = scene
		self._selection = selection
		self._scene_root = scene_root
		self._undo_stack = undo_stack

		self._iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if self._iren is None:
			raise RuntimeError("QtInteractor does not expose a VTK interactor (interactor/iren).")

		self._renderer = getattr(plotter, "renderer", None)
		if self._renderer is None:
			# Fallback to render-window renderer list
			rw = self._iren.GetRenderWindow()
			if rw is not None:
				renderers = rw.GetRenderers()
				self._renderer = renderers.GetFirstRenderer() if renderers is not None else None
		if self._renderer is None:
			raise RuntimeError("Could not resolve a VTK renderer for gizmo.")
		self._pick_renderer = pick_renderer(plotter, self._renderer)

		# Handle actors
		self._axis_actors: list[vtk.vtkActor] = []
		self._axis_dirs_local = [QVector3D(1, 0, 0), QVector3D(0, 1, 0), QVector3D(0, 0, 1)]
		self._axis_colors = [(0.86, 0.20, 0.20), (0.20, 0.86, 0.20), (0.20, 0.47, 0.94)]

		self._picker = vtk.vtkCellPicker()
		self._picker.PickFromListOn()
		self._picker.SetTolerance(0.002)

		self._active_axis: Optional[int] = None
		self._drag_entity: Optional[Entity] = None
		self._drag_axis_dir_world = QVector3D()
		self._drag_origin_world = QVector3D()
		self._drag_t0: float = 0.0
		self._drag_start_local_pos: Optional[QVector3D] = None
		self._enabled: bool = True
		self._external_pick_actors: list[vtk.vtkActor] = []

		self._build_actors()
		self._set_visible(False)

		# Selection + scene updates reposition the gizmo
		self._selection.current_entity_changed.connect(self._on_selection_changed)
		self._scene.events.entity_changed.connect(self._on_entity_changed)
		self._scene.events.entity_transform_changed.connect(self._on_entity_changed)  # Also listen to transform-only changes
		self._scene.events.entity_reparented.connect(self._on_entity_reparented)
		self._scene.events.entity_removed.connect(self._on_entity_removed)

		# Interactor observers (priority > picking bridge)
		self._iren.AddObserver("LeftButtonPressEvent", self._on_left_press, 1.0)
		self._iren.AddObserver("MouseMoveEvent", self._on_mouse_move, 1.0)
		self._iren.AddObserver("LeftButtonReleaseEvent", self._on_left_release, 1.0)
		# When the camera is interacting (orbit/pan/zoom), keep gizmo size constant on screen
		self._iren.AddObserver("InteractionEvent", self._on_camera_interaction, 0.0)
		# Wheel zoom doesn't always emit InteractionEvent; handle explicitly
		self._iren.AddObserver("MouseWheelForwardEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("MouseWheelBackwardEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("EndInteractionEvent", self._on_camera_interaction, 0.0)
		register_camera_view_sync(plotter, self.sync_screen_space_visuals)

	def _build_actors(self) -> None:
		# Simple arrow per axis in +X direction; we'll orient/position per selection
		for i in range(3):
			arrow = vtk.vtkArrowSource()
			arrow.SetTipLength(0.35)
			arrow.SetTipRadius(0.08)
			arrow.SetShaftRadius(0.03)

			mapper = vtk.vtkPolyDataMapper()
			mapper.SetInputConnection(arrow.GetOutputPort())

			actor = vtk.vtkActor()
			actor.SetMapper(mapper)
			actor.SetPickable(True)
			actor.GetProperty().SetColor(*self._axis_colors[i])
			configure_overlay_3d_actor(actor, opacity=0.5)

			self._axis_actors.append(actor)
			self._picker.AddPickList(actor)

			overlay = overlay_renderer(self._plotter)
			if overlay is not None:
				overlay.AddActor(actor)
			else:
				self._plotter.add_actor(actor, pickable=True, reset_camera=False)

	def pickable_actors(self) -> list[vtk.vtkActor]:
		"""Actors that should participate in depth-aware handle picking."""
		return list(self._axis_actors)

	def register_external_pick_actors(self, actors: list[vtk.vtkActor]) -> None:
		"""
		Add other gizmo actors to this picker's pick list so VTK can depth-resolve
		the top-most handle under the cursor.
		"""
		for actor in actors:
			if actor in self._external_pick_actors:
				continue
			self._external_pick_actors.append(actor)
			try:
				self._picker.AddPickList(actor)
			except Exception:
				pass

	def _set_visible(self, visible: bool) -> None:
		for a in self._axis_actors:
			a.SetVisibility(1 if visible else 0)

	def _reposition(self) -> None:
		ent = self._selection.current
		if ent is None:
			self._set_visible(False)
			return
		
		actor_mesh = self._scene_root.actor_for(ent.id)
		if actor_mesh is not None:
			# Anchor to rendered actor to prevent visual drift relative to mesh
			origin, (xw, yw, zw) = basis_and_origin_from_vtk_actor(actor_mesh)
		else:
			# Fallback for empty entities (Transform only)
			origin = world_position(ent)
			xw, yw, zw = world_axis_dirs_local(ent)

		axis_world = [xw, yw, zw]

		# Scale gizmo to a constant on-screen length (~180px)
		try:
			size = max(1e-4, world_length_for_pixels(self._renderer, origin, 180.0))
		except Exception:
			size = 1.0

		for i, axis_actor in enumerate(self._axis_actors):
			d = axis_world[i]
			# Build transform in a stable order so translation is NOT affected by scaling.
			# PostMultiply ensures final matrix = T * R * S (anchored at origin).
			t = vtk.vtkTransform()
			t.PostMultiply()
			t.Scale(size, size, size)

			# Default vtkArrowSource points along +X in its local space.
			# Rotate from +X to desired direction.
			base = QVector3D(1, 0, 0)
			axis = QVector3D.crossProduct(base, d)
			axis_len = axis.length()
			if axis_len > 1e-6:
				axis_n = axis / axis_len
				angle = float(QVector3D.dotProduct(base, d))
				# Clamp due to float errors, then angle = acos(dot)
				angle = max(-1.0, min(1.0, angle))
				import math
				deg = math.degrees(math.acos(angle))
				t.RotateWXYZ(deg, axis_n.x(), axis_n.y(), axis_n.z())
			elif QVector3D.dotProduct(base, d) < 0.0:
				t.RotateWXYZ(180.0, 0.0, 0.0, 1.0)

			# Translate last (not scaled)
			t.Translate(origin.x(), origin.y(), origin.z())
			
			# Use SetUserMatrix for the final update to be consistent and fast
			axis_actor.SetUserMatrix(t.GetMatrix())
			axis_actor.Modified()
			if axis_actor.GetMapper():
				axis_actor.GetMapper().Update()

	def _on_selection_changed(self, _entity: Optional[Entity]) -> None:
		self._reposition()
		self._set_visible(self._selection.current is not None)
		try:
			self._plotter.render()
		except Exception:
			pass

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._selection.current is not None and self._selection.current.id == entity_id:
			self._reposition()

	def _on_entity_reparented(self, child_id: str, _new_parent_id) -> None:
		if self._selection.current is not None and self._selection.current.id == child_id:
			self._reposition()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._selection.is_entity_id_selected(entity_id):
			self._selection.remove_entity_id(entity_id)
			self._set_visible(False)

	def set_enabled(self, enabled: bool) -> None:
		"""Enable or disable the gizmo. When disabled, it won't respond to interactions."""
		self._enabled = enabled
		if not enabled:
			# Cancel any active drag
			self._active_axis = None
			self._drag_entity = None

	def _on_left_press(self, obj, ev) -> None:
		# If disabled or no selection/gizmo hidden: do nothing
		if not self._enabled:
			return
		# Another gizmo may have already claimed this press.
		if self._selection.interaction_active and self._active_axis is None:
			return
		ent = self._selection.current
		if ent is None:
			return
		# If click hits gizmo handle, start drag and abort event so picker doesn't run
		x, y = self._iren.GetEventPosition()
		try:
			self._picker.Pick(x, y, 0, self._pick_renderer)
			actor = self._picker.GetActor()
		except Exception:
			return
		if actor is None:
			return
		try:
			axis_index = self._axis_actors.index(actor)
		except ValueError:
			return

		# Start drag
		self._active_axis = axis_index
		self._drag_entity = ent
		# Tell UI to defer expensive refreshes during interaction
		try:
			self._selection.set_interaction_active(True)
		except Exception:
			pass
		# Capture initial local pos for undo grouping
		tc0 = ent.get_component(TransformComponent)
		self._drag_start_local_pos = QVector3D(tc0.position) if tc0 is not None else None
		
		# Disable highlight during drag to prevent flicker
		self._scene_root.set_outline_enabled(False)

		actor_mesh = self._scene_root.actor_for(ent.id)
		if actor_mesh is not None:
			origin, (xw, yw, zw) = basis_and_origin_from_vtk_actor(actor_mesh)
		else:
			origin = world_position(ent)
			xw, yw, zw = world_axis_dirs_local(ent)

		self._drag_origin_world = origin
		self._drag_axis_dir_world = [xw, yw, zw][axis_index]

		ray = screen_ray(self._renderer, int(x), int(y))
		self._drag_t0 = closest_axis_t(ray, self._drag_origin_world, self._drag_axis_dir_world)

		# Abort event propagation (prevents scene picking and default behaviors)
		try:
			obj.AbortFlagOn()
		except Exception:
			pass

	def _on_mouse_move(self, obj, ev) -> None:
		if self._active_axis is None or self._drag_entity is None:
			return
		x, y = self._iren.GetEventPosition()
		ray = screen_ray(self._renderer, int(x), int(y))
		t = closest_axis_t(ray, self._drag_origin_world, self._drag_axis_dir_world)
		delta = float(t - self._drag_t0)
		new_world = self._drag_origin_world + (self._drag_axis_dir_world * delta)

		# Convert to parent-local and apply
		local_pos = local_position_from_world(self._drag_entity, new_world)
		tc = self._drag_entity.get_component(TransformComponent)
		if tc is not None:
			# Transform setter automatically emits entity_changed signal
			tc.position = local_pos

		# Keep gizmo positioned on entity while dragging
		self._reposition()
		
		# Explicitly trigger a render after all transforms (Mesh + Gizmo) are final
		try:
			self._plotter.render()
		except Exception:
			pass

		try:
			obj.AbortFlagOn()
		except Exception:
			pass

	def _on_left_release(self, obj, ev) -> None:
		if self._active_axis is None:
			return
		# End interaction (re-enable inspector rebuild)
		try:
			self._selection.set_interaction_active(False)
		except Exception:
			pass
		# Push a single undo command for the drag (merged continuous edits are handled by this single command)
		if (
			self._undo_stack is not None
			and self._drag_entity is not None
			and self._drag_start_local_pos is not None
			and getattr(self._drag_entity, "name", "") != "__waypoint_proxy__"
		):
			tc = self._drag_entity.get_component(TransformComponent)
			if tc is not None:
				old = QVector3D(self._drag_start_local_pos)
				new = QVector3D(tc.position)
				if old != new:
					self._undo_stack.push(
						PropertyChangeCommand(
							self._scene,
							self._drag_entity.id,
							getattr(tc, "type_name", tc.__class__.__name__),
							"position",
							old,
							new,
							text="Transform.position",
						)
					)

		self._active_axis = None
		self._drag_entity = None
		self._drag_start_local_pos = None
		
		# Abort event to prevent the PickerBridge from seeing this release event 
		# and potentially clearing selection.
		try:
			obj.AbortFlagOn()
		except Exception:
			pass

		# Re-enable highlight and sync it one last time
		self._scene_root.set_outline_enabled(True)
		if self._selection.current:
			self._scene_root._sync_transform(self._selection.current.id)

		try:
			obj.AbortFlagOn()
		except Exception:
			pass
		self._plotter.render()

	def sync_screen_space_visuals(self) -> None:
		if self._active_axis is not None:
			return
		if self._selection.current is None:
			return
		self._reposition()

	def _on_camera_interaction(self, obj, ev) -> None:
		self.sync_screen_space_visuals()



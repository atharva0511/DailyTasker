from __future__ import annotations

from dataclasses import dataclass

import vtk  # type: ignore
from PyQt6.QtGui import QVector3D

from MotionStudio.render.vtk.camera_view_sync import register_camera_view_sync
from MotionStudio.render.vtk.gizmo.utils import world_length_for_pixels

# World-space RGB line axes at (0, 0, 0); visible in every scene / project.
DEFAULT_ORIGIN_AXIS_PIXEL_LENGTH = 10000.0
DEFAULT_ORIGIN_AXIS_OPACITY = 0.1


@dataclass
class _OriginAxesState:
	plotter: object
	actor: vtk.vtkActor
	poly: vtk.vtkPolyData
	pixel_length: float
	opacity: float


def _renderer(plotter) -> vtk.vtkRenderer | None:
	try:
		return getattr(plotter, "renderer", None)
	except Exception:
		return None


def _world_axis_length(plotter, pixel_length: float) -> float:
	renderer = _renderer(plotter)
	if renderer is None:
		return max(1e-4, float(pixel_length) * 0.001)
	origin = QVector3D(0.0, 0.0, 0.0)
	return max(1e-4, float(world_length_for_pixels(renderer, origin, pixel_length)))


def _rebuild_axis_points(poly: vtk.vtkPolyData, length: float) -> None:
	pts = poly.GetPoints()
	if pts is None or pts.GetNumberOfPoints() < 4:
		return
	pts.SetPoint(1, float(length), 0.0, 0.0)
	pts.SetPoint(2, 0.0, float(length), 0.0)
	pts.SetPoint(3, 0.0, 0.0, float(length))
	pts.Modified()
	poly.Modified()


def origin_axes_actor(plotter) -> vtk.vtkActor | None:
	"""Return the world origin axes actor, if installed."""
	return getattr(plotter, "_pyengine_origin_axes_actor", None)


def update_world_origin_axes_scale(plotter, *, render: bool = True) -> None:
	"""Recompute world axis length so lines stay a fixed size on screen."""
	state: _OriginAxesState | None = getattr(plotter, "_pyengine_origin_axes", None)
	if state is None:
		return
	length = _world_axis_length(state.plotter, state.pixel_length)
	_rebuild_axis_points(state.poly, length)
	if render:
		try:
			state.plotter.render()
		except Exception:
			pass


def install_world_origin_axes(
	plotter,
	*,
	pixel_length: float = DEFAULT_ORIGIN_AXIS_PIXEL_LENGTH,
	opacity: float = DEFAULT_ORIGIN_AXIS_OPACITY,
) -> vtk.vtkActor:
	"""
	Add non-pickable X/Y/Z line axes at the world origin to the base renderer.
	Axis length is kept constant in screen space while the camera moves or zooms.
	"""
	length = _world_axis_length(plotter, pixel_length)

	pts = vtk.vtkPoints()
	lines = vtk.vtkCellArray()
	colors = vtk.vtkUnsignedCharArray()
	colors.SetName("Colors")
	colors.SetNumberOfComponents(3)

	origin_id = pts.InsertNextPoint(0.0, 0.0, 0.0)
	axis_ends = (
		(length, 0.0, 0.0, (255, 0, 0)),
		(0.0, length, 0.0, (0, 255, 0)),
		(0.0, 0.0, length, (0, 128, 255)),
	)
	for x, y, z, rgb in axis_ends:
		end_id = pts.InsertNextPoint(x, y, z)
		line = vtk.vtkLine()
		line.GetPointIds().SetId(0, origin_id)
		line.GetPointIds().SetId(1, end_id)
		lines.InsertNextCell(line)
		colors.InsertNextTuple3(rgb[0], rgb[1], rgb[2])

	poly = vtk.vtkPolyData()
	poly.SetPoints(pts)
	poly.SetLines(lines)
	poly.GetCellData().SetScalars(colors)

	mapper = vtk.vtkPolyDataMapper()
	mapper.SetInputData(poly)
	try:
		mapper.SetScalarModeToUseCellData()
		mapper.ScalarVisibilityOn()
		mapper.SetColorModeToDirectScalars()
	except Exception:
		pass

	actor = vtk.vtkActor()
	actor.SetMapper(mapper)
	actor.SetPickable(False)
	try:
		prop = actor.GetProperty()
		prop.SetLineWidth(5.0)
		prop.SetOpacity(float(opacity))
		prop.SetAmbient(1.0)
		prop.SetDiffuse(0.0)
		prop.SetSpecular(0.0)
		prop.SetLighting(False)
	except Exception:
		pass

	try:
		plotter.add_actor(actor, pickable=False, reset_camera=False)
	except Exception:
		plotter.add_actor(actor, pickable=False)

	state = _OriginAxesState(
		plotter=plotter,
		actor=actor,
		poly=poly,
		pixel_length=float(pixel_length),
		opacity=float(opacity),
	)
	plotter._pyengine_origin_axes = state  # type: ignore[attr-defined]
	plotter._pyengine_origin_axes_actor = actor  # type: ignore[attr-defined]

	def _on_camera_interaction(_obj, _ev) -> None:
		try:
			update_world_origin_axes_scale(plotter)
		except Exception:
			pass

	register_camera_view_sync(plotter, lambda: update_world_origin_axes_scale(plotter, render=False))

	iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
	if iren is not None:
		for ev in (
			"InteractionEvent",
			"MouseWheelForwardEvent",
			"MouseWheelBackwardEvent",
			"EndInteractionEvent",
		):
			try:
				iren.AddObserver(ev, _on_camera_interaction, 0.0)
			except Exception:
				pass

	return actor

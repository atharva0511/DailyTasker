from __future__ import annotations

import math
from typing import Optional, Tuple

import vtk  # type: ignore


class VtkCameraController:
	"""
	Custom camera controller (no reliance on VTK/PyVista default interactor bindings):
	- Right-drag: orbit (azimuth/elevation around focal point)
	- Middle-drag: pan
	- Wheel: zoom (dolly)
	- Left-drag: no-op (left click reserved for picking/gizmos)

	Observers are installed at low priority so gizmos/picking can AbortFlagOn() first.
	"""

	def __init__(self, plotter) -> None:
		self._plotter = plotter
		self._iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if self._iren is None:
			raise RuntimeError("QtInteractor does not expose a VTK interactor (interactor/iren).")

		self._renderer = getattr(plotter, "renderer", None)
		if self._renderer is None:
			rw = self._iren.GetRenderWindow()
			if rw is not None:
				renderers = rw.GetRenderers()
				self._renderer = renderers.GetFirstRenderer() if renderers is not None else None
		if self._renderer is None:
			raise RuntimeError("Could not resolve a VTK renderer for camera controller.")

		self._enabled: bool = True

		self._right_down: bool = False
		self._middle_down: bool = False
		self._last_xy: Optional[Tuple[int, int]] = None

		# Install a neutral style so VTK won't do anything on its own.
		try:
			style = vtk.vtkInteractorStyleUser()
			pv_iren = getattr(plotter, "iren", None)
			if pv_iren is not None and hasattr(pv_iren, "style"):
				pv_iren.style = style
			else:
				self._iren.SetInteractorStyle(style)
			plotter._pyengine_neutral_style = style  # type: ignore[attr-defined]
		except Exception:
			pass

		# Observers (low priority)
		self._iren.AddObserver("RightButtonPressEvent", self._on_right_press, 0.0)
		self._iren.AddObserver("RightButtonReleaseEvent", self._on_right_release, 0.0)
		self._iren.AddObserver("MiddleButtonPressEvent", self._on_middle_press, 0.0)
		self._iren.AddObserver("MiddleButtonReleaseEvent", self._on_middle_release, 0.0)
		self._iren.AddObserver("MouseMoveEvent", self._on_mouse_move, 0.0)
		self._iren.AddObserver("MouseWheelForwardEvent", self._on_wheel_forward, 0.0)
		self._iren.AddObserver("MouseWheelBackwardEvent", self._on_wheel_backward, 0.0)

		# Enforce Z-up consistently
		self._apply_z_up()

	def _apply_z_up(self) -> None:
		try:
			cam = self._camera()
			cam.SetViewUp(0.0, 0.0, 1.0)
			cam.OrthogonalizeViewUp()
		except Exception:
			pass

	def set_enabled(self, enabled: bool) -> None:
		self._enabled = bool(enabled)

	def _camera(self) -> vtk.vtkCamera:
		return self._renderer.GetActiveCamera()

	def _reset_clipping(self) -> None:
		try:
			self._renderer.ResetCameraClippingRange()
		except Exception:
			pass

	def _render(self) -> None:
		try:
			self._plotter.render()
		except Exception:
			pass

	def _event_xy(self) -> Optional[Tuple[int, int]]:
		try:
			x, y = self._iren.GetEventPosition()
			return int(x), int(y)
		except Exception:
			return None

	def _on_right_press(self, obj, ev) -> None:
		if not self._enabled:
			return
		self._right_down = True
		self._last_xy = self._event_xy()

	def _on_right_release(self, obj, ev) -> None:
		self._right_down = False
		self._last_xy = None

	def _on_middle_press(self, obj, ev) -> None:
		if not self._enabled:
			return
		self._middle_down = True
		self._last_xy = self._event_xy()

	def _on_middle_release(self, obj, ev) -> None:
		self._middle_down = False
		self._last_xy = None

	def _on_mouse_move(self, obj, ev) -> None:
		if not self._enabled:
			return
		if not (self._right_down or self._middle_down):
			return
		xy = self._event_xy()
		if xy is None or self._last_xy is None:
			self._last_xy = xy
			return

		x, y = xy
		lx, ly = self._last_xy
		dx = x - lx
		dy = y - ly
		self._last_xy = xy

		cam = self._camera()
		# Orbit
		if self._right_down:
			az = -dx * 0.25
			el = -dy * 0.25
			try:
				cam.Azimuth(az)
				cam.Elevation(el)
				self._apply_z_up()
			except Exception:
				pass
			self._reset_clipping()
			self._render()
			return

		# Pan (screen-space)
		if self._middle_down:
			try:
				# Pan by moving the focal point and camera position in world space.
				fx, fy, fz = cam.GetFocalPoint()
				# Project focal point to display to get its depth
				self._renderer.SetWorldPoint(fx, fy, fz, 1.0)
				self._renderer.WorldToDisplay()
				dd = self._renderer.GetDisplayPoint()
				depth = float(dd[2])

				# Convert (x,y) and (x+dx,y+dy) at that depth back into world points
				self._renderer.SetDisplayPoint(float(x), float(y), depth)
				self._renderer.DisplayToWorld()
				w1 = self._renderer.GetWorldPoint()
				self._renderer.SetDisplayPoint(float(x - dx), float(y - dy), depth)
				self._renderer.DisplayToWorld()
				w2 = self._renderer.GetWorldPoint()
				if abs(w1[3]) < 1e-9 or abs(w2[3]) < 1e-9:
					return
				p1 = (w1[0] / w1[3], w1[1] / w1[3], w1[2] / w1[3])
				p2 = (w2[0] / w2[3], w2[1] / w2[3], w2[2] / w2[3])
				# Delta is how much the world point under cursor shifted; apply to camera and focal
				tx = p2[0] - p1[0]
				ty = p2[1] - p1[1]
				tz = p2[2] - p1[2]

				cx, cy, cz = cam.GetPosition()
				cam.SetFocalPoint(fx + tx, fy + ty, fz + tz)
				cam.SetPosition(cx + tx, cy + ty, cz + tz)
			except Exception:
				return
			self._apply_z_up()
			self._reset_clipping()
			self._render()

	def _on_wheel_forward(self, obj, ev) -> None:
		if not self._enabled:
			return
		try:
			cam = self._camera()
			cam.Dolly(1.1)
			self._apply_z_up()
			self._reset_clipping()
			self._render()
		except Exception:
			return

	def _on_wheel_backward(self, obj, ev) -> None:
		if not self._enabled:
			return
		try:
			cam = self._camera()
			cam.Dolly(1.0 / 1.1)
			self._apply_z_up()
			self._reset_clipping()
			self._render()
		except Exception:
			return



from PyQt6.QtCore import Qt
from PyQt6.Qt3DCore import QEntity, QTransform
from PyQt6.Qt3DExtras import Qt3DWindow
from PyQt6.Qt3DRender import QDirectionalLight, QPickingSettings, QLayer, QRenderStateSet, QDepthTest, QLayerFilter, QCameraSelector
from PyQt6.QtGui import QColor, QVector3D
from PyQt6.QtWidgets import QWidget


def create_qt3d_container(parent: QWidget | None = None) -> tuple[QWidget, Qt3DWindow, QEntity, QLayer]:
	"""
	Create a Qt3D window embedded in a QWidget container suitable as a central widget.
	Returns (container_widget, qt3d_window, root_entity).
	"""
	view = Qt3DWindow()
	# Dark blue background
	view.defaultFrameGraph().setClearColor(QColor(2, 4, 8))

	root_entity = QEntity()
	view.setRootEntity(root_entity)

	camera = view.camera()  # type: ignore[attr-defined]
	camera.lens().setPerspectiveProjection(45.0, 16.0 / 9.0, 0.1, 1000.0)
	camera.setPosition(QVector3D(0.0, 3.0, 10.0))
	camera.setViewCenter(QVector3D(0.0, 0.0, 0.0))
	# Use Z-up convention
	camera.setUpVector(QVector3D(0.0, 0.0, 1.0))

	# Configure precise triangle picking
	try:
		picking = view.renderSettings().pickingSettings()  # type: ignore[attr-defined]
		picking.setPickMethod(QPickingSettings.PickMethod.TrianglePicking)
		picking.setPickResultMode(QPickingSettings.PickResultMode.NearestPick)
		picking.setFaceOrientationPickingMode(QPickingSettings.FaceOrientationPickingMode.FrontAndBackFace)
	except Exception:
		# If API differs or is unavailable, proceed with defaults
		pass

	# Prepare a dedicated layer for gizmos (to render on top via framegraph branch)
	gizmo_layer = QLayer(root_entity)

	# Framegraph overlay branch: render gizmos last with depth test disabled and no depth writes
	try:
		fg = view.defaultFrameGraph()  # type: ignore[attr-defined]
		# Use the same camera
		gizmo_cam_sel = QCameraSelector(fg)  # parented to fg to ensure it's evaluated
		gizmo_cam_sel.setCamera(camera)
		# Filter only gizmo layer
		layer_filter = QLayerFilter(gizmo_cam_sel)
		layer_filter.addLayer(gizmo_layer)
		# Disable depth testing and depth writes so gizmos are on top
		state_set = QRenderStateSet(layer_filter)
		depth_test = QDepthTest(state_set)
		depth_test.setDepthFunction(QDepthTest.DepthFunction.Always)
		# Depth mask disabling is not available in all PyQt6 builds; relying on Always depth test
	except Exception:
		# If framegraph manipulation isn't supported in this environment, gizmos will still be visible
		pass

	# Add a basic directional light so Phong materials are visible
	light_entity = QEntity(root_entity)
	light = QDirectionalLight(light_entity)
	light.setColor(QColor(255, 255, 255))
	light.setIntensity(1.0)
	light.setWorldDirection(QVector3D(-1.5, -1.0, -1.2))
	light_transform = QTransform(light_entity)
	light_transform.setTranslation(QVector3D(10.0, 10.0, 10.0))
	# Attach light components
	light_entity.addComponent(light)
	light_entity.addComponent(light_transform)

	# Soft ambient-like fill (simulated using a low-intensity directional light)
	fill_entity = QEntity(root_entity)
	fill_light = QDirectionalLight(fill_entity)
	fill_light.setColor(QColor(255,255,255))  # cool bluish tint
	fill_light.setIntensity(0.4)
	fill_light.setWorldDirection(QVector3D(0.3, 0.2, -1.0))  # opposite-ish direction
	fill_transform = QTransform(fill_entity)
	fill_transform.setTranslation(QVector3D(-5.0, -5.0, 8.0))
	fill_entity.addComponent(fill_light)
	fill_entity.addComponent(fill_transform)

	container = QWidget.createWindowContainer(view, parent)
	container.setMinimumSize(400, 300)
	container.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
	return container, view, root_entity, gizmo_layer



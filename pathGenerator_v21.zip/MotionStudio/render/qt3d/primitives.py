from PyQt6.Qt3DCore import QEntity
from PyQt6.Qt3DExtras import QCuboidMesh, QPlaneMesh, QSphereMesh
from PyQt6.QtGui import QColor, QVector3D

from MotionStudio.core.transform.transform_component import TransformComponent
from MotionStudio.render.qt3d.materials import make_color_material


def make_cube(parent: QEntity, size: float = 1.0, color: QColor | None = None) -> QEntity:
	entity = QEntity(parent)
	mesh = QCuboidMesh(entity)
	mesh.setXExtent(size)
	mesh.setYExtent(size)
	mesh.setZExtent(size)
	if color is None:
		color = QColor(200, 200, 200)
	material = make_color_material(entity, color)
	transform = TransformComponent()
	transform.scale3d = QVector3D(1.0, 1.0, 1.0)
	transform.qtransform.setParent(entity)
	# Attach components to the entity so they are active in the scene
	entity.addComponent(mesh)
	entity.addComponent(material)
	entity.addComponent(transform.qtransform)
	return entity


def make_plane(parent: QEntity, width: float = 10.0, height: float = 10.0, color: QColor | None = None) -> QEntity:
	entity = QEntity(parent)
	mesh = QPlaneMesh(entity)
	mesh.setWidth(width)
	mesh.setHeight(height)
	if color is None:
		color = QColor(80, 80, 80)
	material = make_color_material(entity, color)
	transform = TransformComponent()
	transform.qtransform.setParent(entity)
	entity.addComponent(mesh)
	entity.addComponent(material)
	entity.addComponent(transform.qtransform)
	return entity


def make_sphere(parent: QEntity, radius: float = 0.5, color: QColor | None = None, rings: int = 32, slices: int = 32) -> QEntity:
	entity = QEntity(parent)
	mesh = QSphereMesh(entity)
	mesh.setRadius(radius)
	mesh.setRings(rings)
	mesh.setSlices(slices)
	if color is None:
		color = QColor(200, 200, 200)
	material = make_color_material(entity, color)
	transform = TransformComponent()
	transform.qtransform.setParent(entity)
	entity.addComponent(mesh)
	entity.addComponent(material)
	entity.addComponent(transform.qtransform)
	return entity


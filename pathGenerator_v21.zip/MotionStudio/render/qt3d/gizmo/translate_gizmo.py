from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import QObject, QPointF, QSize, Qt
from PyQt6.Qt3DCore import QEntity, QTransform
from PyQt6.Qt3DExtras import QConeMesh, QCylinderMesh, QPhongMaterial
from PyQt6.Qt3DRender import QCamera, QObjectPicker, QPickEvent, QLayer
from PyQt6.QtGui import QColor, QVector2D, QVector3D, QWindow,QMatrix4x4

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.transform.transform_component import TransformComponent
from MotionStudio.render.qt3d.gizmo.utils import screen_ray, closest_axis_t
from MotionStudio.render.qt3d.scene_root import SceneRoot


class TranslateGizmo(QObject):
	def __init__(self, root: QEntity, camera: QCamera, window: QWindow, selection: SelectionModel, scene_root: SceneRoot, scene: Scene, gizmo_layer: QLayer | None = None) -> None:
		super().__init__(root)
		self._root = root
		self._camera = camera
		self._window = window
		self._selection = selection
		self._scene_root = scene_root
		self._scene = scene
		self._layer = gizmo_layer

		self._gizmo: QEntity = QEntity(self._root)
		self._gizmo.setObjectName("TranslateGizmo")
		self._gizmo_transform = QTransform(self._gizmo)
		self._gizmo.addComponent(self._gizmo_transform)
		self._gizmo.setEnabled(False)
		if self._layer is not None:
			self._gizmo.addComponent(self._layer)

		self._axis_dirs = [QVector3D(1, 0, 0), QVector3D(0, 1, 0), QVector3D(0, 0, 1)]
		self._axis_colors = [QColor(220, 60, 60), QColor(60, 220, 60), QColor(60, 120, 240)]
		self._axes: list[QEntity] = []
		for i in range(3):
			self._axes.append(self._make_axis(i, self._axis_dirs[i], self._axis_colors[i]))

		self._drag_axis: Optional[int] = None
		self._drag_t0: float = 0.0
		self._drag_origin_world = QVector3D()
		self._drag_entity: Optional[Entity] = None

		self._selection.current_entity_changed.connect(self._on_selection_changed)
		self._window.installEventFilter(self)
		self._dragging: bool = False
		# React to transform-affecting changes (e.g., inspector edits or reparent)
		self._scene.events.entity_changed.connect(self._on_entity_changed)
		self._scene.events.entity_reparented.connect(self._on_entity_reparented)

	def _make_axis(self, axis_index: int, direction: QVector3D, color: QColor) -> QEntity:
		entity = QEntity(self._gizmo)
		# Shaft
		shaft = QCylinderMesh(entity)
		shaft.setRadius(0.02)
		shaft.setLength(1.6)
		shaft.setRings(8)
		shaft.setSlices(16)
		# Arrow head on child entity so it can be offset to the shaft end
		cone_entity = QEntity(entity)
		cone = QConeMesh(cone_entity)
		cone.setTopRadius(0.0)
		cone.setBottomRadius(0.06)
		cone.setLength(0.4)
		cone.setRings(12)
		cone.setSlices(20)
		# Material
		mat = QPhongMaterial(entity)
		mat.setDiffuse(color)
		mat.setAmbient(color)
		# Transforms
		tr_shaft = QTransform(entity)
		tr_cone = QTransform(cone_entity)
		# Default meshes align along +Y; rotate parent axis entity to match X/Z.
		# Keep cone unrotated (inherits parent rotation), and always translate it along +Y.
		if direction == QVector3D(1, 0, 0):  # X axis
			tr_shaft.setRotationZ(-90.0)
			tr_cone.setTranslation(QVector3D(0, 1.6 * 0.5 + 0.4 * 0.5, 0))
		elif direction == QVector3D(0, 1, 0):  # Y axis
			tr_cone.setTranslation(QVector3D(0, 1.6 * 0.5 + 0.4 * 0.5, 0))
		else:  # Z axis
			tr_shaft.setRotationX(90.0)
			tr_cone.setTranslation(QVector3D(0, 1.6 * 0.5 + 0.4 * 0.5, 0))
		entity.addComponent(tr_shaft)
		entity.addComponent(mat)
		entity.addComponent(shaft)
		cone_entity.addComponent(tr_cone)
		cone_entity.addComponent(mat)
		cone_entity.addComponent(cone)
		# Picker
		picker = QObjectPicker(entity)
		picker.setHoverEnabled(True)
		picker.pressed.connect(lambda ev, axis_index=axis_index: self._on_axis_pressed(ev, axis_index))
		picker.moved.connect(self._on_axis_moved)
		picker.released.connect(self._on_axis_released)
		entity.addComponent(picker)
		return entity

	def _on_selection_changed(self, entity: Optional[Entity]) -> None:
		self._drag_axis = None
		self._drag_entity = None
		if entity is None:
			self._gizmo.setParent(self._root)
			self._gizmo.setEnabled(False)
			return
		# Always keep gizmo under root; apply selected entity's world matrix to follow
		world = self._world_matrix_from_ecs(entity)
		self._gizmo.setParent(self._root)
		self._gizmo_transform.setMatrix(world)
		self._gizmo.setEnabled(True)

	def _viewport_size(self) -> QSize:
		return self._window.size()

	def _reposition_to_selection(self) -> None:
		entity = self._selection.current
		if entity is None:
			self._gizmo.setEnabled(False)
			return
		# Keep under root; set full world matrix so it follows selection without parenting
		world = self._world_matrix_from_ecs(entity)
		self._gizmo.setParent(self._root)
		self._gizmo_transform.setMatrix(world)
		self._gizmo.setEnabled(True)

	def _on_entity_changed(self, entity_id: str) -> None:
		# If current selection changed transform, follow it
		if self._selection.current is not None and self._selection.current.id == entity_id:
			self._reposition_to_selection()

	def _on_entity_reparented(self, child_id: str, _new_parent_id) -> None:
		if self._selection.current is not None and self._selection.current.id == child_id:
			self._reposition_to_selection()

	def _on_axis_pressed(self, ev: QPickEvent, axis_index: int) -> None:
		if self._selection.current is None:
			return
		self._drag_axis = axis_index
		self._drag_entity = self._selection.current
		self._drag_origin_world = self._gizmo_transform.translation()
		mouse = QVector2D(ev.position())
		origin, ray = screen_ray(self._camera, self._viewport_size(), mouse)
		axis_dir_world = self._axis_dirs[axis_index]
		self._drag_t0 = closest_axis_t(origin, ray, self._drag_origin_world, axis_dir_world)
		self._dragging = True

	def _on_axis_moved(self, ev: QPickEvent) -> None:
		if self._drag_axis is None or self._drag_entity is None:
			return
		mouse = QVector2D(ev.position())
		origin, ray = screen_ray(self._camera, self._viewport_size(), mouse)
		axis_dir_world = self._axis_dirs[self._drag_axis]
		t = closest_axis_t(origin, ray, self._drag_origin_world, axis_dir_world)
		delta = (t - self._drag_t0)
		new_pos = self._drag_origin_world + (axis_dir_world * delta)
		# Apply to entity transform (local space assumption for v1 = world-parentless or aligned)
		tcomp = self._drag_entity.get_component(TransformComponent)
		if tcomp is not None:
			tcomp.position = new_pos
		self._gizmo_transform.setTranslation(new_pos)

	def _on_axis_released(self, ev: QPickEvent) -> None:
		self._drag_axis = None
		self._drag_entity = None
		self._dragging = False

	def eventFilter(self, watched, event):
		# Keep gizmo a constant on-screen size by scaling with camera distance
		if event.type() == event.Type.MouseMove or event.type() == event.Type.Wheel:
			try:
				if self._gizmo.isEnabled():
					scale = self._compute_camera_scaled_size()
					if scale is not None:
						self._gizmo_transform.setScale(scale)
			except RuntimeError:
				# Underlying C++ object might be deleted during scene teardown
				return False
		return super().eventFilter(watched, event)

	def _world_matrix_from_ecs(self, entity: Entity) -> QMatrix4x4:
		# Accumulate local transforms up to root
		stack = []
		curr: Optional[Entity] = entity
		while curr is not None:
			t = curr.get_component(TransformComponent)
			if t is not None:
				stack.append(t.qtransform.matrix())
			else:
				stack.append(QMatrix4x4())
			curr = curr.parent
		world = QMatrix4x4()
		for m in reversed(stack):
			world = world * m
		return world
	def _compute_camera_scaled_size(self) -> Optional[float]:
		try:
			ent = self._selection.current
			if ent is None:
				return None
			ent_world = self._world_matrix_from_ecs(ent)
			ent_pos = QVector3D(ent_world.column(3).toVector3D())
			sx = QVector3D(ent_world.column(0).toVector3D()).length()
			sy = QVector3D(ent_world.column(1).toVector3D()).length()
			sz = QVector3D(ent_world.column(2).toVector3D()).length()
			parent_scale = max(1e-6, max(sx, sy, sz))
			dist = (self._camera.position() - ent_pos).length()
			k = 0.1
			# return max(0.1, min(10.0, (dist * k) / parent_scale))
			return (dist * k) / parent_scale
		except Exception:
			return None

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._selection.current is not None and self._selection.current.id == entity_id:
			self._gizmo.setParent(self._root)
			self._gizmo.setEnabled(False)
			try:
				self._selection.set_current(None)
			except Exception:
				pass



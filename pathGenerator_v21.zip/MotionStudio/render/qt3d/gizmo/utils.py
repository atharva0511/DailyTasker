from __future__ import annotations

from typing import Tuple

from PyQt6.Qt3DRender import QCamera
from PyQt6.QtGui import QMatrix4x4, QVector2D, QVector3D, QVector4D
from PyQt6.QtCore import QSize


def screen_ray(camera: QCamera, viewport_size: QSize, mouse_pos: QVector2D) -> Tuple[QVector3D, QVector3D]:
	"""
	Compute world-space ray (origin, direction) from screen coordinates.
	"""
	x = (2.0 * mouse_pos.x() / max(1, viewport_size.width())) - 1.0
	y = 1.0 - (2.0 * mouse_pos.y() / max(1, viewport_size.height()))
	ndc_near = QVector4D(x, y, -1.0, 1.0)
	ndc_far = QVector4D(x, y, 1.0, 1.0)
	pv = camera.projectionMatrix() * camera.viewMatrix()
	inv_pv = QMatrix4x4(pv)
	inv_pv = inv_pv.inverted()[0]
	world_near = inv_pv * ndc_near
	world_far = inv_pv * ndc_far
	if world_near.w() != 0.0:
		world_near /= world_near.w()
	if world_far.w() != 0.0:
		world_far /= world_far.w()
	origin = QVector3D(world_near.x(), world_near.y(), world_near.z())
	dir_vec = QVector3D(world_far.x() - world_near.x(), world_far.y() - world_near.y(), world_far.z() - world_near.z())
	dir_len = dir_vec.length()
	if dir_len != 0.0:
		dir_vec /= dir_len
	return origin, dir_vec


def closest_axis_t(origin_ray: QVector3D, dir_ray: QVector3D, axis_origin: QVector3D, axis_dir: QVector3D) -> float:
	"""
	Compute parameter t along axis line P = axis_origin + t * axis_dir
	that minimizes distance to the ray line R = origin_ray + s * dir_ray.
	"""
	w0 = axis_origin - origin_ray
	a = QVector3D.dotProduct(axis_dir, axis_dir)
	b = QVector3D.dotProduct(axis_dir, dir_ray)
	c = QVector3D.dotProduct(dir_ray, dir_ray)
	d = QVector3D.dotProduct(axis_dir, w0)
	e = QVector3D.dotProduct(dir_ray, w0)
	den = (a * c) - (b * b)
	if abs(den) < 1e-6:
		return 0.0
	t = (b * e - c * d) / den
	return t



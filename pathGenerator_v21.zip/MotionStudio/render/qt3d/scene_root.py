from __future__ import annotations

from typing import Dict, Optional

from PyQt6.Qt3DCore import QEntity
from PyQt6.Qt3DCore import QTransform
from PyQt6.Qt3DRender import QObjectPicker, QMesh
from PyQt6.QtGui import QMatrix3x3, QMatrix4x4, QVector3D, QVector4D, QQuaternion, QColor
from PyQt6.QtCore import QUrl

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.transform.transform_component import TransformComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.render.qt3d.primitives import make_cube, make_sphere
from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read


class SceneRoot:
	"""
	Mirrors the ECS Scene hierarchy into a Qt3D entity tree under the view's root entity.
	"""

	def __init__(self, root_entity: QEntity, scene: Scene, selection: Optional[SelectionModel] = None) -> None:
		self._scene = scene
		self._root_entity: QEntity = root_entity
		self._selection = selection

		self._id_to_qentity: Dict[str, QEntity] = {}
		self._transform_connected: set[str] = set()
		self._loading: bool = False
		# Selection shader swap removed; no special tracking needed.

		# Initial population (if any)
		for ent in scene.root_entities():
			self._create_qentity_recursive(ent)

		# Wire scene events
		scene.events.entity_added.connect(self._on_entity_added)
		scene.events.entity_removed.connect(self._on_entity_removed)
		scene.events.entity_reparented.connect(self._on_entity_reparented)
		scene.events.entity_changed.connect(self._on_entity_changed)

	def qentity_for(self, entity_id: str) -> Optional[QEntity]:
		return self._id_to_qentity.get(entity_id)

	def set_loading(self, is_loading: bool) -> None:
		"""
		When True, reparent operations won't attempt to preserve world transforms.
		Useful during bulk deserialization where local matrices are already correct.
		"""
		self._loading = is_loading

	# --- Scene event handlers ---
	def _on_entity_added(self, entity: Entity) -> None:
		self._create_qentity_recursive(entity)
		self._sync_mesh(entity.id)
		self._ensure_transform_attached(entity.id)

	def _on_entity_removed(self, entity_id: str) -> None:
		self._remove_mesh_visual(entity_id)
		qent = self._id_to_qentity.pop(entity_id, None)
		if qent is not None:
			qent.setParent(None)  # let Qt delete hierarchy

	def _on_entity_reparented(self, child_id: str, new_parent_id: str | None) -> None:
		qchild = self._id_to_qentity.get(child_id)
		if qchild is None:
			return
		# During loading, respect serialized local transform; don't adjust to preserve world
		if self._loading:
			if new_parent_id is None:
				qchild.setParent(self._root_entity)
			else:
				qparent = self._id_to_qentity.get(new_parent_id)
				if qparent is not None:
					qchild.setParent(qparent)
			return
		# Normal mode: preserve world transform
		old_world = self._compute_world_matrix(qchild)
		if new_parent_id is None:
			qchild.setParent(self._root_entity)
			parent_world = QMatrix4x4()
		else:
			qparent = self._id_to_qentity.get(new_parent_id)
			if qparent is not None:
				qchild.setParent(qparent)
			parent_world = self._compute_world_matrix(qparent) if qparent is not None else QMatrix4x4()
		inv_parent = parent_world.inverted()[0]
		new_local = inv_parent * old_world
		entity = self._scene.find_by_id(child_id)
		if entity is not None:
			t = entity.get_component(TransformComponent)
			if t is None:
				t = TransformComponent()
				entity.add_component(t)
				t.qtransform.setParent(qchild)
				qchild.addComponent(t.qtransform)
			t.qtransform.setMatrix(new_local)
			# Ensure change signals re-emit scene changes
			self._connect_transform_signals(child_id, t.qtransform)

	def _on_entity_changed(self, entity_id: str) -> None:
		self._sync_mesh(entity_id)
		self._ensure_transform_attached(entity_id)

	# --- Helpers ---
	def _create_qentity_recursive(self, entity: Entity, qparent: QEntity | None = None) -> QEntity:
		qent_parent = qparent or (self._id_to_qentity.get(entity.parent.id) if entity.parent else self._root_entity)
		qent = QEntity(qent_parent)
		self._id_to_qentity[entity.id] = qent

		# Attach existing TransformComponent (shares the same QTransform instance)
		transform_comp = entity.get_component(TransformComponent)
		if transform_comp is not None:
			transform_comp.qtransform.setParent(qent)
			qent.addComponent(transform_comp.qtransform)
			self._connect_transform_signals(entity.id, transform_comp.qtransform)

		for child in entity.children:
			self._create_qentity_recursive(child, qent)
			self._sync_mesh(child.id)
			self._ensure_transform_attached(child.id)
		return qent

	def _entity_qtransform(self, qent: Optional[QEntity]):
		if qent is None:
			return None
		for comp in qent.components():
			if isinstance(comp, QTransform):
				return comp
		return None

	def _compute_world_matrix(self, qent: Optional[QEntity]) -> QMatrix4x4:
		m = QMatrix4x4()
		if qent is None:
			return m
		stack = []
		curr = qent
		while curr is not None:
			t = self._entity_qtransform(curr)
			if t is not None:
				stack.append(t.matrix())
			curr = curr.parent() if isinstance(curr.parent(), QEntity) else None
		for local in reversed(stack):
			m = m * local
		return m

	# Matrix decomposition no longer needed due to setMatrix

	# --- Mesh syncing ---
	def _mesh_container(self, entity_id: str) -> Optional[QEntity]:
		qent = self._id_to_qentity.get(entity_id)
		return qent

	def _remove_mesh_visual(self, entity_id: str) -> None:
		qent = self._id_to_qentity.get(entity_id)
		if qent is None:
			return
		# Remove any child tagged as visual (we tag by objectName)
		for child in list(qent.children()):
			if isinstance(child, QEntity) and child.objectName() == "MeshVisual":
				child.setParent(None)

	def _sync_mesh(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return
		qparent = self._mesh_container(entity_id)
		if qparent is None:
			return
		mesh = entity.get_component(MeshComponent)
		# Clear previous visual
		self._remove_mesh_visual(entity_id)
		if mesh is None:
			return
		# Build new visual according to shape
		vis: Optional[QEntity] = None
		if mesh.shape == "cube":
			vis = make_cube(qparent, size=1.0, color=mesh.color)
		elif mesh.shape == "sphere":
			vis = make_sphere(qparent, radius=0.5, color=mesh.color)
		elif mesh.shape == "custom":
			if mesh.custom_path:
				vis = QEntity(qparent)
				qmesh = QMesh(vis)
				try:
					abs_path = resolve_mesh_path_for_read(
						self._scene.project_root,
						mesh.custom_path,
					)
					qmesh.setSource(QUrl.fromLocalFile(abs_path))
				except Exception:
					vis = None
				if vis is not None:
					from PyQt6.Qt3DExtras import QPhongMaterial
					mat = QPhongMaterial(vis)
					mat.setDiffuse(mesh.color if isinstance(mesh.color, QColor) else QColor(200, 200, 200))
					# IMPORTANT: Do NOT reattach the ECS TransformComponent's QTransform here.
					# The visual inherits the parent's transform; attaching the same QTransform
					# to multiple entities causes ownership errors and deletions.
					vis.addComponent(qmesh)
					vis.addComponent(mat)
		if vis is not None:
			vis.setObjectName("MeshVisual")
			# Add picker for selection
			try:
				picker = QObjectPicker(vis)
				picker.setHoverEnabled(True)
				def _on_clicked(_ev, eid=entity_id):
					if self._selection is not None:
						ent = self._scene.find_by_id(eid)
						self._selection.set_current(ent)
				picker.clicked.connect(_on_clicked)
				vis.addComponent(picker)
			except Exception:
				pass
			# Selection shader swap removed; no tracking of visuals required.

	# --- Transform attach ---
	def _ensure_transform_attached(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return
		qent = self._id_to_qentity.get(entity_id)
		if qent is None:
			return
		# If a QTransform is already present, nothing to do
		if self._entity_qtransform(qent) is not None:
			return
		# If ECS has a TransformComponent, attach its QTransform
		t = entity.get_component(TransformComponent)
		if t is not None:
			t.qtransform.setParent(qent)
			qent.addComponent(t.qtransform)
			self._connect_transform_signals(entity.id, t.qtransform)

	# Selection shader swap logic removed.
	def _connect_transform_signals(self, entity_id: str, qtransform: QTransform) -> None:
		# Avoid duplicate connections per entity
		if entity_id in self._transform_connected:
			return
		self._transform_connected.add(entity_id)
		# Emit scene change whenever transform properties change
		try:
			qtransform.translationChanged.connect(lambda *_: self._scene.events.entity_changed.emit(entity_id))
		except Exception:
			pass
		try:
			qtransform.rotationChanged.connect(lambda *_: self._scene.events.entity_changed.emit(entity_id))
		except Exception:
			pass
		try:
			qtransform.scale3DChanged.connect(lambda *_: self._scene.events.entity_changed.emit(entity_id))
		except Exception:
			pass


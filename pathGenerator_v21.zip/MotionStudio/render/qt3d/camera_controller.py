from __future__ import annotations

import math
from typing import Optional, Tuple

from PyQt6.Qt3DRender import QCamera
from PyQt6.QtCore import QObject, QPoint, Qt, QEvent
from PyQt6.QtGui import QVector3D, QWheelEvent, QMouseEvent
from PyQt6.QtWidgets import QWidget
from PyQt6.QtGui import QWindow


class CameraController(QObject):
	"""
	Z-up camera controller with spherical (azimuth/elevation) orbit, pan, and zoom.
	Controls (unchanged):
	- Right Mouse Drag: Orbit
	- Middle Mouse Drag: Pan
	- Mouse Wheel: Zoom
	"""

	def __init__(self, camera: QCamera, event_widget: QWidget, window: QWindow | None = None) -> None:
		super().__init__(event_widget)
		self._camera = camera
		self._widget = event_widget
		self._widget.installEventFilter(self)
		self._window = window
		if self._window is not None:
			self._window.installEventFilter(self)
		self._enabled: bool = True
		self._orbiting: bool = False
		self._panning: bool = False
		self._last_pos: Optional[QPoint] = None
		# Spherical parameters (Z-up)
		self._azimuth_deg: float = 45.0
		self._elevation_deg: float = 20.0
		self._distance: float = 10.0
		# Initialize from camera
		self._sync_from_camera()

	def _sync_from_camera(self) -> None:
		center = self._camera.viewCenter()
		pos = self._camera.position()
		offset = pos - center
		self._distance = max(0.1, math.sqrt(offset.x() ** 2 + offset.y() ** 2 + offset.z() ** 2))
		if self._distance > 0.0:
			self._azimuth_deg = math.degrees(math.atan2(offset.y(), offset.x()))
			self._elevation_deg = math.degrees(math.asin(offset.z() / self._distance))

	def _update_camera_from_spherical(self) -> None:
		center = self._camera.viewCenter()
		az = math.radians(self._azimuth_deg)
		el = math.radians(self._elevation_deg)
		x = self._distance * math.cos(el) * math.cos(az)
		y = self._distance * math.cos(el) * math.sin(az)
		z = self._distance * math.sin(el)
		self._camera.setPosition(QVector3D(center.x() + x, center.y() + y, center.z() + z))
		self._camera.setUpVector(QVector3D(0.0, 0.0, 1.0))

	def _pan(self, dx: float, dy: float) -> None:
		center = self._camera.viewCenter()
		pos = self._camera.position()
		# Right vector from azimuth (projected on XY plane), Z-up
		az = math.radians(self._azimuth_deg)
		right = QVector3D(-math.sin(az), math.cos(az), 0.0)
		up = QVector3D(0.0, 0.0, 1.0)
		# Scale pan by distance
		scale = self._distance * 0.0015
		translation = (-right * dx * scale) + (up * dy * scale)
		self._camera.setViewCenter(center + translation)
		self._camera.setPosition(pos + translation)

	def eventFilter(self, watched: QObject, event: QEvent) -> bool:
		if not self._enabled:
			return super().eventFilter(watched, event)
		if watched not in (self._widget, self._window):
			return super().eventFilter(watched, event)

		if isinstance(event, QMouseEvent):
			if event.type() == QEvent.Type.MouseButtonPress:
				if event.button() == Qt.MouseButton.RightButton:
					self._orbiting = True
					self._last_pos = event.position().toPoint()
					return True
				if event.button() == Qt.MouseButton.MiddleButton:
					self._panning = True
					self._last_pos = event.position().toPoint()
					return True
			elif event.type() == QEvent.Type.MouseMove:
				if self._orbiting and self._last_pos is not None:
					pos = event.position().toPoint()
					delta = pos - self._last_pos
					self._last_pos = pos
					self._azimuth_deg -= delta.x() * 0.25
					self._elevation_deg += delta.y() * 0.25
					self._elevation_deg = max(-89.9, min(89.9, self._elevation_deg))
					self._update_camera_from_spherical()
					return True
				if self._panning and self._last_pos is not None:
					pos = event.position().toPoint()
					delta = pos - self._last_pos
					self._last_pos = pos
					self._pan(delta.x(), delta.y())
					return True
			elif event.type() == QEvent.Type.MouseButtonRelease:
				if event.button() == Qt.MouseButton.RightButton:
					self._orbiting = False
					self._last_pos = None
					return True
				if event.button() == Qt.MouseButton.MiddleButton:
					self._panning = False
					self._last_pos = None
					return True
		elif isinstance(event, QWheelEvent):
			# Zoom
			angle = event.angleDelta().y() / 8.0  # degrees
			steps = angle / 15.0
			self._distance *= math.pow(0.9, steps)
			self._distance = max(0.1, min(10000.0, self._distance))
			self._update_camera_from_spherical()
			return True

		return super().eventFilter(watched, event)

	def set_enabled(self, enabled: bool) -> None:
		self._enabled = enabled



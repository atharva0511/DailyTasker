from __future__ import annotations

from PyQt6.Qt3DRender import QEffect, QTechnique, QRenderPass, QShaderProgram, QFilterKey, QParameter, QDepthTest
try:
	from PyQt6.Qt3DRender import QPolygonMode  # not available in some PyQt6 builds
	_HAS_POLY = True
except Exception:
	_HAS_POLY = False
from PyQt6.Qt3DRender import QCullFace,QMaterial
from PyQt6.QtGui import QColor
from PyQt6.QtCore import QUrl, QByteArray
from pathlib import Path


class SelectedOverlayMaterial(QMaterial):
	def __init__(self, parent=None, base_color: QColor | None = None):
		super().__init__(parent)
		self._base_color = base_color or QColor(200, 200, 200)

		effect = QEffect(self)

		# Technique
		technique = QTechnique(effect)

		def _src(local_name: str) -> QByteArray:
			# Prefer filesystem path to avoid Qt error logs about missing qrc files
			base_path = Path(__file__).resolve().parents[3] / "resources" / "shaders" / local_name
			if base_path.exists():
				try:
					data = base_path.read_text(encoding="utf-8")
					return QByteArray(data.encode("utf-8"))
				except Exception:
					pass
			# Fallback to qrc if available
			return QShaderProgram.loadSource(QUrl(f"qrc:/shaders/{local_name}"))

		# Base pass (solid color from baseColor)
		base_pass = QRenderPass(technique)
		base_prog = QShaderProgram(base_pass)
		base_prog.setVertexShaderCode(_src("selected_base.vert"))
		base_prog.setFragmentShaderCode(_src("selected_base.frag"))
		base_pass.setShaderProgram(base_prog)
		# Base color parameter
		param = QParameter("baseColor", self._base_color)
		effect.addParameter(param)

		if _HAS_POLY:
			# Wireframe pass (neon green lines) if available
			wire_pass = QRenderPass(technique)
			wire_prog = QShaderProgram(wire_pass)
			wire_prog.setVertexShaderCode(_src("selected_base.vert"))
			wire_prog.setFragmentShaderCode(_src("wire_frag.frag"))
			wire_pass.setShaderProgram(wire_prog)
			poly = QPolygonMode(wire_pass)
			poly.setMode(QPolygonMode.PolygonMode.Line)
			dt = QDepthTest(wire_pass)
			dt.setDepthFunction(QDepthTest.DepthFunction.LessOrEqual)
			technique.addRenderPass(base_pass)
			technique.addRenderPass(wire_pass)
		else:
			# Fallback outline pass: render back faces slightly expanded along normal in shader
			outline_pass = QRenderPass(technique)
			outline_prog = QShaderProgram(outline_pass)
			outline_prog.setVertexShaderCode(_src("outline.vert"))
			outline_prog.setFragmentShaderCode(_src("wire_frag.frag"))
			outline_pass.setShaderProgram(outline_prog)
			# Cull front faces so only back faces form an outline
			cull = QCullFace(outline_pass)
			cull.setMode(QCullFace.CullingMode.Front)
			dt = QDepthTest(outline_pass)
			dt.setDepthFunction(QDepthTest.DepthFunction.LessOrEqual)
			# Outline thickness param
			effect.addParameter(QParameter("outlineWidth", 0.01))
			technique.addRenderPass(base_pass)
			technique.addRenderPass(outline_pass)

		effect.addTechnique(technique)
		self.setEffect(effect)

	def setBaseColor(self, color: QColor) -> None:
		self._base_color = color
		for p in self.parameters():
			if p.name() == "baseColor":
				p.setValue(color)
				break



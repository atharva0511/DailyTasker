from __future__ import annotations

from typing import Iterable, Sequence, Union, List, Tuple
import struct

from PyQt6.Qt3DCore import QEntity, QGeometry, QAttribute, QBuffer
from PyQt6.Qt3DRender import QGeometryRenderer
from PyQt6.Qt3DExtras import QPhongMaterial
from PyQt6.QtGui import QVector3D, QColor
from PyQt6.QtCore import QByteArray

PointLike = Union[QVector3D, Sequence[float], Tuple[float, float, float], List[float]]

def _ensure_qcolor(color: QColor | Tuple) -> QColor:
	if isinstance(color, QColor):
		return color
	if len(color) == 3:
		return QColor(int(color[0]), int(color[1]), int(color[2]))
	return QColor(int(color[0]), int(color[1]), int(color[2]), int(color[3]))

def draw_line_strip(parent: QEntity, points: Iterable[PointLike], color: QColor | Tuple) -> QEntity:
	"""
	Creates a connected polyline.
	"""
	point_list = []
	for p in points:
		if isinstance(p, QVector3D):
			point_list.append(p)
		else:
			point_list.append(QVector3D(float(p[0]), float(p[1]), float(p[2])))

	if len(point_list) < 2:
		return QEntity(parent)

	# 1. Create the Entity first
	line_entity = QEntity(parent)

	# 2. Prepare Vertex Data
	vertex_data = QByteArray()
	for v in point_list:
		# Use QByteArray.append for reliable binary data handling in PyQt6
		vertex_data.append(struct.pack("fff", v.x(), v.y(), v.z()))

	# 3. Create Geometry then Buffer (Explicitly parented to geometry)
	geometry = QGeometry(line_entity)
	pos_buffer = QBuffer()
	pos_buffer.setData(vertex_data)
	
	# 4. Configure Attribute
	position_attr = QAttribute(geometry)
	position_attr.setName(QAttribute.defaultPositionAttributeName())
	position_attr.setVertexBaseType(QAttribute.VertexBaseType.Float)
	position_attr.setVertexSize(3)
	position_attr.setAttributeType(QAttribute.AttributeType.VertexAttribute)
	position_attr.setBuffer(pos_buffer)
	position_attr.setByteStride(3 * 4)
	position_attr.setCount(len(point_list))
	
	geometry.addAttribute(position_attr)
	# Provide dummy normals to satisfy standard material input layout
	normals = QByteArray()
	for _ in point_list:
		normals.append(struct.pack("fff", 0.0, 0.0, 1.0))
	norm_buffer = QBuffer()
	norm_buffer.setData(normals)
	normal_attr = QAttribute(geometry)
	normal_attr.setName(QAttribute.defaultNormalAttributeName())
	normal_attr.setVertexBaseType(QAttribute.VertexBaseType.Float)
	normal_attr.setVertexSize(3)
	normal_attr.setAttributeType(QAttribute.AttributeType.VertexAttribute)
	normal_attr.setBuffer(norm_buffer)
	normal_attr.setByteStride(3 * 4)
	normal_attr.setCount(len(point_list))
	geometry.addAttribute(normal_attr)

	# 5. Renderer setup
	renderer = QGeometryRenderer(line_entity)
	renderer.setGeometry(geometry)
	renderer.setPrimitiveType(QGeometryRenderer.PrimitiveType.LineStrip)

	# 6. Material setup
	col = _ensure_qcolor(color)
	material = QPhongMaterial(line_entity)
	material.setAmbient(col)
	material.setDiffuse(col)

	# 7. Final assembly
	line_entity.addComponent(renderer)
	line_entity.addComponent(material)
	
	return line_entity

def draw_line(parent: QEntity, start: QVector3D, end: QVector3D, color: QColor | Tuple[int, int, int, int] | Tuple[int, int, int]) -> QEntity:
	line_entity = QEntity(parent)
	geometry = QGeometry(line_entity)

	# Vertex data
	vertex_data = QByteArray()

	for point in [start, end]:
		vertex_data += struct.pack('fff', point.x(), point.y(), point.z())

	vertex_buffer = QBuffer()
	vertex_buffer.setData(vertex_data)

	position_attribute = QAttribute(geometry)
	position_attribute.setName(QAttribute.defaultPositionAttributeName())

	position_attribute.setAttributeType(QAttribute.AttributeType.VertexAttribute)
	position_attribute.setVertexBaseType(QAttribute.VertexBaseType.Float)
	position_attribute.setVertexSize(3)
	position_attribute.setBuffer(vertex_buffer)
	position_attribute.setByteStride(3 * 4)
	position_attribute.setCount(2)

	geometry.addAttribute(position_attribute)
	# Dummy normals
	normals2 = QByteArray()
	normals2 += struct.pack('fff', 0.0, 0.0, 1.0)
	normals2 += struct.pack('fff', 0.0, 0.0, 1.0)
	norm_buffer2 = QBuffer()
	norm_buffer2.setData(normals2)
	normal_attr2 = QAttribute(geometry)
	normal_attr2.setName(QAttribute.defaultNormalAttributeName())
	normal_attr2.setAttributeType(QAttribute.AttributeType.VertexAttribute)
	normal_attr2.setVertexBaseType(QAttribute.VertexBaseType.Float)
	normal_attr2.setVertexSize(3)
	normal_attr2.setBuffer(norm_buffer2)
	normal_attr2.setByteStride(3 * 4)
	normal_attr2.setCount(2)
	geometry.addAttribute(normal_attr2)

	# Renderer
	renderer = QGeometryRenderer()
	renderer.setGeometry(geometry)
	renderer.setPrimitiveType(QGeometryRenderer.PrimitiveType.Lines)

	# Material
	material = QPhongMaterial()
	material.setAmbient(color)
	material.setDiffuse(color)

	line_entity.addComponent(renderer)
	line_entity.addComponent(material)
	return line_entity
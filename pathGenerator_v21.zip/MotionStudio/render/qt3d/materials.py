from PyQt6.Qt3DCore import QEntity
from PyQt6.Qt3DExtras import QPhongMaterial
from PyQt6.QtGui import QColor


def make_color_material(parent: QEntity, color: QColor) -> QPhongMaterial:
	material = QPhongMaterial(parent)
	material.setDiffuse(color)
	return material



from __future__ import annotations

import shutil
import json
from pathlib import Path
from typing import Optional, Tuple
from xml.etree import ElementTree


def _copy_into_models(models_dir: Path, source: Path) -> Path:
	"""Copy a source file into models_dir with collision-safe naming."""
	models_dir.mkdir(parents=True, exist_ok=True)
	dest = models_dir / source.name
	stem, suffix = source.stem, source.suffix
	n = 1
	while dest.exists():
		dest = models_dir / f"{stem}_{n}{suffix}"
		n += 1
	shutil.copy2(source, dest)
	return dest


def load_trimesh_scene(source: Path):
	try:
		import trimesh  # type: ignore
	except Exception as exc:
		raise OSError(
			"Mesh import requires trimesh. Install dependencies: "
			"'pip install trimesh pycollada'."
		) from exc
	return trimesh.load(str(source), force="scene")


def _scale_factor_for_unit_source(unit_source: Path) -> float:
	"""Resolve metres → mm scale using Collada metadata (DAE) or URDF mesh conventions."""
	if unit_source.suffix.lower() == ".dae":
		return _dae_scale_to_millimeters(unit_source)
	return mesh_scale_to_millimeters(unit_source)


def convert_scene_to_glb(
	import_dir: Path,
	scene,
	unit_source: Path,
	*,
	output_stem: Optional[str] = None,
) -> Path:
	"""
	Scale a trimesh scene to engine mm, export GLB, and write material sidecar.

	``unit_source`` supplies file metadata (Collada unit tag for DAE, etc.).
	"""
	import_dir.mkdir(parents=True, exist_ok=True)
	stem = output_stem or unit_source.stem
	dest = import_dir / f"{stem}.glb"
	n = 1
	while dest.exists():
		dest = import_dir / f"{stem}_{n}.glb"
		n += 1

	scale_to_mm = _scale_factor_for_unit_source(unit_source)
	if abs(scale_to_mm - 1.0) > 1e-9:
		scene.apply_scale(scale_to_mm)
	glb_data = scene.export(file_type="glb")
	_write_glb_material_sidecar(dest, scene)

	if isinstance(glb_data, (bytes, bytearray)):
		dest.write_bytes(glb_data)
	else:
		try:
			dest.write_bytes(bytes(glb_data))
		except Exception as exc:
			raise OSError(f"Unexpected GLB export payload for: {unit_source}") from exc
	return dest


def _convert_dae_to_glb(models_dir: Path, source: Path) -> Path:
	"""Convert a .dae mesh to .glb for runtime compatibility."""
	scene = load_trimesh_scene(source)
	return convert_scene_to_glb(models_dir, scene, source)


def _write_glb_material_sidecar(dest_glb: Path, scene) -> None:
	"""
	Persist diffuse colors from source geometry order for renderer-side restore.
	"""
	colors: list[list[float]] = []
	try:
		geometry_values = list(scene.geometry.values())
	except Exception:
		geometry_values = []

	for geom in geometry_values:
		rgb = [0.78, 0.78, 0.78]
		try:
			material = getattr(getattr(geom, "visual", None), "material", None)
			main_color = getattr(material, "main_color", None)
			if main_color is not None and len(main_color) >= 3:
				rgb = [
					float(main_color[0]) / 255.0,
					float(main_color[1]) / 255.0,
					float(main_color[2]) / 255.0,
				]
		except Exception:
			pass
		colors.append(rgb)

	if not colors:
		return

	sidecar = dest_glb.with_suffix(dest_glb.suffix + ".materials.json")
	payload = {
		"version": 1,
		"diffuse_colors_rgb": colors,
	}
	try:
		sidecar.write_text(json.dumps(payload, indent=2), encoding="utf-8")
	except Exception:
		# Best-effort metadata; conversion should still succeed without sidecar.
		pass


def mesh_scale_to_millimeters(source: Path) -> float:
	"""
	Return a uniform scale factor to convert mesh file coordinates to engine mm.

	- ``.dae``: reads Collada ``<unit meter="...">`` (default 1 m per unit → ×1000).
	- ``.stl`` / ``.obj`` / ``.ply``: URDF ROS packages use metres → ×1000.
	- ``.glb`` / ``.gltf``: assumed already normalized when produced by this pipeline.
	"""
	suffix = source.suffix.lower()
	if suffix == ".dae":
		return _dae_scale_to_millimeters(source)
	if suffix in (".stl", ".obj", ".ply"):
		return 1000.0
	if suffix in (".glb", ".gltf"):
		return 1.0
	return 1000.0


def _dae_scale_to_millimeters(source: Path) -> float:
	"""
	Read Collada unit metadata and return scale factor to convert coordinates to mm.

	Collada <asset><unit meter="x"/> means 1 file-unit = x meters.
	Engine convention is 1 unit = 1 mm.
	"""
	try:
		tree = ElementTree.parse(source)
		root = tree.getroot()
	except Exception:
		return 1.0

	# Namespace-safe search: use local-name matching by suffix.
	asset_node = None
	for node in root.iter():
		if node.tag.endswith("asset"):
			asset_node = node
			break
	if asset_node is None:
		return 1.0

	unit_node = None
	for node in asset_node:
		if node.tag.endswith("unit"):
			unit_node = node
			break
	if unit_node is None:
		# Collada default when unit is omitted is meter.
		meter_per_unit = 1.0
	else:
		try:
			meter_per_unit = float(unit_node.attrib.get("meter", "1.0"))
		except (TypeError, ValueError):
			meter_per_unit = 1.0

	# Convert file-units to millimeters.
	return meter_per_unit * 1000.0


def import_mesh_into_project(
	project_root: Path,
	source_path: str,
	*,
	import_dir: Optional[Path] = None,
) -> str:
	"""
	Ensure a mesh path is stored relative to the project root.

	If the file already lives under ``project_root``, returns a posix relative path.
	If the file is outside the project folder, copies it into ``<project>/models/``
	(with a numeric suffix if the name collides) and returns ``models/<name>``.

	Raises FileNotFoundError if the source file cannot be resolved or does not exist.
	Raises OSError if copying fails.
	"""
	root = project_root.resolve()
	raw = Path(source_path.strip())
	if not raw.parts:
		return ""

	if raw.is_absolute():
		source = raw.expanduser().resolve()
	else:
		proj_candidate = (root / raw).resolve()
		if proj_candidate.is_file():
			source = proj_candidate
		else:
			cwd_candidate = (Path.cwd() / raw).resolve()
			source = cwd_candidate if cwd_candidate.is_file() else proj_candidate

	if not source.is_file():
		raise FileNotFoundError(f"Mesh file not found: {source_path}")

	out_dir = import_dir if import_dir is not None else root / "models"
	out_dir.mkdir(parents=True, exist_ok=True)

	# Normalize DAE to GLB so runtime loading has a deterministic path.
	if source.suffix.lower() == ".dae":
		dest = _convert_dae_to_glb(out_dir, source)
		return dest.relative_to(root).as_posix()

	try:
		rel = source.relative_to(root)
		return rel.as_posix()
	except ValueError:
		dest = _copy_into_models(out_dir, source)
		return dest.relative_to(root).as_posix()


def resolve_mesh_path_for_read(project_root: Optional[Path], stored_path: str) -> str:
	"""
	Resolve a mesh path from serialized component data to an absolute path for file I/O.

	- Empty string stays empty.
	- Already absolute paths are returned as-is (legacy scenes).
	- Relative paths are joined with ``project_root`` when set; otherwise resolved from cwd.
	"""
	if not stored_path or not str(stored_path).strip():
		return ""
	p = Path(stored_path.strip())
	if p.is_absolute():
		return str(p)
	if project_root is not None:
		return str((project_root / p).resolve())
	return str(p.resolve())


def has_source_material_sidecar(project_root: Optional[Path], stored_path: str) -> bool:
	"""Return True when a mesh has generated source-material metadata."""
	abs_path = resolve_mesh_path_for_read(project_root, stored_path)
	if not abs_path:
		return False
	p = Path(abs_path)
	if p.suffix.lower() not in (".glb", ".gltf"):
		return False
	sidecar = p.with_suffix(p.suffix + ".materials.json")
	return sidecar.is_file()

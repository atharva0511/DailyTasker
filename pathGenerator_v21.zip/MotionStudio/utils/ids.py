import uuid


def generate_uuid() -> str:
	"""
	Generate a unique ID string for entities.
	"""
	return str(uuid.uuid4())



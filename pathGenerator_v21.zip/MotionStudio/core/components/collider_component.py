from __future__ import annotations

from typing import Annotated

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import FilePath, Group, Hidden, Order, Range, Tooltip


@register_component
class ColliderComponent(Component):
	"""
	Marks an entity participant in the scene-wide collision system.

	Entities with this component are paired n(n-1)/2 by the scene's CollisionSystem
	(self-pairs excluded). Pair checks can be enabled/disabled through the Collision
	Matrix UI or via ``scene.collision_system.matrix``.

	The transient ``collided`` flag is owned by this component (rather than the
	mesh) so that pure collision state is separated from rendering data. The
	system always updates ``collided`` to reflect real collision state and emits
	``scene.events.entity_collision_changed`` whenever it flips, so custom
	components can react regardless of how the entity is rendered.

	``repaint_on_collision`` is consumed only by the renderer: it toggles the
	red mesh overlay on/off without affecting ``collided`` or the signal.

	``collider_from_mesh_component`` controls collision source geometry:
	- True: use MeshComponent geometry (default)
	- False: use ``collider_mesh_path`` geometry

	``scale`` applies a uniform multiplier to collider source geometry before
	collision checks and collider wireframe visualization.
	"""

	type_name = "Collider"

	collider_from_mesh_component: Annotated[
		bool,
		Tooltip("Use MeshComponent geometry for collision checks. Disable to use Collider Mesh Path instead."),
	] = True
	collider_mesh_path: Annotated[
		str,
		Group("Collider Settings"),
		FilePath("Mesh Files (*.stl *.obj *.fbx *.dae *.gltf *.glb *.ply *.vtk *.vtp);;All Files (*.*)"),
		Tooltip("Collision mesh path. Used only when 'Collider from Mesh component' is disabled."),
	] = ""
	render_collider: Annotated[
		bool,
		Group("Collider Settings"),
		Tooltip("Render the collider geometry in the 3D view when this entity is selected."),
	] = True
	scale: Annotated[
		float,
		Group("Collider Settings"),
		Range(0.001, 1000.0, step=0.01, decimals=3),
		Tooltip("Uniform scale applied to collider source geometry."),
	] = 1.0
	repaint_on_collision: Annotated[
		bool,
		Tooltip("Renderer-only hint: when true, the mesh is tinted red while colliding. Does not affect the runtime `collided` flag."),
		Group("Collider Settings"),
		Order(0),
	] = True
	use_collision_group: Annotated[
		bool,
		Group("Collision Group"),
		Tooltip(
			"When enabled, this collider is managed as part of a named group in the Physics window "
			"(one global row for the group; per-link pairs in the group sub-matrix)."
		),
	] = False
	collision_group_name: Annotated[
		str,
		Group("Collision Group"),
		Tooltip(
			"Shared group key for global and internal collision matrix toggles. "
			"Required when Use Collision Group is enabled."
		),
	] = ""
	collided: Annotated[
		bool,
		Tooltip("Runtime flag set by the CollisionSystem while the entity is intersecting another collider. Always reflects real state, independent of repaint_on_collision."),
		Hidden(),
	] = False

	def __init__(
		self,
		collider_from_mesh_component: bool = True,
		collider_mesh_path: str = "",
		render_collider: bool = True,
		scale: float = 1.0,
		repaint_on_collision: bool = True,
		use_collision_group: bool = False,
		collision_group_name: str = "",
	) -> None:
		self.collider_from_mesh_component = bool(collider_from_mesh_component)
		self.collider_mesh_path = str(collider_mesh_path or "")
		self.render_collider = bool(render_collider)
		self.use_collision_group = bool(use_collision_group)
		self.collision_group_name = str(collision_group_name or "")
		try:
			scale_val = float(scale)
		except Exception:
			scale_val = 1.0
		# Keep collider geometry valid for VTK pipelines; non-positive scale is nonsensical here.
		self.scale = scale_val if scale_val > 0.0 else 1.0
		self.repaint_on_collision = repaint_on_collision
		# Runtime state; never persisted to .scn (Hidden() also keeps it out of UI).
		self.collided = False

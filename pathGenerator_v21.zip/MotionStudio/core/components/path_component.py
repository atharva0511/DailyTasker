from __future__ import annotations
from typing import List, Dict, Any, Tuple, Optional
from PyQt6.QtGui import QVector3D, QQuaternion, QMatrix4x4
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.matrix import qmatrix_from_prs
from .feature import Feature, get_feature_class

@register_component
class PathComponent(Component):
    """
    Component that stores path generation data as an ordered list of segments.
    """
    type_name = "PathGeneration"

    def __init__(self):
        super().__init__()
        self.segments: List[Feature] = []
        # URScript export defaults (m/s, m/s^2, blend radius in metres)
        self.speed: float = 0.25
        self.acceleration: float = 1.2
        self.default_cnt_radius: float = 0.0

    @property
    def features(self) -> List[Feature]:
        """Backward-compatible alias for ``segments``."""
        return self.segments

    @features.setter
    def features(self, value: List[Feature]) -> None:
        self.segments = value

    def to_dict(self) -> Dict[str, Any]:
        # Component.to_dict handles primitives (floats)
        data = super().to_dict()
        data["segments"] = [
            {"type": s.__class__.__name__, "data": s.to_dict()}
            for s in self.segments
        ]
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> PathComponent:
        # Component.from_dict handles primitives (floats)
        inst = super().from_dict(data)

        segments_data = data.get("segments", data.get("features", []))
        inst.segments = []
        for entry in segments_data:
            s_type_name = entry.get("type")
            s_data = entry.get("data", {})
            s_cls = get_feature_class(s_type_name)
            if s_cls:
                inst.segments.append(s_cls.from_dict(s_data))

        return inst
    
    def get_world_waypoint_transforms(self) -> List[Tuple[float, float, float, float, float, float]]:
        """
        Returns a flat list of waypoint transforms in world space (every
        waypoint from every segment, in segment order).

        Each waypoint is represented as [x, y, z, rx, ry, rz] where:
        - x, y, z: position in world space (millimetres, engine units)
        - rx, ry, rz: rotation in degrees (Euler angles XYZ) in world space

        Raises:
            RuntimeError: If this component is not attached to an entity.
        """
        return [wp for seg in self.get_world_waypoints_by_segment() for wp in seg]

    def get_world_waypoints_by_segment(
        self,
    ) -> List[List[Tuple[float, float, float, float, float, float]]]:
        """
        Returns waypoint transforms in world space, grouped by segment.

        Each outer list element corresponds to one segment in declaration
        order; each inner list contains that segment's waypoints as
        ``(x, y, z, rx, ry, rz)`` tuples. Positions are in engine units
        (millimetres); rotations are XYZ Euler angles in degrees.

        Raises:
            RuntimeError: If this component is not attached to an entity.
        """
        if self.entity is None:
            raise RuntimeError("PathComponent must be attached to an entity to get world transforms")

        world_matrix = self._get_world_matrix()
        # Accumulated rotation through the hierarchy (scale stripped).
        world_rot_quat = self._extract_rotation_from_matrix(world_matrix)

        grouped: List[List[Tuple[float, float, float, float, float, float]]] = []
        for segment in self.segments:
            feat_waypoints: List[Tuple[float, float, float, float, float, float]] = []
            for waypoint in segment.waypoints:
                world_pos = world_matrix.map(waypoint.position)
                # world_rot * waypoint_rot: apply hierarchy rotation first,
                # then the waypoint's local rotation.
                combined_rot_quat = world_rot_quat * waypoint.rotation
                euler = combined_rot_quat.toEulerAngles()
                feat_waypoints.append((
                    float(world_pos.x()),
                    float(world_pos.y()),
                    float(world_pos.z()),
                    float(euler.x()),
                    float(euler.y()),
                    float(euler.z()),
                ))
            grouped.append(feat_waypoints)
        return grouped

    def get_world_waypoints_by_feature(
        self,
    ) -> List[List[Tuple[float, float, float, float, float, float]]]:
        """Backward-compatible alias for :meth:`get_world_waypoints_by_segment`."""
        return self.get_world_waypoints_by_segment()
    
    def _get_world_matrix(self) -> QMatrix4x4:
        """
        Computes the world transform matrix for this component's entity by accumulating
        transforms up the hierarchy.
        """
        if self.entity is None:
            return QMatrix4x4()
        
        stack: List[QMatrix4x4] = []
        curr = self.entity
        
        while curr is not None:
            t = curr.get_component(TransformComponent)
            if t is None:
                stack.append(QMatrix4x4())
            else:
                stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
            curr = curr.parent
        
        world = QMatrix4x4()
        for m in reversed(stack):
            world = world * m
        
        return world
    
    def _extract_rotation_from_matrix(self, matrix: QMatrix4x4) -> QQuaternion:
        """
        Extracts the rotation quaternion from a 4x4 transform matrix.
        Uses normalMatrix() which automatically removes scale and returns a 3x3 rotation matrix.
        """
        # normalMatrix() returns the upper-left 3x3 rotation matrix (scale removed)
        rot_matrix_3x3 = matrix.normalMatrix()
        return QQuaternion.fromRotationMatrix(rot_matrix_3x3)


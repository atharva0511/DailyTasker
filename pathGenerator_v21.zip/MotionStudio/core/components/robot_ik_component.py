from __future__ import annotations

from typing import Annotated, Literal, Optional

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Range, Tooltip, inspector_button


@register_component
class RobotIKComponent(Component):
	"""Inverse-kinematics driver attached to a robot root entity.

	Tracks a target ``TransformComponent`` and, whenever the target (or the
	robot base) moves, solves 6D pose IK on a background thread and writes the
	result onto the sibling ``RobotDescription``'s joint angles. The actual
	solving and threading live in ``RobotIKSystem``; this component only holds
	user-facing configuration plus a one-shot debug button.
	"""

	type_name = "RobotIK"

	enabled: Annotated[bool, Tooltip("Master toggle for IK tracking")] = True

	target: Annotated[
		Optional[TransformComponent],
		Tooltip("Target transform the end-effector should track (entity picker)"),
	] = None

	tcp: Annotated[
		Optional[TransformComponent],
		Tooltip(
			"Optional custom Tool Control Point. Pick an entity (usually a child "
			"of the tool-link entity) whose transform marks the real tool tip. "
			"IK drives THIS point to the target. Leave empty to use the URDF "
			"tool_link directly."
		),
	] = None

	backend: Annotated[
		Literal["ikpy", "pinocchio"],
		Tooltip(
			"IK solver backend. 'ikpy' is pure-Python (installs via pip on all "
			"platforms); 'pinocchio' is faster but conda-only on Windows. "
			"Extensible to 'curobo' later."
		),
		Group("IK Settings"),
	] = "ikpy"

	solve_hz: Annotated[
		float,
		Range(1.0, 120.0, step=1.0, decimals=0),
		Tooltip("Maximum solve rate while dragging the target"),
		Group("IK Settings"),
	] = 20.0

	position_tolerance_m: Annotated[
		float,
		Range(1e-5, 0.1, step=1e-4, decimals=5),
		Tooltip("Position success threshold in metres"),
		Group("IK Settings"),
	] = 1e-3

	orientation_tolerance_rad: Annotated[
		float,
		Range(1e-4, 1.0, step=1e-3, decimals=4),
		Tooltip("Orientation success threshold in radians"),
		Group("IK Settings"),
	] = 1e-2

	max_iterations: Annotated[
		int,
		Range(1, 1000, step=1),
		Tooltip("Maximum solver iterations per solve"),
		Group("IK Settings"),
	] = 100

	def __init__(self) -> None:
		self.enabled = True
		self.target = None
		self.tcp = None
		self.backend = "ikpy"
		self.solve_hz = 20.0
		self.position_tolerance_m = 1e-3
		self.orientation_tolerance_rad = 1e-2
		self.max_iterations = 100

	def _robot_ik_system(self):
		entity = self.entity
		if entity is None:
			return None
		scene = getattr(entity, "_scene", None)
		if scene is None:
			return None
		return getattr(scene, "robot_ik_system", None)

	@inspector_button("Solve IK Now", tooltip="Run one synchronous solve toward the target")
	def solve_ik_now(self) -> None:
		system = self._robot_ik_system()
		if system is None:
			print("Solve IK Now: no IK system on scene.", flush=True)
			return
		request = system.build_request(self)
		if request is None:
			print("Solve IK Now: target/robot not configured.", flush=True)
			return
		from MotionStudio.core.robot.ik.robot_ik_system import make_ik_backend

		backend = make_ik_backend(str(self.backend))
		if not backend.is_available():
			print(
				f"Solve IK Now: backend '{self.backend}' is not installed. "
				"See requirements-robot.txt.",
				flush=True,
			)
			return
		result = backend.solve(request)
		if not result.joint_values:
			print(f"Solve IK Now: failed ({result.message}).", flush=True)
			return
		system.apply_solution(request.robot_entity_id, result.joint_values)
		if self.entity is not None and self.entity._scene is not None:
			self.entity._scene.events.entity_changed.emit(self.entity.id)
		status = "converged" if result.success else f"applied (not converged: {result.message})"
		print(f"Solve IK Now: {status}.", flush=True)

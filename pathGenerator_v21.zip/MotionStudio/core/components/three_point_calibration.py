"""
Three-point calibration component.

The user picks three vertices on the entity's mesh ("model points", stored in
the entity's local frame via :class:`VertexPick`), then types in the three
corresponding **robot / physical** coordinates. The ``Align`` button computes
the least-squares rigid transformation (rotation + translation, preserving
scale) that best maps the model points to the robot points and re-poses the
entity so the model points sit on top of the robot points.

This is the classic 3-point part-to-robot calibration used in robotic
machining/inspection workflows.

Algorithm
---------

For the three model points :math:`P_i` (entity-local) and three robot points
:math:`Q_i` (world / robot frame) we want the *new* entity world matrix
:math:`M_{new}` such that :math:`M_{new} P_i \\approx Q_i` for ``i = 1..3``.

We express the new transform as a delta applied on top of the current world
transform :math:`M_{cur}`:

.. math:: M_{new} = D \\cdot M_{cur}

Working in world space:

1. Compute the current world positions of the model points:
   :math:`p_i = M_{cur} P_i` (using :func:`transform_point`).
2. Solve Kabsch / Umeyama between :math:`(p_i, Q_i)` for the rigid delta
   :math:`D = (R_\\Delta, t_\\Delta)` minimising :math:`\\sum \\lVert R_\\Delta p_i + t_\\Delta - Q_i \\rVert^2`.
3. New world rotation: :math:`R_\\Delta \\cdot R_{cur}`. New world position:
   :math:`R_\\Delta \\cdot \\mathrm{pos}_{cur} + t_\\Delta`.
4. Push via :func:`set_world_rotation_quat` and :func:`set_world_position` —
   these route through the public :class:`TransformComponent` properties, so
   the viewport and any other listeners refresh automatically and the
   entity's existing scale is preserved.
"""

from __future__ import annotations

from typing import Annotated, List, Tuple

import numpy as np
from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.utils import transform_point
from PyQt6.QtGui import QColor
from MotionStudio.core.debug import Debug
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	transform_point,
	world_position,
	world_rotation_quat,
)
from MotionStudio.ui.inspector.metadata import (
	Header,
	Tooltip,
	VertexPick,
	inspector_button,
)


@register_component
class ThreePointCalibrationComponent(Component):
	type_name = "ThreePointCalibration"

	model_a: Annotated[QVector3D, VertexPick(), Header("Model points (pick a mesh vertex)"), Tooltip("Pick the first reference vertex on the model")]
	model_b: Annotated[QVector3D, VertexPick(), Tooltip("Pick the second reference vertex on the model")]
	model_c: Annotated[QVector3D, VertexPick(), Tooltip("Pick the third reference vertex on the model")]

	robot_a: Annotated[QVector3D, Header("Robot coordinates (type physical position)"), Tooltip("Robot/world coordinate measured at the first reference point")]
	robot_b: Annotated[QVector3D, Tooltip("Robot/world coordinate measured at the second reference point")]
	robot_c: Annotated[QVector3D, Tooltip("Robot/world coordinate measured at the third reference point")]

	def __init__(self) -> None:
		self.model_a = QVector3D()
		self.model_b = QVector3D()
		self.model_c = QVector3D()
		self.robot_a = QVector3D()
		self.robot_b = QVector3D()
		self.robot_c = QVector3D()

	# ------------------------------------------------------------------
	# Inspector actions
	# ------------------------------------------------------------------

	def on_viewport_draw(self) -> None:
		selection = self.entity.scene.selection
		if selection is None:
			return
		if selection.current is not self.entity:
			return
		
		model_a_world = transform_point(self.entity, self.model_a)
		model_b_world = transform_point(self.entity, self.model_b)
		model_c_world = transform_point(self.entity, self.model_c)
		Debug.draw_point(model_a_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9)
		Debug.draw_point(model_b_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9)
		Debug.draw_point(model_c_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9)
		Debug.draw_label(model_a_world + QVector3D(0, 0.12, 0), "P1", color=QColor(255, 200, 200), font_size=14)
		Debug.draw_label(model_b_world + QVector3D(0, 0.12, 0), "P2", color=QColor(255, 200, 200), font_size=14)
		Debug.draw_label(model_c_world + QVector3D(0, 0.12, 0), "P3", color=QColor(255, 200, 200), font_size=14)

	@inspector_button(
		"Align",
		tooltip="Compute the least-squares rigid transform mapping the 3 model "
		"points onto the 3 robot points and apply it to this entity",
		order=0,
	)
	def align(self) -> None:
		if self.entity is None:
			print("ThreePointCalibration: no entity attached.", flush=True)
			return
		if self.entity.get_component(TransformComponent) is None:
			print("ThreePointCalibration: entity has no TransformComponent.", flush=True)
			return

		model_pts_local = [self.model_a, self.model_b, self.model_c]
		robot_pts_world = [self.robot_a, self.robot_b, self.robot_c]

		if not self._validate_inputs(model_pts_local, robot_pts_world):
			return

		# Step 1: bring the model points into the entity's *current* world frame.
		model_world = [transform_point(self.entity, p) for p in model_pts_local]

		# Step 2: rigid Kabsch in world space.
		ok, R, t, rmse = _kabsch_rigid(model_world, robot_pts_world)
		if not ok:
			print(
				"ThreePointCalibration: degenerate input (points colinear or coincident); cannot solve.",
				flush=True,
			)
			return

		# Step 3: compose the delta with the current world pose.
		R_delta = _matrix_to_quaternion(R)
		t_delta = QVector3D(float(t[0]), float(t[1]), float(t[2]))

		cur_pos = world_position(self.entity)
		cur_rot = world_rotation_quat(self.entity)
		new_pos = R_delta.rotatedVector(cur_pos) + t_delta
		new_rot = (R_delta * cur_rot).normalized()

		# Step 4: write back (scale preserved by these setters).
		set_world_rotation_quat(self.entity, new_rot)
		set_world_position(self.entity, new_pos)

		print(
			f"ThreePointCalibration: aligned '{self.entity.name}' "
			f"(RMSE = {rmse:.6g} world units).",
			flush=True,
		)

	@inspector_button(
		"Clear",
		tooltip="Reset model and robot coordinates to zero",
		order=1,
	)
	def clear(self) -> None:
		self.model_a = QVector3D()
		self.model_b = QVector3D()
		self.model_c = QVector3D()
		self.robot_a = QVector3D()
		self.robot_b = QVector3D()
		self.robot_c = QVector3D()

	# ------------------------------------------------------------------
	# Validation
	# ------------------------------------------------------------------

	@staticmethod
	def _validate_inputs(model: List[QVector3D], robot: List[QVector3D]) -> bool:
		eps = 1e-9
		# All three model points must be distinct; same for robot points.
		for label, pts in (("model", model), ("robot", robot)):
			if (pts[0] - pts[1]).lengthSquared() < eps or (pts[1] - pts[2]).lengthSquared() < eps or (pts[0] - pts[2]).lengthSquared() < eps:
				print(
					f"ThreePointCalibration: two {label} points coincide; "
					"pick three distinct points and try again.",
					flush=True,
				)
				return False
		return True


# ----------------------------------------------------------------------
# Math helpers (kept at module scope so they remain testable)
# ----------------------------------------------------------------------

def _kabsch_rigid(
	src: List[QVector3D],
	dst: List[QVector3D],
) -> Tuple[bool, np.ndarray, np.ndarray, float]:
	"""
	Kabsch / Umeyama rigid alignment (no scale).

	Returns ``(ok, R, t, rmse)`` such that ``R @ src_i + t  ≈  dst_i`` minimises
	the sum of squared residuals. ``R`` is a 3×3 rotation (det = +1), ``t`` is a
	length-3 translation. ``ok`` is False if the input is degenerate.
	"""
	P = np.array([[p.x(), p.y(), p.z()] for p in src], dtype=np.float64)  # 3x3
	Q = np.array([[q.x(), q.y(), q.z()] for q in dst], dtype=np.float64)  # 3x3
	cp = P.mean(axis=0)
	cq = Q.mean(axis=0)
	Pc = P - cp
	Qc = Q - cq

	# Reject configurations where the source points are colinear (spans < 2D)
	# — those leave the rotation about the line undetermined.
	if np.linalg.matrix_rank(Pc, tol=1e-8) < 2 or np.linalg.matrix_rank(Qc, tol=1e-8) < 2:
		return False, np.eye(3), np.zeros(3), float("inf")

	H = Pc.T @ Qc  # 3x3 cross-covariance
	try:
		U, _S, Vt = np.linalg.svd(H)
	except np.linalg.LinAlgError:
		return False, np.eye(3), np.zeros(3), float("inf")

	# Correct for reflection so det(R) = +1 (proper rotation).
	d = np.sign(np.linalg.det(Vt.T @ U.T))
	D = np.diag([1.0, 1.0, d if d != 0 else 1.0])
	R = Vt.T @ D @ U.T

	t = cq - R @ cp
	residual = (P @ R.T + t) - Q
	rmse = float(np.sqrt((residual ** 2).sum(axis=1).mean()))
	return True, R, t, rmse


def _matrix_to_quaternion(R: np.ndarray) -> QQuaternion:
	"""Convert a 3×3 rotation matrix to a unit :class:`QQuaternion`.

	Uses Shepperd's method (the largest-trace branch) for numerical stability.
	"""
	m00, m01, m02 = float(R[0, 0]), float(R[0, 1]), float(R[0, 2])
	m10, m11, m12 = float(R[1, 0]), float(R[1, 1]), float(R[1, 2])
	m20, m21, m22 = float(R[2, 0]), float(R[2, 1]), float(R[2, 2])
	trace = m00 + m11 + m22
	if trace > 0.0:
		s = 0.5 / float(np.sqrt(trace + 1.0))
		w = 0.25 / s
		x = (m21 - m12) * s
		y = (m02 - m20) * s
		z = (m10 - m01) * s
	elif m00 > m11 and m00 > m22:
		s = 2.0 * float(np.sqrt(1.0 + m00 - m11 - m22))
		w = (m21 - m12) / s
		x = 0.25 * s
		y = (m01 + m10) / s
		z = (m02 + m20) / s
	elif m11 > m22:
		s = 2.0 * float(np.sqrt(1.0 + m11 - m00 - m22))
		w = (m02 - m20) / s
		x = (m01 + m10) / s
		y = 0.25 * s
		z = (m12 + m21) / s
	else:
		s = 2.0 * float(np.sqrt(1.0 + m22 - m00 - m11))
		w = (m10 - m01) / s
		x = (m02 + m20) / s
		y = (m12 + m21) / s
		z = 0.25 * s
	q = QQuaternion(float(w), float(x), float(y), float(z))
	return q.normalized()

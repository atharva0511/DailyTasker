from __future__ import annotations
from typing import Annotated, Dict, List, Literal, Optional
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import *
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from PyQt6.QtGui import QVector3D, QColor
from MotionStudio.core.debug import Debug

@register_component
class TestComponent(Component):
    type_name = "Test"

    example_bool: Annotated[bool,Tooltip("A boolean value (checkbox)"),Order(1)] = True

    example_float: Annotated[float,Tooltip("A floating point value (QDoubleSpinBox)")] = 0.5

    example_int: Annotated[int,Tooltip("An integer value (QSpinBox)")] = 10

    example_str: Annotated[str,Tooltip("A short string (QLineEdit)")] = "Hello"

    file_path: Annotated[str,FilePath(filter="All Files (*.*)"),Tooltip("Pick a file path (file picker dialog)")] = ""

    vector: Annotated[QVector3D,Tooltip("3D vector [x, y, z] (Vector3 Editor)")] = QVector3D(1.0, 2.0, 3.0)

    color: Annotated[QColor,ColorField(alpha=True),Tooltip("A color value (Color picker with alpha)")] = QColor(255, 100, 100, 160)

    # For demonstration: enum literal (appears as a dropdown in the Inspector)
    example_enum: Annotated[Literal["cube", "sphere", "custom"],Tooltip("Choose shape (dropdown)")] = "cube"

    target: Annotated[Optional[TransformComponent],Header("More Options"),Group("More Options"),Tooltip("Target transform component")] = None

    target_point: Annotated[QVector3D, Group("More Options"),VertexPick(), Tooltip("Pick a vertex"),Order(1)]

    more_notes: Annotated[str, Group("More Options"), Order(100), Tooltip("Extra string in gear popup")] = ""
    debug_scale: Annotated[float, Group("More Options"), Order(110), Range(0.1, 5.0, step=0.1), Tooltip("Scale factor in gear popup")] = 1.0

    def __init__(self) -> None:
        # Example annotated fields with widget mapping for Inspector auto-UI
        self.example_bool = True
        self.example_float = 0.5
        self.example_int = 10
        self.example_str = "Hello"
        self.file_path = ""
        self.vector = QVector3D(1.0, 2.0, 3.0)
        self.color = QColor(255, 100, 100, 160)
        self.example_enum = "cube"
        self.target = None
        self.target_point = QVector3D(0.0, 0.0, 0.0)
        self.more_notes = ""
        self.debug_scale = 1.0
        self.sample_float = 2.0

    def on_entity_changed(self) -> None:
        pass

    def on_viewport_draw(self) -> None:
        if self.entity is None:
            return
        from MotionStudio.core.transform.utils import transform_point
        world = transform_point(self.entity, self.target_point)
        # Debug.draw_point(world, size=0.08, color=QColor(255, 0, 0))
        # Debug.draw_sphere(world, radius=0.1, color=QColor(255, 0, 0))
        # Debug.draw_bounding_box(world, size=QVector3D(1, 1, 1), color=QColor(255, 0, 0))
        # Debug.draw_axes(world, length=3.0, width=0.2)
        Debug.draw_label(world + QVector3D(0, 0.12, 0), self.example_str, color=QColor(255, 200, 200), font_size=14)
        Debug.draw_point(world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9)

    def update(self, delta_time: float):
        transform = self.entity.get_component(TransformComponent)
        mesh = self.entity.get_component(MeshComponent)
        # if mesh is not None:
        #     mesh.color = self.color
        if self.target is not None:
            print(type(self.target))
            dir = QVector3D.normalized(self.target.position - transform.position)
            transform.position = transform.position + dir * delta_time*self.example_float
        pass

    @inspector_button("Reset Anchor", tooltip="Snap entity to target point",order=0)
    def reset_anchor(self) -> None:
        # get global position of target point
        from MotionStudio.core.transform.utils import transform_point
        global_point = transform_point(self.entity, self.target_point)
        self.entity.get_component(TransformComponent).position = global_point
        
        
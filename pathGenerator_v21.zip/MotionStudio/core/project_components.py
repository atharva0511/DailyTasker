"""
Unified component discovery system.
Scans both engine components (pyengine/core/components) and project components (Project/Components).
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import List, Optional


def discover_components_from_directory(components_dir: Path, module_prefix: str = "components") -> List[str]:
    """
    Discover and import all component files from a directory.
    
    Args:
        components_dir: Path to the directory containing component files
        module_prefix: Prefix for module names (e.g., "components" or "project_components")
        
    Returns:
        List of successfully imported component module names
    """
    if not components_dir.exists():
        return []
    
    imported_modules = []
    
    # Look for Python files ending with _component.py or any .py file
    for file_path in sorted(components_dir.glob("*.py")):
        # Skip __init__.py and other special files
        if file_path.name.startswith("_") or file_path.name == "components.py":
            continue
        
        module_name = file_path.stem
        
        try:
            # Load the module dynamically
            spec = importlib.util.spec_from_file_location(
                f"{module_prefix}.{module_name}",
                file_path
            )
            
            if spec is None or spec.loader is None:
                continue
            
            # Import the module (this executes @register_component decorators)
            module = importlib.util.module_from_spec(spec)
            
            # Add to sys.modules so it can be imported by other modules
            full_module_name = f"{module_prefix}.{module_name}"
            sys.modules[full_module_name] = module
            
            # Execute the module
            spec.loader.exec_module(module)
            
            imported_modules.append(module_name)
            
        except Exception as e:
            # Log but don't crash - allow other components to load
            print(f"Warning: Failed to load component '{module_name}' from {components_dir}: {e}", flush=True)
            continue
    
    return imported_modules


def discover_engine_components() -> List[str]:
    """
    Discover and import all engine components from pyengine/core/components.
    This complements the explicit imports in __init__.py for PyInstaller compatibility.
    
    Returns:
        List of successfully imported component module names
    """
    # Import the existing __init__.py first (this handles explicit imports for PyInstaller)
    # This ensures all explicitly imported components are registered
    try:
        from MotionStudio.core import components
        # The __init__.py already imports components, so they're registered
    except Exception as e:
        print(f"Warning: Failed to import engine components: {e}", flush=True)
        return []
    
    # Get the engine components directory
    engine_components_dir = Path(__file__).parent.parent / "components"
    
    if not engine_components_dir.exists():
        return []
    
    # Also do dynamic discovery for any components not explicitly imported
    # This ensures we catch any new components added to the engine
    # Note: We use importlib.import_module instead of our discovery function
    # because these are part of a package and should be imported as package modules
    imported_modules = []
    import importlib
    
    for file_path in sorted(engine_components_dir.glob("*_component.py")):
        module_name = file_path.stem
        
        # Skip if already explicitly imported (to avoid duplicate imports)
        if module_name in ['transform_component', 'mesh_component', 'path_component', 'test_component', 'tool_trace_component']:
            continue
        
        try:
            # Import as a package module (this matches how __init__.py does it)
            module = importlib.import_module(f"pyengine.core.components.{module_name}")
            imported_modules.append(module_name)
        except Exception as e:
            # Skip modules that fail to import
            continue
    
    return imported_modules


def discover_project_components(project_dir: Path) -> List[str]:
    """
    Discover and import all component files from the project's Components folder.
    
    Args:
        project_dir: Path to the project root directory
        
    Returns:
        List of successfully imported component module names
    """
    components_dir = project_dir / "Components"
    
    if not components_dir.exists():
        # Create Components directory if it doesn't exist (for user convenience)
        try:
            components_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return []
    
    return discover_components_from_directory(components_dir, "project_components")


def discover_all_components(project_dir: Optional[Path] = None) -> tuple[List[str], List[str]]:
    """
    Discover components from both engine and project locations.
    
    Args:
        project_dir: Optional path to project directory. If None, uses default "Test Project"
        
    Returns:
        Tuple of (engine_components, project_components) - lists of module names
    """
    engine_components = discover_engine_components()
    
    if project_dir is None:
        # Try to find project directory
        project_dir = Path("Test Project")
    
    project_components = discover_project_components(project_dir)
    
    return (engine_components, project_components)


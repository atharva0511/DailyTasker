"""
Transform utility helpers.

Convenience functions for working with entity transforms in world space and
across reference frames. Mirrors the Unity ``Transform`` API in spirit
(``transform_point``, ``inverse_transform_point``, ``world_position``, ...)
without modifying :class:`TransformComponent` itself.

All functions are pure reads except for :func:`set_world_position` and
:func:`set_world_rotation_quat`, which write back through the existing public
setters on ``TransformComponent`` and therefore emit
``entity_transform_changed`` automatically.

Notes
-----
* "Local" means *relative to the immediate parent* (or world if the entity is
  a root). This matches what ``TransformComponent.position`` etc. already
  store.
* :func:`lossy_world_scale` is only mathematically meaningful when ancestor
  scales are uniform or aligned with the entity's own axes. The name follows
  Unity's ``lossyScale`` terminology to flag that limitation.
* These helpers walk the parent chain on every call (``O(depth)``). They do
  not cache. If profiling reveals a hotspot, introduce a dirty-flag cache on
  ``TransformComponent`` rather than memoising at call sites.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

from PyQt6.QtGui import QMatrix4x4, QQuaternion, QVector3D, QVector4D

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.transform.matrix import qmatrix_from_prs


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _norm(v: QVector3D) -> QVector3D:
	length = v.length()
	if length < 1e-9:
		return QVector3D(0.0, 0.0, 0.0)
	return QVector3D(v.x() / length, v.y() / length, v.z() / length)


def _local_matrix(entity: Entity) -> QMatrix4x4:
	"""Build the entity's own local PRS matrix (identity if no TransformComponent)."""
	t = entity.get_component(TransformComponent)
	if t is None:
		return QMatrix4x4()
	return qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d)


def _safe_inverse(m: QMatrix4x4) -> QMatrix4x4:
	"""Invert a matrix, returning identity on failure (degenerate scale, etc.)."""
	inv, ok = m.inverted()
	if not ok:
		return QMatrix4x4()
	return inv


# ---------------------------------------------------------------------------
# World-space read accessors
# ---------------------------------------------------------------------------

def world_matrix(entity: Entity) -> QMatrix4x4:
	"""
	Full 4x4 world matrix: ``root * ... * parent * local`` for ``entity``.

	Ancestors without a ``TransformComponent`` contribute the identity matrix.
	"""
	stack: List[QMatrix4x4] = []
	curr: Optional[Entity] = entity
	while curr is not None:
		stack.append(_local_matrix(curr))
		curr = curr.parent
	m = QMatrix4x4()
	for k in reversed(stack):
		m = m * k
	return m


def parent_world_matrix(entity: Entity) -> QMatrix4x4:
	"""World matrix of the entity's parent (identity if it is a root)."""
	if entity.parent is None:
		return QMatrix4x4()
	return world_matrix(entity.parent)


def world_position(entity: Entity) -> QVector3D:
	"""Translation column of the entity's world matrix."""
	return QVector3D(world_matrix(entity).column(3).toVector3D())


def world_rotation_quat(entity: Entity) -> QQuaternion:
	"""
	Composed world-space orientation as a quaternion.

	Multiplies local rotation quaternions up the parent chain. Independent of
	scale, which is the right thing for orientation queries.
	"""
	chain: List[QQuaternion] = []
	curr: Optional[Entity] = entity
	while curr is not None:
		t = curr.get_component(TransformComponent)
		if t is not None:
			chain.append(t.rotation_quat)
		curr = curr.parent
	q = QQuaternion()
	for r in reversed(chain):
		q = r * q
	return q


def world_euler_deg(entity: Entity) -> Tuple[float, float, float]:
	"""World-space rotation as XYZ Euler angles in degrees."""
	e = world_rotation_quat(entity).toEulerAngles()
	return float(e.x()), float(e.y()), float(e.z())


def lossy_world_scale(entity: Entity) -> QVector3D:
	"""
	Component-wise product of every ancestor's local scale.

	Only fully meaningful when ancestor scales are uniform or aligned with
	the entity's own axes; matches Unity's ``lossyScale``.
	"""
	s = QVector3D(1.0, 1.0, 1.0)
	curr: Optional[Entity] = entity
	while curr is not None:
		t = curr.get_component(TransformComponent)
		if t is not None:
			ls = t.scale3d
			s = QVector3D(s.x() * ls.x(), s.y() * ls.y(), s.z() * ls.z())
		curr = curr.parent
	return s


# ---------------------------------------------------------------------------
# Local-axis directions expressed in world space
# ---------------------------------------------------------------------------

def local_axes_in_world(
	entity: Entity,
) -> Tuple[QVector3D, QVector3D, QVector3D]:
	"""
	Return the entity's local X / Y / Z basis vectors expressed in world
	space (normalised). Use these to translate or query "along the object's
	own axes".
	"""
	m = world_matrix(entity)
	x = _norm(QVector3D(m.column(0).toVector3D()))
	y = _norm(QVector3D(m.column(1).toVector3D()))
	z = _norm(QVector3D(m.column(2).toVector3D()))
	return x, y, z


def local_x_in_world(entity: Entity) -> QVector3D:
	"""Entity's local +X axis expressed in world space (normalised)."""
	return local_axes_in_world(entity)[0]


def local_y_in_world(entity: Entity) -> QVector3D:
	"""Entity's local +Y axis expressed in world space (normalised)."""
	return local_axes_in_world(entity)[1]


def local_z_in_world(entity: Entity) -> QVector3D:
	"""Entity's local +Z axis expressed in world space (normalised)."""
	return local_axes_in_world(entity)[2]


# ---------------------------------------------------------------------------
# Frame conversions (entity defines the reference frame)
# ---------------------------------------------------------------------------

def transform_point(entity: Entity, local_point: QVector3D) -> QVector3D:
	"""Map a point given in the entity's local frame into world space."""
	p4 = world_matrix(entity) * QVector4D(local_point, 1.0)
	w = p4.w() if abs(p4.w()) > 1e-9 else 1.0
	return QVector3D(p4.x() / w, p4.y() / w, p4.z() / w)


def transform_direction(entity: Entity, local_dir: QVector3D) -> QVector3D:
	"""
	Map a *direction* (``w = 0``) from the entity's local frame into world
	space.

	Affected by scale; ignores translation. For a pure rotation use
	``world_rotation_quat(entity).rotatedVector(local_dir)`` instead.
	"""
	d4 = world_matrix(entity) * QVector4D(local_dir, 0.0)
	return QVector3D(d4.x(), d4.y(), d4.z())


def inverse_transform_point(entity: Entity, world_point: QVector3D) -> QVector3D:
	"""Map a world-space point into the entity's local frame."""
	inv = _safe_inverse(world_matrix(entity))
	p4 = inv * QVector4D(world_point, 1.0)
	w = p4.w() if abs(p4.w()) > 1e-9 else 1.0
	return QVector3D(p4.x() / w, p4.y() / w, p4.z() / w)


def inverse_transform_direction(entity: Entity, world_dir: QVector3D) -> QVector3D:
	"""Map a world-space direction into the entity's local frame (``w = 0``)."""
	inv = _safe_inverse(world_matrix(entity))
	d4 = inv * QVector4D(world_dir, 0.0)
	return QVector3D(d4.x(), d4.y(), d4.z())


def local_position_from_world(entity: Entity, world_pos: QVector3D) -> QVector3D:
	"""
	Convert a world point into the entity's *parent-local* frame, ready to be
	assigned to ``TransformComponent.position``.

	If the entity is a root, returns ``world_pos`` unchanged.
	"""
	if entity.parent is None:
		return world_pos
	inv = _safe_inverse(parent_world_matrix(entity))
	p4 = inv * QVector4D(world_pos, 1.0)
	return QVector3D(p4.x(), p4.y(), p4.z())


# ---------------------------------------------------------------------------
# A relative to B
# ---------------------------------------------------------------------------

def relative_matrix(a: Entity, b: Entity) -> QMatrix4x4:
	"""4x4 matrix of ``a``'s pose expressed in ``b``'s local frame."""
	return _safe_inverse(world_matrix(b)) * world_matrix(a)


def relative_position(a: Entity, b: Entity) -> QVector3D:
	"""Position of ``a`` expressed in ``b``'s local frame."""
	return inverse_transform_point(b, world_position(a))


def relative_rotation(a: Entity, b: Entity) -> QQuaternion:
	"""Orientation of ``a`` expressed in ``b``'s local frame."""
	return world_rotation_quat(b).inverted() * world_rotation_quat(a)


# ---------------------------------------------------------------------------
# World-space setters (write through public properties -> signals fire)
# ---------------------------------------------------------------------------

def set_world_position(entity: Entity, world_pos: QVector3D) -> None:
	"""
	Move ``entity`` so that its world position equals ``world_pos``.

	Converts to parent-local and assigns through the public ``position``
	setter, which emits ``entity_transform_changed``.
	"""
	t = entity.get_component(TransformComponent)
	if t is None:
		return
	t.position = local_position_from_world(entity, world_pos)


def set_world_rotation_quat(entity: Entity, world_quat: QQuaternion) -> None:
	"""
	Rotate ``entity`` so that its world orientation equals ``world_quat``.

	Computes ``local = parent_world_inverse * world`` and assigns through
	the public ``rotation_quat`` setter, which emits
	``entity_transform_changed``.
	"""
	t = entity.get_component(TransformComponent)
	if t is None:
		return
	if entity.parent is None:
		t.rotation_quat = world_quat
		return
	parent_q = world_rotation_quat(entity.parent)
	t.rotation_quat = parent_q.inverted() * world_quat

from __future__ import annotations

from PyQt6.QtGui import QMatrix4x4, QQuaternion, QVector3D


def qmatrix_from_prs(position: QVector3D, rotation: QQuaternion, scale3d: QVector3D) -> QMatrix4x4:
	"""
	Build a 4x4 transform matrix from Position/Rotation(quat)/Scale.

	Convention: local = T * R * S (applied to column vectors).
	"""
	m = QMatrix4x4()
	m.translate(position)
	m.rotate(rotation)
	m.scale(scale3d)
	return m


def vtk_matrix_from_qmatrix(m: QMatrix4x4):
	"""
	Convert a QMatrix4x4 to a vtkMatrix4x4.
	"""
	import vtk  # type: ignore
	mtx = vtk.vtkMatrix4x4()
	for r in range(4):
		for c in range(4):
			mtx.SetElement(r, c, float(m[r, c]))
	return mtx


def vtk_transform_from_qmatrix(m: QMatrix4x4):
	"""
	Convert a QMatrix4x4 to a vtkTransform.

	Imported lazily to avoid importing VTK in non-render contexts (tests, headless).
	"""
	import vtk  # type: ignore

	mtx = vtk.vtkMatrix4x4()
	# QMatrix4x4 stores elements in row-major indexing via (row, col)
	for r in range(4):
		for c in range(4):
			mtx.SetElement(r, c, float(m[r, c]))
	t = vtk.vtkTransform()
	t.SetMatrix(mtx)
	return t



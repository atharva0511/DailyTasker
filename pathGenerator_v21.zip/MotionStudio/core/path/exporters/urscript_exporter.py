from __future__ import annotations
from typing import List, Optional, Tuple
import math
from PyQt6.QtGui import QQuaternion


def euler_to_rotation_vector(rx_deg: float, ry_deg: float, rz_deg: float) -> Tuple[float, float, float]:
    """
    Convert Euler angles (degrees, XYZ order) to rotation vector (axis * angle in radians).
    
    The rotation vector represents a rotation around an axis, where the vector direction
    is the axis and the magnitude is the angle in radians. This is the format used by
    Universal Robots.
    
    Args:
        rx_deg: Rotation around X axis in degrees
        ry_deg: Rotation around Y axis in degrees
        rz_deg: Rotation around Z axis in degrees
        
    Returns:
        Tuple of (rx, ry, rz) as rotation vector in radians
    """
    # Convert Euler angles to quaternion (Qt uses XYZ order for toEulerAngles)
    quat = QQuaternion.fromEulerAngles(rx_deg, ry_deg, rz_deg)
    
    # Convert quaternion to axis-angle representation
    # QQuaternion stores as (w, x, y, z) where w is the scalar part
    w = quat.scalar()
    x = quat.x()
    y = quat.y()
    z = quat.z()
    
    # Calculate angle from quaternion
    # cos(angle/2) = w, so angle = 2 * acos(w)
    angle = 2.0 * math.acos(max(-1.0, min(1.0, w)))
    
    # Handle very small rotations (avoid division by zero)
    if angle < 1e-6:
        return (0.0, 0.0, 0.0)
    
    # Normalize the axis part of the quaternion
    axis_len = math.sqrt(x*x + y*y + z*z)
    if axis_len < 1e-6:
        return (0.0, 0.0, 0.0)
    
    # Axis is the normalized (x, y, z) part
    axis_x = x / axis_len
    axis_y = y / axis_len
    axis_z = z / axis_len
    
    # Rotation vector = axis * angle
    return (axis_x * angle, axis_y * angle, axis_z * angle)


# Engine positions are stored in millimetres; URScript expects metres.
_MM_TO_M = 1.0 / 1000.0


def export_to_urscript(
    feature_waypoints: List[List[Tuple[float, float, float, float, float, float]]],
    speed: float = 0.25,
    acceleration: float = 1.2,
    segment_speed_multipliers: Optional[List[float]] = None,
    segment_cnt_radii: Optional[List[float]] = None,
) -> str:
    """
    Export path waypoints (grouped by feature) to URScript format.

    The output wraps the move sequence inside a ``move_path()`` function which
    is invoked at the bottom of the script. Within a single feature, the
    in-feature waypoints are traversed with ``movep`` (blended circular tool-
    space moves). The first waypoint of every feature is reached with
    ``movel`` (a clean linear move), so the robot transitions deterministically
    between features.

    Args:
        feature_waypoints: List of features. Each feature is itself a list of
            waypoints as ``(x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg)``.
            Positions are interpreted as millimetres and converted to metres
            on output.
        speed: Base movement speed in m/s (Path Program Settings).
        acceleration: Movement acceleration in m/s^2 (Path Program Settings).
        segment_speed_multipliers: Optional per-segment multipliers applied to
            ``speed`` (e.g. ``effective_speed = speed * multiplier[segment]``).
        segment_cnt_radii: Optional per-segment CNT blend radii in metres (URScript
            ``r=``). Omitted from a move when the segment value is ``0``.

    Returns:
        URScript program as a string.
    """
    lines: List[str] = []
    lines.append("# URScript program generated from path waypoints")
    lines.append("# Format: p[x, y, z, rx, ry, rz] - positions in metres,")
    lines.append("# rx,ry,rz is rotation vector (axis * angle in radians)")
    lines.append("")

    features = [f for f in (feature_waypoints or []) if f]
    total_waypoints = sum(len(f) for f in features)

    lines.append("def move_path():")
    if not features:
        lines.append("    # No waypoints to export")
        lines.append("end")
        lines.append("")
        lines.append("move_path()")
        return "\n".join(lines)

    global_idx = 0
    for f_idx, waypoints in enumerate(features):
        seg_mult = 1.0
        if segment_speed_multipliers is not None and f_idx < len(segment_speed_multipliers):
            seg_mult = float(segment_speed_multipliers[f_idx])
        effective_speed = speed * seg_mult
        seg_cnt = 0.0
        if segment_cnt_radii is not None and f_idx < len(segment_cnt_radii):
            seg_cnt = float(segment_cnt_radii[f_idx])
        cnt_note = f", r={seg_cnt:.6f} m" if seg_cnt > 0.0 else ""
        lines.append(
            f"    # Segment {f_idx + 1}/{len(features)}"
            f" ({len(waypoints)} waypoint{'s' if len(waypoints) != 1 else ''},"
            f" v={effective_speed:.6f} m/s{cnt_note})"
        )
        for w_idx, waypoint in enumerate(waypoints):
            x_mm, y_mm, z_mm, rx_deg, ry_deg, rz_deg = waypoint
            x = x_mm * _MM_TO_M
            y = y_mm * _MM_TO_M
            z = z_mm * _MM_TO_M
            rx_vec, ry_vec, rz_vec = euler_to_rotation_vector(rx_deg, ry_deg, rz_deg)
            pose_str = (
                f"p[{x:.6f}, {y:.6f}, {z:.6f}, "
                f"{rx_vec:.6f}, {ry_vec:.6f}, {rz_vec:.6f}]"
            )

            # First waypoint of each feature is reached linearly; subsequent
            # waypoints within the same feature use movep for smooth tool-
            # space traversal.
            command = "movel" if w_idx == 0 else "movep"
            if seg_cnt > 0.0:
                call = f"{command}({pose_str}, a={acceleration}, v={effective_speed}, r={seg_cnt})"
            else:
                call = f"{command}({pose_str}, a={acceleration}, v={effective_speed})"

            global_idx += 1
            lines.append(
                f"    {call}  # Segment {f_idx + 1}, waypoint {w_idx + 1}/{len(waypoints)} "
                f"({global_idx}/{total_waypoints})"
            )
        lines.append("")

    # Trim the trailing blank line inside the function body for cleanliness.
    if lines and lines[-1] == "":
        lines.pop()
    lines.append("end")
    lines.append("")
    lines.append("move_path()")
    return "\n".join(lines)


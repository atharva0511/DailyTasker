from __future__ import annotations

from typing import Any, Dict, List, Optional

from PyQt6.QtGui import QUndoCommand

from MotionStudio.core.ecs.component import get_component_class
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.undo.merge_policy import can_merge_property_edit, merge_anchor_now
from MotionStudio.utils.ids import generate_uuid
from PyQt6.QtGui import QVector3D, QQuaternion


class AddPathFeatureCommand(QUndoCommand):
	def __init__(self, scene: Scene, entity_id: str, feature_type: str, feature_data: Dict[str, Any]) -> None:
		from MotionStudio.core.components.feature import SEGMENT_DISPLAY_NAMES

		label = SEGMENT_DISPLAY_NAMES.get(feature_type, feature_type.replace("Feature", "Segment"))
		super().__init__(f"Add {label}")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_type = feature_type
		self._feature_data = feature_data

	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import get_feature_class

		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return

		f_cls = get_feature_class(self._feature_type)
		if f_cls is None:
			return
		feature = f_cls.from_dict(self._feature_data)
		path_comp.features.append(feature)
		self._scene.events.entity_changed.emit(self._entity_id)

	def undo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None or not path_comp.features:
			return

		path_comp.features.pop()
		self._scene.events.entity_changed.emit(self._entity_id)

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		from MotionStudio.core.components.feature import SEGMENT_DISPLAY_NAMES

		label = SEGMENT_DISPLAY_NAMES.get(self._feature_type, self._feature_type)
		return f"Added {label} to path on '{entity_name}'"


class PathFeaturePropertyChangeCommand(QUndoCommand):
	"""
	Command for changing a property on a specific segment within a PathComponent.
	"""

	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		feature_idx: int,
		field: str,
		old_value: Any,
		new_value: Any,
	) -> None:
		super().__init__(f"Segment[{feature_idx}].{field}")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._field = field
		self._old = _clone(old_value)
		self._new = _clone(new_value)
		self._merge_anchor_time = merge_anchor_now()

	def id(self) -> int:
		return (hash((self._entity_id, "PathGeneration", self._feature_idx, self._field)) & 0x7FFFFFFF)

	def mergeWith(self, other: QUndoCommand) -> bool:
		if not isinstance(other, PathFeaturePropertyChangeCommand):
			return False
		if (
			self._entity_id != other._entity_id
			or self._feature_idx != other._feature_idx
			or self._field != other._field
		):
			return False
		if not can_merge_property_edit(self._merge_anchor_time):
			return False
		self._new = _clone(other._new)
		self._merge_anchor_time = merge_anchor_now()
		return True

	def _apply(self, value: Any) -> None:
		from MotionStudio.core.components.path_component import PathComponent

		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None or len(path_comp.features) <= self._feature_idx:
			return

		feature = path_comp.features[self._feature_idx]
		try:
			setattr(feature, self._field, value)
		except Exception:
			return

		# Notify renderer/UI
		try:
			self._scene.events.entity_changed.emit(self._entity_id)
		except Exception:
			pass

	def undo(self) -> None:
		self._apply(_clone(self._old))

	def redo(self) -> None:
		self._apply(self._new)

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Changed {self._field} on segment {self._feature_idx} of '{entity_name}'"


class RemovePathFeatureCommand(QUndoCommand):
	def __init__(self, scene: Scene, entity_id: str, feature_idx: int) -> None:
		super().__init__("Remove Path Segment")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._feature_snapshot: Optional[Dict[str, Any]] = None
		self._feature_type: Optional[str] = None

	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None or len(path_comp.features) <= self._feature_idx:
			return

		feature = path_comp.features[self._feature_idx]
		self._feature_type = feature.__class__.__name__
		self._feature_snapshot = feature.to_dict()
		
		path_comp.features.pop(self._feature_idx)
		self._scene.events.entity_changed.emit(self._entity_id)

	def undo(self) -> None:
		if self._feature_snapshot is None or self._feature_type is None:
			return
			
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import get_feature_class
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return

		f_cls = get_feature_class(self._feature_type)
		if f_cls is None:
			return
		feature = f_cls.from_dict(self._feature_snapshot)
		path_comp.features.insert(self._feature_idx, feature)
		self._scene.events.entity_changed.emit(self._entity_id)

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Removed path segment at index {self._feature_idx} from '{entity_name}'"


class ReorderPathFeatureCommand(QUndoCommand):
	"""Command for reordering segments within a PathComponent."""
	def __init__(self, scene: Scene, entity_id: str, feature_idx: int, direction: int) -> None:
		# direction: -1 for "up" (move earlier), +1 for "down" (move later)
		super().__init__(f"Reorder Path Segment {'Up' if direction < 0 else 'Down'}")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._direction = direction

	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		
		new_idx = self._feature_idx + self._direction
		if new_idx < 0 or new_idx >= len(path_comp.features):
			return
		
		# Swap features
		features = path_comp.features
		features[self._feature_idx], features[new_idx] = features[new_idx], features[self._feature_idx]
		
		# Update selection if needed
		if self._scene is not None:
			# Try to get selection model from scene (if available)
			# For now, just emit entity changed; selection update can be handled by listeners
			self._scene.events.entity_changed.emit(self._entity_id)

	def undo(self) -> None:
		# Reordering is a swap operation; undoing uses the same swap again.
		self.redo()

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		direction_str = "up" if self._direction < 0 else "down"
		return f"Reordered path feature {self._feature_idx} {direction_str} in '{entity_name}'"


def _component_key(comp: Any) -> str:
	return getattr(comp, "type_name", comp.__class__.__name__)


def _find_component(entity, comp_type_name: str):
	for comp in getattr(entity, "components", []):
		if _component_key(comp) == comp_type_name or comp.__class__.__name__ == comp_type_name:
			return comp
	return None


def _clone(v: Any) -> Any:
	try:
		from PyQt6.QtGui import QVector3D, QColor

		if isinstance(v, QVector3D):
			return QVector3D(v)
		if isinstance(v, QColor):
			return QColor(v)
	except Exception:
		pass
	return v


class PropertyChangeCommand(QUndoCommand):
	"""
	Generic property change command for (entity_id, component_type, field).
	Mergeable: successive pushes with same id update the 'new' value.
	"""

	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		component_type: str,
		field: str,
		old_value: Any,
		new_value: Any,
		*,
		text: Optional[str] = None,
	) -> None:
		super().__init__(text or f"{component_type}.{field}")
		self._scene = scene
		self._entity_id = str(entity_id)
		self._component_type = str(component_type)
		self._field = str(field)
		self._old = _clone(old_value)
		self._new = _clone(new_value)
		self._merge_anchor_time = merge_anchor_now()

	def id(self) -> int:
		# Stable-ish id; Qt uses this to decide merge eligibility.
		return (hash((self._entity_id, self._component_type, self._field)) & 0x7FFFFFFF)

	def mergeWith(self, other: QUndoCommand) -> bool:
		if not isinstance(other, PropertyChangeCommand):
			return False
		if (
			self._entity_id != other._entity_id
			or self._component_type != other._component_type
			or self._field != other._field
		):
			return False
		if not can_merge_property_edit(self._merge_anchor_time):
			return False
		# Keep original old; take newest new.
		self._new = _clone(other._new)
		self._merge_anchor_time = merge_anchor_now()
		return True

	def _apply(self, value: Any) -> None:
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return

		if self._component_type == "__entity__":
			try:
				setattr(entity, self._field, value)
			except Exception:
				pass
			return

		comp = _find_component(entity, self._component_type)
		if comp is None:
			return
		try:
			setattr(comp, self._field, value)
			# Signal emission is now handled automatically:
			# - For properties: setters emit signals
			# - For plain attributes: Component.__setattr__ emits signals
		except Exception:
			pass

	def undo(self) -> None:
		self._apply(_clone(self._old))

	def redo(self) -> None:
		self._apply(_clone(self._new))

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		if self._component_type == "__entity__":
			return f"Changed {self._field} on '{entity_name}'"
		else:
			return f"Changed {self._component_type}.{self._field} on '{entity_name}'"


def _serialize_entity_flat(root: Entity) -> List[Dict[str, Any]]:
	flat: List[Dict[str, Any]] = []

	def visit(node: Entity, parent_id: Optional[str]) -> None:
		flat.append(
			{
				"id": node.id,
				"name": node.name,
				"parent_id": parent_id,
				"components": [
					{"type": getattr(c, "type_name", c.__class__.__name__), "data": c.to_dict()} for c in node.components
				],
			}
		)
		for ch in node.children:
			visit(ch, node.id)

	visit(root, root.parent.id if root.parent is not None else None)
	return flat


def _restore_entity_flat(scene: Scene, flat: List[Dict[str, Any]]) -> Optional[Entity]:
	"""
	Restore a subtree previously serialized by _serialize_entity_flat.
	Returns the root entity instance.
	"""
	id_to_entity: Dict[str, Entity] = {}
	pending_parent: List[tuple[Entity, Optional[str]]] = []

	for entry in flat:
		ent = scene.create_entity(entry.get("name", "Entity"), None, entity_id=entry.get("id"))
		id_to_entity[ent.id] = ent
		for c in entry.get("components", []):
			type_name = c.get("type")
			comp_cls = get_component_class(type_name) if type_name else None
			if comp_cls is None:
				continue
			try:
				comp = comp_cls.from_dict(c.get("data", {}))
			except Exception:
				continue
			ent.add_component(comp)
		pending_parent.append((ent, entry.get("parent_id")))

	# Parenting (root parent may be outside the serialized subtree)
	for ent, parent_id in pending_parent:
		parent = None
		if parent_id:
			parent = id_to_entity.get(parent_id) or scene.find_by_id(parent_id)
		scene.reparent(ent, parent)

	# Notify
	for ent in id_to_entity.values():
		try:
			scene.events.entity_changed.emit(ent.id)
		except Exception:
			pass

	# Root is the one whose parent_id was the original external parent (flat[0].parent_id)
	root_id = flat[0].get("id") if flat else None
	return id_to_entity.get(root_id) if root_id else None


class CreateEntityCommand(QUndoCommand):
	def __init__(
		self,
		scene: Scene,
		*,
		name: str = "Entity",
		parent_id: Optional[str] = None,
		initial_components: Optional[List[Dict[str, Any]]] = None,
		selection: Optional[SelectionModel] = None,
		entity_id: Optional[str] = None,
	) -> None:
		super().__init__(f"Create {name}")
		self._scene = scene
		self._entity_id = entity_id or generate_uuid()
		self._name = name
		self._parent_id = parent_id
		self._initial_components = initial_components or []
		self._selection = selection

	def redo(self) -> None:
		# Create
		parent = self._scene.find_by_id(self._parent_id) if self._parent_id else None
		ent = self._scene.create_entity(self._name, parent, entity_id=self._entity_id)
		# Components
		for c in self._initial_components:
			type_name = c.get("type")
			comp_cls = get_component_class(type_name) if type_name else None
			if comp_cls is None:
				continue
			try:
				comp = comp_cls.from_dict(c.get("data", {}))
			except Exception:
				continue
			ent.add_component(comp)
		try:
			self._scene.events.entity_changed.emit(ent.id)
		except Exception:
			pass
		if self._selection is not None:
			self._selection.set_current(ent)

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		return f"Created entity '{self._name}'"

	def undo(self) -> None:
		ent = self._scene.find_by_id(self._entity_id)
		if ent is None:
			return
		# Clear selection if needed
		if self._selection is not None and self._selection.current is ent:
			self._selection.set_current(None)
		self._scene.delete_entity(ent)


class LoadEntityPresetCommand(QUndoCommand):
	"""Instantiate a .pre subtree under an optional parent; undo removes the loaded root."""

	def __init__(
		self,
		scene: Scene,
		path: str,
		attach_under_id: Optional[str],
		selection: Optional[SelectionModel] = None,
	) -> None:
		super().__init__("Load preset")
		self._scene = scene
		self._path = path
		self._attach_under_id = attach_under_id
		self._selection = selection
		self._root_entity_id: Optional[str] = None

	def redo(self) -> None:
		from MotionStudio.core.serialization.json_io import load_entity_preset

		attach = self._scene.find_by_id(self._attach_under_id) if self._attach_under_id else None
		roots = load_entity_preset(self._scene, self._path, attach)
		if roots:
			self._root_entity_id = roots[0].id
			if self._selection is not None:
				self._selection.set_current(roots[0])
		else:
			self._root_entity_id = None

	def undo(self) -> None:
		if not self._root_entity_id:
			return
		ent = self._scene.find_by_id(self._root_entity_id)
		if ent is None:
			self._root_entity_id = None
			return
		if self._selection is not None and self._selection.current is ent:
			self._selection.set_current(None)
		self._scene.delete_entity(ent)
		self._root_entity_id = None

	def get_description(self) -> str:
		return "Loaded entity preset"


class ImportUrdfCommand(QUndoCommand):
	"""Import a URDF robot under an optional parent entity."""

	def __init__(
		self,
		scene: Scene,
		urdf_path: str,
		attach_under_id: Optional[str] = None,
		selection: Optional[SelectionModel] = None,
		*,
		prepared: Any = None,
	) -> None:
		super().__init__("Import URDF")
		self._scene = scene
		self._urdf_path = urdf_path
		self._attach_under_id = attach_under_id
		self._selection = selection
		self._root_entity_id: Optional[str] = None
		self._prepared = prepared

	def redo(self) -> None:
		from MotionStudio.core.robot.urdf_importer import apply_urdf_import, prepare_urdf_import

		if self._scene.project_root is None:
			raise RuntimeError("Open or create a project before importing URDF.")
		attach = self._scene.find_by_id(self._attach_under_id) if self._attach_under_id else None
		if self._prepared is None:
			self._prepared = prepare_urdf_import(self._scene.project_root, self._urdf_path)
		root = apply_urdf_import(self._scene, self._prepared, attach_under=attach)
		self._root_entity_id = root.id
		if self._selection is not None:
			self._selection.set_current(root)

	def undo(self) -> None:
		if not self._root_entity_id:
			return
		ent = self._scene.find_by_id(self._root_entity_id)
		if ent is None:
			self._root_entity_id = None
			return
		if self._selection is not None and self._selection.current is ent:
			self._selection.set_current(None)
		self._scene.delete_entity(ent)
		self._root_entity_id = None


class DeleteEntityCommand(QUndoCommand):
	def __init__(
		self,
		scene: Scene,
		entity: Entity,
		*,
		selection: Optional[SelectionModel] = None,
	) -> None:
		super().__init__(f"Delete {entity.name}")
		self._scene = scene
		self._entity_id = entity.id
		self._snapshot = _serialize_entity_flat(entity)
		self._selection = selection
		self._was_selected = selection.is_entity_id_selected(entity.id) if selection else False

	def redo(self) -> None:
		ent = self._scene.find_by_id(self._entity_id)
		if ent is None:
			return
		if self._selection is not None and self._selection.is_entity_id_selected(self._entity_id):
			self._selection.remove_entity_id(self._entity_id)
		self._scene.delete_entity(ent)

	def undo(self) -> None:
		root = _restore_entity_flat(self._scene, self._snapshot)
		if self._selection is not None and self._was_selected and root is not None:
			existing = self._selection.selected_entities()
			if not any(e.id == root.id for e in existing):
				existing.append(root)
			self._selection.set_selection(existing, primary=root)

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		# Try to get entity name from snapshot
		try:
			if self._snapshot and len(self._snapshot) > 0:
				entity_name = self._snapshot[0].get("name", "Unknown")
				return f"Deleted entity '{entity_name}'"
		except Exception:
			pass
		return "Deleted entity"


class DuplicateEntityCommand(QUndoCommand):
	"""
	Duplicate an entity subtree (Hierarchy Duplicate). Undo deletes the copy;
	redo restores the saved subtree snapshot.
	"""

	def __init__(
		self,
		scene: Scene,
		source: Entity,
		*,
		parent_id: Optional[str] = None,
		selection: Optional[SelectionModel] = None,
	) -> None:
		super().__init__(f"Duplicate {source.name}")
		self._scene = scene
		self._source_id = source.id
		self._source_name = source.name
		self._parent_id = parent_id
		self._selection = selection
		self._duplicated_root_id: Optional[str] = None
		self._snapshot: Optional[List[Dict[str, Any]]] = None

	def redo(self) -> None:
		if self._snapshot is not None:
			root = _restore_entity_flat(self._scene, self._snapshot)
			if root is None:
				return
			self._duplicated_root_id = root.id
			if self._selection is not None:
				self._selection.set_current(root)
			return

		source = self._scene.find_by_id(self._source_id)
		if source is None:
			return

		parent = self._scene.find_by_id(self._parent_id) if self._parent_id else None
		copy = self._scene.duplicate_entity(source, parent)
		self._duplicated_root_id = copy.id
		self._snapshot = _serialize_entity_flat(copy)
		if self._selection is not None:
			self._selection.set_current(copy)

	def undo(self) -> None:
		if not self._duplicated_root_id:
			return
		ent = self._scene.find_by_id(self._duplicated_root_id)
		if ent is None:
			return
		if self._selection is not None and self._selection.current is ent:
			src = self._scene.find_by_id(self._source_id)
			self._selection.set_current(src if src is not None else None)
		self._scene.delete_entity(ent)

	def get_description(self) -> str:
		return f"Duplicated entity '{self._source_name}'"


class RemoveComponentCommand(QUndoCommand):
	"""
	Command for removing a component from an entity.
	"""
	
	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		component_type: str,
		component_snapshot: Dict[str, Any],
	) -> None:
		super().__init__(f"Remove {component_type}")
		self._scene = scene
		self._entity_id = entity_id
		self._component_type = component_type
		self._component_snapshot = component_snapshot
	
	def redo(self) -> None:
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		
		comp = _find_component(entity, self._component_type)
		if comp is None:
			return
		
		entity.remove_component(comp)
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def undo(self) -> None:
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		
		comp_cls = get_component_class(self._component_type)
		if comp_cls is None:
			return
		
		try:
			comp = comp_cls.from_dict(self._component_snapshot)
			entity.add_component(comp)
			self._scene.events.entity_changed.emit(self._entity_id)
		except Exception:
			pass

	def get_description(self) -> str:
		"""Get a human-readable description of this command."""
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Removed {self._component_type} component from '{entity_name}'"


class AddComponentCommand(QUndoCommand):
	"""
	Command for adding a component to an entity (Inspector Add Component, etc.).
	"""

	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		component_type: str,
		component_snapshot: Dict[str, Any],
	) -> None:
		super().__init__(f"Add {component_type}")
		self._scene = scene
		self._entity_id = entity_id
		self._component_type = component_type
		self._component_snapshot = component_snapshot

	def redo(self) -> None:
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		if _find_component(entity, self._component_type) is not None:
			return

		comp_cls = get_component_class(self._component_type)
		if comp_cls is None:
			return

		try:
			comp = comp_cls.from_dict(self._component_snapshot)
			entity.add_component(comp)
		except Exception:
			pass

	def undo(self) -> None:
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return

		comp = _find_component(entity, self._component_type)
		if comp is None:
			return

		entity.remove_component(comp)

	def get_description(self) -> str:
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Added {self._component_type} component to '{entity_name}'"


class ConvertToCustomFeatureCommand(QUndoCommand):
	"""Command for converting a parametric feature to a custom editable feature."""
	
	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		feature_idx: int,
	) -> None:
		super().__init__(f"Convert Segment[{feature_idx}] to Custom")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._original_feature_data: Optional[Dict[str, Any]] = None
		self._original_feature_type: Optional[str] = None
	
	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import CustomFeature, get_feature_class
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[self._feature_idx]
		
		# Store original feature data for undo
		if self._original_feature_data is None:
			self._original_feature_data = feature.to_dict()
			self._original_feature_type = feature.__class__.__name__
		
		# Generate current waypoints from the parametric feature
		# We need the mesh polydata to generate waypoints properly
		# For now, pass None - the feature should handle this gracefully
		# In practice, waypoints should already be generated and stored
		mesh_poly = None
		global_offsets = {}
		
		# Try to get waypoints - if feature has them stored, use those
		# Otherwise, generate them (may fail if mesh is needed)
		try:
			if hasattr(feature, 'waypoints') and feature.waypoints:
				current_waypoints = feature.waypoints
			else:
				current_waypoints = feature.generate_waypoints(mesh_poly, global_offsets)
		except Exception:
			# If generation fails, create empty waypoints list
			current_waypoints = []
		
		# Create custom feature with current waypoints
		custom_feature = CustomFeature()
		custom_feature.waypoints = [wp for wp in current_waypoints]  # Copy waypoints
		custom_feature.speed_multiplier = float(getattr(feature, "speed_multiplier", 1.0))
		custom_feature.cnt_radius = float(getattr(feature, "cnt_radius", 0.0))

		# Replace feature
		path_comp.features[self._feature_idx] = custom_feature
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def undo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import get_feature_class
		
		if self._original_feature_data is None or self._original_feature_type is None:
			return
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		# Restore original feature
		f_cls = get_feature_class(self._original_feature_type)
		if f_cls is None:
			return
		
		original_feature = f_cls.from_dict(self._original_feature_data)
		path_comp.features[self._feature_idx] = original_feature
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def get_description(self) -> str:
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Converted feature to custom on '{entity_name}'"


class WaypointPositionChangeCommand(QUndoCommand):
	"""Command for changing a waypoint's position."""
	
	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		feature_idx: int,
		waypoint_idx: int,
		old_position: QVector3D,
		new_position: QVector3D,
	) -> None:
		super().__init__(f"Change Waypoint {waypoint_idx} Position")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._waypoint_idx = waypoint_idx
		self._old_position = QVector3D(old_position)
		self._new_position = QVector3D(new_position)
	
	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import CustomFeature
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[self._feature_idx]
		if not isinstance(feature, CustomFeature):
			return
		if self._waypoint_idx < 0 or self._waypoint_idx >= len(feature.waypoints):
			return
		
		feature.waypoints[self._waypoint_idx].position = self._new_position
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def undo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import CustomFeature
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[self._feature_idx]
		if not isinstance(feature, CustomFeature):
			return
		if self._waypoint_idx < 0 or self._waypoint_idx >= len(feature.waypoints):
			return
		
		feature.waypoints[self._waypoint_idx].position = self._old_position
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def get_description(self) -> str:
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Changed position of waypoint {self._waypoint_idx} in feature {self._feature_idx} of '{entity_name}'"


class WaypointRotationChangeCommand(QUndoCommand):
	"""Command for changing a waypoint's rotation."""
	
	def __init__(
		self,
		scene: Scene,
		entity_id: str,
		feature_idx: int,
		waypoint_idx: int,
		old_rotation: QQuaternion,
		new_rotation: QQuaternion,
	) -> None:
		super().__init__(f"Change Waypoint {waypoint_idx} Rotation")
		self._scene = scene
		self._entity_id = entity_id
		self._feature_idx = feature_idx
		self._waypoint_idx = waypoint_idx
		self._old_rotation = QQuaternion(old_rotation)
		self._new_rotation = QQuaternion(new_rotation)
	
	def redo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import CustomFeature
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[self._feature_idx]
		if not isinstance(feature, CustomFeature):
			return
		if self._waypoint_idx < 0 or self._waypoint_idx >= len(feature.waypoints):
			return
		
		feature.waypoints[self._waypoint_idx].rotation = self._new_rotation
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def undo(self) -> None:
		from MotionStudio.core.components.path_component import PathComponent
		from MotionStudio.core.components.feature import CustomFeature
		
		entity = self._scene.find_by_id(self._entity_id)
		if entity is None:
			return
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if self._feature_idx < 0 or self._feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[self._feature_idx]
		if not isinstance(feature, CustomFeature):
			return
		if self._waypoint_idx < 0 or self._waypoint_idx >= len(feature.waypoints):
			return
		
		feature.waypoints[self._waypoint_idx].rotation = self._old_rotation
		self._scene.events.entity_changed.emit(self._entity_id)
	
	def get_description(self) -> str:
		entity = self._scene.find_by_id(self._entity_id)
		entity_name = entity.name if entity else "Unknown"
		return f"Changed rotation of waypoint {self._waypoint_idx} in feature {self._feature_idx} of '{entity_name}'"



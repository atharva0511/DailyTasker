"""Time-gated merge policy for Qt undo command coalescing."""

from __future__ import annotations

import time

MERGE_COOLDOWN_SEC = 1.0


def merge_anchor_now() -> float:
	return time.monotonic()


def can_merge_property_edit(anchor: float, *, cooldown: float = MERGE_COOLDOWN_SEC) -> bool:
	return (time.monotonic() - anchor) <= cooldown

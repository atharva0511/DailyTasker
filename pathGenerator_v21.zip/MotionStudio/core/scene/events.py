from PyQt6.QtCore import QObject, pyqtSignal


class SceneEvents(QObject):
	"""
	Qt signals emitted by the Scene to keep UI and renderer in sync.
	"""

	entity_added = pyqtSignal(object)  # Entity
	entity_removed = pyqtSignal(str)  # entity_id
	entity_reparented = pyqtSignal(str, object)  # child_id, new_parent_id (str or None)
	entity_changed = pyqtSignal(str)  # entity_id (e.g., name or component value changed)
	entity_transform_changed = pyqtSignal(str)  # entity_id (transform-only change, skip mesh sync)
	entity_collision_changed = pyqtSignal(str)  # entity_id (ColliderComponent.collided flipped; recolor only)



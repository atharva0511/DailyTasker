from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Protocol, Tuple

from PyQt6.QtGui import QVector3D


@dataclass(frozen=True)
class CameraState:
	"""Snapshot of the active 3D viewport camera."""

	position: QVector3D
	focal_point: QVector3D
	view_up: QVector3D
	view_angle_deg: float
	parallel_projection: bool
	parallel_scale: float


class ViewportService(Protocol):
	"""Read-only viewport queries for component scripts."""

	def world_to_display(self, world: QVector3D) -> Tuple[float, float, float]:
		"""World position → display (pixel x, pixel y, depth)."""
		...

	def display_to_world(self, x: float, y: float, depth: float = 0.0) -> QVector3D:
		"""Display (pixel x, y, depth) → world position."""
		...

	def viewport_size(self) -> Tuple[int, int]:
		"""Render window size (width, height) in pixels."""
		...

	def camera_state(self) -> Optional[CameraState]:
		"""Current camera parameters, or None if unavailable."""
		...

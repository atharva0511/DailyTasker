from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, TYPE_CHECKING, Union

from PyQt6.QtCore import QObject

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.events import SceneEvents

if TYPE_CHECKING:
	from MotionStudio.core.scene.play_mode import PlayModeManager
	from MotionStudio.core.scene.collision_system import CollisionSystem
	from MotionStudio.core.scene.selection import SelectionModel
	from MotionStudio.core.scene.viewport import ViewportService
	from MotionStudio.core.robot.ik.robot_ik_system import RobotIKSystem


class Scene(QObject):
	"""
	Owns entities and manages hierarchy operations.
	"""

	def __init__(self) -> None:
		super().__init__()
		self.events = SceneEvents()
		self._entities_by_id: Dict[str, Entity] = {}
		self._roots: List[Entity] = []
		self._play_mode_manager: Optional["PlayModeManager"] = None
		self._selection_model: Optional["SelectionModel"] = None
		self._viewport_service: Optional["ViewportService"] = None
		self._project_root: Optional[Path] = None

		# Scene-wide collision system (owns the enable-matrix and runs pair checks).
		# Imported here to avoid a circular import at module load time.
		from MotionStudio.core.scene.collision_system import CollisionSystem
		self._collision_system: "CollisionSystem" = CollisionSystem(self)

		# Scene-wide IK service (drives RobotIK components off transform changes).
		from MotionStudio.core.robot.ik.robot_ik_system import RobotIKSystem
		self._robot_ik_system: "RobotIKSystem" = RobotIKSystem(self)

	@property
	def project_root(self) -> Optional[Path]:
		"""Filesystem root of the active editor project (meshes resolve relative to this)."""
		return self._project_root

	def set_project_root(self, path: Optional[Union[Path, str]]) -> None:
		"""Set the active project directory (or None if unknown)."""
		if path is None:
			self._project_root = None
		else:
			self._project_root = Path(path)

	@property
	def collision_system(self) -> "CollisionSystem":
		"""Returns the scene-wide collision system (always non-None)."""
		return self._collision_system

	@property
	def robot_ik_system(self) -> "RobotIKSystem":
		"""Returns the scene-wide robot IK system (always non-None)."""
		return self._robot_ik_system

	def entities(self) -> List[Entity]:
		return list(self._entities_by_id.values())

	def root_entities(self) -> List[Entity]:
		return list(self._roots)

	def find_by_id(self, entity_id: str) -> Optional[Entity]:
		return self._entities_by_id.get(entity_id)

	def create_entity(self, name: str = "Entity", parent: Optional[Entity] = None, entity_id: Optional[str] = None) -> Entity:
		entity = Entity(name=name)
		if entity_id is not None:
			entity.id = entity_id
		# Set scene reference
		entity._scene = self
		self._entities_by_id[entity.id] = entity
		if parent is None:
			self._roots.append(entity)
		else:
			parent.add_child(entity)
		self.events.entity_added.emit(entity)
		return entity

	def delete_entity(self, entity: Entity) -> None:
		# Recursively remove children first
		for child in list(entity.children):
			self.delete_entity(child)
		# Detach from parent or roots
		if entity.parent is not None:
			entity.parent.remove_child(entity)
		else:
			if entity in self._roots:
				self._roots.remove(entity)
		# Remove from map and emit
		if entity.id in self._entities_by_id:
			del self._entities_by_id[entity.id]
		self.events.entity_removed.emit(entity.id)

	def reparent(self, child: Entity, new_parent: Optional[Entity]) -> None:
		"""
		Reparent entity. Preservation of world transform is handled by systems
		that mirror to the renderer (Qt3D) where full matrices are available.
		Here we update the hierarchy and notify listeners.
		"""
		# Ensure child has scene reference
		if child._scene is None:
			child._scene = self
		# Detach from current
		if child.parent is None:
			if child in self._roots:
				self._roots.remove(child)
		else:
			child.parent.remove_child(child)
		# Attach to new
		if new_parent is None:
			child.parent = None
			self._roots.append(child)
		else:
			new_parent.add_child(child)
		self.events.entity_reparented.emit(child.id, new_parent.id if new_parent else None)

	def duplicate_entity(self, source: Entity, new_parent: Optional[Entity] = None) -> Entity:
		"""
		Duplicate an entity and its children, cloning component data via to_dict/from_dict.
		"""
		from MotionStudio.core.ecs.component import get_component_class

		def clone_entity(src: Entity, parent: Optional[Entity]) -> Entity:
			copy = self.create_entity(src.name, parent)
			# Clone components by round-tripping through dict
			for comp in src.components:
				comp_type_name = getattr(comp, "type_name", comp.__class__.__name__)
				comp_cls = get_component_class(comp_type_name)
				if comp_cls is None:
					continue
				data = comp.to_dict()
				new_comp = comp_cls.from_dict(data)
				copy.add_component(new_comp)
			for child in src.children:
				clone_entity(child, copy)
			return copy

		return clone_entity(source, new_parent if new_parent is not None else source.parent)

	def set_play_mode_manager(self, manager: "PlayModeManager") -> None:
		"""Set the PlayModeManager for this scene."""
		self._play_mode_manager = manager

	@property
	def play_mode_manager(self) -> Optional["PlayModeManager"]:
		"""Play Mode loop (None until the editor attaches one)."""
		return self._play_mode_manager

	@property
	def selection(self) -> Optional["SelectionModel"]:
		"""Editor selection (Hierarchy / viewport pick). None until wired by MainWindow."""
		return self._selection_model

	def set_selection_model(self, model: "SelectionModel") -> None:
		"""Attach the editor SelectionModel for component access via ``scene.selection``."""
		self._selection_model = model

	@property
	def viewport(self) -> Optional["ViewportService"]:
		"""Active 3D viewport queries. None until the VTK view is created."""
		return self._viewport_service

	def set_viewport_service(self, service: "ViewportService") -> None:
		"""Attach viewport query service (world/display projection, camera state)."""
		self._viewport_service = service



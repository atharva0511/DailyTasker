from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

from MotionStudio.core.ecs.entity import Entity

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene


class SelectionModel(QObject):
	"""
	Holds multi-entity selection with a primary (last-clicked) entity, plus optional
	path feature / waypoint sub-selection on the primary entity only.
	"""

	current_entity_changed = pyqtSignal(object)  # Entity | None (primary)
	selection_changed = pyqtSignal()  # set or order changed
	current_feature_changed = pyqtSignal(object)  # int | None
	current_waypoint_changed = pyqtSignal(object)  # Tuple[int, int] | None
	interaction_active_changed = pyqtSignal(bool)

	def __init__(self) -> None:
		super().__init__()
		self._scene: Optional["Scene"] = None
		self._selected_ids: List[str] = []
		self._current: Optional[Entity] = None
		self._current_feature_idx: Optional[int] = None
		self._current_waypoint: Optional[Tuple[int, int]] = None
		self._current_waypoint_entity_id: Optional[str] = None
		self._interaction_active: bool = False

	def set_scene(self, scene: "Scene") -> None:
		self._scene = scene

	@property
	def current(self) -> Optional[Entity]:
		"""Primary (last-clicked) selected entity."""
		return self._current

	@property
	def primary(self) -> Optional[Entity]:
		return self._current

	@property
	def current_feature_idx(self) -> Optional[int]:
		return self._current_feature_idx

	@property
	def current_waypoint(self) -> Optional[Tuple[int, int]]:
		return self._current_waypoint

	@property
	def current_waypoint_entity_id(self) -> Optional[str]:
		return self._current_waypoint_entity_id

	@property
	def interaction_active(self) -> bool:
		return self._interaction_active

	def selected_ids(self) -> List[str]:
		return list(self._selected_ids)

	def selected_entities(self) -> List[Entity]:
		out: List[Entity] = []
		if self._scene is None:
			return out
		for eid in self._selected_ids:
			ent = self._scene.find_by_id(eid)
			if ent is not None:
				out.append(ent)
		return out

	def is_entity_selected(self, entity: Optional[Entity]) -> bool:
		if entity is None:
			return False
		return entity.id in self._selected_ids

	def is_entity_id_selected(self, entity_id: str) -> bool:
		if not entity_id:
			return False
		return entity_id in self._selected_ids

	def set_interaction_active(self, active: bool) -> None:
		active = bool(active)
		if active == self._interaction_active:
			return
		self._interaction_active = active
		self.interaction_active_changed.emit(active)

	def _clear_subselection(self) -> None:
		if self._current_feature_idx is not None:
			self._current_feature_idx = None
			self.current_feature_changed.emit(None)
		if self._current_waypoint is not None:
			self._current_waypoint = None
			self._current_waypoint_entity_id = None
			self.current_waypoint_changed.emit(None)

	def _maybe_clear_subselection_for_multi(self) -> None:
		if len(self._selected_ids) != 1:
			self._clear_subselection()

	def set_selection(
		self,
		entities: List[Entity],
		*,
		primary: Optional[Entity] = None,
		clear_subselection: bool = True,
	) -> None:
		"""Replace the full selection. Last entity in ``entities`` is primary unless ``primary`` is set."""
		seen: set[str] = set()
		new_ids: List[str] = []
		for ent in entities:
			if ent is None or ent.id in seen:
				continue
			seen.add(ent.id)
			new_ids.append(ent.id)

		if primary is not None and primary.id in seen:
			pid = primary.id
			new_ids = [i for i in new_ids if i != pid] + [pid]
			primary_ent = self._resolve_entity(primary)
		elif new_ids:
			last_id = new_ids[-1]
			primary_ent = self._scene.find_by_id(last_id) if self._scene else None
			if primary_ent is None:
				for ent in entities:
					if ent is not None and ent.id == last_id:
						primary_ent = ent
						break
		else:
			primary_ent = None

		old_ids = self._selected_ids
		old_primary = self._current

		self._selected_ids = new_ids
		self._current = primary_ent if new_ids else None

		if clear_subselection:
			if old_primary is not self._current:
				self._clear_subselection()
			self._maybe_clear_subselection_for_multi()

		if old_ids != self._selected_ids:
			self.selection_changed.emit()
		if old_primary is not self._current:
			self.current_entity_changed.emit(self._current)

	def select_exclusive(self, entity: Optional[Entity], clear_subselection: bool = True) -> None:
		"""Plain click: select only this entity (or clear)."""
		if entity is None:
			self.clear(clear_subselection=clear_subselection)
			return
		self.set_selection([entity], primary=entity, clear_subselection=clear_subselection)

	def set_current(self, entity: Optional[Entity], clear_subselection: bool = True) -> None:
		"""Backward-compatible alias for single selection."""
		self.select_exclusive(entity, clear_subselection=clear_subselection)

	def toggle_entity(self, entity: Entity, *, make_primary: bool = True) -> None:
		"""Ctrl+click: add/remove from selection; removed entity cannot stay primary."""
		if entity is None:
			return
		if entity.id in self._selected_ids:
			new_ids = [i for i in self._selected_ids if i != entity.id]
			entities = self._resolve_entities(new_ids)
			primary = entities[-1] if entities else None
			self.set_selection(entities, primary=primary)
		else:
			entities = self._resolve_entities(self._selected_ids) + [entity]
			self.set_selection(entities, primary=entity if make_primary else None)

	def clear(self, clear_subselection: bool = True) -> None:
		old_primary = self._current
		had_selection = bool(self._selected_ids)
		self._selected_ids = []
		self._current = None
		if clear_subselection:
			self._clear_subselection()
		if had_selection:
			self.selection_changed.emit()
		if old_primary is not None:
			self.current_entity_changed.emit(None)

	def remove_entity_id(self, entity_id: str) -> None:
		"""Remove one id from the selection (e.g. after delete)."""
		if entity_id not in self._selected_ids:
			return
		remaining = [i for i in self._selected_ids if i != entity_id]
		entities = self._resolve_entities(remaining)
		self.set_selection(entities, primary=entities[-1] if entities else None)

	def _resolve_entity(self, entity: Entity) -> Optional[Entity]:
		if self._scene is not None:
			found = self._scene.find_by_id(entity.id)
			if found is not None:
				return found
		return entity

	def _resolve_entities(self, ids: List[str]) -> List[Entity]:
		out: List[Entity] = []
		if self._scene is None:
			return out
		for eid in ids:
			ent = self._scene.find_by_id(eid)
			if ent is not None:
				out.append(ent)
		return out

	def set_current_feature(self, feature_idx: Optional[int]) -> None:
		if feature_idx is not None:
			try:
				feature_idx = int(feature_idx)
			except Exception:
				feature_idx = None
		if feature_idx == self._current_feature_idx:
			return
		self._current_feature_idx = feature_idx
		if self._current_waypoint is not None:
			self._current_waypoint = None
			self._current_waypoint_entity_id = None
			self.current_waypoint_changed.emit(None)
		self.current_feature_changed.emit(feature_idx)

	def set_current_waypoint(self, feature_idx: Optional[int], waypoint_idx: Optional[int]) -> None:
		if feature_idx is not None and waypoint_idx is not None:
			try:
				feature_idx = int(feature_idx)
				waypoint_idx = int(waypoint_idx)
				new_waypoint = (feature_idx, waypoint_idx)
			except Exception:
				new_waypoint = None
		else:
			new_waypoint = None

		if new_waypoint == self._current_waypoint:
			return

		self._current_waypoint = new_waypoint
		if new_waypoint is None:
			self._current_waypoint_entity_id = None
		else:
			if self._current is not None and getattr(self._current, "name", "") != "__waypoint_proxy__":
				self._current_waypoint_entity_id = self._current.id
		self.current_waypoint_changed.emit(new_waypoint)

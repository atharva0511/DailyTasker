from __future__ import annotations

from MotionStudio.core.ecs.component import Component


def invoke_on_viewport_draw(scene) -> None:
	"""
	Call on_viewport_draw() on every component that overrides the base no-op.
	"""
	for entity in scene.entities():
		for component in entity.components:
			if type(component).on_viewport_draw is Component.on_viewport_draw:
				continue
			try:
				component.on_viewport_draw()
			except Exception as e:
				print(
					f"Error in on_viewport_draw on component "
					f"{component.__class__.__name__} on entity {entity.name}: {e}",
					flush=True,
				)

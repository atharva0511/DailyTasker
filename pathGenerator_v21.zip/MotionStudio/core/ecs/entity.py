from __future__ import annotations

from typing import List, Optional, Type, TypeVar, TYPE_CHECKING

from MotionStudio.core.ecs.component import Component
from MotionStudio.utils.ids import generate_uuid

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene

_C = TypeVar("_C", bound=Component)


class Entity:
	"""
	Core entity with hierarchical relationship and a bag of components.
	"""

	# Attributes whose assignment should broadcast ``scene.events.entity_changed``.
	# Keep this narrow: hierarchy attributes (parent/children/components) are
	# mutated by dedicated Scene APIs that already emit their own signals, so
	# emitting here too would double-fire and cause unnecessary UI rebuilds.
	_NOTIFY_ATTRS = frozenset({"name"})

	def __init__(self, name: str = "Entity") -> None:
		self.id: str = generate_uuid()
		self.name: str = name
		self.parent: Optional["Entity"] = None
		self.children: List["Entity"] = []
		self.components: List[Component] = []
		self._scene: Optional["Scene"] = None

	def __setattr__(self, name: str, value: object) -> None:
		# Detect a real change for notify-worthy attributes before the write.
		should_notify = False
		if name in Entity._NOTIFY_ATTRS:
			try:
				old = object.__getattribute__(self, name)
				should_notify = old != value
			except AttributeError:
				# First-time assignment (during __init__) - don't emit.
				should_notify = False

		super().__setattr__(name, value)

		if should_notify:
			scene = getattr(self, "_scene", None)
			if scene is not None:
				try:
					scene.events.entity_changed.emit(self.id)
				except Exception:
					pass

	@property
	def scene(self) -> Optional["Scene"]:
		"""Returns the Scene that owns this entity, or None if not attached to a scene."""
		return self._scene

	def add_child(self, child: "Entity") -> None:
		if child.parent is self:
			return
		if child.parent is not None:
			child.parent.remove_child(child)
		child.parent = self
		# Propagate scene reference to child if this entity has one
		if self._scene is not None and child._scene is None:
			child._scene = self._scene
		self.children.append(child)

	def remove_child(self, child: "Entity") -> None:
		if child in self.children:
			self.children.remove(child)
			child.parent = None

	def add_component(self, component: Component) -> None:
		component._entity = self
		self.components.append(component)

		# If play mode is active, call start() immediately (Unity-like behavior)
		if self._scene is not None and self._scene._play_mode_manager is not None:
			if self._scene._play_mode_manager.is_playing:
				try:
					if hasattr(component, 'start') and callable(getattr(component, 'start', None)):
						component.start()
				except Exception as e:
					print(f"Error starting component {component.__class__.__name__} on entity {self.name}: {e}", flush=True)

		# Broadcast that this entity's component set changed. Subscribers such as
		# the Inspector, VtkSceneRoot, and the Collision Matrix panel rebuild off
		# of this signal, so emitting here means callers no longer have to
		# remember to fire entity_changed after every add_component() call.
		if self._scene is not None:
			try:
				self._scene.events.entity_changed.emit(self.id)
			except Exception:
				pass

	def remove_component(self, component: Component) -> None:
		if component in self.components:
			component._entity = None
			self.components.remove(component)
			if self._scene is not None:
				try:
					self._scene.events.entity_changed.emit(self.id)
				except Exception:
					pass

	def get_component(self, comp_type: Type[_C]) -> Optional[_C]:
		for comp in self.components:
			if isinstance(comp, comp_type):
				return comp
		return None



from .component import Component, register_component, get_component_class, get_registered_components
from .entity import Entity

__all__ = ["Component", "register_component", "get_component_class", "get_registered_components", "Entity"]



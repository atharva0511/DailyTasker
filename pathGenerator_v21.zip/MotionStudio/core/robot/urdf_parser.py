from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree

from MotionStudio.core.robot.frame_math import parse_rpy, parse_xyz


@dataclass
class UrdfGeometry:
	filename: str = ""
	origin_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	origin_rpy: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	geom_type: str = "mesh"  # mesh | box | cylinder | sphere


@dataclass
class UrdfInertial:
	mass: float = 0.0
	origin_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	origin_rpy: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	ixx: float = 0.0
	ixy: float = 0.0
	ixz: float = 0.0
	iyy: float = 0.0
	iyz: float = 0.0
	izz: float = 0.0


@dataclass
class UrdfLink:
	name: str
	visuals: List[UrdfGeometry] = field(default_factory=list)
	collisions: List[UrdfGeometry] = field(default_factory=list)
	inertial: Optional[UrdfInertial] = None


@dataclass
class UrdfJointLimits:
	lower: float = 0.0
	upper: float = 0.0
	effort: float = 0.0
	velocity: float = 0.0


@dataclass
class UrdfJointDynamics:
	damping: float = 0.0
	friction: float = 0.0


@dataclass
class UrdfJoint:
	name: str
	joint_type: str
	parent_link: str
	child_link: str
	origin_xyz: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	origin_rpy: Tuple[float, float, float] = (0.0, 0.0, 0.0)
	axis_xyz: Tuple[float, float, float] = (1.0, 0.0, 0.0)
	limits: Optional[UrdfJointLimits] = None
	dynamics: Optional[UrdfJointDynamics] = None


@dataclass
class UrdfTransmission:
	name: str
	joint_name: str
	actuator_name: str = ""
	mechanical_reduction: float = 1.0
	transmission_type: str = ""


@dataclass
class UrdfModel:
	robot_name: str
	links: Dict[str, UrdfLink]
	joints: Dict[str, UrdfJoint]
	transmissions: List[UrdfTransmission]
	source_path: Path

	def child_joints_by_parent(self) -> Dict[str, List[UrdfJoint]]:
		out: Dict[str, List[UrdfJoint]] = {}
		for joint in self.joints.values():
			out.setdefault(joint.parent_link, []).append(joint)
		return out

	def actuated_joint_names(self) -> List[str]:
		names: List[str] = []
		for j in self.joints.values():
			if j.joint_type.lower() in ("revolute", "continuous", "prismatic"):
				names.append(j.name)
		return names


def _parse_origin(elem) -> Tuple[Tuple[float, float, float], Tuple[float, float, float]]:
	if elem is None:
		return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
	origin = elem.find("origin")
	if origin is None:
		return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
	return parse_xyz(origin.attrib.get("xyz")), parse_rpy(origin.attrib.get("rpy"))


def _parse_geometry_block(parent_elem) -> Optional[UrdfGeometry]:
	"""
	Parse a URDF ``<visual>`` or ``<collision>`` element.

	Origin is on the parent; ``<mesh>`` / primitives live under ``<geometry>``.
	"""
	if parent_elem is None:
		return None
	xyz, rpy = _parse_origin(parent_elem)
	geom_elem = parent_elem.find("geometry")
	if geom_elem is None:
		return None
	mesh = geom_elem.find("mesh")
	if mesh is not None:
		fn = mesh.attrib.get("filename", "")
		return UrdfGeometry(filename=fn, origin_xyz=xyz, origin_rpy=rpy, geom_type="mesh")
	box = geom_elem.find("box")
	if box is not None:
		size = parse_xyz(box.attrib.get("size"), (1.0, 1.0, 1.0))
		return UrdfGeometry(filename="", origin_xyz=xyz, origin_rpy=rpy, geom_type="box")
	cyl = geom_elem.find("cylinder")
	if cyl is not None:
		return UrdfGeometry(filename="", origin_xyz=xyz, origin_rpy=rpy, geom_type="cylinder")
	sph = geom_elem.find("sphere")
	if sph is not None:
		return UrdfGeometry(filename="", origin_xyz=xyz, origin_rpy=rpy, geom_type="sphere")
	return None


def _parse_inertial(link_elem) -> Optional[UrdfInertial]:
	inertial_elem = link_elem.find("inertial")
	if inertial_elem is None:
		return None
	xyz, rpy = _parse_origin(inertial_elem)
	mass_elem = inertial_elem.find("mass")
	mass = float(mass_elem.attrib.get("value", "0")) if mass_elem is not None else 0.0
	inertia_elem = inertial_elem.find("inertia")
	ixx = ixy = ixz = iyy = iyz = izz = 0.0
	if inertia_elem is not None:
		ixx = float(inertia_elem.attrib.get("ixx", "0"))
		ixy = float(inertia_elem.attrib.get("ixy", "0"))
		ixz = float(inertia_elem.attrib.get("ixz", "0"))
		iyy = float(inertia_elem.attrib.get("iyy", "0"))
		iyz = float(inertia_elem.attrib.get("iyz", "0"))
		izz = float(inertia_elem.attrib.get("izz", "0"))
	return UrdfInertial(
		mass=mass,
		origin_xyz=xyz,
		origin_rpy=rpy,
		ixx=ixx,
		ixy=ixy,
		ixz=ixz,
		iyy=iyy,
		iyz=iyz,
		izz=izz,
	)


def _parse_link(link_elem) -> UrdfLink:
	name = link_elem.attrib.get("name", "link")
	link = UrdfLink(name=name)
	for vis in link_elem.findall("visual"):
		g = _parse_geometry_block(vis)
		if g is not None:
			link.visuals.append(g)
	for col in link_elem.findall("collision"):
		g = _parse_geometry_block(col)
		if g is not None:
			link.collisions.append(g)
	link.inertial = _parse_inertial(link_elem)
	return link


def _parse_joint(joint_elem) -> UrdfJoint:
	name = joint_elem.attrib.get("name", "joint")
	jt = joint_elem.attrib.get("type", "fixed")
	parent = joint_elem.find("parent")
	child = joint_elem.find("child")
	parent_link = parent.attrib.get("link", "") if parent is not None else ""
	child_link = child.attrib.get("link", "") if child is not None else ""
	xyz, rpy = _parse_origin(joint_elem)
	axis_elem = joint_elem.find("axis")
	axis = parse_xyz(axis_elem.attrib.get("xyz") if axis_elem is not None else None, (1.0, 0.0, 0.0))
	limits = None
	lim_elem = joint_elem.find("limit")
	if lim_elem is not None:
		limits = UrdfJointLimits(
			lower=float(lim_elem.attrib.get("lower", "0")),
			upper=float(lim_elem.attrib.get("upper", "0")),
			effort=float(lim_elem.attrib.get("effort", "0")),
			velocity=float(lim_elem.attrib.get("velocity", "0")),
		)
	dynamics = None
	dyn_elem = joint_elem.find("dynamics")
	if dyn_elem is not None:
		dynamics = UrdfJointDynamics(
			damping=float(dyn_elem.attrib.get("damping", "0")),
			friction=float(dyn_elem.attrib.get("friction", "0")),
		)
	return UrdfJoint(
		name=name,
		joint_type=jt,
		parent_link=parent_link,
		child_link=child_link,
		origin_xyz=xyz,
		origin_rpy=rpy,
		axis_xyz=axis,
		limits=limits,
		dynamics=dynamics,
	)


def _parse_transmission(elem) -> UrdfTransmission:
	name = elem.attrib.get("name", "")
	joint_elem = elem.find("joint")
	joint_name = joint_elem.attrib.get("name", "") if joint_elem is not None else ""
	act_elem = elem.find("actuator")
	act_name = act_elem.attrib.get("name", "") if act_elem is not None else ""
	reduction = 1.0
	if act_elem is not None:
		mr = act_elem.find("mechanicalReduction")
		if mr is not None and mr.text:
			try:
				reduction = float(mr.text.strip())
			except ValueError:
				pass
	return UrdfTransmission(
		name=name,
		joint_name=joint_name,
		actuator_name=act_name,
		mechanical_reduction=reduction,
		transmission_type=elem.findtext("type", default=""),
	)


def parse_urdf_file(path: Path) -> UrdfModel:
	path = path.resolve()
	if path.suffix.lower() == ".xacro":
		raise ValueError("Xacro files are not supported. Export a flattened .urdf first.")
	if path.suffix.lower() != ".urdf":
		raise ValueError(f"Not a URDF file: {path}")

	tree = ElementTree.parse(path)
	root = tree.getroot()
	if root.tag != "robot":
		raise ValueError("Root element must be <robot>")

	robot_name = root.attrib.get("name", path.stem)
	links: Dict[str, UrdfLink] = {}
	joints: Dict[str, UrdfJoint] = {}
	transmissions: List[UrdfTransmission] = []

	for link_elem in root.findall("link"):
		link = _parse_link(link_elem)
		links[link.name] = link
	for joint_elem in root.findall("joint"):
		joint = _parse_joint(joint_elem)
		joints[joint.name] = joint
	for trans_elem in root.findall("transmission"):
		transmissions.append(_parse_transmission(trans_elem))

	return UrdfModel(
		robot_name=robot_name,
		links=links,
		joints=joints,
		transmissions=transmissions,
		source_path=path,
	)


def inertial_to_dict(inertial: Optional[UrdfInertial]) -> Optional[Dict[str, Any]]:
	if inertial is None:
		return None
	return {
		"mass": inertial.mass,
		"origin_xyz_m": list(inertial.origin_xyz),
		"origin_rpy_rad": list(inertial.origin_rpy),
		"ixx": inertial.ixx,
		"ixy": inertial.ixy,
		"ixz": inertial.ixz,
		"iyy": inertial.iyy,
		"iyz": inertial.iyz,
		"izz": inertial.izz,
	}


def joint_to_dict(j: UrdfJoint) -> Dict[str, Any]:
	d: Dict[str, Any] = {
		"name": j.name,
		"type": j.joint_type,
		"parent_link": j.parent_link,
		"child_link": j.child_link,
		"origin_xyz_m": list(j.origin_xyz),
		"origin_rpy_rad": list(j.origin_rpy),
		"axis_xyz": list(j.axis_xyz),
	}
	if j.limits is not None:
		d["limits"] = {
			"lower": j.limits.lower,
			"upper": j.limits.upper,
			"effort": j.limits.effort,
			"velocity": j.limits.velocity,
		}
	if j.dynamics is not None:
		d["dynamics"] = {"damping": j.dynamics.damping, "friction": j.dynamics.friction}
	return d


def transmission_to_dict(t: UrdfTransmission) -> Dict[str, Any]:
	return {
		"name": t.name,
		"joint_name": t.joint_name,
		"actuator_name": t.actuator_name,
		"mechanical_reduction": t.mechanical_reduction,
		"type": t.transmission_type,
	}

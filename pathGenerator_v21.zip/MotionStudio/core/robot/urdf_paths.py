from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse


def detect_package_root(urdf_path: Path) -> Path:
	"""
	ROS-style package root: parent of ``urdf/`` when URDF lives in ``.../pkg/urdf/file.urdf``.
	Falls back to URDF parent directory.
	"""
	urdf_path = urdf_path.resolve()
	parent = urdf_path.parent
	if parent.name.lower() == "urdf":
		return parent.parent
	return parent


def extract_package_name_from_model(model) -> str:
	"""Return the ``package://`` name used in mesh URIs (e.g. ``ur_description``)."""
	for link in model.links.values():
		for geom in link.visuals + link.collisions:
			raw = (geom.filename or "").strip()
			if raw.startswith("package://"):
				rest = raw[len("package://") :]
				pkg, _, _ = rest.partition("/")
				if pkg:
					return pkg
	return detect_package_root(model.source_path).name


def build_package_roots(
	package_name: str,
	package_folder: Path | None,
	urdf_path: Path,
) -> dict[str, Path]:
	"""
	Build the ``package_roots`` map for :func:`resolve_mesh_uri`.

	``package_folder`` should be the ROS package root (contains ``meshes/``).
	"""
	if package_folder is not None:
		folder = package_folder.resolve()
		if folder.is_dir():
			return {package_name: folder}
	roots: dict[str, Path] = {}
	auto = detect_package_root(urdf_path)
	roots[package_name] = auto
	if auto.name != package_name:
		sibling = auto.parent / package_name
		if sibling.is_dir():
			roots[package_name] = sibling
	return roots


def resolve_mesh_uri(mesh_filename: str, urdf_path: Path, package_roots: dict[str, Path] | None = None) -> Path:
	"""
	Resolve URDF mesh filename to an absolute filesystem path.

	Supports ``package://pkg/...``, ``file://``, and paths relative to the URDF file.
	"""
	raw = (mesh_filename or "").strip()
	if not raw:
		raise FileNotFoundError("Empty mesh filename")

	if raw.startswith("package://"):
		rest = raw[len("package://") :]
		pkg, _, rel = rest.partition("/")
		if not pkg:
			raise FileNotFoundError(f"Invalid package URI: {raw}")
		if package_roots and pkg in package_roots:
			root = package_roots[pkg]
		else:
			roots = build_package_roots(pkg, None, urdf_path)
			root = roots.get(pkg, detect_package_root(urdf_path))
		return (root / rel).resolve()

	if raw.startswith("file://"):
		parsed = urlparse(raw)
		return Path(parsed.path).resolve()

	p = Path(raw)
	if p.is_absolute():
		return p.resolve()
	return (urdf_path.parent / p).resolve()

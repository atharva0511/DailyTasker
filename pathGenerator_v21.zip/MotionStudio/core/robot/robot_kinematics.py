from __future__ import annotations

from typing import Dict, List, Optional, TYPE_CHECKING

from PyQt6.QtGui import QVector3D

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
from MotionStudio.core.robot.frame_math import decompose_matrix_to_prs, joint_local_transform

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
	from MotionStudio.core.ecs.entity import Entity


def _joint_child_map(robot: "RobotDescriptionComponent") -> Dict[str, Dict]:
	"""parent_link -> list of joint records (child joints)."""
	out: Dict[str, List[Dict]] = {}
	for j in robot.joints:
		parent = j.get("parent_link", "")
		out.setdefault(parent, []).append(j)
	return out


def _find_link_entity(robot_entity: "Entity", link_name: str) -> Optional["Entity"]:
	from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent

	def walk(e: "Entity") -> Optional["Entity"]:
		ul = e.get_component(UrdfLinkComponent)
		if ul is not None and ul.link_name == link_name:
			return e
		for ch in e.children:
			found = walk(ch)
			if found is not None:
				return found
		return None

	for ch in robot_entity.children:
		found = walk(ch)
		if found is not None:
			return found
	return walk(robot_entity)


def update_robot_fk(robot: "RobotDescriptionComponent") -> None:
	"""
	Forward kinematics: write each child link's local TransformComponent from joint state.
	"""
	entity = robot.entity
	if entity is None or entity.scene is None:
		return

	robot._fk_updating = True
	try:
		children_by_parent = _joint_child_map(robot)
		root_link = robot.root_link

		def apply_joint(joint_rec: Dict) -> None:
			child_name = joint_rec.get("child_link", "")
			if not child_name:
				return
			child_ent = _find_link_entity(entity, child_name)
			if child_ent is None:
				return
			t = child_ent.get_component(TransformComponent)
			if t is None:
				return
			jname = joint_rec.get("name", "")
			q = float(robot.joint_positions.get(jname, 0.0))
			origin_xyz = tuple(joint_rec.get("origin_xyz_m", [0, 0, 0])[:3])
			origin_rpy = tuple(joint_rec.get("origin_rpy_rad", [0, 0, 0])[:3])
			axis = tuple(joint_rec.get("axis_xyz", [0, 0, 1])[:3])
			jt = joint_rec.get("type", "fixed")
			m = joint_local_transform(jt, origin_xyz, origin_rpy, axis, q)
			pos, quat, scale = decompose_matrix_to_prs(m)
			t.position = pos
			t.rotation_quat = quat
			t.scale3d = scale

		def dfs(link_name: str) -> None:
			for joint_rec in children_by_parent.get(link_name, []):
				apply_joint(joint_rec)
				dfs(joint_rec.get("child_link", ""))

		dfs(root_link)

		# One transform signal on the robot root: VTK syncs the full subtree
		# recursively. Per-link signals used to fire here and each one triggered
		# a full-scene collision sweep, which scaled badly with multiple robots.
		scene = entity.scene
		try:
			scene.events.entity_transform_changed.emit(entity.id)
		except Exception:
			pass
		try:
			scene.collision_system.request_collision_update()
		except Exception:
			pass
	finally:
		robot._fk_updating = False


def resolve_link_entity_ids(robot: "RobotDescriptionComponent") -> None:
	"""Fill links[].entity_id from link_name after scene load."""
	entity = robot.entity
	if entity is None:
		return
	for rec in robot.links:
		name = rec.get("name", "")
		if not name:
			continue
		ent = _find_link_entity(entity, name)
		if ent is not None:
			rec["entity_id"] = ent.id

from __future__ import annotations

import shutil
from pathlib import Path
from typing import List, Optional, Tuple

from MotionStudio.core.robot.frame_math import make_transform


def _origin_matrix_meter(
	xyz_m: Tuple[float, float, float],
	rpy_rad: Tuple[float, float, float],
) -> "object":
	"""URDF collision origins in metres (collider runtime scale handles mm)."""
	return make_transform(xyz_m, rpy_rad, translation_scale=1.0)


def _load_trimesh(mesh_path: Path):
	try:
		import trimesh  # type: ignore
	except ImportError as exc:
		raise OSError("trimesh is required for URDF mesh preprocessing") from exc

	mesh = trimesh.load(str(mesh_path), force="mesh")
	if isinstance(mesh, trimesh.Scene):
		mesh = mesh.dump(concatenate=True)
	return mesh


def bake_collision_origin(
	mesh_path: Path,
	origin_xyz_m: Tuple[float, float, float],
	origin_rpy_rad: Tuple[float, float, float],
	dest_path: Path,
) -> Path:
	"""Bake URDF collision origin in metre-space vertices (no mm scaling)."""
	dest_path.parent.mkdir(parents=True, exist_ok=True)
	mesh = _load_trimesh(mesh_path)
	mesh.apply_transform(_origin_matrix_meter(origin_xyz_m, origin_rpy_rad))
	mesh.export(str(dest_path))
	return dest_path


def merge_collision_geometries(
	source_paths: List[Tuple[Path, Tuple[float, float, float], Tuple[float, float, float]]],
	dest_path: Path,
) -> Optional[Path]:
	if not source_paths:
		return None
	if len(source_paths) == 1:
		src, xyz, rpy = source_paths[0]
		if xyz == (0.0, 0.0, 0.0) and rpy == (0.0, 0.0, 0.0):
			return copy_mesh_raw(src, dest_path)
		return bake_collision_origin(src, xyz, rpy, dest_path)

	meshes = []
	for src, xyz, rpy in source_paths:
		m = _load_trimesh(src)
		m.apply_transform(_origin_matrix_meter(xyz, rpy))
		meshes.append(m)

	try:
		import trimesh  # type: ignore
	except ImportError as exc:
		raise OSError("trimesh is required for URDF mesh preprocessing") from exc

	combined = trimesh.util.concatenate(meshes)
	dest_path.parent.mkdir(parents=True, exist_ok=True)
	combined.export(str(dest_path))
	return dest_path


def copy_mesh_raw(source: Path, dest: Path) -> Path:
	dest.parent.mkdir(parents=True, exist_ok=True)
	if source.resolve() != dest.resolve():
		shutil.copy2(source, dest)
	return dest

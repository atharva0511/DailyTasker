"""URDF parsing, import, and robot kinematics for MotionStudio."""

__all__ = ["import_urdf_into_scene"]


def __getattr__(name: str):
	if name == "import_urdf_into_scene":
		from MotionStudio.core.robot.urdf_importer import import_urdf_into_scene

		return import_urdf_into_scene
	raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

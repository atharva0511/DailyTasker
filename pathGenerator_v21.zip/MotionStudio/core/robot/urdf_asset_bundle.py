from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from MotionStudio.core.robot.urdf_mesh_preprocess import copy_mesh_raw, merge_collision_geometries
from MotionStudio.core.robot.urdf_parser import UrdfModel
from MotionStudio.core.robot.urdf_paths import (
	build_package_roots,
	extract_package_name_from_model,
	resolve_mesh_uri,
)
from MotionStudio.core.robot.urdf_visual_assets import import_urdf_visual_mesh, import_urdf_visual_meshes_merged


@dataclass
class BundledLinkMeshes:
	visual_project_path: str = ""
	collision_project_path: str = ""


@dataclass
class UrdfAssetBundle:
	robot_dir_name: str
	urdf_project_path: str
	link_meshes: Dict[str, BundledLinkMeshes] = field(default_factory=dict)
	urdf_abs_path: Path = Path()
	# Project-relative path to the local copy of the source package tree
	# (so ``package://`` URIs resolve inside the project, no external deps).
	local_package_rel: str = ""


def _safe_stem(name: str) -> str:
	return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)


def _package_relpath(raw: str) -> Optional[str]:
	"""Return the path part after ``package://<pkg>/`` (or None for non-package URIs)."""
	raw = (raw or "").strip()
	if raw.startswith("package://"):
		rest = raw[len("package://") :]
		_pkg, _, rel = rest.partition("/")
		if rel:
			return rel
	return None


def _localize_source_meshes(
	model: UrdfModel,
	package_roots: dict[str, Path],
	local_root: Path,
) -> bool:
	"""Copy every ``package://`` source mesh into ``local_root`` preserving its
	package-relative layout, so the project resolves them without the original
	ROS package. Returns True if the local package root holds (or already held)
	the referenced meshes.
	"""
	copied_any = False
	for link in model.links.values():
		for geom in link.visuals + link.collisions:
			raw = (geom.filename or "").strip()
			rel = _package_relpath(raw)
			if rel is None:
				continue
			try:
				abs_src = resolve_mesh_uri(raw, model.source_path, package_roots)
			except FileNotFoundError:
				continue
			if not abs_src.is_file():
				continue
			dest = local_root / rel
			try:
				if dest.resolve() == abs_src.resolve():
					# Already resolving from the local copy (e.g. on reload).
					copied_any = True
					continue
			except OSError:
				pass
			dest.parent.mkdir(parents=True, exist_ok=True)
			try:
				shutil.copy2(abs_src, dest)
				copied_any = True
				# OBJ meshes have a hard dependency on their sibling .mtl.
				if abs_src.suffix.lower() == ".obj":
					mtl = abs_src.with_suffix(".mtl")
					if mtl.is_file():
						shutil.copy2(mtl, dest.with_suffix(".mtl"))
			except OSError:
				pass
	return copied_any


def bundle_urdf_assets(
	model: UrdfModel,
	project_root: Path,
	*,
	package_name: str | None = None,
	package_folder: Path | None = None,
) -> UrdfAssetBundle:
	"""
	Copy URDF and meshes into ``<project>/robots/<robot_name>/`` and preprocess geometry.
	"""
	project_root = project_root.resolve()
	robot_dir_name = _safe_stem(model.robot_name) or model.source_path.stem
	robots_dir = project_root / "robots" / robot_dir_name
	robots_dir.mkdir(parents=True, exist_ok=True)

	urdf_dest = robots_dir / model.source_path.name
	# Skip the copy when re-bundling an already-local URDF (e.g. Reload Meshes),
	# which would otherwise raise SameFileError.
	try:
		same = model.source_path.resolve() == urdf_dest.resolve()
	except OSError:
		same = False
	if not same:
		try:
			shutil.copy2(model.source_path, urdf_dest)
		except shutil.SameFileError:
			pass
	urdf_rel = urdf_dest.relative_to(project_root).as_posix()

	pkg_name = package_name or extract_package_name_from_model(model)
	package_roots = build_package_roots(
		pkg_name,
		package_folder,
		model.source_path,
	)

	# Copy referenced source meshes into the project so package:// URIs resolve
	# locally (keeps the project folder self-contained, no external paths).
	local_pkg_root = robots_dir / "package"
	local_package_rel = ""
	if _localize_source_meshes(model, package_roots, local_pkg_root):
		local_package_rel = local_pkg_root.relative_to(project_root).as_posix()

	vis_import_dir = robots_dir / "meshes" / "visual"
	link_meshes: Dict[str, BundledLinkMeshes] = {}

	for link_name, link in model.links.items():
		bundle = BundledLinkMeshes()
		vis_sources: List[Tuple[Path, Tuple[float, float, float], Tuple[float, float, float]]] = []
		for vis in link.visuals:
			if vis.geom_type != "mesh" or not vis.filename:
				continue
			try:
				abs_path = resolve_mesh_uri(vis.filename, model.source_path, package_roots)
			except FileNotFoundError:
				continue
			if abs_path.is_file():
				vis_sources.append((abs_path, vis.origin_xyz, vis.origin_rpy))

		if vis_sources:
			if len(vis_sources) == 1:
				src, xyz, rpy = vis_sources[0]
				bundle.visual_project_path = import_urdf_visual_mesh(
					project_root,
					src,
					xyz,
					rpy,
					import_dir=vis_import_dir,
				)
			else:
				bundle.visual_project_path = import_urdf_visual_meshes_merged(
					project_root,
					vis_sources,
					import_dir=vis_import_dir,
					output_stem=_safe_stem(link_name),
				)

		col_sources: List[Tuple[Path, Tuple[float, float, float], Tuple[float, float, float]]] = []
		for col in link.collisions:
			if col.geom_type != "mesh" or not col.filename:
				continue
			try:
				abs_path = resolve_mesh_uri(col.filename, model.source_path, package_roots)
			except FileNotFoundError:
				continue
			if abs_path.is_file():
				col_sources.append((abs_path, col.origin_xyz, col.origin_rpy))

		if col_sources:
			col_dir = robots_dir / "meshes" / "collision"
			baked_col = col_dir / f"{_safe_stem(link_name)}.stl"
			if len(col_sources) == 1 and col_sources[0][1] == (0.0, 0.0, 0.0) and col_sources[0][2] == (0.0, 0.0, 0.0):
				copy_mesh_raw(col_sources[0][0], baked_col)
			else:
				merge_collision_geometries(col_sources, baked_col)
			bundle.collision_project_path = baked_col.relative_to(project_root).as_posix()

		if bundle.visual_project_path or bundle.collision_project_path:
			link_meshes[link_name] = bundle

	return UrdfAssetBundle(
		robot_dir_name=robot_dir_name,
		urdf_project_path=urdf_rel,
		link_meshes=link_meshes,
		urdf_abs_path=urdf_dest,
		local_package_rel=local_package_rel,
	)

from __future__ import annotations

import math
from typing import Iterable, Tuple

import numpy as np
from PyQt6.QtGui import QMatrix3x3, QMatrix4x4, QQuaternion, QVector3D

METER_TO_MM = 1000.0


def parse_xyz(text: str | None, default: Tuple[float, float, float] = (0.0, 0.0, 0.0)) -> Tuple[float, float, float]:
	if not text:
		return default
	parts = text.strip().split()
	if len(parts) < 3:
		return default
	try:
		return float(parts[0]), float(parts[1]), float(parts[2])
	except ValueError:
		return default


def parse_rpy(text: str | None, default: Tuple[float, float, float] = (0.0, 0.0, 0.0)) -> Tuple[float, float, float]:
	return parse_xyz(text, default)


def rpy_to_rotation_matrix(rpy: Tuple[float, float, float]) -> np.ndarray:
	"""URDF fixed-axis roll-pitch-yaw: R = Rz(yaw) @ Ry(pitch) @ Rx(roll)."""
	roll, pitch, yaw = rpy
	cr, sr = math.cos(roll), math.sin(roll)
	cp, sp = math.cos(pitch), math.sin(pitch)
	cy, sy = math.cos(yaw), math.sin(yaw)
	rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]], dtype=np.float64)
	ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]], dtype=np.float64)
	rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]], dtype=np.float64)
	return rz @ ry @ rx


def axis_angle_rotation_matrix(axis: Tuple[float, float, float], angle_rad: float) -> np.ndarray:
	ax = np.array(axis, dtype=np.float64)
	norm = np.linalg.norm(ax)
	if norm < 1e-12:
		return np.eye(3, dtype=np.float64)
	ax = ax / norm
	x, y, z = ax
	c = math.cos(angle_rad)
	s = math.sin(angle_rad)
	t = 1.0 - c
	return np.array(
		[
			[t * x * x + c, t * x * y - s * z, t * x * z + s * y],
			[t * x * y + s * z, t * y * y + c, t * y * z - s * x],
			[t * x * z - s * y, t * y * z + s * x, t * z * z + c],
		],
		dtype=np.float64,
	)


def make_transform(
	xyz_m: Tuple[float, float, float],
	rpy_rad: Tuple[float, float, float],
	*,
	translation_scale: float = METER_TO_MM,
) -> np.ndarray:
	"""4x4 homogeneous transform (column-vector convention)."""
	t = np.eye(4, dtype=np.float64)
	t[:3, :3] = rpy_to_rotation_matrix(rpy_rad)
	t[0, 3] = xyz_m[0] * translation_scale
	t[1, 3] = xyz_m[1] * translation_scale
	t[2, 3] = xyz_m[2] * translation_scale
	return t


def multiply_transforms(*matrices: np.ndarray) -> np.ndarray:
	out = np.eye(4, dtype=np.float64)
	for m in matrices:
		out = out @ m
	return out


def matrix_to_qmatrix(m: np.ndarray) -> QMatrix4x4:
	qm = QMatrix4x4()
	for r in range(4):
		for c in range(4):
			qm[r, c] = float(m[r, c])
	return qm


def decompose_matrix_to_prs(m: np.ndarray) -> Tuple[QVector3D, QQuaternion, QVector3D]:
	"""Decompose 4x4 into translation (mm), rotation quat, uniform scale (1)."""
	pos = QVector3D(float(m[0, 3]), float(m[1, 3]), float(m[2, 3]))
	rot3 = m[:3, :3].astype(np.float64)
	# Remove scale if present
	for i in range(3):
		col_len = np.linalg.norm(rot3[:, i])
		if col_len > 1e-12:
			rot3[:, i] /= col_len
	rm = QMatrix3x3()
	for r in range(3):
		for c in range(3):
			rm[r, c] = float(rot3[r, c])
	quat = QQuaternion.fromRotationMatrix(rm)
	try:
		length = quat.length()
		if length > 1e-12 and abs(length - 1.0) > 1e-6:
			quat.normalize()
	except Exception:
		pass
	return pos, quat, QVector3D(1.0, 1.0, 1.0)


def joint_local_transform(
	joint_type: str,
	origin_xyz_m: Tuple[float, float, float],
	origin_rpy_rad: Tuple[float, float, float],
	axis_xyz: Tuple[float, float, float],
	q: float,
) -> np.ndarray:
	t_origin = make_transform(origin_xyz_m, origin_rpy_rad)
	jt = (joint_type or "fixed").lower()
	if jt in ("fixed", ""):
		return t_origin
	if jt in ("revolute", "continuous"):
		r_motion = np.eye(4, dtype=np.float64)
		r_motion[:3, :3] = axis_angle_rotation_matrix(axis_xyz, q)
		return multiply_transforms(t_origin, r_motion)
	if jt == "prismatic":
		ax = np.array(axis_xyz, dtype=np.float64)
		n = np.linalg.norm(ax)
		if n < 1e-12:
			ax = np.array([1.0, 0.0, 0.0])
		else:
			ax = ax / n
		t_motion = np.eye(4, dtype=np.float64)
		t_motion[0, 3] = ax[0] * q * METER_TO_MM
		t_motion[1, 3] = ax[1] * q * METER_TO_MM
		t_motion[2, 3] = ax[2] * q * METER_TO_MM
		return multiply_transforms(t_origin, t_motion)
	return t_origin

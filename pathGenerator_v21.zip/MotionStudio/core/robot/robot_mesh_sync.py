from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Optional

from PyQt6.QtGui import QColor

from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
from MotionStudio.core.robot.collision_groups import (
	apply_urdf_collision_group_defaults,
	ensure_link_collider_group_fields,
)
from MotionStudio.core.robot.urdf_asset_bundle import UrdfAssetBundle, bundle_urdf_assets
from MotionStudio.core.robot.urdf_importer import COLLIDER_METER_TO_MM_SCALE, _build_link_records
from MotionStudio.core.robot.urdf_parser import parse_urdf_file
from MotionStudio.core.robot.urdf_paths import extract_package_name_from_model
from MotionStudio.utils.mesh_assets import has_source_material_sidecar, resolve_mesh_path_for_read

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def _resolve_urdf_abs(project_root: Path, urdf_path: str) -> Path:
	abs_path = resolve_mesh_path_for_read(project_root, urdf_path)
	if not abs_path:
		raise FileNotFoundError(f"URDF not found: {urdf_path}")
	p = Path(abs_path)
	if not p.is_file():
		raise FileNotFoundError(f"URDF not found: {urdf_path}")
	return p


def _apply_mesh_to_entity(
	entity: "Entity",
	project_root: Path,
	visual_path: str,
	collision_path: str,
	robot_name: str,
) -> None:
	if visual_path:
		mesh = entity.get_component(MeshComponent)
		use_src = has_source_material_sidecar(project_root, visual_path)
		if mesh is None:
			entity.add_component(
				MeshComponent(
					shape="custom",
					custom_path=visual_path,
					source_material=use_src,
					color=QColor(180, 180, 180),
				)
			)
		else:
			mesh.shape = "custom"
			mesh.custom_path = visual_path
			mesh.source_material = use_src

	if collision_path:
		col = entity.get_component(ColliderComponent)
		if col is None:
			entity.add_component(
				ColliderComponent(
					collider_from_mesh_component=False,
					collider_mesh_path=collision_path,
					render_collider=True,
					scale=COLLIDER_METER_TO_MM_SCALE,
					repaint_on_collision=True,
					use_collision_group=True,
					collision_group_name=robot_name,
				)
			)
		else:
			col.collider_from_mesh_component = False
			col.collider_mesh_path = collision_path
			col.scale = COLLIDER_METER_TO_MM_SCALE
			ensure_link_collider_group_fields(col, robot_name)


def reload_robot_link_meshes(robot: "RobotDescriptionComponent") -> int:
	"""
	Re-resolve mesh URIs from ``package_folder`` and assign Mesh/Collider components on link entities.

	Returns the number of links that received at least one mesh path.
	"""
	entity = robot.entity
	scene = entity.scene if entity is not None else None
	if entity is None or scene is None or scene.project_root is None:
		raise RuntimeError("Robot must be in a scene with an open project.")

	project_root = scene.project_root
	urdf_abs = _resolve_urdf_abs(project_root, robot.urdf_path)
	model = parse_urdf_file(urdf_abs)

	pkg_name = robot.package_name or extract_package_name_from_model(model)
	pkg_folder: Optional[Path] = None
	if robot.package_folder.strip():
		pkg_folder = Path(robot.package_folder.strip()).expanduser()
		if not pkg_folder.is_absolute():
			candidate = (project_root / pkg_folder).resolve()
			if candidate.is_dir():
				pkg_folder = candidate
			else:
				pkg_folder = pkg_folder.resolve()

	bundle = bundle_urdf_assets(
		model,
		project_root,
		package_name=pkg_name,
		package_folder=pkg_folder,
	)
	robot.package_name = pkg_name
	# Re-point at the local package copy so the project stays self-contained
	# (this migrates older robots that still reference an absolute path).
	if bundle.local_package_rel:
		robot.package_folder = bundle.local_package_rel
	robot.links = _build_link_records(model, bundle)

	updated = 0
	for link_name, meshes in bundle.link_meshes.items():
		link_ent_id = robot.find_link_entity_id(link_name)
		if not link_ent_id:
			continue
		link_ent = scene.find_by_id(link_ent_id)
		if link_ent is None:
			continue
		vis = meshes.visual_project_path
		col = meshes.collision_project_path
		if not vis and not col:
			continue
		_apply_mesh_to_entity(link_ent, project_root, vis, col, robot.robot_name)
		updated += 1
		try:
			scene.events.entity_changed.emit(link_ent.id)
		except Exception:
			pass

	apply_urdf_collision_group_defaults(scene, robot)

	try:
		scene.events.entity_changed.emit(entity.id)
	except Exception:
		pass
	return updated

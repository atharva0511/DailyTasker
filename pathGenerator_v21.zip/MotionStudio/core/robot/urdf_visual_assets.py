from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Tuple

from MotionStudio.core.robot.frame_math import make_transform
from MotionStudio.utils.mesh_assets import (
	convert_scene_to_glb,
	import_mesh_into_project,
	load_trimesh_scene,
)


def _urdf_origin_is_identity(
	origin_xyz_m: Tuple[float, float, float],
	origin_rpy_rad: Tuple[float, float, float],
) -> bool:
	return origin_xyz_m == (0.0, 0.0, 0.0) and origin_rpy_rad == (0.0, 0.0, 0.0)


def _apply_urdf_origin_meter_space(
	scene,
	origin_xyz_m: Tuple[float, float, float],
	origin_rpy_rad: Tuple[float, float, float],
) -> None:
	"""Bake URDF geometry origin in file/metre coordinates (before mm scaling)."""
	t = make_transform(origin_xyz_m, origin_rpy_rad, translation_scale=1.0)
	scene.apply_transform(t)


def import_urdf_visual_mesh(
	project_root: Path,
	source_path: str | Path,
	origin_xyz_m: Tuple[float, float, float] = (0.0, 0.0, 0.0),
	origin_rpy_rad: Tuple[float, float, float] = (0.0, 0.0, 0.0),
	*,
	import_dir: Optional[Path] = None,
) -> str:
	"""
	Import a URDF visual mesh through the standard DAE pipeline (scale + materials).

	URDF ``<origin>`` is baked in metre space, then :func:`convert_scene_to_glb`
	applies the same unit scaling and material sidecar as :func:`import_mesh_into_project`.
	"""
	root = project_root.resolve()
	source = Path(source_path).resolve()
	if not source.is_file():
		raise FileNotFoundError(f"Mesh file not found: {source_path}")

	out_dir = import_dir if import_dir is not None else root / "models"
	out_dir = out_dir.resolve()

	if _urdf_origin_is_identity(origin_xyz_m, origin_rpy_rad) and source.suffix.lower() == ".dae":
		return import_mesh_into_project(project_root, str(source), import_dir=import_dir)

	scene = load_trimesh_scene(source)
	if not _urdf_origin_is_identity(origin_xyz_m, origin_rpy_rad):
		_apply_urdf_origin_meter_space(scene, origin_xyz_m, origin_rpy_rad)
	dest = convert_scene_to_glb(out_dir, scene, source)
	return dest.relative_to(root).as_posix()


def import_urdf_visual_meshes_merged(
	project_root: Path,
	sources: List[Tuple[Path, Tuple[float, float, float], Tuple[float, float, float]]],
	*,
	import_dir: Path,
	output_stem: str,
) -> str:
	"""Merge multiple URDF visuals (each with origin) then import via the standard GLB pipeline."""
	if not sources:
		return ""
	if len(sources) == 1:
		src, xyz, rpy = sources[0]
		return import_urdf_visual_mesh(project_root, src, xyz, rpy, import_dir=import_dir)

	root = project_root.resolve()
	out_dir = import_dir.resolve()
	unit_source = sources[0][0]

	import trimesh  # type: ignore

	meshes = []
	for src, xyz, rpy in sources:
		scene = load_trimesh_scene(src)
		if not _urdf_origin_is_identity(xyz, rpy):
			_apply_urdf_origin_meter_space(scene, xyz, rpy)
		geom = scene.dump(concatenate=True) if isinstance(scene, trimesh.Scene) else scene
		meshes.append(geom)

	combined_scene = trimesh.Scene(trimesh.util.concatenate(meshes))
	dest = convert_scene_to_glb(out_dir, combined_scene, unit_source, output_stem=output_stem)
	return dest.relative_to(root).as_posix()

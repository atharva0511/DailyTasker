from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import numpy as np
from PyQt6.QtGui import QMatrix4x4

from MotionStudio.core.transform.utils import world_matrix

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity

MM_TO_M = 0.001


def qmatrix_to_numpy(m: QMatrix4x4) -> np.ndarray:
	"""Convert a column-vector ``QMatrix4x4`` to a 4x4 numpy array."""
	out = np.empty((4, 4), dtype=np.float64)
	for r in range(4):
		for c in range(4):
			out[r, c] = float(m[r, c])
	return out


def relative_offset_m(from_entity: "Entity", to_entity: "Entity") -> np.ndarray:
	"""Pose of ``to_entity`` expressed in ``from_entity``'s frame, translation in metres.

	Used to capture the rigid mounting offset between the robot tool link and a
	custom tool-control-point entity. As long as the TCP is rigidly attached
	(e.g. a child of the tool-link entity), this offset is pose-independent.
	"""
	a = qmatrix_to_numpy(world_matrix(from_entity))
	b = qmatrix_to_numpy(world_matrix(to_entity))
	rel = np.linalg.inv(a) @ b
	rel[:3, 3] *= MM_TO_M
	return rel


def goal_in_base_frame(base_entity: "Entity", target_entity: "Entity") -> np.ndarray:
	"""Target pose expressed in the robot base frame, with translation in metres.

	Engine transforms store translation in millimetres; Pinocchio expects
	metres, so the translation column is scaled here while the rotation block
	is left untouched.
	"""
	t_world_base = qmatrix_to_numpy(world_matrix(base_entity))
	t_world_target = qmatrix_to_numpy(world_matrix(target_entity))
	t_base_target = np.linalg.inv(t_world_base) @ t_world_target
	t_base_target[:3, 3] *= MM_TO_M
	return t_base_target

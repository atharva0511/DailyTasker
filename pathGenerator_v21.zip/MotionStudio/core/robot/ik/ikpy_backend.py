from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult

try:  # IKPy is an optional, pure-Python dependency (pip-installable on Windows).
	from ikpy.chain import Chain  # type: ignore
	from ikpy.link import OriginLink, URDFLink  # type: ignore

	_IKPY_AVAILABLE = True
except Exception:  # pragma: no cover - import guarded for graceful degradation
	Chain = None  # type: ignore
	OriginLink = None  # type: ignore
	URDFLink = None  # type: ignore
	_IKPY_AVAILABLE = False


class IKPyIKBackend:
	"""6D pose IK using the IKPy library.

	The kinematic chain from ``root_link`` to ``ee_link`` is built directly from
	the joint records carried on the request (already parsed by the URDF
	importer, in metres), so this backend never re-reads the URDF file and is
	immune to ``package://`` mesh-path issues. Chains are cached per
	``(urdf_path, root_link, ee_link)``.
	"""

	def __init__(self) -> None:
		self._cache: Dict[Tuple[str, str, str], Tuple[object, List[str]]] = {}

	def is_available(self) -> bool:
		return _IKPY_AVAILABLE

	def invalidate_cache(self, urdf_path: str) -> None:
		for key in [k for k in self._cache if k[0] == urdf_path]:
			self._cache.pop(key, None)

	@staticmethod
	def _joint_path(
		joints: List[Dict[str, Any]], root_link: str, ee_link: str
	) -> List[Dict[str, Any]]:
		"""Ordered joint records along the chain root_link -> ee_link."""
		by_child: Dict[str, Dict[str, Any]] = {
			str(j.get("child_link", "")): j for j in joints
		}
		path: List[Dict[str, Any]] = []
		cur = ee_link
		guard = 0
		while cur and cur != root_link and cur in by_child:
			j = by_child[cur]
			path.append(j)
			cur = str(j.get("parent_link", ""))
			guard += 1
			if guard > 4096:  # cycle guard
				break
		path.reverse()
		return path

	def _build_chain(self, request: IKSolveRequest):
		key = (request.urdf_path, request.root_link, request.ee_link)
		cached = self._cache.get(key)
		if cached is not None:
			return cached

		path = self._joint_path(request.joints, request.root_link, request.ee_link)
		if not path:
			return None

		links: List[object] = [OriginLink()]
		active_mask: List[bool] = [False]
		for j in path:
			name = str(j.get("name", ""))
			xyz = np.array(j.get("origin_xyz_m", [0.0, 0.0, 0.0]), dtype=np.float64)
			rpy = np.array(j.get("origin_rpy_rad", [0.0, 0.0, 0.0]), dtype=np.float64)
			axis = list(j.get("axis_xyz", [0.0, 0.0, 1.0]))
			jtype = str(j.get("type", "fixed")).lower()
			limits = j.get("limits")

			if jtype in ("revolute", "continuous"):
				bounds = (
					(float(limits["lower"]), float(limits["upper"]))
					if (limits and jtype == "revolute")
					else (None, None)
				)
				links.append(
					URDFLink(
						name=name,
						origin_translation=xyz,
						origin_orientation=rpy,
						rotation=axis,
						bounds=bounds,
						joint_type="revolute",
					)
				)
				active_mask.append(True)
			elif jtype == "prismatic":
				bounds = (
					(float(limits["lower"]), float(limits["upper"]))
					if limits
					else (None, None)
				)
				links.append(
					URDFLink(
						name=name,
						origin_translation=xyz,
						origin_orientation=rpy,
						translation=axis,
						bounds=bounds,
						joint_type="prismatic",
					)
				)
				active_mask.append(True)
			else:  # fixed joint: kept inactive at angle 0 -> contributes only its origin
				links.append(
					URDFLink(
						name=name,
						origin_translation=xyz,
						origin_orientation=rpy,
						rotation=[0.0, 0.0, 1.0],
						bounds=(0.0, 0.0),
						joint_type="revolute",
					)
				)
				active_mask.append(False)

		chain = Chain(links, active_links_mask=active_mask)
		link_names = [getattr(lk, "name", "") for lk in chain.links]
		self._cache[key] = (chain, link_names)
		return self._cache[key]

	def solve(self, request: IKSolveRequest) -> IKSolveResult:
		if not _IKPY_AVAILABLE:
			return IKSolveResult(False, {}, "IKPy is not installed.")

		built = self._build_chain(request)
		if built is None:
			return IKSolveResult(
				False, {}, "Could not build IKPy chain (check root_link/tool_link)."
			)
		chain, link_names = built

		name_to_idx = {n: i for i, n in enumerate(link_names) if n}
		seed = np.zeros(len(link_names), dtype=np.float64)
		for name, value in zip(request.joint_names, request.q_seed):
			idx = name_to_idx.get(name)
			if idx is not None:
				seed[idx] = float(value)

		try:
			solution = chain.inverse_kinematics_frame(
				request.T_goal_base,
				initial_position=seed,
				orientation_mode="all",
				max_iter=max(1, int(request.max_iterations)),
			)
		except Exception as exc:
			return IKSolveResult(False, {}, f"IKPy solve failed: {exc}")

		joint_values: Dict[str, float] = {}
		for name in request.joint_names:
			idx = name_to_idx.get(name)
			if idx is not None:
				joint_values[name] = float(solution[idx])

		success, message = self._check_tolerance(chain, solution, request)
		return IKSolveResult(success, joint_values, message)

	@staticmethod
	def _check_tolerance(
		chain, solution: np.ndarray, request: IKSolveRequest
	) -> Tuple[bool, str]:
		try:
			fk = np.asarray(chain.forward_kinematics(solution), dtype=np.float64)
		except Exception:
			return False, "Could not evaluate FK for tolerance check."
		pos_err = float(np.linalg.norm(fk[:3, 3] - request.T_goal_base[:3, 3]))
		r_rel = fk[:3, :3].T @ request.T_goal_base[:3, :3]
		cos_angle = (np.trace(r_rel) - 1.0) / 2.0
		ang_err = float(math.acos(max(-1.0, min(1.0, cos_angle))))
		ok = pos_err < request.position_tolerance_m and ang_err < request.orientation_tolerance_rad
		message = (
			""
			if ok
			else f"Did not converge (pos_err={pos_err:.4g} m, ang_err={ang_err:.4g} rad)."
		)
		return ok, message

"""Inverse kinematics backends and the scene-level IK system.

The solver layer is intentionally decoupled from the ECS/UI so additional
backends (e.g. cuRobo) can be added by implementing :class:`IKBackend`
without touching :class:`RobotIKComponent` or :class:`RobotIKSystem`.
"""

from __future__ import annotations

from MotionStudio.core.robot.ik.ik_backend import (
	IKBackend,
	IKSolveRequest,
	IKSolveResult,
)

__all__ = [
	"IKBackend",
	"IKSolveRequest",
	"IKSolveResult",
]

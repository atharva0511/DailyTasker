from __future__ import annotations

import math
import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult

try:  # Pinocchio is an optional dependency (see requirements-robot.txt).
	import pinocchio as pin  # type: ignore
except Exception:  # pragma: no cover - import guarded for graceful degradation
	pin = None  # type: ignore


_DAMPING = 1e-4
_STEP = 0.5


class PinocchioIKBackend:
	"""6D pose IK using Pinocchio with a damped least-squares (CLIK) iteration.

	The kinematic model is built once per URDF file (keyed by path + mtime) and
	reused across solves. Only the kinematic model is loaded, so ``package://``
	mesh URIs in the URDF are irrelevant here.
	"""

	def __init__(self) -> None:
		# urdf_path -> (mtime, model, data)
		self._cache: Dict[str, Tuple[float, object, object]] = {}

	def is_available(self) -> bool:
		return pin is not None

	def invalidate_cache(self, urdf_path: str) -> None:
		self._cache.pop(urdf_path, None)

	def _get_model(self, urdf_path: str):
		if pin is None:
			return None, None
		try:
			mtime = os.path.getmtime(urdf_path)
		except OSError:
			mtime = 0.0
		cached = self._cache.get(urdf_path)
		if cached is not None and cached[0] == mtime:
			return cached[1], cached[2]
		try:
			model = pin.buildModelFromUrdf(urdf_path)
		except Exception:
			return None, None
		data = model.createData()
		self._cache[urdf_path] = (mtime, model, data)
		return model, data

	def solve(self, request: IKSolveRequest) -> IKSolveResult:
		if pin is None:
			return IKSolveResult(False, {}, "Pinocchio is not installed.")

		model, data = self._get_model(request.urdf_path)
		if model is None:
			return IKSolveResult(False, {}, f"Failed to build model from {request.urdf_path}")

		frame_id = model.getFrameId(request.ee_link)
		if frame_id >= model.nframes:
			return IKSolveResult(False, {}, f"End-effector frame '{request.ee_link}' not found.")

		# Map actuated joints to Pinocchio configuration / velocity indices and
		# seed the configuration vector from the current joint angles.
		q = pin.neutral(model)
		joint_layout: List[Tuple[str, int, int, int]] = []  # (name, idx_q, nq, idx_v)
		actuated_v: List[int] = []
		for name, seed in zip(request.joint_names, request.q_seed):
			jid = model.getJointId(name)
			if jid <= 0 or jid >= model.njoints:
				continue
			jnt = model.joints[jid]
			idx_q, nq, idx_v = jnt.idx_q, jnt.nq, jnt.idx_v
			if nq == 1:
				q[idx_q] = float(seed)
			elif nq == 2:  # continuous joint stored as (cos, sin)
				q[idx_q] = math.cos(float(seed))
				q[idx_q + 1] = math.sin(float(seed))
			joint_layout.append((name, idx_q, nq, idx_v))
			actuated_v.append(idx_v)

		oMdes = pin.SE3(request.T_goal_base[:3, :3], request.T_goal_base[:3, 3])

		col_mask = np.zeros(model.nv, dtype=np.float64)
		for iv in actuated_v:
			if 0 <= iv < model.nv:
				col_mask[iv] = 1.0

		lower = np.asarray(model.lowerPositionLimit, dtype=np.float64)
		upper = np.asarray(model.upperPositionLimit, dtype=np.float64)

		success = False
		eps_pos = float(request.position_tolerance_m)
		eps_ori = float(request.orientation_tolerance_rad)
		identity6 = np.eye(6, dtype=np.float64)

		for _ in range(max(1, int(request.max_iterations))):
			pin.forwardKinematics(model, data, q)
			pin.updateFramePlacements(model, data)
			oMf = data.oMf[frame_id]
			iMd = oMf.actInv(oMdes)
			err = pin.log(iMd).vector  # [linear; angular]
			if (
				np.linalg.norm(err[:3]) < eps_pos
				and np.linalg.norm(err[3:]) < eps_ori
			):
				success = True
				break
			jac = pin.computeFrameJacobian(model, data, q, frame_id)
			jac = -np.dot(pin.Jlog6(iMd.inverse()), jac)
			jac *= col_mask  # restrict motion to actuated joints
			v = -jac.T.dot(np.linalg.solve(jac.dot(jac.T) + _DAMPING * identity6, err))
			q = pin.integrate(model, q, v * _STEP)
			# Clamp to URDF position limits where finite.
			finite = np.isfinite(lower) & np.isfinite(upper)
			if finite.any():
				q[finite] = np.clip(q[finite], lower[finite], upper[finite])

		joint_values: Dict[str, float] = {}
		for name, idx_q, nq, _idx_v in joint_layout:
			if nq == 1:
				joint_values[name] = float(q[idx_q])
			elif nq == 2:
				joint_values[name] = float(math.atan2(q[idx_q + 1], q[idx_q]))

		message = "" if success else "Did not converge within tolerance."
		return IKSolveResult(success, joint_values, message)

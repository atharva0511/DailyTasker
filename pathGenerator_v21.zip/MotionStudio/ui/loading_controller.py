from __future__ import annotations

from typing import Callable, Generic, Optional, TypeVar

from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtWidgets import QMessageBox, QWidget

from MotionStudio.ui.widgets.loading_popup import LoadingPopup

T = TypeVar("T")


class _LoadingWorker(QThread):
	finished_ok = pyqtSignal(object)
	failed = pyqtSignal(str)

	def __init__(self, background: Callable[[], object]) -> None:
		super().__init__()
		self._background = background

	def run(self) -> None:
		try:
			result = self._background()
			self.finished_ok.emit(result)
		except Exception as e:
			self.failed.emit(str(e))


class LoadingController(QObject):
	"""
	Runs heavy work on a background thread and applies results on the main thread
	while showing a non-blocking loading overlay.
	"""

	def __init__(self, parent: QWidget) -> None:
		super().__init__(parent)
		self._parent = parent
		self._popup = LoadingPopup(parent)
		self._worker: Optional[_LoadingWorker] = None
		self._apply_fn: Optional[Callable[[object], None]] = None
		self._on_error_fn: Optional[Callable[[Exception], None]] = None

	def is_busy(self) -> bool:
		return self._worker is not None and self._worker.isRunning()

	def set_message(self, text: str) -> None:
		if self._popup.isVisible():
			self._popup.set_message(text)

	def run(
		self,
		message: str,
		background: Callable[[], T],
		apply: Callable[[T], None],
		*,
		on_error: Optional[Callable[[Exception], None]] = None,
		hide_when_apply_returns: bool = True,
	) -> bool:
		"""
		Start a loading job. Returns False if another job is already running.
		"""
		if self.is_busy():
			print("LoadingController: ignored overlapping load request", flush=True)
			return False

		self._popup.show_message(message)
		self._apply_fn = lambda result: apply(result)  # type: ignore[misc]
		self._on_error_fn = on_error
		self._hide_when_apply_returns = hide_when_apply_returns

		worker = _LoadingWorker(background)  # type: ignore[arg-type]
		worker.finished_ok.connect(self._on_finished)
		worker.failed.connect(self._on_failed)
		worker.finished.connect(self._on_worker_thread_finished)
		self._worker = worker
		worker.start()
		return True

	def hide(self) -> None:
		self._popup.hide_popup()

	def _on_finished(self, result: object) -> None:
		hide_after = True
		try:
			if self._apply_fn is not None:
				self._apply_fn(result)
		except Exception as e:
			self._handle_error(e)
			hide_after = False
		if hide_after and getattr(self, "_hide_when_apply_returns", True):
			self._popup.hide_popup()

	def _on_failed(self, message: str) -> None:
		self._handle_error(RuntimeError(message))

	def _handle_error(self, exc: Exception) -> None:
		self._popup.hide_popup()
		if self._on_error_fn is not None:
			try:
				self._on_error_fn(exc)
				return
			except Exception:
				pass
		QMessageBox.critical(self._parent, "Operation failed", str(exc))

	def _on_worker_thread_finished(self) -> None:
		self._worker = None
		self._apply_fn = None
		self._on_error_fn = None
		self._hide_when_apply_returns = True

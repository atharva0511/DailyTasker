from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QVBoxLayout, QWidget

from MotionStudio.ui.inspector.inspector_dialog_utils import InspectorFormDialog, add_close_button_row
from MotionStudio.ui.widgets.path_toolbox import PathToolbox

if TYPE_CHECKING:
	from MotionStudio.ui.inspector_panel import InspectorPanel
	from MotionStudio.ui.tools.path_tool_manager import PathToolManager


class PathToolboxDialog(InspectorFormDialog):
	"""Dialog hosting path segment creation tools (replaces the viewport floating toolbox)."""

	def __init__(self, panel: "InspectorPanel", tool_manager: "PathToolManager") -> None:
		super().__init__(panel)
		self.setWindowTitle("Toolbox")
		self.setModal(False)
		self.setMinimumSize(280, 120)
		self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		body = QWidget(self)
		body_layout = QVBoxLayout(body)
		body_layout.setContentsMargins(0, 0, 0, 0)
		body_layout.addWidget(PathToolbox(tool_manager, body))
		root.addWidget(body, 1)

		add_close_button_row(self, root)

		self.adjustSize()
		panel._center_dialog_on_window(self)
		self.show()
		self.raise_()
		self.activateWindow()

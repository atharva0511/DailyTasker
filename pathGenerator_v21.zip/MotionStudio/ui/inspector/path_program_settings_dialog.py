from __future__ import annotations

from typing import TYPE_CHECKING

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFormLayout, QScrollArea, QVBoxLayout, QWidget

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.ui.inspector.inspector_dialog_utils import InspectorFormDialog, add_close_button_row

if TYPE_CHECKING:
	from MotionStudio.core.components.path_component import PathComponent
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel


class PathProgramSettingsDialog(InspectorFormDialog):
	"""Dialog for path-level URScript speed and acceleration."""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		comp: "PathComponent",
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._entity = entity
		self._comp = comp
		self.setWindowTitle("Path Program Settings")
		self.setModal(False)
		self.setMinimumSize(360, 160)
		self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

		body = QWidget(scroll)
		self._form = QFormLayout(body)
		self._form.setContentsMargins(0, 0, 0, 0)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		self._rebuild_form()

		add_close_button_row(self, root)
		self._connect_refresh_signals()

		self.adjustSize()
		panel._center_dialog_on_window(self)
		self.show()
		self.raise_()
		self.activateWindow()

	def _connect_refresh_signals(self) -> None:
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.connect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def _rebuild_form(self) -> None:
		if not self._is_context_valid():
			self.close()
			return
		while self._form.rowCount() > 0:
			self._form.removeRow(0)
		self._panel._append_path_program_settings_fields(self._form, self._entity, self._comp)

	def _is_context_valid(self) -> bool:
		try:
			scene = getattr(self._panel, "_scene", None)
			if scene is not None and scene.find_by_id(self._entity.id) is not self._entity:
				return False
			return self._entity.get_component(PathComponent) is self._comp
		except Exception:
			return False

	def _on_undo_redo(self, _idx: int) -> None:
		self._rebuild_form()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._rebuild_form()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.disconnect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)

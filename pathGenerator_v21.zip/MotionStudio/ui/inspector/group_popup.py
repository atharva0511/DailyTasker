from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QFormLayout, QScrollArea, QVBoxLayout, QWidget

from MotionStudio.ui.inspector.inspector_dialog_utils import InspectorFormDialog, add_close_button_row
from MotionStudio.ui.inspector.reflection import InspectorLayoutRow

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel


class InspectorGroupPopup(InspectorFormDialog):
	"""
	Dialog window for fields sharing a ``Group`` metadata label.

	Presented like other inspector pickers (e.g. entity browser): titled window,
	minimum size, scrollable form, and a Close button.
	"""

	def __init__(
		self,
		panel: "InspectorPanel",
		group_label: str,
		rows: List[InspectorLayoutRow],
		*,
		entity: Optional["Entity"] = None,
		component=None,
		entities: Optional[List["Entity"]] = None,
		comp_type: Optional[str] = None,
		prototype=None,
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._rows = rows
		self._entity = entity
		self._component = component
		self._entities = entities
		self._comp_type = comp_type
		self._prototype = prototype
		self._refresh_pending = False
		self._closing = False
		self.setWindowTitle(group_label)
		self.setModal(False)
		self.setMinimumSize(360, 220)
		self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

		body = QWidget(scroll)
		self._form = QFormLayout(body)
		self._form.setContentsMargins(0, 0, 0, 0)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		self._rebuild_rows()

		add_close_button_row(self, root)
		self._connect_refresh_signals()

		self.adjustSize()
		self._center_on_parent(panel)
		self.show()
		self.raise_()
		self.activateWindow()

	def _center_on_parent(self, parent: QWidget) -> None:
		try:
			window = parent.window()
			if window is None:
				return
			parent_geo = window.frameGeometry()
			dialog_geo = self.frameGeometry()
			dialog_geo.moveCenter(parent_geo.center())
			self.move(dialog_geo.topLeft())
		except Exception:
			pass

	def _connect_refresh_signals(self) -> None:
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.connect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def _rebuild_rows(self) -> None:
		self._refresh_pending = False
		if self._closing:
			return
		if not self._is_context_valid():
			self.close()
			return
		while self._form.rowCount() > 0:
			self._form.removeRow(0)
		if self._entities is not None and self._comp_type is not None and self._prototype is not None:
			self._panel._append_inspector_rows_multi(
				self._form, self._rows, self._entities, self._comp_type, self._prototype
			)
		elif self._entity is not None and self._component is not None:
			self._panel._append_inspector_rows_single(self._form, self._rows, self._entity, self._component)

	def _is_context_valid(self) -> bool:
		scene = getattr(self._panel, "_scene", None)
		if self._entity is not None and self._component is not None:
			try:
				if scene is not None and scene.find_by_id(self._entity.id) is not self._entity:
					return False
				return self._component in list(getattr(self._entity, "components", []))
			except Exception:
				return False
		if self._entities is not None and self._comp_type is not None:
			try:
				for ent in self._entities:
					if scene is not None and scene.find_by_id(ent.id) is not ent:
						continue
					for comp in getattr(ent, "components", []):
						type_name = getattr(comp, "type_name", comp.__class__.__name__)
						if type_name == self._comp_type or comp.__class__.__name__ == self._comp_type:
							return True
				return False
			except Exception:
				return False
		return True

	def _schedule_refresh(self) -> None:
		# Defer rebuild so we do not destroy Qt editors while their signal
		# handlers are still running (e.g. bulk bool toggles in this popup).
		if self._refresh_pending or self._closing:
			return
		self._refresh_pending = True
		QTimer.singleShot(0, self._rebuild_rows)

	def _on_undo_redo(self, _idx: int) -> None:
		self._schedule_refresh()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity is not None and self._entity.id == entity_id:
			self._schedule_refresh()
			return
		if self._entities is not None and any(e.id == entity_id for e in self._entities):
			self._schedule_refresh()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity is not None and self._entity.id == entity_id:
			self.close()
			return
		if self._entities is not None and any(e.id == entity_id for e in self._entities):
			self._schedule_refresh()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.disconnect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)

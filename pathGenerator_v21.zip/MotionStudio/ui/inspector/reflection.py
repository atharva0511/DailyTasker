from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, ClassVar, List, Literal, Optional, Tuple, get_args, get_origin, get_type_hints

from MotionStudio.ui.inspector import metadata as inspector_metadata
from MotionStudio.ui.inspector.metadata import Group, Hidden, Order, collect_inspector_buttons

# Names injected when evaluating deferred annotations (``from __future__ import annotations``).
_ANNOTATION_EVAL_NAMES = (
	"Group",
	"Order",
	"Header",
	"Tooltip",
	"Range",
	"Hidden",
	"ReadOnly",
	"FilePath",
	"FolderPath",
	"ColorField",
	"Multiline",
	"VertexPick",
)


@dataclass(frozen=True)
class FieldSpec:
	name: str
	typ: Any
	metadata: Tuple[Any, ...]
	getter: Callable[[], Any]
	setter: Optional[Callable[[Any], None]]


@dataclass(frozen=True)
class InspectorLayoutRow:
	"""One Inspector form row: either an editable field or an @inspector_button."""

	kind: Literal["field", "button"]
	sort_order: int
	declaration_index: int
	field_spec: Optional[FieldSpec] = None
	button_spec: Optional[Any] = None
	button_method: Optional[Callable[..., Any]] = None


def _is_annotated(t: Any) -> bool:
	return get_origin(t) is getattr(__import__("typing"), "Annotated", None)


def unwrap_annotated(t: Any) -> Tuple[Any, Tuple[Any, ...]]:
	"""
	Returns (base_type, metadata).
	If t is not Annotated, metadata is empty.
	"""
	if get_origin(t) is not None and str(get_origin(t)) == "typing.Annotated":
		args = get_args(t)
		if not args:
			return t, ()
		return args[0], tuple(args[1:])
	# Python 3.11+: typing.Annotated origin is typing.Annotated
	if get_origin(t) is getattr(__import__("typing"), "Annotated", None):
		args = get_args(t)
		if not args:
			return t, ()
		return args[0], tuple(args[1:])
	return t, ()


def unified_declaration_index(cls: type) -> dict[str, int]:
	"""
	Declaration order of class-body members across the MRO (bases before subclass).

	Uses ``__dict__`` insertion order so ``@inspector_button`` methods can be
	interleaved with annotated fields. Names only in ``__annotations__`` are
	appended after ``__dict__`` names for that class.
	"""
	index: dict[str, int] = {}
	idx = 0
	for base in reversed(cls.__mro__):
		for name in base.__dict__:
			if name.startswith("_") or name == "type_name":
				continue
			if name not in index:
				index[name] = idx
				idx += 1
		for name in getattr(base, "__annotations__", {}):
			if name.startswith("_") or name == "type_name":
				continue
			if name not in index:
				index[name] = idx
				idx += 1
	return index


def _sort_order_from_metadata(metadata: Tuple[Any, ...]) -> int:
	for m in metadata:
		if isinstance(m, Order):
			return int(m.value)
	return 0


def _hidden_annotation_names(cls: type, hints: dict[str, Any]) -> set[str]:
	"""Field names marked ``Hidden()`` on the class (including ones only set in ``__init__``)."""
	hidden: set[str] = set()
	for name, t in hints.items():
		if name.startswith("_") or name == "type_name":
			continue
		if get_origin(t) is ClassVar or str(get_origin(t)) == "typing.ClassVar":
			continue
		_, meta = unwrap_annotated(t)
		if any(isinstance(m, Hidden) and m.enabled for m in meta):
			hidden.add(name)
	return hidden


def clone_value(v: Any) -> Any:
	"""
	Clone common Qt value types so undo stores stable snapshots.
	"""
	try:
		from PyQt6.QtGui import QVector3D, QColor

		if isinstance(v, QVector3D):
			return QVector3D(v)
		if isinstance(v, QColor):
			return QColor(v)
	except Exception:
		pass
	# primitives/tuples are fine
	return v


def _get_type_hints_for_class(cls: type) -> dict[str, Any]:
	try:
		return get_type_hints(cls, include_extras=True)
	except Exception:
		# Fallback: use __annotations__ directly if get_type_hints fails (e.g., due to forward references)
		# This happens when annotations contain forward references that can't be resolved
		hints = getattr(cls, "__annotations__", {})
		# Try to evaluate the annotation strings manually (needed because of __future__ annotations)
		if hints:
			evaluated_hints = {}
			import sys
			import typing
			# Get the module's globals for evaluation context
			module = sys.modules.get(cls.__module__)
			module_globals = module.__dict__.copy() if module else {}
			# Add common typing constructs that might be used in annotations
			module_globals.update({
				'typing': typing,
				'Annotated': typing.Annotated,
				'Optional': typing.Optional,
				'List': typing.List,
				'Dict': typing.Dict,
				'Tuple': typing.Tuple,
				'Union': typing.Union,
				'Literal': typing.Literal,
			})
			for _meta_name in _ANNOTATION_EVAL_NAMES:
				module_globals.setdefault(
					_meta_name, getattr(inspector_metadata, _meta_name)
				)
			# Also add builtins
			import builtins
			module_globals['__builtins__'] = builtins.__dict__
			
			for name, ann_str in hints.items():
				if isinstance(ann_str, str):
					try:
						# Evaluate the annotation string in the module's context
						evaluated_hints[name] = eval(ann_str, module_globals)
					except Exception:
						# If evaluation fails, skip this annotation
						continue
				else:
					# Already evaluated (shouldn't happen with __future__ annotations, but handle it)
					evaluated_hints[name] = ann_str
			return evaluated_hints
		return hints


def _collect_field_specs(component: Any) -> dict[str, FieldSpec]:
	"""
	Reflect editable fields (not sorted). Skips Hidden fields.
	"""
	cls = component.__class__
	specs: dict[str, FieldSpec] = {}
	hints = _get_type_hints_for_class(cls)
	hidden_names = _hidden_annotation_names(cls, hints)

	for name, t in hints.items():
		if name.startswith("_"):
			continue
		# Skip registry/identity fields and any ClassVar (not an instance-editable field)
		if name == "type_name":
			continue
		if get_origin(t) is ClassVar or str(get_origin(t)) == "typing.ClassVar":
			continue
		base_t, meta = unwrap_annotated(t)
		
		# Skip hidden fields
		if any(isinstance(m, Hidden) and m.enabled for m in meta):
			continue

		# Determine if writable: property with setter or plain attribute
		attr = getattr(cls, name, None)
		if isinstance(attr, property):
			getter = lambda n=name: getattr(component, n)
			setter = None
			if attr.fset is not None:
				setter = lambda v, n=name: setattr(component, n, v)
		else:
			getter = lambda n=name: getattr(component, n, None)
			setter = lambda v, n=name: setattr(component, n, v)

		specs[name] = FieldSpec(name=name, typ=base_t, metadata=meta, getter=getter, setter=setter)

	for name, value in getattr(component, "__dict__", {}).items():
		if name.startswith("_"):
			continue
		if name in hidden_names:
			continue
		if name in specs:
			continue
		if callable(value):
			continue
		getter = lambda n=name: getattr(component, n)
		setter = lambda v, n=name: setattr(component, n, v)
		specs[name] = FieldSpec(name=name, typ=type(value), metadata=(), getter=getter, setter=setter)

	return specs


def iter_editable_fields(component: Any) -> List[FieldSpec]:
	"""Editable fields sorted by ``Order`` then unified declaration order."""
	cls = component.__class__
	specs = list(_collect_field_specs(component).values())
	decl = unified_declaration_index(cls)
	next_index = (max(decl.values()) + 1) if decl else 0
	for spec in specs:
		if spec.name not in decl:
			decl[spec.name] = next_index
			next_index += 1
	specs.sort(
		key=lambda s: (
			_sort_order_from_metadata(s.metadata),
			decl.get(s.name, 1_000_000),
		)
	)
	return specs


def iter_inspector_layout(component: Any) -> List[InspectorLayoutRow]:
	"""
	Unified Inspector rows (fields and @inspector_button) sorted by shared ``order``.

	Field rows use ``Order`` metadata; buttons use ``inspector_button(..., order=...)``.
	Same numeric order interleaves by class declaration order.
	"""
	cls = component.__class__
	fields = _collect_field_specs(component)
	buttons = collect_inspector_buttons(component)
	decl = unified_declaration_index(cls)
	next_index = (max(decl.values()) + 1) if decl else 0
	for name in set(fields) | set(buttons):
		if name not in decl:
			decl[name] = next_index
			next_index += 1

	rows: List[InspectorLayoutRow] = []
	for name in sorted(set(fields) | set(buttons), key=lambda n: decl.get(n, 1_000_000)):
		if name in fields:
			spec = fields[name]
			if any(isinstance(m, Hidden) and m.enabled for m in spec.metadata):
				pass
			elif spec.setter is None:
				pass
			else:
				rows.append(
					InspectorLayoutRow(
						kind="field",
						sort_order=_sort_order_from_metadata(spec.metadata),
						declaration_index=decl[name],
						field_spec=spec,
					)
				)
		if name in buttons:
			bspec, method = buttons[name]
			rows.append(
				InspectorLayoutRow(
					kind="button",
					sort_order=int(bspec.order),
					declaration_index=decl[name],
					button_spec=bspec,
					button_method=method,
				)
			)

	rows.sort(key=lambda r: (r.sort_order, r.declaration_index))
	return rows


InspectorLayoutItem = Tuple[Literal["row", "group"], Any]


def group_label_from_metadata(metadata: Tuple[Any, ...]) -> Optional[str]:
	"""Return the group label from field metadata, if any."""
	for m in metadata:
		if isinstance(m, Group):
			return str(m.label)
	return None


def partition_inspector_layout(
	rows: List[InspectorLayoutRow],
) -> Tuple[List[InspectorLayoutItem], dict[str, List[InspectorLayoutRow]]]:
	"""
	Split layout rows into main-form items and grouped field buckets.

	Grouped fields are removed from inline ``row`` items; the first encounter of
	each group label yields a ``("group", label)`` item at that sort position.
	"""
	groups: dict[str, List[InspectorLayoutRow]] = {}
	seen_groups: set[str] = set()
	items: List[InspectorLayoutItem] = []

	for row in rows:
		if row.kind == "field" and row.field_spec is not None:
			label = group_label_from_metadata(row.field_spec.metadata)
			if label:
				groups.setdefault(label, []).append(row)
				if label not in seen_groups:
					seen_groups.add(label)
					items.append(("group", label))
				continue
		items.append(("row", row))

	return items, groups


def is_literal_type(t: Any) -> bool:
	return get_origin(t) is getattr(__import__("typing"), "Literal", None) or str(get_origin(t)) == "typing.Literal"


def literal_choices(t: Any) -> List[Any]:
	if not is_literal_type(t):
		return []
	return list(get_args(t))



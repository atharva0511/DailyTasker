from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Literal, Optional, Set

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.ui.inspector.reflection import clone_value


def _component_type_name(comp) -> str:
	return getattr(comp, "type_name", comp.__class__.__name__)


def find_component(entity: Entity, comp_type: str):
	for comp in entity.components:
		if _component_type_name(comp) == comp_type or comp.__class__.__name__ == comp_type:
			return comp
	return None


def common_component_types(entities: List[Entity], *, exclude_path_unless_single: bool = True) -> List[str]:
	if not entities:
		return []
	sets: List[Set[str]] = []
	for ent in entities:
		names = {_component_type_name(c) for c in ent.components}
		if exclude_path_unless_single and len(entities) != 1:
			names.discard("PathGeneration")
		sets.append(names)
	common = set.intersection(*sets) if sets else set()
	# Transform first, then alphabetical
	ordered = sorted(common)
	if "Transform" in ordered:
		ordered.remove("Transform")
		ordered.insert(0, "Transform")
	return ordered


@dataclass
class FieldValue:
	kind: Literal["uniform", "mixed"]
	value: Any = None


def field_value_for(entities: List[Entity], comp_type: str, field_name: str) -> FieldValue:
	values: List[Any] = []
	for ent in entities:
		comp = find_component(ent, comp_type)
		if comp is None:
			continue
		try:
			values.append(clone_value(getattr(comp, field_name)))
		except Exception:
			values.append(None)
	if not values:
		return FieldValue(kind="uniform", value=None)
	first = values[0]
	for v in values[1:]:
		if v != first:
			return FieldValue(kind="mixed")
	return FieldValue(kind="uniform", value=first)


def entity_name_field_value(entities: List[Entity]) -> FieldValue:
	if not entities:
		return FieldValue(kind="uniform", value="")
	names = [e.name for e in entities]
	if all(n == names[0] for n in names):
		return FieldValue(kind="uniform", value=names[0])
	return FieldValue(kind="mixed")

from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (
	QAbstractSpinBox,
	QComboBox,
	QDialog,
	QDialogButtonBox,
	QLineEdit,
	QPlainTextEdit,
	QVBoxLayout,
	QWidget,
)


def _is_field_editor(widget: QWidget | None) -> bool:
	"""True when Enter should commit the focused control, not close the dialog."""
	if widget is None:
		return False
	if isinstance(widget, (QLineEdit, QPlainTextEdit, QAbstractSpinBox, QComboBox)):
		return True
	# Vector3Editor and similar containers: focus is usually on a child line edit.
	parent = widget.parentWidget()
	while parent is not None:
		if isinstance(parent, QDialog):
			break
		if isinstance(parent, (QLineEdit, QPlainTextEdit, QAbstractSpinBox, QComboBox)):
			return True
		parent = parent.parentWidget()
	return False


def add_close_button_row(dialog: QDialog, layout: QVBoxLayout) -> None:
	"""Add a Close button that is never auto-default (Enter must not activate it)."""
	button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close, Qt.Orientation.Horizontal, dialog)
	close_btn = button_box.button(QDialogButtonBox.StandardButton.Close)
	if close_btn is not None:
		close_btn.setAutoDefault(False)
		close_btn.setDefault(False)
		close_btn.clicked.connect(dialog.close)
	layout.addWidget(button_box)


class InspectorFormDialog(QDialog):
	"""
	Non-modal inspector sub-dialog (group fields, segment settings, …).

	Enter commits the focused editor; Escape closes the window.
	"""

	def __init__(self, parent: QWidget | None = None) -> None:
		super().__init__(parent)
		# Window-level shortcuts: keep undo/redo available while popup has focus.
		self._undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
		self._redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
		self._redo_ctrl_y_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
		for sc in (self._undo_shortcut, self._redo_shortcut, self._redo_ctrl_y_shortcut):
			sc.setContext(Qt.ShortcutContext.WindowShortcut)
		self._undo_shortcut.activated.connect(self._trigger_global_undo)
		self._redo_shortcut.activated.connect(self._trigger_global_redo)
		self._redo_ctrl_y_shortcut.activated.connect(self._trigger_global_redo)

	def _undo_stack(self):
		panel = self.parentWidget()
		return getattr(panel, "_undo_stack", None)

	def _trigger_global_undo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canUndo():
			stack.undo()

	def _trigger_global_redo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canRedo():
			stack.redo()

	def keyPressEvent(self, event) -> None:  # noqa: N802
		if event.matches(QKeySequence.StandardKey.Undo):
			self._trigger_global_undo()
			event.accept()
			return
		if event.matches(QKeySequence.StandardKey.Redo) or (
			event.modifiers() & Qt.KeyboardModifier.ControlModifier and event.key() == Qt.Key.Key_Y
		):
			self._trigger_global_redo()
			event.accept()
			return
		key = event.key()
		if key == Qt.Key.Key_Escape:
			self.close()
			event.accept()
			return
		if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
			fw = self.focusWidget()
			if _is_field_editor(fw):
				# Commit spin boxes / line edits without closing the dialog.
				if isinstance(fw, QAbstractSpinBox):
					fw.interpretText()
				fw.clearFocus()
				event.accept()
				return
		super().keyPressEvent(event)

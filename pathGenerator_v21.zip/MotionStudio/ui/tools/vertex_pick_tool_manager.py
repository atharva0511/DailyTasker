from __future__ import annotations
from typing import Callable, Optional

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QVector3D

from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.render.vtk.scene_root import VtkSceneRoot


class VertexPickToolManager(QObject):
	"""
	One-shot vertex picking driven from the Inspector.

	When `start_pick` is called the scene is put into "vertex" selection mode
	and an instruction is shown via `instruction_changed`. The next valid
	`vertex_picked` from the picker bridge is converted to a world-space
	`QVector3D` and forwarded to the supplied callback, after which the tool
	resets itself.
	"""

	request_selection_mode = pyqtSignal(str)
	instruction_changed = pyqtSignal(str)
	tool_active_changed = pyqtSignal(bool)

	def __init__(
		self,
		scene: Scene,
		selection: SelectionModel,
		scene_root: VtkSceneRoot,
		picker_bridge,
		undo_stack=None,
	) -> None:
		super().__init__()
		self._scene = scene
		self._selection = selection
		self._scene_root = scene_root
		self._picker_bridge = picker_bridge
		self._undo_stack = undo_stack

		self._active: bool = False
		self._on_picked: Optional[Callable[[QVector3D], None]] = None
		self._label: str = ""
		# Owning entity id of the field being edited. Used to express the
		# picked vertex in the owner's local frame even when the user clicks a
		# vertex on a different entity's mesh.
		self._owner_entity_id: Optional[str] = None

		self._picker_bridge.vertex_picked.connect(self._on_vertex_picked)

	@property
	def is_active(self) -> bool:
		return self._active

	def start_pick(
		self,
		entity,
		component,
		field_name: str,
		on_picked: Callable[[QVector3D], None],
		label: Optional[str] = None,
	) -> None:
		"""Arm the picker. The next vertex click on the selected mesh emits the world position."""
		self.cancel_pick()

		self._active = True
		self._on_picked = on_picked
		self._label = label or field_name
		self._owner_entity_id = entity.id if entity is not None else None

		self.request_selection_mode.emit("vertex")
		# Show edges/vertices on EVERY mesh so the user can pick any vertex,
		# and freeze entity selection so clicking another mesh's vertex
		# doesn't rebuild the Inspector for the other entity.
		try:
			self._scene_root.set_show_all_edges(True)
		except Exception:
			pass
		try:
			self._picker_bridge.set_lock_entity_selection(True)
		except Exception:
			pass
		self.tool_active_changed.emit(True)
		self._emit_instruction()

	def cancel_pick(self) -> None:
		"""Cancel an armed pick (no callback fired)."""
		if not self._active:
			# Always make sure overlay/instruction is cleared if we were never active.
			return
		self._active = False
		self._on_picked = None
		self._label = ""
		self._owner_entity_id = None

		self._teardown_visuals()
		self.request_selection_mode.emit("object")
		self.instruction_changed.emit("")
		self.tool_active_changed.emit(False)

	def _teardown_visuals(self) -> None:
		try:
			self._scene_root.set_show_all_edges(False)
		except Exception:
			pass
		try:
			self._picker_bridge.set_lock_entity_selection(False)
		except Exception:
			pass

	def _emit_instruction(self) -> None:
		if not self._active:
			self.instruction_changed.emit("")
			return
		self.instruction_changed.emit(
			f"[Vertex Pick] Click any mesh vertex to set '{self._label}'"
		)

	def _on_vertex_picked(self, entity_id: str, vertex_id: int) -> None:
		if not self._active or self._on_picked is None:
			return

		picked_owner_local = self._owner_local_position_for_vertex(entity_id, vertex_id)
		if picked_owner_local is None:
			# Could not resolve the position in the owner's frame; cancel to
			# release UI state rather than emitting a garbage value.
			self.cancel_pick()
			return

		callback = self._on_picked

		# Reset state BEFORE invoking the callback so any inspector rebuild
		# triggered by the property change sees a clean tool state.
		self._active = False
		self._on_picked = None
		self._label = ""
		self._owner_entity_id = None
		self._teardown_visuals()
		self.request_selection_mode.emit("object")
		self.instruction_changed.emit("")
		self.tool_active_changed.emit(False)

		try:
			callback(picked_owner_local)
		except Exception:
			import traceback
			traceback.print_exc()

	def _owner_local_position_for_vertex(
		self, picked_entity_id: str, vertex_id: int
	) -> Optional[QVector3D]:
		"""
		Return the picked vertex's position expressed in the **owner entity's**
		local frame (the entity whose component holds the VertexPick field).

		Pipeline:
		    raw mesh local point of picked_entity
		      --(picked_entity world matrix)-->  world point
		      --(inverse of owner world matrix)--> owner-local point

		When `owner == picked_entity` this collapses to the raw mesh point.
		"""
		try:
			actor = self._scene_root.actor_for(picked_entity_id)
			if actor is None:
				return None
			mapper = actor.GetMapper()
			if mapper is None:
				return None
			poly = mapper.GetInput()
			if poly is None:
				return None
			local_pt = poly.GetPoint(int(vertex_id))
			picked_local = QVector3D(float(local_pt[0]), float(local_pt[1]), float(local_pt[2]))

			picked_entity = self._scene.find_by_id(picked_entity_id)
			if picked_entity is None:
				return picked_local

			from MotionStudio.core.transform.utils import (
				transform_point,
				inverse_transform_point,
			)
			world_pt = transform_point(picked_entity, picked_local)

			owner_entity = (
				self._scene.find_by_id(self._owner_entity_id)
				if self._owner_entity_id is not None
				else None
			)
			if owner_entity is None or owner_entity is picked_entity:
				# No owner (or self-pick): the round-trip would be the identity.
				return picked_local if owner_entity is None else picked_local

			return inverse_transform_point(owner_entity, world_pt)
		except Exception:
			return None

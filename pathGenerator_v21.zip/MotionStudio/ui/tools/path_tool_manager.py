from __future__ import annotations
from typing import List, Optional
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QVector3D, QMatrix4x4

from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.feature import TwoPointLineFeature, ThreePointArcFeature, SinglePointFeature
from MotionStudio.render.vtk.path_bridge import VtkPathBridge

class PathToolManager(QObject):
    """
    Manages the stateful sequential picking for path segment creation.
    """
    request_selection_mode = pyqtSignal(str)
    tool_active_changed = pyqtSignal(bool)  # Emits True when tool is active, False when inactive
    instruction_changed = pyqtSignal(str)  # Emits instruction text for current step

    def __init__(self, scene: Scene, selection: SelectionModel, path_bridge: VtkPathBridge, picker_bridge, undo_stack=None) -> None:
        super().__init__()
        self._scene = scene
        self._selection = selection
        self._path_bridge = path_bridge
        self._picker_bridge = picker_bridge
        self._undo_stack = undo_stack

        self._active_feature_type: Optional[str] = None  # "line", "arc", or "point"
        self._picked_vertex_ids: List[int] = []
        self._picked_position: Optional[QVector3D] = None
        self._picked_normal: Optional[QVector3D] = None

        self._picker_bridge.vertex_picked.connect(self._on_vertex_picked)
        self._picker_bridge.face_picked.connect(self._on_face_picked)

    def start_feature_tool(self, feature_type: str) -> None:
        """Starts the sequential picking tool for a specific segment type."""
        self._active_feature_type = feature_type
        self._picked_vertex_ids = []
        self._picked_position = None
        self._picked_normal = None
        
        # For point tool, use face mode; for line/arc, use vertex mode
        if feature_type == "point":
            self.request_selection_mode.emit("face")
        else:
            self.request_selection_mode.emit("vertex")
        
        self.tool_active_changed.emit(True)
        # Emit initial instruction
        self._emit_current_instruction()

    def cancel_tool(self) -> None:
        """Resets the tool state and clears previews. Idempotent: a no-op when no tool is active."""
        if (
            self._active_feature_type is None
            and not self._picked_vertex_ids
            and self._picked_position is None
            and self._picked_normal is None
        ):
            # Nothing to cancel; avoid spurious mode/instruction emissions that
            # would clobber other tools (e.g. VertexPickToolManager).
            return
        self._active_feature_type = None
        self._picked_vertex_ids = []
        self._picked_position = None
        self._picked_normal = None
        self._path_bridge.set_preview_points([])
        # Return to normal selection behavior
        self.request_selection_mode.emit("object")
        self.tool_active_changed.emit(False)
        # Clear instruction
        self.instruction_changed.emit("")

    def _on_vertex_picked(self, entity_id: str, vertex_id: int) -> None:
        if not self._active_feature_type:
            return

        current = self._selection.current
        if current is None or current.id != entity_id:
            # We only allow picking on the currently selected mesh entity
            return

        path_comp = current.get_component(PathComponent)
        if path_comp is None:
            # Proactively add PathComponent if it doesn't exist
            path_comp = PathComponent()
            current.add_component(path_comp)

        self._picked_vertex_ids.append(vertex_id)
        self._update_preview()
        
        # Update instruction for next step
        self._emit_current_instruction()

        # Check if feature is complete
        if self._active_feature_type == "line" and len(self._picked_vertex_ids) == 2:
            self._finish_feature(TwoPointLineFeature())
        elif self._active_feature_type == "arc" and len(self._picked_vertex_ids) == 3:
            # Ordered as: start, end, mid (as per requirement)
            self._finish_feature(ThreePointArcFeature())
    
    def _on_face_picked(self, entity_id: str, cell_id: int, pick_position: QVector3D, normal: QVector3D) -> None:
        """Handle face picking for single point feature."""
        if self._active_feature_type != "point":
            return
        
        current = self._selection.current
        if current is None or current.id != entity_id:
            # We only allow picking on the currently selected mesh entity
            return
        
        path_comp = current.get_component(PathComponent)
        if path_comp is None:
            # Proactively add PathComponent if it doesn't exist
            path_comp = PathComponent()
            current.add_component(path_comp)
        
        # Store position and normal
        self._picked_position = pick_position
        self._picked_normal = normal
        
        # Create and finish the feature immediately
        feature = SinglePointFeature()
        feature.world_position = pick_position
        feature.world_normal = normal
        self._finish_feature(feature)

    def _update_preview(self) -> None:
        if not self._active_feature_type or not self._picked_vertex_ids:
            self._path_bridge.set_preview_points([])
            return

        entity = self._selection.current
        if not entity:
            return
            
        mesh_actor = self._path_bridge._scene_root.actor_for(entity.id)
        if not mesh_actor:
            return
            
        mesh_poly = mesh_actor.GetMapper().GetInput()
        
        world_points = []
        m4 = mesh_actor.GetUserMatrix()
        
        for vid in self._picked_vertex_ids:
            local_pt = mesh_poly.GetPoint(vid)
            # Transform local mesh point to world space for preview actor
            out = [0.0, 0.0, 0.0, 1.0]
            m4.MultiplyPoint([float(local_pt[0]), float(local_pt[1]), float(local_pt[2]), 1.0], out)
            wx, wy, wz = (out[0] / out[3], out[1] / out[3], out[2] / out[3]) if abs(out[3]) > 1e-9 else (out[0], out[1], out[2])
            world_points.append(QVector3D(wx, wy, wz))

        self._path_bridge.set_preview_points(world_points)

    def _finish_feature(self, feature) -> None:
        entity = self._selection.current
        if not entity:
            return
            
        path_comp = entity.get_component(PathComponent)
        if not path_comp:
            return
            
        # Only set vertex_ids for features that use them (line, arc)
        if not isinstance(feature, SinglePointFeature):
            feature.vertex_ids = list(self._picked_vertex_ids)

        feature.cnt_radius = float(getattr(path_comp, "default_cnt_radius", 0.0))

        # Feature index after insertion (append semantics)
        new_feature_idx = len(path_comp.features)
        
        if self._undo_stack:
            from MotionStudio.core.undo.commands import AddPathFeatureCommand
            cmd = AddPathFeatureCommand(self._scene, entity.id, feature.__class__.__name__, feature.to_dict())
            self._undo_stack.push(cmd)
        else:
            path_comp.features.append(feature)
            # Trigger visuals rebuild
            self._scene.events.entity_changed.emit(entity.id)
        
        # Auto-select the newly created feature
        try:
            self._selection.set_current_feature(new_feature_idx)
        except Exception:
            pass

        # Reset tool
        self.cancel_tool()
    
    def _emit_current_instruction(self) -> None:
        """Emits the instruction text for the current step."""
        if not self._active_feature_type:
            self.instruction_changed.emit("")
            return
        
        num_picked = len(self._picked_vertex_ids)
        
        if self._active_feature_type == "line":
            if num_picked == 0:
                self.instruction_changed.emit("[Two-point line segment] Select starting point")
            elif num_picked == 1:
                self.instruction_changed.emit("[Two-point line segment] Select end point")
        
        elif self._active_feature_type == "arc":
            if num_picked == 0:
                self.instruction_changed.emit("[Three-point arc segment] Select starting point")
            elif num_picked == 1:
                self.instruction_changed.emit("[Three-point arc segment] Select end point")
            elif num_picked == 2:
                self.instruction_changed.emit("[Three-point arc segment] Select any intermediate point")
        
        elif self._active_feature_type == "point":
            self.instruction_changed.emit("[Single-point segment] Click on surface to place waypoint")


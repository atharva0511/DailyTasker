from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QFrame, QLabel, QProgressBar, QSizePolicy, QVBoxLayout, QWidget

MIN_CARD_WIDTH = 360
MAX_CARD_WIDTH = 520
CARD_HORIZONTAL_MARGIN = 40


class LoadingPopup(QWidget):
	"""
	Semi-transparent overlay with a small centered loading card.
	Parent should be the main window so it covers the editor while work runs.
	"""

	def __init__(self, parent: QWidget) -> None:
		super().__init__(parent)
		self.setObjectName("LoadingPopup")
		self.hide()
		self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
		self.setStyleSheet(
			"""
			#LoadingPopup {
				background-color: rgba(0, 0, 0, 120);
			}
			QFrame#LoadingCard {
				background-color: rgb(30, 30, 30);
				border: 2px solid #4CAF50;
				border-radius: 8px;
			}
			QLabel#LoadingMessage {
				color: #ffffff;
				font-size: 11pt;
			}
			"""
		)

		outer = QVBoxLayout(self)
		outer.setContentsMargins(0, 0, 0, 0)
		outer.addStretch(1)

		row = QVBoxLayout()
		row.addStretch(1)
		self._card = QFrame(self)
		self._card.setObjectName("LoadingCard")
		card_layout = QVBoxLayout(self._card)
		card_layout.setContentsMargins(20, 16, 20, 16)
		card_layout.setSpacing(12)

		self._message = QLabel(self._card)
		self._message.setObjectName("LoadingMessage")
		self._message.setAlignment(Qt.AlignmentFlag.AlignCenter)
		self._message.setWordWrap(True)
		self._message.setSizePolicy(
			QSizePolicy.Policy.Expanding,
			QSizePolicy.Policy.Minimum,
		)
		card_layout.addWidget(self._message)

		self._progress = QProgressBar(self._card)
		self._progress.setRange(0, 0)
		self._progress.setTextVisible(False)
		self._progress.setFixedHeight(8)
		self._progress.setMinimumWidth(MIN_CARD_WIDTH - CARD_HORIZONTAL_MARGIN)
		card_layout.addWidget(self._progress)

		row.addWidget(self._card, 0, Qt.AlignmentFlag.AlignCenter)
		row.addStretch(1)
		outer.addLayout(row, 1)
		outer.addStretch(1)

		if parent is not None:
			parent.installEventFilter(self)

	def show_message(self, text: str) -> None:
		self._set_message_text(text)
		self._reposition_card()
		self.show()
		self.raise_()

	def set_message(self, text: str) -> None:
		self._set_message_text(text)
		if self.isVisible():
			self._update_card_size()

	def _set_message_text(self, text: str) -> None:
		self._message.setText(text)

	def _update_card_size(self) -> None:
		"""Size the card from message content so progress text is not clipped."""
		p = self.parent()
		max_w = MAX_CARD_WIDTH
		if p is not None and p.width() > 0:
			max_w = min(MAX_CARD_WIDTH, max(MIN_CARD_WIDTH, int(p.width() * 0.55)))

		text_w = max_w - CARD_HORIZONTAL_MARGIN
		self._message.setFixedWidth(text_w)
		self._message.adjustSize()

		card_w = min(max_w, max(MIN_CARD_WIDTH, self._message.sizeHint().width() + CARD_HORIZONTAL_MARGIN))
		self._card.setFixedWidth(card_w)
		self._card.adjustSize()

	def hide_popup(self) -> None:
		self.hide()

	def eventFilter(self, obj, event) -> bool:
		if obj == self.parent() and event.type() == event.Type.Resize:
			if self.isVisible():
				self.setGeometry(0, 0, obj.width(), obj.height())
				self._reposition_card()
		return super().eventFilter(obj, event)

	def _reposition_card(self) -> None:
		p = self.parent()
		if p is not None:
			self.setGeometry(0, 0, p.width(), p.height())
		self._update_card_size()

	def showEvent(self, event) -> None:
		super().showEvent(event)
		self._reposition_card()

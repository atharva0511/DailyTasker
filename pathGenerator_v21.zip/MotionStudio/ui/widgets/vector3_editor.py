from __future__ import annotations

from typing import Callable

from PyQt6.QtGui import QVector3D
from PyQt6.QtWidgets import QDoubleSpinBox, QHBoxLayout, QPushButton, QWidget


_PICK_BUTTON_STYLE_IDLE = (
	"QPushButton {"
	" background-color: #444;"
	" color: #ffffff;"
	" border: 1px solid #666;"
	" border-radius: 3px;"
	" padding: 0 6px;"
	"}"
	"QPushButton:hover { background-color: #555; }"
	"QPushButton:pressed { background-color: #333; }"
)

_PICK_BUTTON_STYLE_ACTIVE = (
	"QPushButton {"
	" background-color: #5b3a1a;"
	" color: #ffffff;"
	" border: 1px solid #ff9933;"
	" border-radius: 3px;"
	" padding: 0 6px;"
	"}"
	"QPushButton:hover { background-color: #6c4520; }"
)


class Vector3Editor(QWidget):
	def __init__(
		self,
		parent: QWidget | None = None,
		initial: QVector3D | None = None,
		on_changed: Callable[[QVector3D], None] | None = None,
		step: float = 0.1,
		suffix: str = "",
		on_pick: Callable[[], None] | None = None,
	) -> None:
		super().__init__(parent)
		self._on_changed = on_changed
		self._on_pick = on_pick
		self._pick_btn: QPushButton | None = None
		self._x = self._make_spin(step, suffix)
		self._y = self._make_spin(step, suffix)
		self._z = self._make_spin(step, suffix)
		layout = QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(4)
		if on_pick is not None:
			btn = QPushButton("Pick", self)
			btn.setToolTip("Click then pick a mesh vertex in the 3D view")
			btn.setFixedHeight(22)
			btn.setStyleSheet(_PICK_BUTTON_STYLE_IDLE)
			btn.clicked.connect(self._on_pick_clicked)
			self._pick_btn = btn
			layout.addWidget(btn)
		layout.addWidget(self._x)
		layout.addWidget(self._y)
		layout.addWidget(self._z)
		if initial is not None:
			self.set_value(initial)
		# Commit on editingFinished to avoid disrupting typing (Unity-like).
		self._x.editingFinished.connect(self._emit_changed)
		self._y.editingFinished.connect(self._emit_changed)
		self._z.editingFinished.connect(self._emit_changed)

	def _make_spin(self, step: float, suffix: str) -> QDoubleSpinBox:
		spin = QDoubleSpinBox(self)
		spin.setDecimals(3)
		spin.setSingleStep(step)
		spin.setRange(-1e9, 1e9)
		spin.setMinimumWidth(80)
		if suffix:
			spin.setSuffix(suffix)
		return spin

	def value(self) -> QVector3D:
		return QVector3D(self._x.value(), self._y.value(), self._z.value())

	def set_value(self, v: QVector3D) -> None:
		for spin in (self._x, self._y, self._z):
			spin.lineEdit().setPlaceholderText("")
		self._x.setValue(float(v.x()))
		self._y.setValue(float(v.y()))
		self._z.setValue(float(v.z()))

	def set_mixed(self, mixed: bool = True) -> None:
		"""Show placeholder '-' on each axis when values differ across selection."""
		for spin in (self._x, self._y, self._z):
			spin.blockSignals(True)
			if mixed:
				spin.lineEdit().clear()
				spin.lineEdit().setPlaceholderText("-")
			else:
				spin.lineEdit().setPlaceholderText("")
			spin.blockSignals(False)

	def _read_axis(self, spin: QDoubleSpinBox) -> float:
		text = spin.lineEdit().text().strip()
		if text in ("", "-"):
			return 0.0
		try:
			return float(text)
		except ValueError:
			return float(spin.value())

	def set_pick_active(self, active: bool) -> None:
		"""Visually indicate that this editor is waiting for a vertex pick."""
		if self._pick_btn is None:
			return
		self._pick_btn.setStyleSheet(
			_PICK_BUTTON_STYLE_ACTIVE if active else _PICK_BUTTON_STYLE_IDLE
		)
		self._pick_btn.setText("Picking..." if active else "Pick")

	def _on_pick_clicked(self) -> None:
		if self._on_pick is None:
			return
		self._on_pick()

	def _emit_changed(self) -> None:
		if self._on_changed is not None:
			self._on_changed(
				QVector3D(
					self._read_axis(self._x),
					self._read_axis(self._y),
					self._read_axis(self._z),
				)
			)

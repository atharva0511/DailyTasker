from __future__ import annotations

from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QHBoxLayout, QSizePolicy, QWidget, QPushButton

# Import resources to register them with Qt
try:
	import resources.resources_rc  # noqa: F401
except ImportError:
	pass  # Resources not available, will fall back to file paths


class PathToolbox(QWidget):
	"""
	Segment-creation tool buttons (line, arc, point, cancel) for PathGeneration.

	Embedded in the Inspector Toolbox dialog; driven by ``PathToolManager``.
	"""

	_BTN_PX = 30
	_ICON_PX = 24

	def __init__(self, tool_manager, parent: QWidget | None = None) -> None:
		super().__init__(parent)
		self._tool_manager = tool_manager

		self.setStyleSheet("""
			QPushButton {
				background-color: #444;
				color: white;
				border: 1px solid #666;
				padding: 2px;
				border-radius: 4px;
			}
			QPushButton:hover {
				background-color: #555;
				border-color: #888;
			}
			QPushButton:pressed {
				background-color: #333;
			}
			QPushButton:disabled {
				background-color: #333;
				border-color: #444;
				color: #666;
			}
			QPushButton#cancel_button:enabled {
				background-color: #553333;
				border: 1px solid #884444;
			}
			QPushButton#cancel_button:enabled:hover {
				background-color: #664444;
			}
		""")

		layout = QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(8)
		layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

		icon_size = QSize(self._ICON_PX, self._ICON_PX)
		icon_line_path = ":/icons/2p_line.svg"
		icon_arc_path = ":/icons/3p_cir_arc.svg"
		icon_point_path = ":/icons/1p_point.svg"
		icon_cancel_path = ":/icons/cancel.svg"

		self.btn_line = QPushButton(self)
		self.btn_line.setToolTip("Create Two-Point Line Segment")
		self.btn_line.setIcon(QIcon(icon_line_path))
		self.btn_line.setIconSize(icon_size)
		self.btn_line.setFixedSize(self._BTN_PX, self._BTN_PX)
		self.btn_line.clicked.connect(lambda: self._on_tool_button_clicked("line"))
		layout.addWidget(self.btn_line)

		self.btn_arc = QPushButton(self)
		self.btn_arc.setToolTip("Create Three-Point Arc Segment")
		self.btn_arc.setIcon(QIcon(icon_arc_path))
		self.btn_arc.setIconSize(icon_size)
		self.btn_arc.setFixedSize(self._BTN_PX, self._BTN_PX)
		self.btn_arc.clicked.connect(lambda: self._on_tool_button_clicked("arc"))
		layout.addWidget(self.btn_arc)

		self.btn_point = QPushButton(self)
		self.btn_point.setToolTip("Create Single-Point Segment")
		point_icon = QIcon(icon_point_path)
		if point_icon.isNull():
			self.btn_point.setText("•")
			self.btn_point.setStyleSheet("font-size: 18px; font-weight: bold;")
		else:
			self.btn_point.setIcon(point_icon)
			self.btn_point.setIconSize(icon_size)
		self.btn_point.setFixedSize(self._BTN_PX, self._BTN_PX)
		self.btn_point.clicked.connect(lambda: self._on_tool_button_clicked("point"))
		layout.addWidget(self.btn_point)

		self.btn_cancel = QPushButton(self)
		self.btn_cancel.setToolTip("Cancel active tool")
		self.btn_cancel.setObjectName("cancel_button")
		self.btn_cancel.setIcon(QIcon(icon_cancel_path))
		self.btn_cancel.setIconSize(icon_size)
		self.btn_cancel.setFixedSize(self._BTN_PX, self._BTN_PX)
		self.btn_cancel.setEnabled(False)
		self.btn_cancel.clicked.connect(self._tool_manager.cancel_tool)
		layout.addWidget(self.btn_cancel)

		if self._tool_manager:
			self._tool_manager.tool_active_changed.connect(self._on_tool_active_changed)

		self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)

	def _on_tool_button_clicked(self, tool_type: str) -> None:
		if self._tool_manager:
			self._tool_manager.start_feature_tool(tool_type)
		self._refresh_toolbox()

	def _refresh_toolbox(self) -> None:
		self.btn_line.update()
		self.btn_arc.update()
		self.btn_point.update()
		self.btn_cancel.update()
		self.update()

	def _on_tool_active_changed(self, is_active: bool) -> None:
		if is_active:
			self.btn_line.setEnabled(False)
			self.btn_arc.setEnabled(False)
			self.btn_point.setEnabled(False)
			self.btn_cancel.setEnabled(True)
		else:
			self.btn_line.setEnabled(True)
			self.btn_arc.setEnabled(True)
			self.btn_point.setEnabled(True)
			self.btn_cancel.setEnabled(False)
		self._refresh_toolbox()

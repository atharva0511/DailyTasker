from __future__ import annotations

from typing import Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QDialog, QDialogButtonBox, QTreeView, QVBoxLayout

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.ui.hierarchy_panel import _EntityTreeModel


class EntityBrowserDialog(QDialog):
	"""
	Reusable dialog for selecting entities from the scene.
	Displays a tree view of all entities (same as Hierarchy panel) and allows user to select one.
	"""
	
	def __init__(self, scene: Scene, parent=None) -> None:
		super().__init__(parent)
		self.setWindowTitle("Select Entity")
		self.setModal(True)
		self.setMinimumSize(400, 500)
		
		self._scene = scene
		self._selected_entity: Optional[Entity] = None
		
		# Create layout
		layout = QVBoxLayout(self)
		layout.setContentsMargins(12, 12, 12, 12)
		layout.setSpacing(8)
		
		# Create tree model and view
		self._model = _EntityTreeModel(scene)
		self._tree_view = QTreeView(self)
		self._tree_view.setModel(self._model)
		self._tree_view.setHeaderHidden(True)
		self._tree_view.setExpandsOnDoubleClick(False)
		self._tree_view.setSelectionMode(QTreeView.SelectionMode.SingleSelection)
		
		# Connect selection change
		self._tree_view.selectionModel().selectionChanged.connect(self._on_selection_changed)
		
		# Connect double-click to accept
		self._tree_view.doubleClicked.connect(self._on_double_clicked)
		
		layout.addWidget(self._tree_view)
		
		# Create button box
		self._button_box = QDialogButtonBox(
			QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
			Qt.Orientation.Horizontal,
			self
		)
		self._button_box.button(QDialogButtonBox.StandardButton.Ok).setText("Select")
		self._button_box.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
		self._button_box.accepted.connect(self.accept)
		self._button_box.rejected.connect(self.reject)
		
		layout.addWidget(self._button_box)
	
	def _on_selection_changed(self) -> None:
		"""Update selected entity and enable/disable Select button."""
		indexes = self._tree_view.selectionModel().selectedIndexes()
		if indexes:
			index = indexes[0]
			if index.isValid():
				entity: Entity = index.internalPointer()  # type: ignore[assignment]
				self._selected_entity = entity
				self._button_box.button(QDialogButtonBox.StandardButton.Ok).setEnabled(True)
				return
		
		self._selected_entity = None
		self._button_box.button(QDialogButtonBox.StandardButton.Ok).setEnabled(False)
	
	def _on_double_clicked(self, index) -> None:
		"""Handle double-click to accept selection."""
		if index.isValid():
			self.accept()
	
	def selected_entity(self) -> Optional[Entity]:
		"""Returns the selected entity, or None if dialog was cancelled."""
		return self._selected_entity


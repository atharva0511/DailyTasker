from __future__ import annotations
from typing import Optional, Callable
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QPushButton, QToolBar
from PyQt6.QtCore import Qt


class PlayModeRibbon(QWidget):
	"""
	Ribbon-style toolbar widget for Play Mode controls.
	Displays Play and Stop buttons similar to Unity's play controls.
	"""
	
	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._on_play_clicked: Optional[Callable[[], None]] = None
		self._on_stop_clicked: Optional[Callable[[], None]] = None
		self._on_pause_clicked: Optional[Callable[[], None]] = None
		self._on_resume_clicked: Optional[Callable[[], None]] = None
		
		# Ribbon styling - default (inactive)
		self._default_stylesheet = """
			QWidget {
				background-color: #2b2b2b;
				border-bottom: 1px solid #555;
			}
			QPushButton {
				background-color: #3c3c3c;
				color: white;
				border: 1px solid #555;
				padding: 6px 12px;
				border-radius: 4px;
				min-width: 80px;
				font-size: 11pt;
			}
			QPushButton:hover {
				background-color: #4a4a4a;
			}
			QPushButton:pressed {
				background-color: #2a2a2a;
			}
			QPushButton:disabled {
				background-color: #2a2a2a;
				border: 1px solid #444;
				color: #888;
			}
			QPushButton#play_button {
				background-color: #4a7c4a;
			}
			QPushButton#play_button:hover {
				background-color: #5a8c5a;
			}
			QPushButton#stop_button {
				background-color: #7c4a4a;
			}
			QPushButton#stop_button:hover {
				background-color: #8c5a5a;
			}
			QPushButton#pause_button {
				background-color: #7c7c4a;
			}
			QPushButton#pause_button:hover {
				background-color: #8c8c5a;
			}
		"""
		
		# Ribbon styling - active (green)
		self._active_stylesheet = """
			QWidget {
				background-color: #2b4a2b;
				border-bottom: 1px solid #4a7c4a;
			}
			QPushButton {
				background-color: #3c5c3c;
				color: white;
				border: 1px solid #4a7c4a;
				padding: 6px 12px;
				border-radius: 4px;
				min-width: 80px;
				font-size: 11pt;
			}
			QPushButton:hover {
				background-color: #4a6c4a;
			}
			QPushButton:pressed {
				background-color: #2a4a2a;
			}
			QPushButton:disabled {
				background-color: #2a4a2a;
				border: 1px solid #3a5c3a;
				color: #aaa;
			}
			QPushButton#play_button {
				background-color: #4a7c4a;
			}
			QPushButton#play_button:hover {
				background-color: #5a8c5a;
			}
			QPushButton#stop_button {
				background-color: #7c4a4a;
			}
			QPushButton#stop_button:hover {
				background-color: #8c5a5a;
			}
			QPushButton#pause_button {
				background-color: #7c7c4a;
			}
			QPushButton#pause_button:hover {
				background-color: #8c8c5a;
			}
		"""
		
		# Ribbon styling - paused (yellow)
		self._paused_stylesheet = """
			QWidget {
				background-color: #4a4a2b;
				border-bottom: 1px solid #7c7c4a;
			}
			QPushButton {
				background-color: #5c5c3c;
				color: white;
				border: 1px solid #7c7c4a;
				padding: 6px 12px;
				border-radius: 4px;
				min-width: 80px;
				font-size: 11pt;
			}
			QPushButton:hover {
				background-color: #6c6c4a;
			}
			QPushButton:pressed {
				background-color: #4a4a2a;
			}
			QPushButton:disabled {
				background-color: #4a4a2a;
				border: 1px solid #5c5c3a;
				color: #aaa;
			}
			QPushButton#play_button {
				background-color: #4a7c4a;
			}
			QPushButton#play_button:hover {
				background-color: #5a8c5a;
			}
			QPushButton#stop_button {
				background-color: #7c4a4a;
			}
			QPushButton#stop_button:hover {
				background-color: #8c5a5a;
			}
			QPushButton#pause_button {
				background-color: #7c7c4a;
			}
			QPushButton#pause_button:hover {
				background-color: #8c8c5a;
			}
		"""
		
		self.setStyleSheet(self._default_stylesheet)
		
		layout = QHBoxLayout(self)
		layout.setContentsMargins(8, 6, 8, 6)
		layout.setSpacing(8)
		
		# Add stretch before buttons to center them
		layout.addStretch()
		
		# Play button
		self._play_button = QPushButton("▶ Play", self)
		self._play_button.setObjectName("play_button")
		self._play_button.clicked.connect(self._on_play_button_clicked)
		layout.addWidget(self._play_button)
		
		# Pause/Resume button (initially disabled)
		self._pause_button = QPushButton("⏸ Pause", self)
		self._pause_button.setObjectName("pause_button")
		self._pause_button.setEnabled(False)
		self._pause_button.clicked.connect(self._on_pause_button_clicked)
		layout.addWidget(self._pause_button)

		# Stop button (initially disabled)
		self._stop_button = QPushButton("⏹ Stop", self)
		self._stop_button.setObjectName("stop_button")
		self._stop_button.setEnabled(False)
		self._stop_button.clicked.connect(self._on_stop_button_clicked)
		layout.addWidget(self._stop_button)
		
		# Add stretch after buttons to center them
		layout.addStretch()
	
	def set_play_callbacks(self, on_play: Callable[[], None], on_stop: Callable[[], None], on_pause: Optional[Callable[[], None]] = None, on_resume: Optional[Callable[[], None]] = None) -> None:
		"""Set callbacks for Play, Stop, Pause, and Resume button clicks."""
		self._on_play_clicked = on_play
		self._on_stop_clicked = on_stop
		self._on_pause_clicked = on_pause
		self._on_resume_clicked = on_resume
	
	def set_play_mode(self, is_playing: bool, is_paused: bool = False) -> None:
		"""Update button states and ribbon color based on play mode and pause state."""
		self._play_button.setEnabled(not is_playing)
		self._stop_button.setEnabled(is_playing)
		self._pause_button.setEnabled(is_playing)
		
		# Update pause button text and state
		if is_playing:
			if is_paused:
				self._pause_button.setText("▶ Resume")
			else:
				self._pause_button.setText("⏸ Pause")
		
		# Change ribbon color: yellow when paused, green when active, default when inactive
		# Apply stylesheet to both this widget and parent toolbar if it exists
		if is_playing:
			if is_paused:
				stylesheet = self._paused_stylesheet
			else:
				stylesheet = self._active_stylesheet
		else:
			stylesheet = self._default_stylesheet
		
		self.setStyleSheet(stylesheet)
		
		# Also apply to parent toolbar if it's a QToolBar
		parent = self.parent()
		if isinstance(parent, QToolBar):
			parent.setStyleSheet(stylesheet)
		
		# Force update to ensure stylesheet is applied
		self.update()
		if isinstance(parent, QToolBar):
			parent.update()
	
	def _on_play_button_clicked(self) -> None:
		"""Handle Play button click."""
		if self._on_play_clicked:
			self._on_play_clicked()
	
	def _on_stop_button_clicked(self) -> None:
		"""Handle Stop button click."""
		if self._on_stop_clicked:
			self._on_stop_clicked()
	
	def _on_pause_button_clicked(self) -> None:
		"""Handle Pause/Resume button click."""
		# Toggle between pause and resume based on current button text
		if self._pause_button.text() == "⏸ Pause":
			if self._on_pause_clicked:
				self._on_pause_clicked()
		else:
			if self._on_resume_clicked:
				self._on_resume_clicked()


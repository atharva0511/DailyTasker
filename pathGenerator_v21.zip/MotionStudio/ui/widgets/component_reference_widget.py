from __future__ import annotations

from typing import Callable, Optional, Type

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QDialog, QHBoxLayout, QLabel, QMessageBox, QPushButton, QWidget

from MotionStudio.core.ecs.component import Component
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel


class ComponentReferenceWidget(QWidget):
	"""
	Widget for selecting an entity that contains a specific component type.
	Similar to Unity's component reference system.
	
	Displays:
	- Label showing component type name
	- Input-like button showing entity name or "None"
	- Browse button to open entity browser
	"""
	
	def __init__(
		self,
		component_type: Type[Component],
		scene: Scene,
		current_entity_id: Optional[str],
		on_entity_selected: Callable[[Optional[str]], None],
		selection: Optional[SelectionModel] = None,
		parent=None
	) -> None:
		super().__init__(parent)
		
		self._component_type = component_type
		self._scene = scene
		self._current_entity_id = current_entity_id
		self._on_entity_selected = on_entity_selected
		self._selection = selection
		
		# Get component type name for display
		component_type_name = getattr(component_type, "type_name", component_type.__name__)
		
		# Create layout
		layout = QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(4)
		
		# Note: The field name label is added by InspectorPanel
		# Add a label showing the component type name
		self._type_label = QLabel(f"({component_type_name})", self)
		self._type_label.setStyleSheet("color: #888; font-size: 10pt;")
		layout.addWidget(self._type_label)
		
		# Input-like button (styled to look like QLineEdit)
		self._input_button = QPushButton(self)
		self._input_button.setObjectName("component_reference_input")
		self._input_button.setToolTip(f"Select entity with {component_type_name} component")
		self._input_button.setStyleSheet("""
			QPushButton#component_reference_input {
				background-color: #2b2b2b;
				border: 1px solid #555;
				border-radius: 2px;
				padding: 4px 8px;
				text-align: left;
				min-height: 22px;
			}
			QPushButton#component_reference_input:hover {
				border-color: #777;
			}
			QPushButton#component_reference_input:pressed {
				background-color: #333;
			}
		""")
		# Clicking the input button: if entity exists, select it; otherwise open browser
		self._input_button.clicked.connect(self._on_input_button_clicked)
		layout.addWidget(self._input_button, 1)  # Stretch to fill space
		
		# Browse button
		self._browse_button = QPushButton("...", self)
		self._browse_button.setFixedWidth(30)
		self._browse_button.setToolTip("Browse entities")
		self._browse_button.clicked.connect(self._on_browse_clicked)
		layout.addWidget(self._browse_button)
		
		# Update display with current value
		self._update_display()
	
	def _update_display(self) -> None:
		"""Update the input button text based on current entity ID."""
		if self._current_entity_id is None:
			self._input_button.setText("None")
			return
		
		# Look up entity
		entity = self._scene.find_by_id(self._current_entity_id)
		if entity is None:
			# Entity doesn't exist (was deleted)
			self._input_button.setText("None")
			self._current_entity_id = None
			# Optionally clear invalid reference
			if self._on_entity_selected:
				self._on_entity_selected(None)
			return
		
		# Validate entity has the required component
		component = entity.get_component(self._component_type)
		if component is None:
			# Entity exists but doesn't have the component
			self._input_button.setText("None")
			self._current_entity_id = None
			# Optionally clear invalid reference
			if self._on_entity_selected:
				self._on_entity_selected(None)
			return
		
		# Valid entity with component - show entity name
		self._input_button.setText(entity.name)
	
	def _on_input_button_clicked(self) -> None:
		"""Handle input button click: select entity if valid, otherwise open browser."""
		if self._current_entity_id is not None:
			# Try to find and select the referenced entity
			entity = self._scene.find_by_id(self._current_entity_id)
			if entity is not None:
				# Validate entity has the required component
				component = entity.get_component(self._component_type)
				if component is not None:
					# Valid entity - select it
					if self._selection is not None:
						self._selection.set_current(entity)
					return
		
		# No valid entity or entity doesn't have component - open browser
		self._on_browse_clicked()
	
	def _on_browse_clicked(self) -> None:
		"""Open entity browser dialog."""
		from MotionStudio.ui.widgets.entity_browser_dialog import EntityBrowserDialog
		
		dialog = EntityBrowserDialog(self._scene, self)
		if dialog.exec() == QDialog.DialogCode.Accepted:
			selected_entity = dialog.selected_entity()
			if selected_entity is None:
				# Clear selection
				self._current_entity_id = None
				self._input_button.setText("None")
				if self._on_entity_selected:
					self._on_entity_selected(None)
				return
			
			# Validate entity has the required component
			component = selected_entity.get_component(self._component_type)
			if component is None:
				# Show error message
				component_type_name = getattr(self._component_type, "type_name", self._component_type.__name__)
				QMessageBox.warning(
					self,
					"Invalid Selection",
					f"Selected entity '{selected_entity.name}' does not have {component_type_name} component."
				)
				return
			
			# Valid selection - update
			self._current_entity_id = selected_entity.id
			self._input_button.setText(selected_entity.name)
			if self._on_entity_selected:
				self._on_entity_selected(selected_entity.id)


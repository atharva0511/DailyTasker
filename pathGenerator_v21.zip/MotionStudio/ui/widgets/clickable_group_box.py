from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QGroupBox
from PyQt6.QtGui import QMouseEvent


class ClickableGroupBox(QGroupBox):
	"""
	A QGroupBox that emits clicked() when the user clicks inside it.
	Used to make feature groups selectable from the Inspector.
	"""

	clicked = pyqtSignal()

	def mousePressEvent(self, event: QMouseEvent) -> None:
		try:
			self.clicked.emit()
		except Exception:
			pass
		super().mousePressEvent(event)



from __future__ import annotations

from typing import List, Optional, Tuple

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QVector3D, QUndoStack
from PyQt6.QtWidgets import (
	QCheckBox,
	QComboBox,
	QDoubleSpinBox,
	QFileDialog,
	QFormLayout,
	QGroupBox,
	QHBoxLayout,
	QLabel,
	QLineEdit,
	QMenu,
	QMessageBox,
	QPushButton,
	QScrollArea,
	QSizePolicy,
	QSpinBox,
	QStyle,
	QToolButton,
	QVBoxLayout,
	QWidget,
	QColorDialog,
)
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
from MotionStudio.core.components.feature import (
	TwoPointLineFeature,
	ThreePointArcFeature,
	SinglePointFeature,
	CustomFeature,
	segment_display_name,
)
from MotionStudio.ui.inspector.path_segment_settings_dialog import PathSegmentSettingsDialog
from MotionStudio.ui.inspector.path_toolbox_dialog import PathToolboxDialog
from MotionStudio.ui.inspector.path_program_settings_dialog import PathProgramSettingsDialog
from MotionStudio.ui.widgets.vector3_editor import Vector3Editor
from MotionStudio.ui.widgets.clickable_group_box import ClickableGroupBox
from MotionStudio.core.ecs.component import get_registered_components
from MotionStudio.core.undo.commands import (
	AddComponentCommand,
	PropertyChangeCommand,
	RemoveComponentCommand,
	ReorderPathFeatureCommand,
	ConvertToCustomFeatureCommand,
)
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, FolderPath, Header, Hidden, Range, ReadOnly, Tooltip, VertexPick
from MotionStudio.ui.inspector.group_popup import InspectorGroupPopup
from MotionStudio.ui.inspector.reflection import (
	FieldSpec,
	InspectorLayoutRow,
	clone_value,
	iter_editable_fields,
	iter_inspector_layout,
	is_literal_type,
	literal_choices,
	partition_inspector_layout,
)
from MotionStudio.ui.inspector.multi_values import (
	FieldValue,
	common_component_types,
	entity_name_field_value,
	field_value_for,
	find_component,
)
from MotionStudio.utils.mesh_assets import import_mesh_into_project, has_source_material_sidecar


class InspectorPanel(QWidget):
	_ICON_TOOL_BUTTON_PX = 30
	_BORDERED_TOOL_BUTTON_QSS = """
QToolButton {
	border: 1px solid #666;
	border-radius: 4px;
	padding: 2px;
	background-color: #444;
}
QToolButton:hover {
	background-color: #555;
	border-color: #888;
}
QToolButton:pressed {
	background-color: #333;
}
QToolButton:disabled {
	background-color: #333;
	border-color: #444;
	color: #666;
}
"""

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._selection: Optional[SelectionModel] = None
		self.setMinimumWidth(360)
		self._scene: Optional[Scene] = None
		self._undo_stack: Optional[QUndoStack] = None
		self._vertex_pick_manager = None
		self._path_tool_manager = None
		self._active_pick_editor: Optional[Vector3Editor] = None
		self._defer_rebuild: bool = False
		self._pending_rebuild_entity_id: Optional[str] = None
		self._scroll = QScrollArea(self)
		self._scroll.setWidgetResizable(True)
		self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
		self._content = QWidget(self._scroll)
		self._scroll.setWidget(self._content)
		self._vbox = QVBoxLayout(self._content)
		self._vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
		# Feature index -> widget, used for auto-scroll when selecting a feature
		self._path_feature_widgets: dict[int, QWidget] = {}

		layout = QVBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.addWidget(self._scroll)

	def bind_selection(self, selection: SelectionModel) -> None:
		if self._selection is not None:
			try:
				self._selection.current_entity_changed.disconnect(self._on_selection_changed)
			except Exception:
				pass
			try:
				self._selection.selection_changed.disconnect(self._on_selection_changed)
			except Exception:
				pass
			try:
				self._selection.current_feature_changed.disconnect(self._on_feature_selection_changed)
			except Exception:
				pass
		self._selection = selection
		selection.selection_changed.connect(self._on_selection_changed)
		selection.current_entity_changed.connect(self._on_selection_changed)
		try:
			selection.current_feature_changed.connect(self._on_feature_selection_changed)
		except Exception:
			pass
		try:
			selection.interaction_active_changed.connect(self._on_interaction_active_changed)
		except Exception:
			pass

	def bind_scene(self, scene: Scene) -> None:
		# Disconnect previous scene if any
		try:
			if self._scene is not None:
				self._scene.events.entity_changed.disconnect(self._on_scene_entity_changed)
		except Exception:
			pass
		self._scene = scene
		# Rebuild inspector when the currently selected entity changes (e.g. features added/removed)
		try:
			scene.events.entity_changed.connect(self._on_scene_entity_changed)
		except Exception:
			pass

	def _on_scene_entity_changed(self, entity_id: str) -> None:
		if self._selection is None:
			return
		if entity_id not in self._selection.selected_ids():
			return
		# During gizmo drags we intentionally defer expensive rebuilds
		if self._defer_rebuild:
			self._pending_rebuild_entity_id = entity_id
			return
		self._rebuild_for_selection()

	def _on_interaction_active_changed(self, active: bool) -> None:
		self._defer_rebuild = bool(active)
		if not self._defer_rebuild and self._pending_rebuild_entity_id is not None:
			# Rebuild once after interaction ends
			if self._selection is not None and self._pending_rebuild_entity_id in self._selection.selected_ids():
				self._rebuild_for_selection()
			self._pending_rebuild_entity_id = None
	def bind_undo_stack(self, undo_stack: QUndoStack) -> None:
		self._undo_stack = undo_stack
		try:
			# Rebuild on undo/redo so widgets reflect current values
			undo_stack.indexChanged.connect(lambda _idx: self._rebuild_for_selection())
		except Exception:
			pass

	def bind_path_tool_manager(self, manager) -> None:
		self._path_tool_manager = manager

	def bind_vertex_pick_manager(self, manager) -> None:
		"""Bind the VertexPickToolManager used by VertexPick-annotated QVector3D fields."""
		self._vertex_pick_manager = manager
		try:
			manager.tool_active_changed.connect(self._on_vertex_pick_active_changed)
		except Exception:
			pass
		# Refresh inspector when entities are reparented
		try:
			scene.events.entity_reparented.connect(self._on_scene_reparented)
		except Exception:
			pass

	def _on_selection_changed(self, *_args) -> None:
		self._rebuild_for_selection()

	def _rebuild_for_selection(self) -> None:
		if self._selection is None:
			self._clear()
			return
		entities = self._selection.selected_entities()
		if len(entities) == 0:
			self._clear()
		elif len(entities) == 1:
			self._rebuild_for_entity(entities[0])
		else:
			self._rebuild_for_multi(entities)

	def _on_feature_selection_changed(self, _feature_idx) -> None:
		# Rebuild to update feature highlight styling.
		if self._selection is None:
			return
		self._rebuild_for_selection()
		# After rebuild, ensure selected feature is scrolled into view.
		try:
			idx = self._selection.current_feature_idx
			if idx is None:
				return
			w = self._path_feature_widgets.get(int(idx))
			if w is None:
				return
			QTimer.singleShot(0, lambda ww=w: self._scroll.ensureWidgetVisible(ww))
		except Exception:
			pass

	def _on_scene_reparented(self, child_id: str, _new_parent_id) -> None:
		if self._selection is not None and child_id in self._selection.selected_ids():
			self._rebuild_for_selection()

	def _clear(self) -> None:
		self._path_feature_widgets.clear()
		while self._vbox.count():
			item = self._vbox.takeAt(0)
			w = item.widget()
			if w is not None:
				w.deleteLater()

	def _rebuild_for_entity(self, entity: Optional[Entity]) -> None:
		self._clear()
		if entity is None:
			return
		# Entity group (name uses the same property-change command, targeting __entity__)
		gb_entity = QGroupBox("Entity", self._content)
		form_entity = QFormLayout(gb_entity)
		name_edit = QLineEdit(self._content)
		name_edit.setText(entity.name)
		name_edit.editingFinished.connect(lambda e=entity, w=name_edit: self._push_entity_field_change(e, "name", w.text()))
		form_entity.addRow("Name", name_edit)
		self._vbox.addWidget(gb_entity)

		# Auto-generate component UIs (Transform included, but not removable)
		for comp in entity.components:
			type_name = getattr(comp, "type_name", comp.__class__.__name__)
			gb = QGroupBox(type_name, self._content)
			form = QFormLayout(gb)
			if type_name not in ("Transform", "TransformComponent"):
				self._add_remove_component_row(form, entity=entity, component=comp, type_name=type_name, emit_scene_change=True)
			
			if type_name == "PathGeneration":
				self._build_path_generation_ui(entity, comp, form)
			elif type_name == "RobotDescription":
				self._build_robot_description_ui(entity, comp, form)
			else:
				self._build_component_fields(entity, comp, form)
			self._vbox.addWidget(gb)

		# Footer: full-width "Add Component" button
		add_btn = QPushButton("Add Component", self._content)
		add_btn.setToolTip("Add Component")
		add_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		add_btn.setMinimumHeight(28)
		add_btn.clicked.connect(lambda checked=False, e=entity, btn=add_btn: self._open_add_component_menu(e, btn))
		self._vbox.addWidget(add_btn)

		self._vbox.addStretch(1)

	def _rebuild_for_multi(self, entities: List[Entity]) -> None:
		self._clear()
		if not entities:
			return
		primary = self._selection.current if self._selection is not None else None
		header = QLabel(
			f"Selection ({len(entities)}) — primary: {primary.name if primary is not None else '-'}",
			self._content,
		)
		header.setWordWrap(True)
		self._vbox.addWidget(header)

		gb_entity = QGroupBox("Entity", self._content)
		form_entity = QFormLayout(gb_entity)
		name_fv = entity_name_field_value(entities)
		name_edit = QLineEdit(self._content)
		if name_fv.kind == "mixed":
			name_edit.clear()
			name_edit.setPlaceholderText("-")
		else:
			name_edit.setText(str(name_fv.value or ""))
		name_edit.editingFinished.connect(
			lambda ents=entities, w=name_edit: self._push_bulk_entity_field_change(ents, "name", w.text())
		)
		form_entity.addRow("Name", name_edit)
		self._vbox.addWidget(gb_entity)

		for comp_type in common_component_types(entities):
			prototype = find_component(entities[0], comp_type)
			if prototype is None:
				continue
			gb = QGroupBox(comp_type, self._content)
			form = QFormLayout(gb)
			if comp_type not in ("Transform", "TransformComponent"):
				self._add_remove_component_row_multi(form, entities, comp_type)
			self._build_component_fields_multi(entities, comp_type, prototype, form)
			self._vbox.addWidget(gb)

		add_btn = QPushButton("Add Component", self._content)
		add_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		add_btn.setMinimumHeight(28)
		add_btn.clicked.connect(lambda _c=False, ents=entities, btn=add_btn: self._open_add_component_menu_multi(ents, btn))
		self._vbox.addWidget(add_btn)
		self._vbox.addStretch(1)

	def _add_remove_component_row(
		self,
		form: QFormLayout,
		*,
		entity: Entity,
		component,
		type_name: str,
		emit_scene_change: bool,
	) -> None:
		"""
		Add a small remove-component button aligned to the top-right of a component group.
		"""
		row = QWidget(self._content)
		row_layout = QHBoxLayout(row)
		row_layout.setContentsMargins(0, 0, 0, 0)
		row_layout.addStretch(1)
		rm_btn = QToolButton(row)
		rm_btn.setText("✕")
		rm_btn.setToolTip(f"Remove {type_name} Component")
		rm_btn.setAutoRaise(True)
		rm_btn.clicked.connect(lambda _checked=False, e=entity, comp=component: self._remove_component(e, comp, emit_scene_change))
		row_layout.addWidget(rm_btn, 0, Qt.AlignmentFlag.AlignRight)
		try:
			form.insertRow(0, row)
		except Exception:
			# Fallback: add as first row (will appear just under the title)
			form.addRow(row)

	def _remove_component(self, entity: Entity, component, emit_scene_change: bool) -> None:
		if self._scene is None or self._undo_stack is None:
			# Fallback: direct removal
			try:
				entity.remove_component(component)
			finally:
				if emit_scene_change and self._scene is not None:
					self._scene.events.entity_changed.emit(entity.id)
					self._rebuild_for_entity(entity)
					return
		
		# Use undo command
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		comp_snapshot = component.to_dict()
		cmd = RemoveComponentCommand(self._scene, entity.id, comp_type, comp_snapshot)
		self._undo_stack.push(cmd)
		self._rebuild_for_entity(entity)

	def _build_component_fields_multi(
		self,
		entities: List[Entity],
		comp_type: str,
		prototype,
		form: QFormLayout,
	) -> None:
		rows = iter_inspector_layout(prototype)
		items, groups = partition_inspector_layout(rows)
		for kind, payload in items:
			if kind == "group":
				self._append_group_gear_row(
					form,
					str(payload),
					groups[str(payload)],
					entities=entities,
					comp_type=comp_type,
					prototype=prototype,
				)
			else:
				self._append_inspector_row_multi(form, payload, entities, comp_type, prototype)

	def _widget_for_field_multi(
		self,
		entities: List[Entity],
		comp_type: str,
		spec: FieldSpec,
		fv: FieldValue,
	) -> QWidget:
		typ = spec.typ
		mixed = fv.kind == "mixed"
		value = fv.value

		if is_literal_type(typ) and not mixed:
			choices = literal_choices(typ)
			combo = QComboBox(self._content)
			for c in choices:
				combo.addItem(str(c), c)
			idx = combo.findData(value)
			if idx != -1:
				combo.setCurrentIndex(idx)
			combo.currentIndexChanged.connect(
				lambda _i, ents=entities, ct=comp_type, s=spec, c=combo: self._push_bulk_comp_field_change(
					ents, ct, s.name, c.currentData()
				)
			)
			return combo
		if is_literal_type(typ) and mixed:
			edit = QLineEdit(self._content)
			edit.setPlaceholderText("-")
			edit.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=edit, choices=literal_choices(typ): self._apply_literal_text_bulk(
					ents, ct, s.name, w.text(), choices
				)
			)
			return edit

		if typ is bool or (not mixed and isinstance(value, bool)):
			cb = QCheckBox(self._content)
			if mixed:
				cb.setTristate(True)
				cb.setCheckState(Qt.CheckState.PartiallyChecked)
			else:
				cb.setTristate(False)
				cb.setChecked(bool(value))
			cb.clicked.connect(
				lambda _checked=False, ents=entities, ct=comp_type, s=spec, c=cb, m=mixed: self._on_multi_bool_checkbox_clicked(
					ents, ct, s, c, mixed=m
				)
			)
			return cb

		if typ is int or (not mixed and isinstance(value, int)):
			if mixed:
				edit = QLineEdit(self._content)
				edit.setPlaceholderText("-")
				edit.editingFinished.connect(
					lambda ents=entities, ct=comp_type, s=spec, w=edit: self._apply_int_text_bulk(ents, ct, s.name, w.text())
				)
				return edit
			sb = QSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(int(rng.min), int(rng.max))
				sb.setSingleStep(int(rng.step))
			else:
				sb.setRange(-2_000_000_000, 2_000_000_000)
			sb.setValue(int(value))
			sb.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=sb: self._push_bulk_comp_field_change(ents, ct, s.name, int(w.value()))
			)
			return sb

		if typ is float or (not mixed and isinstance(value, float)):
			if mixed:
				edit = QLineEdit(self._content)
				edit.setPlaceholderText("-")
				edit.editingFinished.connect(
					lambda ents=entities, ct=comp_type, s=spec, w=edit: self._apply_float_text_bulk(ents, ct, s.name, w.text())
				)
				return edit
			sb = QDoubleSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(float(rng.min), float(rng.max))
				sb.setSingleStep(float(rng.step))
				if rng.decimals is not None:
					sb.setDecimals(int(rng.decimals))
			else:
				sb.setRange(-1e12, 1e12)
				sb.setSingleStep(0.1)
			sb.setValue(float(value))
			sb.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=sb: self._push_bulk_comp_field_change(ents, ct, s.name, float(w.value()))
			)
			return sb

		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if typ is _QVector3D or (not mixed and isinstance(value, _QVector3D)):
				editor = Vector3Editor(self._content, on_changed=lambda v, ents=entities, ct=comp_type, sn=spec.name: self._push_bulk_comp_field_change(ents, ct, sn, v))
				if mixed:
					editor.set_mixed(True)
				else:
					editor.set_value(value)
				return editor
		except Exception:
			pass

		try:
			from PyQt6.QtGui import QColor

			if typ is QColor or (not mixed and isinstance(value, QColor)) or any(isinstance(m, ColorField) for m in spec.metadata):
				btn = QPushButton(self._content)
				btn.setFixedHeight(22)
				if mixed:
					self._apply_color_button_style_mixed(btn)
				else:
					self._apply_color_button_style(btn, value)

				def _pick_color(_c=False, ents=entities, ct=comp_type, s=spec, b=btn):
					from PyQt6.QtGui import QColor as _QColor

					start = value if isinstance(value, _QColor) else _QColor(128, 128, 128)
					col = QColorDialog.getColor(start, self, "Select Color")
					if col.isValid():
						self._push_bulk_comp_field_change(ents, ct, s.name, col)
						self._apply_color_button_style(b, col)

				btn.clicked.connect(_pick_color)
				return btn
		except Exception:
			pass

		if any(isinstance(m, FilePath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			if mixed:
				edit.setPlaceholderText("-")
			else:
				edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FilePath)), FilePath())
			browse = QPushButton("Browse", row)
			browse.clicked.connect(
				lambda _c=False, ents=entities, ct=comp_type, s=spec, m=meta, w=edit: self._browse_path_bulk(ents, ct, s.name, m, w)
			)
			edit.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=edit: self._push_bulk_comp_field_change(ents, ct, s.name, w.text())
			)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# Component refs, VertexPick: disabled in multi-select
		if any(isinstance(m, VertexPick) and m.enabled for m in spec.metadata):
			lbl = QLabel("-", self._content)
			lbl.setToolTip("Vertex pick requires a single selection")
			return lbl

		edit = QLineEdit(self._content)
		if mixed:
			edit.setPlaceholderText("-")
		else:
			edit.setText("" if value is None else str(value))
		edit.editingFinished.connect(
			lambda ents=entities, ct=comp_type, s=spec, w=edit: self._push_bulk_comp_field_change(ents, ct, s.name, w.text())
		)
		return edit

	def _apply_literal_text_bulk(self, entities, comp_type, field, text: str, choices) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		for c in choices:
			if str(c) == text:
				self._push_bulk_comp_field_change(entities, comp_type, field, c)
				return

	def _apply_int_text_bulk(self, entities, comp_type, field, text: str) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		try:
			self._push_bulk_comp_field_change(entities, comp_type, field, int(text))
		except ValueError:
			pass

	def _apply_float_text_bulk(self, entities, comp_type, field, text: str) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		try:
			self._push_bulk_comp_field_change(entities, comp_type, field, float(text))
		except ValueError:
			pass

	def _browse_path_bulk(self, entities, comp_type, field, meta: FilePath, edit: QLineEdit) -> None:
		file, _ = QFileDialog.getOpenFileName(self, meta.dialog_title, "", meta.filter)
		if file:
			edit.setText(file)
			self._push_bulk_comp_field_change(entities, comp_type, field, file)

	def _add_remove_component_row_multi(self, form: QFormLayout, entities: List[Entity], comp_type: str) -> None:
		row = QWidget(self._content)
		row_layout = QHBoxLayout(row)
		row_layout.setContentsMargins(0, 0, 0, 0)
		row_layout.addStretch(1)
		rm_btn = QToolButton(row)
		rm_btn.setText("✕")
		rm_btn.setToolTip(f"Remove {comp_type} from all selected entities")
		rm_btn.clicked.connect(lambda _c=False, ents=entities, ct=comp_type: self._remove_component_multi(ents, ct))
		row_layout.addWidget(rm_btn, 0, Qt.AlignmentFlag.AlignRight)
		form.addRow(row)

	def _remove_component_multi(self, entities: List[Entity], comp_type: str) -> None:
		if self._scene is None or self._undo_stack is None:
			return
		targets = [(e, find_component(e, comp_type)) for e in entities]
		targets = [(e, c) for e, c in targets if c is not None]
		if not targets:
			return
		if len(targets) > 1:
			self._undo_stack.beginMacro(f"Remove {comp_type} ({len(targets)} objects)")
		try:
			for ent, comp in targets:
				snapshot = comp.to_dict()
				self._undo_stack.push(RemoveComponentCommand(self._scene, ent.id, comp_type, snapshot))
		finally:
			if len(targets) > 1:
				self._undo_stack.endMacro()
		self._rebuild_for_selection()

	def _invoke_inspector_button_multi(self, entities: List[Entity], comp_type: str, method, label: str) -> None:
		for ent in entities:
			comp = find_component(ent, comp_type)
			if comp is None:
				continue
			try:
				bound = getattr(comp, method.__name__)
				bound()
			except Exception as ex:
				import traceback
				print(f"Inspector button '{label}' on {ent.name} raised: {ex}", flush=True)
				traceback.print_exc()
		if self._scene is not None:
			for ent in entities:
				self._scene.events.entity_changed.emit(ent.id)
		self._rebuild_for_selection()

	def _open_add_component_menu_multi(self, entities: List[Entity], anchor_widget: QWidget) -> None:
		menu = QMenu(anchor_widget)
		registry = get_registered_components()
		for type_name, cls in registry.items():
			if type_name in ("Transform", "TransformComponent"):
				continue
			action = menu.addAction(type_name)

			def _add(_c=False, ents=entities, comp_cls=cls, tn=type_name):
				to_add = [e for e in ents if e.get_component(comp_cls) is None]
				if not to_add:
					QMessageBox.warning(self, "Add Component", f"All selected entities already have {tn}.")
					return
				if self._undo_stack is not None and self._scene is not None:
					if len(to_add) > 1:
						self._undo_stack.beginMacro(f"Add {tn} ({len(to_add)} objects)")
					try:
						for e in to_add:
							instance = comp_cls()  # type: ignore[call-arg]
							self._undo_stack.push(
								AddComponentCommand(self._scene, e.id, tn, instance.to_dict())
							)
					finally:
						if len(to_add) > 1:
							self._undo_stack.endMacro()
				self._rebuild_for_selection()

			action.triggered.connect(_add)
		menu.exec(anchor_widget.mapToGlobal(anchor_widget.rect().bottomRight()))

	def _push_bulk_entity_field_change(self, entities: List[Entity], field: str, new_value) -> None:
		if self._scene is None or self._undo_stack is None:
			for e in entities:
				setattr(e, field, new_value)
			return
		changes = []
		for e in entities:
			old = clone_value(getattr(e, field))
			if old != new_value:
				changes.append((e.id, old))
		if not changes:
			return
		label = f"Change Entity.{field} ({len(changes)} objects)"
		self._undo_stack.beginMacro(label)
		try:
			for entity_id, old in changes:
				self._undo_stack.push(
					PropertyChangeCommand(
						self._scene, entity_id, "__entity__", field, old, clone_value(new_value), text=f"Entity.{field}"
					)
				)
		finally:
			self._undo_stack.endMacro()

	def _on_multi_bool_checkbox_clicked(
		self,
		entities: List[Entity],
		comp_type: str,
		spec: FieldSpec,
		checkbox: QCheckBox,
		*,
		mixed: bool,
	) -> None:
		"""
		Bulk-edit bool fields from the inspector.

		Tristate is only used for mixed multi-selection. A click on the dash
		sets all targets to True. Uniform values use a normal two-state checkbox
		so one click toggles without passing through PartiallyChecked.
		"""
		state = checkbox.checkState()
		if mixed and state == Qt.CheckState.PartiallyChecked:
			checkbox.blockSignals(True)
			checkbox.setTristate(False)
			checkbox.setChecked(True)
			checkbox.blockSignals(False)
			new_value = True
		else:
			new_value = checkbox.isChecked()
		self._push_bulk_comp_field_change(entities, comp_type, spec.name, new_value)

	def _push_bulk_comp_field_change(
		self,
		entities: List[Entity],
		comp_type: str,
		field: str,
		new_value,
	) -> None:
		if self._scene is None or self._undo_stack is None:
			for e in entities:
				comp = find_component(e, comp_type)
				if comp is not None:
					setattr(comp, field, new_value)
			return
		changes = []
		for e in entities:
			comp = find_component(e, comp_type)
			if comp is None:
				continue
			old = clone_value(getattr(comp, field, None))
			if old != new_value:
				changes.append((e.id, old))
		if not changes:
			return
		label = f"Change {comp_type}.{field} ({len(changes)} objects)"
		self._undo_stack.beginMacro(label)
		try:
			for entity_id, old in changes:
				self._undo_stack.push(
					PropertyChangeCommand(
						self._scene,
						entity_id,
						comp_type,
						field,
						old,
						clone_value(new_value),
						text=f"{comp_type}.{field}",
					)
				)
		finally:
			self._undo_stack.endMacro()

	def _push_entity_field_change(self, entity: Entity, field: str, new_value) -> None:
		if self._scene is None or self._undo_stack is None:
			# fallback
			setattr(entity, field, new_value)
			return
		old = clone_value(getattr(entity, field))
		if old == new_value:
			return
		cmd = PropertyChangeCommand(self._scene, entity.id, "__entity__", field, old, clone_value(new_value), text=f"Entity.{field}")
		self._undo_stack.push(cmd)

	def _build_component_fields(self, entity: Entity, component, form: QFormLayout) -> None:
		"""
		Build editor widgets for a component using typing.Annotated metadata.
		Fields and @inspector_button rows share one ``Order`` / ``order`` sort key.
		"""
		rows = iter_inspector_layout(component)
		items, groups = partition_inspector_layout(rows)
		for kind, payload in items:
			if kind == "group":
				self._append_group_gear_row(
					form,
					str(payload),
					groups[str(payload)],
					entity=entity,
					component=component,
				)
			else:
				self._append_inspector_row_single(form, payload, entity, component)

	def _append_header_if_present(self, form: QFormLayout, metadata: tuple) -> None:
		for m in metadata:
			if isinstance(m, Header):
				hdr = QLabel(m.text, self._content)
				font = hdr.font()
				font.setBold(True)
				hdr.setFont(font)
				form.addRow(hdr)
				return

	def _append_inspector_rows_single(
		self,
		form: QFormLayout,
		rows: List[InspectorLayoutRow],
		entity: Entity,
		component,
	) -> None:
		for row in rows:
			self._append_inspector_row_single(form, row, entity, component)

	def _append_inspector_row_single(
		self,
		form: QFormLayout,
		row: InspectorLayoutRow,
		entity: Entity,
		component,
	) -> None:
		if row.kind == "field" and row.field_spec is not None:
			spec = row.field_spec
			self._append_header_if_present(form, spec.metadata)
			label = spec.name
			tooltip = next((m.text for m in spec.metadata if isinstance(m, Tooltip)), None)
			readonly = any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata)
			if (
				isinstance(component, TransformComponent)
				and entity.get_component(UrdfLinkComponent) is not None
			):
				readonly = True
			w = self._widget_for_field(entity, component, spec)
			if tooltip and hasattr(w, "setToolTip"):
				w.setToolTip(tooltip)
			try:
				w.setEnabled(not readonly)
			except Exception:
				pass
			form.addRow(label, w)
		elif row.kind == "button" and row.button_spec is not None and row.button_method is not None:
			spec = row.button_spec
			method = row.button_method
			btn = QPushButton(spec.label, self._content)
			if spec.tooltip:
				btn.setToolTip(spec.tooltip)
			btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
			btn.clicked.connect(
				lambda _checked=False, e=entity, m=method, lbl=spec.label: self._invoke_inspector_button(e, m, lbl)
			)
			form.addRow(btn)

	def _append_inspector_rows_multi(
		self,
		form: QFormLayout,
		rows: List[InspectorLayoutRow],
		entities: List[Entity],
		comp_type: str,
		prototype,
	) -> None:
		for row in rows:
			self._append_inspector_row_multi(form, row, entities, comp_type, prototype)

	def _append_inspector_row_multi(
		self,
		form: QFormLayout,
		row: InspectorLayoutRow,
		entities: List[Entity],
		comp_type: str,
		prototype,
	) -> None:
		if row.kind == "field" and row.field_spec is not None:
			spec = row.field_spec
			self._append_header_if_present(form, spec.metadata)
			fv = field_value_for(entities, comp_type, spec.name)
			readonly = any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata)
			w = self._widget_for_field_multi(entities, comp_type, spec, fv)
			tooltip = next((m.text for m in spec.metadata if isinstance(m, Tooltip)), None)
			if tooltip and hasattr(w, "setToolTip"):
				w.setToolTip(tooltip)
			try:
				w.setEnabled(not readonly)
			except Exception:
				pass
			form.addRow(spec.name, w)
		elif row.kind == "button" and row.button_spec is not None and row.button_method is not None:
			spec = row.button_spec
			btn = QPushButton(spec.label, self._content)
			if spec.tooltip:
				btn.setToolTip(spec.tooltip)
			btn.clicked.connect(
				lambda _c=False, ents=entities, m=row.button_method, lbl=spec.label: self._invoke_inspector_button_multi(
					ents, comp_type, m, lbl
				)
			)
			form.addRow(btn)

	def _apply_bordered_tool_button_style(
		self, btn: QToolButton, *, size_px: int | None = None
	) -> None:
		btn.setAutoRaise(False)
		btn.setStyleSheet(self._BORDERED_TOOL_BUTTON_QSS)
		if size_px is not None:
			btn.setFixedSize(size_px, size_px)
			btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

	def _make_bordered_icon_tool_button(
		self,
		parent: QWidget,
		icon: QStyle.StandardPixmap,
		tooltip: str,
		*,
		size_px: int | None = _ICON_TOOL_BUTTON_PX,
	) -> QToolButton:
		btn = QToolButton(parent)
		btn.setIcon(btn.style().standardIcon(icon))
		btn.setToolTip(tooltip)
		btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
		self._apply_bordered_tool_button_style(btn, size_px=size_px)
		return btn

	def _append_group_gear_row(
		self,
		form: QFormLayout,
		group_label: str,
		rows: List[InspectorLayoutRow],
		*,
		entity: Optional[Entity] = None,
		component=None,
		entities: Optional[List[Entity]] = None,
		comp_type: Optional[str] = None,
		prototype=None,
	) -> None:
		row_w = QWidget(self._content)
		h = QHBoxLayout(row_w)
		h.setContentsMargins(0, 0, 0, 0)
		h.addWidget(QLabel(group_label, row_w))
		gear = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_FileDialogDetailedView,
			f"Open {group_label}",
		)
		h.addWidget(gear)
		h.addStretch(1)
		gear.clicked.connect(
			lambda _c=False, g=group_label, r=rows, ent=entity, comp=component, ents=entities, ct=comp_type, proto=prototype: InspectorGroupPopup(
				self,
				g,
				r,
				entity=ent,
				component=comp,
				entities=ents,
				comp_type=ct,
				prototype=proto,
			)
		)
		form.addRow(row_w)

	def _invoke_inspector_button(self, entity: Entity, method, label: str) -> None:
		"""Run a component @inspector_button method, refresh the inspector."""
		try:
			method()
		except Exception as ex:
			import traceback
			print(f"Inspector button '{label}' raised: {ex}", flush=True)
			traceback.print_exc()
			return
		# Notify the scene so other panels / VTK actors refresh, then rebuild
		# this inspector so any field mutations done by the method appear.
		try:
			if self._scene is not None:
				self._scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass
		self._rebuild_for_entity(entity)

	def _widget_for_field(self, entity: Entity, component, spec: FieldSpec) -> QWidget:
		typ = spec.typ
		value = spec.getter()

		# Literal/Enum-like via typing.Literal
		if is_literal_type(typ):
			choices = literal_choices(typ)
			combo = QComboBox(self._content)
			for c in choices:
				combo.addItem(str(c), c)
			# set current
			idx = combo.findData(value)
			if idx != -1:
				combo.setCurrentIndex(idx)
			combo.currentIndexChanged.connect(
				lambda _i, e=entity, comp=component, s=spec, c=combo: self._push_comp_field_change(
					e, comp, s.name, c.currentData()
				)
			)
			return combo

		# Basic primitives
		if typ is bool or isinstance(value, bool):
			from PyQt6.QtWidgets import QCheckBox

			cb = QCheckBox(self._content)
			cb.setChecked(bool(value))
			cb.stateChanged.connect(lambda _st, e=entity, comp=component, s=spec, c=cb: self._push_comp_field_change(e, comp, s.name, bool(c.isChecked())))
			return cb

		if typ is int or isinstance(value, int):
			from PyQt6.QtWidgets import QSpinBox

			sb = QSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(int(rng.min), int(rng.max))
				sb.setSingleStep(int(rng.step))
			else:
				sb.setRange(-2_000_000_000, 2_000_000_000)
			sb.setValue(int(value))
			sb.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=sb: self._push_comp_field_change(e, comp, s.name, int(w.value())))
			return sb

		if typ is float or isinstance(value, float):
			

			sb = QDoubleSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(float(rng.min), float(rng.max))
				sb.setSingleStep(float(rng.step))
				if rng.decimals is not None:
					sb.setDecimals(int(rng.decimals))
			else:
				sb.setRange(-1e12, 1e12)
				sb.setSingleStep(0.1)
			sb.setValue(float(value))
			sb.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=sb: self._push_comp_field_change(e, comp, s.name, float(w.value())))
			return sb

		# QVector3D via existing Vector3Editor
		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if typ is _QVector3D or isinstance(value, _QVector3D):
				want_pick = any(isinstance(m, VertexPick) and m.enabled for m in spec.metadata)
				on_pick_cb = None
				if want_pick and self._vertex_pick_manager is not None:
					on_pick_cb = lambda e=entity, comp=component, s=spec: self._start_vertex_pick(e, comp, s)
				editor = Vector3Editor(
					self._content,
					initial=value,
					on_changed=lambda v, e=entity, comp=component, s=spec: self._push_comp_field_change(e, comp, s.name, v),
					on_pick=on_pick_cb,
				)
				try:
					editor.setProperty("ms_field_tag", f"{id(component)}::{spec.name}")
				except Exception:
					pass
				return editor
		except Exception:
			pass

		# QColor special case
		try:
			from PyQt6.QtGui import QColor

			if typ is QColor or isinstance(value, QColor) or any(isinstance(m, ColorField) for m in spec.metadata):
				btn = QPushButton(self._content)
				btn.setFixedHeight(22)
				self._apply_color_button_style(btn, value)
				def _pick_color(_checked=False, e=entity, comp=component, s=spec, b=btn):
					col = QColorDialog.getColor(value, self, "Select Color")
					if col.isValid():
						self._push_comp_field_change(e, comp, s.name, col)
						self._apply_color_button_style(b, col)
				btn.clicked.connect(_pick_color)
				return btn
		except Exception:
			pass

		# Component type reference (Optional[ComponentType])
		try:
			from typing import get_origin, get_args
			from MotionStudio.core.ecs.component import Component as ComponentBase
			from MotionStudio.ui.widgets.component_reference_widget import ComponentReferenceWidget
			
			# Check if type is Optional[ComponentType] or Union[ComponentType, None]
			origin = get_origin(typ)
			if origin is not None:
				args = get_args(typ)
				# Handle Optional (which is Union[T, None])
				import typing
				if origin is typing.Union:
					# Extract inner type (first non-None type)
					inner_type = None
					for arg in args:
						if arg is not type(None):
							inner_type = arg
							break
					
					if inner_type is not None:
						# Check if inner type is a Component subclass
						try:
							if issubclass(inner_type, ComponentBase):
								# This is a Component reference field
								# Value can be:
								# - Component instance (after resolution during load)
								# - entity_id string (during load, before resolution, or if resolution failed)
								# - None
								if isinstance(value, ComponentBase):
									# Already resolved to Component - extract entity_id
									entity_id = value.entity.id if value.entity is not None else None
								elif isinstance(value, str):
									# Still entity_id string (not yet resolved or resolution failed)
									entity_id = value
								else:
									# None
									entity_id = None
								
								if self._scene is None:
									# Fallback to string if no scene
									edit = QLineEdit(self._content)
									edit.setText("" if entity_id is None else str(entity_id))
									edit.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text() if w.text() else None))
									return edit
								
								# Create ComponentReferenceWidget
								# The callback needs to convert entity_id -> Component before setting the field
								def on_entity_selected_callback(selected_entity_id, e=entity, comp=component, s=spec, comp_type=inner_type):
									if selected_entity_id is None:
										# Clear reference
										self._push_comp_field_change(e, comp, s.name, None)
									else:
										# Convert entity_id -> Component
										target_entity = self._scene.find_by_id(selected_entity_id) if self._scene else None
										if target_entity is not None:
											target_component = target_entity.get_component(comp_type)
											if target_component is not None:
												self._push_comp_field_change(e, comp, s.name, target_component)
											else:
												# Entity doesn't have the component - clear
												self._push_comp_field_change(e, comp, s.name, None)
										else:
											# Entity doesn't exist - clear
											self._push_comp_field_change(e, comp, s.name, None)
								
								return ComponentReferenceWidget(
									component_type=inner_type,
									scene=self._scene,
									current_entity_id=entity_id,
									on_entity_selected=on_entity_selected_callback,
									selection=self._selection,
									parent=self._content
								)
						except TypeError:
							# Not a class type, skip
							pass
		except Exception:
			# If anything fails, fall through to default handling
			pass

		# FolderPath hint: lineedit + folder browse
		if any(isinstance(m, FolderPath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FolderPath)), FolderPath())
			browse = QPushButton("Browse", row)

			def _browse_folder(_checked=False, e=entity, comp=component, s=spec):
				folder = QFileDialog.getExistingDirectory(self, meta.dialog_title, edit.text() or "")
				if folder:
					edit.setText(folder)
					self._push_comp_field_change(e, comp, s.name, folder)

			browse.clicked.connect(_browse_folder)
			edit.editingFinished.connect(
				lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text())
			)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# FilePath hint: lineedit + browse
		if any(isinstance(m, FilePath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FilePath)), FilePath())
			browse = QPushButton("Browse", row)

			def _normalize_mesh_path_if_needed(raw: str) -> str:
				is_mesh_path = isinstance(component, MeshComponent) and spec.name == "custom_path"
				is_collider_path = isinstance(component, ColliderComponent) and spec.name == "collider_mesh_path"
				if not (is_mesh_path or is_collider_path):
					return raw
				if self._scene is None or self._scene.project_root is None:
					return raw
				if not raw.strip():
					return raw
				return import_mesh_into_project(self._scene.project_root, raw)

			def _browse(_checked=False, e=entity, comp=component, s=spec):
				file, _ = QFileDialog.getOpenFileName(self, meta.dialog_title, "", meta.filter)
				if file:
					try:
						file = _normalize_mesh_path_if_needed(file)
					except (FileNotFoundError, OSError) as ex:
						QMessageBox.warning(self, "Mesh", str(ex))
						return
					edit.setText(file)
					self._push_comp_field_change(e, comp, s.name, file)
					if isinstance(comp, MeshComponent) and s.name == "custom_path" and self._scene is not None:
						try:
							use_source = has_source_material_sidecar(self._scene.project_root, file)
							self._push_comp_field_change(e, comp, "source_material", bool(use_source))
						except Exception:
							pass
			browse.clicked.connect(_browse)

			def _on_path_edit_finished(e=entity, comp=component, s=spec, w=edit):
				text = w.text()
				is_mesh_path = isinstance(component, MeshComponent) and s.name == "custom_path"
				is_collider_path = isinstance(component, ColliderComponent) and s.name == "collider_mesh_path"
				if (is_mesh_path or is_collider_path) and text.strip():
					try:
						normalized = _normalize_mesh_path_if_needed(text)
						if normalized != text:
							w.setText(normalized)
							text = normalized
					except (FileNotFoundError, OSError):
						pass
				self._push_comp_field_change(e, comp, s.name, text)
				if isinstance(comp, MeshComponent) and s.name == "custom_path" and self._scene is not None:
					try:
						use_source = has_source_material_sidecar(self._scene.project_root, text)
						self._push_comp_field_change(e, comp, "source_material", bool(use_source))
					except Exception:
						pass

			edit.editingFinished.connect(_on_path_edit_finished)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# Default: string
		edit = QLineEdit(self._content)
		edit.setText("" if value is None else str(value))
		edit.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text()))
		return edit

	def _center_dialog_on_window(self, dialog: QWidget) -> None:
		try:
			window = self.window()
			if window is None:
				return
			center = window.frameGeometry().center()
			dialog.move(center.x() - dialog.width() // 2, center.y() - dialog.height() // 2)
		except Exception:
			pass

	def _append_path_program_settings_fields(
		self,
		form: QFormLayout,
		entity: Entity,
		comp: PathComponent,
	) -> None:
		parent = form.parentWidget()

		speed_sb = QDoubleSpinBox(parent)
		speed_sb.setRange(0.001, 10.0)
		speed_sb.setDecimals(4)
		speed_sb.setSingleStep(0.05)
		speed_sb.setSuffix(" m/s")
		speed_sb.setValue(comp.speed)
		speed_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=speed_sb: self._push_comp_field_change(e, c, "speed", float(w.value()))
		)
		form.addRow("Speed", speed_sb)

		accel_sb = QDoubleSpinBox(parent)
		accel_sb.setRange(0.001, 50.0)
		accel_sb.setDecimals(4)
		accel_sb.setSingleStep(0.1)
		accel_sb.setSuffix(" m/s²")
		accel_sb.setValue(comp.acceleration)
		accel_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=accel_sb: self._push_comp_field_change(
				e, c, "acceleration", float(w.value())
			)
		)
		form.addRow("Acceleration", accel_sb)

		default_cnt_sb = QDoubleSpinBox(parent)
		default_cnt_sb.setRange(0.0, 10.0)
		default_cnt_sb.setDecimals(6)
		default_cnt_sb.setSingleStep(0.001)
		default_cnt_sb.setSuffix(" m")
		default_cnt_sb.setValue(comp.default_cnt_radius)
		default_cnt_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=default_cnt_sb: self._push_comp_field_change(
				e, c, "default_cnt_radius", float(w.value())
			)
		)
		form.addRow("Default CNT Radius", default_cnt_sb)

	def _append_path_program_settings_row(self, form: QFormLayout, entity: Entity, comp: PathComponent) -> None:
		btn = QPushButton("Path Program Settings", self._content)
		btn.setToolTip("Open path program settings (speed, acceleration, default CNT radius)")
		btn.clicked.connect(
			lambda _c=False, ent=entity, c=comp: PathProgramSettingsDialog(self, ent, c)
		)
		form.addRow(btn)

	def _append_segment_settings_fields(
		self,
		form: QFormLayout,
		entity: Entity,
		segment_idx: int,
		segment,
	) -> None:
		"""Segment fields shown inside Segment Settings dialog."""
		parent = form.parentWidget()

		speed_mult_sb = QDoubleSpinBox(parent)
		speed_mult_sb.setRange(0.01, 100.0)
		speed_mult_sb.setDecimals(3)
		speed_mult_sb.setSingleStep(0.1)
		speed_mult_sb.setValue(segment.speed_multiplier)
		speed_mult_sb.editingFinished.connect(
			lambda e=entity, idx=segment_idx, field="speed_multiplier", w=speed_mult_sb: self._push_feature_field_change(
				e, idx, field, float(w.value())
			)
		)
		form.addRow("Speed Multiplier", speed_mult_sb)

		cnt_sb = QDoubleSpinBox(parent)
		cnt_sb.setRange(0.0, 10.0)
		cnt_sb.setDecimals(6)
		cnt_sb.setSingleStep(0.001)
		cnt_sb.setSuffix(" m")
		cnt_sb.setValue(segment.cnt_radius)
		cnt_sb.editingFinished.connect(
			lambda e=entity, idx=segment_idx, field="cnt_radius", w=cnt_sb: self._push_feature_field_change(
				e, idx, field, float(w.value())
			)
		)
		form.addRow("CNT Radius", cnt_sb)

		if isinstance(segment, CustomFeature):
			wp_count_label = QLabel(f"{len(segment.waypoints)} waypoints", parent)
			form.addRow("Waypoints", wp_count_label)
			return

		if isinstance(segment, (TwoPointLineFeature, SinglePointFeature)):
			return

		if isinstance(segment, ThreePointArcFeature):
			axial_sb = QDoubleSpinBox(parent)
			axial_sb.setRange(-1000.0, 1000.0)
			axial_sb.setSingleStep(0.5)
			axial_sb.setDecimals(3)
			axial_sb.setValue(segment.axial_offset)
			axial_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="axial_offset", w=axial_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Axial Offset", axial_sb)

			radial_sb = QDoubleSpinBox(parent)
			radial_sb.setRange(-1000.0, 1000.0)
			radial_sb.setSingleStep(0.5)
			radial_sb.setDecimals(3)
			radial_sb.setValue(segment.radial_offset)
			radial_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="radial_offset", w=radial_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Radial Offset", radial_sb)

			dense_sb = QDoubleSpinBox(parent)
			dense_sb.setRange(0.01, 100.0)
			dense_sb.setValue(segment.density_multiplier)
			dense_sb.setSingleStep(0.1)
			dense_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="density_multiplier", w=dense_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Density Multiplier", dense_sb)

			radial_rot_sb = QDoubleSpinBox(parent)
			radial_rot_sb.setRange(-360.0, 360.0)
			radial_rot_sb.setValue(segment.radial_rotation)
			radial_rot_sb.setSingleStep(1.0)
			radial_rot_sb.setDecimals(1)
			radial_rot_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="radial_rotation", w=radial_rot_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Radial Rotation (deg)", radial_rot_sb)

			tangent_rot_sb = QDoubleSpinBox(parent)
			tangent_rot_sb.setRange(-360.0, 360.0)
			tangent_rot_sb.setValue(segment.tangent_rotation)
			tangent_rot_sb.setSingleStep(1.0)
			tangent_rot_sb.setDecimals(1)
			tangent_rot_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="tangent_rotation", w=tangent_rot_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Tangent Rotation (deg)", tangent_rot_sb)

	def _append_path_toolbox_row(self, form: QFormLayout) -> None:
		btn = QPushButton("Path Segment Toolbox", self._content)
		btn.setToolTip("Open path segment toolbox")
		if self._path_tool_manager is not None:
			btn.clicked.connect(
				lambda _c=False: PathToolboxDialog(self, self._path_tool_manager)
			)
		else:
			btn.setEnabled(False)
		form.addRow(btn)

	def _append_segment_settings_row(
		self,
		form: QFormLayout,
		entity: Entity,
		comp: PathComponent,
		segment_idx: int,
		segment,
		*,
		parent: QWidget,
	) -> None:
		row_w = QWidget(parent)
		h = QHBoxLayout(row_w)
		h.setContentsMargins(0, 0, 0, 0)
		h.setSpacing(4)
		h.addWidget(QLabel("Segment Settings", row_w))
		gear = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_FileDialogDetailedView,
			"Open Segment Settings",
		)
		h.addWidget(gear)
		h.addStretch(1)
		gear.clicked.connect(
			lambda _c=False, ent=entity, idx=segment_idx, seg=segment: PathSegmentSettingsDialog(
				self, ent, idx, seg
			)
		)

		if not isinstance(segment, CustomFeature):
			edit_btn = QPushButton("Edit", row_w)
			edit_btn.setToolTip(
				"Convert this segment to a custom segment. Waypoints become directly editable via gizmos."
			)
			edit_btn.setFixedSize(self._ICON_TOOL_BUTTON_PX, self._ICON_TOOL_BUTTON_PX)
			edit_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
			edit_btn.setStyleSheet("font-size: 10px; padding: 0px;")
			edit_btn.clicked.connect(
				lambda _checked=False, e=entity, idx=segment_idx: self._convert_feature_to_custom(e, idx)
			)
			h.addWidget(edit_btn, 0, Qt.AlignmentFlag.AlignRight)

		move_up_btn = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_ArrowUp,
			"Move segment up",
		)
		move_up_btn.setEnabled(segment_idx > 0)
		move_up_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._reorder_path_feature(e, idx, -1)
		)
		h.addWidget(move_up_btn, 0, Qt.AlignmentFlag.AlignRight)

		move_down_btn = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_ArrowDown,
			"Move segment down",
		)
		move_down_btn.setEnabled(segment_idx < len(comp.segments) - 1)
		move_down_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._reorder_path_feature(e, idx, 1)
		)
		h.addWidget(move_down_btn, 0, Qt.AlignmentFlag.AlignRight)

		rm_seg_btn = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_TrashIcon,
			"Remove segment",
		)
		rm_seg_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._remove_path_feature(e, idx)
		)
		h.addWidget(rm_seg_btn, 0, Qt.AlignmentFlag.AlignRight)

		form.addRow(row_w)

	def _build_robot_description_ui(
		self, entity: Entity, comp: RobotDescriptionComponent, form: QFormLayout
	) -> None:
		import math

		self._build_component_fields(entity, comp, form)
		if not comp.actuated_joint_names:
			return
		form.addRow(QLabel("Joint positions (rad)", self._content))
		for jname in comp.actuated_joint_names:
			jrec = comp.get_joint_record(jname)
			lower = -math.pi
			upper = math.pi
			if jrec and jrec.get("limits"):
				lower = float(jrec["limits"].get("lower", lower))
				upper = float(jrec["limits"].get("upper", upper))
			spin = QDoubleSpinBox(self._content)
			spin.setDecimals(4)
			spin.setSingleStep(0.01)
			spin.setRange(lower, upper)
			spin.setValue(float(comp.joint_positions.get(jname, 0.0)))
			spin.valueChanged.connect(
				lambda val, c=comp, n=jname, ent=entity: self._on_robot_joint_changed(ent, c, n, val)
			)
			form.addRow(jname, spin)

	def _on_robot_joint_changed(
		self, entity: Entity, comp: RobotDescriptionComponent, joint_name: str, value: float
	) -> None:
		comp.joint_positions[joint_name] = float(value)
		try:
			from MotionStudio.core.robot.robot_kinematics import update_robot_fk

			update_robot_fk(comp)
		except Exception:
			pass
		try:
			if self._scene is not None:
				self._scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass

	def _build_path_generation_ui(self, entity: Entity, comp: PathComponent, form: QFormLayout) -> None:
		self._append_path_toolbox_row(form)
		self._append_path_program_settings_row(form, entity, comp)
		form.addRow(QLabel("Path Segments: ", self._content))

		for i, segment in enumerate(comp.segments):
			title = f"{i + 1}: {segment_display_name(segment)}"
			seg_gb = ClickableGroupBox(title, self._content)
			try:
				seg_gb.clicked.connect(
					lambda _checked=False, idx=i: self._selection.set_current_feature(idx)
					if self._selection is not None
					else None
				)
			except Exception:
				pass
			self._path_feature_widgets[i] = seg_gb

			selected_idx = self._selection.current_feature_idx if self._selection is not None else None
			if selected_idx == i:
				seg_gb.setStyleSheet(
					"QGroupBox { border: 2px solid #66ff66; border-radius: 6px; margin-top: 6px; } "
					"QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px 0 3px; }"
				)
			else:
				seg_gb.setStyleSheet(
					"QGroupBox { border: 1px solid #444; border-radius: 6px; margin-top: 6px; } "
					"QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px 0 3px; }"
				)
			seg_form = QFormLayout(seg_gb)

			self._append_segment_settings_row(seg_form, entity, comp, i, segment, parent=seg_gb)

			form.addRow(seg_gb)

		export_btn = QPushButton("Export to URScript...", self._content)
		export_btn.clicked.connect(lambda _checked=False, e=entity, c=comp: self._export_path_to_urscript(e, c))
		form.addRow(export_btn)

	def _push_feature_field_change(self, entity: Entity, feature_idx: int, field: str, new_value: Any) -> None:
		if self._scene is None or self._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp and len(path_comp.features) > feature_idx:
				setattr(path_comp.features[feature_idx], field, new_value)
				if self._scene is not None:
					self._scene.events.entity_changed.emit(entity.id)
			return

		path_comp = entity.get_component(PathComponent)
		if not path_comp or len(path_comp.features) <= feature_idx:
			return
		
		old = clone_value(getattr(path_comp.features[feature_idx], field))
		if old == new_value:
			return
		
		from MotionStudio.core.undo.commands import PathFeaturePropertyChangeCommand
		cmd = PathFeaturePropertyChangeCommand(self._scene, entity.id, feature_idx, field, old, clone_value(new_value))
		self._undo_stack.push(cmd)

	def _remove_path_feature(self, entity: Entity, feature_idx: int) -> None:
		if self._scene is None or self._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp and len(path_comp.features) > feature_idx:
				path_comp.features.pop(feature_idx)
				if self._scene:
					self._scene.events.entity_changed.emit(entity.id)
				self._rebuild_for_entity(entity)
			return

		from MotionStudio.core.undo.commands import RemovePathFeatureCommand
		cmd = RemovePathFeatureCommand(self._scene, entity.id, feature_idx)
		self._undo_stack.push(cmd)
		self._rebuild_for_entity(entity)

	def _export_path_to_urscript(self, entity: Entity, comp: PathComponent) -> None:
		"""Export path waypoints to URScript file."""
		if self._scene is None:
			return
		
		try:
			segment_waypoints = comp.get_world_waypoints_by_segment()
			total_waypoints = sum(len(s) for s in segment_waypoints)

			if total_waypoints == 0:
				from PyQt6.QtWidgets import QMessageBox
				QMessageBox.warning(self, "Export Failed", "No waypoints to export. Please add path segments first.")
				return

			file_path, _ = QFileDialog.getSaveFileName(
				self,
				"Export Path to URScript",
				"",
				"URScript Files (*.script);;All Files (*.*)",
			)

			if not file_path:
				return

			if not file_path.endswith('.script'):
				file_path += '.script'

			from MotionStudio.core.path.exporters.urscript_exporter import export_to_urscript
			segment_speed_multipliers = [float(seg.speed_multiplier) for seg in comp.segments]
			segment_cnt_radii = [float(seg.cnt_radius) for seg in comp.segments]
			urscript_code = export_to_urscript(
				segment_waypoints,
				speed=float(comp.speed),
				acceleration=float(comp.acceleration),
				segment_speed_multipliers=segment_speed_multipliers,
				segment_cnt_radii=segment_cnt_radii,
			)

			with open(file_path, 'w', encoding='utf-8') as f:
				f.write(urscript_code)

			from PyQt6.QtWidgets import QMessageBox
			QMessageBox.information(
				self,
				"Export Successful",
				f"Path exported successfully to:\n{file_path}\n\n"
				f"{total_waypoints} waypoint(s) across {len(segment_waypoints)} segment(s) exported."
			)
		except Exception as e:
			from PyQt6.QtWidgets import QMessageBox
			QMessageBox.critical(self, "Export Failed", f"Failed to export path:\n{str(e)}")

	def _reorder_path_feature(self, entity: Entity, feature_idx: int, direction: int) -> None:
		"""Reorder a path segment up (-1) or down (+1)."""
		if self._scene is None or self._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp:
				new_idx = feature_idx + direction
				if 0 <= new_idx < len(path_comp.features):
					path_comp.features[feature_idx], path_comp.features[new_idx] = path_comp.features[new_idx], path_comp.features[feature_idx]
					# Update selection if this feature was selected
					if self._selection and self._selection.current_feature_idx == feature_idx:
						self._selection.set_current_feature(new_idx)
					elif self._selection and self._selection.current_feature_idx == new_idx:
						self._selection.set_current_feature(feature_idx)
					if self._scene:
						self._scene.events.entity_changed.emit(entity.id)
					self._rebuild_for_entity(entity)
			return

		from MotionStudio.core.undo.commands import ReorderPathFeatureCommand
		cmd = ReorderPathFeatureCommand(self._scene, entity.id, feature_idx, direction)
		self._undo_stack.push(cmd)
		
		# Update selection index after reorder
		path_comp = entity.get_component(PathComponent)
		if path_comp and self._selection:
			new_idx = feature_idx + direction
			if 0 <= new_idx < len(path_comp.features):
				if self._selection.current_feature_idx == feature_idx:
					self._selection.set_current_feature(new_idx)
				elif self._selection.current_feature_idx == new_idx:
					self._selection.set_current_feature(feature_idx)
		
		self._rebuild_for_entity(entity)

	def _convert_feature_to_custom(self, entity: Entity, feature_idx: int) -> None:
		"""Convert a parametric feature to a custom editable feature."""
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		
		feature = path_comp.features[feature_idx]
		if isinstance(feature, CustomFeature):
			return  # Already custom
		
		# Use command for undo/redo
		cmd = ConvertToCustomFeatureCommand(self._scene, entity.id, feature_idx)
		if self._undo_stack is not None:
			self._undo_stack.push(cmd)
		else:
			cmd.redo()
		
		# Rebuild UI to reflect changes
		self._rebuild_for_entity(entity)

	def _start_vertex_pick(self, entity: Entity, component, spec: FieldSpec) -> None:
		"""Arm the vertex-pick tool for this Vec3 field. Re-clicking the button cancels."""
		mgr = self._vertex_pick_manager
		if mgr is None:
			return
		# Locate the editor widget that triggered this; mark it active.
		editor = self._find_field_editor(component, spec.name)
		# Toggle behaviour: clicking Pick again while armed cancels.
		if getattr(mgr, "is_active", False) and self._active_pick_editor is editor:
			mgr.cancel_pick()
			return
		# Reset prior editor's visual state if any.
		if self._active_pick_editor is not None and self._active_pick_editor is not editor:
			try:
				self._active_pick_editor.set_pick_active(False)
			except Exception:
				pass
		self._active_pick_editor = editor
		if editor is not None:
			try:
				editor.set_pick_active(True)
			except Exception:
				pass

		def _on_picked(world_pos, e=entity, comp=component, s=spec):
			self._push_comp_field_change(e, comp, s.name, world_pos)

		mgr.start_pick(entity, component, spec.name, on_picked=_on_picked, label=spec.name)

	def _field_editor_search_root(self) -> QWidget:
		"""Search the main inspector and any open child windows (e.g. Group dialogs)."""
		return self.window() or self._content

	def _find_field_editor(self, component, field_name: str) -> Optional[Vector3Editor]:
		"""Find the Vector3Editor for (component, field_name) by its dynamic tag property."""
		target = f"{id(component)}::{field_name}"
		for w in self._field_editor_search_root().findChildren(Vector3Editor):
			if w.property("ms_field_tag") == target:
				return w
		return None

	def _sync_vector3_field_editors(self, component, field_name: str, value: QVector3D) -> None:
		"""Refresh every Vector3Editor for this field (inline inspector and Group dialogs)."""
		target = f"{id(component)}::{field_name}"
		for w in self._field_editor_search_root().findChildren(Vector3Editor):
			if w.property("ms_field_tag") != target:
				continue
			try:
				w.blockSignals(True)
				w.set_value(value)
			finally:
				w.blockSignals(False)

	def _on_vertex_pick_active_changed(self, active: bool) -> None:
		"""Clear active editor styling when the tool finishes or is cancelled."""
		if not active and self._active_pick_editor is not None:
			try:
				self._active_pick_editor.set_pick_active(False)
			except Exception:
				pass
			self._active_pick_editor = None

	def _push_comp_field_change(self, entity: Entity, component, field: str, new_value) -> None:
		if self._scene is None or self._undo_stack is None:
			setattr(component, field, new_value)
			self._sync_field_editor_after_change(component, field, new_value)
			return
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		# Tolerate fields that are declared via class annotation but not yet
		# initialised on the instance (e.g. user forgot to set it in __init__).
		old = clone_value(getattr(component, field, None))
		if old == new_value:
			return
		cmd = PropertyChangeCommand(self._scene, entity.id, comp_type, field, old, clone_value(new_value), text=f"{comp_type}.{field}")
		self._undo_stack.push(cmd)
		self._sync_field_editor_after_change(component, field, new_value)

	def _sync_field_editor_after_change(self, component, field: str, new_value) -> None:
		"""Keep Vector3 editors in sync when the component changes outside the widget (e.g. vertex pick)."""
		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if isinstance(new_value, _QVector3D):
				self._sync_vector3_field_editors(component, field, new_value)
		except Exception:
			pass

	def _open_add_component_menu(self, entity: Entity, anchor_widget: QWidget) -> None:
		menu = QMenu(anchor_widget)
		registry = get_registered_components()
		for type_name, cls in registry.items():
			# Hide Transform; it's considered always present/managed
			if type_name in ("Transform", "TransformComponent"):
				continue
			action = menu.addAction(type_name)
			def _add_component(_checked=False, e=entity, comp_cls=cls, type_name=type_name):
				# Check if component of this type already exists
				existing = e.get_component(comp_cls)
				if existing is not None:
					QMessageBox.warning(
						self,
						"Component Already Exists",
						f"The entity '{e.name}' already has a {type_name} component.\n\nOnly one component of each type can be added to an entity."
					)
					return
				
				try:
					instance = comp_cls()  # type: ignore[call-arg]
					if self._scene is not None and self._undo_stack is not None:
						snapshot = instance.to_dict()
						cmd = AddComponentCommand(
							self._scene,
							e.id,
							type_name,
							snapshot,
						)
						self._undo_stack.push(cmd)
					else:
						e.add_component(instance)
					self._rebuild_for_entity(e)
				except Exception as ex:
					# Log the error for debugging, but still rebuild to reflect any change
					import traceback
					print(f"Error adding component {type_name}: {ex}")
					traceback.print_exc()
					self._rebuild_for_entity(e)
			action.triggered.connect(_add_component)
		menu.exec(anchor_widget.mapToGlobal(anchor_widget.rect().bottomRight()))

	def _on_mesh_shape_changed(self, entity: Entity, combo: QComboBox) -> None:
		data = combo.currentData()
		mesh = entity.get_component(MeshComponent)
		if mesh is None:
			return
		if isinstance(data, str) and data in ("cube", "sphere", "custom"):
			mesh.shape = data
			if self._scene is not None:
				self._scene.events.entity_changed.emit(entity.id)

	def _apply_color_button_style(self, btn: QPushButton, color) -> None:
		try:
			# QColor expected; fallback if tuple/list provided
			r = int(color.red()) if hasattr(color, "red") else int(color[0])
			g = int(color.green()) if hasattr(color, "green") else int(color[1])
			b = int(color.blue()) if hasattr(color, "blue") else int(color[2])
			a = int(color.alpha()) if hasattr(color, "alpha") else (int(color[3]) if len(color) > 3 else 255)
		except Exception:
			r, g, b, a = 200, 200, 200, 255
		btn.setText("")
		btn.setStyleSheet(f"QPushButton {{ background-color: rgba({r},{g},{b},{a}); border: 1px solid #444; border-radius: 3px; }} QPushButton:pressed {{ border: 1px solid #666; }}")

	@staticmethod
	def _apply_color_button_style_mixed(btn: QPushButton) -> None:
		btn.setText("-")
		btn.setStyleSheet(
			"QPushButton { background-color: #555; color: #ccc; border: 1px solid #444; border-radius: 3px; }"
			"QPushButton:pressed { border: 1px solid #666; }"
		)



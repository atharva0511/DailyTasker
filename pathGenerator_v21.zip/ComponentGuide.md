# Component Guide

A **component** is a Python class attached to an `Entity` that holds data
(rendered in the Inspector) and optionally runtime behaviour (`start`,
`update`, `on_entity_changed`). The engine handles the Inspector UI,
serialization, and rendering updates automatically — you write the
behaviour.

## Implementing one

Subclass `Component`, decorate with `@register_component`, declare editable
fields as `Annotated` class attributes, and initialise them in `__init__`.

Drop the file into `Project/Components/` (e.g.
`Test Project/Components/rotator_component.py`). Every `.py` file in that
folder is imported automatically when the project loads — no manual import
needed.

```python
from __future__ import annotations
from typing import Annotated
from PyQt6.QtGui import QVector3D, QQuaternion

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.ui.inspector.metadata import Range, Tooltip


@register_component
class RotatorComponent(Component):
    type_name = "Rotator"

    speed_deg_per_sec: Annotated[float, Range(0.0, 360.0, step=1.0), Tooltip("Degrees per second")]
    axis: Annotated[QVector3D, Tooltip("Rotation axis")]

    def __init__(self, speed_deg_per_sec: float = 45.0, axis: QVector3D | None = None) -> None:
        self.speed_deg_per_sec = float(speed_deg_per_sec)
        self.axis = axis or QVector3D(0.0, 0.0, 1.0)

    def update(self, delta_time: float) -> None:
        if self.entity is None:
            return
        t = self.entity.get_component(TransformComponent)
        if t is None:
            return
        q = QQuaternion.fromAxisAndAngle(self.axis, self.speed_deg_per_sec * delta_time)
        t.rotation_quat = q * t.rotation_quat
```

Key pieces:

- `type_name` — string used in `.scn` files and the "Add Component" menu.
- `@register_component` — registers the class. Without it the Inspector
  and the serializer can't see your component.
- `Annotated[T, ...]` class attributes — drive both the Inspector UI and
  automatic serialization.
- `self.entity` — backref to the owning `Entity` (or `None`). Reach
  siblings via `self.entity.get_component(SomeType)`.

---

## 1. Inspector fields and metadata

The Inspector reads your `Annotated` attributes and picks a widget by type.

| Type | Widget |
|---|---|
| `bool` | Checkbox |
| `int` / `float` | Spinbox (use `Range`) |
| `str` | Line edit (or file picker with `FilePath`) |
| `Literal["a", "b"]` | Combo box |
| `QVector3D` | Vector3 editor |
| `QColor` | Color picker (`ColorField`) |
| `Optional[SomeComponent]` | Entity-reference picker |

Metadata markers live in `MotionStudio.ui.inspector.metadata`:

```python
from MotionStudio.ui.inspector.metadata import (
    Range,      # numeric limits: Range(min, max, step=1.0, decimals=None)
    Tooltip,    # hover text
    Header,     # section header inside a Group popup (above that field)
    Group,      # collapse fields into a gear-popup (same label = one popup)
    Order,      # Inspector row sort key (see below)
    ReadOnly,   # display only
    Multiline,  # multi-line text edit for str
    FilePath,   # turns str into a "Browse..." picker
    ColorField, # explicit color picker for QColor
    Hidden,     # excludes from Inspector AND from serialization
    VertexPick, # adds a "Pick" button to a QVector3D field for vertex-picking
)
```

### Inspector row order (`Order` + `inspector_button` `order`)

Fields and `@inspector_button` rows share **one sort key**. Lower values render
first; ties break by **class declaration order** (source order in the class
body, including methods between fields — not alphabetical).

| Row type | Sort key |
|----------|----------|
| Annotated field | `Order(N)` metadata (default `0`) |
| `@inspector_button` | `order=N` keyword (default `0`) |

| Situation | Sort behaviour |
|-----------|----------------|
| No `Order` / no `order` | Treated as `0` |
| Field `Order(5)` and button `order=5` | Interleaved by declaration order |
| Same order, same kind | Declaration order |
| Inherited members | Base class first, then subclass (MRO) |

Use gaps (`0`, `10`, `100`) so you can insert rows later without renumbering.

```python
from typing import Annotated
from MotionStudio.ui.inspector.metadata import Order, Tooltip, Range

@register_component
class OrderedExample(Component):
    type_name = "OrderedExample"

    # Renders first (lowest order, then declaration order among ties)
    name: Annotated[str, Order(0), Tooltip("Entity label")]
    enabled: Annotated[bool, Order(0)]

    # Renders after the block above
    speed: Annotated[float, Order(10), Range(0.0, 100.0)]
    mode: Annotated[str, Order(10)]

    # No Order → defaults to 0; among other 0s, follows declaration position
    notes: Annotated[str, Tooltip("Appears with other order=0 fields by decl order")]
```

`Order` / `order` affect **Inspector layout only** — not serialization, Play Mode,
or runtime field values.

### `Group` — fields in a gear popup

Fields that share the same `Group("Label")` are **not** shown on the main Inspector
form. Instead, one row appears at the first field’s sorted position: the group
label plus a **gear** button. Clicking the gear opens a **dialog window** (like
the component-reference entity browser) listing those fields in `Order` /
declaration order; use **Close** to dismiss.

**Metadata placement:** `Group`, `Order`, `Header`, and other inspector markers must be
**inside** the `Annotated[...]` tuple (same as `Tooltip`, `Range`, etc.), not
placed after `Annotated`. The reflection layer only reads `field_spec.metadata`.

**Imports:** Every marker class you use in annotations must be imported from
`MotionStudio.ui.inspector.metadata` in that component module (e.g.
`from MotionStudio.ui.inspector.metadata import Group, Order, Tooltip`). With
`from __future__ import annotations`, missing imports do not fail at import time,
but reflection cannot resolve metadata and grouped fields stay inline with no
tooltips or ranges.

```python
# Correct
collider_from_mesh_component: Annotated[
    bool,
    Group("Collider Settings"),
    Tooltip("..."),
] = True

# Wrong (group ignored — fields stay inline on the component box)
collider_from_mesh_component: Annotated[bool, Tooltip("..."), Group("Collider Settings")] = True
```

```python
from MotionStudio.ui.inspector.metadata import Group, Order, Range

    speed: Annotated[float, Order(0), Range(0.0, 100.0)]
    tolerance: Annotated[float, Group("More Options"), Order(10), Range(0.0, 1.0)]
    notes: Annotated[str, Group("More Options"), Order(20)]
```

`@inspector_button` rows are not grouped (they always stay inline). `Hidden()`
fields are never shown in the popup.

**Important:** `Group`, `Order`, `Header`, etc. must be **inside** the `Annotated[...]` tuple, not after it:

```python
# Correct — metadata is part of Annotated
speed: Annotated[float, Group("More Options"), Order(10), Range(0.0, 100.0)]

# Wrong — Group is not in metadata; grouping will not work
speed: Annotated[float, Tooltip("..."), Group("More Options")]
```

Example exercising most markers:

```python
from typing import Annotated, Literal
from PyQt6.QtGui import QColor, QVector3D

@register_component
class ExampleComponent(Component):
    type_name = "Example"

    enabled: Annotated[bool, Order(0), Tooltip("Master switch")]
    speed:   Annotated[float, Order(10), Range(0.0, 100.0, step=0.5, decimals=2)]
    mode:    Annotated[Literal["a", "b", "c"], Order(10), Tooltip("Behaviour mode")]
    offset:  Annotated[QVector3D, Order(20), Header("Geometry")]
    source:  Annotated[str, FilePath("Data (*.json);;All Files (*.*)")]
    tint:    Annotated[QColor, ColorField()]
    target:  Annotated[QVector3D, VertexPick(), Tooltip("Click 'Pick' then click a mesh vertex")]
    debug:   Annotated[bool, Hidden()]  # not shown, not serialized
```

### `VertexPick` — picking a point in the component owner's local frame

`VertexPick()` adds a small **Pick** button before the X/Y/Z spinboxes of a
`QVector3D` field. Clicking it puts the 3D view into vertex-selection mode
and shows an instruction overlay at the top of the viewport (the same
overlay used by the path-generator tools). A translucent cyan ghost
follows the cursor and previews the vertex that will be captured. The next
vertex the user clicks writes the vertex's position expressed in the
**component-owner entity's local frame** into the field via the normal
property-change command — full undo / redo support.

Frame semantics:

- If the picked vertex belongs to the **same** entity that owns the
  component, the value is just the raw mesh-local position of the vertex
  (the polydata point, identical to what you'd read directly from the
  mesh).
- If the picked vertex belongs to a **different** entity, the manager
  rebases via world space: `world = transform_point(picked, mesh_local)`,
  then `result = inverse_transform_point(owner, world)`. The stored value
  therefore stays meaningful relative to the owner — moving or rotating
  the owner moves the picked-point reference with it, which is what you
  want for most component use-cases.

If you need the value in world space, convert at use-site with
`transform_point(owner_entity, value)` from
[`MotionStudio/core/transform/utils.py`](MotionStudio/core/transform/utils.py).

```python
from typing import Annotated
from PyQt6.QtGui import QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Tooltip, VertexPick


@register_component
class AnchorComponent(Component):
    type_name = "Anchor"

    target_point: Annotated[QVector3D, VertexPick(), Tooltip("Pick a vertex on a mesh to capture its world position")]

    def __init__(self, target_point: QVector3D | None = None) -> None:
        self.target_point = target_point or QVector3D(0.0, 0.0, 0.0)
```

Notes:

- Picking is one-shot: the tool auto-disarms after a successful pick.
- Re-clicking the **Pick** button while armed cancels the pending pick.
- A **translucent cyan ghost marker** follows the mouse and previews the
  vertex that will be captured on click; this preview is provided by the
  picker bridge for Vertex Mode in general, so the same preview is also
  visible whenever you enter Vertex Mode manually (`2`).
- You can pick a vertex on **any** mesh in the scene — while a pick is
  armed every mesh shows its edges/vertices, not just the selected one.
- Entity selection is **frozen** while a pick is armed: clicking another
  mesh's vertex writes the value into the field without moving
  `SelectionModel.current` or rebuilding the Inspector for the other entity.
- The captured value is in the **component owner's local frame**. For a
  same-entity pick this is identical to the raw mesh-local vertex; for a
  cross-entity pick the manager rebases through world space so the value
  remains meaningful relative to the owner.
- Starting a path-generator tool cancels any pending pick.

### `@inspector_button` — adding action buttons to a component

Use the `inspector_button` decorator to render a method as a button in the
Inspector. The decorated method is invoked with no arguments (other than
`self`) when the button is clicked, and the Inspector refreshes
automatically afterwards so any field mutations show up immediately.

```python
from typing import Annotated
from PyQt6.QtGui import QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.ui.inspector.metadata import Tooltip, VertexPick, inspector_button


@register_component
class AnchorComponent(Component):
    type_name = "Anchor"

    target_point: Annotated[QVector3D, VertexPick(), Tooltip("World-space anchor")]

    def __init__(self, target_point: QVector3D | None = None) -> None:
        self.target_point = target_point or QVector3D(0.0, 0.0, 0.0)

    @inspector_button("Reset Anchor", tooltip="Snap target back to origin")
    def reset_anchor(self) -> None:
        self.target_point = QVector3D(0.0, 0.0, 0.0)

    @inspector_button("Teleport To Anchor", order=1)
    def teleport_to_anchor(self) -> None:
        if self.entity is None:
            return
        t = self.entity.get_component(TransformComponent)
        if t is not None:
            t.position = self.target_point
```

Decorator signature:

```python
inspector_button(label: str | None = None, *, tooltip: str | None = None, order: int = 0)
```

- `label` — button text. Defaults to a title-cased version of the method name
  (`reset_anchor` → `Reset Anchor`).
- `tooltip` — optional hover text.
- `order` — same unified sort key as field `Order(N)`; lower values render first.
  A button with `order=5` appears among fields with `Order(5)` by declaration
  order.

Notes:

- Buttons are **not** forced to the bottom of the component block; they use the
  same ordering as fields (see **Inspector row order** above).
- Exceptions raised by the method are caught and printed; they will not
  crash the editor.
- The button itself does not push an undo command. If your method mutates
  state and you want it undoable, push a `PropertyChangeCommand` from
  inside the method (see existing inspector code for examples), or set
  attributes via their normal Python setters and accept that the
  individual edits will not be on the undo stack.

Serialization is automatic for all annotated fields — `to_dict` / `from_dict`
on the base `Component` use reflection. Override them only when you need
legacy-key compatibility or polymorphic collections.

---

## 2. Lifecycle hooks

Override any of these — base implementations are no-ops.

| Method | When it fires |
|---|---|
| `__init__(self, ...)` | When the component is instantiated. |
| `start(self)` | Once when Play Mode starts, or immediately when added during Play Mode. |
| `update(self, delta_time)` | Every frame during Play Mode. `delta_time` is clamped to 100 ms. |
| `on_entity_changed(self)` | When any property on the entity changes (Inspector edit, component add/remove, name change). Fires in both edit and play modes. |
| `on_viewport_draw(self)` | Immediately before each 3D viewport render pass (edit and play). Use for per-frame `Debug.draw_*` and other visual sync. Only components that override this method are invoked. |

```python
def start(self) -> None:
    self._t = self.entity.get_component(TransformComponent)

def update(self, delta_time: float) -> None:
    if self._t is None:
        return
    self._t.position += QVector3D(0, 0, delta_time)
```

Inside any hook:

- `self.entity` — owning `Entity` (or `None`).
- `self.entity.scene` — the `Scene`.
- `self.entity.scene.events` — `SceneEvents` (signals you can connect to).
- `self.entity.scene.selection` — editor selection (§6).
- `self.entity.scene.viewport` — camera / screen projection (§5).
- `self.entity.scene.play_mode_manager` — Play Mode state when attached.

Errors in lifecycle hooks are caught by Play Mode so a buggy component
won't crash the loop, but they print to the console.

---

## 3. Working with transforms

`TransformComponent` stores **local** PRS (relative to the parent). For
world-space queries, frame conversions, and "A relative to B", use the
helpers in
[`MotionStudio/core/transform/utils.py`](MotionStudio/core/transform/utils.py).

### Local

```python
t = entity.get_component(TransformComponent)
t.position        # QVector3D, local
t.rotation_quat   # QQuaternion
t.euler_deg       # (x, y, z) degrees
t.scale3d         # alias: t.scale
```

Assigning to any of these emits `entity_transform_changed` automatically.

### World (global)

```python
from MotionStudio.core.transform.utils import (
    world_matrix, world_position, world_rotation_quat,
    world_euler_deg, lossy_world_scale, local_axes_in_world,
)

wm = world_matrix(entity)              # QMatrix4x4
wp = world_position(entity)            # QVector3D
wq = world_rotation_quat(entity)       # QQuaternion (scale-independent)
ax, ay, az = local_axes_in_world(entity)  # entity's local axes in world space
```

### Frame conversions

The entity defines the reference frame.

```python
from MotionStudio.core.transform.utils import (
    transform_point, transform_direction,
    inverse_transform_point, inverse_transform_direction,
    local_position_from_world,
)

tip_world = transform_point(entity, QVector3D(0, 0, 1))      # local point → world
p_local   = inverse_transform_point(entity, QVector3D(10, 0, 5))  # world → local

# World point → parent-local (ready to assign to t.position):
t.position = local_position_from_world(entity, QVector3D(10, 0, 5))
```

### A relative to B

```python
from MotionStudio.core.transform.utils import (
    relative_matrix, relative_position, relative_rotation,
)

m_a_in_b = relative_matrix(entity_a, entity_b)
p_a_in_b = relative_position(entity_a, entity_b)
q_a_in_b = relative_rotation(entity_a, entity_b)
```

### Writing in world space

```python
from MotionStudio.core.transform.utils import (
    set_world_position, set_world_rotation_quat,
)

set_world_position(entity, QVector3D(10, 0, 5))
set_world_rotation_quat(entity, QQuaternion.fromEulerAngles(0, 0, 90))
```

Both setters route through the public properties on `TransformComponent`,
so signals fire and the viewport updates.

> All helpers walk the parent chain on every call (`O(depth)`). In tight
> `update()` loops with deep hierarchies, compute `world_matrix(entity)`
> once per frame and reuse it.

---

## 4. Reacting to collisions

Attach a **`ColliderComponent`** to any entity that should participate in
the scene-wide collision system:

```python
from MotionStudio.core.components.collider_component import ColliderComponent

entity.add_component(ColliderComponent(repaint_on_collision=True))
```

The scene's `CollisionSystem` pairs every collider-bearing entity, respects
the per-pair Collision Matrix (View → Collision Matrix), and maintains a
runtime flag on each collider:

- `ColliderComponent.collided: bool` — `True` while the entity is
  intersecting another collider this frame.
- `scene.events.entity_collision_changed(entity_id)` — Qt signal emitted
  whenever the flag flips on any collider.

You can react two ways.

### 4a. Poll `collided` in `update()`

Simplest, no signal wiring. Good for "do something every frame I'm
colliding".

```python
from typing import Annotated
from PyQt6.QtGui import QVector3D
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.ui.inspector.metadata import Range, Tooltip


@register_component
class BounceOnCollisionComponent(Component):
    type_name = "BounceOnCollision"

    bounce_speed: Annotated[float, Range(0.0, 100.0, step=0.1), Tooltip("Units / sec while colliding")]

    def __init__(self, bounce_speed: float = 5.0) -> None:
        self.bounce_speed = float(bounce_speed)

    def update(self, delta_time: float) -> None:
        if self.entity is None:
            return
        collider = self.entity.get_component(ColliderComponent)
        transform = self.entity.get_component(TransformComponent)
        if collider is None or transform is None:
            return
        if collider.collided:
            # Push up along world +Z while we're intersecting another collider.
            transform.position = transform.position + QVector3D(0, 0, self.bounce_speed * delta_time)
```

### 4b. Subscribe to `entity_collision_changed` (edge-triggered)

Use this when you only want to fire on the transition (entered / left
collision) — for example play a sound, log, spawn a particle.

```python
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.collider_component import ColliderComponent


@register_component
class CollisionLoggerComponent(Component):
    type_name = "CollisionLogger"

    def __init__(self) -> None:
        self._connected = False
        self._was_colliding = False

    def start(self) -> None:
        # Connect once; play mode guarantees self.entity.scene is set.
        if self.entity is None or self._connected:
            return
        self.entity.scene.events.entity_collision_changed.connect(self._on_collision_changed)
        self._connected = True

    def _on_collision_changed(self, entity_id: str) -> None:
        # Signal fires for ANY collider in the scene; filter to ours.
        if self.entity is None or entity_id != self.entity.id:
            return
        collider = self.entity.get_component(ColliderComponent)
        if collider is None:
            return
        now = bool(collider.collided)
        if now and not self._was_colliding:
            print(f"{self.entity.name} entered collision")
        elif not now and self._was_colliding:
            print(f"{self.entity.name} left collision")
        self._was_colliding = now
```

Notes:

- `entity_collision_changed` is emitted for **the entity whose flag
  flipped**, so always filter on `entity_id == self.entity.id`.
- `ColliderComponent.collided` always reflects real collision state.
  `repaint_on_collision` is a renderer-only hint that toggles the red
  mesh overlay - set it to `False` if you want collision callbacks
  without any visual change.
- Disable specific pairs from the **View → Collision Matrix** dock, or
  programmatically via `scene.collision_system.matrix.set_enabled(a_id, b_id, False)`.
- Collisions are evaluated every frame in Play Mode and on every
  `entity_transform_changed` in edit mode, so your callback / poll is
  always working off fresh state.

---

## 5. Camera and viewport (component access)

Use **`self.entity.scene.viewport`** for read-only 3D viewport queries. The
editor attaches a `VtkViewportService` when the central VTK view is created;
until then `viewport` is `None`.

### API (`scene.viewport`)

| Method | Returns |
|--------|---------|
| `world_to_display(world)` | `(pixel_x, pixel_y, depth)` — VTK display coordinates |
| `display_to_world(x, y, depth=0.0)` | `QVector3D` in world space |
| `viewport_size()` | `(width, height)` in pixels |
| `camera_state()` | `CameraState` or `None` — position, focal_point, view_up, `view_angle_deg`, `parallel_projection`, `parallel_scale` |

Import `CameraState` from `MotionStudio.core.scene` if you need typing.

### Example: screen position of a mesh vertex

```python
from MotionStudio.core.transform.utils import transform_point

def on_viewport_draw(self) -> None:
    vp = self.entity.scene.viewport
    if vp is None:
        return
    world = transform_point(self.entity, self.target_point)
    px, py, depth = vp.world_to_display(world)
    cam = vp.camera_state()
    if cam is not None:
        Debug.log(f"FOV={cam.view_angle_deg:.1f} px=({px:.0f},{py:.0f})")
```

Call from `on_viewport_draw()` or `update()` so the camera matches the frame
being drawn.

**Play Mode:** prefer `scene.play_mode_manager.is_playing` instead of private
`_play_mode_manager`.

---

## 6. Entity selection (component access)

Use **`self.entity.scene.selection`** for the editor `SelectionModel`
(Hierarchy + viewport pick). Wired at startup; always non-`None` in normal
editor sessions.

`on_entity_changed()` still means **Inspector / field edits** on an entity, not
selection changes — use the selection API below for “am I selected?” logic.

### Read current selection

| Member | Meaning |
|--------|---------|
| `selection.current` | Selected `Entity` or `None` |
| `selection.current_feature_idx` | Path feature index, or `None` |
| `selection.current_waypoint` | `(feature_idx, waypoint_idx)` or `None` |
| `selection.interaction_active` | `True` during gizmo drag |
| `selection.is_entity_selected(entity)` | **`True` if this entity is selected** |
| `selection.is_entity_id_selected(entity_id)` | Same check by id string |

### Signals (react to selection changes)

| Signal | When |
|--------|------|
| `current_entity_changed` | User selects another entity (or clears) |
| `current_feature_changed` | Path feature sub-selection changes |
| `current_waypoint_changed` | Waypoint sub-selection changes |

### If this entity is selected (one-shot check)

```python
def on_viewport_draw(self) -> None:
    sel = self.entity.scene.selection
    if sel is None or not sel.is_entity_selected(self.entity):
        return
    # Only runs while this entity is the active selection
    Debug.draw_axes(world_position(self.entity), length=0.5)
```

Same check anywhere (`update`, `on_entity_changed`, button handler):

```python
if self.entity.scene.selection.is_entity_selected(self.entity):
    ...
```

### React when selection changes (subscribe in `start`)

```python
def start(self) -> None:
    if self.entity is None:
        return
    sel = self.entity.scene.selection
    if sel is None:
        return
    sel.current_entity_changed.connect(self._on_selection_changed)
    self._on_selection_changed(sel.current)

def _on_selection_changed(self, selected_entity) -> None:
    if self.entity.scene.selection.is_entity_selected(self.entity):
        Debug.log(f"{self.entity.name} selected")
    else:
        Debug.log(f"{self.entity.name} not selected")
```

Components on **every** entity receive the signal when **any** selection changes;
always filter with `is_entity_selected(self.entity)`.

**Do not** call `selection.set_current(...)` from gameplay unless you intend to
drive the editor selection.

**Selection vs collision:** use `entity_collision_changed` (§4b) for physics
overlap, not selection.

---

## 7. Debug API (logging and 3D drawing)

Motion Studio provides a Unity-style `Debug` class for quick diagnostics
from any component script. Import it once and use static methods — no
registration or scene wiring required in your component code (the editor
configures the renderer when the main window starts).

```python
from MotionStudio.core.debug import Debug
from PyQt6.QtGui import QVector3D, QColor

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.utils import transform_point, world_position
```

### Text logging

| Method | Purpose |
|--------|---------|
| `Debug.log(message)` | General message to the console |
| `Debug.warning(message)` | Prefixed with `WARNING:` |
| `Debug.error(message)` | Prefixed with `ERROR:` |

Each line is timestamped (`[Debug HH:MM:SS] ...`) and flushed immediately.
Use these instead of bare `print()` when you want consistent debug
prefixing.

### 3D drawing

| Method | Purpose |
|--------|---------|
| `Debug.draw_line(start, end, color=..., width=2.0)` | Segment between two points |
| `Debug.draw_ray(origin, direction, length=1.0, color=..., width=2.0)` | Ray from `origin` along `direction` |
| `Debug.draw_sphere(center, radius=0.05, color=..., filled=False, opacity=1.0)` | Wireframe or filled sphere |
| `Debug.draw_bounding_box(center, size, color=..., width=2.0)` | Wireframe axis-aligned box (`size` = full extents) |
| `Debug.draw_axes(origin, length=1.0, rotation=None, ...)` | RGB XYZ axes; optional `QQuaternion` for local frame |
| `Debug.draw_point(position, size=8.0, screen_space=True, color=..., opacity=1.0)` | Camera-facing disc; default size is **pixel radius**; set `screen_space=False` for world radius |
| `Debug.draw_label(position, text, color=..., font_size=14)` | Billboard text at a 3D position |

**Input types**

- Positions: `QVector3D` or any 3-number sequence `(x, y, z)`.
- Colors: `QColor` or RGB floats in `0.0`–`1.0`, e.g. `(1.0, 0.0, 0.0)`.

**Coordinate space**

Draw calls use **world-space** coordinates (same as the 3D viewport). If
you have a point in an entity's local frame, convert before drawing:

```python
from MotionStudio.core.transform.utils import transform_point, world_position

wp = world_position(self.entity)           # entity origin in world space
tip = transform_point(self.entity, QVector3D(0, 0, 1))  # local offset → world
```

### Example: visualize motion in `update()`

```python
@register_component
class TraceDebugComponent(Component):
    type_name = "TraceDebug"

    def update(self, delta_time: float) -> None:
        if self.entity is None:
            return
        t = self.entity.get_component(TransformComponent)
        if t is None:
            return

        pos = world_position(self.entity)
        Debug.draw_sphere(pos, radius=0.03, color=(0.2, 0.8, 1.0))
        Debug.draw_ray(pos, t.rotation_quat.rotatedVector(QVector3D(0, 0, 1)), length=0.2, color=(0, 1, 0))
```

Re-issue draw calls every frame you want them visible (see lifetime below).

### One-frame lifetime (performance model)

Debug primitives use a **one-frame** model for low overhead:

- Each `draw_*` call is queued for the **next viewport render**.
- At the start of the following render, the queue is consumed and cleared.
- To keep a line or sphere visible, call the same `draw_*` again on the
  next frame (e.g. every `update()` in Play Mode).

**Play Mode** — natural fit: call `Debug.draw_*` inside `update()` each
tick; the play loop renders every frame, so visuals stay on screen.

**Edit Mode** — there is no `update()` loop. For continuous edit-mode
previews (e.g. a picked vertex marker while orbiting the camera), override
`on_viewport_draw()` and call the same `draw_*` each pass. A one-off draw
from `on_entity_changed` or an `@inspector_button` still works: the API
requests an immediate render, but the primitive clears on the next viewport
pass unless you draw again.

### Enabling and disabling

| Control | Effect |
|---------|--------|
| **View → Enable Debug Draw** | Global on/off for all `draw_*` output |
| `Debug.set_enabled(False)` | Same as unchecking the menu item |
| `Debug.set_mode_enabled(edit_mode=False)` | Suppress draws while not in Play Mode |
| `Debug.set_mode_enabled(play_mode=False)` | Suppress draws during Play Mode |
| `Debug.clear()` | Drop queued primitives without drawing them |

`Debug.is_enabled()` returns whether drawing is currently allowed.

### Notes

- Debug overlays render on the VTK **overlay layer** (on top of meshes and
  gizmos), similar to pick highlights.
- Drawing does not create entities, components, or undo steps — it is
  diagnostic only.
- `Debug.configure(...)` is called by the editor at startup; component
  authors normally only import `Debug` and call the static helpers.
- For file-based command history, the editor still uses
  `CommandLogger` on undo/redo; `Debug.log` is console-only.

---

## URDF robots (`RobotDescription` + `UrdfLink`)

Import via **File → Import URDF...** (project must be open). The importer
creates a robot root entity with `RobotDescriptionComponent` and a child
entity per URDF link.

- **FK** is driven by updating each link's `TransformComponent` from
  `RobotDescription.joint_positions` (radians). Link transforms are
  read-only in the Inspector.
- **Inspector** on the robot root shows URDF metadata and joint sliders.
  Use **Reset Pose** to zero actuated joints.
- **Collision** on imported links uses dedicated STL paths with
  `collider_from_mesh_component=False` and `scale=1000` (URDF metres → engine mm).
- **Package folder** on `RobotDescription`: set to the ROS package root (folder
  containing `meshes/`), then **Reload Meshes** if paths were not resolved at import.
- **Metadata imports**: every marker used in annotations must be imported
  from `MotionStudio.ui.inspector.metadata` (see `Group` section above).

### Inverse kinematics (`RobotIK`)

Add a `RobotIKComponent` on the robot root to make the tool link follow a
target pose:

- Assign **Target** to any entity that has a `TransformComponent` (entity-
  reference picker). Move/rotate it with the gizmo and the arm tracks its full
  6D pose; **Solve IK Now** runs one synchronous solve for debugging.
- **Custom TCP**: assign the optional **TCP** field to an entity (parent it
  under the tool-link entity and position it at the real tool tip). IK then
  drives that point to the target instead of the URDF `tool_link`. Leave empty
  to use `tool_link` directly. See `documentation.md` → **Inverse Kinematics**.
- Solving happens on a background thread at `solve_hz` (latest-wins), then the
  result is applied on the main thread to `joint_positions` + FK.
- **Backend** dropdown switches the solver at runtime:
  - `ikpy` (default) — pure Python, ships in `requirements.txt` (`pip install
    ikpy`); works on all platforms.
  - `pinocchio` — faster; Linux `pip install pin`, Windows/macOS `conda install
    -c conda-forge pinocchio` (see `requirements-robot.txt`).
  - If the selected backend's library is missing, the component is inert and
    reports it; the editor never crashes.
- A future cuRobo backend plugs in by implementing the `IKBackend` protocol in
  `MotionStudio/core/robot/ik/` and registering it in `make_ik_backend`. See
  `documentation.md` → **Inverse Kinematics**.

Core modules: `MotionStudio/core/robot/` (`urdf_importer`, `robot_kinematics`,
`urdf_parser`, `ik/`).

---

## See also

- `documentation.md` — full engine reference (scene, signals, rendering,
  gizmos, persistence, Play Mode, collision system internals, Debug API
  wiring).
- `MotionStudio/core/debug.py` — `Debug` implementation.
- `MotionStudio/core/transform/utils.py` — source for the transform
  helpers.
- `MotionStudio/core/components/` — built-in components to learn from
  (`TransformComponent`, `MeshComponent`, `ColliderComponent`, `PathComponent`,
  `RobotDescriptionComponent`, `RobotIKComponent`, `UrdfLinkComponent`).
- `Test Project/Components/rotator_component.py` — minimal working example.

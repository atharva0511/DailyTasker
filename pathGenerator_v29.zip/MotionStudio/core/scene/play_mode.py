from __future__ import annotations
from typing import Optional, Dict, List, Any
from PyQt6.QtCore import QObject, QTimer, pyqtSignal, QElapsedTimer
import time
from MotionStudio.core.ecs.component import get_component_class


class PlayModeManager(QObject):
	"""
	Manages Play Mode state and update loop for the scene.
	Similar to Unity's Play Mode - runs a simulation loop calling update() on all components.
	Uses variable timing (QTimer.singleShot) to adapt to actual performance.
	
	Saves and restores scene state when entering/exiting play mode (Unity-like behavior):
	- Entities deleted during play mode are restored
	- Entities created during play mode are deleted
	- Component state for all entities is restored to pre-play state
	"""
	
	play_mode_changed = pyqtSignal(bool)  # Emits True when starting, False when stopping
	pause_state_changed = pyqtSignal(bool)  # Emits True when paused, False when resumed
	frame_ready = pyqtSignal()  # Emitted after each update to trigger rendering
	
	def __init__(self, scene) -> None:
		super().__init__()
		self._scene = scene
		self._is_playing = False
		self._is_paused = False
		self._elapsed_timer = QElapsedTimer()
		self._last_frame_time: float = 0.0
		self._play_mode_snapshot: Optional[List[Dict[str, Any]]] = None  # Saved state before play mode
		
	def start_play_mode(self) -> None:
		"""Start the play mode update loop with variable timing."""
		if self._is_playing:
			return
		
		# Save current scene state (Unity-like: serialize before play mode)
		self._save_scene_snapshot()

		# Edit-mode play routines must not double-tick with component.update().
		runner = getattr(self._scene, "play_routine_runner", None)
		if runner is not None:
			runner.stop_all()

		self._is_playing = True
		self._is_paused = False
		self._last_frame_time = time.time()
		self._elapsed_timer.start()
		
		# Call start() on all existing components (Unity-like behavior)
		self._start_all_components()
		
		# Start the update loop with variable timing
		# Use singleShot(0) to schedule immediately, then recursively schedule after each frame
		QTimer.singleShot(0, self._on_update_tick)
		
		self.play_mode_changed.emit(True)
		self.pause_state_changed.emit(False)
	
	def stop_play_mode(self) -> None:
		"""Stop the play mode update loop and restore saved state."""
		if not self._is_playing:
			return
		
		self._is_playing = False
		self._is_paused = False
		# No timer to stop - the loop will naturally stop when _is_playing is False
		
		# Restore scene state (Unity-like: restore after play mode)
		if self._play_mode_snapshot is not None:
			self._restore_scene_snapshot()
			self._play_mode_snapshot = None  # Clear snapshot after restore
		
		self.play_mode_changed.emit(False)
		self.pause_state_changed.emit(False)
	
	@property
	def is_playing(self) -> bool:
		"""Returns True if play mode is currently active."""
		return self._is_playing
	
	@property
	def is_paused(self) -> bool:
		"""Returns True if play mode is currently paused."""
		return self._is_paused
	
	def pause_play_mode(self) -> None:
		"""Pause the play mode update loop. Updates will not be called until resumed."""
		if not self._is_playing or self._is_paused:
			return
		
		self._is_paused = True
		self.pause_state_changed.emit(True)
	
	def resume_play_mode(self) -> None:
		"""Resume the play mode update loop after being paused."""
		if not self._is_playing or not self._is_paused:
			return
		
		self._is_paused = False
		# Reset last frame time to prevent large delta_time spike after resume
		self._last_frame_time = time.time()
		self.pause_state_changed.emit(False)
	
	def _on_update_tick(self) -> None:
		"""
		Called every frame with variable timing.
		Calculates delta_time (including render time), updates all components, and schedules next frame.
		Similar to Unity's frame loop: Update → Render → Next Frame
		"""
		if not self._is_playing:
			return
		
		# If paused, still schedule next tick but skip updates and rendering
		if self._is_paused:
			QTimer.singleShot(0, self._on_update_tick)
			return
		
		# Calculate delta_time (time since last frame, including render time)
		current_time = time.time()
		delta_time = current_time - self._last_frame_time
		self._last_frame_time = current_time
		
		# Clamp delta_time to prevent large spikes (e.g., when debugging or window minimized)
		delta_time = min(delta_time, 0.1)  # Max 100ms per frame
		
		# Update all components
		self._update_all_components(delta_time)

		# Run scene-wide collision checks after component updates so the collider
		# state reflects transforms mutated this tick.
		try:
			self._scene.collision_system.check_all()
		except Exception as e:
			print(f"Error running collision_system.check_all(): {e}", flush=True)

		# Emit signal to trigger rendering (MainWindow will handle the actual render call)
		self.frame_ready.emit()
		
		# Schedule next update immediately (variable timing - adapts to actual performance)
		# This ensures the frame time naturally includes both update and render time
		QTimer.singleShot(0, self._on_update_tick)
	
	def _start_all_components(self) -> None:
		"""
		Call start() on all components that implement it.
		This is called when play mode starts (Unity-like behavior).
		"""
		for entity in self._scene.entities():
			for component in entity.components:
				try:
					if hasattr(component, 'start') and callable(getattr(component, 'start', None)):
						component.start()
				except Exception as e:
					# Log error but don't crash the start sequence
					print(f"Error starting component {component.__class__.__name__} on entity {entity.name}: {e}", flush=True)

	def _update_all_components(self, delta_time: float) -> None:
		"""
		Iterates through all entities and components, calling update() if implemented.
		
		Args:
			delta_time: Time elapsed since last frame in seconds
		"""
		for entity in self._scene.entities():
			for component in entity.components:
				try:
					# Check if component has update method and it's callable
					if hasattr(component, 'update') and callable(getattr(component, 'update', None)):
						component.update(delta_time)
				except Exception as e:
					# Log error but don't crash the update loop
					print(f"Error updating component {component.__class__.__name__} on entity {entity.name}: {e}", flush=True)
	
	def _save_scene_snapshot(self) -> None:
		"""
		Serialize all entities and components to a snapshot.
		Similar to Unity's pre-play serialization.
		"""
		snapshot: List[Dict[str, Any]] = []
		
		def serialize_entity(entity, parent_id: Optional[str]) -> Dict[str, Any]:
			"""Serialize entity and all its components."""
			components_data = []
			for comp in entity.components:
				comp_type_name = getattr(comp, "type_name", comp.__class__.__name__)
				components_data.append({
					"type": comp_type_name,
					"data": comp.to_dict()
				})
			
			return {
				"id": entity.id,
				"name": entity.name,
				"parent_id": parent_id,
				"components": components_data
			}
		
		def visit(node, parent_id: Optional[str]) -> None:
			snapshot.append(serialize_entity(node, parent_id))
			for child in node.children:
				visit(child, node.id)
		
		# Serialize all root entities and their children
		for root in self._scene.root_entities():
			visit(root, None)
		
		self._play_mode_snapshot = snapshot
	
	def _restore_scene_snapshot(self) -> None:
		"""
		Restore scene to the saved snapshot state.
		Handles:
		1. Delete entities created during play mode (not in snapshot)
		2. Recreate entities deleted during play mode (in snapshot but not in scene)
		3. Restore component state for all entities that existed before play mode
		"""
		if self._play_mode_snapshot is None:
			return
		
		# Build sets for efficient lookup
		snapshot_entity_ids = {entry.get("id") for entry in self._play_mode_snapshot}
		current_entity_ids = {e.id for e in self._scene.entities()}
		
		# Step 1: Delete entities created during play mode (exist now but not in snapshot)
		entities_to_delete = current_entity_ids - snapshot_entity_ids
		for entity_id in entities_to_delete:
			entity = self._scene.find_by_id(entity_id)
			if entity is not None:
				self._scene.delete_entity(entity)
		
		# Step 2: Recreate entities deleted during play mode (in snapshot but not in scene)
		# We need to recreate them with their original IDs and hierarchy
		entities_to_recreate = snapshot_entity_ids - current_entity_ids
		
		# Recreate entities recursively, respecting parent-child relationships
		def recreate_entity_recursive(entry: Dict[str, Any], parent: Optional[Any]) -> None:
			"""Recreate an entity and its children from snapshot data."""
			entity_id = entry.get("id")
			entity_name = entry.get("name", "Entity")
			
			# Create entity with original ID
			entity = self._scene.create_entity(entity_name, parent, entity_id=entity_id)
			
			# Add all components
			for comp_data in entry.get("components", []):
				comp_type_name = comp_data.get("type")
				comp_cls = get_component_class(comp_type_name) if comp_type_name else None
				if comp_cls is None:
					continue
				comp = comp_cls.from_dict(comp_data.get("data", {}))
				entity.add_component(comp)
			
			# Recreate children
			for child_entry in self._play_mode_snapshot:
				if child_entry.get("parent_id") == entity_id:
					recreate_entity_recursive(child_entry, entity)
		
		# Recreate root entities first (those with no parent or parent_id is None)
		for entry in self._play_mode_snapshot:
			if entry.get("id") in entities_to_recreate:
				parent_id = entry.get("parent_id")
				# If parent_id is None or parent doesn't need recreation, it's a root entity
				if parent_id is None or parent_id not in entities_to_recreate:
					parent = self._scene.find_by_id(parent_id) if parent_id else None
					recreate_entity_recursive(entry, parent)
		
		# Step 3: Restore component state for all entities that existed before play mode
		# (both those that still exist and those we just recreated)
		entity_map = {e.id: e for e in self._scene.entities()}
		
		for entry in self._play_mode_snapshot:
			entity_id = entry.get("id")
			entity = entity_map.get(entity_id)
			
			if entity is None:
				# Shouldn't happen after recreation, but skip just in case
				continue
			
			# Build a set of component types that should exist (from snapshot)
			snapshot_comp_types = {comp_data.get("type") for comp_data in entry.get("components", [])}
			
			# Remove components that were added during play mode (not in snapshot)
			components_to_remove = []
			for comp in entity.components:
				comp_type_name = getattr(comp, "type_name", comp.__class__.__name__)
				if comp_type_name not in snapshot_comp_types:
					components_to_remove.append(comp)
			
			for comp in components_to_remove:
				entity.remove_component(comp)
			
			# Build a map of component type -> component for this entity (after removal)
			comp_map = {}
			for comp in entity.components:
				comp_type_name = getattr(comp, "type_name", comp.__class__.__name__)
				comp_map[comp_type_name] = comp
			
			# Restore each component from snapshot
			for comp_data in entry.get("components", []):
				comp_type_name = comp_data.get("type")
				comp_cls = get_component_class(comp_type_name) if comp_type_name else None
				
				if comp_cls is None:
					continue
				
				existing_comp = comp_map.get(comp_type_name)
				
				if existing_comp is None:
					# Component was removed during play mode - recreate it
					comp = comp_cls.from_dict(comp_data.get("data", {}))
					entity.add_component(comp)
				else:
					# Component exists - restore its data
					# Create temporary instance to respect from_dict() logic
					temp_comp = comp_cls.from_dict(comp_data.get("data", {}))
					
					# Copy all public attributes from temp to existing component
					saved_data = comp_data.get("data", {})
					for key in saved_data.keys():
						if not key.startswith("_"):
							try:
								temp_value = object.__getattribute__(temp_comp, key)
								# Use object.__setattr__ to avoid triggering signal emission during bulk restore
								object.__setattr__(existing_comp, key, temp_value)
							except (AttributeError, Exception):
								pass
			
			# Emit entity_changed once per entity after all components are restored
			if entity.scene:
				entity.scene.events.entity_changed.emit(entity.id)
		
		# Step 4: Resolve Component references (entity_id -> Component)
		# Now that all entities and components are restored, we can resolve Component references
		# Similar to load_scene() - component references need to be resolved after all entities exist
		self._resolve_component_references()
	
	def _resolve_component_references(self) -> None:
		"""
		Resolve Component reference fields from entity_id strings to Component instances.
		This is called after all entities and components are restored from snapshot.
		Reuses the same logic as json_io._resolve_component_references().
		"""
		from typing import get_origin, get_args
		from MotionStudio.core.ecs.component import Component
		from MotionStudio.ui.inspector.reflection import iter_editable_fields
		import typing
		
		# Build entity ID to Entity map for efficient lookup
		id_to_entity = {e.id: e for e in self._scene.entities()}
		
		for entity in self._scene.entities():
			for component in entity.components:
				# Use reflection to find Component reference fields
				for spec in iter_editable_fields(component):
					field_name = spec.name
					field_type = spec.typ
					
					# Check if this is a Component reference field (Optional[ComponentType])
					origin = get_origin(field_type) if hasattr(typing, 'get_origin') else None
					if origin is typing.Union:
						args = get_args(field_type)
						# Extract inner type (first non-None type)
						inner_type = None
						for arg in args:
							if arg is not type(None):
								inner_type = arg
								break
						
						if inner_type is not None:
							# Check if inner type is a Component subclass
							try:
								if issubclass(inner_type, Component):
									# This is a Component reference field
									# Get current value (should be entity_id string or None)
									current_value = spec.getter()
									
									# If it's a string (entity_id), resolve it to Component
									if isinstance(current_value, str):
										target_entity = id_to_entity.get(current_value)
										if target_entity is not None:
											# Find the component of the expected type on the target entity
											target_component = target_entity.get_component(inner_type)
											if target_component is not None:
												# Resolve: set the Component reference
												if spec.setter is not None:
													spec.setter(target_component)
											else:
												# Entity exists but doesn't have the component - set to None
												if spec.setter is not None:
													spec.setter(None)
										else:
											# Entity doesn't exist - set to None
											if spec.setter is not None:
												spec.setter(None)
									elif current_value is None:
										# Already None, leave as-is
										pass
									# If it's already a Component, leave it as-is
							except (TypeError, AttributeError):
								# Not a Component type, skip
								pass


from __future__ import annotations

from typing import Annotated, Optional

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ReadOnly, Tooltip


@register_component
class UrdfLinkComponent(Component):
	"""Marks an entity as a URDF link in an imported robot."""

	type_name = "UrdfLink"
	category = "Robot"
	description = (
		"Marks an entity as a URDF link in an imported robot hierarchy. "
		"Usually added automatically during Import URDF."
	)

	link_name: Annotated[str, ReadOnly(), Tooltip("URDF link name")]
	parent_joint_name: Annotated[Optional[str], ReadOnly(), Tooltip("Joint connecting parent link to this link")] = None

	def __init__(self, link_name: str = "", parent_joint_name: Optional[str] = None) -> None:
		self.link_name = str(link_name)
		self.parent_joint_name = str(parent_joint_name) if parent_joint_name else None

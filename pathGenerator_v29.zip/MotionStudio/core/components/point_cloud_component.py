from __future__ import annotations

from typing import Annotated

from PyQt6.QtGui import QColor

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Range, Tooltip


@register_component
class PointCloudComponent(Component):
	"""
	Renders a dense 3D point cloud (``.ply`` / ``.pcd``) in the viewport.

	Geometry follows the owning entity's world transform. Does not participate
	in collision, VertexPick, or path tools.
	"""

	type_name = "PointCloud"
	category = "Rendering"
	description = (
		"Renders a dense .ply / .pcd point cloud in the viewport. Does not "
		"participate in collision, VertexPick, or path tools."
	)

	file_path: Annotated[
		str,
		FilePath(
			"Point Clouds (*.ply *.pcd);;All Files (*.*)",
			dialog_title="Select Point Cloud",
		),
		Tooltip(
			"Project-relative point-cloud path; external files are copied into "
			"the project's models/ folder. Supported: .ply, .pcd (ASCII or uncompressed binary)."
		),
	] = ""
	color: Annotated[
		QColor,
		ColorField(),
		Tooltip("Uniform point color when vertex colors are unavailable or disabled."),
	]
	use_vertex_colors: Annotated[
		bool,
		Tooltip("When true and the file has RGB, render per-point colors instead of Color."),
	] = True
	point_size: Annotated[
		float,
		Range(1.0, 20.0, step=0.5, decimals=1),
		Tooltip("Point size in screen pixels."),
	] = 2.0
	opacity: Annotated[
		float,
		Range(0.0, 1.0, step=0.05, decimals=2),
		Tooltip("Actor opacity (0 = invisible, 1 = opaque)."),
	] = 1.0
	scale: Annotated[
		float,
		Range(0.001, 10000.0, step=1.0, decimals=3),
		Tooltip(
			"Uniform multiplier applied to XYZ at load. Default 1000 converts "
			"metre-scale clouds to engine millimetres; use 1 if the file is already in mm."
		),
	] = 1000.0

	def __init__(
		self,
		file_path: str = "",
		color: QColor | None = None,
		use_vertex_colors: bool = True,
		point_size: float = 2.0,
		opacity: float = 1.0,
		scale: float = 1000.0,
	) -> None:
		self.file_path = str(file_path or "")
		self.color = color or QColor(200, 200, 200)
		self.use_vertex_colors = bool(use_vertex_colors)
		try:
			self.point_size = float(point_size)
		except Exception:
			self.point_size = 2.0
		try:
			op = float(opacity)
		except Exception:
			op = 1.0
		self.opacity = max(0.0, min(1.0, op))
		try:
			sc = float(scale)
		except Exception:
			sc = 1000.0
		self.scale = sc if sc > 0.0 else 1000.0

from __future__ import annotations

from typing import Annotated, Any, Dict, List, Literal, Optional, Tuple, TYPE_CHECKING

from PyQt6.QtGui import QMatrix4x4, QQuaternion, QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.matrix import qmatrix_from_prs
from MotionStudio.ui.inspector.metadata import Group, Tooltip, inspector_button
from .feature import Feature, get_feature_class
from MotionStudio.core.debug import Debug
from MotionStudio.core.transform.utils import world_matrix, transform_direction

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity


@register_component
class PathComponent(Component):
	"""
	Component that stores path generation data as an ordered list of segments.
	"""

	type_name = "PathGeneration"
	category = "Path generation and planning"
	description = (
		"Defines Cartesian path segments and waypoints for robot jobs. "
		"Supports export (e.g. URScript) and pairs with MotionPlanner."
	)

	export_format: Annotated[
		Literal["URScript"],
		Tooltip("Robot program language for Export Robot Program"),
		Group("Export Robot Program"),
	] = "URScript"

	robot: Annotated[
		Optional[RobotDescriptionComponent],
		Tooltip(
			"Robot whose base/root frame is used when exporting path coordinates. "
			"Waypoints are transformed from world space into this robot's root_link frame."
		),
		Group("Export Robot Program"),
	] = None

	def __init__(self):
		super().__init__()
		self.segments: List[Feature] = []
		# URScript export defaults (m/s, m/s^2, blend radius in metres)
		self.speed: float = 0.25
		self.acceleration: float = 1.2
		self.default_cnt_radius: float = 0.0
		self.export_format = "URScript"
		self.robot = None

	@inspector_button(
		"Export...",
		tooltip="Export the path as a robot program in the selected format",
		group="Export Robot Program",
	)
	def export_robot_program(self) -> None:
		"""Export path waypoints in the selected robot base frame."""
		from PyQt6.QtWidgets import QFileDialog, QMessageBox

		fmt = str(getattr(self, "export_format", "URScript") or "URScript")
		if fmt != "URScript":
			QMessageBox.warning(None, "Export Failed", f"Unsupported export format: {fmt}")
			return

		robot = self._resolved_robot()
		if robot is None:
			QMessageBox.warning(
				None,
				"Export Failed",
				"Select a Robot (RobotDescription) in Export Robot Program so "
				"path coordinates can be expressed in the robot base frame.",
			)
			return

		try:
			segment_waypoints = self.get_waypoints_in_robot_frame(robot)
		except Exception as exc:
			QMessageBox.critical(None, "Export Failed", f"Failed to compute robot-frame poses:\n{exc}")
			return

		total_waypoints = sum(len(s) for s in segment_waypoints)
		if total_waypoints == 0:
			QMessageBox.warning(
				None, "Export Failed", "No waypoints to export. Please add path segments first."
			)
			return

		file_path, _ = QFileDialog.getSaveFileName(
			None,
			"Export Path to URScript",
			"",
			"URScript Files (*.script);;All Files (*.*)",
		)
		if not file_path:
			return
		if not file_path.endswith(".script"):
			file_path += ".script"

		try:
			from MotionStudio.core.path.exporters.urscript_exporter import export_to_urscript

			segment_speed_multipliers = [float(seg.speed_multiplier) for seg in self.segments]
			segment_cnt_radii = [float(seg.cnt_radius) for seg in self.segments]
			urscript_code = export_to_urscript(
				segment_waypoints,
				speed=float(self.speed),
				acceleration=float(self.acceleration),
				segment_speed_multipliers=segment_speed_multipliers,
				segment_cnt_radii=segment_cnt_radii,
			)
			with open(file_path, "w", encoding="utf-8") as f:
				f.write(urscript_code)
		except Exception as exc:
			QMessageBox.critical(None, "Export Failed", f"Failed to export path:\n{exc}")
			return

		base_ent = self.resolve_robot_base_entity(robot)
		base_name = base_ent.name if base_ent is not None else robot.root_link
		QMessageBox.information(
			None,
			"Export Successful",
			f"Path exported successfully to:\n{file_path}\n\n"
			f"{total_waypoints} waypoint(s) across {len(segment_waypoints)} segment(s) "
			f"exported in robot frame '{base_name}'.",
		)

	# Green cone at the first waypoint of each multi-waypoint segment showing
	# the initial travel direction. Rendered every viewport frame via Debug.draw_cone.
	SEGMENT_DIRECTION_CONE_SIZE: float = 15.0  # World-space base diameter (engine units)
	SEGMENT_DIRECTION_CONE_COLOR: Tuple[float, float, float] = (0.0, 1.0, 0.0)
	SEGMENT_DIRECTION_CONE_OPACITY: float = 0.2

	def on_viewport_draw(self) -> None:
		"""
		Draw a small semi-transparent green cone at the first waypoint of every
		segment that has more than 2 waypoints, pointing toward the segment's
		second waypoint. Serves as a per-segment direction indicator.

		Uses ``Debug.draw_cone`` (one-frame semantics) so this method must run
		every viewport render pass.
		"""
		if self.entity is None or not self.segments:
			return

		sel = self.entity.scene.selection
		if sel is None or not sel.is_entity_selected(self.entity):
			return

		wm = world_matrix(self.entity)

		for segment in self.segments:
			wps = segment.waypoints
			if len(wps) < 2:
				continue

			first_world = wm.map(wps[0].position)
			# Direction toward the next waypoint (in the entity's local frame),
			# then rotated into world space so the cone axis matches the on-screen path.
			local_dir = wps[1].position - wps[0].position
			if local_dir.lengthSquared() < 1e-12:
				continue
			world_dir = transform_direction(self.entity, local_dir)

			Debug.draw_cone(
				first_world,
				world_dir,
				size=self.SEGMENT_DIRECTION_CONE_SIZE,
				color=self.SEGMENT_DIRECTION_CONE_COLOR,
				filled=True,
				opacity=self.SEGMENT_DIRECTION_CONE_OPACITY,
				on_top=False,
			)

	@property
	def features(self) -> List[Feature]:
		"""Backward-compatible alias for ``segments``."""
		return self.segments

	@features.setter
	def features(self, value: List[Feature]) -> None:
		self.segments = value

	def to_dict(self) -> Dict[str, Any]:
		# Component.to_dict handles primitives and component refs
		data = super().to_dict()
		data["segments"] = [
			{"type": s.__class__.__name__, "data": s.to_dict()}
			for s in self.segments
		]
		return data

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> PathComponent:
		# Component.from_dict handles primitives and component refs (entity ids)
		inst = super().from_dict(data)

		segments_data = data.get("segments", data.get("features", []))
		inst.segments = []
		for entry in segments_data:
			s_type_name = entry.get("type")
			s_data = entry.get("data", {})
			s_cls = get_feature_class(s_type_name)
			if s_cls:
				inst.segments.append(s_cls.from_dict(s_data))

		return inst

	def get_world_waypoint_transforms(self) -> List[Tuple[float, float, float, float, float, float]]:
		"""
		Returns a flat list of waypoint transforms in world space (every
		waypoint from every segment, in segment order).

		Each waypoint is represented as [x, y, z, rx, ry, rz] where:
		- x, y, z: position in world space (millimetres, engine units)
		- rx, ry, rz: rotation in degrees (Euler angles XYZ) in world space

		Raises:
			RuntimeError: If this component is not attached to an entity.
		"""
		return [wp for seg in self.get_world_waypoints_by_segment() for wp in seg]

	def get_world_waypoints_by_segment(
		self,
	) -> List[List[Tuple[float, float, float, float, float, float]]]:
		"""
		Returns waypoint transforms in world space, grouped by segment.

		Each outer list element corresponds to one segment in declaration
		order; each inner list contains that segment's waypoints as
		``(x, y, z, rx, ry, rz)`` tuples. Positions are in engine units
		(millimetres); rotations are XYZ Euler angles in degrees.

		Raises:
			RuntimeError: If this component is not attached to an entity.
		"""
		if self.entity is None:
			raise RuntimeError("PathComponent must be attached to an entity to get world transforms")

		world_matrix = self._get_world_matrix()
		# Accumulated rotation through the hierarchy (scale stripped).
		world_rot_quat = self._extract_rotation_from_matrix(world_matrix)

		grouped: List[List[Tuple[float, float, float, float, float, float]]] = []
		for segment in self.segments:
			feat_waypoints: List[Tuple[float, float, float, float, float, float]] = []
			for waypoint in segment.waypoints:
				world_pos = world_matrix.map(waypoint.position)
				# world_rot * waypoint_rot: apply hierarchy rotation first,
				# then the waypoint's local rotation.
				combined_rot_quat = world_rot_quat * waypoint.rotation
				euler = combined_rot_quat.toEulerAngles()
				feat_waypoints.append((
					float(world_pos.x()),
					float(world_pos.y()),
					float(world_pos.z()),
					float(euler.x()),
					float(euler.y()),
					float(euler.z()),
				))
			grouped.append(feat_waypoints)
		return grouped

	def get_world_waypoints_by_feature(
		self,
	) -> List[List[Tuple[float, float, float, float, float, float]]]:
		"""Backward-compatible alias for :meth:`get_world_waypoints_by_segment`."""
		return self.get_world_waypoints_by_segment()

	def resolve_robot_base_entity(
		self,
		robot: Optional["RobotDescriptionComponent"] = None,
	) -> Optional["Entity"]:
		"""
		Resolve the entity whose frame is the robot base/root link.

		Uses ``RobotDescription.root_link`` when present; falls back to the robot
		root entity that owns the description.
		"""
		rd = robot if robot is not None else self._resolved_robot()
		if rd is None:
			return None
		robot_ent = rd.entity
		if robot_ent is None:
			return None
		root_id = rd.find_link_entity_id(rd.root_link)
		if root_id and robot_ent.scene is not None:
			base = robot_ent.scene.find_by_id(root_id)
			if base is not None:
				return base
		return robot_ent

	def get_waypoints_in_robot_frame(
		self,
		robot: Optional["RobotDescriptionComponent"] = None,
	) -> List[List[Tuple[float, float, float, float, float, float]]]:
		"""
		Return waypoint transforms expressed in the selected robot's base frame.

		Same tuple layout as :meth:`get_world_waypoints_by_segment`:
		positions in millimetres, XYZ Euler angles in degrees — but relative to
		the robot ``root_link`` (or robot root entity if the link cannot be
		resolved).

		Raises:
			RuntimeError: If this component is not attached, or no robot base
				frame can be resolved.
		"""
		rd = robot if robot is not None else self._resolved_robot()
		base_ent = self.resolve_robot_base_entity(rd)
		if base_ent is None:
			raise RuntimeError(
				"PathComponent export requires a RobotDescription reference "
				"to define the robot base frame."
			)

		from MotionStudio.core.transform.utils import world_matrix

		t_world_base = world_matrix(base_ent)
		inv_base, ok = t_world_base.inverted()
		if not ok:
			raise RuntimeError("Could not invert robot base world matrix.")

		world_groups = self.get_world_waypoints_by_segment()
		out: List[List[Tuple[float, float, float, float, float, float]]] = []
		for waypoints in world_groups:
			frame_wps: List[Tuple[float, float, float, float, float, float]] = []
			for x, y, z, rx, ry, rz in waypoints:
				t_world_wp = QMatrix4x4()
				t_world_wp.translate(QVector3D(float(x), float(y), float(z)))
				t_world_wp.rotate(QQuaternion.fromEulerAngles(float(rx), float(ry), float(rz)))
				t_base_wp = inv_base * t_world_wp
				pos = t_base_wp.column(3).toVector3D()
				euler = self._extract_rotation_from_matrix(t_base_wp).toEulerAngles()
				frame_wps.append((
					float(pos.x()),
					float(pos.y()),
					float(pos.z()),
					float(euler.x()),
					float(euler.y()),
					float(euler.z()),
				))
			out.append(frame_wps)
		return out

	def _resolved_robot(self) -> Optional["RobotDescriptionComponent"]:
		"""Return the bound RobotDescription, rebinding from entity id if needed."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)

		value = getattr(self, "robot", None)
		if value is None:
			return None
		if isinstance(value, RobotDescriptionComponent):
			return value
		if isinstance(value, str) and self.entity is not None and self.entity.scene is not None:
			ent = self.entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if comp is not None:
					self.robot = comp
					return comp
		return None

	def _get_world_matrix(self) -> QMatrix4x4:
		"""
		Computes the world transform matrix for this component's entity by accumulating
		transforms up the hierarchy.
		"""
		if self.entity is None:
			return QMatrix4x4()

		stack: List[QMatrix4x4] = []
		curr = self.entity

		while curr is not None:
			t = curr.get_component(TransformComponent)
			if t is None:
				stack.append(QMatrix4x4())
			else:
				stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
			curr = curr.parent

		world = QMatrix4x4()
		for m in reversed(stack):
			world = world * m

		return world

	def _extract_rotation_from_matrix(self, matrix: QMatrix4x4) -> QQuaternion:
		"""
		Extracts the rotation quaternion from a 4x4 transform matrix.
		Uses normalMatrix() which automatically removes scale and returns a 3x3 rotation matrix.
		"""
		# normalMatrix() returns the upper-left 3x3 rotation matrix (scale removed)
		rot_matrix_3x3 = matrix.normalMatrix()
		return QQuaternion.fromRotationMatrix(rot_matrix_3x3)

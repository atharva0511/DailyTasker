from __future__ import annotations

from typing import Annotated, Literal

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Tooltip
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QVector3D, QColor
import time
import numpy as np


@register_component
class MeshComponent(Component):
	type_name = "Mesh"
	category = "Rendering"
	description = (
		"Renders a primitive or custom mesh on the entity. Geometry follows "
		"Transform; optional source-material colors for imported assets."
	)

	shape: Annotated[Literal["cube", "sphere", "custom"], Tooltip("Primitive shape or custom mesh")]
	custom_path: Annotated[str, FilePath("Mesh Files (*.stl *.obj *.fbx *.dae *.gltf *.glb);;All Files (*.*)"), Tooltip("Project-relative mesh path; external files are copied into the project's models/ folder")]
	source_material: Annotated[bool, Tooltip("Use imported source material colors (when available) instead of custom unicolor")]
	color: Annotated[QColor, ColorField(), Tooltip("Material color")]

	def __init__(self, shape: str = "cube", custom_path: str = "", source_material: bool = False, color: QColor | None = None) -> None:
		# shape: "cube" | "sphere" | "custom"
		self.shape = shape
		self.custom_path = custom_path
		self.source_material = bool(source_material)
		self.color = color or QColor(200, 200, 200)

		self._last_time = time.time()
		self._check = False

	def update(self, delta_time: float):
		pass

	# to_dict() and from_dict() are now automatically handled by Component base class!
	# No need to override them unless you have special serialization needs.



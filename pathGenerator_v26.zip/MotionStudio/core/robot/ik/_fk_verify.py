"""Shared FK evaluation helpers used by analytic backends (enumerate mode)."""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest


def rx(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((1.0, 0.0, 0.0), (0.0, c, -s), (0.0, s, c)), dtype=np.float64)


def ry(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((c, 0.0, s), (0.0, 1.0, 0.0), (-s, 0.0, c)), dtype=np.float64)


def rz(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((c, -s, 0.0), (s, c, 0.0), (0.0, 0.0, 1.0)), dtype=np.float64)


def axis_angle(axis: np.ndarray, theta: float) -> np.ndarray:
	ax = np.asarray(axis, dtype=np.float64)
	n = float(np.linalg.norm(ax))
	if n < 1e-12:
		return np.eye(3, dtype=np.float64)
	x, y, z = ax / n
	c = math.cos(theta)
	s = math.sin(theta)
	t = 1.0 - c
	return np.array(
		(
			(t * x * x + c, t * x * y - s * z, t * x * z + s * y),
			(t * y * x + s * z, t * y * y + c, t * y * z - s * x),
			(t * z * x - s * y, t * z * y + s * x, t * z * z + c),
		),
		dtype=np.float64,
	)


def origin_transform(joint: Dict[str, Any]) -> np.ndarray:
	xyz = np.asarray(joint.get("origin_xyz_m", [0.0, 0.0, 0.0]), dtype=np.float64)
	rpy = np.asarray(joint.get("origin_rpy_rad", [0.0, 0.0, 0.0]), dtype=np.float64)
	m = np.eye(4, dtype=np.float64)
	# URDF convention: R = Rz(yaw) * Ry(pitch) * Rx(roll)
	m[:3, :3] = rz(float(rpy[2])) @ ry(float(rpy[1])) @ rx(float(rpy[0]))
	m[:3, 3] = xyz
	return m


def joint_path(
	joints: List[Dict[str, Any]], root_link: str, ee_link: str
) -> List[Dict[str, Any]]:
	by_child: Dict[str, Dict[str, Any]] = {str(j.get("child_link", "")): j for j in joints}
	path: List[Dict[str, Any]] = []
	cur = str(ee_link or "")
	guard = 0
	while cur and cur != root_link and cur in by_child:
		j = by_child[cur]
		path.append(j)
		cur = str(j.get("parent_link", ""))
		guard += 1
		if guard > 4096:
			break
	path.reverse()
	return path


def forward_kinematics(request: IKSolveRequest, q_map: Dict[str, float]) -> Optional[np.ndarray]:
	path = joint_path(request.joints, request.root_link, request.ee_link)
	if not path:
		return None
	t = np.eye(4, dtype=np.float64)
	for j in path:
		t = t @ origin_transform(j)
		jname = str(j.get("name", ""))
		jtype = str(j.get("type", "fixed")).lower()
		if jtype in ("revolute", "continuous"):
			angle = float(q_map.get(jname, 0.0))
			axis = np.asarray(j.get("axis_xyz", [0.0, 0.0, 1.0]), dtype=np.float64)
			r = np.eye(4, dtype=np.float64)
			r[:3, :3] = axis_angle(axis, angle)
			t = t @ r
		elif jtype == "prismatic":
			dist = float(q_map.get(jname, 0.0))
			axis = np.asarray(j.get("axis_xyz", [0.0, 0.0, 1.0]), dtype=np.float64)
			n = float(np.linalg.norm(axis))
			if n > 1e-12:
				tr = np.eye(4, dtype=np.float64)
				tr[:3, 3] = axis / n * dist
				t = t @ tr
	return t


def pose_error(fk: np.ndarray, goal: np.ndarray) -> Tuple[float, float]:
	pos_err = float(np.linalg.norm(fk[:3, 3] - goal[:3, 3]))
	r_rel = fk[:3, :3].T @ goal[:3, :3]
	cos_angle = (np.trace(r_rel) - 1.0) * 0.5
	ang_err = float(math.acos(max(-1.0, min(1.0, cos_angle))))
	return pos_err, ang_err


def joint_wrap_distance(q_a: Dict[str, float], q_b: Dict[str, float], joint_names: List[str]) -> float:
	"""Sum of absolute wrapped joint deltas (radians) between two configs."""
	total = 0.0
	two_pi = 2.0 * math.pi
	for name in joint_names:
		da = float(q_a.get(name, 0.0))
		db = float(q_b.get(name, 0.0))
		d = (da - db + math.pi) % two_pi - math.pi
		total += abs(d)
	return total

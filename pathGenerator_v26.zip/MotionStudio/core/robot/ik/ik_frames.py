from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from PyQt6.QtGui import QMatrix4x4, QQuaternion

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity

MM_TO_M = 0.001


def qmatrix_to_numpy(m: QMatrix4x4) -> np.ndarray:
	"""Convert a column-vector ``QMatrix4x4`` to a 4x4 numpy array."""
	out = np.empty((4, 4), dtype=np.float64)
	for r in range(4):
		for c in range(4):
			out[r, c] = float(m[r, c])
	return out


def quat_to_rotation_matrix(q: QQuaternion) -> np.ndarray:
	"""Orthonormal 3x3 from a quaternion (scale-free)."""
	m = QMatrix4x4()
	m.rotate(q.normalized())
	out = np.empty((3, 3), dtype=np.float64)
	for r in range(3):
		for c in range(3):
			out[r, c] = float(m[r, c])
	return out


def project_to_se3(T: np.ndarray) -> np.ndarray:
	"""Force a 4x4 into a rigid SE(3) pose (orthonormal R, bottom row [0,0,0,1]).

	Analytical IK (ssik) rejects targets whose FK residual is measured with a
	full-matrix Frobenius norm at ~1e-7. Scaled / sheared scene matrices that
	are still "close enough" for numerical IK will return ``[]`` from ssik.
	"""
	T = np.asarray(T, dtype=np.float64)
	out = np.eye(4, dtype=np.float64)
	R = T[:3, :3]
	u, _s, vt = np.linalg.svd(R)
	Rn = u @ vt
	if np.linalg.det(Rn) < 0.0:
		u = u.copy()
		u[:, -1] *= -1.0
		Rn = u @ vt
	out[:3, :3] = Rn
	out[:3, 3] = T[:3, 3]
	return out


def rigid_world_pose_m(entity: "Entity") -> np.ndarray:
	"""World pose of ``entity`` as a clean SE(3) matrix, translation in metres.

	Built from scale-free ``world_rotation_quat`` + ``world_position`` rather
	than ``world_matrix`` (which folds parent scale into the linear block and
	breaks analytical IK).
	"""
	# Late import: transform.utils <-> components can circular-import at startup.
	from MotionStudio.core.transform.utils import world_position, world_rotation_quat

	pos = world_position(entity)
	out = np.eye(4, dtype=np.float64)
	out[:3, :3] = quat_to_rotation_matrix(world_rotation_quat(entity))
	out[0, 3] = float(pos.x()) * MM_TO_M
	out[1, 3] = float(pos.y()) * MM_TO_M
	out[2, 3] = float(pos.z()) * MM_TO_M
	return out


def relative_offset_m(from_entity: "Entity", to_entity: "Entity") -> np.ndarray:
	"""Pose of ``to_entity`` expressed in ``from_entity``'s frame, metres.

	Used to capture the rigid mounting offset between the robot tool link and a
	custom tool-control-point entity. As long as the TCP is rigidly attached
	(e.g. a child of the tool-link entity), this offset is pose-independent.
	"""
	a = rigid_world_pose_m(from_entity)
	b = rigid_world_pose_m(to_entity)
	return project_to_se3(np.linalg.inv(a) @ b)


def goal_in_base_frame(base_entity: "Entity", target_entity: "Entity") -> np.ndarray:
	"""Target pose expressed in the robot base frame, translation in metres.

	Engine transforms store translation in millimetres; IK solvers expect
	metres. Rotation is taken from scale-free world quaternions so the result
	is a proper SE(3) pose suitable for analytical solvers.
	"""
	t_world_base = rigid_world_pose_m(base_entity)
	t_world_target = rigid_world_pose_m(target_entity)
	return project_to_se3(np.linalg.inv(t_world_base) @ t_world_target)

"""Generate ssik analytical IK artifacts next to a URDF."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Tuple


def analytic_solver_relpath(urdf_project_path: str | Path) -> Path:
	"""Project-relative path for ``<stem>_analytic_ik.py`` next to the URDF."""
	urdf_rel = Path(urdf_project_path)
	return urdf_rel.with_name(f"{urdf_rel.stem}_analytic_ik.py")


def try_generate_analytic_solver(
	*,
	urdf_abs: Path,
	base_link: str,
	ee_link: str,
	output: Path,
	timeout_s: float = 60.0,
) -> Tuple[bool, str]:
	"""Run ``python -m ssik.cli build`` to emit an analytical IK module.

	Returns ``(ok, message)``. Failures (missing extras, unsupported topology,
	timeouts) never raise — callers can swallow and continue URDF import.
	"""
	urdf_abs = Path(urdf_abs)
	output = Path(output)
	if not urdf_abs.is_file():
		return False, f"URDF not found: {urdf_abs}"

	module_name = output.stem
	# ssik exposes its CLI via the ``ssik`` console script / ``ssik.cli`` module.
	# There is no ``ssik.__main__``, so ``python -m ssik`` fails.
	cmd = [
		sys.executable,
		"-m",
		"ssik.cli",
		"build",
		str(urdf_abs),
		"--base",
		str(base_link or "base_link"),
		"--ee",
		str(ee_link or "tool0"),
		"--out",
		str(output),
		"--module-name",
		module_name,
		"--no-validate",
	]
	# ssik prints Unicode arrows (→, ✓); force UTF-8 so Windows cp1252 consoles
	# don't crash the subprocess mid-build.
	env = os.environ.copy()
	env.setdefault("PYTHONIOENCODING", "utf-8")
	env.setdefault("PYTHONUTF8", "1")
	try:
		output.parent.mkdir(parents=True, exist_ok=True)
		completed = subprocess.run(
			cmd,
			capture_output=True,
			text=True,
			encoding="utf-8",
			errors="replace",
			timeout=float(timeout_s),
			check=False,
			env=env,
		)
	except FileNotFoundError:
		return False, "Python interpreter not found while generating analytic IK."
	except subprocess.TimeoutExpired:
		return False, f"ssik build timed out after {timeout_s:.0f}s for {urdf_abs.name}."
	except Exception as exc:  # pragma: no cover - defensive
		return False, f"ssik build failed: {exc}"

	if completed.returncode != 0:
		stderr = (completed.stderr or completed.stdout or "").strip()
		hint = stderr.splitlines()[-1] if stderr else f"exit code {completed.returncode}"
		missing_ssik = "No module named ssik" in stderr or "No module named 'ssik" in stderr
		needs_urdf_extra = (
			"urchin" in stderr.lower()
			or "ssik[urdf]" in stderr.lower()
			or ("urdf" in stderr.lower() and "install" in stderr.lower())
		)
		if missing_ssik or needs_urdf_extra:
			return False, (
				"ssik (or ssik[urdf]) is not installed. Run: pip install \"ssik[urdf]\" "
				f"(detail: {hint})"
			)
		return False, f"ssik build failed for {urdf_abs.name}: {hint}"

	if not output.is_file():
		return False, f"ssik build reported success but did not write {output}."

	return True, f"Generated analytic IK solver: {output.name}"


def resolve_or_generate_analytic_solver(
	*,
	project_root: Path,
	urdf_project_path: str | Path,
	base_link: str,
	ee_link: str,
	force: bool = False,
) -> Tuple[str, str]:
	"""Return ``(project_relative_path, status_message)``.

	If the artifact already exists and ``force`` is False, just returns its
	relative path. Otherwise attempts generation via :func:`try_generate_analytic_solver`.
	"""
	rel = analytic_solver_relpath(urdf_project_path)
	abs_path = Path(project_root) / rel
	if abs_path.is_file() and not force:
		return rel.as_posix(), f"Using existing analytic IK solver: {rel.as_posix()}"

	urdf_abs = Path(project_root) / Path(urdf_project_path)
	ok, msg = try_generate_analytic_solver(
		urdf_abs=urdf_abs,
		base_link=base_link,
		ee_link=ee_link,
		output=abs_path,
	)
	if ok:
		return rel.as_posix(), msg
	return "", msg

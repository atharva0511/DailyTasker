"""IK backend factory — no silent fallback between solvers."""

from __future__ import annotations

from typing import Dict

from MotionStudio.core.robot.ik.ik_backend import IKBackend, IKSolveRequest, IKSolveResult

_VALID_BACKENDS = frozenset({"analytic", "ikpy"})


class IKBackendError(RuntimeError):
	"""Raised when the selected IK backend cannot be used or fails hard."""


def make_ik_backend(name: str) -> IKBackend:
	"""Construct an IK backend by name.

	Only ``analytic`` and ``ikpy`` are supported. Unknown names raise
	:class:`IKBackendError` (no silent remap to another solver).
	"""
	key = (name or "").strip().lower()
	if key == "analytic":
		from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend

		return AnalyticIKBackend()
	if key == "ikpy":
		from MotionStudio.core.robot.ik.ikpy_backend import IKPyIKBackend

		return IKPyIKBackend()
	raise IKBackendError(
		f"Unknown IK backend '{name}'. Supported backends: analytic, ikpy. "
		f"(ikfast and pinocchio have been removed.)"
	)


def solve_ik_request(
	backend_name: str,
	request: IKSolveRequest,
	backend_cache: Dict[str, IKBackend],
) -> IKSolveResult:
	"""Run IK with exactly one backend — never falls back to another.

	Raises :class:`IKBackendError` if the backend name is invalid, the
	backend is not installed/available, or (for analytic) the solver module
	is not configured. Unreachable poses return ``IKSolveResult(success=False)``
	without raising so continuous tracking can skip applying.
	"""
	key = (backend_name or "").strip().lower()

	backend = backend_cache.get(key)
	if backend is None:
		backend = make_ik_backend(key)  # raises IKBackendError if unknown
		backend_cache[key] = backend

	if not backend.is_available():
		raise IKBackendError(
			f"IK backend '{key}' is not available (dependency not installed)."
		)

	result = backend.solve(request)

	# Hard configuration errors — do not silently continue with another solver.
	msg_l = (result.message or "").lower()
	hard_fail = (
		not result.success
		and not result.joint_values
		and (
			"not configured" in msg_l
			or "not found or invalid" in msg_l
			or "not installed" in msg_l
		)
	)
	if hard_fail:
		raise IKBackendError(result.message or f"IK backend '{key}' failed.")

	if result.success or result.joint_values:
		if not result.message:
			result.message = f"solved by {key}"
		elif "solved by" not in result.message:
			result.message = f"{result.message} (solved by {key})"

	return result

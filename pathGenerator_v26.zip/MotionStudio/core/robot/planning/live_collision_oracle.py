"""Live viewport collision oracle (diagnostics / unit tests only).

Production planning uses ``PlanningCollisionWorld`` so sampling never poses the
robot or runs Qt/VTK. This oracle remains for A/B checks: every
``is_state_valid(q)`` is marshalled to the main thread, which applies ``q`` via
``apply_solution`` and runs ``CollisionSystem.check_all()``.

IMPORTANT: this path must **never** call ``QApplication.processEvents()``.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

import numpy as np
from PyQt6.QtCore import QMutex, QMutexLocker, QObject, QWaitCondition, pyqtSignal, pyqtSlot

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene


class LiveViewportCollisionOracle(QObject):
	"""Drop-in ``collision_world`` that poses the robot and uses live CollisionSystem.

	Must be created on the main (GUI) thread. Safe to call ``is_state_valid`` /
	``first_invalid_on_segment`` from the planner worker thread.
	"""

	uses_live_viewport: bool = True

	# Worker → main: wake the slot that performs the check.
	_check_requested = pyqtSignal()

	def __init__(
		self,
		scene: "Scene",
		*,
		robot_entity_id: str,
		joint_names: List[str],
		joints: List[Dict[str, Any]],
		root_link: str,
		# Worker sleeps this long every ``yield_every`` checks so the GUI can paint.
		yield_every: int = 8,
		yield_s: float = 0.008,
		parent: Optional[QObject] = None,
	) -> None:
		super().__init__(parent)
		self._scene = scene
		self.robot_entity_id = str(robot_entity_id)
		self.joint_names = list(joint_names)
		self.joints = [dict(j) for j in joints]
		self.root_link = str(root_link)
		self._yield_every = max(1, int(yield_every))
		self._yield_s = max(0.0, float(yield_s))

		self._mutex = QMutex()
		self._wait = QWaitCondition()
		self._pending_q: Optional[np.ndarray] = None
		self._want_pair = False
		self._result_valid = True
		self._result_pair: Optional[Tuple[str, str]] = None
		self._done = False
		self._closed = False
		self._in_check = False  # reentrancy guard (main thread)

		self._check_count = 0
		self._saved_joints: Dict[str, float] = {}
		self._saved_ik_enabled: Optional[bool] = None

		# Pipeline-compat fields (``plan_pipeline`` inspects these).
		self.robot_bodies: List[Any] = []
		self.static_bodies: List[Any] = []
		self.enabled_pairs: List[Tuple[str, str]] = []

		self._check_requested.connect(self._on_check_main)
		self._refresh_pair_census()

	# ------------------------------------------------------------------ lifecycle

	def begin_planning(self) -> None:
		"""Call on the main thread before the worker starts planning."""
		rd = self._robot_desc()
		if rd is None:
			return
		self._saved_joints = {
			n: float(rd.joint_positions.get(n, 0.0)) for n in self.joint_names
		}
		ent = rd.entity
		if ent is not None:
			from MotionStudio.core.components.robot_ik_component import RobotIKComponent

			ik = ent.get_component(RobotIKComponent)
			if ik is not None:
				self._saved_ik_enabled = bool(ik.enabled)
				ik.enabled = False
			else:
				self._saved_ik_enabled = None
		self._refresh_pair_census()
		self._check_count = 0

	def end_planning(self, *, restore_joints: bool = True) -> None:
		"""Call on the main thread after planning finishes."""
		rd = self._robot_desc()
		ent = rd.entity if rd is not None else None
		if ent is not None and self._saved_ik_enabled is not None:
			from MotionStudio.core.components.robot_ik_component import RobotIKComponent

			ik = ent.get_component(RobotIKComponent)
			if ik is not None:
				ik.enabled = bool(self._saved_ik_enabled)
		self._saved_ik_enabled = None

		if restore_joints and self._saved_joints and rd is not None and ent is not None:
			try:
				cs = self._scene.collision_system
				cs.suspend_deferred_updates()
				try:
					self._scene.robot_ik_system.apply_solution(ent.id, dict(self._saved_joints))
					cs.check_all()
				finally:
					cs.resume_deferred_updates(discard_pending=True)
			except Exception:
				pass
		self._saved_joints = {}

	def close(self) -> None:
		"""Wake any blocked worker and mark the oracle unusable."""
		with QMutexLocker(self._mutex):
			self._closed = True
			self._done = True
			self._result_valid = True
			self._result_pair = None
			self._wait.wakeAll()

	# ------------------------------------------------------------------ census / summary

	def _refresh_pair_census(self) -> None:
		from MotionStudio.core.components.collider_component import ColliderComponent
		from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
		from MotionStudio.core.robot.collision_groups import partition_colliders
		from MotionStudio.core.robot.planning.collision_world import all_matrix_pairs

		cs = self._scene.collision_system
		entities = list(cs.collider_entities())
		groups, ungrouped = partition_colliders(entities)
		pairs = all_matrix_pairs(groups, ungrouped, cs.matrix)
		self.enabled_pairs = [(str(a.id), str(b.id)) for a, b in pairs]

		robot_ent = self._scene.find_by_id(self.robot_entity_id)
		robot_ids: List[str] = []
		static_ids: List[str] = []
		if robot_ent is not None:
			link_ids = set()

			def walk(e) -> None:
				if e.get_component(UrdfLinkComponent) is not None:
					link_ids.add(str(e.id))
				for ch in e.children:
					walk(ch)

			walk(robot_ent)
			for e in entities:
				eid = str(e.id)
				col = e.get_component(ColliderComponent)
				if col is None:
					continue
				cur = e
				under = False
				while cur is not None:
					if str(cur.id) == str(robot_ent.id) or str(cur.id) in link_ids:
						under = True
						break
					cur = cur.parent
				if under:
					robot_ids.append(eid)
				else:
					static_ids.append(eid)
		else:
			static_ids = [str(e.id) for e in entities]

		self.robot_bodies = [{"entity_id": i} for i in robot_ids]
		self.static_bodies = [{"entity_id": i} for i in static_ids]

	def collision_summary(self) -> str:
		backend = getattr(self._scene.collision_system, "backend_id", "?")
		return (
			f"live_viewport backend={backend} "
			f"robot_colliders={len(self.robot_bodies)} "
			f"world_colliders={len(self.static_bodies)} "
			f"pairs={len(self.enabled_pairs)} "
			f"checks={self._check_count}"
		)

	def collision_checking_active(self) -> bool:
		return len(self.enabled_pairs) > 0

	# ------------------------------------------------------------------ joint limits (plain data)

	def joint_limits(self) -> List[Tuple[float, float]]:
		by_name = {str(j.get("name", "")): j for j in self.joints}
		out: List[Tuple[float, float]] = []
		for name in self.joint_names:
			j = by_name.get(name, {})
			jtype = str(j.get("type", "revolute")).lower()
			limits = j.get("limits") or {}
			if jtype == "continuous":
				out.append((-float(np.pi), float(np.pi)))
				continue
			lo = float(limits.get("lower", -np.pi)) if limits else -float(np.pi)
			hi = float(limits.get("upper", np.pi)) if limits else float(np.pi)
			if hi < lo:
				lo, hi = hi, lo
			out.append((lo, hi))
		return out

	def normalize_q(self, q: np.ndarray) -> np.ndarray:
		q = np.asarray(q, dtype=np.float64).reshape(-1).copy()
		by_name = {str(j.get("name", "")): j for j in self.joints}
		for i, name in enumerate(self.joint_names):
			if i >= q.size:
				break
			j = by_name.get(name, {})
			if str(j.get("type", "revolute")).lower() != "continuous":
				continue
			x = float(q[i])
			q[i] = float((x + np.pi) % (2.0 * np.pi) - np.pi)
		return q

	def within_limits(self, q: np.ndarray) -> bool:
		q = self.normalize_q(q)
		limits = self.joint_limits()
		if q.size != len(limits):
			return False
		for i, (lo, hi) in enumerate(limits):
			if q[i] < lo - 1e-9 or q[i] > hi + 1e-9:
				return False
		return True

	# ------------------------------------------------------------------ worker API

	def is_state_valid(self, q: np.ndarray) -> bool:
		q = self.normalize_q(q)
		if not self.within_limits(q):
			return False
		if not self.enabled_pairs:
			return True
		valid, _pair = self._invoke(q, want_pair=False)
		return bool(valid)

	def find_colliding_pair(self, q: np.ndarray) -> Optional[Tuple[str, str]]:
		q = self.normalize_q(q)
		if not self.within_limits(q) or not self.enabled_pairs:
			return None
		valid, pair = self._invoke(q, want_pair=True)
		if valid:
			return None
		return pair

	def first_invalid_on_segment(
		self,
		q_a: np.ndarray,
		q_b: np.ndarray,
		*,
		resolution_rad: float = 0.05,
	) -> Tuple[bool, Optional[np.ndarray], str]:
		qa = np.asarray(q_a, dtype=np.float64).reshape(-1)
		qb = np.asarray(q_b, dtype=np.float64).reshape(-1)
		if qa.size != qb.size:
			return False, qa, "DOF mismatch"

		ok, fail_q, detail = self._check_endpoint(qa, "start")
		if not ok:
			return False, fail_q, detail
		ok, fail_q, detail = self._check_endpoint(qb, "end")
		if not ok:
			return False, fail_q, detail

		delta = self._joint_delta_wrapped(qa, qb)
		dist = float(np.linalg.norm(delta))
		if dist < 1e-12:
			return True, None, ""
		step = max(1e-4, float(resolution_rad))
		# At least one interior sample so thin obstacles between free endpoints
		# cannot slip through when dist <= step (matches imove RRT).
		n = max(2, int(np.ceil(dist / step)))
		for i in range(1, n):
			alpha = float(i) / float(n)
			q = qa + alpha * delta
			valid, pair = self._invoke(q, want_pair=True)
			if not valid:
				extra = f" pair={pair}" if pair else ""
				return (
					False,
					q.copy(),
					f"mid-edge collision at α={alpha:.3f}{extra}",
				)
		return True, None, ""

	def _check_endpoint(
		self, q: np.ndarray, label: str
	) -> Tuple[bool, Optional[np.ndarray], str]:
		q = self.normalize_q(q)
		if not self.within_limits(q):
			return False, q.copy(), f"{label} sample out of limits"
		if not self.enabled_pairs:
			return True, None, ""
		valid, pair = self._invoke(q, want_pair=True)
		if valid:
			return True, None, ""
		extra = f" pair={pair}" if pair else ""
		return False, q.copy(), f"{label} sample in collision{extra}"

	def is_segment_valid(
		self,
		q_a: np.ndarray,
		q_b: np.ndarray,
		*,
		resolution_rad: float = 0.05,
	) -> bool:
		ok, _q, _detail = self.first_invalid_on_segment(
			q_a, q_b, resolution_rad=resolution_rad
		)
		return ok

	def _joint_delta_wrapped(self, qa: np.ndarray, qb: np.ndarray) -> np.ndarray:
		d = np.asarray(qb, dtype=np.float64).reshape(-1) - np.asarray(
			qa, dtype=np.float64
		).reshape(-1)
		out = d.copy()
		by_name = {str(j.get("name", "")): j for j in self.joints}
		limits = self.joint_limits()
		for i, name in enumerate(self.joint_names):
			if i >= out.size:
				break
			j = by_name.get(name, {})
			wrap = str(j.get("type", "revolute")).lower() == "continuous"
			if not wrap and i < len(limits):
				lo, hi = limits[i]
				wrap = float(hi - lo) >= (2.0 * np.pi - 1e-6)
			if wrap:
				x = float(out[i])
				out[i] = float((x + np.pi) % (2.0 * np.pi) - np.pi)
		return out

	def _invoke(
		self, q: np.ndarray, *, want_pair: bool
	) -> Tuple[bool, Optional[Tuple[str, str]]]:
		"""Block the calling (worker) thread until the main thread finishes the check."""
		with QMutexLocker(self._mutex):
			if self._closed:
				return True, None
			self._pending_q = np.asarray(q, dtype=np.float64).reshape(-1).copy()
			self._want_pair = bool(want_pair)
			self._done = False
			self._result_valid = True
			self._result_pair = None

		self._check_requested.emit()

		with QMutexLocker(self._mutex):
			while not self._done and not self._closed:
				self._wait.wait(self._mutex)
			valid = bool(self._result_valid)
			pair = self._result_pair
			count = int(self._check_count)

		# Let the GUI event loop breathe so VTK paint events are not starved.
		# Never call processEvents from the main-thread check slot.
		if self._yield_s > 0.0 and count > 0 and (count % self._yield_every) == 0:
			time.sleep(self._yield_s)

		return valid, pair

	# ------------------------------------------------------------------ main-thread slot

	@pyqtSlot()
	def _on_check_main(self) -> None:
		# Reentrancy guard: a nested delivery must not start a second evaluate.
		# (Should not happen without processEvents; keep as belt-and-suspenders.)
		if self._in_check:
			return
		self._in_check = True
		try:
			with QMutexLocker(self._mutex):
				q = None if self._pending_q is None else self._pending_q.copy()
				want_pair = bool(self._want_pair)

			valid = True
			pair: Optional[Tuple[str, str]] = None
			try:
				if q is not None:
					valid, pair = self._evaluate_on_main(q, want_pair=want_pair)
			except Exception:
				valid = False
				pair = None

			with QMutexLocker(self._mutex):
				self._result_valid = valid
				self._result_pair = pair
				self._done = True
				self._check_count += 1
				self._wait.wakeAll()
		finally:
			self._in_check = False

	def _evaluate_on_main(
		self, q: np.ndarray, *, want_pair: bool
	) -> Tuple[bool, Optional[Tuple[str, str]]]:
		rd = self._robot_desc()
		if rd is None or rd.entity is None:
			return True, None

		joints = {
			self.joint_names[i]: float(q[i])
			for i in range(min(len(self.joint_names), int(q.size)))
		}

		cs = self._scene.collision_system
		# FK emits entity_transform_changed → request_collision_update (0ms timer).
		# Suspend that timer so it cannot re-enter check_all while we run it below.
		cs.suspend_deferred_updates()
		try:
			self._scene.robot_ik_system.apply_solution(rd.entity.id, joints)
			# Synchronous sweep — same path as viewport Physics.
			cs.check_all()
		finally:
			cs.resume_deferred_updates(discard_pending=True)

		if want_pair:
			hit = self._first_colliding_entity_pair()
			return (hit is None), hit

		from MotionStudio.core.components.collider_component import ColliderComponent

		for ent in cs.collider_entities():
			col = ent.get_component(ColliderComponent)
			if col is not None and bool(getattr(col, "collided", False)):
				return False, None
		return True, None

	def _first_colliding_entity_pair(self) -> Optional[Tuple[str, str]]:
		from MotionStudio.core.robot.collision_groups import partition_colliders
		from MotionStudio.core.robot.planning.collision_world import all_matrix_pairs

		cs = self._scene.collision_system
		groups, ungrouped = partition_colliders(cs.collider_entities())
		for ent_a, ent_b in all_matrix_pairs(groups, ungrouped, cs.matrix):
			try:
				if cs._pair_collides(ent_a, ent_b):
					return str(ent_a.id), str(ent_b.id)
			except Exception:
				continue
		return None

	def _robot_desc(self):
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)

		ent = self._scene.find_by_id(self.robot_entity_id)
		if ent is None:
			return None
		return ent.get_component(RobotDescriptionComponent)

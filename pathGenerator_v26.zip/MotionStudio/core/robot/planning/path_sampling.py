"""Cartesian densification of path waypoints for process-segment IK."""

from __future__ import annotations

import math
from typing import List, Sequence, Tuple

import numpy as np
from PyQt6.QtGui import QMatrix4x4, QQuaternion


Pose6 = Tuple[float, float, float, float, float, float]  # x,y,z (m), rx,ry,rz (rad)


def pose6_to_matrix(pose: Pose6) -> np.ndarray:
	"""XYZ Euler (radians) → 4x4 SE3."""
	x, y, z, rx, ry, rz = pose
	quat = QQuaternion.fromEulerAngles(
		math.degrees(rx), math.degrees(ry), math.degrees(rz)
	)
	m = np.eye(4, dtype=np.float64)
	qm = QMatrix4x4()
	qm.rotate(quat.normalized())
	for r in range(3):
		for c in range(3):
			m[r, c] = float(qm[r, c])
	m[0, 3] = float(x)
	m[1, 3] = float(y)
	m[2, 3] = float(z)
	return m


def densify_segment(
	waypoints: Sequence[Pose6],
	spacing_m: float,
) -> Tuple[List[Pose6], List[float]]:
	"""Linear position + slerp orientation between consecutive waypoints.

	Returns densified poses (including all originals) and Cartesian lengths
	between consecutive densified poses.
	"""
	spacing = max(1e-4, float(spacing_m))
	if not waypoints:
		return [], []
	if len(waypoints) == 1:
		return [tuple(float(v) for v in waypoints[0])], []  # type: ignore[return-value]

	out: List[Pose6] = []
	lengths: List[float] = []

	def _append(pose: Pose6) -> None:
		if out:
			prev = np.array(out[-1][:3], dtype=np.float64)
			cur = np.array(pose[:3], dtype=np.float64)
			lengths.append(float(np.linalg.norm(cur - prev)))
		out.append(pose)

	_append(tuple(float(v) for v in waypoints[0]))  # type: ignore[arg-type]

	for i in range(len(waypoints) - 1):
		a = waypoints[i]
		b = waypoints[i + 1]
		pa = np.array(a[:3], dtype=np.float64)
		pb = np.array(b[:3], dtype=np.float64)
		dist = float(np.linalg.norm(pb - pa))
		qa = QQuaternion.fromEulerAngles(
			math.degrees(a[3]), math.degrees(a[4]), math.degrees(a[5])
		)
		qb = QQuaternion.fromEulerAngles(
			math.degrees(b[3]), math.degrees(b[4]), math.degrees(b[5])
		)
		n_steps = max(1, int(math.ceil(dist / spacing))) if dist > 1e-12 else 1
		for s in range(1, n_steps):
			alpha = float(s) / float(n_steps)
			p = pa + alpha * (pb - pa)
			q = QQuaternion.slerp(qa, qb, alpha)
			e = q.toEulerAngles()
			_append(
				(
					float(p[0]),
					float(p[1]),
					float(p[2]),
					math.radians(float(e.x())),
					math.radians(float(e.y())),
					math.radians(float(e.z())),
				)
			)
		_append(
			(
				float(pb[0]),
				float(pb[1]),
				float(pb[2]),
				float(b[3]),
				float(b[4]),
				float(b[5]),
			)
		)
	return out, lengths


def convert_path_waypoints_mm_deg_to_m_rad(
	segments_mm_deg: List[List[Tuple[float, float, float, float, float, float]]],
) -> List[List[Pose6]]:
	"""PathComponent tuples (mm, deg) → planner tuples (m, rad)."""
	out: List[List[Pose6]] = []
	for seg in segments_mm_deg:
		converted: List[Pose6] = []
		for x, y, z, rx, ry, rz in seg:
			converted.append(
				(
					float(x) * 0.001,
					float(y) * 0.001,
					float(z) * 0.001,
					math.radians(float(rx)),
					math.radians(float(ry)),
					math.radians(float(rz)),
				)
			)
		out.append(converted)
	return out

"""Continuous seeded IK along densified Cartesian path segments."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult
from MotionStudio.core.robot.ik.ik_frames import project_to_se3
from MotionStudio.core.robot.ik._fk_verify import joint_wrap_distance
from MotionStudio.core.robot.planning.path_sampling import densify_segment, pose6_to_matrix
from MotionStudio.core.robot.planning.planner_backend import PlanRequest
from MotionStudio.core.robot.planning.trajectory import JointSample, assign_times_cartesian_speed


def _q_from_joint_map(joint_names: List[str], values: Dict[str, float]) -> np.ndarray:
	return np.array([float(values.get(n, 0.0)) for n in joint_names], dtype=np.float64)


def _goal_ee_from_tcp_pose(T_tcp_base: np.ndarray, T_ee_tcp: np.ndarray) -> np.ndarray:
	"""Aim tool_link so TCP reaches T_tcp_base: T_ee = T_tcp @ inv(T_ee_tcp)."""
	T_ee_tcp = project_to_se3(T_ee_tcp)
	return project_to_se3(T_tcp_base @ np.linalg.inv(T_ee_tcp))


def _ik_once(
	ik: AnalyticIKBackend,
	request_template: PlanRequest,
	T_goal: np.ndarray,
	q_seed: np.ndarray,
	*,
	enumerate_all: bool,
) -> IKSolveResult:
	req = IKSolveRequest(
		robot_entity_id=request_template.robot_entity_id,
		urdf_path=request_template.urdf_path,
		joint_names=list(request_template.joint_names),
		q_seed=np.asarray(q_seed, dtype=np.float64),
		T_goal_base=project_to_se3(T_goal),
		ee_link=request_template.tool_link,
		position_tolerance_m=float(request_template.position_tolerance_m),
		orientation_tolerance_rad=float(request_template.orientation_tolerance_rad),
		root_link=request_template.root_link,
		joints=[dict(j) for j in request_template.joints],
		analytic_solver_path=request_template.analytic_solver_path,
		enumerate_all_solutions=enumerate_all,
	)
	return ik.solve(req)


def _edge_valid(collision_world, q_prev: np.ndarray, q_next: np.ndarray) -> bool:
	"""True when the C-space edge from ``q_prev`` to ``q_next`` is collision-free."""
	if collision_world is None:
		return True
	if hasattr(collision_world, "first_invalid_on_segment"):
		ok, _fail_q, _detail = collision_world.first_invalid_on_segment(
			q_prev, q_next, resolution_rad=0.05
		)
		return bool(ok)
	if hasattr(collision_world, "is_segment_valid"):
		return bool(collision_world.is_segment_valid(q_prev, q_next, resolution_rad=0.05))
	# Point-only fallback when the oracle has no edge check.
	return bool(collision_world.is_state_valid(q_next))


def _candidate_point_ok(collision_world, q: np.ndarray) -> bool:
	if collision_world is None:
		return True
	return bool(collision_world.is_state_valid(q))


def _candidate_point_and_edge_ok(
	collision_world,
	q_prev: np.ndarray,
	q: np.ndarray,
) -> bool:
	if not _candidate_point_ok(collision_world, q):
		return False
	return _edge_valid(collision_world, q_prev, q)


def _pick_edge_collision_free(
	candidates: List[Dict[str, float]],
	seed_map: Dict[str, float],
	joint_names: List[str],
	collision_world,
	prev_q: np.ndarray,
	*,
	require_edge: bool = True,
) -> Tuple[Optional[Dict[str, float]], Optional[np.ndarray], int]:
	"""Pick nearest-to-seed candidate that passes collision filters.

	When ``require_edge`` is True, the candidate must be point-valid and the
	C-space edge from ``prev_q`` must be clear. When False, only the point is
	checked (inter-segment entry — RRT owns the connection).

	Returns ``(picked_dict_or_None, blocked_q, n_candidates)``.
	``blocked_q`` is the nearest-to-seed kinematic candidate that failed collision
	(for viewport pose-at-failure), or None when no candidates existed.
	"""
	if not candidates:
		return None, None, 0
	ordered = sorted(
		candidates,
		key=lambda c: joint_wrap_distance(c, seed_map, joint_names),
	)
	blocked_q: Optional[np.ndarray] = None
	for cand in ordered:
		q = _q_from_joint_map(joint_names, cand)
		ok = (
			_candidate_point_and_edge_ok(collision_world, prev_q, q)
			if require_edge
			else _candidate_point_ok(collision_world, q)
		)
		if ok:
			return cand, blocked_q, len(ordered)
		if blocked_q is None:
			blocked_q = q.copy()
	return None, blocked_q, len(ordered)


def solve_pose_continuous(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	T_tcp_base: np.ndarray,
	q_seed: np.ndarray,
	*,
	require_edge_from_seed: bool = True,
) -> Tuple[Optional[np.ndarray], str, Optional[np.ndarray]]:
	"""Solve IK for one TCP pose with seed continuity + collision filtering.

	When ``require_edge_from_seed`` is True (intra-segment continuity), candidates
	must also have a collision-free C-space edge from ``q_seed``. When False
	(inter-segment entry), only the goal config must be collision-free — the
	transition planner (RRT) connects from the previous segment end.

	Returns ``(q_or_None, message, blocked_q)``. ``blocked_q`` is set when kinematic
	candidates existed but all were blocked by collision (for failure posing).
	"""
	T_goal = _goal_ee_from_tcp_pose(T_tcp_base, request.T_ee_tcp)
	result = _ik_once(ik, request, T_goal, q_seed, enumerate_all=False)
	joint_names = list(request.joint_names)
	seed_map = {n: float(q_seed[i]) if i < len(q_seed) else 0.0 for i, n in enumerate(joint_names)}
	cw = request.collision_world
	prev_q = np.asarray(q_seed, dtype=np.float64).reshape(-1)

	def _accept(q: np.ndarray) -> bool:
		if require_edge_from_seed:
			return _candidate_point_and_edge_ok(cw, prev_q, q)
		return _candidate_point_ok(cw, q)

	if result.success and result.joint_values:
		q = _q_from_joint_map(joint_names, result.joint_values)
		if _accept(q):
			return q, "", None

	# Retry with full branch enumeration — try alternate elbow/wrist/shoulder branches.
	result2 = _ik_once(ik, request, T_goal, q_seed, enumerate_all=True)
	cands = list(result2.all_solutions) if result2.all_solutions else []
	if result2.success and result2.joint_values and result2.joint_values not in cands:
		cands.insert(0, result2.joint_values)
	# Include the fast-path candidate if it was not already in the enumerate set.
	if result.success and result.joint_values and result.joint_values not in cands:
		cands.insert(0, result.joint_values)

	picked, blocked_q, n_cands = _pick_edge_collision_free(
		cands,
		seed_map,
		joint_names,
		cw,
		prev_q,
		require_edge=require_edge_from_seed,
	)
	if picked is not None:
		return _q_from_joint_map(joint_names, picked), "", None

	if n_cands == 0:
		msg = result2.message or result.message or "no kinematic solution reaches this pose"
		return None, msg, None

	pair_extra = ""
	if cw is not None and blocked_q is not None and hasattr(cw, "find_colliding_pair"):
		try:
			pair = cw.find_colliding_pair(blocked_q)
			if pair is not None:
				pair_extra = f" pair={pair}"
		except Exception:
			pass
	if require_edge_from_seed:
		detail = (
			f"{n_cands} branch(es) found, all blocked by collision when connecting "
			f"from the previous sample{pair_extra}"
		)
	else:
		detail = (
			f"{n_cands} branch(es) found, all blocked by collision at this pose"
			f"{pair_extra}"
		)
	return None, detail, blocked_q


def trace_segment_ik(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	segment_waypoints: List[tuple],
	segment_index: int,
	q_seed: np.ndarray,
	t0: float,
) -> Tuple[Optional[List[JointSample]], np.ndarray, str]:
	"""Densify one segment, run continuous IK, return timed process samples."""
	if not segment_waypoints:
		return [], np.asarray(q_seed, dtype=np.float64), ""

	poses, cart_lengths = densify_segment(
		segment_waypoints, request.process_sample_spacing_m
	)
	q_list: List[np.ndarray] = []
	lengths_used: List[float] = []
	q_cur = np.asarray(q_seed, dtype=np.float64)

	for i, pose in enumerate(poses):
		T_tcp = pose6_to_matrix(pose)
		# Inter-segment entry (sample 0 of segment > 0): point-only validity.
		# RRT owns the C-space connection from the previous segment end.
		# Intra-segment samples (and first-segment entry from robot seed) still
		# require a collision-free straight edge from the previous config.
		require_edge = not (i == 0 and segment_index > 0)
		q_next, err, blocked_q = solve_pose_continuous(
			ik,
			request,
			T_tcp,
			q_cur,
			require_edge_from_seed=require_edge,
		)
		if q_next is None:
			pose_q = blocked_q if blocked_q is not None else q_cur
			return None, pose_q, (
				f"Process IK failed on segment {segment_index} sample {i}: {err}"
			)

		if q_list:
			# Length between densified poses (edge already validated by solver).
			if i - 1 < len(cart_lengths):
				lengths_used.append(cart_lengths[i - 1])
			else:
				lengths_used.append(
					float(np.linalg.norm(np.array(pose[:3]) - np.array(poses[i - 1][:3])))
				)
		elif i == 0 and len(poses) >= 1:
			# Entry from seed into first sample — no cart length between densified
			# poses yet; length accounting starts at the next sample.
			pass

		q_list.append(q_next)
		q_cur = q_next

	mult = 1.0
	if segment_index < len(request.segment_speed_multipliers):
		mult = max(1e-6, float(request.segment_speed_multipliers[segment_index]))
	speed = max(1e-6, float(request.path_speed_m_s) * mult)
	samples, _t_end = assign_times_cartesian_speed(
		q_list,
		lengths_used,
		kind="process",
		segment_index=segment_index,
		t0=t0,
		linear_speed_m_s=speed,
	)
	return samples, q_cur, ""

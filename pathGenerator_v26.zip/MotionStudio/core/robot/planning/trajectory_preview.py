"""FK helpers to visualize planned joint trajectories as TCP polylines."""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import numpy as np
from PyQt6.QtGui import QVector3D

from MotionStudio.core.robot.frame_math import METER_TO_MM
from MotionStudio.core.robot.ik._fk_verify import forward_kinematics
from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest
from MotionStudio.core.robot.ik.ik_frames import project_to_se3
from MotionStudio.core.robot.planning.trajectory import JointTrajectory

TcpPathMm = List[QVector3D]


def trajectory_tcp_path_base_mm(
	trajectory: JointTrajectory,
	*,
	root_link: str,
	tool_link: str,
	joints: Sequence[dict],
	T_ee_tcp: Optional[np.ndarray] = None,
) -> TcpPathMm:
	"""Evaluate TCP positions (robot base frame, millimetres) along a joint trajectory.

	Uses analytic chain FK (same units as scene transforms: translation mm).
	``T_ee_tcp`` is the rigid tool_link→TCP offset in metres (identity if unset).
	"""
	if trajectory is None or trajectory.is_empty():
		return []
	joint_names = list(trajectory.joint_names)
	if not joint_names or not tool_link or not root_link:
		return []

	T_off = project_to_se3(
		T_ee_tcp if T_ee_tcp is not None else np.eye(4, dtype=np.float64)
	)
	req = IKSolveRequest(
		robot_entity_id="",
		urdf_path="",
		joint_names=joint_names,
		q_seed=np.zeros(len(joint_names), dtype=np.float64),
		T_goal_base=np.eye(4, dtype=np.float64),
		ee_link=str(tool_link),
		root_link=str(root_link),
		joints=[dict(j) for j in joints],
	)

	out: TcpPathMm = []
	prev: Optional[Tuple[float, float, float]] = None
	for sample in trajectory.samples:
		q = np.asarray(sample.q, dtype=np.float64).reshape(-1)
		q_map = {
			name: float(q[i]) if i < q.size else 0.0
			for i, name in enumerate(joint_names)
		}
		T_ee = forward_kinematics(req, q_map)
		if T_ee is None:
			continue
		T_tcp = project_to_se3(T_ee) @ T_off
		xyz_mm = (
			float(T_tcp[0, 3]) * METER_TO_MM,
			float(T_tcp[1, 3]) * METER_TO_MM,
			float(T_tcp[2, 3]) * METER_TO_MM,
		)
		if prev is not None and (
			abs(xyz_mm[0] - prev[0]) < 1e-6
			and abs(xyz_mm[1] - prev[1]) < 1e-6
			and abs(xyz_mm[2] - prev[2]) < 1e-6
		):
			continue
		out.append(QVector3D(xyz_mm[0], xyz_mm[1], xyz_mm[2]))
		prev = xyz_mm
	return out

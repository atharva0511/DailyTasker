"""imove motion-planner backend (numpy RRT-Connect transitions)."""

from __future__ import annotations

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.planning.imove.rrt_connect import plan_joint_transition
from MotionStudio.core.robot.planning.plan_pipeline import plan_segments_with_transitions
from MotionStudio.core.robot.planning.planner_backend import PlanRequest, PlanResult


class ImoveMotionPlannerBackend:
	"""imove planner: continuous IK on segments, numpy RRT-Connect between them.

	Always available (numpy only). Transitions use multi-attempt RRT-Connect
	with line-biased sampling and iterative shortcutting within
	``planning_time_limit_s``. Process IK retries alternate analytic branches
	when an intra-segment joint-space edge is blocked; inter-segment gaps are
	left to RRT (point-valid segment entry only). Future imove modules (PRM,
	etc.) can plug in as alternate transition functions without a new top-level
	backend.
	"""

	def is_available(self) -> bool:
		return True

	def invalidate_cache(self, key: str) -> None:
		_ = key

	def plan(self, request: PlanRequest) -> PlanResult:
		ik = AnalyticIKBackend()
		if not ik.is_available():
			return PlanResult(False, "ssik is not available for analytic IK.")

		return plan_segments_with_transitions(
			request,
			backend_name="imove",
			transition_fn=plan_joint_transition,
			ik=ik,
		)

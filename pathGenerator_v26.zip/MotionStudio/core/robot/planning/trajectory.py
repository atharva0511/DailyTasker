"""Joint-space trajectory types for motion planning.

Interpolation (densify, timing, ``sample_at``) uses the **same wrap-aware
short-arc metric** as imove RRT validity checks for continuous / full-range
joints, so playback and the blue TCP overlay match what the planner validated.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Sequence, Tuple

import numpy as np

SampleKind = Literal["process", "transition"]


def wrap_pi(x: float) -> float:
	"""Wrap angle to (-pi, pi]."""
	return float((x + math.pi) % (2.0 * math.pi) - math.pi)


def wrap_mask_from_joints(
	joint_names: Sequence[str],
	joints: Sequence[Dict[str, Any]],
) -> np.ndarray:
	"""True for continuous joints or revolute with near-full ±2π span."""
	by_name = {str(j.get("name", "")): j for j in joints}
	mask = np.zeros(len(joint_names), dtype=bool)
	for i, name in enumerate(joint_names):
		j = by_name.get(str(name), {})
		jtype = str(j.get("type", "revolute")).lower()
		if jtype == "continuous":
			mask[i] = True
			continue
		limits = j.get("limits") or {}
		lo = float(limits.get("lower", -math.pi)) if limits else -math.pi
		hi = float(limits.get("upper", math.pi)) if limits else math.pi
		if float(hi - lo) >= (2.0 * math.pi - 1e-6):
			mask[i] = True
	return mask


def joint_delta(
	q_from: np.ndarray,
	q_to: np.ndarray,
	wrap_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
	"""Joint-space delta; wrap marked axes to the short arc in (-pi, pi]."""
	d = np.asarray(q_to, dtype=np.float64).reshape(-1) - np.asarray(
		q_from, dtype=np.float64
	).reshape(-1)
	if wrap_mask is None:
		return d
	out = d.copy()
	for i, wrap in enumerate(wrap_mask):
		if wrap and i < out.size:
			out[i] = wrap_pi(float(out[i]))
	return out


def joint_distance(
	q_from: np.ndarray,
	q_to: np.ndarray,
	wrap_mask: Optional[np.ndarray] = None,
) -> float:
	"""L2 length of the wrap-aware joint delta."""
	return float(np.linalg.norm(joint_delta(q_from, q_to, wrap_mask)))


def lerp_joints(
	q_a: np.ndarray,
	q_b: np.ndarray,
	alpha: float,
	wrap_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
	"""Interpolate along the same short-arc chord the planner validates."""
	qa = np.asarray(q_a, dtype=np.float64).reshape(-1)
	delta = joint_delta(qa, q_b, wrap_mask)
	q = qa + float(alpha) * delta
	if wrap_mask is not None:
		for i, wrap in enumerate(wrap_mask):
			if wrap and i < q.size:
				q[i] = wrap_pi(float(q[i]))
	return q


def _mask_from_meta(meta: Dict[str, Any], dof: int) -> Optional[np.ndarray]:
	raw = meta.get("wrap_mask") if meta else None
	if raw is None:
		return None
	mask = np.asarray(raw, dtype=bool).reshape(-1)
	if mask.size != dof:
		return None
	return mask


@dataclass
class JointSample:
	"""One timed configuration along a planned trajectory."""

	t: float
	q: List[float]
	kind: SampleKind = "process"
	segment_index: int = 0

	def to_dict(self) -> Dict[str, Any]:
		return {
			"t": float(self.t),
			"q": [float(v) for v in self.q],
			"kind": str(self.kind),
			"segment_index": int(self.segment_index),
		}

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "JointSample":
		kind = str(data.get("kind", "process") or "process")
		if kind not in ("process", "transition"):
			kind = "process"
		q_raw = data.get("q", []) or []
		return cls(
			t=float(data.get("t", 0.0)),
			q=[float(v) for v in q_raw],
			kind=kind,  # type: ignore[arg-type]
			segment_index=int(data.get("segment_index", 0)),
		)


@dataclass
class JointTrajectory:
	"""Timed joint-space path produced by a motion planner."""

	joint_names: List[str] = field(default_factory=list)
	samples: List[JointSample] = field(default_factory=list)
	meta: Dict[str, Any] = field(default_factory=dict)

	@property
	def duration(self) -> float:
		if not self.samples:
			return 0.0
		return float(self.samples[-1].t)

	def is_empty(self) -> bool:
		return not self.samples or not self.joint_names

	def wrap_mask(self) -> Optional[np.ndarray]:
		"""Per-joint wrap flags stored at plan time (None ⇒ no wrapping)."""
		return _mask_from_meta(self.meta, len(self.joint_names))

	def to_dict(self) -> Dict[str, Any]:
		return {
			"joint_names": list(self.joint_names),
			"samples": [s.to_dict() for s in self.samples],
			"meta": dict(self.meta),
		}

	@classmethod
	def from_dict(cls, data: Optional[Dict[str, Any]]) -> "JointTrajectory":
		if not data:
			return cls()
		samples_raw = data.get("samples", []) or []
		return cls(
			joint_names=[str(n) for n in (data.get("joint_names") or [])],
			samples=[JointSample.from_dict(s) for s in samples_raw if isinstance(s, dict)],
			meta=dict(data.get("meta") or {}),
		)

	def sample_at(self, t: float) -> Optional[Dict[str, float]]:
		"""Interpolate joint values at time ``t`` (clamped to [0, duration]).

		Uses wrap-aware short-arc lerp when ``meta['wrap_mask']`` is set — same
		metric as planning densify / imove RRT.
		"""
		if self.is_empty():
			return None
		if len(self.samples) == 1:
			return {n: float(v) for n, v in zip(self.joint_names, self.samples[0].q)}
		t = float(max(0.0, min(t, self.duration)))
		times = [s.t for s in self.samples]
		idx = int(np.searchsorted(times, t, side="right") - 1)
		idx = max(0, min(idx, len(self.samples) - 2))
		a = self.samples[idx]
		b = self.samples[idx + 1]
		dt = b.t - a.t
		alpha = 0.0 if dt < 1e-12 else (t - a.t) / dt
		qa = np.asarray(a.q, dtype=np.float64)
		qb = np.asarray(b.q, dtype=np.float64)
		q = lerp_joints(qa, qb, alpha, self.wrap_mask())
		return {n: float(v) for n, v in zip(self.joint_names, q.tolist())}


def stitch_segments(
	chunks: List[List[JointSample]],
	*,
	joint_names: List[str],
	meta: Optional[Dict[str, Any]] = None,
) -> JointTrajectory:
	"""Concatenate sample chunks that already have absolute times."""
	samples: List[JointSample] = []
	for chunk in chunks:
		samples.extend(chunk)
	return JointTrajectory(joint_names=list(joint_names), samples=samples, meta=dict(meta or {}))


def densify_joint_polyline(
	q_list: List[np.ndarray],
	*,
	max_step: float = 0.05,
	wrap_mask: Optional[np.ndarray] = None,
) -> List[np.ndarray]:
	"""Insert intermediates so consecutive waypoints are ≤ ``max_step`` apart (L2).

	When ``wrap_mask`` is set, steps follow the short arc (matching planner
	validity), and continuous joints are wrapped to (-pi, pi] on each sample.
	"""
	if not q_list:
		return []
	max_step = max(1e-6, float(max_step))
	out: List[np.ndarray] = [np.asarray(q_list[0], dtype=np.float64).reshape(-1).copy()]
	if wrap_mask is not None:
		for i, wrap in enumerate(wrap_mask):
			if wrap and i < out[0].size:
				out[0][i] = wrap_pi(float(out[0][i]))
	for raw in q_list[1:]:
		b = np.asarray(raw, dtype=np.float64).reshape(-1)
		a = out[-1]
		delta = joint_delta(a, b, wrap_mask)
		dist = float(np.linalg.norm(delta))
		if dist < 1e-12:
			qb = b.copy()
			if wrap_mask is not None:
				for i, wrap in enumerate(wrap_mask):
					if wrap and i < qb.size:
						qb[i] = wrap_pi(float(qb[i]))
			out.append(qb)
			continue
		n = max(1, int(np.ceil(dist / max_step)))
		for k in range(1, n + 1):
			out.append(lerp_joints(a, b, float(k) / float(n), wrap_mask))
	return out


def assign_times_constant_speed(
	q_list: List[np.ndarray],
	*,
	kind: SampleKind,
	segment_index: int,
	t0: float,
	speed: float,
	min_dt: float = 1e-4,
	wrap_mask: Optional[np.ndarray] = None,
) -> tuple[List[JointSample], float]:
	"""Assign times along a joint polyline using wrap-aware L2 C-space speed."""
	speed = max(1e-6, float(speed))
	samples: List[JointSample] = []
	t = float(t0)
	if not q_list:
		return samples, t
	prev = np.asarray(q_list[0], dtype=np.float64).reshape(-1)
	samples.append(
		JointSample(t=t, q=prev.tolist(), kind=kind, segment_index=segment_index)
	)
	for raw in q_list[1:]:
		q = np.asarray(raw, dtype=np.float64).reshape(-1)
		dist = joint_distance(prev, q, wrap_mask)
		dt = max(min_dt, dist / speed)
		t += dt
		samples.append(
			JointSample(t=t, q=q.tolist(), kind=kind, segment_index=segment_index)
		)
		prev = q
	return samples, t


def assign_times_cartesian_speed(
	q_list: List[np.ndarray],
	cart_lengths_m: List[float],
	*,
	kind: SampleKind,
	segment_index: int,
	t0: float,
	linear_speed_m_s: float,
	min_dt: float = 1e-4,
) -> tuple[List[JointSample], float]:
	"""Assign times from Cartesian path lengths between successive samples."""
	speed = max(1e-6, float(linear_speed_m_s))
	samples: List[JointSample] = []
	t = float(t0)
	if not q_list:
		return samples, t
	samples.append(
		JointSample(
			t=t,
			q=np.asarray(q_list[0], dtype=np.float64).reshape(-1).tolist(),
			kind=kind,
			segment_index=segment_index,
		)
	)
	for i in range(1, len(q_list)):
		length = float(cart_lengths_m[i - 1]) if i - 1 < len(cart_lengths_m) else 0.0
		dt = max(min_dt, length / speed)
		t += dt
		samples.append(
			JointSample(
				t=t,
				q=np.asarray(q_list[i], dtype=np.float64).reshape(-1).tolist(),
				kind=kind,
				segment_index=segment_index,
			)
		)
	return samples, t

"""Shared segment-IK + transition stitch pipeline for motion planners."""

from __future__ import annotations

from typing import Callable, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.planning.planner_backend import PlanRequest, PlanResult
from MotionStudio.core.robot.planning.segment_ik import trace_segment_ik
from MotionStudio.core.robot.planning.trajectory import (
	JointSample,
	JointTrajectory,
	assign_times_constant_speed,
	densify_joint_polyline,
	joint_distance,
	wrap_mask_from_joints,
)

TransitionFn = Callable[..., Tuple[Optional[List[np.ndarray]], str]]


def validate_plan_request(request: PlanRequest) -> Optional[str]:
	"""Return an error message if the request is not plannable, else None."""
	if not request.waypoint_segments_m_rad:
		return "No path segments to plan."
	if not request.joint_names:
		return "Robot has no actuated joints."
	if not request.analytic_solver_path:
		return "Analytic solver path is required for process-segment IK."
	return None


def plan_segments_with_transitions(
	request: PlanRequest,
	*,
	backend_name: str,
	transition_fn: TransitionFn,
	ik: Optional[AnalyticIKBackend] = None,
) -> PlanResult:
	"""Dense continuous IK along segments; ``transition_fn`` connects them.

	``transition_fn`` signature matches OMPL/imove helpers::

	    transition_fn(q_from, q_to, collision_world, *, time_limit_s, simplify)
	        -> (path_or_None, detail_message)
	"""
	err = validate_plan_request(request)
	if err:
		return PlanResult(False, err)

	if ik is None:
		ik = AnalyticIKBackend()
	if not ik.is_available():
		return PlanResult(False, "ssik is not available for analytic IK.")

	cw = request.collision_world
	collision_note = ""
	if cw is None:
		collision_note = " (WARNING: no collision world — planning ignores obstacles)"
	elif not cw.collision_checking_active():
		summary = cw.collision_summary() if hasattr(cw, "collision_summary") else ""
		live = bool(getattr(cw, "uses_live_viewport", False))
		if live:
			# Diagnostics-only oracle; production uses PlanningCollisionWorld.
			collision_note = f" (live viewport: {summary})"
		else:
			try:
				import fcl  # noqa: F401
			except Exception:
				return PlanResult(
					False,
					"Collision checking unavailable: python-fcl is not installed. "
					"Install python-fcl (see requirements.txt) so imove/OMPL can avoid obstacles.",
				)
			if len(getattr(cw, "robot_bodies", []) or []) == 0:
				return PlanResult(
					False,
					"Collision checking inactive: no articulated robot colliders were snapshotted "
					"(URDF link Colliders and/or colliders parented under robot links). "
					f"({summary})",
				)
			collision_note = f" (collision snapshot: {summary})"
	else:
		collision_note = f" (collision: {cw.collision_summary()})"

	q_seed = np.asarray(request.q_seed, dtype=np.float64).reshape(-1)
	per_seg: List[List[JointSample]] = []

	for seg_idx, waypoints in enumerate(request.waypoint_segments_m_rad):
		if not waypoints:
			per_seg.append([])
			continue
		samples, q_end, seg_err = trace_segment_ik(
			ik, request, list(waypoints), seg_idx, q_seed, t0=0.0
		)
		if samples is None:
			return PlanResult(
				False,
				seg_err,
				failure_q=np.asarray(q_end, dtype=np.float64),
				collision_world=cw,
			)
		per_seg.append(samples)
		q_seed = q_end

	out: List[JointSample] = []
	t_cursor = 0.0
	joint_names = list(request.joint_names)
	wrap_mask = wrap_mask_from_joints(joint_names, request.joints)
	trans_speed = max(1e-3, float(request.transition_joint_speed_rad_s))
	name = (backend_name or "planner").strip().lower() or "planner"

	active_indices = [i for i, s in enumerate(per_seg) if s]
	for ai, seg_idx in enumerate(active_indices):
		samples = per_seg[seg_idx]
		if samples:
			t0_local = samples[0].t
			shifted: List[JointSample] = []
			for s in samples:
				shifted.append(
					JointSample(
						t=t_cursor + (s.t - t0_local),
						q=list(s.q),
						kind=s.kind,
						segment_index=s.segment_index,
					)
				)
			if out and shifted and np.allclose(out[-1].q, shifted[0].q, atol=1e-9):
				shifted = shifted[1:]
			out.extend(shifted)
			if out:
				t_cursor = out[-1].t

		if ai + 1 >= len(active_indices):
			continue
		next_idx = active_indices[ai + 1]
		next_samples = per_seg[next_idx]
		if not next_samples or not out:
			continue
		q_from = np.asarray(out[-1].q, dtype=np.float64)
		q_to = np.asarray(next_samples[0].q, dtype=np.float64)
		if joint_distance(q_from, q_to, wrap_mask) < 1e-6:
			continue

		path_q = transition_fn(
			q_from,
			q_to,
			request.collision_world,
			time_limit_s=float(request.planning_time_limit_s),
			simplify=bool(request.simplify_path),
		)
		detail = ""
		if isinstance(path_q, tuple):
			path_q, detail = path_q
		if path_q is None:
			extra = f" ({detail})" if detail else ""
			# Prefer the transition goal when it is the invalid endpoint; otherwise start.
			detail_l = (detail or "").lower()
			failure_q = q_to if "goal" in detail_l else q_from
			return PlanResult(
				False,
				f"{name} failed to connect segment {seg_idx} → {next_idx}.{extra}",
				failure_q=np.asarray(failure_q, dtype=np.float64),
				collision_world=cw,
			)
		# Densify along the same wrap-aware short arc the planner validated.
		interior = path_q[1:-1] if len(path_q) > 2 else []
		# Match imove edge resolution: never space playback samples coarser
		# than planning checks (old max(0.05, jump/20) grew coarse on long jumps).
		edge_res = 0.05
		chain = densify_joint_polyline(
			[q_from] + interior + [q_to],
			max_step=edge_res,
			wrap_mask=wrap_mask,
		)
		# Re-check densified waypoints — reject tunneling that coarse RRT/shortcut
		# samples might have missed (defense in depth; same oracle as planning).
		if request.collision_world is not None:
			cw_check = request.collision_world
			for qi in chain:
				if not cw_check.is_state_valid(qi):
					return PlanResult(
						False,
						(
							f"{name} transition segment {seg_idx} → {next_idx} "
							f"collides after densify (edge resolution too coarse "
							f"or invalid shortcut)."
						),
						failure_q=np.asarray(qi, dtype=np.float64),
						collision_world=cw,
					)
		trans_samples, t_trans_end = assign_times_constant_speed(
			chain,
			kind="transition",
			segment_index=-1,
			t0=t_cursor,
			speed=trans_speed,
			wrap_mask=wrap_mask,
		)
		# Drop duplicates of the adjacent process endpoints, but always keep the
		# full transition duration so the next segment does not start at the same t.
		if len(trans_samples) >= 2:
			trans_samples = trans_samples[1:-1]
		elif len(trans_samples) == 1:
			trans_samples = []
		out.extend(trans_samples)
		t_cursor = float(t_trans_end)

	if not out:
		return PlanResult(False, "Planning produced an empty trajectory.")

	traj = JointTrajectory(
		joint_names=joint_names,
		samples=out,
		meta={
			"backend": name,
			"segments": len(request.waypoint_segments_m_rad),
			"simplify_path": bool(request.simplify_path),
			# Persist wrap flags so Play Mode sample_at matches planner arcs.
			"wrap_mask": [bool(v) for v in wrap_mask.tolist()],
		},
	)
	return PlanResult(True, f"planned by {name}{collision_note}", traj)

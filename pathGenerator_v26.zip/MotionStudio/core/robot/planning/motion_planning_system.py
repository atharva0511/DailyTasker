"""Scene-owned motion planning service (async worker + request builder)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional

import numpy as np
from PyQt6.QtCore import QMutex, QMutexLocker, QThread, QWaitCondition, pyqtSignal
from PyQt6.QtWidgets import QMessageBox

from MotionStudio.core.robot.planning.backend_runtime import (
	MotionPlannerError,
	plan_with_backend,
)
from MotionStudio.core.robot.planning.collision_world import (
	PlanningCollisionWorld,
	build_planning_collision_world,
)
from MotionStudio.core.robot.planning.path_sampling import convert_path_waypoints_mm_deg_to_m_rad
from MotionStudio.core.robot.planning.planner_backend import (
	MotionPlannerBackend,
	PlanRequest,
	PlanResult,
)
from MotionStudio.core.robot.ik.ik_frames import project_to_se3, relative_offset_m

if TYPE_CHECKING:
	from MotionStudio.core.components.motion_planner_component import MotionPlannerComponent
	from MotionStudio.core.scene.scene import Scene
	from MotionStudio.ui.loading_controller import LoadingController


class _PlannerWorker(QThread):
	"""Background planning loop — latest-wins per job entity."""

	planned = pyqtSignal(str, object)  # job_entity_id, PlanResult

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		self._pending: Dict[str, tuple[str, PlanRequest]] = {}
		self._stop = False
		self._backends: Dict[str, MotionPlannerBackend] = {}

	def submit(self, backend_name: str, request: PlanRequest) -> None:
		with QMutexLocker(self._mutex):
			self._pending[request.job_entity_id] = (backend_name, request)
			self._wait.wakeOne()

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._wait.wakeOne()
		self.wait(5000)

	def run(self) -> None:
		while True:
			with QMutexLocker(self._mutex):
				while not self._pending and not self._stop:
					self._wait.wait(self._mutex)
				if self._stop:
					return
				_job_id, (backend_name, request) = self._pending.popitem()

			try:
				result = plan_with_backend(backend_name, request, self._backends)
			except MotionPlannerError as exc:
				result = PlanResult(False, str(exc))
			except Exception as exc:
				result = PlanResult(False, f"Planning failed: {exc}")
			if getattr(result, "collision_world", None) is None:
				result.collision_world = request.collision_world
			self.planned.emit(request.job_entity_id, result)


class MotionPlanningSystem:
	"""Scene service that runs motion planning off the main thread.

	Collision validity uses an offline :class:`PlanningCollisionWorld` snapshot
	built on the main thread before the worker starts. Sampling never poses the
	robot in the viewport or runs Qt/VTK — only FCL queries against snapshotted
	geometry, the same CollisionMatrix pairs, and FK-updated articulated poses.
	"""

	def __init__(self, scene: "Scene") -> None:
		self._scene = scene
		self._worker = _PlannerWorker()
		self._worker.planned.connect(self._on_planned)
		self._worker.start()
		self._busy_jobs: Dict[str, bool] = {}
		self._loading: Optional["LoadingController"] = None
		self._loading_active: bool = False

	def set_loading_controller(self, loading: Optional["LoadingController"]) -> None:
		"""Attach the editor loading overlay (same UI as Open Project / Import URDF)."""
		self._loading = loading

	def shutdown(self) -> None:
		self._end_loading_overlay()
		self._worker.stop()

	def is_busy(self, job_entity_id: str) -> bool:
		return bool(self._busy_jobs.get(job_entity_id, False))

	def _begin_loading_overlay(self, message: str) -> bool:
		loading = self._loading
		if loading is None:
			return True
		if not loading.begin_external(message):
			return False
		self._loading_active = True
		return True

	def _set_loading_message(self, message: str) -> None:
		if self._loading_active and self._loading is not None:
			self._loading.set_message(message)

	def _end_loading_overlay(self) -> None:
		if not self._loading_active:
			return
		self._loading_active = False
		if self._loading is not None:
			self._loading.end_external()

	def submit_plan(self, planner: "MotionPlannerComponent") -> None:
		"""Build a request on the main thread and enqueue planning."""
		from MotionStudio.core.scene.play_mode import PlayModeManager

		pm = getattr(self._scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			QMessageBox.warning(
				None,
				"Plan Motion",
				"Cannot plan while Play Mode is active. Stop Play Mode first.",
			)
			return

		if not self._begin_loading_overlay("Planning motion…"):
			QMessageBox.warning(
				None,
				"Plan Motion",
				"Another load operation is already in progress.",
			)
			return

		try:
			request = self.build_request(planner)
		except Exception as exc:
			self._end_loading_overlay()
			QMessageBox.critical(None, "Plan Motion", f"Failed to start planning:\n{exc}")
			return

		if request is None:
			self._end_loading_overlay()
			return

		job_id = request.job_entity_id
		self._busy_jobs[job_id] = True
		cw = request.collision_world
		summary = ""
		if isinstance(cw, PlanningCollisionWorld):
			summary = cw.collision_summary()
		planner.status = f"Planning…{(' (' + summary + ')') if summary else ''}"
		overlay_msg = "Planning motion…"
		if summary:
			overlay_msg = f"Planning motion…\n{summary}"
		self._set_loading_message(overlay_msg)

		backend = str(getattr(planner, "backend", "ompl") or "ompl")
		self._worker.submit(backend, request)

	def build_request(self, planner: "MotionPlannerComponent") -> Optional[PlanRequest]:
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent
		from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read

		job_ent = planner.entity
		if job_ent is None:
			QMessageBox.warning(None, "Plan Motion", "MotionPlanner is not attached to an entity.")
			return None

		path = planner._resolved_path()
		if path is None:
			QMessageBox.warning(
				None,
				"Plan Motion",
				"Select a PathGeneration component (or add PathGeneration on this entity).",
			)
			return None

		rd = planner._resolved_robot()
		if rd is None:
			QMessageBox.warning(
				None,
				"Plan Motion",
				"Select a Robot (RobotDescription), or set Robot on the PathGeneration Export group.",
			)
			return None

		robot_ent = rd.entity
		if robot_ent is None:
			return None

		try:
			segments_mm_deg = path.get_waypoints_in_robot_frame(rd)
		except Exception as exc:
			QMessageBox.critical(None, "Plan Motion", f"Failed to read path waypoints:\n{exc}")
			return None

		segments = convert_path_waypoints_mm_deg_to_m_rad(segments_mm_deg)
		if not any(segments):
			QMessageBox.warning(None, "Plan Motion", "Path has no waypoints to plan.")
			return None

		project_root = self._scene.project_root
		abs_urdf = resolve_mesh_path_for_read(project_root, rd.urdf_path)
		if not abs_urdf:
			QMessageBox.warning(None, "Plan Motion", "Robot URDF path could not be resolved.")
			return None

		analytic_path = str(getattr(rd, "analytic_solver_path", "") or "").strip()
		ik = robot_ent.get_component(RobotIKComponent)
		if ik is not None:
			override = str(getattr(ik, "analytic_solver_path", "") or "").strip()
			if override:
				analytic_path = override
		abs_analytic = resolve_mesh_path_for_read(project_root, analytic_path) if analytic_path else ""

		joint_names = list(rd.actuated_joint_names)
		q_seed = np.array(
			[float(rd.joint_positions.get(n, 0.0)) for n in joint_names],
			dtype=np.float64,
		)

		T_ee_tcp = np.eye(4, dtype=np.float64)
		if ik is not None:
			tcp_ref = getattr(ik, "tcp", None)
			tcp_ent = None
			if tcp_ref is not None:
				if hasattr(tcp_ref, "entity"):
					tcp_ent = tcp_ref.entity
				elif isinstance(tcp_ref, str):
					tcp_ent = self._scene.find_by_id(tcp_ref)
			if tcp_ent is not None:
				ee_id = rd.find_link_entity_id(rd.tool_link)
				ee_ent = self._scene.find_by_id(ee_id) if ee_id else None
				if ee_ent is not None:
					try:
						T_ee_tcp = project_to_se3(relative_offset_m(ee_ent, tcp_ent))
					except Exception:
						T_ee_tcp = np.eye(4, dtype=np.float64)

		# Offline snapshot on the main thread: same CollisionMatrix pairs and
		# world/link transforms as the viewport, queried via FCL on the worker
		# with no Qt/VTK posing during sampling.
		collision_world = build_planning_collision_world(self._scene, rd)

		speed_mults = [float(getattr(seg, "speed_multiplier", 1.0)) for seg in path.segments]

		return PlanRequest(
			job_entity_id=job_ent.id,
			robot_entity_id=robot_ent.id,
			urdf_path=str(abs_urdf),
			root_link=str(rd.root_link),
			tool_link=str(rd.tool_link),
			joint_names=joint_names,
			q_seed=q_seed,
			joints=[dict(j) for j in rd.joints],
			waypoint_segments_m_rad=segments,
			segment_speed_multipliers=speed_mults,
			path_speed_m_s=float(getattr(path, "speed", 0.25)),
			path_acceleration_m_s2=float(getattr(path, "acceleration", 1.2)),
			analytic_solver_path=str(abs_analytic or ""),
			backend=str(getattr(planner, "backend", "ompl") or "ompl"),
			planning_time_limit_s=float(getattr(planner, "planning_time_limit_s", 2.0)),
			process_sample_spacing_m=float(getattr(planner, "process_sample_spacing_m", 0.01)),
			simplify_path=bool(getattr(planner, "simplify_path", True)),
			transition_joint_speed_rad_s=float(
				getattr(planner, "transition_joint_speed_rad_s", 1.0)
			),
			T_ee_tcp=T_ee_tcp,
			collision_world=collision_world,
			position_tolerance_m=float(
				getattr(ik, "position_tolerance_m", 1e-3) if ik else 1e-3
			),
			orientation_tolerance_rad=float(
				getattr(ik, "orientation_tolerance_rad", 1e-2) if ik else 1e-2
			),
		)

	def _on_planned(self, job_entity_id: str, result: PlanResult) -> None:
		from MotionStudio.core.components.motion_planner_component import (
			MotionPlannerComponent,
		)

		self._busy_jobs[job_entity_id] = False
		# Hide overlay before dialogs so the UI is interactive again.
		self._end_loading_overlay()
		cw = getattr(result, "collision_world", None)

		ent = self._scene.find_by_id(job_entity_id)
		if ent is None:
			return
		planner = ent.get_component(MotionPlannerComponent)
		if planner is None:
			return

		if result.success:
			planner.set_trajectory(result.trajectory)
			n = len(result.trajectory.samples)
			summary = ""
			if isinstance(cw, PlanningCollisionWorld):
				summary = f" — {cw.collision_summary()}"
			planner.status = (
				f"OK — {n} samples, {result.trajectory.duration:.2f}s — "
				f"{result.message}{summary}"
			)
		else:
			planner.status = result.message or "Planning failed"
			# Pose at failure_q once on the main thread for debugging (not during sampling).
			self._apply_failure_q(planner, result, cw)
			QMessageBox.warning(None, "Plan Motion", planner.status)

	def _apply_failure_q(
		self,
		planner: "MotionPlannerComponent",
		result: PlanResult,
		cw: object,
	) -> None:
		"""Pose the bound robot at the failing sample using live FK + check_all."""
		q = getattr(result, "failure_q", None)
		if q is None:
			return
		q = np.asarray(q, dtype=np.float64).reshape(-1)
		if q.size == 0:
			return
		rd = planner._resolved_robot()
		if rd is None or rd.entity is None:
			return
		names = list(rd.actuated_joint_names)
		if not names:
			return
		joints = {
			names[i]: float(q[i])
			for i in range(min(len(names), int(q.size)))
		}
		try:
			self._scene.robot_ik_system.apply_solution(rd.entity.id, joints)
			self._scene.collision_system.check_all()
		except Exception:
			return

		pair = None
		if isinstance(cw, PlanningCollisionWorld):
			try:
				pair = cw.find_colliding_pair(q)
			except Exception:
				pair = None
		if pair is None:
			pair = self._live_any_colliding_pair()
		if pair is not None:
			planner.status = (
				f"{planner.status}  |  colliding {pair[0]} ↔ {pair[1]}"
			)

	def _live_any_colliding_pair(self) -> Optional[tuple]:
		from MotionStudio.core.robot.collision_groups import partition_colliders
		from MotionStudio.core.robot.planning.collision_world import all_matrix_pairs

		cs = self._scene.collision_system
		groups, ungrouped = partition_colliders(cs.collider_entities())
		for ent_a, ent_b in all_matrix_pairs(groups, ungrouped, cs.matrix):
			try:
				if cs._pair_collides(ent_a, ent_b):
					return str(ent_a.id), str(ent_b.id)
			except Exception:
				continue
		return None

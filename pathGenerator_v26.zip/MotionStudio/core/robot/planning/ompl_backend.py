"""OMPL motion-planner backend (RRT-Connect for inter-segment transitions)."""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.planning.plan_pipeline import plan_segments_with_transitions
from MotionStudio.core.robot.planning.planner_backend import PlanRequest, PlanResult


def _ompl_available() -> bool:
	try:
		from ompl import base as ob  # noqa: F401
		from ompl import geometric as og  # noqa: F401

		return True
	except Exception:
		return False


def plan_joint_transition(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	collision_world,
	*,
	time_limit_s: float,
	simplify: bool,
) -> Tuple[Optional[List[np.ndarray]], str]:
	"""OMPL RRT-Connect in joint space. Returns ``(path, "")`` or ``(None, reason)``."""
	from ompl import base as ob
	from ompl import geometric as og

	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	q_goal = np.asarray(q_goal, dtype=np.float64).reshape(-1)
	dof = int(q_start.size)
	if q_goal.size != dof:
		return None, "start/goal DOF mismatch"

	limits = (
		collision_world.joint_limits()
		if collision_world is not None
		else [(-np.pi, np.pi) for _ in range(dof)]
	)
	space = ob.RealVectorStateSpace(dof)
	bounds = ob.RealVectorBounds(dof)
	for i, (lo, hi) in enumerate(limits):
		bounds.setLow(i, float(lo))
		bounds.setHigh(i, float(hi))
	space.setBounds(bounds)

	ss = og.SimpleSetup(space)

	def is_valid(state) -> bool:
		q = np.array([state[i] for i in range(dof)], dtype=np.float64)
		if collision_world is None:
			return True
		return bool(collision_world.is_state_valid(q))

	ss.setStateValidityChecker(ob.StateValidityCheckerFn(is_valid))
	space.setLongestValidSegmentFraction(0.01)
	ss.getSpaceInformation().setStateValidityCheckingResolution(0.01)

	start = ob.State(space)
	goal = ob.State(space)
	for i in range(dof):
		start[i] = float(q_start[i])
		goal[i] = float(q_goal[i])
	ss.setStartAndGoalStates(start, goal)

	planner = og.RRTConnect(ss.getSpaceInformation())
	ss.setPlanner(planner)
	solved = ss.solve(float(max(0.05, time_limit_s)))
	if not solved:
		return None, f"OMPL RRT-Connect timed out after {time_limit_s:.2f}s"

	if simplify:
		try:
			ss.simplifySolution()
		except Exception:
			pass

	path = ss.getSolutionPath()
	try:
		path.interpolate()
	except Exception:
		pass

	states: List[np.ndarray] = []
	for i in range(path.getStateCount()):
		st = path.getState(i)
		states.append(np.array([st[i] for i in range(dof)], dtype=np.float64))
	if not states:
		return None, "OMPL returned an empty path"
	states[0] = q_start.copy()
	states[-1] = q_goal.copy()
	return states, ""


class OmplMotionPlannerBackend:
	"""OMPL-backed planner: continuous IK on segments, RRT-Connect between them."""

	def is_available(self) -> bool:
		return _ompl_available()

	def invalidate_cache(self, key: str) -> None:
		_ = key

	def plan(self, request: PlanRequest) -> PlanResult:
		if not self.is_available():
			return PlanResult(
				False,
				"OMPL is not installed. Install via conda-forge (see requirements-robot.txt).",
			)

		ik = AnalyticIKBackend()
		if not ik.is_available():
			return PlanResult(False, "ssik is not available for analytic IK.")

		return plan_segments_with_transitions(
			request,
			backend_name="ompl",
			transition_fn=plan_joint_transition,
			ik=ik,
		)

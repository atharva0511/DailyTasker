from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PyQt6.QtGui import QColor, QVector3D

from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.robot_ik_component import RobotIKComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.robot.collision_groups import apply_urdf_collision_group_defaults
from MotionStudio.core.robot.robot_kinematics import resolve_link_entity_ids, update_robot_fk
from MotionStudio.core.robot.urdf_asset_bundle import UrdfAssetBundle, bundle_urdf_assets
from MotionStudio.core.robot.urdf_paths import detect_package_root, extract_package_name_from_model
from MotionStudio.core.robot.urdf_parser import (
	UrdfModel,
	inertial_to_dict,
	joint_to_dict,
	parse_urdf_file,
	transmission_to_dict,
)
from MotionStudio.core.scene.scene import Scene
from MotionStudio.utils.mesh_assets import has_source_material_sidecar

COLLIDER_METER_TO_MM_SCALE = 1000.0


@dataclass
class UrdfImportPrepared:
	"""URDF parse + asset bundle result (worker-thread safe; no Scene access)."""

	source: Path
	model: UrdfModel
	bundle: UrdfAssetBundle
	pkg_name: str
	root_link: str
	tool_link: str
	robot_name: str
	package_folder_value: str


def _detect_root_link(model: UrdfModel) -> str:
	child_links = {j.child_link for j in model.joints.values()}
	candidates = [name for name in model.links if name not in child_links]
	if "base_link" in model.links:
		return "base_link"
	if candidates:
		return candidates[0]
	return next(iter(model.links.keys()), "base_link")


def _detect_tool_link(model: UrdfModel) -> str:
	if "tool0" in model.links:
		return "tool0"
	# Leaf link with no outgoing joints
	parent_links = {j.parent_link for j in model.joints.values()}
	leaves = [n for n in model.links if n not in parent_links]
	return leaves[0] if leaves else _detect_root_link(model)


def _build_link_records(model: UrdfModel, bundle: UrdfAssetBundle) -> List[Dict]:
	records: List[Dict] = []
	for link_name, link in model.links.items():
		meshes = bundle.link_meshes.get(link_name)
		rec = {
			"name": link_name,
			"entity_id": "",
			"visual_mesh_paths": [],
			"collision_mesh_paths": [],
			"inertial": inertial_to_dict(link.inertial),
		}
		if meshes is not None:
			if meshes.visual_project_path:
				rec["visual_mesh_paths"] = [meshes.visual_project_path]
			if meshes.collision_project_path:
				rec["collision_mesh_paths"] = [meshes.collision_project_path]
		records.append(rec)
	return records


def _create_link_entity(
	scene: Scene,
	parent: Entity,
	link_name: str,
	joint_name: Optional[str],
	bundle: UrdfAssetBundle,
	model: UrdfModel,
	project_root: Path,
	robot_name: str,
) -> Entity:
	ent = scene.create_entity(link_name, parent)
	ent.add_component(UrdfLinkComponent(link_name=link_name, parent_joint_name=joint_name))
	ent.add_component(TransformComponent())

	link = model.links.get(link_name)
	meshes = bundle.link_meshes.get(link_name)

	if meshes is not None and meshes.visual_project_path:
		use_src = has_source_material_sidecar(project_root, meshes.visual_project_path)
		ent.add_component(
			MeshComponent(
				shape="custom",
				custom_path=meshes.visual_project_path,
				source_material=use_src,
				color=QColor(180, 180, 180),
			)
		)

	if meshes is not None and meshes.collision_project_path:
		ent.add_component(
			ColliderComponent(
				collider_from_mesh_component=False,
				collider_mesh_path=meshes.collision_project_path,
				render_collider=True,
				scale=COLLIDER_METER_TO_MM_SCALE,
				repaint_on_collision=True,
				use_collision_group=True,
				collision_group_name=robot_name,
			)
		)

	return ent


def _build_entity_tree(
	scene: Scene,
	robot_root: Entity,
	model: UrdfModel,
	bundle: UrdfAssetBundle,
	project_root: Path,
	root_link: str,
	robot_name: str,
) -> Dict[str, Entity]:
	"""Create link entities; return map link_name -> entity."""
	link_entities: Dict[str, Entity] = {}
	children_by_parent: Dict[str, List] = model.child_joints_by_parent()

	def ensure_link(link_name: str, parent_ent: Entity, joint_name: Optional[str]) -> Entity:
		if link_name in link_entities:
			return link_entities[link_name]
		ent = _create_link_entity(
			scene, parent_ent, link_name, joint_name, bundle, model, project_root, robot_name
		)
		link_entities[link_name] = ent
		for joint in children_by_parent.get(link_name, []):
			ensure_link(joint.child_link, ent, joint.name)
		return ent

	ensure_link(root_link, robot_root, None)
	return link_entities


def prepare_urdf_import(
	project_root: Path,
	urdf_source_path: str | Path,
) -> UrdfImportPrepared:
	"""
	Parse URDF and copy/convert meshes into the project (worker-thread safe).
	"""
	root = project_root.resolve()
	source = Path(urdf_source_path).resolve()
	model = parse_urdf_file(source)
	pkg_name = extract_package_name_from_model(model)
	pkg_folder = detect_package_root(source)
	bundle = bundle_urdf_assets(
		model,
		root,
		package_name=pkg_name,
		package_folder=pkg_folder,
	)
	root_link = _detect_root_link(model)
	tool_link = _detect_tool_link(model)
	robot_name = model.robot_name or source.stem
	package_folder_value = bundle.local_package_rel or str(pkg_folder)
	return UrdfImportPrepared(
		source=source,
		model=model,
		bundle=bundle,
		pkg_name=pkg_name,
		root_link=root_link,
		tool_link=tool_link,
		robot_name=robot_name,
		package_folder_value=package_folder_value,
	)


def apply_urdf_import(
	scene: Scene,
	prepared: UrdfImportPrepared,
	*,
	attach_under: Optional[Entity] = None,
) -> Entity:
	"""
	Create robot entities in the scene from a prepared URDF import. Main thread only.
	"""
	if scene.project_root is None:
		raise RuntimeError("Open or create a project before importing URDF.")

	model = prepared.model
	bundle = prepared.bundle
	root_link = prepared.root_link
	tool_link = prepared.tool_link
	robot_name = prepared.robot_name

	robot_root = scene.create_entity(robot_name, attach_under)
	robot_root.add_component(TransformComponent())

	analytic_solver_rel = ""
	try:
		from MotionStudio.core.robot.ik.analytic_solver_gen import (
			resolve_or_generate_analytic_solver,
		)

		analytic_solver_rel, analytic_msg = resolve_or_generate_analytic_solver(
			project_root=Path(scene.project_root),
			urdf_project_path=bundle.urdf_project_path,
			base_link=root_link,
			ee_link=tool_link,
			force=False,
		)
		if analytic_msg:
			print(f"URDF import analytic IK: {analytic_msg}", flush=True)
	except Exception as exc:
		print(f"URDF import analytic IK: skipped ({exc})", flush=True)
		analytic_solver_rel = ""

	robot_desc = RobotDescriptionComponent(
		urdf_path=bundle.urdf_project_path,
		robot_name=robot_name,
		package_name=prepared.pkg_name,
		package_folder=prepared.package_folder_value,
		root_link=root_link,
		tool_link=tool_link,
		analytic_solver_path=analytic_solver_rel,
	)
	robot_desc.links = _build_link_records(model, bundle)
	robot_desc.joints = [joint_to_dict(j) for j in model.joints.values()]
	robot_desc.transmissions = [transmission_to_dict(t) for t in model.transmissions]
	robot_desc.actuated_joint_names = model.actuated_joint_names()
	for jname in robot_desc.actuated_joint_names:
		robot_desc.joint_positions[jname] = 0.0
	robot_root.add_component(robot_desc)

	link_entities = _build_entity_tree(
		scene, robot_root, model, bundle, scene.project_root, root_link, robot_name
	)
	resolve_link_entity_ids(robot_desc)
	update_robot_fk(robot_desc)
	apply_urdf_collision_group_defaults(scene, robot_desc)

	# Auto IK setup: a Tool Control Point entity under the tool link (identity
	# offset by default, ready for the user to position) plus a RobotIK
	# component on the root that already references it.
	robot_ik = RobotIKComponent()
	tool_ent = link_entities.get(tool_link)
	if tool_ent is not None:
		tcp_ent = scene.create_entity("TCP", tool_ent)
		tcp_transform = TransformComponent()
		tcp_ent.add_component(tcp_transform)
		robot_ik.tcp = tcp_transform
	robot_root.add_component(robot_ik)

	try:
		scene.events.entity_changed.emit(robot_root.id)
	except Exception:
		pass

	return robot_root


def import_urdf_into_scene(
	scene: Scene,
	urdf_source_path: str | Path,
	*,
	attach_under: Optional[Entity] = None,
) -> Entity:
	"""
	Import a URDF file into the scene. Requires ``scene.project_root`` to be set.

	Returns the robot root entity (with ``RobotDescriptionComponent``).
	"""
	if scene.project_root is None:
		raise RuntimeError("Open or create a project before importing URDF.")
	prepared = prepare_urdf_import(scene.project_root, urdf_source_path)
	return apply_urdf_import(scene, prepared, attach_under=attach_under)

"""Motion planner component — Job entity binding for OMPL (and future backends)."""

from __future__ import annotations

from typing import Annotated, Any, Dict, List, Literal, Optional, Tuple

import numpy as np
from PyQt6.QtGui import QVector3D

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.robot.ik.ik_frames import project_to_se3, relative_offset_m
from MotionStudio.core.robot.planning.trajectory import JointTrajectory
from MotionStudio.core.robot.planning.trajectory_preview import trajectory_tcp_path_base_mm
from MotionStudio.core.transform.utils import world_matrix
from MotionStudio.ui.inspector.metadata import Group, Hidden, Range, Tooltip, inspector_button


@register_component
class MotionPlannerComponent(Component):
	"""Plans a joint-space trajectory for a PathGeneration job on a robot.

	Lives on the Job entity (alongside PathGeneration). Planning runs on a
	background thread via ``scene.motion_planning_system``. Play Mode streams
	the persisted trajectory onto ``RobotDescription.joint_positions``.
	"""

	type_name = "MotionPlanner"

	# Debug overlay for the planned TCP path (world mm).
	PLANNED_PATH_COLOR: Tuple[float, float, float] = (0.1, 0.35, 1.0)
	PLANNED_PATH_WIDTH: float = 5.0

	path: Annotated[
		Optional[PathComponent],
		Tooltip(
			"PathGeneration job to plan. If empty, uses PathGeneration on this same entity."
		),
		Group("Bindings"),
	] = None

	robot: Annotated[
		Optional[RobotDescriptionComponent],
		Tooltip(
			"Robot to plan for. If empty, uses the Robot selected on PathGeneration export."
		),
		Group("Bindings"),
	] = None

	backend: Annotated[
		Literal["ompl", "imove"],
		Tooltip(
			"Motion planner backend. 'ompl' (default): continuous IK on path segments "
			"+ OMPL RRT-Connect transitions (needs OMPL installed). "
			"'imove': same process IK + built-in numpy RRT-Connect (no extra deps)."
		),
		Group("Planner"),
	] = "ompl"

	planning_time_limit_s: Annotated[
		float,
		Range(0.1, 60.0, step=0.1, decimals=2),
		Tooltip("Wall-clock budget per inter-segment transition (seconds)"),
		Group("Planner"),
	] = 2.0

	process_sample_spacing_m: Annotated[
		float,
		Range(0.001, 0.1, step=0.001, decimals=3),
		Tooltip("Cartesian densify spacing along each path segment (metres)"),
		Group("Planner"),
	] = 0.01

	simplify_path: Annotated[
		bool,
		Tooltip(
			"Simplify transition paths: OMPL PathSimplifier, or imove greedy + "
			"iterative random shortcutting (keeps shortest of multi-attempt RRT)"
		),
		Group("Planner"),
	] = True

	transition_joint_speed_rad_s: Annotated[
		float,
		Range(0.05, 10.0, step=0.05, decimals=2),
		Tooltip("C-space speed used to time inter-segment transitions (rad/s L2)"),
		Group("Planner"),
	] = 1.0

	enabled_playback: Annotated[
		bool,
		Tooltip("When Play Mode starts, stream the planned joint trajectory onto the robot"),
		Group("Playback"),
	] = True

	show_planned_path: Annotated[
		bool,
		Tooltip("Draw the planned TCP path (FK of joint trajectory) as a blue debug polyline"),
		Group("Playback"),
	] = True

	status: Annotated[
		str,
		Tooltip("Last planning status"),
		Group("Planner"),
		Hidden(),
	] = ""

	def __init__(self) -> None:
		self.path = None
		self.robot = None
		self.backend = "ompl"
		self.planning_time_limit_s = 2.0
		self.process_sample_spacing_m = 0.01
		self.simplify_path = True
		self.transition_joint_speed_rad_s = 1.0
		self.enabled_playback = True
		self.show_planned_path = True
		self.status = ""
		self._trajectory = JointTrajectory()
		# Play-only state (not serialized)
		self._play_t = 0.0
		self._play_done = False
		self._saved_ik_enabled: Optional[bool] = None
		# Cached TCP path in robot-base millimetres (recomputed when trajectory changes).
		self._tcp_path_base_mm: List[QVector3D] = []

	# ------------------------------------------------------------------ trajectory

	@property
	def trajectory(self) -> JointTrajectory:
		return self._trajectory

	def set_trajectory(self, traj: JointTrajectory) -> None:
		self._trajectory = traj if traj is not None else JointTrajectory()
		self._rebuild_tcp_path_preview()

	def clear_trajectory(self) -> None:
		self._trajectory = JointTrajectory()
		self._tcp_path_base_mm = []
		self.status = "Cleared"

	def _resolve_T_ee_tcp(self, rd: RobotDescriptionComponent) -> np.ndarray:
		"""tool_link → TCP offset in metres (identity when no TCP is bound)."""
		T = np.eye(4, dtype=np.float64)
		robot_ent = rd.entity
		if robot_ent is None or robot_ent.scene is None:
			return T
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		ik = robot_ent.get_component(RobotIKComponent)
		if ik is None:
			return T
		tcp_ref = getattr(ik, "tcp", None)
		tcp_ent = None
		if tcp_ref is not None:
			if hasattr(tcp_ref, "entity"):
				tcp_ent = tcp_ref.entity
			elif isinstance(tcp_ref, str):
				tcp_ent = robot_ent.scene.find_by_id(tcp_ref)
		if tcp_ent is None:
			return T
		ee_id = rd.find_link_entity_id(rd.tool_link)
		ee_ent = robot_ent.scene.find_by_id(ee_id) if ee_id else None
		if ee_ent is None:
			return T
		try:
			return project_to_se3(relative_offset_m(ee_ent, tcp_ent))
		except Exception:
			return T

	def _rebuild_tcp_path_preview(self) -> None:
		self._tcp_path_base_mm = []
		if self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None:
			return
		self._tcp_path_base_mm = trajectory_tcp_path_base_mm(
			self._trajectory,
			root_link=str(rd.root_link),
			tool_link=str(rd.tool_link),
			joints=list(rd.joints),
			T_ee_tcp=self._resolve_T_ee_tcp(rd),
		)

	# ------------------------------------------------------------------ resolve refs

	def _resolved_path(self) -> Optional[PathComponent]:
		value = self.path
		if isinstance(value, PathComponent):
			return value
		entity = self.entity
		if entity is None:
			return None
		if isinstance(value, str) and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(PathComponent)
				if comp is not None:
					self.path = comp
					return comp
		# Sibling fallback
		return entity.get_component(PathComponent)

	def _resolved_robot(self) -> Optional[RobotDescriptionComponent]:
		value = self.robot
		if isinstance(value, RobotDescriptionComponent):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if comp is not None:
					self.robot = comp
					return comp
		path = self._resolved_path()
		if path is not None:
			return path._resolved_robot()
		return None

	# ------------------------------------------------------------------ inspector

	@inspector_button("Plan Motion", tooltip="Plan joint trajectory for the bound path + robot", group="Planner")
	def plan_motion(self) -> None:
		entity = self.entity
		if entity is None or entity.scene is None:
			return
		system = getattr(entity.scene, "motion_planning_system", None)
		if system is None:
			return
		if system.is_busy(entity.id):
			from PyQt6.QtWidgets import QMessageBox

			QMessageBox.information(None, "Plan Motion", "A plan is already running for this job.")
			return
		system.submit_plan(self)

	@inspector_button("Clear Trajectory", tooltip="Remove the stored joint trajectory", group="Planner")
	def clear_motion_trajectory(self) -> None:
		self.clear_trajectory()

	# ------------------------------------------------------------------ viewport / debug

	def on_viewport_draw(self) -> None:
		"""Draw the planned TCP path as a thick blue polyline (one-frame Debug)."""
		if not self.show_planned_path:
			return
		if len(self._tcp_path_base_mm) < 2 and not self._trajectory.is_empty():
			self._rebuild_tcp_path_preview()
		if len(self._tcp_path_base_mm) < 2:
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None:
			return
		wm = world_matrix(rd.entity)
		world_pts = [wm.map(p) for p in self._tcp_path_base_mm]
		Debug.draw_polyline(
			world_pts,
			color=self.PLANNED_PATH_COLOR,
			width=self.PLANNED_PATH_WIDTH,
			on_top=True,
		)

	# ------------------------------------------------------------------ play mode

	def start(self) -> None:
		self._play_t = 0.0
		self._play_done = False
		self._saved_ik_enabled = None
		if not self.enabled_playback or self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None:
			return
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		ik = rd.entity.get_component(RobotIKComponent)
		if ik is not None:
			self._saved_ik_enabled = bool(ik.enabled)
			ik.enabled = False

	def update(self, delta_time: float) -> None:
		if not self.enabled_playback or self._play_done or self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None or rd.entity.scene is None:
			return
		self._play_t += float(delta_time)
		joints = self._trajectory.sample_at(self._play_t)
		if joints is None:
			return
		ik_system = rd.entity.scene.robot_ik_system
		ik_system.apply_solution(rd.entity.id, joints)
		if self._play_t >= self._trajectory.duration:
			self._play_done = True

	# ------------------------------------------------------------------ serialize

	def to_dict(self) -> Dict[str, Any]:
		data = super().to_dict()
		data["trajectory"] = self._trajectory.to_dict()
		return data

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "MotionPlannerComponent":
		inst = super().from_dict(data)
		traj_data = data.get("trajectory")
		if isinstance(traj_data, dict):
			inst._trajectory = JointTrajectory.from_dict(traj_data)
		else:
			inst._trajectory = JointTrajectory()
		# Rebuild preview after load (robot may resolve later on first draw).
		inst._tcp_path_base_mm = []
		return inst

from __future__ import annotations

from typing import Annotated, Literal, Optional

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import FilePath, Group, Range, Tooltip, inspector_button
from MotionStudio.core.debug import Debug


@register_component
class RobotIKComponent(Component):
	"""Inverse-kinematics driver attached to a robot root entity.

	Tracks a target ``TransformComponent`` and, whenever the target (or the
	robot base) moves, solves 6D pose IK on a background thread and writes the
	result onto the sibling ``RobotDescription``'s joint angles. The actual
	solving and threading live in ``RobotIKSystem``; this component only holds
	user-facing configuration plus a one-shot debug button.
	"""

	type_name = "RobotIK"

	enabled: Annotated[bool, Tooltip("Master toggle for IK tracking")] = True

	target: Annotated[
		Optional[TransformComponent],
		Tooltip("Target transform the end-effector should track (entity picker)"),
	] = None

	tcp: Annotated[
		Optional[TransformComponent],
		Tooltip(
			"Optional custom Tool Control Point. Pick an entity (usually a child "
			"of the tool-link entity) whose transform marks the real tool tip. "
			"IK drives THIS point to the target. Leave empty to use the URDF "
			"tool_link directly."
		),
	] = None

	backend: Annotated[
		Literal["analytic", "ikpy"],
		Tooltip(
			"IK solver backend. 'analytic' uses an ssik-generated closed-form "
			"solver (requires analytic_solver_path / Regenerate Analytical IK). "
			"'ikpy' is pure-Python numerical IK. There is no automatic fallback "
			"between backends — a misconfigured or unavailable solver raises an error."
		),
		Group("IK Settings"),
	] = "analytic"

	analytic_solver_path: Annotated[
		str,
		FilePath("Python Files (*.py);;All Files (*.*)"),
		Tooltip(
			"Optional analytic (ssik) solver Python module path for this IK "
			"component. If empty, uses RobotDescription.analytic_solver_path."
		),
		Group("IK Settings"),
	] = ""

	solve_hz: Annotated[
		float,
		Range(1.0, 120.0, step=1.0, decimals=0),
		Tooltip("Maximum solve rate while dragging the target"),
		Group("IK Settings"),
	] = 20.0

	position_tolerance_m: Annotated[
		float,
		Range(1e-5, 0.1, step=1e-4, decimals=5),
		Tooltip("Position success threshold in metres"),
		Group("IK Settings"),
	] = 1e-3

	orientation_tolerance_rad: Annotated[
		float,
		Range(1e-4, 1.0, step=1e-3, decimals=4),
		Tooltip("Orientation success threshold in radians"),
		Group("IK Settings"),
	] = 1e-2

	max_iterations: Annotated[
		int,
		Range(1, 1000, step=1),
		Tooltip("Maximum solver iterations per solve (ikpy)"),
		Group("IK Settings"),
	] = 100

	def __init__(self) -> None:
		self.enabled = True
		self.target = None
		self.tcp = None
		self.backend = "analytic"
		self.analytic_solver_path = ""
		self.solve_hz = 20.0
		self.position_tolerance_m = 1e-3
		self.orientation_tolerance_rad = 1e-2
		self.max_iterations = 100

	def _robot_ik_system(self):
		entity = self.entity
		if entity is None:
			return None
		scene = getattr(entity, "_scene", None)
		if scene is None:
			return None
		return getattr(scene, "robot_ik_system", None)

	def on_viewport_draw(self):
		if self.target is not None:
			from MotionStudio.core.transform.utils import world_position, world_rotation_quat

			entity = self.target.entity
			Debug.draw_axes(world_position(entity), length=10.0, screen_space=True,rotation=world_rotation_quat(entity), width=2.0, x_color=(1, 0, 0), y_color=(0, 1, 0), z_color=(0, 0, 1))

	@inspector_button("Solve IK Now", tooltip="Run one synchronous solve toward the target")
	def solve_ik_now(self) -> None:
		system = self._robot_ik_system()
		if system is None:
			print("Solve IK Now: no IK system on scene.", flush=True)
			return
		request = system.build_request(self)
		if request is None:
			print("Solve IK Now: target/robot not configured.", flush=True)
			return
		from MotionStudio.core.robot.ik.backend_runtime import IKBackendError, solve_ik_request

		try:
			result = solve_ik_request(str(self.backend), request, {})
		except IKBackendError as exc:
			print(f"Solve IK Now: error ({exc}).", flush=True)
			return
		if not result.joint_values:
			print(f"Solve IK Now: failed ({result.message}).", flush=True)
			return
		system.apply_solution(request.robot_entity_id, result.joint_values)
		if self.entity is not None and self.entity._scene is not None:
			self.entity._scene.events.entity_changed.emit(self.entity.id)
		status = "converged" if result.success else f"applied (not converged: {result.message})"
		print(f"Solve IK Now: {status}.", flush=True)

	@inspector_button(
		"Regenerate Analytical IK",
		tooltip="Re-run ssik build for this robot's URDF and refresh analytic_solver_path",
	)
	def regenerate_analytical_ik(self) -> None:
		from pathlib import Path

		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.robot.ik.analytic_solver_gen import (
			resolve_or_generate_analytic_solver,
		)

		entity = self.entity
		if entity is None:
			print("Regenerate Analytical IK: no entity.", flush=True)
			return
		scene = getattr(entity, "_scene", None)
		rd = entity.get_component(RobotDescriptionComponent)
		if scene is None or scene.project_root is None or rd is None or not rd.urdf_path:
			print("Regenerate Analytical IK: robot/URDF/project not configured.", flush=True)
			return
		rel, msg = resolve_or_generate_analytic_solver(
			project_root=Path(scene.project_root),
			urdf_project_path=rd.urdf_path,
			base_link=str(rd.root_link or "base_link"),
			ee_link=str(rd.tool_link or "tool0"),
			force=True,
		)
		if rel:
			rd.analytic_solver_path = rel
			self.analytic_solver_path = ""
			print(f"Regenerate Analytical IK: {msg}", flush=True)
			try:
				scene.events.entity_changed.emit(entity.id)
			except Exception:
				pass
		else:
			print(f"Regenerate Analytical IK: {msg}", flush=True)

# TCP Commands

Drive Motion Studio from an external app: `RUN` presses an Inspector button,
`EDIT` changes an Inspector value, `GET` reads one. If you can click, type, or
see it in the Inspector, you can send it — nothing else is reachable.

**Connect** to `127.0.0.1:5555` (default). Toggle it, change the port, or set the
command timeout in **Edit → Preferences… → TCP Command Server**, or in the
`[tcp]` section of `preferences.ini` (`host` is file-only; loopback by default,
no authentication).

## Format

One UTF-8 line per command, `\n` terminated. One reply per command. The
connection stays open.

```
RUN,<entity>,<component>,<function>            -> 1            success
EDIT,<entity>,<component>,<property>,<value>   -> 1,<output>   success with a return value
GET,<entity>,<component>,<property>            -> 1,<value>    current field value
                                               -> 0,<reason>   failure
```

A bare **`1` means done** — that is the usual reply for `EDIT` and most buttons.
`GET` almost always carries a payload (`1,150,0,25`, `1,true`, `1,Connected`).
An empty string still drops the comma (`1`). Fields are trimmed and matched
ignoring case and spaces. Everything after the fourth comma of an `EDIT` is the
value, so values may contain commas. Never send a blank line — it gets no reply.

```
> EDIT,UUT,Transform,position,150,0,25
< 1
> GET,UUT,Transform,position
< 1,150,0,25
> GET,Cam,MechmindScanner,connection_status
< 1,Connected
> RUN,ur10e_robot,RobotDescription,Reset Pose
< 1
> RUN,PlannerJob,MotionPlanner,Plan Motion
< 1,OK — 120 samples, traj 4.20s
```

`RUN` and `GET` need four fields — `RUN,ur10e_robot,Reset Pose` is missing the
component. Use the button caption (`Plan Motion`) or the method name
(`plan_motion`). Entity names must be unique; a UUID also works.

## `EDIT` values

| Property type | Send | Example value |
| --- | --- | --- |
| number | any number | `30` |
| whole number | decimal or `0x` hex | `200` |
| yes/no | `true`/`false`, `1`/`0`, `yes`/`no`, `on`/`off` | `true` |
| text | verbatim, paths included | `C:/models/arm.glb` |
| dropdown | one of the listed choices | `ikpy` |
| vector | 3 numbers, commas and/or spaces | `150,0,25` |
| color | `#rrggbb`, a name, or `r,g,b[,a]` | `#ff8800` |
| component reference | name/UUID of the owning entity; `none` clears | `ur10e_robot` |

Ranges are **rejected, not clamped**: `0,value 99999 out of range [1, 120] for
solve_hz`. Lists and other structured fields are not editable remotely.

Remote edits use the normal undo stack — they appear in the status bar, in
`logs.txt`, and undo with Ctrl+Z. `GET` does not create an undo entry.

## `GET` values

The reply payload uses the same grammar as the `EDIT` table above, so you can
round-trip: `GET` then later `EDIT` with that text. Read-only Inspector fields
(`connection_status`, planner `status`, …) are readable. A cleared component
reference is `none`.

## Logging

Every command and every reply is written to `logs.txt` in the project folder, so
a sequence can be audited afterwards — `>` is what you sent, `<` is what you got
back, and the timestamps show how long each command took. The same line appears
on the editor status bar as it is written.

```
[2026-08-27 20:38:33] tcp: 127.0.0.1:49369 > RUN,PlannerJob,MotionPlanner,Plan Motion
[2026-08-27 20:38:36] tcp: 127.0.0.1:49369 < 1,OK — 120 samples, traj 4.20s
```

Inspector button clicks (not only TCP) write the same reply grammar under `inspector`:
`… Plan Motion clicked` when the button is pressed, then `… Plan Motion < 1,…` when that action's reply is ready.

## Timing

**The reply is the completion signal** — a command answers only when the action
has actually finished, and the UI stays responsive meanwhile. `Plan Motion`
replies when planning completes. Hardware **Connect** replies `1` only when
the camera/robot is connected (`0,Error: …` on failure). `Capture` / UR **RUN**
wait for the worker the same way.

Commands run one at a time across all connections. Past `timeout_s` (300 s
default) you get `0,timeout after 300s: …`, but the action itself keeps running.
Set your client's socket timeout higher than `timeout_s`.

## Failures

A reply starting with `0` is a failed step; the text after the comma is the
reason. Common ones: `entity not found: X`, `multiple entities named X`,
`component not found: X on Y`, `function not found: X on Y`,
`property not found / is read-only: X on Y`, `expected GET,<entity>,<component>,<property>`, `expected one of [a, b] for X`,
`expected 3 numbers for a vector`, `value N out of range`, `X raised: …`.

## Available commands

The Inspector is the authority — the labels and field names it shows are what
you send. Buttons currently available:

| Component | Functions |
| --- | --- |
| `MotionPlanner` | `Plan Motion`, `Clear Trajectory` |
| `RobotIK` | `Solve IK Now`, `Regenerate Analytical IK` |
| `RobotDescription` | `Reset Pose` |
| `ThreePointCalibration` | `Align`, `Clear` |
| `PathGeneration` | `Export...` |
| `MechmindScanner` | `Connect`, `Disconnect`, `Capture`, `Clear Scan` |
| `UniversalRobot` | `Connect`, `Disconnect`, `RUN` |
| `LiftToSafety` | `Lift to safety`, `Cancel lift` |

Editable properties include `Transform.position/rotation/scale` (rotation is
Euler degrees), `Mesh.shape/color`, the `MotionPlanner` backend and tuning
fields, `RobotIK.target/tcp/backend/solve_hz`, and the same for custom
components in `<Project>/Components/`.


Keep one connection open for the whole sequence, check every reply, and rely on
replies instead of sleeps.


# -*- mode: python ; coding: utf-8 -*-

import os

# pyqtdarktheme auto-detects Qt bindings at import time; force PyQt6 for Analysis.
os.environ.setdefault("QT_API", "pyqt6")

from PyInstaller.utils.hooks import collect_all


def _collect(pkg: str):
	"""collect_all wrapper that returns empty triples if a package is absent."""
	try:
		return collect_all(pkg)
	except Exception as exc:  # pragma: no cover - build-time only
		print(f"WARNING: collect_all({pkg!r}) failed: {exc}")
		return [], [], []


# Package is installed as pyqtdarktheme but imported as qdarktheme.
_qdarktheme_datas, _qdarktheme_binaries, _qdarktheme_hidden = _collect("qdarktheme")
_darkdetect_datas, _darkdetect_binaries, _darkdetect_hidden = _collect("darkdetect")
# pycollada installs as ``collada``; DAE→GLB (URDF visuals / Import Model) needs
# collada/resources/schema-1.4.1.xml on disk under sys._MEIPASS.
_collada_datas, _collada_binaries, _collada_hidden = _collect("collada")

# Analytical IK (ssik): generation + runtime of generated solvers. These are
# imported lazily from MotionStudio, so Analysis will not discover them unless
# we force-collect. URDF→solver needs urchin (+ lxml/networkx); codegen needs
# sympy/scipy; ssik subproblems import the Cython shadow module.
_ssik_datas, _ssik_binaries, _ssik_hidden = _collect("ssik")
_urchin_datas, _urchin_binaries, _urchin_hidden = _collect("urchin")
_sympy_datas, _sympy_binaries, _sympy_hidden = _collect("sympy")
_scipy_datas, _scipy_binaries, _scipy_hidden = _collect("scipy")
_cython_datas, _cython_binaries, _cython_hidden = _collect("Cython")
_lxml_datas, _lxml_binaries, _lxml_hidden = _collect("lxml")
_networkx_datas, _networkx_binaries, _networkx_hidden = _collect("networkx")

a = Analysis(
	["launcher.py"],
	pathex=[],
	binaries=(
		_qdarktheme_binaries
		+ _darkdetect_binaries
		+ _collada_binaries
		+ _ssik_binaries
		+ _urchin_binaries
		+ _sympy_binaries
		+ _scipy_binaries
		+ _cython_binaries
		+ _lxml_binaries
		+ _networkx_binaries
	),
	datas=[
		("resources", "resources"),
	]
	+ _qdarktheme_datas
	+ _darkdetect_datas
	+ _collada_datas
	+ _ssik_datas
	+ _urchin_datas
	+ _sympy_datas
	+ _scipy_datas
	+ _cython_datas
	+ _lxml_datas
	+ _networkx_datas,
	hiddenimports=[
		"resources.resources_rc",
		"qdarktheme",
		"darkdetect",
		"collada",
		"PyQt6.QtSvg",
		# Analytical IK stack (lazy imports in analytic_solver_gen / generated modules)
		"ssik",
		"ssik.cli",
		"urchin",
		"sympy",
		"scipy",
		"cython",
		"Cython",
		"lxml",
		"lxml.etree",
		"networkx",
	]
	+ _qdarktheme_hidden
	+ _darkdetect_hidden
	+ _collada_hidden
	+ _ssik_hidden
	+ _urchin_hidden
	+ _sympy_hidden
	+ _scipy_hidden
	+ _cython_hidden
	+ _lxml_hidden
	+ _networkx_hidden,
	hookspath=[],
	hooksconfig={},
	runtime_hooks=[],
	excludes=["PySide6"],
	noarchive=False,
	optimize=0,
)
pyz = PYZ(a.pure)

# One-dir layout: ``dist/iMOVE/iMOVE.exe`` + sibling deps (faster start than onefile).
exe = EXE(
	pyz,
	a.scripts,
	[],
	exclude_binaries=True,
	name="iMOVE",
	icon="resources/icon.ico",
	debug=False,
	bootloader_ignore_signals=False,
	strip=False,
	upx=True,
	console=False,
	disable_windowed_traceback=False,
	argv_emulation=False,
	target_arch=None,
	codesign_identity=None,
	entitlements_file=None,
)
coll = COLLECT(
	exe,
	a.binaries,
	a.datas,
	strip=False,
	upx=True,
	upx_exclude=[],
	name="iMOVE",
)

# -*- coding: utf-8 -*-
# Resource object code
# Created by: Resource Compiler
# WARNING! All changes made in this file will be lost!

from PyQt6 import QtCore
import sys
import os
from pathlib import Path

# Get the base directory for resources
# When packaged with PyInstaller, resources are in the temp extraction directory
# When running in development, resources are relative to this file
if hasattr(sys, '_MEIPASS'):
    # Running as PyInstaller executable
    _resource_base = Path(sys._MEIPASS) / 'resources'
else:
    # Running in development
    _resource_base = Path(__file__).parent

# Resource file mappings for qrc: paths
_resource_map = {
    ":/icons/2p_line.svg": _resource_base / "icons" / "2p_line.svg",
    ":/icons/3p_cir_arc.svg": _resource_base / "icons" / "3p_cir_arc.svg",
    ":/icons/polyline.svg": _resource_base / "icons" / "polyline.svg",
    ":/icons/cancel.svg": _resource_base / "icons" / "cancel.svg",
}

def application_icon_path() -> Path:
	"""Path to the main application icon (dev and PyInstaller builds)."""
	return _resource_base / "icon.png"


def load_application_icon():
	"""
	Build a multi-resolution QIcon for title bar and Windows taskbar.

	Windows needs several embedded sizes; a single PNG path is often not enough
	for the taskbar when running under python.exe.
	"""
	try:
		from PyQt6.QtCore import Qt
		from PyQt6.QtGui import QIcon, QPixmap
	except Exception:
		return None

	path = application_icon_path()
	if not path.exists():
		return None
	pixmap = QPixmap(str(path))
	if pixmap.isNull():
		return None

	icon = QIcon()
	for size in (16, 20, 24, 32, 40, 48, 64, 128, 256):
		scaled = pixmap.scaled(
			size,
			size,
			Qt.AspectRatioMode.KeepAspectRatio,
			Qt.TransformationMode.SmoothTransformation,
		)
		icon.addPixmap(scaled)
	return icon if not icon.isNull() else None


def _resolve_qrc_path(qrc_path: str) -> str:
    """Resolve a qrc: path to an actual file path"""
    if qrc_path in _resource_map:
        resolved = _resource_map[qrc_path]
        if resolved.exists():
            return str(resolved)
    # Fallback: try to construct path from qrc: format
    if qrc_path.startswith(":/"):
        # Remove leading ":/" and use as relative path
        rel_path = qrc_path[2:]  # Remove ":/"
        resolved = _resource_base / rel_path
        if resolved.exists():
            return str(resolved)
    return qrc_path

# Monkey-patch QIcon to support qrc: paths by resolving to file paths
# This allows QIcon(":/icons/file.svg") to work even without compiled resources
_original_QIcon_init = None

def _patched_QIcon_init(self, *args, **kwargs):
    """Patched QIcon.__init__ to resolve qrc: paths"""
    if args and isinstance(args[0], str) and args[0].startswith(":/"):
        # Resolve qrc: path to file path
        file_path = _resolve_qrc_path(args[0])
        if file_path and Path(file_path).exists():
            # Use file path instead
            _original_QIcon_init(self, file_path, *args[1:], **kwargs)
            return
    # Use original behavior
    _original_QIcon_init(self, *args, **kwargs)

# Apply monkey patch
try:
    from PyQt6.QtGui import QIcon
    _original_QIcon_init = QIcon.__init__
    QIcon.__init__ = _patched_QIcon_init
except Exception:
    pass  # If patching fails, continue without it

def qInitResources():
    """Initialize Qt resources"""
    pass

def qCleanupResources():
    """Cleanup Qt resources"""
    pass

# Auto-initialize
qInitResources()

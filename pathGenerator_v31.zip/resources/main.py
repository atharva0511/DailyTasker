import pyautogui
import time

def press_spacebar():
    print("Script started. Move your cursor to the corner of the screen to abort.")
    try:
        while True:
            # Press the spacebar
            pyautogui.press('space')
            print(f"Spacebar pressed at {time.strftime('%H:%M:%S')}")
            
            # Wait for 6 seconds
            time.sleep(6)
    except KeyboardInterrupt:
        print("\nScript stopped by user.")

if __name__ == "__main__":
    press_spacebar()
"""Application preferences (``preferences.ini`` next to the executable when built)."""

from __future__ import annotations

import configparser
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

DEFAULT_THEME = "dark"
DEFAULT_FONT_SIZE = 10
MIN_FONT_SIZE = 8
MAX_FONT_SIZE = 16

DEFAULT_TCP_ENABLED = True
DEFAULT_TCP_HOST = "127.0.0.1"
DEFAULT_TCP_PORT = 5555
MIN_TCP_PORT = 1
MAX_TCP_PORT = 65535
DEFAULT_TCP_TIMEOUT_S = 300
MIN_TCP_TIMEOUT_S = 1
MAX_TCP_TIMEOUT_S = 3600


@dataclass
class Preferences:
	theme: str = DEFAULT_THEME  # "dark" | "light"
	font_size: int = DEFAULT_FONT_SIZE
	# TCP command server (see MotionStudio.core.remote).
	tcp_enabled: bool = DEFAULT_TCP_ENABLED
	tcp_host: str = DEFAULT_TCP_HOST
	tcp_port: int = DEFAULT_TCP_PORT
	tcp_timeout_s: int = DEFAULT_TCP_TIMEOUT_S

	def normalized(self) -> "Preferences":
		theme = "light" if str(self.theme).lower() == "light" else "dark"
		try:
			size = int(self.font_size)
		except Exception:
			size = DEFAULT_FONT_SIZE
		size = max(MIN_FONT_SIZE, min(MAX_FONT_SIZE, size))

		host = str(self.tcp_host or "").strip() or DEFAULT_TCP_HOST
		try:
			port = int(self.tcp_port)
		except Exception:
			port = DEFAULT_TCP_PORT
		port = max(MIN_TCP_PORT, min(MAX_TCP_PORT, port))
		try:
			timeout = int(self.tcp_timeout_s)
		except Exception:
			timeout = DEFAULT_TCP_TIMEOUT_S
		timeout = max(MIN_TCP_TIMEOUT_S, min(MAX_TCP_TIMEOUT_S, timeout))

		return Preferences(
			theme=theme,
			font_size=size,
			tcp_enabled=bool(self.tcp_enabled),
			tcp_host=host,
			tcp_port=port,
			tcp_timeout_s=timeout,
		)

	def tcp_settings(self) -> tuple:
		"""Comparable tuple of the settings that require a server restart."""
		normalized = self.normalized()
		return (
			normalized.tcp_enabled,
			normalized.tcp_host,
			normalized.tcp_port,
			normalized.tcp_timeout_s,
		)


def application_directory() -> Path:
	"""
	Directory that should hold ``preferences.ini``.

	- Packaged (PyInstaller / frozen): folder containing the executable.
	- Development: repository root (parent of the ``MotionStudio`` package).
	"""
	if getattr(sys, "frozen", False):
		return Path(sys.executable).resolve().parent
	# MotionStudio/core/preferences.py -> parents[2] == repo root
	return Path(__file__).resolve().parents[2]


def preferences_ini_path() -> Path:
	return application_directory() / "preferences.ini"


def load_preferences(path: Optional[Path] = None) -> Preferences:
	"""Load preferences from INI; missing or invalid files yield defaults."""
	ini_path = Path(path) if path is not None else preferences_ini_path()
	prefs = Preferences()
	if not ini_path.is_file():
		return prefs.normalized()
	parser = configparser.ConfigParser()
	try:
		parser.read(ini_path, encoding="utf-8")
	except Exception:
		return prefs.normalized()
	section = "ui"
	if parser.has_section(section):
		if parser.has_option(section, "theme"):
			prefs.theme = parser.get(section, "theme")
		if parser.has_option(section, "font_size"):
			try:
				prefs.font_size = parser.getint(section, "font_size")
			except Exception:
				pass

	tcp = "tcp"
	if parser.has_section(tcp):
		if parser.has_option(tcp, "enabled"):
			try:
				prefs.tcp_enabled = parser.getboolean(tcp, "enabled")
			except Exception:
				pass
		if parser.has_option(tcp, "host"):
			prefs.tcp_host = parser.get(tcp, "host")
		if parser.has_option(tcp, "port"):
			try:
				prefs.tcp_port = parser.getint(tcp, "port")
			except Exception:
				pass
		if parser.has_option(tcp, "timeout_s"):
			try:
				prefs.tcp_timeout_s = parser.getint(tcp, "timeout_s")
			except Exception:
				pass
	return prefs.normalized()


def save_preferences(prefs: Preferences, path: Optional[Path] = None) -> Path:
	"""Write preferences to INI. Returns the path written."""
	ini_path = Path(path) if path is not None else preferences_ini_path()
	normalized = prefs.normalized()
	parser = configparser.ConfigParser()
	parser["ui"] = {
		"theme": normalized.theme,
		"font_size": str(normalized.font_size),
	}
	parser["tcp"] = {
		"enabled": "true" if normalized.tcp_enabled else "false",
		"host": normalized.tcp_host,
		"port": str(normalized.tcp_port),
		"timeout_s": str(normalized.tcp_timeout_s),
	}
	ini_path.parent.mkdir(parents=True, exist_ok=True)
	with ini_path.open("w", encoding="utf-8", newline="\n") as fh:
		parser.write(fh)
	return ini_path


def apply_font_size(point_size: int) -> None:
	"""Set the QApplication default font point size (global UI text)."""
	from PyQt6.QtWidgets import QApplication

	app = QApplication.instance()
	if app is None:
		return
	normalized = Preferences(font_size=point_size).normalized()
	font = app.font()
	font.setPointSize(normalized.font_size)
	app.setFont(font)


def apply_preferences(prefs: Preferences) -> Preferences:
	"""
	Apply theme + font size to the running application.

	Call after ``QApplication`` exists. Re-applies font after theme setup so
	qdarktheme does not leave the previous size behind.
	"""
	from MotionStudio.ui.theme import apply_theme

	normalized = prefs.normalized()
	apply_theme(normalized.theme)
	apply_font_size(normalized.font_size)
	return normalized

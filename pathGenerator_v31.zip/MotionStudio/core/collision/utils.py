"""
Collision query helpers.

Read-only convenience functions over ``ColliderComponent.collided`` after the
scene's ``CollisionSystem`` has run. They do not start a new sweep — call
``scene.collision_system.check_all()`` first when you need fresh flags
(play-routine ticks and Play Mode already do this after component loops).
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity


def entity_is_colliding(entity: Optional["Entity"]) -> bool:
	"""
	Return ``True`` if ``entity`` or any descendant is currently colliding.

	Walks the child tree and reads each ``ColliderComponent.collided`` flag
	from the last ``CollisionSystem.check_all()``. Entities without a collider
	are skipped; ``None`` returns ``False``.
	"""
	# Imported lazily: this module is used by engine components, and importing
	# ColliderComponent at file top would cycle through components/__init__.py.
	from MotionStudio.core.components.collider_component import ColliderComponent

	if entity is None:
		return False

	def walk(node: "Entity") -> bool:
		col = node.get_component(ColliderComponent)
		if col is not None and bool(getattr(col, "collided", False)):
			return True
		for child in node.children:
			if walk(child):
				return True
		return False

	return walk(entity)

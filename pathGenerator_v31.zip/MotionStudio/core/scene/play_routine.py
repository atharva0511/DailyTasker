"""Edit-mode tick routines — lightweight frame loop without Play Mode snapshot.

Components register a bound method via ``Component.start_play_routine``.
Return ``False`` from the loop (or call ``handle.stop()``) to unregister.
"""

from __future__ import annotations

import time
import weakref
from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable, Dict, Optional

from PyQt6.QtCore import QObject, QTimer, pyqtSignal

if TYPE_CHECKING:
	from MotionStudio.core.ecs.component import Component
	from MotionStudio.core.scene.scene import Scene

LoopFn = Callable[[float], bool]


@dataclass
class _ActiveEntry:
	routine_id: int
	loop_fn: LoopFn
	owner_ref: Optional[weakref.ref] = None
	name: str = ""


class PlayRoutineHandle:
	"""Opaque handle returned by ``PlayRoutineRunner.start`` / ``start_play_routine``.

	A handle with ``routine_id < 0`` (or no runner) is inactive: ``is_running`` is
	always ``False`` and ``stop()`` is a no-op.
	"""

	__slots__ = ("_runner", "_routine_id")

	def __init__(
		self,
		runner: Optional["PlayRoutineRunner"],
		routine_id: int,
	) -> None:
		self._runner = runner
		self._routine_id = int(routine_id)

	@property
	def is_running(self) -> bool:
		if self._runner is None or self._routine_id < 0:
			return False
		return self._runner.is_active(self._routine_id)

	def stop(self) -> None:
		if self._runner is None or self._routine_id < 0:
			return
		self._runner.stop(self)


class PlayRoutineRunner(QObject):
	"""Scene service that ticks edit-mode loops (no scene snapshot/restore)."""

	frame_ready = pyqtSignal()
	active_changed = pyqtSignal(bool)

	def __init__(self, scene: "Scene") -> None:
		super().__init__()
		self._scene = scene
		self._active: Dict[int, _ActiveEntry] = {}
		self._next_id = 1
		self._ticking = False
		self._last_frame_time = 0.0
		self._signaled_running = False

	@property
	def active_count(self) -> int:
		return len(self._active)

	def is_active(self, routine_id: int) -> bool:
		return int(routine_id) in self._active

	def start(
		self,
		loop_fn: LoopFn,
		*,
		owner: Optional["Component"] = None,
		name: str = "",
	) -> PlayRoutineHandle:
		"""Register ``loop_fn(dt) -> bool`` and ensure the tick loop is running.

		``loop_fn`` should return ``True`` to continue or ``False`` to stop.
		Refuses while Play Mode is active.
		"""
		if not callable(loop_fn):
			raise TypeError("loop_fn must be callable")

		pm = getattr(self._scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			print(
				"PlayRoutineRunner: refused start while Play Mode is active "
				"(use component.update instead)",
				flush=True,
			)
			# Dead handle so callers can still call .stop() safely.
			return PlayRoutineHandle(self, -1)

		rid = self._next_id
		self._next_id += 1
		owner_ref = weakref.ref(owner) if owner is not None else None
		self._active[rid] = _ActiveEntry(
			routine_id=rid,
			loop_fn=loop_fn,
			owner_ref=owner_ref,
			name=str(name or ""),
		)
		self._ensure_ticking()
		self._sync_running_signal()
		return PlayRoutineHandle(self, rid)

	def stop(self, handle: Optional[PlayRoutineHandle]) -> None:
		if handle is None:
			return
		rid = int(getattr(handle, "_routine_id", -1))
		self._active.pop(rid, None)
		self._sync_running_signal()

	def stop_all(self) -> None:
		self._active.clear()
		self._sync_running_signal()

	def _ensure_ticking(self) -> None:
		if self._ticking:
			return
		if not self._active:
			return
		self._ticking = True
		self._last_frame_time = time.time()
		QTimer.singleShot(0, self._on_tick)

	def _on_tick(self) -> None:
		if not self._active:
			self._ticking = False
			self._sync_running_signal()
			return

		now = time.time()
		delta_time = now - self._last_frame_time
		self._last_frame_time = now
		delta_time = min(max(0.0, delta_time), 0.1)

		for rid in list(self._active.keys()):
			entry = self._active.get(rid)
			if entry is None:
				continue
			if entry.owner_ref is not None and entry.owner_ref() is None:
				self._active.pop(rid, None)
				continue
			try:
				keep = bool(entry.loop_fn(delta_time))
			except Exception as exc:
				label = entry.name or f"id={rid}"
				print(f"PlayRoutineRunner: error in loop '{label}': {exc}", flush=True)
				keep = False
			if not keep:
				self._active.pop(rid, None)

		try:
			self._scene.collision_system.check_all()
		except Exception as exc:
			print(f"PlayRoutineRunner: collision_system.check_all failed: {exc}", flush=True)

		self.frame_ready.emit()

		if self._active:
			QTimer.singleShot(0, self._on_tick)
		else:
			self._ticking = False
		self._sync_running_signal()

	def _sync_running_signal(self) -> None:
		running = bool(self._active)
		if running == self._signaled_running:
			return
		self._signaled_running = running
		self.active_changed.emit(running)

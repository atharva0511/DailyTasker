"""Optional ur_rtde adapter for Universal Robots controllers.

Connect / send-script / disconnect live here so the component can start
without ``ur_rtde`` installed. Callables raise ``UniversalRobotSdkError``
with a user-facing message when the package is missing or a call fails.

Handles are owned by the hardware worker thread only.
"""

from __future__ import annotations

import socket
from typing import Any, Optional, Tuple


RTDE_PORT = 30004


class UniversalRobotSdkError(RuntimeError):
	"""ur_rtde missing, connect failed, or script send failed."""


class UrRtdeSession:
	"""Paired control + receive interfaces for one controller session."""

	__slots__ = ("control", "receive")

	def __init__(self, control: Any, receive: Any) -> None:
		self.control = control
		self.receive = receive


def sdk_available() -> bool:
	return _load_sdk()[0] is not None


def sdk_missing_message() -> str:
	return "ur_rtde is not installed. pip install ur_rtde"


def connect_robot(ip_address: str, timeout_ms: int) -> UrRtdeSession:
	"""Open RTDE receive + control interfaces (worker-thread only)."""
	control_mod, receive_mod, err = _load_sdk()
	if control_mod is None or receive_mod is None:
		raise UniversalRobotSdkError(err or sdk_missing_message())
	ip = str(ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	try:
		timeout = int(timeout_ms)
	except Exception:
		timeout = 10000
	timeout = max(1, timeout)
	_probe_rtde_port(ip, timeout)

	receive = _construct_receive(receive_mod, ip)
	try:
		control = _construct_control(control_mod, ip)
	except Exception:
		disconnect_robot(UrRtdeSession(None, receive))
		raise
	return UrRtdeSession(control, receive)


def disconnect_robot(session: Optional[UrRtdeSession]) -> None:
	if session is None:
		return
	for handle in (session.control, session.receive):
		if handle is None:
			continue
		try:
			if hasattr(handle, "disconnect"):
				handle.disconnect()
		except Exception:
			pass
	session.control = None
	session.receive = None


def send_script_file(session: Optional[UrRtdeSession], abs_script_path: str) -> None:
	"""Send a URScript file to the controller and wait until ur_rtde finishes."""
	if session is None or session.control is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	path = str(abs_script_path or "").strip()
	if not path:
		raise UniversalRobotSdkError("Script path is empty.")
	try:
		ok = session.control.sendCustomScriptFile(path)
	except Exception as exc:
		raise UniversalRobotSdkError(f"Send script failed: {exc}") from exc
	if ok is False:
		raise UniversalRobotSdkError(
			"Controller did not accept the script (timeout, not in Remote Control, "
			"or the file failed to run)."
		)


def get_tcp_pose(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""TCP pose in metres / rotation vector (ur_rtde ``getActualTCPPose``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		pose = session.receive.getActualTCPPose()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualTCPPose failed: {exc}") from exc
	return tuple(float(v) for v in pose)


def get_joints(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""Actual joint positions in radians (ur_rtde ``getActualQ``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		q = session.receive.getActualQ()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualQ failed: {exc}") from exc
	return tuple(float(v) for v in q)


def _probe_rtde_port(ip: str, timeout_ms: int) -> None:
	"""Fail fast if the controller RTDE port is unreachable."""
	try:
		sock = socket.create_connection((ip, RTDE_PORT), timeout=max(0.2, timeout_ms / 1000.0))
		sock.close()
	except OSError as exc:
		raise UniversalRobotSdkError(
			f"Cannot reach {ip}:{RTDE_PORT} (RTDE). Check IP, network, and that "
			f"Polyscope is running. ({exc})"
		) from exc


def _construct_receive(receive_mod: Any, ip: str) -> Any:
	cls = receive_mod.RTDEReceiveInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(f"RTDE receive connect failed: {exc}") from exc
	try:
		if hasattr(handle, "isConnected") and not handle.isConnected():
			raise UniversalRobotSdkError("RTDE receive is not connected.")
	except UniversalRobotSdkError:
		disconnect_robot(UrRtdeSession(None, handle))
		raise
	except Exception:
		pass
	return handle


def _construct_control(control_mod: Any, ip: str) -> Any:
	cls = control_mod.RTDEControlInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(
			f"RTDE control connect failed: {exc}. On e-Series the robot must be "
			f"in Remote Control."
		) from exc
	return handle


def _load_sdk() -> Tuple[Optional[Any], Optional[Any], str]:
	try:
		import rtde_control  # type: ignore
		import rtde_receive  # type: ignore
	except Exception as exc:
		return None, None, f"{sdk_missing_message()} ({exc})"
	if not hasattr(rtde_control, "RTDEControlInterface"):
		return None, None, "ur_rtde is installed but RTDEControlInterface is missing."
	if not hasattr(rtde_receive, "RTDEReceiveInterface"):
		return None, None, "ur_rtde is installed but RTDEReceiveInterface is missing."
	return rtde_control, rtde_receive, ""

"""Registry of live hardware worker sessions.

Only *connected* sessions (a running QThread that owns an SDK / RTDE handle)
are registered — not every hardware component in the scene. On editor quit
or scene clear, ``shutdown_all`` requests a cooperative stop and waits;
it never calls ``QThread.terminate()``.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Protocol, runtime_checkable

HardwareJobListener = Callable[[str, bool, str], None]


class HardwareJobHub:
	"""Fan-out for connect / capture / disconnect / run_script completion."""

	def __init__(self) -> None:
		self._listeners: List[HardwareJobListener] = []

	def add(self, callback: HardwareJobListener) -> None:
		if callback not in self._listeners:
			self._listeners.append(callback)

	def remove(self, callback: HardwareJobListener) -> None:
		try:
			self._listeners.remove(callback)
		except ValueError:
			pass

	def notify(self, kind: str, success: bool, message: str = "") -> None:
		for callback in list(self._listeners):
			try:
				callback(str(kind), bool(success), str(message or ""))
			except Exception:
				pass


@runtime_checkable
class HardwareSession(Protocol):
	"""Main-thread owner of a hardware worker. ``shutdown`` must be idempotent."""

	def shutdown(self) -> None:
		...


class HardwareRuntime:
	"""Scene-owned map of live hardware sessions, keyed by ``{entity_id}:{type_name}``."""

	def __init__(self) -> None:
		self._sessions: Dict[str, HardwareSession] = {}

	def register(self, key: str, session: HardwareSession) -> None:
		if not key:
			return
		existing = self._sessions.get(key)
		if existing is session:
			return
		if existing is not None:
			try:
				existing.shutdown()
			except Exception:
				pass
		self._sessions[key] = session

	def unregister(self, key: str) -> None:
		if not key:
			return
		self._sessions.pop(key, None)

	def shutdown_all(self) -> None:
		"""Stop every registered session. Safe to call more than once."""
		sessions = list(self._sessions.values())
		self._sessions.clear()
		for session in sessions:
			try:
				session.shutdown()
			except Exception:
				pass

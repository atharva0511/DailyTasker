from __future__ import annotations

from typing import TYPE_CHECKING, Annotated, Optional, Tuple

from PyQt6.QtGui import QVector3D

from MotionStudio.core.collision.utils import entity_is_colliding
from MotionStudio.core.components.robot_ik_component import RobotIKComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.transform.utils import set_world_position, world_position
from MotionStudio.ui.inspector.metadata import Order, Range, Tooltip, inspector_button

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene


@register_component
class LiftToSafetyComponent(Component):
	"""Lift the robot IK target along world +Z until the robot is collision-free."""

	type_name = "LiftToSafety"
	category = "Robot"
	description = (
		"<p><b>Lift To Safety</b></p>"
		"<p>Edit-mode helper on the <b>robot root</b> (same entity as RobotIK). "
		"<b>Lift to safety</b> starts a play routine that raises the IK target along "
		"world +Z and re-solves IK each frame until no collider under this robot is "
		"intersecting.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Add this next to <b>RobotIK</b> and assign that component's <b>Target</b>.</li>"
		"<li>Click <b>Lift to safety</b>. The routine stops when the robot is clear, "
		"<b>max_lift_mm</b> is reached, or you click <b>Cancel lift</b>.</li>"
		"<li><b>step_mm</b> is the world-Z increment per frame (scene units are millimetres).</li>"
		"</ul>"
	)

	step_mm: Annotated[
		float,
		Order(10),
		Range(0.1, 100.0, step=0.1, decimals=2),
		Tooltip("World +Z lift increment applied to the IK target each play-routine frame (mm)."),
	] = 5.0

	max_lift_mm: Annotated[
		float,
		Order(20),
		Range(1.0, 10000.0, step=1.0, decimals=1),
		Tooltip("Stop lifting after this total world +Z travel if the robot is still colliding (mm)."),
	] = 500.0

	def __init__(self, step_mm: float = 5.0, max_lift_mm: float = 500.0) -> None:
		self.step_mm = float(step_mm)
		self.max_lift_mm = float(max_lift_mm)
		self._lift_handle = None
		self._lifted_mm = 0.0
		self._saved_ik_enabled: Optional[bool] = None
		self._lift_listeners: list = []
		self._lift_fail_reason: str = ""

	def add_lift_listener(self, callback) -> None:
		if callback not in self._lift_listeners:
			self._lift_listeners.append(callback)

	def remove_lift_listener(self, callback) -> None:
		try:
			self._lift_listeners.remove(callback)
		except ValueError:
			pass

	def _notify_lift_done(self, success: bool, message: str = "") -> None:
		for callback in list(self._lift_listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	@inspector_button(
		"Lift to safety",
		tooltip="Raise the RobotIK target along world +Z until this robot is collision-free",
		order=0,
	)
	def lift_to_safety(self):
		if self._lift_handle is not None and self._lift_handle.is_running:
			return False, "a lift is already running"

		resolved = self._resolve_ik_target()
		if resolved is None:
			return False, "RobotIK target is not configured"

		ik, _target_ent, scene = resolved

		pm = getattr(scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			Debug.warning("LiftToSafety: refused while Play Mode is active.")
			return False, "refused while Play Mode is active"

		try:
			scene.collision_system.check_all()
		except Exception as exc:
			Debug.warning(f"LiftToSafety: collision check failed ({exc}).")
			return False, f"collision check failed ({exc})"

		if not entity_is_colliding(self.entity):
			Debug.log("LiftToSafety: already collision free.")
			return None

		self._lifted_mm = 0.0
		self._lift_fail_reason = ""
		self._saved_ik_enabled = bool(ik.enabled)
		ik.enabled = False
		self._lift_handle = self.start_play_routine(
			self._lift_loop, name="lift_to_safety"
		)
		if self._lift_handle is None or not self._lift_handle.is_running:
			self._restore_ik_enabled()
			return False, "lift did not start"
		return True

	@inspector_button(
		"Cancel lift",
		tooltip="Stop the Lift to safety play routine",
		order=5,
	)
	def cancel_lift(self) -> None:
		if self._lift_handle is not None:
			self._lift_fail_reason = "lift cancelled"
			self._lift_handle.stop()
			self._lift_handle = None
		self._restore_ik_enabled()
		if entity_is_colliding(self.entity):
			self._notify_lift_done(False, self._lift_fail_reason or "lift cancelled")
		else:
			self._notify_lift_done(True, "")

	def _stop_lift(self) -> None:
		self._lift_handle = None
		self._restore_ik_enabled()
		ok = not entity_is_colliding(self.entity)
		message = "" if ok else (self._lift_fail_reason or "still colliding")
		self._notify_lift_done(ok, message)

	def _restore_ik_enabled(self) -> None:
		if self._saved_ik_enabled is None:
			return
		if self.entity is not None:
			ik = self.entity.get_component(RobotIKComponent)
			if ik is not None:
				ik.enabled = bool(self._saved_ik_enabled)
		self._saved_ik_enabled = None

	def _lift_loop(self, _delta_time: float) -> bool:
		# Previous tick already ran check_all after all loops (or the button did).
		if not entity_is_colliding(self.entity):
			Debug.log(
				f"LiftToSafety: collision free after {self._lifted_mm:.1f} mm."
			)
			self._lift_fail_reason = ""
			self._stop_lift()
			return False

		step = max(0.0, float(self.step_mm))
		limit = max(0.0, float(self.max_lift_mm))
		if step <= 0.0:
			Debug.warning("LiftToSafety: step_mm must be greater than 0.")
			self._lift_fail_reason = "step_mm must be greater than 0"
			self._stop_lift()
			return False
		remaining = limit - self._lifted_mm
		if remaining <= 0.0:
			Debug.warning(
				f"LiftToSafety: still colliding after {self._lifted_mm:.1f} mm "
				f"(max_lift_mm={limit:.1f})."
			)
			self._lift_fail_reason = (
				f"still colliding after {self._lifted_mm:.1f} mm"
			)
			self._stop_lift()
			return False
		step = min(step, remaining)

		resolved = self._resolve_ik_target()
		if resolved is None:
			self._lift_fail_reason = "RobotIK target is not configured"
			self._stop_lift()
			return False
		ik, target_ent, scene = resolved

		set_world_position(
			target_ent,
			world_position(target_ent) + QVector3D(0.0, 0.0, step),
		)
		self._lifted_mm += step

		system = getattr(scene, "robot_ik_system", None)
		if system is None:
			Debug.warning("LiftToSafety: no IK system on scene.")
			self._lift_fail_reason = "no IK system on scene"
			self._stop_lift()
			return False
		result = system.solve_sync(ik)
		if result is None:
			Debug.warning("LiftToSafety: IK target/robot not configured.")
			self._lift_fail_reason = "IK target/robot not configured"
			self._stop_lift()
			return False
		if not result.joint_values:
			Debug.warning(
				f"LiftToSafety: IK solve failed ({result.message})."
			)
			self._lift_fail_reason = result.message or "IK solve failed"
			self._stop_lift()
			return False
		return True

	def _resolve_ik_target(
		self,
	) -> Optional[Tuple[RobotIKComponent, Entity, "Scene"]]:
		if self.entity is None:
			Debug.warning("LiftToSafety: no entity.")
			return None
		scene = self.entity.scene
		if scene is None:
			Debug.warning("LiftToSafety: entity is not in a scene.")
			return None
		ik = self.entity.get_component(RobotIKComponent)
		if ik is None:
			Debug.warning("LiftToSafety: add RobotIK on this robot entity.")
			return None
		target = ik.target
		if target is None or not isinstance(target, TransformComponent):
			Debug.warning("LiftToSafety: RobotIK has no Target.")
			return None
		target_ent = target.entity
		if target_ent is None:
			Debug.warning("LiftToSafety: IK Target has no entity.")
			return None
		return ik, target_ent, scene

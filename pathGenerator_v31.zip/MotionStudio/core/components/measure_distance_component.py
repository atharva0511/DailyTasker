from __future__ import annotations

from typing import Annotated, Optional, Tuple

from PyQt6.QtGui import QColor, QVector3D

from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.transform.utils import transform_point
from MotionStudio.ui.inspector.metadata import Order, ReadOnly, Tooltip, VertexPick


_POINT_COLOR = QColor(255, 255, 0)
_LINE_COLOR = QColor(80, 220, 255)
_LABEL_COLOR = QColor(255, 220, 120)


def _format_distance_mm(length: float) -> str:
	return f"{length:.2f} mm"


@register_component
class MeasureDistanceComponent(Component):
	type_name = "MeasureDistance"
	category = "Measure"
	description = (
		"<p><b>Measure Distance</b></p>"
		"<p>Measures the world-space distance between two points. Scene units are millimetres "
		"(1 unit = 1 mm). Pick vertices on any mesh; values are stored in this entity's local frame.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Click <b>Pick</b> next to Point A and Point B, then click a mesh vertex for each.</li>"
		"<li>The read-only <b>distance</b> field shows the result (for example <code>123.45 mm</code>).</li>"
		"<li>While this entity is selected, the viewport draws both points, the connecting line, and a millimetre label "
		"(requires <b>View &rarr; Enable Debug Draw</b>).</li>"
		"<li>You can also type coordinates by hand. Coincident points report <code>0.00 mm</code>.</li>"
		"</ul>"
	)

	point_a: Annotated[QVector3D, VertexPick(), Order(0), Tooltip("First measurement point (pick a mesh vertex)")]
	point_b: Annotated[QVector3D, VertexPick(), Order(10), Tooltip("Second measurement point (pick a mesh vertex)")]
	distance: Annotated[str, ReadOnly(), Order(20), Tooltip("World-space distance in mm")]

	def __init__(self) -> None:
		self.point_a = QVector3D()
		self.point_b = QVector3D()
		self.distance = _format_distance_mm(0.0)

	def on_entity_changed(self) -> None:
		text = self._compute_distance_text()
		if text != self.distance:
			self.distance = text

	def on_viewport_draw(self) -> None:
		if self.entity is None or self.entity.scene is None:
			return
		selection = self.entity.scene.selection
		if selection is None or not selection.is_entity_selected(self.entity):
			return

		world_a, world_b, dist_text = self._world_segment()
		if world_a is None or world_b is None:
			return

		Debug.draw_point(world_a, size=10.0, screen_space=True, color=_POINT_COLOR, opacity=0.9, on_top=False)
		Debug.draw_point(world_b, size=10.0, screen_space=True, color=_POINT_COLOR, opacity=0.9, on_top=False)
		Debug.draw_line(world_a, world_b, color=_LINE_COLOR, width=2.0, opacity=1.0, on_top=True)
		mid = (world_a + world_b) * 0.5
		Debug.draw_label(mid, dist_text, color=_LABEL_COLOR, font_size=14, on_top=True)

	def _compute_distance_text(self) -> str:
		_world_a, _world_b, text = self._world_segment()
		return text

	def _world_segment(self) -> Tuple[Optional[QVector3D], Optional[QVector3D], str]:
		if self.entity is None:
			delta = self.point_b - self.point_a
			return None, None, _format_distance_mm(float(delta.length()))
		world_a = transform_point(self.entity, self.point_a)
		world_b = transform_point(self.entity, self.point_b)
		length = float((world_b - world_a).length())
		return world_a, world_b, _format_distance_mm(length)

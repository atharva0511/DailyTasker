"""Motion planner component — Job entity binding for OMPL / imove backends."""

from __future__ import annotations

from typing import Annotated, Any, Dict, List, Literal, Optional

import numpy as np
from PyQt6.QtGui import QColor, QVector3D

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.robot.ik.ik_frames import project_to_se3, relative_offset_m
from MotionStudio.core.robot.planning.trajectory import JointTrajectory
from MotionStudio.core.robot.planning.trajectory_preview import trajectory_tcp_path_base_mm
from MotionStudio.core.transform.utils import world_matrix
from MotionStudio.ui.inspector.metadata import (
	ColorField,
	Group,
	Header,
	Hidden,
	Order,
	Range,
	Tooltip,
	inspector_button,
)


@register_component
class MotionPlannerComponent(Component):
	"""Plans a joint-space trajectory for a PathGeneration job on a robot.

	Lives on the Job entity (alongside PathGeneration). Planning runs on a
	background thread via ``scene.motion_planning_system``. Play Mode streams
	the persisted trajectory onto ``RobotDescription.joint_positions``.
	"""

	type_name = "MotionPlanner"
	category = "Path generation and planning"
	description = (
		"<p><b>Motion Planner</b></p>"
		"<p>Plans a collision-aware joint-space trajectory for a <b>PathGeneration</b> job "
		"and can play it back in Play Mode. Attach this on the same Job entity as the path "
		"(not on the robot root).</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Choose backend <b>ompl</b> (RRT-Connect) or <b>imove</b> (RRT-Connect or RRT*).</li>"
		"<li>Bind <b>Path</b> and <b>Robot</b> (or leave empty to use a sibling PathGeneration and that path's export robot).</li>"
		"<li>Tune planner settings (time, simplify, edge resolution, iMOVE goal bias / workspace bound) in the gear groups.</li>"
		"<li>Click <b>Plan Motion</b>. Enable <b>Show Planned Path</b> to draw the TCP polyline, and <b>Enabled Playback</b> to stream joints in Play Mode (RobotIK is disabled during play).</li>"
		"</ul>"
	)

	# Ungrouped — top of the main Inspector form.
	backend: Annotated[
		Literal["ompl", "imove"],
		Order(0),
		Tooltip(
			"Motion planner backend. 'ompl' (default): continuous IK on path segments "
			"+ OMPL RRT-Connect transitions (needs OMPL installed). "
			"'imove': same process IK + built-in numpy planner (RRT-Connect or Informed RRT*)."
		),
	] = "ompl"

	path: Annotated[
		Optional[PathComponent],
		Order(10),
		Tooltip(
			"PathGeneration job to plan. If empty, uses PathGeneration on this same entity."
		),
		Group("Bindings"),
	] = None

	robot: Annotated[
		Optional[RobotDescriptionComponent],
		Order(20),
		Tooltip(
			"Robot to plan for. If empty, uses the Robot selected on PathGeneration export."
		),
		Group("Bindings"),
	] = None

	# --- Planner settings: process (shared) ---
	process_sample_spacing_m: Annotated[
		float,
		Order(100),
		Range(0.001, 0.1, step=0.001, decimals=3),
		Header("Process"),
		Tooltip("Cartesian densify spacing along each path segment (metres)"),
		Group("Planner settings"),
	] = 0.01

	max_joint_jump_rad: Annotated[
		float,
		Order(110),
		Range(0.2, 6.28, step=0.05, decimals=2),
		Tooltip(
			"Max wrap-aware ‖Δq‖ (rad L2) between consecutive process samples. "
			"Larger jumps are treated as a sudden config change; the segment is "
			"re-traced from the next start IK branch (0 disables the gate)."
		),
		Group("Planner settings"),
	] = 2.0

	transition_joint_speed_rad_s: Annotated[
		float,
		Order(120),
		Range(0.05, 10.0, step=0.05, decimals=2),
		Tooltip("C-space speed used to time inter-segment transitions (rad/s L2)"),
		Group("Planner settings"),
	] = 1.0

	# --- Planner settings: OMPL ---
	ompl_planning_time_limit_s: Annotated[
		float,
		Order(200),
		Range(0.1, 600.0, step=0.1, decimals=2),
		Header("OMPL"),
		Tooltip("Wall-clock budget per inter-segment OMPL RRT-Connect transition (seconds)"),
		Group("Planner settings"),
	] = 300.0

	ompl_simplify_path: Annotated[
		bool,
		Order(210),
		Tooltip("Simplify OMPL transition paths with PathSimplifier"),
		Group("Planner settings"),
	] = True

	ompl_rrt_edge_resolution_rad: Annotated[
		float,
		Order(220),
		Range(0.01, 0.25, step=0.005, decimals=3),
		Tooltip(
			"C-space edge sample spacing for OMPL state validity / densify (rad L2). "
			"Finer catches thin colliders; coarser plans faster."
		),
		Group("Planner settings"),
	] = 0.05

	# --- Planner settings: iMOVE ---
	imove_algorithm: Annotated[
		Literal["RRT-Connect", "RRT*"],
		Order(300),
		Header("iMOVE"),
		Tooltip(
			"imove transition algorithm. RRT-Connect: bidirectional tree growth. "
			"RRT*: Informed RRT* with rewiring and ellipsoid sampling after the first path."
		),
		Group("Planner settings"),
	] = "RRT-Connect"

	imove_planning_time_limit_s: Annotated[
		float,
		Order(310),
		Range(0.1, 600.0, step=0.1, decimals=2),
		Tooltip("Wall-clock budget per inter-segment imove transition (seconds)"),
		Group("Planner settings"),
	] = 300.0

	imove_simplify_path: Annotated[
		bool,
		Order(320),
		Tooltip(
			"After RRT, prune transition paths in C-space (~100 random shortcuts): "
			"connect non-adjacent waypoints with a direct free edge and drop "
			"intermediates; then greedy + partial/Steiner polish. Reserves part of "
			"the planning time budget so shortcutting always runs."
		),
		Group("Planner settings"),
	] = True

	imove_rrt_edge_resolution_rad: Annotated[
		float,
		Order(330),
		Range(0.01, 0.25, step=0.005, decimals=3),
		Tooltip(
			"C-space edge sample spacing for imove RRT validity / shortcutting (rad L2). "
			"Finer catches thin colliders; coarser plans faster. Also used to densify "
			"transition playback samples."
		),
		Group("Planner settings"),
	] = 0.05

	imove_goal_bias: Annotated[
		float,
		Order(340),
		Range(0.0, 1.0, step=0.01, decimals=2),
		Tooltip(
			"Probability of sampling the goal configuration each RRT iteration "
			"(RRT-Connect and RRT*). Higher values grow toward the goal faster; "
			"lower values explore more. Clamped so goal + line bias ≤ 1."
		),
		Group("Planner settings"),
	] = 0.25

	imove_workspace_bound_diameter: Annotated[
		float,
		Order(350),
		Range(1.0, 5.0, step=0.1, decimals=2),
		Tooltip(
			"Workspace proximity sphere for imove RRT samples (TCP FK). "
			"Diameter = this value × the job bounding-box diagonal. "
			"1 means the sphere diameter equals the job AABB diagonal; "
			"larger values allow wider detours. Samples whose TCP lands outside "
			"are rejected before collision checks (helps avoid huge arch routes)."
		),
		Group("Planner settings"),
	] = 1.0

	enabled_playback: Annotated[
		bool,
		Order(400),
		Tooltip("When Play Mode starts, stream the planned joint trajectory onto the robot"),
		Group("Preview"),
	] = True

	show_planned_path: Annotated[
		bool,
		Order(410),
		Tooltip("Draw the planned TCP path (FK of joint trajectory) as a blue debug polyline"),
		Group("Preview"),
	] = True

	planned_path_color: Annotated[
		QColor,
		Order(420),
		ColorField(alpha=False),
		Tooltip("Color of the planned TCP path overlay"),
		Group("Preview"),
	] = QColor.fromRgbF(0.1, 0.35, 1.0)

	planned_path_width: Annotated[
		float,
		Order(430),
		Range(0.5, 20.0, step=0.5, decimals=2),
		Tooltip("Line width of the planned TCP path overlay"),
		Group("Preview"),
	] = 5.0

	status: Annotated[
		str,
		Tooltip("Last planning status"),
		Group("Planner settings"),
		Hidden(),
	] = ""

	def __init__(self) -> None:
		self.path = None
		self.robot = None
		self.backend = "ompl"
		self.process_sample_spacing_m = 0.01
		self.max_joint_jump_rad = 2.0
		self.transition_joint_speed_rad_s = 1.0
		self.ompl_planning_time_limit_s = 60.0
		self.ompl_simplify_path = True
		self.ompl_rrt_edge_resolution_rad = 0.05
		self.imove_algorithm = "RRT*"
		self.imove_planning_time_limit_s = 60.0
		self.imove_simplify_path = True
		self.imove_rrt_edge_resolution_rad = 0.05
		self.imove_goal_bias = 0.15
		self.imove_workspace_bound_diameter = 1.0
		self.enabled_playback = True
		self.show_planned_path = True
		self.planned_path_color = QColor.fromRgbF(0.1, 0.35, 1.0)
		self.planned_path_width = 5.0
		self.status = ""
		self._trajectory = JointTrajectory()
		# Play-only state (not serialized)
		self._play_t = 0.0
		self._play_done = False
		self._saved_ik_enabled: Optional[bool] = None
		# Cached TCP path in robot-base millimetres (recomputed when trajectory changes).
		self._tcp_path_base_mm: List[QVector3D] = []

	# ------------------------------------------------------------------ active knobs

	def active_planning_time_limit_s(self) -> float:
		if str(self.backend).strip().lower() == "imove":
			return float(self.imove_planning_time_limit_s)
		return float(self.ompl_planning_time_limit_s)

	def active_simplify_path(self) -> bool:
		if str(self.backend).strip().lower() == "imove":
			return bool(self.imove_simplify_path)
		return bool(self.ompl_simplify_path)

	def active_rrt_edge_resolution_rad(self) -> float:
		if str(self.backend).strip().lower() == "imove":
			return float(self.imove_rrt_edge_resolution_rad)
		return float(self.ompl_rrt_edge_resolution_rad)

	# ------------------------------------------------------------------ trajectory

	@property
	def trajectory(self) -> JointTrajectory:
		return self._trajectory

	def set_trajectory(self, traj: JointTrajectory) -> None:
		self._trajectory = traj if traj is not None else JointTrajectory()
		self._rebuild_tcp_path_preview()

	def clear_trajectory(self) -> None:
		self._trajectory = JointTrajectory()
		self._tcp_path_base_mm = []
		self.status = "Cleared"

	def _resolve_T_ee_tcp(self, rd: RobotDescriptionComponent) -> np.ndarray:
		"""tool_link → TCP offset in metres (identity when no TCP is bound)."""
		T = np.eye(4, dtype=np.float64)
		robot_ent = rd.entity
		if robot_ent is None or robot_ent.scene is None:
			return T
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		ik = robot_ent.get_component(RobotIKComponent)
		if ik is None:
			return T
		tcp_ref = getattr(ik, "tcp", None)
		tcp_ent = None
		if tcp_ref is not None:
			if hasattr(tcp_ref, "entity"):
				tcp_ent = tcp_ref.entity
			elif isinstance(tcp_ref, str):
				tcp_ent = robot_ent.scene.find_by_id(tcp_ref)
		if tcp_ent is None:
			return T
		ee_id = rd.find_link_entity_id(rd.tool_link)
		ee_ent = robot_ent.scene.find_by_id(ee_id) if ee_id else None
		if ee_ent is None:
			return T
		try:
			return project_to_se3(relative_offset_m(ee_ent, tcp_ent))
		except Exception:
			return T

	def _rebuild_tcp_path_preview(self) -> None:
		self._tcp_path_base_mm = []
		if self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None:
			return
		self._tcp_path_base_mm = trajectory_tcp_path_base_mm(
			self._trajectory,
			root_link=str(rd.root_link),
			tool_link=str(rd.tool_link),
			joints=list(rd.joints),
			T_ee_tcp=self._resolve_T_ee_tcp(rd),
		)

	# ------------------------------------------------------------------ resolve refs

	def _resolved_path(self) -> Optional[PathComponent]:
		value = self.path
		if isinstance(value, PathComponent):
			return value
		entity = self.entity
		if entity is None:
			return None
		if isinstance(value, str) and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(PathComponent)
				if comp is not None:
					self.path = comp
					return comp
		# Sibling fallback
		return entity.get_component(PathComponent)

	def _resolved_robot(self) -> Optional[RobotDescriptionComponent]:
		value = self.robot
		if isinstance(value, RobotDescriptionComponent):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if comp is not None:
					self.robot = comp
					return comp
		path = self._resolved_path()
		if path is not None:
			return path._resolved_robot()
		return None

	# ------------------------------------------------------------------ inspector

	@inspector_button(
		"Plan Motion",
		tooltip="Plan joint trajectory for the bound path + robot",
		# group="Planner settings",
		order=500,
	)
	def plan_motion(self):
		entity = self.entity
		if entity is None or entity.scene is None:
			return False, "no entity in a scene"
		system = getattr(entity.scene, "motion_planning_system", None)
		if system is None:
			return False, "motion planning system unavailable"
		if system.is_busy(entity.id):
			from PyQt6.QtWidgets import QMessageBox

			QMessageBox.information(None, "Plan Motion", "A plan is already running for this job.")
			return False, "a plan is already running for this job"
		system.submit_plan(self)

	@inspector_button(
		"Clear Trajectory",
		tooltip="Remove the stored joint trajectory",
		# group="Planner settings",
		order=510,
	)
	def clear_motion_trajectory(self) -> None:
		self.clear_trajectory()

	# ------------------------------------------------------------------ viewport / debug

	def on_viewport_draw(self) -> None:
		"""Draw the planned TCP path as a thick blue polyline (one-frame Debug)."""
		if not self.show_planned_path:
			return
		if len(self._tcp_path_base_mm) < 2 and not self._trajectory.is_empty():
			self._rebuild_tcp_path_preview()
		if len(self._tcp_path_base_mm) < 2:
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None:
			return
		wm = world_matrix(rd.entity)
		world_pts = [wm.map(p) for p in self._tcp_path_base_mm]
		Debug.draw_polyline(
			world_pts,
			color=self.planned_path_color,
			opacity=0.5,
			width=float(self.planned_path_width),
			on_top=True,
		)

	# ------------------------------------------------------------------ play mode

	def start(self) -> None:
		self._play_t = 0.0
		self._play_done = False
		self._saved_ik_enabled = None
		if not self.enabled_playback or self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None:
			return
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		ik = rd.entity.get_component(RobotIKComponent)
		if ik is not None:
			self._saved_ik_enabled = bool(ik.enabled)
			ik.enabled = False

	def update(self, delta_time: float) -> None:
		if not self.enabled_playback or self._play_done or self._trajectory.is_empty():
			return
		rd = self._resolved_robot()
		if rd is None or rd.entity is None or rd.entity.scene is None:
			return
		self._play_t += float(delta_time)
		joints = self._trajectory.sample_at(self._play_t)
		if joints is None:
			return
		ik_system = rd.entity.scene.robot_ik_system
		ik_system.apply_solution(rd.entity.id, joints)
		if self._play_t >= self._trajectory.duration:
			self._play_done = True

	# ------------------------------------------------------------------ serialize

	def to_dict(self) -> Dict[str, Any]:
		data = super().to_dict()
		data["trajectory"] = self._trajectory.to_dict()
		return data

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "MotionPlannerComponent":
		inst = super().from_dict(data)
		# Migrate pre-section field names onto OMPL + iMOVE knobs.
		# May load locked; force_setattr so migrations are not blocked.
		if "planning_time_limit_s" in data:
			legacy = float(data["planning_time_limit_s"])
			if "ompl_planning_time_limit_s" not in data:
				inst.force_setattr("ompl_planning_time_limit_s", legacy)
			if "imove_planning_time_limit_s" not in data:
				inst.force_setattr("imove_planning_time_limit_s", legacy)
		if "simplify_path" in data:
			legacy_b = bool(data["simplify_path"])
			if "ompl_simplify_path" not in data:
				inst.force_setattr("ompl_simplify_path", legacy_b)
			if "imove_simplify_path" not in data:
				inst.force_setattr("imove_simplify_path", legacy_b)
		if "rrt_edge_resolution_rad" in data:
			legacy_r = float(data["rrt_edge_resolution_rad"])
			if "ompl_rrt_edge_resolution_rad" not in data:
				inst.force_setattr("ompl_rrt_edge_resolution_rad", legacy_r)
			if "imove_rrt_edge_resolution_rad" not in data:
				inst.force_setattr("imove_rrt_edge_resolution_rad", legacy_r)
		traj_data = data.get("trajectory")
		if isinstance(traj_data, dict):
			inst._trajectory = JointTrajectory.from_dict(traj_data)
		else:
			inst._trajectory = JointTrajectory()
		# Rebuild preview after load (robot may resolve later on first draw).
		inst._tcp_path_base_mm = []
		return inst

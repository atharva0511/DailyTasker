from __future__ import annotations
from typing import Annotated, ClassVar, Dict, List, Literal, Optional, Tuple
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Tooltip
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.path_component import PathComponent
from PyQt6.QtGui import QVector3D, QColor, QQuaternion

@register_component
class ToolTraceComponent(Component):
    type_name = "ToolTrace"
    category = "Simulation"
    description = (
        "<p><b>Tool Trace</b></p>"
        "<p>Play Mode helper that moves this entity along a PathGeneration waypoint "
        "sequence so you can preview a tool / TCP trace.</p>"
        "<p><b>How to use</b></p>"
        "<ul>"
        "<li>Assign <b>path</b> to the Job entity that owns PathGeneration.</li>"
        "<li>Set <b>speed</b> (units per second along the waypoint list).</li>"
        "<li>Press Play. The entity interpolates through world waypoint poses until the path ends.</li>"
        "<li>For planned joint playback on a robot, use <b>MotionPlanner</b> instead of this component.</li>"
        "</ul>"
    )

    speed: Annotated[float,Tooltip("A floating point value (QDoubleSpinBox)")] = 5.0

    path: Annotated[Optional[PathComponent],Tooltip("Target transform component")] = None

    def __init__(self) -> None:
        # Example annotated fields with widget mapping for Inspector auto-UI
        self.path = None
        self._waypoint_transforms: List[Tuple[float, float, float, float, float, float]] = []
        self._current_waypoint_index = 0
        self._start_rot = QQuaternion.fromEulerAngles(0.0, 0.0, 0.0)
        self._start_pos = QVector3D(0.0, 0.0, 0.0)

    def get_waypoint_transforms(self) -> List[Tuple[float, float, float, float, float, float]]:
        if self.path is None:
            return []
        return self.path.get_world_waypoint_transforms()

    def start(self) -> None:
        self._waypoint_transforms = self.get_waypoint_transforms()
        self._current_waypoint_index = 0

    def update(self, delta_time: float):
        transform = self.entity.get_component(TransformComponent)
        mesh = self.entity.get_component(MeshComponent)
        # if mesh is not None:
        #     mesh.color = self.color
        if transform is not None:
            if len(self._waypoint_transforms) > 0:
                wp = self._waypoint_transforms[self._current_waypoint_index]
                # calculate the progress of the tool along the path (0 to 1)
                t = (transform.position - self._start_pos).length() / (QVector3D(float(wp[0]), float(wp[1]), float(wp[2])) - self._start_pos).length()
                target_rot = QQuaternion.fromEulerAngles(float(wp[3]), float(wp[4]), float(wp[5]))
                dir = QVector3D.normalized(QVector3D(float(wp[0]), float(wp[1]), float(wp[2])) - transform.position)
                transform.position = transform.position + dir * delta_time*self.speed
                transform.rotation_quat = QQuaternion.slerp(self._start_rot, target_rot, t)
                # check if tool reached the next waypoint
                if (transform.position - QVector3D(float(wp[0]), float(wp[1]), float(wp[2]))).length() < self.speed*delta_time:
                    self._current_waypoint_index = (self._current_waypoint_index + 1) % len(self._waypoint_transforms)
                    self._start_pos = transform.position
                    self._start_rot = transform.rotation_quat
        
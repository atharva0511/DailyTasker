"""Universal Robots controller hardware component.

Connect and Run Script run on a dedicated QThread that owns ur_rtde
control + receive handles. Optional ``robot`` links a virtual
``RobotDescription`` for later pose/joint streaming.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any, Dict, Optional, TYPE_CHECKING

from PyQt6.QtCore import QMutex, QMutexLocker, QObject, QThread, QWaitCondition, pyqtSignal

from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.hardwares.hardware_runtime import HardwareJobHub
from MotionStudio.core.hardwares.universal_robot_sdk import (
	UniversalRobotSdkError,
	UrRtdeSession,
	connect_robot,
	disconnect_robot,
	sdk_available,
	sdk_missing_message,
	send_script_file,
)
from MotionStudio.ui.inspector.metadata import (
	FilePath,
	Group,
	Order,
	Range,
	ReadOnly,
	Tooltip,
	inspector_button,
)

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene


STATUS_DISCONNECTED = "Disconnected"
STATUS_CONNECTING = "Connecting…"
STATUS_CONNECTED = "Connected"
STATUS_RUNNING_SCRIPT = "Running script…"
STATUS_DISCONNECTING = "Disconnecting…"


class _UrJob:
	__slots__ = ("kind", "ip_address", "timeout_ms", "script_path")

	def __init__(
		self,
		kind: str,
		*,
		ip_address: str = "",
		timeout_ms: int = 10000,
		script_path: str = "",
	) -> None:
		self.kind = kind
		self.ip_address = ip_address
		self.timeout_ms = timeout_ms
		self.script_path = script_path


class _UniversalRobotWorker(QThread):
	"""Owns ur_rtde handles; processes connect / disconnect / run_script jobs."""

	job_succeeded = pyqtSignal(str, str)
	job_failed = pyqtSignal(str, str)

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		self._pending: Optional[_UrJob] = None
		self._stop = False
		self._session: Optional[UrRtdeSession] = None

	def submit(self, job: _UrJob) -> None:
		with QMutexLocker(self._mutex):
			self._pending = job
			self._wait.wakeOne()

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._pending = None
			self._wait.wakeOne()
		self.wait(8000)

	def run(self) -> None:
		while True:
			with QMutexLocker(self._mutex):
				while self._pending is None and not self._stop:
					self._wait.wait(self._mutex)
				if self._stop:
					break
				job = self._pending
				self._pending = None
			if job is None:
				continue
			self._run_job(job)
		disconnect_robot(self._session)
		self._session = None

	def _run_job(self, job: _UrJob) -> None:
		kind = job.kind
		try:
			if kind == "connect":
				disconnect_robot(self._session)
				self._session = None
				self._session = connect_robot(job.ip_address, job.timeout_ms)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "disconnect":
				disconnect_robot(self._session)
				self._session = None
				self.job_succeeded.emit(kind, STATUS_DISCONNECTED)
			elif kind == "run_script":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				send_script_file(self._session, job.script_path)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			else:
				raise UniversalRobotSdkError(f"Unknown job: {kind}")
		except UniversalRobotSdkError as exc:
			self.job_failed.emit(kind, str(exc))
		except Exception as exc:
			self.job_failed.emit(kind, str(exc))


class _UrWorkerHost(QObject):
	"""Main-thread owner of the worker thread (signals must land here)."""

	def __init__(self, component: "UniversalRobotComponent") -> None:
		super().__init__()
		self._component = component
		self._stopped = False
		self.worker = _UniversalRobotWorker()
		self.worker.job_succeeded.connect(self._on_ok)
		self.worker.job_failed.connect(self._on_fail)
		self.worker.start()

	def _on_ok(self, kind: str, message: str) -> None:
		self._component._on_worker_ok(kind, message)

	def _on_fail(self, kind: str, error: str) -> None:
		self._component._on_worker_fail(kind, error)

	def shutdown(self) -> None:
		if self._stopped:
			return
		self._stopped = True
		try:
			self.worker.job_succeeded.disconnect(self._on_ok)
			self.worker.job_failed.disconnect(self._on_fail)
		except Exception:
			pass
		self.worker.stop()


@register_component
class UniversalRobotComponent(Component):
	type_name = "UniversalRobot"
	category = "Hardware/Robots"
	description = (
		"<p><b>Universal Robot</b></p>"
		"<p>Connects to a Universal Robots controller (ur_rtde) and can send a "
		"<code>.script</code> file to run on the robot. Link a virtual "
		"<b>RobotDescription</b> for later joint/TCP streaming.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Install <code>ur_rtde</code> (<code>pip install ur_rtde</code>).</li>"
		"<li>Put the e-Series teach pendant in <b>Remote Control</b>.</li>"
		"<li>Open <b>Connection Settings</b>, set the controller <b>IP address</b>, "
		"then click <b>Connect</b>.</li>"
		"<li>Optionally assign <b>robot</b> to the virtual URDF root "
		"(<b>RobotDescription</b>).</li>"
		"<li>Open <b>Run Script</b>, pick a <code>.script</code> file, then <b>RUN</b>.</li>"
		"</ul>"
	)

	ip_address: Annotated[
		str,
		Group("Connection Settings"),
		Order(0),
		Tooltip("IPv4 address of the UR controller (same subnet as this PC)."),
	]
	timeout_ms: Annotated[
		int,
		Group("Connection Settings"),
		Order(10),
		Range(1000, 60000, step=1000),
		Tooltip("Connect probe timeout in milliseconds (RTDE port 30004)."),
	]
	connection_status: Annotated[
		str,
		ReadOnly(),
		Order(40),
		Tooltip("Live connection state. Not restored from the scene file."),
	]
	robot: Annotated[
		Optional[RobotDescriptionComponent],
		Order(50),
		Tooltip(
			"Virtual robot (RobotDescription) linked to this controller. "
			"Unused by Run Script; reserved for joint/TCP streaming."
		),
	]
	script_path: Annotated[
		str,
		FilePath("URScript (*.script);;All Files (*.*)"),
		Group("Run Script"),
		Order(60),
		Tooltip("URScript file to send to the controller (project-relative or absolute)."),
	]

	def __init__(
		self,
		ip_address: str = "192.168.0.1",
		timeout_ms: int = 10000,
		script_path: str = "",
	) -> None:
		self.ip_address = str(ip_address or "192.168.0.1")
		try:
			self.timeout_ms = int(timeout_ms)
		except Exception:
			self.timeout_ms = 10000
		self.connection_status = STATUS_DISCONNECTED
		self.robot = None
		self.script_path = str(script_path or "")
		self._busy = False
		self._host: Optional[_UrWorkerHost] = None
		self._bound_scene: Optional["Scene"] = None
		self._hw_session_key: Optional[str] = None
		self._was_connected = False
		self._job_hub = HardwareJobHub()

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "UniversalRobotComponent":
		inst = super().from_dict(data)
		inst.force_setattr("connection_status", STATUS_DISCONNECTED)
		return inst

	def add_job_listener(self, callback) -> None:
		self._job_hub.add(callback)

	def remove_job_listener(self, callback) -> None:
		self._job_hub.remove(callback)

	@inspector_button(
		"Connect",
		tooltip="Connect to the UR controller via ur_rtde (background thread)",
		order=20,
		group="Connection Settings",
	)
	def connect_robot(self):
		if self._busy:
			return False, "robot is busy"
		if not sdk_available():
			self.connection_status = f"Error: {sdk_missing_message()}"
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_CONNECTING
		self._ensure_host().worker.submit(
			_UrJob(
				"connect",
				ip_address=str(self.ip_address or "").strip(),
				timeout_ms=int(self.timeout_ms),
			)
		)
		return True

	@inspector_button(
		"Disconnect",
		tooltip="Disconnect from the UR controller",
		order=30,
		group="Connection Settings",
	)
	def disconnect_robot(self):
		if self._busy:
			return False, "robot is busy"
		if self._host is None:
			self.connection_status = STATUS_DISCONNECTED
			self._was_connected = False
			return None
		self._busy = True
		self.connection_status = STATUS_DISCONNECTING
		self._host.worker.submit(_UrJob("disconnect"))
		return True

	@inspector_button(
		"RUN",
		tooltip="Send the selected .script file to the connected controller",
		order=70,
		group="Run Script",
	)
	def run_script(self):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		abs_path = self._resolve_script_path()
		if abs_path is None:
			self.connection_status = "Error: Assign a valid .script file in Run Script."
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_RUNNING_SCRIPT
		self._ensure_host().worker.submit(_UrJob("run_script", script_path=str(abs_path)))
		return True

	def _on_worker_ok(self, kind: str, message: str) -> None:
		self._busy = False
		if kind == "connect":
			self._was_connected = True
			self.connection_status = message or STATUS_CONNECTED
		elif kind == "disconnect":
			self._was_connected = False
			self.connection_status = STATUS_DISCONNECTED
		elif kind == "run_script":
			self._was_connected = True
			self.connection_status = message or STATUS_CONNECTED
		self._job_hub.notify(kind, True, self.connection_status)

	def _on_worker_fail(self, kind: str, error: str) -> None:
		self._busy = False
		if kind in ("connect", "disconnect"):
			self._was_connected = False
		self.connection_status = f"Error: {error}"
		self._job_hub.notify(kind, False, self.connection_status)

	def _ensure_host(self) -> _UrWorkerHost:
		if self._host is None:
			self._host = _UrWorkerHost(self)
			self._register_hardware_session()
		return self._host

	def _session_key(self) -> str:
		entity = self.entity
		eid = entity.id if entity is not None else "unbound"
		return f"{eid}:{self.type_name}"

	def _register_hardware_session(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is None or self._host is None:
			return
		key = self._session_key()
		self._hw_session_key = key
		scene.hardware_runtime.register(key, self._host)

	def _unregister_hardware_session(self) -> None:
		key = self._hw_session_key
		self._hw_session_key = None
		scene = self._bound_scene
		entity = self.entity
		if entity is not None and entity.scene is not None:
			scene = entity.scene
		if scene is None or not key:
			return
		scene.hardware_runtime.unregister(key)

	def _shutdown_host(self) -> None:
		self._unregister_hardware_session()
		host = self._host
		self._host = None
		self._busy = False
		self._was_connected = False
		if host is not None:
			try:
				host.shutdown()
			except Exception:
				pass

	def _bind_scene(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is self._bound_scene:
			return
		self._unbind_scene()
		if scene is None:
			return
		try:
			scene.events.entity_removed.connect(self._on_entity_removed)
			scene.events.entity_changed.connect(self._on_owning_entity_changed)
		except Exception:
			return
		self._bound_scene = scene

	def _unbind_scene(self) -> None:
		scene = self._bound_scene
		self._bound_scene = None
		if scene is None:
			return
		try:
			scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		try:
			scene.events.entity_changed.disconnect(self._on_owning_entity_changed)
		except Exception:
			pass

	def _on_entity_removed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None or entity.id != entity_id:
			return
		self._teardown()

	def _on_owning_entity_changed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None:
			self._teardown()
			return
		if entity.id != entity_id:
			return
		if self not in getattr(entity, "components", []):
			self._teardown()

	def _teardown(self) -> None:
		self._unbind_scene()
		self._shutdown_host()
		self.connection_status = STATUS_DISCONNECTED

	def _resolve_script_path(self) -> Optional[Path]:
		raw = str(self.script_path or "").strip()
		if not raw:
			return None
		p = Path(raw)
		if p.is_file():
			return p.resolve()
		entity = self.entity
		scene = entity.scene if entity is not None else None
		root = scene.project_root if scene is not None else None
		if root is not None:
			cand = (Path(root) / raw).resolve()
			if cand.is_file():
				return cand
		return None

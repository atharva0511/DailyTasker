from __future__ import annotations

from typing import Annotated, Any, Dict, Tuple

from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Range, Tooltip


@register_component
class TransformComponent(Component):
	type_name = "Transform"
	category = "Others"
	description = (
		"<p><b>Transform</b></p>"
		"<p>Local position, rotation, and scale of this entity relative to its parent "
		"(or the world, if it is a root). Every visible object needs a Transform.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Edit <b>position</b> / <b>rotation</b> / <b>scale</b> here, or drag the viewport gizmos.</li>"
		"<li>Rotation is Euler XYZ in degrees. Scale is per-axis; 1 is unscaled.</li>"
		"<li>Child entities inherit this pose. Reparent in the Hierarchy to change the local frame.</li>"
		"<li>This component cannot be removed.</li>"
		"</ul>"
	)

	# Inspector field declarations (Unity-like)
	position: Annotated[QVector3D, Tooltip("Local position")]
	rotation: Annotated[QVector3D, Tooltip("Local rotation (Euler degrees, XYZ)")]
	scale: Annotated[QVector3D, Tooltip("Local scale")]

	def __setattr__(self, name: str, value: Any) -> None:
		"""
		Override to prevent Component.__setattr__ from emitting entity_changed
		for transform properties. Transform properties emit entity_transform_changed
		via their setters instead.
		"""
		# Transform property names that should skip entity_changed emission
		transform_props = {"position", "rotation", "scale", "rotation_quat", "euler_deg", "scale3d"}
		
		# If this is a transform property (and it's actually a property, not a plain attribute),
		# we need to prevent Component.__setattr__ from emitting entity_changed.
		# The property setter will handle emitting entity_transform_changed.
		if name in transform_props:
			# Check if this is actually a property (not a plain attribute)
			cls = self.__class__
			attr = getattr(cls, name, None)
			if isinstance(attr, property) and attr.fset is not None:
				# It's a property with a setter. When setattr is called, it will invoke the property setter.
				# The property setter will emit entity_transform_changed.
				# We need to prevent Component.__setattr__ from also emitting entity_changed.
				# Since setattr on a property calls the setter directly (not __setattr__),
				# the issue must be that the class-level annotation is creating an attribute
				# that can be set, which triggers __setattr__.
				# Solution: Check if we're setting the property name itself (not the private attribute),
				# and if so, call the property setter directly to bypass __setattr__.
				try:
					attr.fset(self, value)
					return  # Skip calling parent __setattr__ to prevent entity_changed emission
				except Exception:
					# If property setter fails, fall through to normal __setattr__
					pass
		
		# For everything else (including private attributes), use parent __setattr__
		super().__setattr__(name, value)

	def __init__(
		self,
		position: QVector3D | None = None,
		rotation: QVector3D | None = None,
		scale: QVector3D | None = None,
		*,
		# Backwards-compatible aliases (older code + scene files may still use these names)
		euler_deg: Tuple[float, float, float] | None = None,
		scale3d: QVector3D | None = None,
	) -> None:
		self._position = position or QVector3D(0.0, 0.0, 0.0)
		# Rotation: prefer `rotation` (QVector3D degrees), fallback to `euler_deg` (tuple degrees)
		if rotation is None and euler_deg is None:
			self._rotation_quat = QQuaternion.fromEulerAngles(0.0, 0.0, 0.0)
		elif rotation is not None:
			self._rotation_quat = QQuaternion.fromEulerAngles(float(rotation.x()), float(rotation.y()), float(rotation.z()))
		else:
			self._rotation_quat = QQuaternion.fromEulerAngles(float(euler_deg[0]), float(euler_deg[1]), float(euler_deg[2]))

		# Scale: prefer `scale`, fallback to `scale3d`
		if scale is None and scale3d is None:
			self._scale3d = QVector3D(1.0, 1.0, 1.0)
		elif scale is not None:
			self._scale3d = scale
		else:
			self._scale3d = scale3d

	@property
	def position(self) -> QVector3D:
		return self._position

	@position.setter
	def position(self, value: QVector3D) -> None:
		if not self._writes_allowed():
			return
		if self._position == value:
			return
		self._position = value
		# Property setters bypass __setattr__, and we set private attributes (_position)
		# which __setattr__ ignores, so we must emit signal here
		if self.entity and self.entity.scene:
			self.entity.scene.events.entity_transform_changed.emit(self.entity.id)

	@property
	def rotation_quat(self) -> QQuaternion:
		return self._rotation_quat

	@rotation_quat.setter
	def rotation_quat(self, value: QQuaternion) -> None:
		if not self._writes_allowed():
			return
		if self._rotation_quat == value:
			return
		self._rotation_quat = value
		# Property setters bypass __setattr__, and we set private attributes (_rotation_quat)
		# which __setattr__ ignores, so we must emit signal here
		if self.entity and self.entity.scene:
			self.entity.scene.events.entity_transform_changed.emit(self.entity.id)

	@property
	def euler_deg(self) -> Tuple[float, float, float]:
		# Qt stores rotation internally as quaternion, convert to Euler XYZ (pitch, yaw, roll)
		euler = self._rotation_quat.toEulerAngles()
		return (euler.x(), euler.y(), euler.z())

	@euler_deg.setter
	def euler_deg(self, value: Tuple[float, float, float]) -> None:
		if not self._writes_allowed():
			return
		new_quat = QQuaternion.fromEulerAngles(*value)
		if self._rotation_quat == new_quat:
			return
		self._rotation_quat = new_quat
		# Property setters bypass __setattr__, and we set private attributes (_rotation_quat)
		# which __setattr__ ignores, so we must emit signal here
		if self.entity and self.entity.scene:
			self.entity.scene.events.entity_transform_changed.emit(self.entity.id)

	@property
	def rotation(self) -> QVector3D:
		"""
		Alias for euler rotation in degrees, exposed as QVector3D for the auto-inspector.
		"""
		e = self.euler_deg
		return QVector3D(float(e[0]), float(e[1]), float(e[2]))

	@rotation.setter
	def rotation(self, value: QVector3D) -> None:
		self.euler_deg = (float(value.x()), float(value.y()), float(value.z()))

	@property
	def scale3d(self) -> QVector3D:
		return self._scale3d

	@scale3d.setter
	def scale3d(self, value: QVector3D) -> None:
		if not self._writes_allowed():
			return
		if self._scale3d == value:
			return
		self._scale3d = value
		# Property setters bypass __setattr__, and we set private attributes (_scale3d)
		# which __setattr__ ignores, so we must emit signal here
		if self.entity and self.entity.scene:
			self.entity.scene.events.entity_transform_changed.emit(self.entity.id)

	@property
	def scale(self) -> QVector3D:
		"""
		Alias for scale3d for the auto-inspector (Unity-like naming).
		"""
		return self.scale3d

	@scale.setter
	def scale(self, value: QVector3D) -> None:
		self.scale3d = value

	# to_dict() is now automatically handled by Component base class!
	# It will serialize: position, rotation, scale (as QVector3D)

	@classmethod
	def from_dict(cls, data: Dict) -> "TransformComponent":
		"""
		Override from_dict to handle backwards compatibility with legacy keys.
		Supports both new format (rotation, scale) and legacy format (euler_deg, scale3d).
		New format is preferred if both exist.
		"""
		# Convert legacy keys to new format for automatic deserialization
		normalized_data = dict(data)
		
		# Handle rotation: prefer new format, fallback to legacy
		if "rotation" not in normalized_data and "euler_deg" in normalized_data:
			# Legacy format: convert euler_deg tuple to rotation QVector3D
			euler = normalized_data["euler_deg"]
			normalized_data["rotation"] = [float(euler[0]), float(euler[1]), float(euler[2])]
		
		# Handle scale: prefer new format, fallback to legacy
		if "scale" not in normalized_data and "scale3d" in normalized_data:
			# Legacy format: scale3d is already a list, use it directly
			normalized_data["scale"] = normalized_data["scale3d"]
		
		# Use automatic deserialization with normalized data
		return super().from_dict(normalized_data)



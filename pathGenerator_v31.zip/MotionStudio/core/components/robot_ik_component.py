from __future__ import annotations

from typing import Annotated, Literal, Optional

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import FilePath, Group, Range, Tooltip, inspector_button
from MotionStudio.core.debug import Debug


@register_component
class RobotIKComponent(Component):
	"""Inverse-kinematics driver attached to a robot root entity.

	Tracks a target ``TransformComponent`` and, whenever the target (or the
	robot base) moves, solves 6D pose IK on a background thread and writes the
	result onto the sibling ``RobotDescription``'s joint angles.

	For one-shot / play-routine use, call ``solve_ik_now()`` (or
	``scene.robot_ik_system.solve_sync(ik)``): that path solves and applies on
	the calling thread and clears any pending worker job for this robot.
	"""

	type_name = "RobotIK"
	category = "Robot"
	description = (
		"<p><b>Robot IK</b></p>"
		"<p>Drives the robot so the tool (or a custom TCP) follows a target pose in 6D. "
		"Add this on the <b>robot root</b> next to RobotDescription.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Assign <b>Target</b> to any entity with a Transform, then move/rotate it with the gizmos.</li>"
		"<li>Optionally assign <b>TCP</b> to a child of the tool link for a custom tool tip. Leave empty to use URDF <code>tool_link</code>.</li>"
		"<li>Backend <b>analytic</b> uses the imported closed-form solver; <b>ikpy</b> is a numerical fallback. There is no automatic switch.</li>"
		"<li>Solving runs in the background at <b>solve_hz</b>. Use <b>Solve IK Now</b> for one synchronous solve, or <b>Regenerate Analytical IK</b> after installing <code>ssik[urdf]</code> / editing the URDF.</li>"
		"</ul>"
	)

	enabled: Annotated[bool, Tooltip("Master toggle for IK tracking")] = True

	target: Annotated[
		Optional[TransformComponent],
		Tooltip("Target transform the end-effector should track (entity picker)"),
	] = None

	tcp: Annotated[
		Optional[TransformComponent],
		Tooltip(
			"Optional custom Tool Control Point. Pick an entity (usually a child "
			"of the tool-link entity) whose transform marks the real tool tip. "
			"IK drives THIS point to the target. Leave empty to use the URDF "
			"tool_link directly."
		),
	] = None

	backend: Annotated[
		Literal["analytic", "ikpy"],
		Tooltip(
			"IK solver backend. 'analytic' uses an ssik-generated closed-form "
			"solver (requires analytic_solver_path / Regenerate Analytical IK). "
			"'ikpy' is pure-Python numerical IK. There is no automatic fallback "
			"between backends — a misconfigured or unavailable solver raises an error."
		),
		Group("IK Settings"),
	] = "analytic"

	analytic_solver_path: Annotated[
		str,
		FilePath("Python Files (*.py);;All Files (*.*)"),
		Tooltip(
			"Optional analytic (ssik) solver Python module path for this IK "
			"component. If empty, uses RobotDescription.analytic_solver_path."
		),
		Group("IK Settings"),
	] = ""

	solve_hz: Annotated[
		float,
		Range(1.0, 120.0, step=1.0, decimals=0),
		Tooltip("Maximum solve rate while dragging the target"),
		Group("IK Settings"),
	] = 20.0

	position_tolerance_m: Annotated[
		float,
		Range(1e-5, 0.1, step=1e-4, decimals=5),
		Tooltip("Position success threshold in metres"),
		Group("IK Settings"),
	] = 1e-3

	orientation_tolerance_rad: Annotated[
		float,
		Range(1e-4, 1.0, step=1e-3, decimals=4),
		Tooltip("Orientation success threshold in radians"),
		Group("IK Settings"),
	] = 1e-2

	max_iterations: Annotated[
		int,
		Range(1, 1000, step=1),
		Tooltip("Maximum solver iterations per solve (ikpy)"),
		Group("IK Settings"),
	] = 100

	def __init__(self) -> None:
		self.enabled = True
		self.target = None
		self.tcp = None
		self.backend = "analytic"
		self.analytic_solver_path = ""
		self.solve_hz = 20.0
		self.position_tolerance_m = 1e-3
		self.orientation_tolerance_rad = 1e-2
		self.max_iterations = 100

	def _robot_ik_system(self):
		entity = self.entity
		if entity is None:
			return None
		scene = getattr(entity, "_scene", None)
		if scene is None:
			return None
		return getattr(scene, "robot_ik_system", None)

	def on_viewport_draw(self):
		if self.target is not None:
			from MotionStudio.core.transform.utils import world_position, world_rotation_quat

			entity = self.target.entity
			Debug.draw_axes(world_position(entity), length=10.0, screen_space=True,rotation=world_rotation_quat(entity), width=2.0, x_color=(1, 0, 0), y_color=(0, 1, 0), z_color=(0, 0, 1))

	@inspector_button(
		"Solve IK Now",
		tooltip="Solve and apply IK immediately",
	)
	def solve_ik_now(self) -> bool:
		"""Solve toward the target and apply joints before returning.

		Runs on the calling thread (no background IK worker). Use from
		play-routine loops when you need joints/FK updated before the next
		line / before ``check_all``. Returns ``True`` only if IK converged.
		"""
		system = self._robot_ik_system()
		if system is None:
			print("Solve IK Now: no IK system on scene.", flush=True)
			return False
		result = system.solve_sync(self)
		if result is None:
			print("Solve IK Now: target/robot not configured.", flush=True)
			return False
		if not result.joint_values:
			print(f"Solve IK Now: failed ({result.message}).", flush=True)
			return False
		if self.entity is not None and self.entity._scene is not None:
			self.entity._scene.events.entity_changed.emit(self.entity.id)
		if not result.success:
			print(f"Solve IK Now: applied but did not converge ({result.message}).", flush=True)
			return False
		print("Solve IK Now: converged.", flush=True)
		return True

	@inspector_button(
		"Regenerate Analytical IK",
		tooltip="Re-run ssik build for this robot's URDF and refresh analytic_solver_path",
	)
	def regenerate_analytical_ik(self) -> None:
		from pathlib import Path

		from PyQt6.QtWidgets import QApplication, QMessageBox

		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.robot.ik.analytic_solver_gen import (
			resolve_or_generate_analytic_solver,
		)

		def _notify(title: str, text: str, *, ok: bool) -> None:
			print(f"{title}: {text}", flush=True)
			parent = QApplication.activeWindow()
			if ok:
				QMessageBox.information(parent, title, text)
			else:
				QMessageBox.warning(parent, title, text)

		entity = self.entity
		if entity is None:
			_notify("Regenerate Analytical IK", "no entity.", ok=False)
			return False, "no entity"
		scene = getattr(entity, "_scene", None)
		rd = entity.get_component(RobotDescriptionComponent)
		if scene is None or scene.project_root is None or rd is None or not rd.urdf_path:
			_notify(
				"Regenerate Analytical IK",
				"robot/URDF/project not configured.",
				ok=False,
			)
			return False, "robot/URDF/project not configured"
		rel, msg = resolve_or_generate_analytic_solver(
			project_root=Path(scene.project_root),
			urdf_project_path=rd.urdf_path,
			base_link=str(rd.root_link or "base_link"),
			ee_link=str(rd.tool_link or "tool0"),
			force=True,
		)
		if rel:
			rd.analytic_solver_path = rel
			self.analytic_solver_path = ""
			try:
				scene.events.entity_changed.emit(entity.id)
			except Exception:
				pass
			_notify("Regenerate Analytical IK", msg, ok=True)
			return None
		_notify("Regenerate Analytical IK", msg, ok=False)
		return False, msg or "analytic solver generation failed"

from __future__ import annotations

from typing import Annotated, Optional

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ReadOnly, Tooltip


@register_component
class UrdfLinkComponent(Component):
	"""Marks an entity as a URDF link in an imported robot."""

	type_name = "UrdfLink"
	category = "Robot"
	description = (
		"<p><b>URDF Link</b></p>"
		"<p>Marks this entity as one link in an imported robot hierarchy. "
		"Added automatically by <b>File &rarr; Import URDF</b>.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li><b>link_name</b> and <b>parent_joint_name</b> are read-only metadata from the URDF.</li>"
		"<li>The sibling Transform is FK-driven from RobotDescription joint positions &mdash; do not edit it by hand.</li>"
		"<li>Collision meshes on links move with FK. Group them in the Physics matrix if you want one robot row.</li>"
		"<li>You normally do not add this component yourself.</li>"
		"</ul>"
	)

	link_name: Annotated[str, ReadOnly(), Tooltip("URDF link name")]
	parent_joint_name: Annotated[Optional[str], ReadOnly(), Tooltip("Joint connecting parent link to this link")] = None

	def __init__(self, link_name: str = "", parent_joint_name: Optional[str] = None) -> None:
		self.link_name = str(link_name)
		self.parent_joint_name = str(parent_joint_name) if parent_joint_name else None

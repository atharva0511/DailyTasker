from __future__ import annotations

import math
from typing import Annotated, List, Optional, Tuple

from PyQt6.QtGui import QColor, QQuaternion, QVector3D

from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.transform.utils import transform_point
from MotionStudio.ui.inspector.metadata import Order, ReadOnly, Tooltip, VertexPick


_POINT_COLOR = QColor(255, 255, 0)
_LINE_COLOR = QColor(80, 220, 255)
_ARC_COLOR = QColor(255, 180, 60)
_LABEL_COLOR = QColor(255, 220, 120)
_EPS = 1e-9
_ARC_RADIUS_FRACTION = 0.25
_ARC_LABEL_OUTSET = 1.15
_UNKNOWN_ANGLE = "—"


def _format_angle_deg(angle_deg: float) -> str:
	return f"{angle_deg:.2f}°"


def _safe_normalize(v: QVector3D) -> Optional[QVector3D]:
	length = float(v.length())
	if length < _EPS:
		return None
	return QVector3D(v.x() / length, v.y() / length, v.z() / length)


@register_component
class MeasureAngleComponent(Component):
	type_name = "MeasureAngle"
	category = "Measure"
	description = (
		"<p><b>Measure Angle</b></p>"
		"<p>Measures interior angle <b>ABC</b> (the angle at B) in degrees. "
		"Pick vertices on any mesh; values are stored in this entity's local frame.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Click <b>Pick</b> for Point A, vertex B, and Point C, then click mesh vertices in that order.</li>"
		"<li>The read-only <b>angle</b> field shows the result (for example <code>45.67&deg;</code>). "
		"Zero-length arms or colinear points that cannot form an arc show an em dash.</li>"
		"<li>While this entity is selected, the viewport draws the three points, arms BA and BC, an arc, and a degree label "
		"(requires <b>View &rarr; Enable Debug Draw</b>).</li>"
		"<li>Arc radius is one quarter of the shorter arm among AB and BC.</li>"
		"</ul>"
	)

	point_a: Annotated[QVector3D, VertexPick(), Order(0), Tooltip("Point A of angle ABC (pick a mesh vertex)")]
	point_b: Annotated[QVector3D, VertexPick(), Order(10), Tooltip("Vertex B of angle ABC (the angle is at this point)")]
	point_c: Annotated[QVector3D, VertexPick(), Order(20), Tooltip("Point C of angle ABC (pick a mesh vertex)")]
	angle: Annotated[str, ReadOnly(), Order(30), Tooltip("Interior angle ABC in degrees")]

	def __init__(self) -> None:
		self.point_a = QVector3D()
		self.point_b = QVector3D()
		self.point_c = QVector3D()
		self.angle = _UNKNOWN_ANGLE

	def on_entity_changed(self) -> None:
		text = self._compute_angle_text()
		if text != self.angle:
			self.angle = text

	def on_viewport_draw(self) -> None:
		if self.entity is None or self.entity.scene is None:
			return
		selection = self.entity.scene.selection
		if selection is None or not selection.is_entity_selected(self.entity):
			return

		world_a, world_b, world_c, angle_text, arc_points, label_pos = self._world_angle()
		if world_a is None or world_b is None or world_c is None:
			return

		Debug.draw_point(world_a, size=10.0, screen_space=True, color=_POINT_COLOR, opacity=0.9, on_top=False)
		Debug.draw_point(world_b, size=10.0, screen_space=True, color=_POINT_COLOR, opacity=0.9, on_top=False)
		Debug.draw_point(world_c, size=10.0, screen_space=True, color=_POINT_COLOR, opacity=0.9, on_top=False)
		Debug.draw_line(world_b, world_a, color=_LINE_COLOR, width=2.0, opacity=1.0, on_top=True)
		Debug.draw_line(world_b, world_c, color=_LINE_COLOR, width=2.0, opacity=1.0, on_top=True)
		if len(arc_points) >= 2:
			Debug.draw_polyline(arc_points, color=_ARC_COLOR, width=2.0, opacity=1.0, on_top=True)
		if label_pos is not None:
			Debug.draw_label(label_pos, angle_text, color=_LABEL_COLOR, font_size=14, on_top=True)

	def _compute_angle_text(self) -> str:
		_a, _b, _c, text, _arc, _label = self._world_angle()
		return text

	def _world_points(self) -> Tuple[Optional[QVector3D], Optional[QVector3D], Optional[QVector3D]]:
		if self.entity is None:
			return None, None, None
		return (
			transform_point(self.entity, self.point_a),
			transform_point(self.entity, self.point_b),
			transform_point(self.entity, self.point_c),
		)

	def _world_angle(
		self,
	) -> Tuple[
		Optional[QVector3D],
		Optional[QVector3D],
		Optional[QVector3D],
		str,
		List[QVector3D],
		Optional[QVector3D],
	]:
		world_a, world_b, world_c = self._world_points()
		if world_a is None or world_b is None or world_c is None:
			ba = self.point_a - self.point_b
			bc = self.point_c - self.point_b
			text = _angle_text_from_arms(ba, bc)
			return None, None, None, text, [], None

		ba = world_a - world_b
		bc = world_c - world_b
		text = _angle_text_from_arms(ba, bc)
		arc_points, label_pos = _arc_and_label(world_b, ba, bc)
		return world_a, world_b, world_c, text, arc_points, label_pos


def _angle_text_from_arms(ba: QVector3D, bc: QVector3D) -> str:
	ba_n = _safe_normalize(ba)
	bc_n = _safe_normalize(bc)
	if ba_n is None or bc_n is None:
		return _UNKNOWN_ANGLE
	normal = QVector3D.crossProduct(ba_n, bc_n)
	if float(normal.lengthSquared()) < _EPS:
		return _UNKNOWN_ANGLE
	dot = max(-1.0, min(1.0, float(QVector3D.dotProduct(ba_n, bc_n))))
	return _format_angle_deg(math.degrees(math.acos(dot)))


def _arc_and_label(
	origin: QVector3D,
	ba: QVector3D,
	bc: QVector3D,
) -> Tuple[List[QVector3D], Optional[QVector3D]]:
	len_ab = float(ba.length())
	len_bc = float(bc.length())
	ba_n = _safe_normalize(ba)
	bc_n = _safe_normalize(bc)
	if ba_n is None or bc_n is None:
		return [], None

	shorter = min(len_ab, len_bc)
	radius = _ARC_RADIUS_FRACTION * shorter
	if radius < _EPS:
		return [], None

	normal = QVector3D.crossProduct(ba_n, bc_n)
	if float(normal.lengthSquared()) < _EPS:
		return [], None
	normal = _safe_normalize(normal)
	if normal is None:
		return [], None

	dot = max(-1.0, min(1.0, float(QVector3D.dotProduct(ba_n, bc_n))))
	angle_deg = math.degrees(math.acos(dot))
	if angle_deg < _EPS:
		return [], None

	n_segments = max(16, int(round(angle_deg / 2.0)))
	n_segments = min(n_segments, 64)
	points: List[QVector3D] = []
	for i in range(n_segments + 1):
		t = i / n_segments
		rotated = QQuaternion.fromAxisAndAngle(normal, t * angle_deg).rotatedVector(ba_n)
		points.append(origin + rotated * radius)

	mid = QQuaternion.fromAxisAndAngle(normal, 0.5 * angle_deg).rotatedVector(ba_n)
	label_pos = origin + mid * (radius * _ARC_LABEL_OUTSET)
	return points, label_pos

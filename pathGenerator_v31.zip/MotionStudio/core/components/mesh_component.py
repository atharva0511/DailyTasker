from __future__ import annotations

from typing import Annotated, Literal

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Tooltip
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QVector3D, QColor
import time
import numpy as np


@register_component
class MeshComponent(Component):
	type_name = "Mesh"
	category = "Rendering"
	description = (
		"<p><b>Mesh</b></p>"
		"<p>Draws a primitive or imported 3D model on this entity. Geometry follows the "
		"entity Transform. Scene units are millimetres (1 unit = 1 mm).</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Set <b>shape</b> to cube or sphere for a primitive, or <b>custom</b> to load a file.</li>"
		"<li>Browse <b>custom_path</b> for STL, OBJ, FBX, DAE, glTF, or GLB. External files are copied into the project's <code>models/</code> folder.</li>"
		"<li>Enable <b>source_material</b> to use imported colours when available; otherwise the uniform <b>color</b> is used.</li>"
		"<li>Add a <b>Collider</b> on the same entity if this mesh should participate in collision checks.</li>"
		"</ul>"
	)

	shape: Annotated[Literal["cube", "sphere", "custom"], Tooltip("Primitive shape or custom mesh")]
	custom_path: Annotated[str, FilePath("Mesh Files (*.stl *.obj *.fbx *.dae *.gltf *.glb);;All Files (*.*)"), Tooltip("Project-relative mesh path; external files are copied into the project's models/ folder")]
	source_material: Annotated[bool, Tooltip("Use imported source material colors (when available) instead of custom unicolor")]
	color: Annotated[QColor, ColorField(), Tooltip("Material color")]

	def __init__(self, shape: str = "cube", custom_path: str = "", source_material: bool = False, color: QColor | None = None) -> None:
		# shape: "cube" | "sphere" | "custom"
		self.shape = shape
		self.custom_path = custom_path
		self.source_material = bool(source_material)
		self.color = color or QColor(200, 200, 200)

		self._last_time = time.time()
		self._check = False

	def update(self, delta_time: float):
		pass

	# to_dict() and from_dict() are now automatically handled by Component base class!
	# No need to override them unless you have special serialization needs.



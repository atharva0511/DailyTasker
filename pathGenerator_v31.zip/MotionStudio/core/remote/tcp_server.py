"""Line-oriented TCP server that runs Inspector actions on request.

Uses raw sockets and daemon threads rather than ``QTcpServer``: a command must
be able to block its own connection until the action completes (including
asynchronous Plan Motion), which a main-thread Qt server could not do without
freezing the editor.
"""

from __future__ import annotations

import socket
import threading
from typing import TYPE_CHECKING, Optional

from MotionStudio.core.remote.protocol import format_response, parse_command

if TYPE_CHECKING:
	from MotionStudio.core.logging.command_logger import CommandLogger
	from MotionStudio.core.remote.dispatcher import RemoteCommandDispatcher

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5555
DEFAULT_TIMEOUT_S = 300
_MAX_LINE_BYTES = 64 * 1024
# ``logs.txt`` action for every remote request / reply.
_LOG_ACTION = "tcp"


class TcpCommandServer:
	"""Accepts ``RUN`` / ``EDIT`` / ``GET`` lines on a TCP socket.

	Commands are serialised: a second client waits until the in-flight command
	finishes, so remote callers can never interleave scene mutations. Every
	request and reply is mirrored into the project ``logs.txt``.
	"""

	def __init__(
		self,
		dispatcher: "RemoteCommandDispatcher",
		*,
		host: str = DEFAULT_HOST,
		port: int = DEFAULT_PORT,
		timeout_s: float = DEFAULT_TIMEOUT_S,
		command_logger: Optional["CommandLogger"] = None,
	) -> None:
		self._dispatcher = dispatcher
		self._host = str(host or DEFAULT_HOST)
		self._port = int(port)
		self._timeout_s = float(timeout_s)
		self._command_logger = command_logger
		self._server_socket: Optional[socket.socket] = None
		self._accept_thread: Optional[threading.Thread] = None
		self._command_lock = threading.Lock()
		self._stopping = threading.Event()

	def set_command_logger(self, logger: Optional["CommandLogger"]) -> None:
		"""Attach project ``logs.txt`` logger (same as undo command logging)."""
		self._command_logger = logger

	# ------------------------------------------------------------------ state

	@property
	def address(self) -> str:
		return f"{self._host}:{self._port}"

	@property
	def is_running(self) -> bool:
		return self._server_socket is not None

	# ---------------------------------------------------------------- control

	def start(self) -> None:
		"""Bind and start accepting. Raises ``OSError`` if the port is taken."""
		if self.is_running:
			return
		self._stopping.clear()
		server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		try:
			server.bind((self._host, self._port))
			server.listen(8)
		except OSError:
			server.close()
			raise
		self._server_socket = server
		self._accept_thread = threading.Thread(
			target=self._accept_loop,
			name="TcpCommandServer",
			daemon=True,
		)
		self._accept_thread.start()
		print(f"TCP command server listening on {self.address}", flush=True)

	def stop(self) -> None:
		"""Close the listening socket; open connections end on their next read."""
		if not self.is_running:
			return
		self._stopping.set()
		server = self._server_socket
		self._server_socket = None
		try:
			server.close()
		except Exception:
			pass
		thread = self._accept_thread
		self._accept_thread = None
		if thread is not None and thread.is_alive():
			thread.join(timeout=2.0)
		print(f"TCP command server on {self.address} stopped", flush=True)

	# ----------------------------------------------------------------- server

	def _accept_loop(self) -> None:
		server = self._server_socket
		while server is not None and not self._stopping.is_set():
			try:
				client, addr = server.accept()
			except OSError:
				break
			except Exception as exc:
				print(f"TCP command server accept failed: {exc}", flush=True)
				break
			threading.Thread(
				target=self._serve_client,
				args=(client, addr),
				name=f"TcpCommand-{addr[0]}:{addr[1]}",
				daemon=True,
			).start()

	def _serve_client(self, client: socket.socket, addr) -> None:
		peer = f"{addr[0]}:{addr[1]}"
		buffer = bytearray()
		try:
			while not self._stopping.is_set():
				try:
					chunk = client.recv(4096)
				except OSError:
					break
				if not chunk:
					break
				buffer.extend(chunk)
				if len(buffer) > _MAX_LINE_BYTES:
					response = format_response(False, "command line too long")
					self._log_reply(peer, response)
					self._send(client, response)
					break
				while b"\n" in buffer:
					raw, _, rest = bytes(buffer).partition(b"\n")
					buffer = bytearray(rest)
					self._send(client, self._handle_line(raw, peer))
		except Exception as exc:
			print(f"TCP command connection {addr} failed: {exc}", flush=True)
		finally:
			try:
				client.close()
			except Exception:
				pass

	def _handle_line(self, raw: bytes, peer: str) -> str:
		try:
			line = raw.decode("utf-8", errors="replace")
		except Exception:
			response = format_response(False, "could not decode command")
			self._log_reply(peer, response)
			return response

		text = line.strip()
		if not text:
			return ""

		# Logged on arrival so a long-running command is visible before it replies.
		self._log(f"{peer} > {text}")

		command, error = parse_command(line)
		if command is None:
			response = format_response(False, error)
		else:
			with self._command_lock:
				ok, output = self._dispatcher.execute(command, self._timeout_s)
			response = format_response(ok, output)
		self._log_reply(peer, response)
		return response

	# ---------------------------------------------------------------- logging

	def _log(self, description: str) -> None:
		logger = self._command_logger
		if logger is None:
			return
		try:
			logger.log_event(_LOG_ACTION, description)
		except Exception:
			pass

	def _log_reply(self, peer: str, response: str) -> None:
		self._log(f"{peer} < {response.rstrip()}")

	@staticmethod
	def _send(client: socket.socket, text: str) -> None:
		if not text:
			return
		try:
			client.sendall(text.encode("utf-8"))
		except OSError:
			pass

from __future__ import annotations

import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QUndoCommand, QUndoStack


def command_for_stack_action(stack: QUndoStack, index: int, action: str) -> Optional[QUndoCommand]:
	"""
	Return the QUndoCommand that was just applied for logging/status.

	After ``undo()``, ``index`` is the stack cursor *after* the undo; the command
	whose ``undo()`` ran is ``command(index)``. After ``redo()`` / push, the
	active command is ``command(index - 1)``.
	"""
	count = stack.count()
	if count <= 0:
		return None
	if action == "undo":
		if index < 0 or index >= count:
			return None
		return stack.command(index)
	if index <= 0:
		return None
	return stack.command(index - 1)


class CommandLogger(QObject):
	"""
	Logs command executions and other editor events to ``logs.txt`` in the
	project root (same file / format for undo commands and Plan Motion, etc.).

	Writes are serialized: TCP connection threads log alongside the main thread.
	``event_logged`` fires on every entry so the status bar can mirror the file.
	"""

	event_logged = pyqtSignal(str, str)  # action, description

	def __init__(
		self,
		project_root: Optional[Path] = None,
		parent: Optional[QObject] = None,
	) -> None:
		"""
		Initialize the command logger.
		
		Args:
			project_root: Path to the project root directory. If None, file logging is disabled.
			parent: Optional Qt parent (typically the main window).
		"""
		super().__init__(parent)
		self._project_root = project_root
		self._write_lock = threading.Lock()

	def set_project_root(self, project_root: Optional[Path]) -> None:
		"""Update the project root path."""
		self._project_root = project_root

	def log_event(self, action: str, description: str) -> None:
		"""
		Append one line to ``logs.txt`` and notify the status bar.

		Format matches command logging::

			[YYYY-MM-DD HH:MM:SS] {action}: {description}

		The status-bar signal is emitted even when no project is loaded so
		execute/undo still appear. File writes are skipped without a project root.
		Does not print to the console.
		"""
		action_text = str(action or "")
		description_text = str(description or "")
		if self._project_root is not None:
			try:
				timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
				log_entry = f"[{timestamp}] {action_text}: {description_text}\n"
				if not self._project_root.exists():
					try:
						self._project_root.mkdir(parents=True, exist_ok=True)
					except Exception as e:
						print(f"Failed to create project directory {self._project_root}: {e}", flush=True)
				if self._project_root.exists():
					log_file = self._project_root / "logs.txt"
					try:
						with self._write_lock:
							with open(log_file, "a", encoding="utf-8") as f:
								f.write(log_entry)
								f.flush()
					except Exception as e:
						print(f"Failed to write to log file {log_file}: {e}", flush=True)
			except Exception as e:
				print(f"Error in log_event: {e}", flush=True)
		# Mirror every log line on the status bar (TCP threads emit; the slot
		# is queued onto the UI thread).
		try:
			self.event_logged.emit(action_text, description_text)
		except Exception:
			pass

	def log_command(self, command: QUndoCommand, action: str) -> None:
		"""
		Log a command execution to the log file.
		
		Args:
			command: The command that was executed
			action: One of "execute", "undo", or "redo"
		"""
		try:
			self.log_event(action, self._get_command_description(command))
		except Exception as e:
			print(f"Error in log_command: {e}", flush=True)

	def _get_command_description(self, command: QUndoCommand) -> str:
		"""
		Get a human-readable description from a command.
		
		Args:
			command: The command to describe
			
		Returns:
			Description string, or command text() as fallback
		"""
		try:
			# Try to call get_description() if the command has it
			if hasattr(command, "get_description"):
				return command.get_description()
		except Exception:
			pass
		
		# Fallback to command text
		try:
			return command.text()
		except Exception:
			return "Unknown command"


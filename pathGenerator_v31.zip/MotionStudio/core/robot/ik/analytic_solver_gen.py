"""Generate ssik analytical IK artifacts next to a URDF."""

from __future__ import annotations

import io
import os
import subprocess
import sys
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from typing import List, Tuple


def analytic_solver_relpath(urdf_project_path: str | Path) -> Path:
	"""Project-relative path for ``<stem>_analytic_ik.py`` next to the URDF."""
	urdf_rel = Path(urdf_project_path)
	return urdf_rel.with_name(f"{urdf_rel.stem}_analytic_ik.py")


def _ssik_build_argv(
	*,
	urdf_abs: Path,
	base_link: str,
	ee_link: str,
	output: Path,
	module_name: str,
) -> List[str]:
	return [
		"build",
		str(urdf_abs),
		"--base",
		str(base_link or "base_link"),
		"--ee",
		str(ee_link or "tool0"),
		"--out",
		str(output),
		"--module-name",
		module_name,
		"--no-validate",
	]


def _missing_ssik_message(detail: str) -> str:
	"""User-facing hint when ssik / ssik[urdf] cannot be imported or run."""
	if getattr(sys, "frozen", False):
		return (
			"ssik (or URDF extras such as urchin) is missing from this frozen build. "
			"Rebuild with build.spec collect_all for ssik/urchin/sympy/scipy "
			f"(detail: {detail})"
		)
	return (
		"ssik (or ssik[urdf]) is not installed. Run: pip install \"ssik[urdf]\" "
		f"(detail: {detail})"
	)


def _hint_from_ssik_failure(stderr: str, returncode: int) -> Tuple[bool, str]:
	"""Return ``(is_missing_install, message)`` for a failed ssik build."""
	hint = stderr.splitlines()[-1] if stderr.strip() else f"exit code {returncode}"
	missing_ssik = "No module named ssik" in stderr or "No module named 'ssik" in stderr
	needs_urdf_extra = (
		"urchin" in stderr.lower()
		or "ssik[urdf]" in stderr.lower()
		or ("urdf" in stderr.lower() and "install" in stderr.lower())
	)
	if missing_ssik or needs_urdf_extra:
		return True, _missing_ssik_message(hint)
	return False, hint


def _try_generate_inprocess(
	*,
	urdf_abs: Path,
	base_link: str,
	ee_link: str,
	output: Path,
	module_name: str,
) -> Tuple[bool, str]:
	"""Call ``ssik.cli.main`` in this process (safe for PyInstaller frozen apps)."""
	try:
		from ssik.cli import main as ssik_main
	except ImportError as exc:
		return False, _missing_ssik_message(str(exc))

	argv = _ssik_build_argv(
		urdf_abs=urdf_abs,
		base_link=base_link,
		ee_link=ee_link,
		output=output,
		module_name=module_name,
	)
	out_buf = io.StringIO()
	err_buf = io.StringIO()
	try:
		output.parent.mkdir(parents=True, exist_ok=True)
		with redirect_stdout(out_buf), redirect_stderr(err_buf):
			code = int(ssik_main(argv) or 0)
	except Exception as exc:  # pragma: no cover - defensive
		return False, f"ssik build failed: {exc}"

	combined = ((err_buf.getvalue() or "") + "\n" + (out_buf.getvalue() or "")).strip()
	if code != 0:
		_missing, hint = _hint_from_ssik_failure(combined, code)
		if _missing:
			return False, hint
		return False, f"ssik build failed for {urdf_abs.name}: {hint}"

	if not output.is_file():
		return False, f"ssik build reported success but did not write {output}."

	return True, f"Generated analytic IK solver: {output.name}"


def _try_generate_subprocess(
	*,
	urdf_abs: Path,
	base_link: str,
	ee_link: str,
	output: Path,
	module_name: str,
	timeout_s: float,
) -> Tuple[bool, str]:
	"""Dev-path: ``python -m ssik.cli build ...`` (must not use frozen ``sys.executable``)."""
	cmd = [
		sys.executable,
		"-m",
		"ssik.cli",
		*_ssik_build_argv(
			urdf_abs=urdf_abs,
			base_link=base_link,
			ee_link=ee_link,
			output=output,
			module_name=module_name,
		),
	]
	env = os.environ.copy()
	env.setdefault("PYTHONIOENCODING", "utf-8")
	env.setdefault("PYTHONUTF8", "1")
	try:
		output.parent.mkdir(parents=True, exist_ok=True)
		completed = subprocess.run(
			cmd,
			capture_output=True,
			text=True,
			encoding="utf-8",
			errors="replace",
			timeout=float(timeout_s),
			check=False,
			env=env,
		)
	except FileNotFoundError:
		return False, "Python interpreter not found while generating analytic IK."
	except subprocess.TimeoutExpired:
		return False, f"ssik build timed out after {timeout_s:.0f}s for {urdf_abs.name}."
	except Exception as exc:  # pragma: no cover - defensive
		return False, f"ssik build failed: {exc}"

	if completed.returncode != 0:
		stderr = (completed.stderr or completed.stdout or "").strip()
		_missing, hint = _hint_from_ssik_failure(stderr, int(completed.returncode))
		if _missing:
			return False, hint
		return False, f"ssik build failed for {urdf_abs.name}: {hint}"

	if not output.is_file():
		return False, f"ssik build reported success but did not write {output}."

	return True, f"Generated analytic IK solver: {output.name}"


def try_generate_analytic_solver(
	*,
	urdf_abs: Path,
	base_link: str,
	ee_link: str,
	output: Path,
	timeout_s: float = 60.0,
) -> Tuple[bool, str]:
	"""Generate an analytical IK module via ssik.

	Returns ``(ok, message)``. Failures (missing extras, unsupported topology,
	timeouts) never raise — callers can swallow and continue URDF import.

	**Frozen builds:** always runs ``ssik.cli.main`` in-process. Spawning
	``sys.executable -m ssik.cli`` would re-launch the Motion Studio GUI
	(PyInstaller ``sys.executable`` is the app exe).
	"""
	urdf_abs = Path(urdf_abs)
	output = Path(output)
	if not urdf_abs.is_file():
		return False, f"URDF not found: {urdf_abs}"

	module_name = output.stem
	if getattr(sys, "frozen", False):
		return _try_generate_inprocess(
			urdf_abs=urdf_abs,
			base_link=base_link,
			ee_link=ee_link,
			output=output,
			module_name=module_name,
		)

	return _try_generate_subprocess(
		urdf_abs=urdf_abs,
		base_link=base_link,
		ee_link=ee_link,
		output=output,
		module_name=module_name,
		timeout_s=timeout_s,
	)


def resolve_or_generate_analytic_solver(
	*,
	project_root: Path,
	urdf_project_path: str | Path,
	base_link: str,
	ee_link: str,
	force: bool = False,
) -> Tuple[str, str]:
	"""Return ``(project_relative_path, status_message)``.

	If the artifact already exists and ``force`` is False, just returns its
	relative path. Otherwise attempts generation via :func:`try_generate_analytic_solver`.
	"""
	rel = analytic_solver_relpath(urdf_project_path)
	abs_path = Path(project_root) / rel
	if abs_path.is_file() and not force:
		return rel.as_posix(), f"Using existing analytic IK solver: {rel.as_posix()}"

	urdf_abs = Path(project_root) / Path(urdf_project_path)
	ok, msg = try_generate_analytic_solver(
		urdf_abs=urdf_abs,
		base_link=base_link,
		ee_link=ee_link,
		output=abs_path,
	)
	if ok:
		return rel.as_posix(), msg
	return "", msg

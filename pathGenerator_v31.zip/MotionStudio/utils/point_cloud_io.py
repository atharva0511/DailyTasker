"""Load point-cloud files (``.ply`` / ``.pcd``) into numpy arrays.

PLY uses PyVista. PCD uses a lightweight ASCII / uncompressed-binary reader
(no open3d). ``DATA binary_compressed`` is not supported in v1.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

import numpy as np

# Packed PCL rgb is often float32 whose bits encode 0x00RRGGBB.
_RGB_PACKED_DTYPE = np.dtype(np.float32).newbyteorder("<")


class PointCloudLoadError(OSError):
	"""Raised when a point-cloud file cannot be parsed."""


def load_point_cloud(
	path: str | Path,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	"""
	Load a point cloud from disk.

	Returns
	-------
	points : (N, 3) float64
		XYZ in file units (caller applies component ``scale``).
	colors : (N, 3) float64 in [0, 1], or None
		Per-point RGB when present.
	"""
	p = Path(path)
	if not p.is_file():
		raise PointCloudLoadError(f"Point cloud file not found: {path}")
	suffix = p.suffix.lower()
	if suffix == ".ply":
		return _load_ply(p)
	if suffix == ".pcd":
		return _load_pcd(p)
	raise PointCloudLoadError(
		f"Unsupported point-cloud format '{suffix}'. Use .ply or .pcd."
	)


def save_point_cloud(
	path: str | Path,
	points: np.ndarray,
	colors: Optional[np.ndarray] = None,
) -> None:
	"""
	Write a point cloud as PLY (overwrites).

	Parameters
	----------
	points : (N, 3) float
	colors : optional (N, 3) float in [0, 1]

	Notes
	-----
	Uses ``vtkPLYWriter`` (not ``PolyData.save``). PyVista's PLY saver drops
	vertex colors; VTK writes them as ``red``/``green``/``blue`` uchar properties
	when ``SetArrayName(\"RGB\")`` is set.
	"""
	try:
		import pyvista as pv  # type: ignore
		import vtk  # type: ignore
	except Exception as exc:
		raise PointCloudLoadError("PyVista/VTK is required to save .ply files.") from exc

	pts = np.asarray(points, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3 or pts.shape[0] == 0:
		raise PointCloudLoadError("Cannot save an empty point cloud.")
	pts = np.ascontiguousarray(pts[:, :3], dtype=np.float64)

	p = Path(path)
	p.parent.mkdir(parents=True, exist_ok=True)
	cloud = pv.PolyData(pts)

	writer = vtk.vtkPLYWriter()
	writer.SetFileName(str(p))
	writer.SetInputData(cloud)
	writer.SetFileTypeToBinary()

	if colors is not None:
		rgb = np.asarray(colors, dtype=np.float64)
		if rgb.ndim == 2 and rgb.shape[0] == pts.shape[0] and rgb.shape[1] >= 3:
			u8 = np.ascontiguousarray(
				(np.clip(rgb[:, :3], 0.0, 1.0) * 255.0).astype(np.uint8)
			)
			cloud.point_data["RGB"] = u8
			cloud.set_active_scalars("RGB")
			writer.SetArrayName("RGB")

	try:
		ok = int(writer.Write())
	except Exception as exc:
		raise PointCloudLoadError(f"Failed to write PLY: {path}") from exc
	if ok == 0:
		raise PointCloudLoadError(f"Failed to write PLY: {path}")


def _load_ply(path: Path) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	try:
		import pyvista as pv  # type: ignore
	except Exception as exc:
		raise PointCloudLoadError("PyVista is required to load .ply files.") from exc

	try:
		dataset = pv.read(str(path))
	except Exception as exc:
		raise PointCloudLoadError(f"Failed to read PLY: {path}") from exc

	if dataset is None:
		raise PointCloudLoadError(f"Empty PLY dataset: {path}")

	# Prefer vertices even when faces exist (mesh PLY treated as a cloud).
	try:
		pts = np.asarray(dataset.points, dtype=np.float64)
	except Exception as exc:
		raise PointCloudLoadError(f"PLY has no points: {path}") from exc

	if pts.ndim != 2 or pts.shape[1] < 3 or pts.shape[0] == 0:
		raise PointCloudLoadError(f"PLY has no usable XYZ points: {path}")

	points = np.ascontiguousarray(pts[:, :3], dtype=np.float64)
	colors = _extract_pyvista_point_colors(dataset)
	return points, colors


def _extract_pyvista_point_colors(dataset) -> Optional[np.ndarray]:
	"""Return (N,3) RGB in 0–1 from common PLY point-color array names."""
	try:
		n = int(dataset.n_points)
	except Exception:
		return None
	if n <= 0:
		return None

	# Prefer packed RGB/RGBA. Do not treat a lone "red" channel as RGB — that
	# shadows Mech-Eye / VTK PLYs that store separate red/green/blue properties.
	candidates = (
		"RGB",
		"rgb",
		"RGBA",
		"rgba",
		"Colors",
		"colors",
	)
	arr = None
	for name in candidates:
		try:
			if name in dataset.point_data:
				candidate = np.asarray(dataset.point_data[name])
				# Only accept multi-component arrays here.
				if candidate.ndim == 2 and candidate.shape[0] == n and candidate.shape[1] >= 3:
					arr = candidate
					break
		except Exception:
			continue

	# Separate r/g/b channels (common in Mech-Eye / vtkPLYWriter output)
	if arr is None:
		try:
			keys = {str(k).lower(): k for k in dataset.point_data.keys()}
			if "red" in keys and "green" in keys and "blue" in keys:
				r = np.asarray(dataset.point_data[keys["red"]], dtype=np.float64).reshape(-1)
				g = np.asarray(dataset.point_data[keys["green"]], dtype=np.float64).reshape(-1)
				b = np.asarray(dataset.point_data[keys["blue"]], dtype=np.float64).reshape(-1)
				if r.size == n and g.size == n and b.size == n:
					arr = np.column_stack([r, g, b])
		except Exception:
			arr = None

	if arr is None:
		return None

	arr = np.asarray(arr)
	if arr.ndim == 2 and arr.shape[0] == n and arr.shape[1] >= 3:
		rgb = arr[:, :3].astype(np.float64, copy=False)
	else:
		return None

	# Heuristic: values in 0–255 → normalize
	if np.nanmax(rgb) > 1.5:
		rgb = rgb / 255.0
	return np.clip(np.ascontiguousarray(rgb, dtype=np.float64), 0.0, 1.0)


def _load_pcd(path: Path) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	with path.open("rb") as f:
		header, data_offset = _parse_pcd_header(f)
		data_mode = header["data"]
		n_points = int(header["points"])
		if n_points <= 0:
			raise PointCloudLoadError(f"PCD reports zero points: {path}")

		fields = header["fields"]
		sizes = header["size"]
		types = header["type"]
		counts = header["count"]

		if "x" not in fields or "y" not in fields or "z" not in fields:
			raise PointCloudLoadError(f"PCD missing x/y/z fields: {path}")

		if data_mode == "ascii":
			f.seek(data_offset)
			text = f.read().decode("utf-8", errors="replace")
			return _read_pcd_ascii(text, fields, n_points)

		if data_mode == "binary":
			f.seek(data_offset)
			point_step = sum(int(s) * int(c) for s, c in zip(sizes, counts))
			blob = f.read(point_step * n_points)
			if len(blob) < point_step * n_points:
				raise PointCloudLoadError(f"PCD binary truncated: {path}")
			return _read_pcd_binary(blob, fields, sizes, types, counts, n_points)

		if data_mode == "binary_compressed":
			raise PointCloudLoadError(
				f"PCD binary_compressed is not supported: {path}. "
				"Re-export as ASCII or uncompressed binary PCD."
			)

		raise PointCloudLoadError(f"Unknown PCD DATA mode '{data_mode}': {path}")


def _parse_pcd_header(f) -> Tuple[dict, int]:
	"""Parse PCD header; return (header_dict, data_byte_offset)."""
	fields: list[str] = []
	sizes: list[int] = []
	types: list[str] = []
	counts: list[int] = []
	width = 0
	height = 1
	points = 0
	data_mode = ""
	version = ""

	# Headers are ASCII lines ending with DATA <mode>
	while True:
		pos = f.tell()
		line_b = f.readline()
		if not line_b:
			raise PointCloudLoadError("Unexpected EOF in PCD header.")
		try:
			line = line_b.decode("ascii", errors="strict").strip()
		except Exception:
			f.seek(pos)
			raise PointCloudLoadError("Invalid (non-ASCII) PCD header line.")

		if not line or line.startswith("#"):
			continue

		parts = line.split()
		key = parts[0].upper()
		if key == "VERSION" and len(parts) >= 2:
			version = parts[1]
		elif key == "FIELDS":
			fields = [p.lower() for p in parts[1:]]
		elif key == "SIZE":
			sizes = [int(p) for p in parts[1:]]
		elif key == "TYPE":
			types = [p.upper() for p in parts[1:]]
		elif key == "COUNT":
			counts = [int(p) for p in parts[1:]]
		elif key == "WIDTH" and len(parts) >= 2:
			width = int(parts[1])
		elif key == "HEIGHT" and len(parts) >= 2:
			height = int(parts[1])
		elif key == "POINTS" and len(parts) >= 2:
			points = int(parts[1])
		elif key == "DATA" and len(parts) >= 2:
			data_mode = parts[1].lower()
			data_offset = f.tell()
			break
		# VIEWPOINT / other keys ignored

	if not fields:
		raise PointCloudLoadError("PCD header missing FIELDS.")
	if not sizes:
		sizes = [4] * len(fields)
	if not types:
		types = ["F"] * len(fields)
	if not counts:
		counts = [1] * len(fields)
	if len(sizes) != len(fields) or len(types) != len(fields) or len(counts) != len(fields):
		raise PointCloudLoadError("PCD FIELDS/SIZE/TYPE/COUNT length mismatch.")

	if points <= 0:
		points = int(width) * int(height) if width > 0 else 0

	return (
		{
			"version": version,
			"fields": fields,
			"size": sizes,
			"type": types,
			"count": counts,
			"width": width,
			"height": height,
			"points": points,
			"data": data_mode,
		},
		data_offset,
	)


def _field_index(fields: list[str], name: str) -> int:
	try:
		return fields.index(name)
	except ValueError:
		return -1


def _read_pcd_ascii(
	text: str, fields: list[str], n_points: int
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	ix = _field_index(fields, "x")
	iy = _field_index(fields, "y")
	iz = _field_index(fields, "z")
	irgb = _field_index(fields, "rgb")
	ir = _field_index(fields, "r")
	ig = _field_index(fields, "g")
	ib = _field_index(fields, "b")
	ired = _field_index(fields, "red")
	igreen = _field_index(fields, "green")
	iblue = _field_index(fields, "blue")

	points = np.zeros((n_points, 3), dtype=np.float64)
	colors: Optional[np.ndarray] = None
	want_rgb = irgb >= 0 or (ir >= 0 and ig >= 0 and ib >= 0) or (
		ired >= 0 and igreen >= 0 and iblue >= 0
	)
	if want_rgb:
		colors = np.zeros((n_points, 3), dtype=np.float64)

	lines = [ln for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
	if len(lines) < n_points:
		# Some writers omit POINTS count accuracy — take what we have
		n_use = len(lines)
		points = points[:n_use]
		if colors is not None:
			colors = colors[:n_use]
	else:
		n_use = n_points

	for i in range(n_use):
		toks = lines[i].split()
		if len(toks) < len(fields):
			raise PointCloudLoadError(f"PCD ASCII line {i + 1} has too few columns.")
		points[i, 0] = float(toks[ix])
		points[i, 1] = float(toks[iy])
		points[i, 2] = float(toks[iz])
		if colors is None:
			continue
		if irgb >= 0:
			colors[i] = _unpack_rgb_token(toks[irgb])
		elif ir >= 0:
			colors[i] = _normalize_rgb_triplet(float(toks[ir]), float(toks[ig]), float(toks[ib]))
		else:
			colors[i] = _normalize_rgb_triplet(
				float(toks[ired]), float(toks[igreen]), float(toks[iblue])
			)

	# Drop NaN / Inf points (common in organized PCD)
	finite = np.isfinite(points).all(axis=1)
	points = points[finite]
	if colors is not None:
		colors = colors[finite]
		if colors.shape[0] == 0:
			colors = None
	if points.shape[0] == 0:
		raise PointCloudLoadError("PCD contained no finite XYZ points.")
	return points, colors


def _read_pcd_binary(
	blob: bytes,
	fields: list[str],
	sizes: list[int],
	types: list[str],
	counts: list[int],
	n_points: int,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	names: list[str] = []
	formats: list = []
	offsets: list[int] = []
	offset = 0
	for name, size, typ, count in zip(fields, sizes, types, counts):
		np_t = _pcd_type_to_numpy(typ, size)
		names.append(name)
		formats.append(np_t if int(count) == 1 else (np_t, (int(count),)))
		offsets.append(offset)
		offset += int(size) * int(count)

	dtype = np.dtype(
		{"names": names, "formats": formats, "offsets": offsets, "itemsize": offset}
	)
	arr = np.frombuffer(blob, dtype=dtype, count=n_points)
	x = np.asarray(arr["x"], dtype=np.float64).reshape(-1)
	y = np.asarray(arr["y"], dtype=np.float64).reshape(-1)
	z = np.asarray(arr["z"], dtype=np.float64).reshape(-1)
	points = np.column_stack([x, y, z])

	colors: Optional[np.ndarray] = None
	if "rgb" in arr.dtype.names:
		colors = _unpack_rgb_array(np.asarray(arr["rgb"]))
	elif "r" in arr.dtype.names and "g" in arr.dtype.names and "b" in arr.dtype.names:
		colors = np.column_stack(
			[
				_channel_to_unit(np.asarray(arr["r"], dtype=np.float64)),
				_channel_to_unit(np.asarray(arr["g"], dtype=np.float64)),
				_channel_to_unit(np.asarray(arr["b"], dtype=np.float64)),
			]
		)
	elif "red" in arr.dtype.names and "green" in arr.dtype.names and "blue" in arr.dtype.names:
		colors = np.column_stack(
			[
				_channel_to_unit(np.asarray(arr["red"], dtype=np.float64)),
				_channel_to_unit(np.asarray(arr["green"], dtype=np.float64)),
				_channel_to_unit(np.asarray(arr["blue"], dtype=np.float64)),
			]
		)

	finite = np.isfinite(points).all(axis=1)
	points = np.ascontiguousarray(points[finite], dtype=np.float64)
	if colors is not None:
		colors = np.ascontiguousarray(colors[finite], dtype=np.float64)
		if colors.shape[0] == 0:
			colors = None
	if points.shape[0] == 0:
		raise PointCloudLoadError("PCD contained no finite XYZ points.")
	return points, colors


def _pcd_type_to_numpy(typ: str, size: int) -> str:
	t = typ.upper()
	if t == "F":
		if size == 8:
			return "<f8"
		return "<f4"
	if t == "U":
		return {1: "<u1", 2: "<u2", 4: "<u4", 8: "<u8"}.get(size, "<u4")
	if t == "I":
		return {1: "<i1", 2: "<i2", 4: "<i4", 8: "<i8"}.get(size, "<i4")
	# Default float
	return "<f4"


def _unpack_rgb_token(token: str) -> np.ndarray:
	"""Parse an ASCII rgb field (float bits or integer 0xRRGGBB)."""
	try:
		if "." in token or "e" in token.lower():
			val = np.array([float(token)], dtype=_RGB_PACKED_DTYPE)
			return _unpack_rgb_array(val)[0]
		ival = int(float(token))
		r = (ival >> 16) & 255
		g = (ival >> 8) & 255
		b = ival & 255
		return np.array([r, g, b], dtype=np.float64) / 255.0
	except Exception:
		return np.array([0.8, 0.8, 0.8], dtype=np.float64)


def _unpack_rgb_array(rgb_field: np.ndarray) -> np.ndarray:
	"""Unpack PCL packed float/int rgb to (N,3) float64 in 0–1."""
	raw = np.asarray(rgb_field)
	if raw.dtype == np.float32 or raw.dtype == np.float64:
		# Reinterpret float32 bits as uint32
		u = np.ascontiguousarray(raw.astype(np.float32, copy=False)).view(np.uint32)
	else:
		u = raw.astype(np.uint32, copy=False)
	r = ((u >> 16) & 255).astype(np.float64) / 255.0
	g = ((u >> 8) & 255).astype(np.float64) / 255.0
	b = (u & 255).astype(np.float64) / 255.0
	return np.column_stack([r, g, b])


def _normalize_rgb_triplet(r: float, g: float, b: float) -> np.ndarray:
	rgb = np.array([r, g, b], dtype=np.float64)
	if np.nanmax(rgb) > 1.5:
		rgb = rgb / 255.0
	return np.clip(rgb, 0.0, 1.0)


def _channel_to_unit(ch: np.ndarray) -> np.ndarray:
	ch = np.asarray(ch, dtype=np.float64).reshape(-1)
	if ch.size and np.nanmax(ch) > 1.5:
		return np.clip(ch / 255.0, 0.0, 1.0)
	return np.clip(ch, 0.0, 1.0)

import os
import sys
from pathlib import Path

# pyqtdarktheme picks the first installed Qt binding; a partial PySide6 install
# (e.g. when PySide6 is excluded from PyInstaller) breaks import unless forced.
os.environ.setdefault("QT_API", "pyqt6")

from PyQt6.QtWidgets import QApplication

import qdarktheme
from MotionStudio.core.preferences import apply_preferences, load_preferences
from MotionStudio.core.project_components import discover_all_components
from MotionStudio.platform.windows_taskbar import configure_windows_taskbar_identity
from MotionStudio.ui.main_window import MainWindow
from resources.resources_rc import load_application_icon


def main() -> None:
	"""
	Entry point for launching the PyEngine editor application.
	"""
	configure_windows_taskbar_identity()

	app = QApplication(sys.argv)
	app_icon = load_application_icon()
	if app_icon is not None:
		app.setWindowIcon(app_icon)

	qdarktheme.enable_hi_dpi()
	apply_preferences(load_preferences())

	# Discover components from both engine and project before creating MainWindow
	# This ensures components are registered before the Inspector tries to list them
	project_dir = Path("Test Project")  # Default project directory
	if len(sys.argv) > 1:
		project_dir = Path(sys.argv[1])

	engine_components, project_components = discover_all_components(project_dir)

	if engine_components:
		print(f"Loaded {len(engine_components)} engine component(s)", flush=True)
	if project_components:
		print(f"Loaded {len(project_components)} project component(s) from {project_dir}: {', '.join(project_components)}", flush=True)

	window = MainWindow()
	if app_icon is not None:
		window.setWindowIcon(app_icon)
	window.show()
	sys.exit(app.exec())


if __name__ == "__main__":
	main()

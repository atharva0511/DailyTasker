from __future__ import annotations
from typing import Dict, Optional, Set, Tuple, Any
import vtk # type: ignore
from PyQt6.QtGui import QVector3D

from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.render.vtk.camera_view_sync import register_camera_view_sync
from MotionStudio.render.vtk.gizmo.utils import world_length_for_pixels
from MotionStudio.render.vtk.scene_root import VtkSceneRoot

WAYPOINT_AXES_LINE_OPACITY = 0.4
WAYPOINT_MARKER_OPACITY = 0.6
# Screen-space axis length (pixels), recomputed on camera zoom like waypoint discs.
WAYPOINT_AXIS_PIXEL_LENGTH = 36.0
# Custom-feature waypoint disc radius (pixels), recomputed on camera zoom.
WAYPOINT_MARKER_PIXEL_RADIUS = 14.0
WAYPOINT_MARKER_SELECTED_PIXEL_RADIUS = 16.0
# Selected path overlay / selected-segment waypoint discs (light green).
PATH_SELECTED_RGB = (40 / 255.0, 255 / 255.0, 120 / 255.0)
WAYPOINT_MARKER_DEFAULT_RGB = (1.0, 232 / 255.0, 64 / 255.0)
WAYPOINT_MARKER_SELECTED_RGB = (1.0, 145 / 255.0, 0.0)

_WaypointAxisSpec = Tuple[QVector3D, QVector3D, QVector3D, QVector3D]

class VtkPathBridge:
    """
    Renders path data from PathComponent as VTK actors.
    """
    def __init__(self, plotter, scene: Scene, selection: SelectionModel, scene_root: VtkSceneRoot) -> None:
        self._plotter = plotter
        self._scene = scene
        self._selection = selection
        self._scene_root = scene_root

        # entity_id -> vtkActor
        self._path_actors: Dict[str, vtk.vtkActor] = {}
        # entity_id -> vtkActor (selected feature overlay)
        self._selected_feature_actors: Dict[str, vtk.vtkActor] = {}
        # entity_id -> vtkActor (waypoint axes)
        self._axes_actors: Dict[str, vtk.vtkActor] = {}
        # entity_id -> [(origin, x_dir, y_dir, z_dir)] in mesh-local space
        self._waypoint_axes_specs: Dict[str, list[_WaypointAxisSpec]] = {}
        # entity_id -> [(vtkFollower, vtkDiskSource), ...] camera-facing waypoint markers
        self._waypoint_marker_followers: Dict[str, list[Tuple[vtk.vtkFollower, vtk.vtkDiskSource]]] = {}
        # entity_id -> vtkActor (inter-feature dotted lines)
        self._inter_feature_actors: Dict[str, vtk.vtkActor] = {}
        # entity_id -> { point_id -> (feature_idx, waypoint_idx) } for waypoint spheres
        self._waypoint_point_mapping: Dict[str, Dict[int, Tuple[int, int]]] = {}
        # actor address -> entity_id
        self._actor_to_entity: Dict[int, str] = {}
        # actor address -> { vtk_point_id -> (feature_idx, waypoint_idx) }
        self._point_mappings: Dict[int, Dict[int, Tuple[int, int]]] = {}
        # entity_id -> { cell_id -> feature_idx }
        self._cell_to_feature: Dict[str, Dict[int, int]] = {}
        # entity_id -> [((feature_idx, waypoint_idx), world_pos)]
        self._waypoint_world_points: Dict[str, list[Tuple[Tuple[int, int], QVector3D]]] = {}
        # Paths waiting for mesh actors (e.g. during deferred bulk load)
        self._pending_path_sync: Set[str] = set()

        # Preview actor for drawing
        self._preview_actor: Optional[vtk.vtkActor] = None
        self._init_preview_actor()

        # Wire scene events
        self._scene.events.entity_changed.connect(self._on_entity_changed)
        self._scene.events.entity_transform_changed.connect(self._on_entity_transform_changed)  # Listen to transform-only changes
        self._scene.events.entity_removed.connect(self._on_entity_removed)
        # Keep waypoint marker discs screen-size constant during camera motion.
        self._iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
        if self._iren is not None:
            self._iren.AddObserver("InteractionEvent", self._on_camera_interaction, 0.0)
            self._iren.AddObserver("MouseWheelForwardEvent", self._on_camera_interaction, 0.0)
            self._iren.AddObserver("MouseWheelBackwardEvent", self._on_camera_interaction, 0.0)
        register_camera_view_sync(self._plotter, self.sync_screen_space_visuals)
        # Wire feature selection to update line coloring
        try:
            self._selection.current_feature_changed.connect(self._on_feature_selection_changed)
            self._selection.current_entity_changed.connect(self._on_entity_selection_changed)
            self._selection.current_waypoint_changed.connect(self._on_waypoint_selection_changed)
            self._selection.selection_changed.connect(self._on_selection_set_changed)
        except Exception:
            pass

    def _init_preview_actor(self):
        pd = vtk.vtkPolyData()
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputData(pd)
        self._preview_actor = vtk.vtkActor()
        self._preview_actor.SetMapper(mapper)
        self._preview_actor.GetProperty().SetColor(1.0, 1.0, 0.0) # Yellow
        self._preview_actor.GetProperty().SetLineWidth(2.0)
        self._preview_actor.GetProperty().SetPointSize(10.0)
        self._preview_actor.SetVisibility(False)
        self._preview_actor.SetPickable(False)
        self._plotter.add_actor(self._preview_actor, pickable=False)

    def _on_entity_changed(self, entity_id: str) -> None:
        self._sync_path(entity_id)

    def _on_entity_transform_changed(self, entity_id: str) -> None:
        """
        Handle transform-only changes. Updates path actor transforms without
        rebuilding the geometry (since waypoints are in local space).
        """
        entity = self._scene.find_by_id(entity_id)
        if entity is None:
            return

        path_comp = entity.get_component(PathComponent)
        if path_comp is None:
            return

        mesh_actor = self._scene_root.actor_for(entity_id)
        if mesh_actor is None:
            return

        # Update transform matrices for path actors to match mesh transform
        actor = self._path_actors.get(entity_id)
        if actor is not None:
            try:
                actor.SetUserMatrix(mesh_actor.GetUserMatrix())
                actor.Modified()
            except Exception:
                pass

        axes_actor = self._axes_actors.get(entity_id)
        if axes_actor is not None:
            try:
                axes_actor.SetUserMatrix(mesh_actor.GetUserMatrix())
                axes_actor.Modified()
            except Exception:
                pass

        # Update selected feature overlay transform
        overlay = self._selected_feature_actors.get(entity_id)
        if overlay is not None:
            try:
                overlay.SetUserMatrix(mesh_actor.GetUserMatrix())
                overlay.Modified()
            except Exception:
                pass

        # Update inter-feature actor transform
        inter_feature_key = f"{entity_id}_inter"
        inter_actor = self._inter_feature_actors.get(inter_feature_key)
        if inter_actor is not None:
            try:
                inter_actor.SetUserMatrix(mesh_actor.GetUserMatrix())
                inter_actor.Modified()
            except Exception:
                pass

        # Update waypoint spheres position when entity transform changes
        # Only update if this entity is the active path entity.
        # This matters during waypoint editing where selection.current is temporarily
        # redirected to a waypoint proxy entity for gizmo placement.
        if self._active_path_entity_id() == entity_id:
            self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
            self._update_waypoint_axes_scale(entity_id, path_comp, mesh_actor)

        try:
            self._plotter.render()
        except Exception:
            pass

    def _on_entity_removed(self, entity_id: str) -> None:
        self._remove_path_actor(entity_id)

    def _on_entity_selection_changed(self, _entity) -> None:
        self._on_selection_set_changed()

    def _on_selection_set_changed(self) -> None:
        """Hide path edit overlays on non-primary / deselected entities."""
        try:
            self._refresh_path_overlay_visibility()
            entity_id = self._active_path_entity_id()
            if entity_id is None:
                return
            entity = self._scene.find_by_id(entity_id)
            if entity is None:
                return
            path_comp = entity.get_component(PathComponent)
            mesh_actor = self._scene_root.actor_for(entity_id)
            if path_comp and mesh_actor:
                self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
                self._update_waypoint_axes_scale(entity_id, path_comp, mesh_actor)
        except Exception:
            pass

    def _on_feature_selection_changed(self, _feature_idx) -> None:
        # Update highlight and waypoint disc colors for the current entity.
        try:
            entity_id = self._active_path_entity_id()
            if entity_id is None:
                return
            entity = self._scene.find_by_id(entity_id)
            if entity is not None:
                path_comp = entity.get_component(PathComponent)
                mesh_actor = self._scene_root.actor_for(entity_id)
                if path_comp is not None and mesh_actor is not None:
                    self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
            self._apply_feature_colors(entity_id)
        except Exception:
            pass

    def sync_screen_space_visuals(self) -> None:
        """Recompute waypoint disc and axis sizes for the active path entity."""
        try:
            entity_id = self._active_path_entity_id()
            if entity_id is None:
                return
            entity = self._scene.find_by_id(entity_id)
            if entity is None:
                return
            path_comp = entity.get_component(PathComponent)
            mesh_actor = self._scene_root.actor_for(entity_id)
            if path_comp is None or mesh_actor is None:
                return
            self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
            self._update_waypoint_axes_scale(entity_id, path_comp, mesh_actor)
        except Exception:
            pass

    def _on_camera_interaction(self, _obj, _ev) -> None:
        """Keep waypoint discs and axes constant in screen space while the camera moves."""
        try:
            self.sync_screen_space_visuals()
            self._plotter.render()
        except Exception:
            pass

    def _on_waypoint_selection_changed(self, _waypoint: Optional[Tuple[int, int]]) -> None:
        """Refresh waypoint marker style (selected waypoint is larger + orange)."""
        try:
            entity_id = self._active_path_entity_id()
            if entity_id is None:
                return
            entity = self._scene.find_by_id(entity_id)
            if entity is None:
                return
            path_comp = entity.get_component(PathComponent)
            mesh_actor = self._scene_root.actor_for(entity_id)
            if path_comp is None or mesh_actor is None:
                return
            self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
        except Exception:
            pass

    def _active_path_entity_id(self) -> Optional[str]:
        """
        Entity id whose path edit overlays (axes, waypoint discs, feature highlight)
        should be shown: primary selected entity only, or the path owner while the
        waypoint proxy is selected for gizmo editing.
        """
        current = self._selection.current
        if current is not None and getattr(current, "name", "") == "__waypoint_proxy__":
            wp_entity_id = getattr(self._selection, "current_waypoint_entity_id", None)
            if isinstance(wp_entity_id, str) and self._scene.find_by_id(wp_entity_id) is not None:
                return wp_entity_id
            return None
        if (
            current is not None
            and self._scene.find_by_id(current.id) is not None
            and self._selection.is_entity_id_selected(current.id)
        ):
            return current.id
        return None

    def _refresh_path_overlay_visibility(self) -> None:
        """Show axes / waypoint discs only for the active path entity."""
        active = self._active_path_entity_id()
        for eid, axes_actor in self._axes_actors.items():
            axes_actor.SetVisibility(1 if eid == active else 0)
        for eid, followers in self._waypoint_marker_followers.items():
            vis = 1 if eid == active else 0
            for follower, _src in followers:
                follower.SetVisibility(vis)
        for eid in list(self._path_actors.keys()):
            self._apply_feature_colors(eid)
        try:
            self._plotter.render()
        except Exception:
            pass

    def entity_id_for_waypoint_marker(self, actor: vtk.vtkProp) -> Optional[str]:
        """Return entity id if ``actor`` is a custom-feature waypoint disc."""
        for eid, followers in self._waypoint_marker_followers.items():
            for follower, _src in followers:
                if actor == follower:
                    return eid
        return None

    def _sync_path(self, entity_id: str) -> None:
        entity = self._scene.find_by_id(entity_id)
        if entity is None:
            return

        path_comp = entity.get_component(PathComponent)
        if path_comp is None:
            self._pending_path_sync.discard(entity_id)
            self._remove_path_actor(entity_id)
            return

        mesh_actor = self._scene_root.actor_for(entity_id)
        if mesh_actor is None:
            # Mesh actor may not exist yet during bulk project load (deferred VTK sync).
            if entity.get_component(MeshComponent) is not None:
                self._pending_path_sync.add(entity_id)
                return
            self._pending_path_sync.discard(entity_id)
            self._remove_path_actor(entity_id)
            return

        self._pending_path_sync.discard(entity_id)

        # Prepare geometry
        poly = vtk.vtkPolyData()
        pts = vtk.vtkPoints()
        lines = vtk.vtkCellArray()
        
        mapping = {}
        current_pt_id = 0
        cell_to_feature: Dict[int, int] = {}
        current_cell_id = 0
        
        # Get mesh points for waypoint generation
        mesh_poly = mesh_actor.GetMapper().GetInput()
        
        global_offsets = {}

        # Store first and last waypoint IDs for each feature for inter-feature connections
        feature_first_pt_ids: Dict[int, int] = {}
        feature_last_pt_ids: Dict[int, int] = {}
        
        for f_idx, feature in enumerate(path_comp.features):
            waypoints = feature.generate_waypoints(mesh_poly, global_offsets)
            
            if len(waypoints) == 0:
                continue
            
            first_in_feature = True
            for w_idx, wp in enumerate(waypoints):
                pts.InsertNextPoint(wp.position.x(), wp.position.y(), wp.position.z())
                mapping[current_pt_id] = (f_idx, w_idx)
                
                # Track first waypoint of this feature
                if first_in_feature:
                    feature_first_pt_ids[f_idx] = current_pt_id
                
                if not first_in_feature:
                    line = vtk.vtkLine()
                    line.GetPointIds().SetId(0, current_pt_id - 1)
                    line.GetPointIds().SetId(1, current_pt_id)
                    lines.InsertNextCell(line)
                    cell_to_feature[current_cell_id] = f_idx
                    current_cell_id += 1
                
                # Track last waypoint of this feature
                feature_last_pt_ids[f_idx] = current_pt_id
                first_in_feature = False
                current_pt_id += 1

        poly.SetPoints(pts)
        poly.SetLines(lines)

        # Per-cell colors for feature highlighting (single actor)
        cell_colors = vtk.vtkUnsignedCharArray()
        cell_colors.SetName("PathColors")
        cell_colors.SetNumberOfComponents(3)
        active_id = self._active_path_entity_id()
        selected_feature = self._selection.current_feature_idx if active_id == entity_id else None
        num_cells = int(poly.GetNumberOfCells())
        for cid in range(num_cells):
            # Base actor is always unselected shade; selection is drawn with a separate overlay actor.
            cell_colors.InsertNextTuple3(0, 120, 0)
        poly.GetCellData().SetScalars(cell_colors)

        # Waypoint axes visualizer (RGB X/Y/Z); length scales with camera zoom.
        axes_specs = self._collect_waypoint_axes_specs(path_comp)
        self._waypoint_axes_specs[entity_id] = axes_specs
        axes_pd = vtk.vtkPolyData()
        mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
        self._fill_waypoint_axes_polydata(
            axes_pd,
            axes_specs,
            self._get_renderer(),
            mesh_matrix,
        )

        # Create or update actor
        actor = self._path_actors.get(entity_id)
        if actor is None:
            mapper = vtk.vtkPolyDataMapper()
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            # Use per-cell colors; keep base property neutral
            actor.GetProperty().SetColor(1.0, 1.0, 1.0)
            actor.GetProperty().SetLineWidth(3.0)
            self._path_actors[entity_id] = actor
            self._plotter.add_actor(actor)
            
            key = self._actor_key(actor)
            self._actor_to_entity[key] = entity_id
        
        actor.GetMapper().SetInputData(poly)
        try:
            actor.GetMapper().SetScalarModeToUseCellData()
            actor.GetMapper().ScalarVisibilityOn()
            actor.GetMapper().SetColorModeToDirectScalars()
        except Exception:
            pass
        
        # Set transform to match mesh (path is in local space)
        actor.SetUserMatrix(mesh_actor.GetUserMatrix())
        
        # Create/update waypoint axes actor
        axes_actor = self._axes_actors.get(entity_id)
        if axes_actor is None:
            axes_mapper = vtk.vtkPolyDataMapper()
            axes_actor = vtk.vtkActor()
            axes_actor.SetMapper(axes_mapper)
            axes_actor.SetPickable(False)
            try:
                axes_actor.GetProperty().SetLineWidth(2.0)
                axes_actor.GetProperty().SetLighting(False)
                axes_actor.GetProperty().SetOpacity(WAYPOINT_AXES_LINE_OPACITY)
            except Exception:
                pass
            self._axes_actors[entity_id] = axes_actor
            try:
                self._plotter.add_actor(axes_actor, pickable=False, reset_camera=False)
            except Exception:
                self._plotter.add_actor(axes_actor)

        axes_actor.GetMapper().SetInputData(axes_pd)
        try:
            axes_actor.GetMapper().SetScalarModeToUseCellData()
            axes_actor.GetMapper().ScalarVisibilityOn()
            axes_actor.GetMapper().SetColorModeToDirectScalars()
        except Exception:
            pass
        try:
            axes_actor.GetProperty().SetOpacity(WAYPOINT_AXES_LINE_OPACITY)
        except Exception:
            pass
        axes_actor.SetUserMatrix(mesh_actor.GetUserMatrix())

        # Create a separate actor for inter-feature dotted lines
        inter_feature_pd = vtk.vtkPolyData()
        inter_feature_pts = vtk.vtkPoints()
        inter_feature_lines = vtk.vtkCellArray()
        
        for f_idx in range(len(path_comp.features) - 1):
            if f_idx in feature_last_pt_ids and (f_idx + 1) in feature_first_pt_ids:
                last_pt_id = feature_last_pt_ids[f_idx]
                first_pt_id = feature_first_pt_ids[f_idx + 1]
                
                # Get world positions from the main points
                last_pt = pts.GetPoint(last_pt_id)
                first_pt = pts.GetPoint(first_pt_id)
                
                p0_id = inter_feature_pts.InsertNextPoint(last_pt)
                p1_id = inter_feature_pts.InsertNextPoint(first_pt)
                
                inter_line = vtk.vtkLine()
                inter_line.GetPointIds().SetId(0, p0_id)
                inter_line.GetPointIds().SetId(1, p1_id)
                inter_feature_lines.InsertNextCell(inter_line)
        
        inter_feature_pd.SetPoints(inter_feature_pts)
        inter_feature_pd.SetLines(inter_feature_lines)
        
        # Create or update inter-feature actor
        inter_feature_key = f"{entity_id}_inter"
        inter_actor = self._inter_feature_actors.get(inter_feature_key)
        if inter_actor is None:
            inter_mapper = vtk.vtkPolyDataMapper()
            inter_actor = vtk.vtkActor()
            inter_actor.SetMapper(inter_mapper)
            inter_actor.GetProperty().SetLineWidth(2.0)
            # Set line stipple pattern for dotted line (0xAAAA = alternating pattern)
            try:
                inter_actor.GetProperty().SetLineStipplePattern(0xAAAA)
                inter_actor.GetProperty().SetLineStippleRepeatFactor(1)
            except Exception:
                # Fallback if stipple not available - use dashed pattern
                try:
                    inter_actor.GetProperty().SetLineStipplePattern(0x00FF)
                    inter_actor.GetProperty().SetLineStippleRepeatFactor(2)
                except Exception:
                    pass
            self._inter_feature_actors[inter_feature_key] = inter_actor
            try:
                self._plotter.add_actor(inter_actor, reset_camera=False)
            except Exception:
                self._plotter.add_actor(inter_actor)

        # Pink connectors (hot pink ~ #FF69B4). Reapplied on every sync so cached
        # actors from prior sessions/scenes also pick up the color change.
        try:
            inter_actor.GetProperty().SetColor(1.0, 105 / 255.0, 180 / 255.0)
        except Exception:
            pass

        inter_actor.GetMapper().SetInputData(inter_feature_pd)
        # Set transform to match mesh (path is in local space)
        inter_actor.SetUserMatrix(mesh_actor.GetUserMatrix())

        # Store point mapping for picking
        self._point_mappings[self._actor_key(actor)] = mapping
        self._cell_to_feature[entity_id] = cell_to_feature
        # Ensure selected overlay is in sync after rebuild
        self._apply_feature_colors(entity_id)
        
        # Update waypoint discs and overlay visibility for the active entity only
        self._update_waypoint_markers(entity_id, path_comp, mesh_actor)
        self._refresh_path_overlay_visibility()
        
        self._plotter.render()

    def _apply_feature_colors(self, entity_id: str) -> None:
        actor = self._path_actors.get(entity_id)
        if actor is None:
            return
        try:
            poly = actor.GetMapper().GetInput()
        except Exception:
            return
        if poly is None:
            return

        cell_to_feature = self._cell_to_feature.get(entity_id, {})
        active_id = self._active_path_entity_id()
        selected = self._selection.current_feature_idx if active_id == entity_id else None

        # Base actor: always unselected shade
        try:
            colors = vtk.vtkUnsignedCharArray()
            colors.SetName("PathColors")
            colors.SetNumberOfComponents(3)
            n = int(poly.GetNumberOfCells())
            for _cid in range(n):
                colors.InsertNextTuple3(0, 120, 0)
            poly.GetCellData().SetScalars(colors)
            poly.Modified()
            actor.Modified()
        except Exception:
            pass

        # Selected feature overlay actor (thicker + brighter green)
        overlay = self._selected_feature_actors.get(entity_id)
        if selected is None:
            if overlay is not None:
                try:
                    self._plotter.remove_actor(overlay, reset_camera=False)
                except Exception:
                    try:
                        self._plotter.remove_actor(overlay)
                    except Exception:
                        pass
                self._selected_feature_actors.pop(entity_id, None)
            try:
                self._plotter.render()
            except Exception:
                pass
            return

        # Build a polydata containing only the selected feature's cells
        try:
            ids = vtk.vtkIdList()
            for cid, fidx in cell_to_feature.items():
                if fidx == selected:
                    ids.InsertNextId(int(cid))
            extract = vtk.vtkExtractCells()
            extract.SetInputData(poly)
            extract.SetCellList(ids)
            extract.Update()
            geom = vtk.vtkGeometryFilter()
            geom.SetInputConnection(extract.GetOutputPort())
            geom.Update()
            sel_poly = geom.GetOutput()
        except Exception:
            sel_poly = None

        if sel_poly is None:
            return

        if overlay is None:
            m = vtk.vtkPolyDataMapper()
            overlay = vtk.vtkActor()
            overlay.SetMapper(m)
            overlay.SetPickable(True)  # allow clicking the path lines for feature selection
            try:
                overlay.GetProperty().SetLineWidth(6.0)
                overlay.GetProperty().SetColor(*PATH_SELECTED_RGB)
            except Exception:
                pass
            # IMPORTANT: ensure overlay uses the actor property color (not scalar colors from the polydata)
            try:
                m.ScalarVisibilityOff()
            except Exception:
                pass
            self._selected_feature_actors[entity_id] = overlay
            try:
                self._plotter.add_actor(overlay, reset_camera=False)
            except Exception:
                self._plotter.add_actor(overlay)

        overlay.GetMapper().SetInputData(sel_poly)
        try:
            overlay.SetUserMatrix(actor.GetUserMatrix())
        except Exception:
            pass

        try:
            self._plotter.render()
        except Exception:
            pass

    def _remove_path_actor(self, entity_id: str) -> None:
        actor = self._path_actors.pop(entity_id, None)
        if actor:
            key = self._actor_key(actor)
            self._actor_to_entity.pop(key, None)
            self._point_mappings.pop(key, None)
            self._cell_to_feature.pop(entity_id, None)
            self._plotter.remove_actor(actor)
            self._plotter.render()
        overlay = self._selected_feature_actors.pop(entity_id, None)
        if overlay:
            try:
                self._plotter.remove_actor(overlay, reset_camera=False)
            except Exception:
                try:
                    self._plotter.remove_actor(overlay)
                except Exception:
                    pass
        axes_actor = self._axes_actors.pop(entity_id, None)
        if axes_actor:
            try:
                self._plotter.remove_actor(axes_actor, reset_camera=False)
            except Exception:
                try:
                    self._plotter.remove_actor(axes_actor)
                except Exception:
                    pass
        self._waypoint_axes_specs.pop(entity_id, None)
        self._remove_waypoint_markers(entity_id)
        # Remove inter-feature actor
        inter_feature_key = f"{entity_id}_inter"
        inter_actor = self._inter_feature_actors.pop(inter_feature_key, None)
        if inter_actor:
            try:
                self._plotter.remove_actor(inter_actor, reset_camera=False)
            except Exception:
                try:
                    self._plotter.remove_actor(inter_actor)
                except Exception:
                    pass
        self._waypoint_point_mapping.pop(entity_id, None)
        self._waypoint_world_points.pop(entity_id, None)

    @staticmethod
    def _actor_key(actor: vtk.vtkActor) -> int:
        try:
            s = actor.GetAddressAsString("")
            if "0x" in s:
                return int(s.split("0x", 1)[1], 16)
        except Exception:
            pass
        return id(actor)

    def get_feature_at(self, actor: vtk.vtkActor, point_id: int) -> Optional[Tuple[int, int]]:
        """Returns (feature_index, waypoint_index) for a given picked point."""
        key = self._actor_key(actor)
        mapping = self._point_mappings.get(key)
        if mapping:
            return mapping.get(point_id)
        return None

    def get_waypoint_at_pick_position(
        self,
        entity_id: str,
        world_pos: QVector3D,
        max_pixels: float = 16.0,
    ) -> Optional[Tuple[int, int]]:
        """
        Resolve closest waypoint to a picked world position.
        Used for glyph-based sphere actors where VTK point ids don't map 1:1 to waypoints.
        """
        points = self._waypoint_world_points.get(entity_id)
        if not points:
            return None
        from MotionStudio.render.vtk.gizmo.utils import world_length_for_pixels
        renderer = self._get_renderer()
        if renderer is None:
            return None
        best: Optional[Tuple[int, int]] = None
        best_d2 = float("inf")
        for key, wp_pos in points:
            dx = float(wp_pos.x() - world_pos.x())
            dy = float(wp_pos.y() - world_pos.y())
            dz = float(wp_pos.z() - world_pos.z())
            d2 = dx * dx + dy * dy + dz * dz
            if d2 < best_d2:
                best_d2 = d2
                best = key
        if best is None:
            return None
        # Reject far hits to avoid accidental selections.
        threshold = float(world_length_for_pixels(renderer, world_pos, max_pixels))
        if threshold <= 0.0:
            return None
        return best if best_d2 <= (threshold * threshold) else None

    @staticmethod
    def _local_to_world(mesh_matrix, local: QVector3D) -> QVector3D:
        if mesh_matrix is None:
            return QVector3D(local)
        out = [0.0, 0.0, 0.0, 1.0]
        mesh_matrix.MultiplyPoint(
            [float(local.x()), float(local.y()), float(local.z()), 1.0],
            out,
        )
        w = float(out[3]) if abs(out[3]) > 1e-9 else 1.0
        return QVector3D(out[0] / w, out[1] / w, out[2] / w)

    def _local_axis_length_for_pixels(
        self,
        renderer,
        mesh_matrix,
        origin: QVector3D,
        direction: QVector3D,
        pixels: float,
    ) -> float:
        """Mesh-local axis length matching ``pixels`` on screen at ``origin``."""
        if renderer is None:
            return 4.0
        world_origin = self._local_to_world(mesh_matrix, origin)
        world_len = max(1e-6, float(world_length_for_pixels(renderer, world_origin, pixels)))
        dir_len = max(1e-9, float(direction.length()))
        unit = QVector3D(
            direction.x() / dir_len,
            direction.y() / dir_len,
            direction.z() / dir_len,
        )
        world_unit = self._local_to_world(mesh_matrix, origin + unit)
        local_unit_world = float((world_unit - world_origin).length())
        if local_unit_world < 1e-9:
            return world_len
        return world_len / local_unit_world

    @staticmethod
    def _collect_waypoint_axes_specs(path_comp: PathComponent) -> list[_WaypointAxisSpec]:
        specs: list[_WaypointAxisSpec] = []
        for feature in path_comp.features:
            for wp in feature.waypoints:
                o = wp.position
                q = wp.rotation
                try:
                    x_dir = q.rotatedVector(QVector3D(1, 0, 0)).normalized()
                    y_dir = q.rotatedVector(QVector3D(0, 1, 0)).normalized()
                    z_dir = q.rotatedVector(QVector3D(0, 0, 1)).normalized()
                except Exception:
                    x_dir = QVector3D(1, 0, 0)
                    y_dir = QVector3D(0, 1, 0)
                    z_dir = QVector3D(0, 0, 1)
                specs.append((QVector3D(o), x_dir, y_dir, z_dir))
        return specs

    def _fill_waypoint_axes_polydata(
        self,
        axes_pd: vtk.vtkPolyData,
        specs: list[_WaypointAxisSpec],
        renderer,
        mesh_matrix,
        *,
        pixel_length: float = WAYPOINT_AXIS_PIXEL_LENGTH,
    ) -> None:
        axes_pts = vtk.vtkPoints()
        axes_lines = vtk.vtkCellArray()
        colors = vtk.vtkUnsignedCharArray()
        colors.SetName("Colors")
        colors.SetNumberOfComponents(3)

        for o, x_dir, y_dir, z_dir in specs:
            len_x = self._local_axis_length_for_pixels(renderer, mesh_matrix, o, x_dir, pixel_length)
            len_y = self._local_axis_length_for_pixels(renderer, mesh_matrix, o, y_dir, pixel_length)
            len_z = self._local_axis_length_for_pixels(renderer, mesh_matrix, o, z_dir, pixel_length)

            p0_id = axes_pts.InsertNextPoint(o.x(), o.y(), o.z())
            px = o + x_dir * len_x
            py = o + y_dir * len_y
            pz = o + z_dir * len_z
            px_id = axes_pts.InsertNextPoint(px.x(), px.y(), px.z())
            py_id = axes_pts.InsertNextPoint(py.x(), py.y(), py.z())
            pz_id = axes_pts.InsertNextPoint(pz.x(), pz.y(), pz.z())

            line_x = vtk.vtkLine()
            line_x.GetPointIds().SetId(0, p0_id)
            line_x.GetPointIds().SetId(1, px_id)
            axes_lines.InsertNextCell(line_x)
            colors.InsertNextTuple3(255, 0, 0)

            line_y = vtk.vtkLine()
            line_y.GetPointIds().SetId(0, p0_id)
            line_y.GetPointIds().SetId(1, py_id)
            axes_lines.InsertNextCell(line_y)
            colors.InsertNextTuple3(0, 255, 0)

            line_z = vtk.vtkLine()
            line_z.GetPointIds().SetId(0, p0_id)
            line_z.GetPointIds().SetId(1, pz_id)
            axes_lines.InsertNextCell(line_z)
            colors.InsertNextTuple3(0, 0, 255)

        axes_pd.SetPoints(axes_pts)
        axes_pd.SetLines(axes_lines)
        axes_pd.GetCellData().SetScalars(colors)
        axes_pd.Modified()

    def _update_waypoint_axes_scale(
        self,
        entity_id: str,
        path_comp: PathComponent,
        mesh_actor: vtk.vtkActor,
    ) -> None:
        """Recompute waypoint RGB axis lengths for constant on-screen size."""
        axes_actor = self._axes_actors.get(entity_id)
        if axes_actor is None:
            return
        try:
            axes_pd = axes_actor.GetMapper().GetInput()
        except Exception:
            return
        if axes_pd is None:
            return

        specs = self._waypoint_axes_specs.get(entity_id)
        if not specs:
            specs = self._collect_waypoint_axes_specs(path_comp)
            self._waypoint_axes_specs[entity_id] = specs

        mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
        self._fill_waypoint_axes_polydata(
            axes_pd,
            specs,
            self._get_renderer(),
            mesh_matrix,
        )
        try:
            axes_actor.GetMapper().SetInputData(axes_pd)
            axes_actor.Modified()
        except Exception:
            pass

    def _create_waypoint_disk_follower(self) -> Tuple[vtk.vtkFollower, vtk.vtkDiskSource]:
        """Camera-facing filled disc (lightweight vs glyph spheres)."""
        src = vtk.vtkDiskSource()
        src.SetInnerRadius(0.0)
        src.SetOuterRadius(1.0)
        src.SetCircumferentialResolution(8)
        src.SetCenter(0.0, 0.0, 0.0)
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(src.GetOutputPort())
        follower = vtk.vtkFollower()
        follower.SetMapper(mapper)
        follower.SetPickable(True)
        try:
            prop = follower.GetProperty()
            prop.SetAmbient(1.0)
            prop.SetDiffuse(0.0)
            prop.SetSpecular(0.0)
            prop.SetLighting(False)
            prop.SetOpacity(WAYPOINT_MARKER_OPACITY)
        except Exception:
            pass
        renderer = self._get_renderer()
        if renderer is not None:
            try:
                cam = renderer.GetActiveCamera()
                if cam is not None:
                    follower.SetCamera(cam)
            except Exception:
                pass
        return follower, src

    def _remove_waypoint_markers(self, entity_id: str) -> None:
        followers = self._waypoint_marker_followers.pop(entity_id, [])
        for follower, _src in followers:
            key = self._actor_key(follower)
            self._actor_to_entity.pop(key, None)
            try:
                self._plotter.remove_actor(follower, reset_camera=False)
            except Exception:
                try:
                    self._plotter.remove_actor(follower)
                except Exception:
                    pass

    def _update_waypoint_markers(self, entity_id: str, path_comp: PathComponent, mesh_actor: vtk.vtkActor) -> None:
        """Update camera-facing waypoint discs for CustomFeature waypoints."""
        from MotionStudio.render.vtk.gizmo.utils import world_length_for_pixels

        is_active = self._active_path_entity_id() == entity_id
        waypoint_world_points: list[Tuple[Tuple[int, int], QVector3D]] = []
        marker_specs: list[Tuple[Tuple[int, int], QVector3D, float, Tuple[float, float, float]]] = []

        mesh_matrix = mesh_actor.GetUserMatrix() if mesh_actor else None
        from MotionStudio.core.components.feature import CustomFeature

        selected_waypoint = (
            self._selection.current_waypoint
            if getattr(self._selection, "current_waypoint_entity_id", None) == entity_id
            else None
        )
        selected_feature_idx = (
            self._selection.current_feature_idx if is_active else None
        )
        # Waypoint pick does not always set current_feature_idx; treat that
        # waypoint's segment as the active custom segment for disc coloring.
        active_custom_fidx = (
            selected_waypoint[0]
            if selected_waypoint is not None
            else selected_feature_idx
        )

        for f_idx, feature in enumerate(path_comp.features):
            if not isinstance(feature, CustomFeature):
                continue
            mesh_poly = mesh_actor.GetMapper().GetInput() if mesh_actor else None
            global_offsets: dict = {}
            waypoints = feature.generate_waypoints(mesh_poly, global_offsets) if mesh_poly else feature.waypoints
            for w_idx, wp in enumerate(waypoints):
                local_pos = wp.position
                if mesh_matrix:
                    out = [0.0, 0.0, 0.0, 1.0]
                    mesh_matrix.MultiplyPoint(
                        [float(local_pos.x()), float(local_pos.y()), float(local_pos.z()), 1.0], out
                    )
                    world_pos = QVector3D(
                        out[0] / out[3] if abs(out[3]) > 1e-9 else out[0],
                        out[1] / out[3] if abs(out[3]) > 1e-9 else out[1],
                        out[2] / out[3] if abs(out[3]) > 1e-9 else out[2],
                    )
                else:
                    world_pos = local_pos
                key = (f_idx, w_idx)
                waypoint_world_points.append((key, QVector3D(world_pos)))
                is_wp_selected = selected_waypoint == key
                renderer = self._get_renderer()
                pixel_radius = (
                    WAYPOINT_MARKER_SELECTED_PIXEL_RADIUS
                    if is_wp_selected
                    else WAYPOINT_MARKER_PIXEL_RADIUS
                )
                if renderer is not None:
                    radius_world = max(1e-4, float(world_length_for_pixels(renderer, world_pos, pixel_radius)))
                else:
                    radius_world = 0.03
                if is_wp_selected:
                    rgb = WAYPOINT_MARKER_SELECTED_RGB
                elif active_custom_fidx == f_idx:
                    rgb = PATH_SELECTED_RGB
                else:
                    rgb = WAYPOINT_MARKER_DEFAULT_RGB
                marker_specs.append((key, world_pos, radius_world, rgb))

        followers = self._waypoint_marker_followers.get(entity_id, [])
        while len(followers) < len(marker_specs):
            follower, src = self._create_waypoint_disk_follower()
            try:
                self._plotter.add_actor(follower, reset_camera=False)
            except Exception:
                self._plotter.add_actor(follower)
            key = self._actor_key(follower)
            self._actor_to_entity[key] = entity_id
            followers.append((follower, src))
        while len(followers) > len(marker_specs):
            follower, _src = followers.pop()
            actor_key = self._actor_key(follower)
            self._actor_to_entity.pop(actor_key, None)
            try:
                self._plotter.remove_actor(follower, reset_camera=False)
            except Exception:
                try:
                    self._plotter.remove_actor(follower)
                except Exception:
                    pass
        self._waypoint_marker_followers[entity_id] = followers

        renderer = self._get_renderer()
        cam = None
        if renderer is not None:
            try:
                cam = renderer.GetActiveCamera()
            except Exception:
                cam = None

        for i, (_key, world_pos, radius_world, rgb) in enumerate(marker_specs):
            follower, disk_src = followers[i]
            if cam is not None:
                try:
                    follower.SetCamera(cam)
                except Exception:
                    pass
            disk_src.SetOuterRadius(float(radius_world))
            disk_src.Update()
            follower.SetPosition(float(world_pos.x()), float(world_pos.y()), float(world_pos.z()))
            try:
                follower.GetProperty().SetColor(rgb[0], rgb[1], rgb[2])
                follower.GetProperty().SetOpacity(WAYPOINT_MARKER_OPACITY)
            except Exception:
                pass
            follower.SetVisibility(1 if is_active else 0)
            follower.SetPickable(True)

        self._waypoint_point_mapping.pop(entity_id, None)
        self._waypoint_world_points[entity_id] = waypoint_world_points
    
    def _get_renderer(self):
        """Get the active renderer."""
        try:
            return getattr(self._plotter, "renderer", None)
        except Exception:
            return None
    
    def set_preview_points(self, world_points: list[QVector3D], entity_id: Optional[str] = None):
        """Updates the preview actor with points. Points are expected in world space."""
        if not self._preview_actor:
            return
        
        if not world_points:
            self._preview_actor.SetVisibility(False)
            self._plotter.render()
            return

        pts = vtk.vtkPoints()
        lines = vtk.vtkCellArray()
        verts = vtk.vtkCellArray()

        # If an entity_id is provided, convert world points to local space
        # so we can use the mesh's UserMatrix for consistent rendering.
        # But for preview, it might be simpler to keep it in world space and SetUserMatrix(None).
        self._preview_actor.SetUserMatrix(None)

        for i, p in enumerate(world_points):
            pts.InsertNextPoint(p.x(), p.y(), p.z())
            verts.InsertNextCell(1)
            verts.InsertCellPoint(i)
            if i > 0:
                line = vtk.vtkLine()
                line.GetPointIds().SetId(0, i - 1)
                line.GetPointIds().SetId(1, i)
                lines.InsertNextCell(line)

        pd = self._preview_actor.GetMapper().GetInput()
        pd.SetPoints(pts)
        pd.SetLines(lines)
        pd.SetVerts(verts)
        pd.Modified()
        self._preview_actor.SetVisibility(True)
        self._plotter.render()


from __future__ import annotations

from typing import Optional, Tuple

import vtk  # type: ignore

from PyQt6.QtCore import QObject, Qt, pyqtSignal
from PyQt6.QtGui import QVector3D
from PyQt6.QtWidgets import QApplication

from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.scene.scene import Scene
from MotionStudio.render.vtk.scene_root import VtkSceneRoot
from MotionStudio.render.vtk.camera_view_sync import register_camera_view_sync
from MotionStudio.render.vtk.gizmo.utils import world_length_for_pixels


class VtkPickerBridge(QObject):
	"""
	Connects VTK click-picking to the editor's SelectionModel.
	"""
	vertex_picked = pyqtSignal(str, int)  # entity_id, point_id
	feature_picked = pyqtSignal(str, int, int) # entity_id, feature_idx, waypoint_idx
	face_picked = pyqtSignal(str, int, QVector3D, QVector3D)  # entity_id, cell_id, pick_position, normal
	waypoint_picked = pyqtSignal(str, int, int)  # entity_id, feature_idx, waypoint_idx

	def __init__(self, plotter, scene: Scene, selection: SelectionModel, scene_root: VtkSceneRoot, path_bridge: Optional[Any] = None) -> None:
		super().__init__()
		self._plotter = plotter
		self._scene = scene
		self._selection = selection
		self._scene_root = scene_root
		self._path_bridge = path_bridge
		self._selection_mode: str = "object"  # object|vertex|edge|face
		self._lock_entity_selection: bool = False

		self._sub_entity_id: Optional[str] = None
		self._sub_point_id: int = -1
		self._sub_edge_point_ids: Optional[Tuple[int, int]] = None
		self._sub_cell_id: int = -1

		self._vertex_actor: Optional[vtk.vtkActor] = None
		self._vertex_source: Optional[vtk.vtkSphereSource] = None
		self._edge_actor: Optional[vtk.vtkActor] = None
		self._edge_source: Optional[vtk.vtkLineSource] = None
		self._face_actor: Optional[vtk.vtkActor] = None
		self._face_filter: Optional[vtk.vtkExtractCells] = None
		self._face_geom: Optional[vtk.vtkGeometryFilter] = None

		# Hover preview (vertex mode only): a separate marker that follows the
		# nearest vertex under the cursor before any click.
		self._hover_vertex_actor: Optional[vtk.vtkActor] = None
		self._hover_vertex_source: Optional[vtk.vtkSphereSource] = None
		self._hover_entity_id: Optional[str] = None
		self._hover_point_id: int = -1
		self._hover_picked_actor: Optional[vtk.vtkActor] = None
		# Separate picker for hover so we don't disturb the click picker's state.
		self._hover_picker = vtk.vtkCellPicker()
		try:
			self._hover_picker.SetTolerance(0.0005)
		except Exception:
			pass

		# Cell picker tends to be more reliable than PropPicker for meshes
		self._picker = vtk.vtkCellPicker()
		try:
			self._picker.SetTolerance(0.0005)
		except Exception:
			pass

		# Install on the underlying interactor
		iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if iren is None:
			raise RuntimeError("QtInteractor does not expose a VTK interactor (interactor/iren).")

		self._iren = iren
		self._press_pos: Optional[tuple[int, int]] = None
		self._renderer = getattr(plotter, "renderer", None)
		if self._renderer is None:
			try:
				rw = self._iren.GetRenderWindow()
				renderers = rw.GetRenderers() if rw is not None else None
				self._renderer = renderers.GetFirstRenderer() if renderers is not None else None
			except Exception:
				self._renderer = None

		# Selection logic: record press, pick on release if movement was small.
		self._iren.AddObserver("LeftButtonPressEvent", self._on_left_press, 0.0)
		self._iren.AddObserver("LeftButtonReleaseEvent", self._on_left_release, 0.0)
		# Hover preview for vertex mode.
		self._iren.AddObserver("MouseMoveEvent", self._on_mouse_move, 0.0)
		try:
			self._iren.AddObserver("LeaveEvent", self._on_mouse_leave, 0.0)
		except Exception:
			pass

		# Keep highlight synced/cleared
		self._selection.current_entity_changed.connect(self._on_selection_changed)
		try:
			self._scene.events.entity_changed.connect(self._on_entity_changed)
		except Exception:
			pass

		self._ensure_highlights()
		# Update vertex remember-size on camera interaction
		self._iren.AddObserver("InteractionEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("MouseWheelForwardEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("MouseWheelBackwardEvent", self._on_camera_interaction, 0.0)
		register_camera_view_sync(plotter, self.sync_screen_space_visuals)

	def set_selection_mode(self, mode: str) -> None:
		mode = str(mode).lower()
		if mode not in ("object", "vertex", "edge", "face"):
			mode = "object"
		self._selection_mode = mode
		if mode == "object":
			self._clear_subselection()
		# Hide hover preview whenever leaving vertex mode.
		if mode != "vertex":
			self._hide_hover_vertex()

	def selection_mode(self) -> str:
		return self._selection_mode

	@staticmethod
	def _ctrl_pressed() -> bool:
		try:
			return bool(QApplication.keyboardModifiers() & Qt.KeyboardModifier.ControlModifier)
		except Exception:
			return False

	def _apply_entity_click(self, ent) -> None:
		"""Object-mode click: replace selection, or Ctrl toggles membership."""
		if ent is None:
			if not self._ctrl_pressed():
				self._selection.clear()
			return
		if self._ctrl_pressed():
			self._selection.toggle_entity(ent)
		else:
			self._selection.select_exclusive(ent)

	def set_lock_entity_selection(self, locked: bool) -> None:
		"""
		When True, clicks (in any selection mode) will NOT move
		`SelectionModel.current`. Sub-selection still works and the
		vertex_picked / face_picked signals still fire — only entity
		selection is frozen. Used while a VertexPickToolManager pick is armed
		so the Inspector doesn't rebuild when the user clicks a vertex on a
		different mesh.
		"""
		self._lock_entity_selection = bool(locked)

	def _ensure_highlights(self) -> None:
		if self._vertex_actor is not None and self._edge_actor is not None and self._face_actor is not None:
			return

		# Vertex marker
		src = vtk.vtkSphereSource()
		src.SetRadius(0.03)
		src.SetThetaResolution(16)
		src.SetPhiResolution(16)
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		actor = vtk.vtkActor()
		actor.SetMapper(mapper)
		actor.SetPickable(False)
		try:
			actor.GetProperty().SetColor(1.0, 0.9, 0.2)
			actor.GetProperty().SetAmbient(1.0)
			actor.GetProperty().SetDiffuse(0.0)
			actor.GetProperty().SetSpecular(0.0)
		except Exception:
			pass
		try:
			actor.GetProperty().SetDepthTest(False)
			actor.GetProperty().SetLighting(False)
		except Exception:
			pass
		actor.SetVisibility(0)

		self._vertex_source = src
		self._vertex_actor = actor

		# Edge marker
		edge_src = vtk.vtkLineSource()
		edge_src.SetPoint1(0.0, 0.0, 0.0)
		edge_src.SetPoint2(0.0, 0.0, 0.0)
		edge_map = vtk.vtkPolyDataMapper()
		edge_map.SetInputConnection(edge_src.GetOutputPort())
		edge_actor = vtk.vtkActor()
		edge_actor.SetMapper(edge_map)
		edge_actor.SetPickable(False)
		try:
			edge_actor.GetProperty().SetColor(1.0, 0.9, 0.2)
			edge_actor.GetProperty().SetLineWidth(4.0)
			edge_actor.GetProperty().SetAmbient(1.0)
			edge_actor.GetProperty().SetDiffuse(0.0)
			edge_actor.GetProperty().SetSpecular(0.0)
		except Exception:
			pass
		try:
			edge_actor.GetProperty().SetDepthTest(False)
			edge_actor.GetProperty().SetLighting(False)
		except Exception:
			pass
		edge_actor.SetVisibility(0)
		self._edge_source = edge_src
		self._edge_actor = edge_actor

		# Face highlight pipeline (extract cell id)
		face_extract = vtk.vtkExtractCells()
		face_geom = vtk.vtkGeometryFilter()
		face_geom.SetInputConnection(face_extract.GetOutputPort())
		face_map = vtk.vtkPolyDataMapper()
		face_map.SetInputConnection(face_geom.GetOutputPort())
		face_actor = vtk.vtkActor()
		face_actor.SetMapper(face_map)
		face_actor.SetPickable(False)
		try:
			face_actor.GetProperty().SetColor(1.0, 0.9, 0.2)
			face_actor.GetProperty().SetOpacity(0.25)
			face_actor.GetProperty().SetAmbient(1.0)
			face_actor.GetProperty().SetDiffuse(0.0)
			face_actor.GetProperty().SetSpecular(0.0)
		except Exception:
			pass
		try:
			face_actor.GetProperty().SetDepthTest(False)
			face_actor.GetProperty().SetLighting(False)
		except Exception:
			pass
		face_actor.SetVisibility(0)
		self._face_filter = face_extract
		self._face_geom = face_geom
		self._face_actor = face_actor

		# Hover vertex marker (translucent cyan ghost — shown while hovering in
		# vertex mode to preview the vertex that will be picked on click).
		hover_src = vtk.vtkSphereSource()
		hover_src.SetRadius(0.03)
		hover_src.SetThetaResolution(16)
		hover_src.SetPhiResolution(16)
		hover_map = vtk.vtkPolyDataMapper()
		hover_map.SetInputConnection(hover_src.GetOutputPort())
		hover_actor = vtk.vtkActor()
		hover_actor.SetMapper(hover_map)
		hover_actor.SetPickable(False)
		try:
			hover_actor.GetProperty().SetColor(0.35, 0.85, 1.0)
			hover_actor.GetProperty().SetOpacity(0.55)
			hover_actor.GetProperty().SetAmbient(1.0)
			hover_actor.GetProperty().SetDiffuse(0.0)
			hover_actor.GetProperty().SetSpecular(0.0)
		except Exception:
			pass
		try:
			hover_actor.GetProperty().SetDepthTest(False)
			hover_actor.GetProperty().SetLighting(False)
		except Exception:
			pass
		hover_actor.SetVisibility(0)
		self._hover_vertex_source = hover_src
		self._hover_vertex_actor = hover_actor

		# Prefer overlay renderer if present
		overlay = getattr(self._plotter, "_pyengine_overlay_renderer", None)
		for a in (actor, edge_actor, face_actor, hover_actor):
			if overlay is not None:
				overlay.AddActor(a)
			else:
				try:
					self._plotter.add_actor(a, pickable=False, reset_camera=False)
				except Exception:
					pass

	def _clear_subselection(self) -> None:
		self._sub_entity_id = None
		self._sub_point_id = -1
		self._sub_edge_point_ids = None
		self._sub_cell_id = -1
		if self._vertex_actor is not None:
			self._vertex_actor.SetVisibility(0)
		if self._edge_actor is not None:
			self._edge_actor.SetVisibility(0)
		if self._face_actor is not None:
			self._face_actor.SetVisibility(0)
		try:
			self._plotter.render()
		except Exception:
			pass

	def _hide_hover_vertex(self) -> None:
		self._hover_entity_id = None
		self._hover_point_id = -1
		self._hover_picked_actor = None
		if self._hover_vertex_actor is not None and self._hover_vertex_actor.GetVisibility():
			self._hover_vertex_actor.SetVisibility(0)
			try:
				self._plotter.render()
			except Exception:
				pass

	def _on_mouse_leave(self, _obj, _ev) -> None:
		self._hide_hover_vertex()

	def _on_mouse_move(self, _obj, _ev) -> None:
		# Only show the ghost marker in vertex mode.
		if self._selection_mode != "vertex":
			if self._hover_vertex_actor is not None and self._hover_vertex_actor.GetVisibility():
				self._hide_hover_vertex()
			return
		# Skip while user is dragging (e.g. orbiting); the press position is
		# only set when a left-button drag is in progress.
		if self._press_pos is not None:
			return
		try:
			x, y = self._iren.GetEventPosition()
		except Exception:
			return
		renderer = self._active_renderer()
		if renderer is None:
			return
		try:
			self._hover_picker.Pick(x, y, 0, renderer)
			picked_actor = self._hover_picker.GetActor()
			pid = int(self._hover_picker.GetPointId())
		except Exception:
			self._hide_hover_vertex()
			return
		if picked_actor is None or pid < 0:
			self._hide_hover_vertex()
			return
		entity_id = self._scene_root.entity_id_for_actor(picked_actor)
		if entity_id is None:
			self._hide_hover_vertex()
			return
		# Avoid re-rendering when the hover hasn't actually changed.
		if entity_id == self._hover_entity_id and pid == self._hover_point_id:
			return
		self._hover_entity_id = entity_id
		self._hover_point_id = pid
		self._hover_picked_actor = picked_actor
		self._update_hover_marker(picked_actor, pid)

	def _update_hover_marker(self, actor, pid: int) -> None:
		if self._hover_vertex_actor is None or self._hover_vertex_source is None:
			return
		try:
			mapper = actor.GetMapper()
			if mapper is None:
				self._hide_hover_vertex()
				return
			pd = mapper.GetInput()
			if pd is None:
				self._hide_hover_vertex()
				return
			local_pt = pd.GetPoint(int(pid))
			m4 = vtk.vtkMatrix4x4()
			try:
				actor.GetMatrix(m4)
			except Exception:
				pass
			out = [0.0, 0.0, 0.0, 1.0]
			m4.MultiplyPoint(
				[float(local_pt[0]), float(local_pt[1]), float(local_pt[2]), 1.0],
				out,
			)
			if abs(out[3]) > 1e-9:
				wx, wy, wz = (out[0] / out[3], out[1] / out[3], out[2] / out[3])
			else:
				wx, wy, wz = (out[0], out[1], out[2])
			self._hover_vertex_actor.SetPosition(float(wx), float(wy), float(wz))
			# Screen-space sizing (slightly bigger than the click marker).
			if self._renderer is not None:
				r = max(1e-6, float(world_length_for_pixels(self._renderer, QVector3D(wx, wy, wz), 9.0)))
				self._hover_vertex_source.SetRadius(r)
			self._hover_vertex_actor.SetVisibility(1)
			try:
				self._plotter.render()
			except Exception:
				pass
		except Exception:
			self._hide_hover_vertex()

	def _on_selection_changed(self, _entity) -> None:
		# Clear sub-selection when switching objects (Unity-like)
		self._clear_subselection()

	def _on_entity_changed(self, entity_id: str) -> None:
		# If we're tracking a sub-selection on this entity, recompute marker position after transforms change.
		if self._sub_entity_id is None:
			return
		if entity_id != self._sub_entity_id:
			return
		self._update_highlights()

	def sync_screen_space_visuals(self) -> None:
		"""Keep vertex pick / hover markers constant in screen space."""
		if self._selection_mode == "vertex" and self._vertex_actor is not None and self._vertex_actor.GetVisibility():
			self._update_highlights()
		if (
			self._selection_mode == "vertex"
			and self._hover_vertex_actor is not None
			and self._hover_vertex_actor.GetVisibility()
			and self._hover_entity_id is not None
			and self._hover_point_id >= 0
		):
			hover_actor = self._hover_picked_actor
			if hover_actor is None:
				hover_actor = self._scene_root.actor_for_vertex_pick(self._hover_entity_id)
			if hover_actor is None:
				hover_actor = self._scene_root.actor_for(self._hover_entity_id)
			if hover_actor is not None:
				self._update_hover_marker(hover_actor, self._hover_point_id)

	def _on_camera_interaction(self, obj, ev) -> None:
		self.sync_screen_space_visuals()

	def _update_highlights(self) -> None:
		if self._sub_entity_id is None:
			return
		ent = self._scene.find_by_id(self._sub_entity_id)
		if ent is None:
			self._clear_subselection()
			return
		actor_mesh = self._scene_root.actor_for_vertex_pick(ent.id)
		if actor_mesh is None:
			actor_mesh = self._scene_root.actor_for(ent.id)
		if actor_mesh is None:
			self._clear_subselection()
			return
		mapper = actor_mesh.GetMapper()
		if mapper is None:
			self._clear_subselection()
			return
		pd = mapper.GetInput()
		if pd is None:
			self._clear_subselection()
			return

		# Actor matrix for local->world
		m4 = vtk.vtkMatrix4x4()
		try:
			actor_mesh.GetMatrix(m4)
		except Exception:
			pass

		# Vertex highlight
		if self._selection_mode == "vertex" and self._sub_point_id >= 0 and self._vertex_actor is not None and self._vertex_source is not None:
			try:
				local_pt = pd.GetPoint(int(self._sub_point_id))
				out = [0.0, 0.0, 0.0, 1.0]
				m4.MultiplyPoint([float(local_pt[0]), float(local_pt[1]), float(local_pt[2]), 1.0], out)
				wx, wy, wz = (out[0] / out[3], out[1] / out[3], out[2] / out[3]) if abs(out[3]) > 1e-9 else (out[0], out[1], out[2])
				self._vertex_actor.SetPosition(float(wx), float(wy), float(wz))
				# Screen-space scaling (~8px radius)
				if self._renderer is not None:
					r = max(1e-6, float(world_length_for_pixels(self._renderer, QVector3D(wx, wy, wz), 8.0)))
					self._vertex_source.SetRadius(r)
				self._vertex_actor.SetVisibility(1)
			except Exception:
				self._vertex_actor.SetVisibility(0)
		elif self._vertex_actor is not None:
			self._vertex_actor.SetVisibility(0)

		# Edge highlight
		if self._selection_mode == "edge" and self._sub_edge_point_ids is not None and self._edge_actor is not None and self._edge_source is not None:
			try:
				i0, i1 = self._sub_edge_point_ids
				p0 = pd.GetPoint(int(i0))
				p1 = pd.GetPoint(int(i1))
				o0 = [0.0, 0.0, 0.0, 1.0]
				o1 = [0.0, 0.0, 0.0, 1.0]
				m4.MultiplyPoint([float(p0[0]), float(p0[1]), float(p0[2]), 1.0], o0)
				m4.MultiplyPoint([float(p1[0]), float(p1[1]), float(p1[2]), 1.0], o1)
				w0 = (o0[0] / o0[3], o0[1] / o0[3], o0[2] / o0[3]) if abs(o0[3]) > 1e-9 else (o0[0], o0[1], o0[2])
				w1 = (o1[0] / o1[3], o1[1] / o1[3], o1[2] / o1[3]) if abs(o1[3]) > 1e-9 else (o1[0], o1[1], o1[2])
				self._edge_source.SetPoint1(*w0)
				self._edge_source.SetPoint2(*w1)
				self._edge_actor.SetVisibility(1)
			except Exception:
				self._edge_actor.SetVisibility(0)
		elif self._edge_actor is not None:
			self._edge_actor.SetVisibility(0)

		# Face highlight
		if self._selection_mode == "face" and self._sub_cell_id >= 0 and self._face_actor is not None and self._face_filter is not None:
			try:
				ids = vtk.vtkIdList()
				ids.InsertNextId(int(self._sub_cell_id))
				self._face_filter.SetInputData(pd)
				self._face_filter.SetCellList(ids)
				self._face_filter.Update()
				# Follow mesh transform
				self._face_actor.SetUserTransform(None)
				try:
					self._face_actor.SetUserMatrix(actor_mesh.GetUserMatrix())
				except Exception:
					pass
				self._face_actor.SetVisibility(1)
			except Exception:
				self._face_actor.SetVisibility(0)
		elif self._face_actor is not None:
			self._face_actor.SetVisibility(0)

		try:
			self._plotter.render()
		except Exception:
			pass

	def _active_renderer(self):
		# Prefer plotter.renderer, but fall back to render-window lookup
		r = getattr(self._plotter, "renderer", None)
		if r is not None:
			return r
		try:
			rw = self._iren.GetRenderWindow()
			if rw is None:
				return None
			renderers = rw.GetRenderers()
			return renderers.GetFirstRenderer() if renderers is not None else None
		except Exception:
			return None

	def _on_left_press(self, obj, ev) -> None:
		try:
			self._press_pos = self._iren.GetEventPosition()
		except Exception:
			self._press_pos = None

	def _on_left_release(self, obj, ev) -> None:
		if self._press_pos is None:
			return
		
		try:
			curr_pos = self._iren.GetEventPosition()
			dx = curr_pos[0] - self._press_pos[0]
			dy = curr_pos[1] - self._press_pos[1]
			dist_sq = dx*dx + dy*dy
			self._press_pos = None

			# If the mouse moved significantly (e.g. > 3 pixels), it was likely a drag, not a selection click.
			if dist_sq > 9:
				return
			
			x, y = curr_pos
		except Exception:
			return

		renderer = self._active_renderer()
		if renderer is None:
			return

		# Sub-selection modes
		if self._selection_mode in ("vertex", "edge", "face"):
			try:
				self._picker.Pick(x, y, 0, renderer)
				picked_actor = self._picker.GetActor()
			except Exception:
				return
			entity_id = self._scene_root.entity_id_for_actor(picked_actor)
			if entity_id is None:
				# Clear sub-selection but keep entity selection
				self._clear_subselection()
				return
			ent = self._scene.find_by_id(entity_id)
			if ent is None:
				self._clear_subselection()
				return
			has_mesh = ent.get_component(MeshComponent) is not None
			has_cloud = ent.get_component(PointCloudComponent) is not None
			# Vertex mode accepts Mesh or PointCloud; edge/face need Mesh topology.
			if self._selection_mode == "vertex":
				if not (has_mesh or has_cloud):
					self._clear_subselection()
					return
			elif not has_mesh:
				self._clear_subselection()
				return
			# Ensure selection follows clicked mesh entity (unless locked, e.g.
			# while a VertexPick is armed; in that case keep current selection).
			if not self._lock_entity_selection:
				if self._ctrl_pressed():
					if not self._selection.is_entity_selected(ent):
						self._selection.toggle_entity(ent)
				elif self._selection.current is None or self._selection.current.id != ent.id:
					self._selection.select_exclusive(ent)
			mesh_actor = self._scene_root.mesh_actor_for(ent.id)
			cloud_actor = self._scene_root.point_cloud_actor_for(ent.id)
			if self._selection_mode == "vertex":
				if picked_actor is mesh_actor:
					actor_mesh = mesh_actor
				elif picked_actor is cloud_actor:
					actor_mesh = cloud_actor
				else:
					self._clear_subselection()
					return
			else:
				if mesh_actor is None or picked_actor is not mesh_actor:
					self._clear_subselection()
					return
				actor_mesh = mesh_actor

			self._sub_entity_id = ent.id

			if self._selection_mode == "vertex":
				pid = int(self._picker.GetPointId())
				if pid < 0:
					self._clear_subselection()
					return
				self._sub_point_id = pid
				self._sub_edge_point_ids = None
				self._sub_cell_id = -1
				self._scene_root.note_vertex_pick_actor(ent.id, actor_mesh)
				self._update_highlights()
				self.vertex_picked.emit(ent.id, pid)
				return

			if self._selection_mode == "face":
				cid = int(self._picker.GetCellId())
				if cid < 0:
					self._clear_subselection()
					return
				self._sub_cell_id = cid
				self._sub_point_id = -1
				self._sub_edge_point_ids = None
				self._update_highlights()
				
				# Emit face_picked signal with position and normal
				try:
					px, py, pz = self._picker.GetPickPosition()
					pick_pos = QVector3D(float(px), float(py), float(pz))
					
					# Compute cell normal
					mapper = actor_mesh.GetMapper()
					pd = mapper.GetInput() if mapper is not None else None
					if pd is not None:
						cell = pd.GetCell(cid)
						if cell is not None:
							# Compute normal from cell points
							normal = self._compute_cell_normal(cell, pd)
							if normal is not None:
								# Transform normal to world space
								m4 = vtk.vtkMatrix4x4()
								try:
									actor_mesh.GetMatrix(m4)
								except Exception:
									pass
								# Transform normal (rotation only, no translation)
								normal_world = QVector3D(
									m4.GetElement(0, 0) * normal.x() + m4.GetElement(0, 1) * normal.y() + m4.GetElement(0, 2) * normal.z(),
									m4.GetElement(1, 0) * normal.x() + m4.GetElement(1, 1) * normal.y() + m4.GetElement(1, 2) * normal.z(),
									m4.GetElement(2, 0) * normal.x() + m4.GetElement(2, 1) * normal.y() + m4.GetElement(2, 2) * normal.z()
								)
								normal_world.normalize()
								self.face_picked.emit(ent.id, cid, pick_pos, normal_world)
				except Exception:
					pass
				return

			# Edge mode: choose nearest edge within picked cell to pick position
			try:
				cid = int(self._picker.GetCellId())
				px, py, pz = self._picker.GetPickPosition()
			except Exception:
				self._clear_subselection()
				return
			if cid < 0:
				self._clear_subselection()
				return
			mapper = actor_mesh.GetMapper()
			pd = mapper.GetInput() if mapper is not None else None
			if pd is None:
				self._clear_subselection()
				return
			cell = pd.GetCell(cid)
			if cell is None:
				self._clear_subselection()
				return
			ids = cell.GetPointIds()
			n = ids.GetNumberOfIds() if ids is not None else 0
			if n < 2:
				self._clear_subselection()
				return
			# Actor matrix for local->world
			m4 = vtk.vtkMatrix4x4()
			try:
				actor_mesh.GetMatrix(m4)
			except Exception:
				pass
			pick = (float(px), float(py), float(pz))

			def dist2_point_to_seg(p, a, b) -> float:
				# squared distance from point p to segment ab
				(px, py, pz) = p
				(ax, ay, az) = a
				(bx, by, bz) = b
				abx, aby, abz = (bx - ax, by - ay, bz - az)
				apx, apy, apz = (px - ax, py - ay, pz - az)
				den = abx * abx + aby * aby + abz * abz
				if den <= 1e-12:
					dx, dy, dz = (px - ax, py - ay, pz - az)
					return dx * dx + dy * dy + dz * dz
				t = (apx * abx + apy * aby + apz * abz) / den
				if t < 0.0:
					t = 0.0
				elif t > 1.0:
					t = 1.0
				cx, cy, cz = (ax + t * abx, ay + t * aby, az + t * abz)
				dx, dy, dz = (px - cx, py - cy, pz - cz)
				return dx * dx + dy * dy + dz * dz

			best = None
			best_d2 = 1e30
			for i in range(n):
				i0 = int(ids.GetId(i))
				i1 = int(ids.GetId((i + 1) % n))
				p0 = pd.GetPoint(i0)
				p1 = pd.GetPoint(i1)
				o0 = [0.0, 0.0, 0.0, 1.0]
				o1 = [0.0, 0.0, 0.0, 1.0]
				m4.MultiplyPoint([float(p0[0]), float(p0[1]), float(p0[2]), 1.0], o0)
				m4.MultiplyPoint([float(p1[0]), float(p1[1]), float(p1[2]), 1.0], o1)
				w0 = (o0[0] / o0[3], o0[1] / o0[3], o0[2] / o0[3]) if abs(o0[3]) > 1e-9 else (o0[0], o0[1], o0[2])
				w1 = (o1[0] / o1[3], o1[1] / o1[3], o1[2] / o1[3]) if abs(o1[3]) > 1e-9 else (o1[0], o1[1], o1[2])
				d2 = dist2_point_to_seg(pick, w0, w1)
				if d2 < best_d2:
					best_d2 = d2
					best = (i0, i1)
			if best is None:
				self._clear_subselection()
				return
			self._sub_edge_point_ids = best
			self._sub_point_id = -1
			self._sub_cell_id = -1
			self._update_highlights()
			return

		try:
			self._picker.Pick(x, y, 0, renderer)
			actor = None
			try:
				actor = self._picker.GetActor()
			except Exception:
				pass
			if actor is None:
				try:
					prop = self._picker.GetProp3D()
					actor = prop if isinstance(prop, vtk.vtkActor) else None
				except Exception:
					actor = None
		except Exception:
			return

		entity_id: Optional[str] = self._scene_root.entity_id_for_actor(actor)
		
		# If not a mesh actor, check waypoint discs or path line actors
		if self._path_bridge and actor is not None:
			marker_entity_id = self._path_bridge.entity_id_for_waypoint_marker(actor)
			if marker_entity_id is not None:
				try:
					px, py, pz = self._picker.GetPickPosition()
					pick_world = QVector3D(float(px), float(py), float(pz))
					wp = self._path_bridge.get_waypoint_at_pick_position(marker_entity_id, pick_world)
					if wp is not None:
						f_idx, w_idx = wp
						ent = self._scene.find_by_id(marker_entity_id)
						if ent:
							if not self._lock_entity_selection:
								if self._ctrl_pressed():
									self._selection.toggle_entity(ent)
								else:
									self._selection.select_exclusive(ent)
							try:
								self._selection.set_current_waypoint(f_idx, w_idx)
							except Exception:
								pass
							self.waypoint_picked.emit(marker_entity_id, f_idx, w_idx)
							return
				except Exception:
					pass

			if entity_id is None:
				actor_key = self._path_bridge._actor_key(actor)
				entity_id = self._path_bridge._actor_to_entity.get(actor_key)

				# Path line actor (feature selection)
				if entity_id:
					# Path hit! 
					try:
						pid = int(self._picker.GetPointId())
						mapping = self._path_bridge.get_feature_at(actor, pid)
						if mapping:
							f_idx, w_idx = mapping
							# Ensure entity is selected before selecting feature
							ent = self._scene.find_by_id(entity_id)
							if ent:
								if not self._lock_entity_selection:
									if self._ctrl_pressed():
										self._selection.toggle_entity(ent)
									else:
										self._selection.select_exclusive(ent)
								try:
									self._selection.set_current_feature(f_idx)
								except Exception:
									pass
								self.feature_picked.emit(entity_id, f_idx, w_idx)
								return
					except Exception:
						pass

		if entity_id is None:
			if not self._lock_entity_selection:
				self._apply_entity_click(None)
			return

		ent = self._scene.find_by_id(entity_id)
		if not self._lock_entity_selection:
			self._apply_entity_click(ent)
	
	def _compute_cell_normal(self, cell, poly_data) -> Optional[QVector3D]:
		"""Compute the normal vector for a VTK cell."""
		try:
			point_ids = cell.GetPointIds()
			num_points = point_ids.GetNumberOfIds()
			if num_points < 3:
				return None
			
			# Get first three points to compute normal
			p0 = poly_data.GetPoint(point_ids.GetId(0))
			p1 = poly_data.GetPoint(point_ids.GetId(1))
			p2 = poly_data.GetPoint(point_ids.GetId(2))
			
			# Compute two edge vectors
			v1 = QVector3D(float(p1[0] - p0[0]), float(p1[1] - p0[1]), float(p1[2] - p0[2]))
			v2 = QVector3D(float(p2[0] - p0[0]), float(p2[1] - p0[1]), float(p2[2] - p0[2]))
			
			# Cross product gives normal
			normal = QVector3D.crossProduct(v1, v2)
			if normal.length() < 1e-6:
				return None
			normal.normalize()
			return normal
		except Exception:
			return None



from __future__ import annotations

from typing import Optional
import math

import vtk  # type: ignore
from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QUndoStack
from MotionStudio.render.vtk.gizmo.utils import (
	basis_and_origin_from_vtk_actor,
	configure_overlay_3d_actor,
	overlay_renderer,
	pick_renderer,
	screen_ray,
	world_length_for_pixels,
	world_position,
	world_axis_dirs_local,
)
from MotionStudio.render.vtk.camera_view_sync import register_camera_view_sync
from MotionStudio.render.vtk.scene_root import VtkSceneRoot
from MotionStudio.core.undo.commands import PropertyChangeCommand


def _angle_on_circle(point: QVector3D, center: QVector3D, u_axis: QVector3D, v_axis: QVector3D) -> float:
	"""Get the angle of a point on a circle relative to u_axis."""
	vec = point - center
	u_component = QVector3D.dotProduct(vec, u_axis)
	v_component = QVector3D.dotProduct(vec, v_axis)
	return math.atan2(v_component, u_component)


def _intersect_ray_with_plane(ray_origin: QVector3D, ray_dir: QVector3D, plane_origin: QVector3D, plane_normal: QVector3D) -> Optional[QVector3D]:
	"""Intersect a ray with a plane. Returns intersection point or None."""
	# Ray: P = ray_origin + t * ray_dir
	# Plane: (P - plane_origin) . plane_normal = 0
	# Solve: (ray_origin + t * ray_dir - plane_origin) . plane_normal = 0
	# t = (plane_origin - ray_origin) . plane_normal / (ray_dir . plane_normal)
	
	denom = QVector3D.dotProduct(ray_dir, plane_normal)
	if abs(denom) < 1e-9:
		return None  # Ray is parallel to plane
	
	vec_to_plane = plane_origin - ray_origin
	t = QVector3D.dotProduct(vec_to_plane, plane_normal) / denom
	
	if t < 0:
		return None  # Intersection is behind ray origin
	
	return ray_origin + (ray_dir * t)


class VtkRotateGizmo:
	"""
	Local-space rotate gizmo with X/Y/Z arc rings.
	Left-click and drag a ring to rotate the selected entity around that local axis.
	"""

	def __init__(self, plotter, scene: Scene, selection: SelectionModel, scene_root: VtkSceneRoot, undo_stack: Optional[QUndoStack] = None) -> None:
		self._plotter = plotter
		self._scene = scene
		self._selection = selection
		self._scene_root = scene_root
		self._undo_stack = undo_stack

		self._iren = getattr(plotter, "interactor", None) or getattr(plotter, "iren", None)
		if self._iren is None:
			raise RuntimeError("QtInteractor does not expose a VTK interactor (interactor/iren).")

		self._renderer = getattr(plotter, "renderer", None)
		if self._renderer is None:
			rw = self._iren.GetRenderWindow()
			if rw is not None:
				renderers = rw.GetRenderers()
				self._renderer = renderers.GetFirstRenderer() if renderers is not None else None
		if self._renderer is None:
			raise RuntimeError("Could not resolve a VTK renderer for gizmo.")
		self._pick_renderer = pick_renderer(plotter, self._renderer)

		# Ring actors
		self._ring_actors: list[vtk.vtkActor] = []
		self._axis_dirs_local = [QVector3D(1, 0, 0), QVector3D(0, 1, 0), QVector3D(0, 0, 1)]
		self._axis_colors = [(0.86, 0.20, 0.20), (0.20, 0.86, 0.20), (0.20, 0.47, 0.94)]

		self._picker = vtk.vtkCellPicker()
		self._picker.PickFromListOn()
		self._picker.SetTolerance(0.01)  # Slightly larger tolerance for rings

		self._active_axis: Optional[int] = None
		self._drag_entity: Optional[Entity] = None
		self._drag_axis_dir_world = QVector3D()
		self._drag_origin_world = QVector3D()
		self._drag_u_axis_world = QVector3D()
		self._drag_v_axis_world = QVector3D()
		self._drag_initial_angle: float = 0.0
		self._drag_start_rotation_quat: Optional[QQuaternion] = None
		self._drag_last_angle: float = 0.0
		self._enabled: bool = True
		self._external_pick_actors: list[vtk.vtkActor] = []

		self._build_actors()
		self._set_visible(False)

		# Selection + scene updates reposition the gizmo
		self._selection.current_entity_changed.connect(self._on_selection_changed)
		self._scene.events.entity_changed.connect(self._on_entity_changed)
		self._scene.events.entity_transform_changed.connect(self._on_entity_changed)  # Also listen to transform-only changes
		self._scene.events.entity_reparented.connect(self._on_entity_reparented)
		self._scene.events.entity_removed.connect(self._on_entity_removed)

		# Interactor observers (priority > picking bridge, but after translate gizmo)
		# Use priority 0.5 so rotation gizmo is checked after translate (lower priority = checked later)
		self._iren.AddObserver("LeftButtonPressEvent", self._on_left_press, 0.5)
		self._iren.AddObserver("MouseMoveEvent", self._on_mouse_move, 0.5)
		self._iren.AddObserver("LeftButtonReleaseEvent", self._on_left_release, 0.5)
		# Camera interaction updates
		self._iren.AddObserver("InteractionEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("MouseWheelForwardEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("MouseWheelBackwardEvent", self._on_camera_interaction, 0.0)
		self._iren.AddObserver("EndInteractionEvent", self._on_camera_interaction, 0.0)
		register_camera_view_sync(plotter, self.sync_screen_space_visuals)

	def _build_actors(self) -> None:
		"""Create arc ring actors for X, Y, Z axes."""
		# Arc parameters: 90 degrees - arcs visible only between translate handles
		arc_angle_deg = 90.0
		
		# Ring radius (will be scaled to match translate gizmo size)
		base_radius = 1.0
		# Ring thickness (tube radius)
		tube_radius = 0.03
		# Number of segments for the arc
		num_segments = 32

		for i in range(3):
			# Create arc curve
			arc = vtk.vtkArcSource()
			
			# Each ring arcs between two translate arrow directions:
			# Z ring (in XY plane): from +X (0°) to +Y (90°)
			# Y ring (in XZ plane): from +Z to +X (will be rotated to XZ plane)
			# X ring (in YZ plane): from +Y to +Z (will be rotated to YZ plane)
			
			if i == 0:  # X ring - arcs from +Y to +Z in YZ plane
				# In YZ plane (x=0): +Y is (0,1,0), +Z is (0,0,1)
				# Start at +Y, end at +Z (90° arc)
				arc.SetPoint1(0.0, base_radius, 0.0)  # +Y
				arc.SetPoint2(0.0, 0.0, base_radius)  # +Z
				arc.SetCenter(0.0, 0.0, 0.0)
			elif i == 1:  # Y ring - arcs from +Z to +X in XZ plane
				# In XZ plane (y=0): +Z is (0,0,1), +X is (1,0,0)
				# Start at +Z, end at +X (90° arc)
				arc.SetPoint1(0.0, 0.0, base_radius)  # +Z
				arc.SetPoint2(base_radius, 0.0, 0.0)  # +X
				arc.SetCenter(0.0, 0.0, 0.0)
			else:  # Z ring - arcs from +X to +Y in XY plane
				# In XY plane (z=0): +X is (1,0,0), +Y is (0,1,0)
				# Start at +X, end at +Y (90° arc)
				arc.SetPoint1(base_radius, 0.0, 0.0)  # +X
				arc.SetPoint2(0.0, base_radius, 0.0)  # +Y
				arc.SetCenter(0.0, 0.0, 0.0)
			
			arc.SetResolution(num_segments)
			arc.Update()

			# Create tube around the arc
			tube = vtk.vtkTubeFilter()
			tube.SetInputConnection(arc.GetOutputPort())
			tube.SetRadius(tube_radius)
			tube.SetNumberOfSides(12)
			tube.CappingOn()
			tube.Update()

			mapper = vtk.vtkPolyDataMapper()
			mapper.SetInputConnection(tube.GetOutputPort())

			actor = vtk.vtkActor()
			actor.SetMapper(mapper)
			actor.SetPickable(True)
			actor.GetProperty().SetColor(*self._axis_colors[i])
			configure_overlay_3d_actor(actor, opacity=0.5)

			self._ring_actors.append(actor)
			self._picker.AddPickList(actor)

			overlay = overlay_renderer(self._plotter)
			if overlay is not None:
				overlay.AddActor(actor)
			else:
				self._plotter.add_actor(actor, pickable=True, reset_camera=False)

	def pickable_actors(self) -> list[vtk.vtkActor]:
		"""Actors that should participate in depth-aware handle picking."""
		return list(self._ring_actors)

	def register_external_pick_actors(self, actors: list[vtk.vtkActor]) -> None:
		"""
		Add other gizmo actors to this picker's pick list so VTK can depth-resolve
		the top-most handle under the cursor.
		"""
		for actor in actors:
			if actor in self._external_pick_actors:
				continue
			self._external_pick_actors.append(actor)
			try:
				self._picker.AddPickList(actor)
			except Exception:
				pass

	def _set_visible(self, visible: bool) -> None:
		for a in self._ring_actors:
			a.SetVisibility(1 if visible else 0)

	def _reposition(self) -> None:
		ent = self._selection.current
		if ent is None:
			self._set_visible(False)
			return

		actor_mesh = self._scene_root.actor_for(ent.id)
		if actor_mesh is not None:
			origin, (xw, yw, zw) = basis_and_origin_from_vtk_actor(actor_mesh)
		else:
			origin = world_position(ent)
			xw, yw, zw = world_axis_dirs_local(ent)

		axis_world = [xw, yw, zw]

		# Scale gizmo to match translate gizmo size (~180px on screen)
		try:
			size = max(1e-4, world_length_for_pixels(self._renderer, origin, 180.0))
		except Exception:
			size = 1.0

		# For each ring, position it in the plane perpendicular to its axis
		# X ring: in YZ plane (perpendicular to X), arcs from +Y to +Z
		# Y ring: in XZ plane (perpendicular to Y), arcs from +Z to +X
		# Z ring: in XY plane (perpendicular to Z), arcs from +X to +Y
		for i, ring_actor in enumerate(self._ring_actors):
			axis_dir = axis_world[i]
			
			# Build two perpendicular vectors in the ring plane (in world space)
			# These define where the arc starts and ends (aligned with translate arrows)
			if i == 0:  # X axis - arc from Y to Z
				u_axis_world = axis_world[1]  # Y world (start of arc)
				v_axis_world = axis_world[2]  # Z world (end of arc)
			elif i == 1:  # Y axis - arc from Z to X
				u_axis_world = axis_world[2]  # Z world (start of arc)
				v_axis_world = axis_world[0]  # X world (end of arc)
			else:  # Z axis - arc from X to Y
				u_axis_world = axis_world[0]  # X world (start of arc)
				v_axis_world = axis_world[1]  # Y world (end of arc)

			# Build transform: scale, then rotate to align ring plane and arc orientation, then translate
			t = vtk.vtkTransform()
			t.PostMultiply()
			t.Scale(size, size, size)

			# Each arc is created in its canonical plane:
			# X ring: created in YZ plane, normal = +X, arc from +Y (u) to +Z (v)
			# Y ring: created in XZ plane, normal = +Y, arc from +Z (u) to +X (v)
			# Z ring: created in XY plane, normal = +Z, arc from +X (u) to +Y (v)
			
			# Default normal for each ring (in local space of the arc)
			if i == 0:  # X ring
				default_normal = QVector3D(1, 0, 0)  # +X
				default_u = QVector3D(0, 1, 0)  # +Y (arc start)
				default_v = QVector3D(0, 0, 1)  # +Z (arc end)
			elif i == 1:  # Y ring
				default_normal = QVector3D(0, 1, 0)  # +Y
				default_u = QVector3D(0, 0, 1)  # +Z (arc start)
				default_v = QVector3D(1, 0, 0)  # +X (arc end)
			else:  # Z ring
				default_normal = QVector3D(0, 0, 1)  # +Z
				default_u = QVector3D(1, 0, 0)  # +X (arc start)
				default_v = QVector3D(0, 1, 0)  # +Y (arc end)
			
			# Target vectors in world space
			target_normal = axis_dir
			target_u = u_axis_world
			target_v = v_axis_world
			
			# First, rotate the normal to align with target_normal
			axis = QVector3D.crossProduct(default_normal, target_normal)
			axis_len = axis.length()
			if axis_len > 1e-6:
				axis_n = axis / axis_len
				dot = float(QVector3D.dotProduct(default_normal, target_normal))
				dot = max(-1.0, min(1.0, dot))
				angle_deg = math.degrees(math.acos(dot))
				if angle_deg > 1e-6:
					t.RotateWXYZ(angle_deg, axis_n.x(), axis_n.y(), axis_n.z())
			elif QVector3D.dotProduct(default_normal, target_normal) < 0.0:
				# Opposite directions, rotate 180° around any perpendicular axis
				if i == 0:  # X ring, use Y axis
					t.RotateWXYZ(180.0, 0.0, 1.0, 0.0)
				elif i == 1:  # Y ring, use X axis
					t.RotateWXYZ(180.0, 1.0, 0.0, 0.0)
				else:  # Z ring, use X axis
					t.RotateWXYZ(180.0, 1.0, 0.0, 0.0)
			
			# Now rotate around the normal axis to align the arc's u/v directions with target u/v
			# Get the current u direction after the normal rotation
			# We need to build a rotation matrix to see what default_u becomes
			temp_transform = vtk.vtkTransform()
			temp_transform.PostMultiply()
			temp_transform.Scale(1.0, 1.0, 1.0)
			if axis_len > 1e-6:
				dot = float(QVector3D.dotProduct(default_normal, target_normal))
				dot = max(-1.0, min(1.0, dot))
				angle_deg = math.degrees(math.acos(dot))
				if angle_deg > 1e-6:
					temp_transform.RotateWXYZ(angle_deg, axis_n.x(), axis_n.y(), axis_n.z())
			elif QVector3D.dotProduct(default_normal, target_normal) < 0.0:
				if i == 0:
					temp_transform.RotateWXYZ(180.0, 0.0, 1.0, 0.0)
				elif i == 1:
					temp_transform.RotateWXYZ(180.0, 1.0, 0.0, 0.0)
				else:
					temp_transform.RotateWXYZ(180.0, 1.0, 0.0, 0.0)
			
			# Transform default_u to see where it ends up
			temp_matrix = temp_transform.GetMatrix()
			rotated_u = QVector3D(
				temp_matrix.GetElement(0, 0) * default_u.x() + temp_matrix.GetElement(0, 1) * default_u.y() + temp_matrix.GetElement(0, 2) * default_u.z(),
				temp_matrix.GetElement(1, 0) * default_u.x() + temp_matrix.GetElement(1, 1) * default_u.y() + temp_matrix.GetElement(1, 2) * default_u.z(),
				temp_matrix.GetElement(2, 0) * default_u.x() + temp_matrix.GetElement(2, 1) * default_u.y() + temp_matrix.GetElement(2, 2) * default_u.z()
			)
			rotated_u = rotated_u.normalized()
			
			# Now rotate around the normal axis to align rotated_u with target_u
			# Project both onto the plane perpendicular to the normal
			# rotated_u and target_u should both be perpendicular to target_normal
			u_proj = rotated_u - (QVector3D.dotProduct(rotated_u, target_normal) * target_normal)
			v_proj = target_u - (QVector3D.dotProduct(target_u, target_normal) * target_normal)
			
			u_proj_len = u_proj.length()
			v_proj_len = v_proj.length()
			
			if u_proj_len > 1e-6 and v_proj_len > 1e-6:
				u_proj = u_proj / u_proj_len
				v_proj = v_proj / v_proj_len
				
				# Calculate rotation angle around the normal
				dot = float(QVector3D.dotProduct(u_proj, v_proj))
				dot = max(-1.0, min(1.0, dot))
				angle_around_normal = math.degrees(math.acos(dot))
				
				# Check cross product to determine rotation direction
				cross = QVector3D.crossProduct(u_proj, v_proj)
				if QVector3D.dotProduct(cross, target_normal) < 0.0:
					angle_around_normal = -angle_around_normal
				
				if abs(angle_around_normal) > 1e-6:
					# Rotate around the normal axis
					t.RotateWXYZ(angle_around_normal, target_normal.x(), target_normal.y(), target_normal.z())

			# Translate last
			t.Translate(origin.x(), origin.y(), origin.z())

			ring_actor.SetUserMatrix(t.GetMatrix())
			ring_actor.Modified()
			if ring_actor.GetMapper():
				ring_actor.GetMapper().Update()

	def _on_selection_changed(self, _entity: Optional[Entity]) -> None:
		self._reposition()
		self._set_visible(self._selection.current is not None)
		try:
			self._plotter.render()
		except Exception:
			pass

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._selection.current is not None and self._selection.current.id == entity_id:
			self._reposition()

	def _on_entity_reparented(self, child_id: str, _new_parent_id) -> None:
		if self._selection.current is not None and self._selection.current.id == child_id:
			self._reposition()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._selection.is_entity_id_selected(entity_id):
			self._selection.remove_entity_id(entity_id)
			self._set_visible(False)

	def set_enabled(self, enabled: bool) -> None:
		"""Enable or disable the gizmo. When disabled, it won't respond to interactions."""
		self._enabled = enabled
		if not enabled:
			# Cancel any active drag
			self._active_axis = None
			self._drag_entity = None

	def _on_left_press(self, obj, ev) -> None:
		# If disabled, do nothing
		if not self._enabled:
			return
		# If another gizmo already claimed this press, ignore.
		# Translate gizmo has higher observer priority and should win ties.
		if self._selection.interaction_active and self._active_axis is None:
			return
		# Check if translate gizmo is already handling this
		# (We use lower priority, so translate gizmo checks first)
		ent = self._selection.current
		if ent is None:
			return
		# Locked Transform: ignore gizmo drags (silent).
		tc_lock = ent.get_component(TransformComponent)
		if tc_lock is not None and bool(getattr(tc_lock, "locked", False)):
			return

		# Check if click hits a rotation ring
		x, y = self._iren.GetEventPosition()
		try:
			self._picker.Pick(x, y, 0, self._pick_renderer)
			actor = self._picker.GetActor()
		except Exception:
			return
		if actor is None:
			return
		try:
			axis_index = self._ring_actors.index(actor)
		except ValueError:
			return

		# Start rotation drag
		self._active_axis = axis_index
		self._drag_entity = ent
		
		# Set interaction active
		try:
			self._selection.set_interaction_active(True)
		except Exception:
			pass

		# Capture initial rotation for undo
		tc0 = ent.get_component(TransformComponent)
		if tc0 is not None:
			self._drag_start_rotation_quat = QQuaternion(tc0.rotation_quat)
		else:
			self._drag_start_rotation_quat = QQuaternion()

		# Disable highlight during drag
		self._scene_root.set_outline_enabled(False)

		# Get ring plane information
		actor_mesh = self._scene_root.actor_for(ent.id)
		if actor_mesh is not None:
			origin, (xw, yw, zw) = basis_and_origin_from_vtk_actor(actor_mesh)
		else:
			origin = world_position(ent)
			xw, yw, zw = world_axis_dirs_local(ent)

		self._drag_origin_world = origin
		self._drag_axis_dir_world = [xw, yw, zw][axis_index]

		# Build u and v axes for the ring plane
		# These define the arc's start (u) and end (v) directions
		if axis_index == 0:  # X axis - arc from Y to Z
			self._drag_u_axis_world = yw  # Start: +Y
			self._drag_v_axis_world = zw  # End: +Z
		elif axis_index == 1:  # Y axis - arc from Z to X
			self._drag_u_axis_world = zw  # Start: +Z
			self._drag_v_axis_world = xw  # End: +X
		else:  # Z axis - arc from X to Y
			self._drag_u_axis_world = xw  # Start: +X
			self._drag_v_axis_world = yw  # End: +Y

		# Store the local axis direction (constant, doesn't change with rotation)
		self._drag_local_axis = self._axis_dirs_local[axis_index]
		
		# Get initial angle on the ring
		ray = screen_ray(self._renderer, int(x), int(y))
		intersection = _intersect_ray_with_plane(ray.origin, ray.dir, origin, self._drag_axis_dir_world)
		if intersection is not None:
			# Project onto ring circle
			vec = intersection - origin
			vec_len = vec.length()
			if vec_len > 1e-6:
				# Get radius (same as gizmo size)
				try:
					radius = max(1e-4, world_length_for_pixels(self._renderer, origin, 180.0))
				except Exception:
					radius = 1.0
				# Normalize to circle
				vec_normalized = vec / vec_len
				point_on_circle = origin + vec_normalized * radius
				self._drag_initial_angle = _angle_on_circle(point_on_circle, origin, self._drag_u_axis_world, self._drag_v_axis_world)
				self._drag_last_angle = self._drag_initial_angle
			else:
				self._drag_initial_angle = 0.0
				self._drag_last_angle = 0.0
		else:
			self._drag_initial_angle = 0.0
			self._drag_last_angle = 0.0

		# Abort event propagation
		try:
			obj.AbortFlagOn()
		except Exception:
			pass

	def _on_mouse_move(self, obj, ev) -> None:
		if self._active_axis is None or self._drag_entity is None:
			return

		# Get current origin (may have changed due to parent transforms, but unlikely during drag)
		actor_mesh = self._scene_root.actor_for(self._drag_entity.id)
		if actor_mesh is not None:
			origin, _ = basis_and_origin_from_vtk_actor(actor_mesh)
		else:
			origin = world_position(self._drag_entity)

		x, y = self._iren.GetEventPosition()
		ray = screen_ray(self._renderer, int(x), int(y))
		
		# Use the initial axis direction for the plane intersection (constant throughout drag)
		# This ensures we're always intersecting with the same plane
		intersection = _intersect_ray_with_plane(ray.origin, ray.dir, origin, self._drag_axis_dir_world)
		if intersection is None:
			return

		# Get radius
		try:
			radius = max(1e-4, world_length_for_pixels(self._renderer, origin, 180.0))
		except Exception:
			radius = 1.0

		# Project intersection onto ring circle using INITIAL u/v axes
		# This ensures angle calculation is consistent (relative to initial orientation)
		vec = intersection - origin
		vec_len = vec.length()
		if vec_len > 1e-6:
			vec_normalized = vec / vec_len
			point_on_circle = origin + vec_normalized * radius
			current_angle = _angle_on_circle(point_on_circle, origin, self._drag_u_axis_world, self._drag_v_axis_world)
		else:
			current_angle = self._drag_last_angle

		# Calculate total angle delta from initial angle
		angle_delta = current_angle - self._drag_initial_angle
		# Normalize to [-pi, pi] to handle wrap-around
		while angle_delta > math.pi:
			angle_delta -= 2.0 * math.pi
		while angle_delta < -math.pi:
			angle_delta += 2.0 * math.pi

		# Update last angle for next frame
		self._drag_last_angle = current_angle

		# Convert to degrees
		angle_delta_deg = math.degrees(angle_delta)
		
		# For Y axis, we need to reverse the rotation direction to match drag direction
		# This is because the Y ring arc direction and rotation convention don't match
		# if self._active_axis == 1:  # Y axis
		# 	angle_delta_deg = -angle_delta_deg

		# Apply rotation: start from initial rotation, apply total delta
		# Rotate around the LOCAL axis (constant direction in local space)
		tc = self._drag_entity.get_component(TransformComponent)
		if tc is not None and self._drag_start_rotation_quat is not None:
			# Transform local axis to world space using initial rotation
			# This gives us the world-space axis direction at drag start
			initial_world_axis = self._drag_start_rotation_quat.rotatedVector(self._drag_local_axis).normalized()
			
			# Create delta rotation quaternion around the initial world axis direction
			# This ensures we rotate around the same axis throughout the drag
			delta_quat = QQuaternion.fromAxisAndAngle(initial_world_axis, angle_delta_deg)
			# Apply in local space: new = delta * initial
			# Transform setter automatically emits entity_changed signal
			tc.rotation_quat = delta_quat * self._drag_start_rotation_quat

		# Keep gizmo positioned (this will update arcs to match new rotation)
		self._reposition()

		# Render
		try:
			self._plotter.render()
		except Exception:
			pass

		try:
			obj.AbortFlagOn()
		except Exception:
			pass

	def _on_left_release(self, obj, ev) -> None:
		if self._active_axis is None:
			return

		# End interaction
		try:
			self._selection.set_interaction_active(False)
		except Exception:
			pass

		# Push undo command
		if (
			self._undo_stack is not None
			and self._drag_entity is not None
			and self._drag_start_rotation_quat is not None
			and getattr(self._drag_entity, "name", "") != "__waypoint_proxy__"
		):
			tc = self._drag_entity.get_component(TransformComponent)
			if tc is not None:
				old_rotation = QVector3D(self._drag_start_rotation_quat.toEulerAngles())
				new_rotation = QVector3D(tc.rotation_quat.toEulerAngles())
				# Only push if rotation actually changed
				if (old_rotation - new_rotation).length() > 1e-6:
					self._undo_stack.push(
						PropertyChangeCommand(
							self._scene,
							self._drag_entity.id,
							getattr(tc, "type_name", tc.__class__.__name__),
							"rotation",
							old_rotation,
							new_rotation,
							text="Transform.rotation",
						)
					)

		self._active_axis = None
		self._drag_entity = None
		self._drag_start_rotation_quat = None
		self._drag_last_angle = 0.0

		# Abort event
		try:
			obj.AbortFlagOn()
		except Exception:
			pass

		# Re-enable highlight
		self._scene_root.set_outline_enabled(True)
		if self._selection.current:
			self._scene_root._sync_transform(self._selection.current.id)

		try:
			obj.AbortFlagOn()
		except Exception:
			pass
		self._plotter.render()

	def sync_screen_space_visuals(self) -> None:
		if self._active_axis is not None:
			return
		if self._selection.current is None:
			return
		self._reposition()

	def _on_camera_interaction(self, obj, ev) -> None:
		self.sync_screen_space_visuals()


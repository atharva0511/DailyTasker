"""Shared helpers for Inspector floating dockable windows."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Dict, Hashable, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QDockWidget, QMainWindow, QWidget

if TYPE_CHECKING:
	from MotionStudio.ui.inspector_panel import InspectorPanel

DockKey = Hashable
ContentFactory = Callable[[], QWidget]


def resolve_inspector_main_window(panel: "InspectorPanel") -> QMainWindow:
	"""Return the app main window, or a temporary host if none is available."""
	mw = panel.window()
	if isinstance(mw, QMainWindow):
		return mw
	mw = QMainWindow()
	mw.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
	mw.resize(480, 420)
	mw.show()
	return mw


def open_or_focus_inspector_dock(
	panel: "InspectorPanel",
	key: DockKey,
	title: str,
	make_content: ContentFactory,
	*,
	store_attr: str = "_inspector_docks",
	width: int = 420,
	height: int = 360,
) -> QDockWidget:
	"""
	Open one floating dockable window per ``key`` (reuse / raise if already open).

	``make_content`` must return a ``QWidget``. If the widget exposes
	``bind_host_dock(dock)``, it is called after the dock is created.
	"""
	mw = resolve_inspector_main_window(panel)

	if not hasattr(panel, store_attr):
		setattr(panel, store_attr, {})
	docks: Dict[Any, QDockWidget] = getattr(panel, store_attr)

	existing = docks.get(key)
	if existing is not None:
		try:
			existing.setWindowTitle(title)
			existing.show()
			existing.raise_()
			if existing.isFloating():
				existing.activateWindow()
			return existing
		except RuntimeError:
			docks.pop(key, None)

	content = make_content()
	dock = QDockWidget(title, mw)
	safe = "".join(ch if ch.isalnum() else "_" for ch in title)[:80]
	dock.setObjectName(f"InspectorDock_{safe}")
	dock.setAllowedAreas(
		Qt.DockWidgetArea.LeftDockWidgetArea
		| Qt.DockWidgetArea.RightDockWidgetArea
		| Qt.DockWidgetArea.BottomDockWidgetArea
		| Qt.DockWidgetArea.TopDockWidgetArea
	)
	dock.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
	dock.setWidget(content)
	bind = getattr(content, "bind_host_dock", None)
	if callable(bind):
		bind(dock)

	mw.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
	dock.setFloating(True)
	try:
		geo = mw.frameGeometry()
		dock.resize(width, height)
		n_open = len(docks)
		offset = 28 * (n_open % 8)
		dock.move(geo.center().x() - width // 2 + offset, geo.center().y() - height // 2 + offset)
	except Exception:
		pass

	docks[key] = dock

	def _on_destroyed(*_args, k=key, p=panel, attr=store_attr) -> None:
		store = getattr(p, attr, None)
		if isinstance(store, dict):
			store.pop(k, None)

	dock.destroyed.connect(_on_destroyed)
	dock.show()
	dock.raise_()
	dock.activateWindow()
	return dock


def path_window_title(entity_name: str, group_label: str) -> str:
	"""``Entity Name -> PathGeneration -> Group``."""
	name = str(entity_name or "").strip() or "Entity"
	return f"{name} -> PathGeneration -> {group_label}"


def entity_display_name(entity) -> str:
	name = str(getattr(entity, "name", "") or "").strip()
	return name if name else "Entity"

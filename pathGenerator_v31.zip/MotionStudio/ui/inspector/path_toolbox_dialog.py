from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QDockWidget, QVBoxLayout, QWidget

from MotionStudio.ui.inspector.inspector_dock import (
	entity_display_name,
	open_or_focus_inspector_dock,
	path_window_title,
)
from MotionStudio.ui.widgets.path_toolbox import PathToolbox

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel
	from MotionStudio.ui.tools.path_tool_manager import PathToolManager


def open_path_toolbox_dock(
	panel: "InspectorPanel",
	entity: "Entity",
	tool_manager: "PathToolManager",
) -> None:
	"""Open (or focus) the PathGeneration toolbox as a floating dockable window."""
	key = ("path_toolbox", str(entity.id))
	title = path_window_title(entity_display_name(entity), "Toolbox")

	def _make() -> PathToolboxPanel:
		return PathToolboxPanel(panel, entity, tool_manager)

	open_or_focus_inspector_dock(
		panel,
		key,
		title,
		_make,
		store_attr="_path_docks",
		width=320,
		height=160,
	)


class PathToolboxPanel(QWidget):
	"""Path segment-creation tools hosted in a floating dock."""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		tool_manager: "PathToolManager",
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._entity = entity
		self._tool_manager = tool_manager
		self._host_dock: Optional[QDockWidget] = None
		self._closing = False

		self._undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
		self._redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
		self._redo_ctrl_y_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
		for sc in (self._undo_shortcut, self._redo_shortcut, self._redo_ctrl_y_shortcut):
			sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
		self._undo_shortcut.activated.connect(self._trigger_global_undo)
		self._redo_shortcut.activated.connect(self._trigger_global_redo)
		self._redo_ctrl_y_shortcut.activated.connect(self._trigger_global_redo)

		self._enter_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Return), self)
		self._enter_kp_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Enter), self)
		self._escape_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
		for sc in (self._enter_shortcut, self._enter_kp_shortcut, self._escape_shortcut):
			sc.setContext(Qt.ShortcutContext.WindowShortcut)
		self._enter_shortcut.activated.connect(self._on_confirm_tool)
		self._enter_kp_shortcut.activated.connect(self._on_confirm_tool)
		self._escape_shortcut.activated.connect(self._on_cancel_tool)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)
		root.addWidget(PathToolbox(tool_manager, self), 1)

		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def bind_host_dock(self, dock: QDockWidget) -> None:
		self._host_dock = dock

	def _undo_stack(self):
		return getattr(self._panel, "_undo_stack", None)

	def _trigger_global_undo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canUndo():
			stack.undo()

	def _trigger_global_redo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canRedo():
			stack.redo()

	def _on_confirm_tool(self) -> None:
		if self._tool_manager is not None:
			self._tool_manager.confirm_tool()

	def _on_cancel_tool(self) -> None:
		if self._tool_manager is not None:
			self._tool_manager.cancel_tool()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._close_host()

	def _close_host(self) -> None:
		self._closing = True
		dock = self._host_dock
		if dock is not None:
			dock.close()
		else:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		"""Cancel any active path tool when the toolbox dock is closed."""
		self._closing = True
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		try:
			if self._tool_manager is not None:
				self._tool_manager.cancel_tool()
		except Exception:
			pass
		super().closeEvent(event)


# Back-compat alias.
PathToolboxDialog = PathToolboxPanel

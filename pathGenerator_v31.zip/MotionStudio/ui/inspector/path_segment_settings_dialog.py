from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import QDockWidget, QFormLayout, QScrollArea, QVBoxLayout, QWidget

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.ui.inspector.inspector_dock import (
	entity_display_name,
	open_or_focus_inspector_dock,
	path_window_title,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.components.feature import Feature
	from MotionStudio.ui.inspector_panel import InspectorPanel


def open_path_segment_settings_dock(
	panel: "InspectorPanel",
	entity: "Entity",
	segment_idx: int,
	segment: "Feature | None" = None,
) -> None:
	"""Open (or focus) segment settings as a floating dockable window."""
	_ = segment  # kept for call-site compatibility; content refreshes from the component
	key = ("path_segment_settings", str(entity.id), int(segment_idx))
	title = path_window_title(
		entity_display_name(entity),
		f"Segment {segment_idx + 1} Settings",
	)

	def _make() -> PathSegmentSettingsPanel:
		return PathSegmentSettingsPanel(panel, entity, segment_idx)

	open_or_focus_inspector_dock(
		panel,
		key,
		title,
		_make,
		store_attr="_path_docks",
		width=380,
		height=280,
	)


class PathSegmentSettingsPanel(QWidget):
	"""Parametric segment fields hosted in a floating dock."""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		segment_idx: int,
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._entity = entity
		self._segment_idx = segment_idx
		self._refresh_pending = False
		self._closing = False
		self._host_dock: Optional[QDockWidget] = None

		self._undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
		self._redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
		self._redo_ctrl_y_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
		for sc in (self._undo_shortcut, self._redo_shortcut, self._redo_ctrl_y_shortcut):
			sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
		self._undo_shortcut.activated.connect(self._trigger_global_undo)
		self._redo_shortcut.activated.connect(self._trigger_global_redo)
		self._redo_ctrl_y_shortcut.activated.connect(self._trigger_global_redo)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

		body = QWidget(scroll)
		self._form = QFormLayout(body)
		self._form.setContentsMargins(0, 0, 0, 0)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		self._rebuild_form()
		self._connect_refresh_signals()

	def bind_host_dock(self, dock: QDockWidget) -> None:
		self._host_dock = dock

	def _undo_stack(self):
		return getattr(self._panel, "_undo_stack", None)

	def _trigger_global_undo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canUndo():
			stack.undo()

	def _trigger_global_redo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canRedo():
			stack.redo()

	def _connect_refresh_signals(self) -> None:
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.connect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def _rebuild_form(self) -> None:
		self._refresh_pending = False
		if self._closing:
			return
		if not self._is_context_valid():
			self._close_host()
			return
		self._refresh_window_title()
		while self._form.rowCount() > 0:
			self._form.removeRow(0)
		path_comp = self._entity.get_component(PathComponent)
		if path_comp is None or self._segment_idx < 0 or self._segment_idx >= len(path_comp.segments):
			self._close_host()
			return
		segment = path_comp.segments[self._segment_idx]
		self._panel._path_section.append_segment_settings_fields(
			self._form, self._entity, self._segment_idx, segment
		)

	def _refresh_window_title(self) -> None:
		dock = self._host_dock
		if dock is None:
			return
		dock.setWindowTitle(
			path_window_title(
				entity_display_name(self._entity),
				f"Segment {self._segment_idx + 1} Settings",
			)
		)

	def _is_context_valid(self) -> bool:
		try:
			scene = getattr(self._panel, "_scene", None)
			if scene is not None and scene.find_by_id(self._entity.id) is not self._entity:
				return False
			path_comp = self._entity.get_component(PathComponent)
			return path_comp is not None
		except Exception:
			return False

	def _on_undo_redo(self, _idx: int) -> None:
		self._schedule_refresh()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._schedule_refresh()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._close_host()

	def _schedule_refresh(self) -> None:
		# Defer rebuild to avoid replacing Qt editors while their editingFinished
		# handlers are still executing (can cause intermittent crashes).
		if self._refresh_pending or self._closing:
			return
		self._refresh_pending = True
		QTimer.singleShot(0, self._rebuild_form)

	def _close_host(self) -> None:
		self._closing = True
		dock = self._host_dock
		if dock is not None:
			dock.close()
		else:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.disconnect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)


# Back-compat alias.
PathSegmentSettingsDialog = PathSegmentSettingsPanel

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional, Tuple

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (
	QDockWidget,
	QFormLayout,
	QScrollArea,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.ui.inspector.inspector_dock import open_or_focus_inspector_dock
from MotionStudio.ui.inspector.reflection import InspectorLayoutRow

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel

GroupDockKey = Tuple[str, ...]


def _group_dock_key(
	group_label: str,
	*,
	entity: Optional["Entity"],
	component,
	entities: Optional[List["Entity"]],
	comp_type: Optional[str],
) -> GroupDockKey:
	if entity is not None and component is not None:
		ctype = getattr(component, "type_name", component.__class__.__name__)
		return ("single", str(entity.id), str(ctype), str(group_label))
	ents = entities or []
	ids = tuple(sorted(str(e.id) for e in ents))
	return ("multi", ids, str(comp_type or ""), str(group_label))


def _entity_display_name(entity: "Entity") -> str:
	name = str(getattr(entity, "name", "") or "").strip()
	return name if name else "Entity"


def _component_display_name(component=None, *, comp_type: Optional[str] = None) -> str:
	if component is not None:
		return str(getattr(component, "type_name", component.__class__.__name__))
	return str(comp_type or "Component")


def _group_window_title(
	group_label: str,
	*,
	entity: Optional["Entity"],
	component,
	entities: Optional[List["Entity"]],
	comp_type: Optional[str],
) -> str:
	"""``Entity Name -> Component Name -> Group Name``."""
	group = str(group_label)
	if entity is not None and component is not None:
		return (
			f"{_entity_display_name(entity)} -> "
			f"{_component_display_name(component)} -> {group}"
		)
	ents = list(entities or [])
	if len(ents) == 1:
		entity_part = _entity_display_name(ents[0])
	elif len(ents) > 1:
		entity_part = f"{len(ents)} entities"
	else:
		entity_part = "Selection"
	return (
		f"{entity_part} -> "
		f"{_component_display_name(comp_type=comp_type)} -> {group}"
	)


def open_inspector_group_dock(
	panel: "InspectorPanel",
	group_label: str,
	rows: List[InspectorLayoutRow],
	*,
	entity: Optional["Entity"] = None,
	component=None,
	entities: Optional[List["Entity"]] = None,
	comp_type: Optional[str] = None,
	prototype=None,
) -> None:
	"""Open one floating dockable window per group (reuse if already open)."""
	key = _group_dock_key(
		group_label,
		entity=entity,
		component=component,
		entities=entities,
		comp_type=comp_type,
	)
	title = _group_window_title(
		group_label,
		entity=entity,
		component=component,
		entities=entities,
		comp_type=comp_type,
	)

	def _make() -> InspectorGroupPanel:
		return InspectorGroupPanel(
			panel,
			group_label,
			rows,
			entity=entity,
			component=component,
			entities=entities,
			comp_type=comp_type,
			prototype=prototype,
		)

	open_or_focus_inspector_dock(
		panel,
		key,
		title,
		_make,
		store_attr="_group_docks",
		width=420,
		height=360,
	)


class InspectorGroupPanel(QWidget):
	"""Form content for one inspector ``Group``, hosted in its own floating dock."""

	def __init__(
		self,
		panel: "InspectorPanel",
		group_label: str,
		rows: List[InspectorLayoutRow],
		*,
		entity: Optional["Entity"] = None,
		component=None,
		entities: Optional[List["Entity"]] = None,
		comp_type: Optional[str] = None,
		prototype=None,
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._group_label = str(group_label)
		self._rows = rows
		self._entity = entity
		self._component = component
		self._entities = entities
		self._comp_type = comp_type
		self._prototype = prototype
		self._refresh_pending = False
		self._closing = False
		self._host_dock: Optional[QDockWidget] = None

		self._undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
		self._redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
		self._redo_ctrl_y_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
		for sc in (self._undo_shortcut, self._redo_shortcut, self._redo_ctrl_y_shortcut):
			sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
		self._undo_shortcut.activated.connect(self._trigger_global_undo)
		self._redo_shortcut.activated.connect(self._trigger_global_redo)
		self._redo_ctrl_y_shortcut.activated.connect(self._trigger_global_redo)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

		body = QWidget(scroll)
		self._form = QFormLayout(body)
		self._form.setContentsMargins(0, 0, 0, 0)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		self._rebuild_rows()
		self._connect_refresh_signals()

	def bind_host_dock(self, dock: QDockWidget) -> None:
		self._host_dock = dock

	def _undo_stack(self):
		return getattr(self._panel, "_undo_stack", None)

	def _trigger_global_undo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canUndo():
			stack.undo()

	def _trigger_global_redo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canRedo():
			stack.redo()

	def _connect_refresh_signals(self) -> None:
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.connect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def _rebuild_rows(self) -> None:
		self._refresh_pending = False
		if self._closing:
			return
		if not self._is_context_valid():
			self._close_host()
			return
		self._refresh_window_title()
		while self._form.rowCount() > 0:
			self._form.removeRow(0)
		if self._entities is not None and self._comp_type is not None and self._prototype is not None:
			self._panel._append_inspector_rows_multi(
				self._form, self._rows, self._entities, self._comp_type, self._prototype
			)
		elif self._entity is not None and self._component is not None:
			self._panel._append_inspector_rows_single(
				self._form, self._rows, self._entity, self._component
			)

	def _refresh_window_title(self) -> None:
		dock = self._host_dock
		if dock is None:
			return
		dock.setWindowTitle(
			_group_window_title(
				self._group_label,
				entity=self._entity,
				component=self._component,
				entities=self._entities,
				comp_type=self._comp_type,
			)
		)

	def _is_context_valid(self) -> bool:
		scene = getattr(self._panel, "_scene", None)
		if self._entity is not None and self._component is not None:
			try:
				if scene is not None and scene.find_by_id(self._entity.id) is not self._entity:
					return False
				return self._component in list(getattr(self._entity, "components", []))
			except Exception:
				return False
		if self._entities is not None and self._comp_type is not None:
			try:
				for ent in self._entities:
					if scene is not None and scene.find_by_id(ent.id) is not ent:
						continue
					for comp in getattr(ent, "components", []):
						type_name = getattr(comp, "type_name", comp.__class__.__name__)
						if type_name == self._comp_type or comp.__class__.__name__ == self._comp_type:
							return True
				return False
			except Exception:
				return False
		return True

	def _schedule_refresh(self) -> None:
		if self._refresh_pending or self._closing:
			return
		self._refresh_pending = True
		QTimer.singleShot(0, self._rebuild_rows)

	def _on_undo_redo(self, _idx: int) -> None:
		self._schedule_refresh()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity is not None and self._entity.id == entity_id:
			self._schedule_refresh()
			return
		if self._entities is not None and any(e.id == entity_id for e in self._entities):
			self._schedule_refresh()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity is not None and self._entity.id == entity_id:
			self._close_host()
			return
		if self._entities is not None and any(e.id == entity_id for e in self._entities):
			self._schedule_refresh()

	def _close_host(self) -> None:
		self._closing = True
		dock = self._host_dock
		if dock is not None:
			dock.close()
		else:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.disconnect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)


# Back-compat alias used by older imports / tests.
InspectorGroupPopup = InspectorGroupPanel

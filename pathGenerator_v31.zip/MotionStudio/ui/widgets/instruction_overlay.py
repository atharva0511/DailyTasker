from __future__ import annotations
from PyQt6.QtWidgets import QLabel, QWidget
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class InstructionOverlay(QLabel):
    """
    Overlay text widget that displays step-by-step instructions in the 3D view.
    """
    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        
        # Styling for a prominent overlay
        self.setStyleSheet("""
            QLabel {
                background-color: rgba(30, 30, 30, 255);
                color: #ffffff;
                border: 2px solid #4CAF50;
                border-radius: 8px;
                padding: 12px 20px;
                font-size: 12pt;
            }
        """)
        
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setWordWrap(True)
        self.hide()
        
        if parent:
            parent.installEventFilter(self)
    
    def show_instruction(self, text: str) -> None:
        """Shows the instruction text."""
        p = self.parent()
        if p is not None:
            self.setMaximumWidth(max(360, int(p.width() * 0.72)))
        self.setText(text)
        self.adjustSize()
        self.reposition()
        self.show()
        self.raise_()
    
    def clear_instruction(self) -> None:
        """Hides the instruction overlay."""
        self.hide()
        self.setText("")
    
    def eventFilter(self, obj, event) -> bool:
        """Reposition on parent resize."""
        if obj == self.parent() and event.type() == event.Type.Resize:
            if self.isVisible():
                p = self.parent()
                if p is not None:
                    self.setMaximumWidth(max(360, int(p.width() * 0.72)))
                    self.adjustSize()
                self.reposition()
        return super().eventFilter(obj, event)
    
    def reposition(self) -> None:
        """Positions the overlay at the top center of the parent viewport."""
        p = self.parent()
        if not p:
            return
        
        # Position at top center with some margin
        self.adjustSize()
        w = self.width()
        h = self.height()
        
        x = (p.width() - w) // 2
        y = 40  # Top margin
        
        self.move(x, y)


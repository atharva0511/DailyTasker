from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtWidgets import QHBoxLayout, QPushButton, QToolBar, QWidget

from MotionStudio.ui.theme import play_ribbon_stylesheet


class PlayModeRibbon(QWidget):
	"""
	Ribbon-style toolbar widget for Play Mode controls.
	Displays Play and Stop buttons similar to Unity's play controls.
	"""

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._on_play_clicked: Optional[Callable[[], None]] = None
		self._on_stop_clicked: Optional[Callable[[], None]] = None
		self._on_pause_clicked: Optional[Callable[[], None]] = None
		self._on_resume_clicked: Optional[Callable[[], None]] = None
		self._ribbon_mode = "default"
		self._is_playing = False
		self._is_paused = False
		self._routine_running = False

		layout = QHBoxLayout(self)
		layout.setContentsMargins(8, 6, 8, 6)
		layout.setSpacing(8)

		layout.addStretch()

		self._play_button = QPushButton("▶ Play", self)
		self._play_button.setObjectName("play_button")
		self._play_button.clicked.connect(self._on_play_button_clicked)
		layout.addWidget(self._play_button)

		self._pause_button = QPushButton("⏸ Pause", self)
		self._pause_button.setObjectName("pause_button")
		self._pause_button.setEnabled(False)
		self._pause_button.clicked.connect(self._on_pause_button_clicked)
		layout.addWidget(self._pause_button)

		self._stop_button = QPushButton("⏹ Stop", self)
		self._stop_button.setObjectName("stop_button")
		self._stop_button.setEnabled(False)
		self._stop_button.clicked.connect(self._on_stop_button_clicked)
		layout.addWidget(self._stop_button)

		layout.addStretch()

		self.apply_theme_stylesheet()

	def set_play_callbacks(
		self,
		on_play: Callable[[], None],
		on_stop: Callable[[], None],
		on_pause: Optional[Callable[[], None]] = None,
		on_resume: Optional[Callable[[], None]] = None,
	) -> None:
		"""Set callbacks for Play, Stop, Pause, and Resume button clicks."""
		self._on_play_clicked = on_play
		self._on_stop_clicked = on_stop
		self._on_pause_clicked = on_pause
		self._on_resume_clicked = on_resume

	def apply_theme_stylesheet(self) -> None:
		"""Re-apply ribbon QSS for the current UI theme and play state."""
		stylesheet = play_ribbon_stylesheet(self._ribbon_mode)
		self.setStyleSheet(stylesheet)
		parent = self.parent()
		if isinstance(parent, QToolBar):
			parent.setStyleSheet(stylesheet)
		self.update()
		if isinstance(parent, QToolBar):
			parent.update()

	def set_play_mode(self, is_playing: bool, is_paused: bool = False) -> None:
		"""Update button states and ribbon color based on play mode and pause state."""
		self._is_playing = bool(is_playing)
		self._is_paused = bool(is_paused)
		self._apply_ribbon_state()

	def set_routine_running(self, running: bool) -> None:
		"""Blue ribbon + all Play/Pause/Stop disabled while any edit-mode routine runs."""
		self._routine_running = bool(running)
		self._apply_ribbon_state()

	def _apply_ribbon_state(self) -> None:
		if self._routine_running:
			self._play_button.setEnabled(False)
			self._pause_button.setEnabled(False)
			self._stop_button.setEnabled(False)
			self._pause_button.setText("⏸ Pause")
			self._ribbon_mode = "routine"
			self.apply_theme_stylesheet()
			return

		self._play_button.setEnabled(not self._is_playing)
		self._stop_button.setEnabled(self._is_playing)
		self._pause_button.setEnabled(self._is_playing)

		if self._is_playing:
			if self._is_paused:
				self._pause_button.setText("▶ Resume")
				self._ribbon_mode = "paused"
			else:
				self._pause_button.setText("⏸ Pause")
				self._ribbon_mode = "active"
		else:
			self._pause_button.setText("⏸ Pause")
			self._ribbon_mode = "default"

		self.apply_theme_stylesheet()

	def _on_play_button_clicked(self) -> None:
		if self._on_play_clicked:
			self._on_play_clicked()

	def _on_stop_button_clicked(self) -> None:
		if self._on_stop_clicked:
			self._on_stop_clicked()

	def _on_pause_button_clicked(self) -> None:
		if self._pause_button.text() == "⏸ Pause":
			if self._on_pause_clicked:
				self._on_pause_clicked()
		else:
			if self._on_resume_clicked:
				self._on_resume_clicked()

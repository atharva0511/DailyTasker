"""Edit → Preferences dialog (theme, global font size, TCP command server)."""

from __future__ import annotations

from typing import Callable, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
	QCheckBox,
	QComboBox,
	QDialog,
	QDialogButtonBox,
	QFormLayout,
	QGroupBox,
	QLabel,
	QSpinBox,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.core.preferences import (
	MAX_FONT_SIZE,
	MAX_TCP_PORT,
	MAX_TCP_TIMEOUT_S,
	MIN_FONT_SIZE,
	MIN_TCP_PORT,
	MIN_TCP_TIMEOUT_S,
	Preferences,
	preferences_ini_path,
)


class PreferencesDialog(QDialog):
	"""
	Modal preferences editor.

	``on_preview`` is invoked whenever Theme or Font Size changes so the UI can
	update live. Cancel restores ``initial`` via the same callback.
	"""

	def __init__(
		self,
		parent: Optional[QWidget] = None,
		*,
		initial: Preferences,
		on_preview: Optional[Callable[[Preferences], None]] = None,
	) -> None:
		super().__init__(parent)
		self.setWindowTitle("Preferences")
		self.setModal(True)
		self.setMinimumWidth(360)

		self._initial = initial.normalized()
		self._on_preview = on_preview
		self._updating = False

		root = QVBoxLayout(self)
		form = QFormLayout()
		form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

		self._theme = QComboBox(self)
		self._theme.addItem("Dark", "dark")
		self._theme.addItem("Light", "light")
		idx = 0 if self._initial.theme == "dark" else 1
		self._theme.setCurrentIndex(idx)
		self._theme.currentIndexChanged.connect(self._emit_preview)
		form.addRow("Color Theme", self._theme)

		self._font_size = QSpinBox(self)
		self._font_size.setRange(MIN_FONT_SIZE, MAX_FONT_SIZE)
		self._font_size.setSuffix(" pt")
		self._font_size.setValue(self._initial.font_size)
		self._font_size.valueChanged.connect(self._emit_preview)
		form.addRow("Font Size", self._font_size)

		root.addLayout(form)

		tcp_box = QGroupBox("TCP Command Server", self)
		tcp_form = QFormLayout(tcp_box)
		tcp_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

		self._tcp_enabled = QCheckBox("Listen for remote commands", tcp_box)
		self._tcp_enabled.setChecked(self._initial.tcp_enabled)
		tcp_form.addRow("Enabled", self._tcp_enabled)

		self._tcp_port = QSpinBox(tcp_box)
		self._tcp_port.setRange(MIN_TCP_PORT, MAX_TCP_PORT)
		self._tcp_port.setValue(self._initial.tcp_port)
		tcp_form.addRow("Port", self._tcp_port)

		self._tcp_timeout = QSpinBox(tcp_box)
		self._tcp_timeout.setRange(MIN_TCP_TIMEOUT_S, MAX_TCP_TIMEOUT_S)
		self._tcp_timeout.setSuffix(" s")
		self._tcp_timeout.setValue(self._initial.tcp_timeout_s)
		tcp_form.addRow("Command Timeout", self._tcp_timeout)

		tcp_hint = QLabel(
			f"Bound to {self._initial.tcp_host}. Applied when you click OK.", tcp_box
		)
		tcp_hint.setWordWrap(True)
		tcp_hint.setStyleSheet("color: gray;")
		tcp_form.addRow(tcp_hint)

		root.addWidget(tcp_box)

		path_hint = QLabel(f"Saved to: {preferences_ini_path()}", self)
		path_hint.setWordWrap(True)
		path_hint.setStyleSheet("color: gray;")
		root.addWidget(path_hint)

		buttons = QDialogButtonBox(
			QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel,
			parent=self,
		)
		buttons.accepted.connect(self.accept)
		buttons.rejected.connect(self.reject)
		root.addWidget(buttons)

	def current_preferences(self) -> Preferences:
		theme = str(self._theme.currentData() or "dark")
		return Preferences(
			theme=theme,
			font_size=int(self._font_size.value()),
			tcp_enabled=bool(self._tcp_enabled.isChecked()),
			# No UI field: keep whatever preferences.ini already has.
			tcp_host=self._initial.tcp_host,
			tcp_port=int(self._tcp_port.value()),
			tcp_timeout_s=int(self._tcp_timeout.value()),
		).normalized()

	def _emit_preview(self, *_args) -> None:
		"""Live preview for theme / font only; TCP settings apply on OK."""
		if self._updating or self._on_preview is None:
			return
		self._on_preview(self.current_preferences())

	def reject(self) -> None:
		if self._on_preview is not None:
			self._on_preview(self._initial)
		super().reject()

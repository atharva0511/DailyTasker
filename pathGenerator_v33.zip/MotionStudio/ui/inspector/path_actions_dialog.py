"""Editor for the digital I/O actions attached to a path segment.

One floating dock per target: a segment's own action list, or the program-level
``default_actions`` template that seeds newly created segments
(``segment_idx=None``).

Rows are built per action rather than as a fixed table because the three kinds
carry different fields -- a Duration column would be meaningless for a Set, and
a grid would be mostly empty cells.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QKeySequence, QShortcut
from PyQt6.QtWidgets import (
	QCheckBox,
	QComboBox,
	QDockWidget,
	QDoubleSpinBox,
	QFrame,
	QHBoxLayout,
	QLabel,
	QMenu,
	QPushButton,
	QScrollArea,
	QSpinBox,
	QStyle,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.path.actions import (
	AT_EVERY,
	AT_FIRST,
	AT_INDEX,
	AT_LABELS,
	AT_LAST,
	KIND_LABELS,
	KIND_SET,
	KIND_WAIT_SIGNAL,
	KIND_WAIT_TIME,
	PathAction,
	actions_to_data,
	bank_spec,
	banks_for_kind,
	clamp_port,
	clone_actions,
	default_bank_for_kind,
	new_action,
)
from MotionStudio.ui.inspector.inspector_dock import (
	entity_display_name,
	open_or_focus_inspector_dock,
	path_window_title,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel

_AT_ORDER = [AT_FIRST, AT_LAST, AT_EVERY, AT_INDEX]
_STATE_LABELS = ["High", "Low"]


def actions_dock_label(segment_idx: Optional[int]) -> str:
	return "Default Actions" if segment_idx is None else f"Segment {segment_idx + 1} Actions"


def open_path_actions_dock(
	panel: "InspectorPanel",
	entity: "Entity",
	segment_idx: Optional[int],
) -> None:
	"""Open (or focus) the action list editor. ``segment_idx=None`` = defaults."""
	key = ("path_actions", str(entity.id), segment_idx)
	title = path_window_title(entity_display_name(entity), actions_dock_label(segment_idx))

	def _make() -> PathActionsPanel:
		return PathActionsPanel(panel, entity, segment_idx)

	open_or_focus_inspector_dock(
		panel,
		key,
		title,
		_make,
		store_attr="_path_docks",
		width=660,
		height=360,
	)


class PathActionsPanel(QWidget):
	"""Dock host: title/refresh plumbing around a :class:`PathActionListEditor`."""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		segment_idx: Optional[int],
	) -> None:
		super().__init__(panel)
		self._panel = panel
		self._entity = entity
		self._segment_idx = segment_idx
		self._refresh_pending = False
		self._closing = False
		self._host_dock: Optional[QDockWidget] = None

		self._undo_shortcut = QShortcut(QKeySequence.StandardKey.Undo, self)
		self._redo_shortcut = QShortcut(QKeySequence.StandardKey.Redo, self)
		self._redo_ctrl_y_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
		for sc in (self._undo_shortcut, self._redo_shortcut, self._redo_ctrl_y_shortcut):
			sc.setContext(Qt.ShortcutContext.WidgetWithChildrenShortcut)
		self._undo_shortcut.activated.connect(self._trigger_global_undo)
		self._redo_shortcut.activated.connect(self._trigger_global_redo)
		self._redo_ctrl_y_shortcut.activated.connect(self._trigger_global_redo)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)
		self._editor = PathActionListEditor(panel, entity, segment_idx, self)
		root.addWidget(self._editor, 1)

		self._connect_refresh_signals()

	def bind_host_dock(self, dock: QDockWidget) -> None:
		self._host_dock = dock

	def _undo_stack(self):
		return getattr(self._panel, "_undo_stack", None)

	def _trigger_global_undo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canUndo():
			stack.undo()

	def _trigger_global_redo(self) -> None:
		stack = self._undo_stack()
		if stack is not None and stack.canRedo():
			stack.redo()

	def _connect_refresh_signals(self) -> None:
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.connect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
		except Exception:
			pass

	def _rebuild(self) -> None:
		self._refresh_pending = False
		if self._closing:
			return
		if not self._is_context_valid():
			self._close_host()
			return
		self._refresh_window_title()
		self._editor.rebuild()

	def _refresh_window_title(self) -> None:
		dock = self._host_dock
		if dock is None:
			return
		dock.setWindowTitle(
			path_window_title(
				entity_display_name(self._entity),
				actions_dock_label(self._segment_idx),
			)
		)

	def _is_context_valid(self) -> bool:
		try:
			scene = getattr(self._panel, "_scene", None)
			if scene is not None and scene.find_by_id(self._entity.id) is not self._entity:
				return False
			path_comp = self._entity.get_component(PathComponent)
			if path_comp is None:
				return False
			if self._segment_idx is None:
				return True
			return 0 <= self._segment_idx < len(path_comp.segments)
		except Exception:
			return False

	def _on_undo_redo(self, _idx: int) -> None:
		self._schedule_refresh()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._schedule_refresh()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._close_host()

	def _schedule_refresh(self) -> None:
		# Defer so rows are not destroyed while their own signal handlers run.
		if self._refresh_pending or self._closing:
			return
		self._refresh_pending = True
		QTimer.singleShot(0, self._rebuild)

	def _close_host(self) -> None:
		self._closing = True
		dock = self._host_dock
		if dock is not None:
			dock.close()
		else:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			if self._panel._undo_stack is not None:
				self._panel._undo_stack.indexChanged.disconnect(self._on_undo_redo)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)


class PathActionListEditor(QWidget):
	"""Add / reorder / edit / remove rows of :class:`PathAction`.

	Fully data-driven: every edit pushes a whole-list undo command, and the
	resulting ``entity_changed`` rebuilds the rows from the model.
	"""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		segment_idx: Optional[int],
		parent: Optional[QWidget] = None,
	) -> None:
		super().__init__(parent)
		self._panel = panel
		self._entity = entity
		self._segment_idx = segment_idx
		self._building = False

		root = QVBoxLayout(self)
		root.setContentsMargins(0, 0, 0, 0)
		root.setSpacing(6)

		header = QWidget(self)
		hl = QHBoxLayout(header)
		hl.setContentsMargins(0, 0, 0, 0)
		self._hint = QLabel("", header)
		self._hint.setWordWrap(True)
		hl.addWidget(self._hint, 1)
		add_btn = QPushButton("Add", header)
		add_btn.setToolTip("Add an action to this list")
		self._add_menu = QMenu(add_btn)
		for kind in (KIND_SET, KIND_WAIT_TIME, KIND_WAIT_SIGNAL):
			act = self._add_menu.addAction(KIND_LABELS[kind])
			act.triggered.connect(lambda _c=False, k=kind: self._add_action(k))
		add_btn.setMenu(self._add_menu)
		hl.addWidget(add_btn, 0)
		root.addWidget(header, 0)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		body = QWidget(scroll)
		self._rows = QVBoxLayout(body)
		self._rows.setContentsMargins(0, 0, 0, 0)
		self._rows.setSpacing(4)
		self._rows.addStretch(1)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		self.rebuild()

	# ------------------------------------------------------------------ model

	def _path_component(self) -> Optional[PathComponent]:
		try:
			return self._entity.get_component(PathComponent)
		except Exception:
			return None

	def _actions(self) -> List[PathAction]:
		comp = self._path_component()
		if comp is None:
			return []
		if self._segment_idx is None:
			return list(getattr(comp, "default_actions", []) or [])
		if 0 <= self._segment_idx < len(comp.segments):
			return list(getattr(comp.segments[self._segment_idx], "actions", []) or [])
		return []

	def _waypoint_count(self) -> int:
		comp = self._path_component()
		if comp is None or self._segment_idx is None:
			return 0
		if 0 <= self._segment_idx < len(comp.segments):
			return len(getattr(comp.segments[self._segment_idx], "waypoints", []) or [])
		return 0

	def _commit(self, actions: List[PathAction], text: str) -> None:
		stack = getattr(self._panel, "_undo_stack", None)
		scene = getattr(self._panel, "_scene", None)
		old_data = actions_to_data(self._actions())
		new_data = actions_to_data(actions)
		if old_data == new_data:
			return
		if stack is None or scene is None:
			return
		from MotionStudio.core.undo.commands import PathActionsChangeCommand

		stack.push(
			PathActionsChangeCommand(
				scene,
				self._entity.id,
				self._segment_idx,
				old_data,
				new_data,
				text=text,
			)
		)

	def _mutate(self, index: int, text: str, apply) -> None:
		if self._building:
			return
		actions = clone_actions(self._actions())
		if not (0 <= index < len(actions)):
			return
		apply(actions[index])
		self._commit(actions, text)

	# ----------------------------------------------------------- list actions

	def _add_action(self, kind: str) -> None:
		actions = clone_actions(self._actions())
		actions.append(new_action(kind))
		self._commit(actions, f"Add {KIND_LABELS.get(kind, 'Action')}")

	def _remove_action(self, index: int) -> None:
		actions = clone_actions(self._actions())
		if not (0 <= index < len(actions)):
			return
		actions.pop(index)
		self._commit(actions, "Remove Action")

	def _move_action(self, index: int, delta: int) -> None:
		actions = clone_actions(self._actions())
		target = index + delta
		if not (0 <= index < len(actions)) or not (0 <= target < len(actions)):
			return
		actions[index], actions[target] = actions[target], actions[index]
		self._commit(actions, "Reorder Actions")

	# -------------------------------------------------------------------- ui

	def rebuild(self) -> None:
		self._building = True
		try:
			while self._rows.count() > 1:
				item = self._rows.takeAt(0)
				w = item.widget()
				if w is not None:
					w.setParent(None)
					w.deleteLater()

			actions = self._actions()
			self._hint.setText(self._hint_text(actions))

			if not actions:
				empty = QLabel("No actions. Use Add to create one.", self)
				empty.setEnabled(False)
				self._rows.insertWidget(0, empty)
				return

			for i, action in enumerate(actions):
				self._rows.insertWidget(i, self._build_row(i, action, len(actions)))
		finally:
			self._building = False

	def _hint_text(self, actions: List[PathAction]) -> str:
		if self._segment_idx is None:
			return "Copied onto each new segment as it is created; existing segments are unaffected."
		comp = self._path_component()
		blended = False
		if comp is not None and 0 <= self._segment_idx < len(comp.segments):
			blended = float(getattr(comp.segments[self._segment_idx], "cnt_radius", 0.0)) > 0.0
		if blended and any(a.enabled for a in actions):
			return (
				"CNT Radius is set on this segment. Waypoints carrying an action "
				"are exported without blending so the robot stops there first."
			)
		return "Runs after the robot reaches the anchored waypoint."

	def _build_row(self, index: int, action: PathAction, total: int) -> QWidget:
		panel = self._panel
		row = QFrame(self)
		row.setFrameShape(QFrame.Shape.StyledPanel)
		h = QHBoxLayout(row)
		h.setContentsMargins(6, 4, 6, 4)
		h.setSpacing(6)

		enabled = QCheckBox(row)
		enabled.setToolTip("Include this action in the exported program")
		enabled.setChecked(bool(action.enabled))
		enabled.toggled.connect(
			lambda checked, i=index: self._mutate(
				i, "Toggle Action", lambda a: setattr(a, "enabled", bool(checked))
			)
		)
		h.addWidget(enabled, 0)

		kind_cb = QComboBox(row)
		for kind in (KIND_SET, KIND_WAIT_TIME, KIND_WAIT_SIGNAL):
			kind_cb.addItem(KIND_LABELS[kind], kind)
		kind_cb.setCurrentIndex(max(0, kind_cb.findData(action.kind)))
		kind_cb.setToolTip("Set writes an output; Wait dwells or polls an input")
		kind_cb.activated.connect(
			lambda _i, i=index, w=kind_cb: self._change_kind(i, str(w.currentData()))
		)
		h.addWidget(kind_cb, 0)

		h.addWidget(QLabel("At", row), 0)
		at_cb = QComboBox(row)
		for at in _AT_ORDER:
			at_cb.addItem(AT_LABELS[at], at)
		at_cb.setCurrentIndex(max(0, at_cb.findData(action.at)))
		at_cb.activated.connect(
			lambda _i, i=index, w=at_cb: self._mutate(
				i, "Edit Action", lambda a, v=str(w.currentData()): setattr(a, "at", v)
			)
		)
		h.addWidget(at_cb, 0)

		if action.at == AT_INDEX:
			idx_sb = QSpinBox(row)
			idx_sb.setRange(1, max(1, self._waypoint_count() or 9999))
			idx_sb.setValue(int(action.at_index) + 1)
			idx_sb.setToolTip("1-based waypoint number within this segment")
			idx_sb.setMaximumWidth(70)
			idx_sb.editingFinished.connect(
				lambda i=index, w=idx_sb: self._mutate(
					i, "Edit Action", lambda a, v=w: setattr(a, "at_index", int(v.value()) - 1)
				)
			)
			h.addWidget(idx_sb, 0)

		if action.kind in (KIND_SET, KIND_WAIT_SIGNAL):
			bank_cb = QComboBox(row)
			for spec in banks_for_kind(action.kind):
				bank_cb.addItem(spec.label, spec.id)
			bank_cb.setCurrentIndex(max(0, bank_cb.findData(action.bank)))
			bank_cb.activated.connect(
				lambda _i, i=index, w=bank_cb: self._change_bank(i, str(w.currentData()))
			)
			h.addWidget(bank_cb, 0)

			spec = bank_spec(action.bank)
			port_sb = QSpinBox(row)
			port_sb.setRange(spec.min_port, spec.max_port)
			port_sb.setValue(clamp_port(action.bank, action.port))
			port_sb.setToolTip(f"{spec.label} port ({spec.min_port}-{spec.max_port})")
			port_sb.setMaximumWidth(60)
			port_sb.editingFinished.connect(
				lambda i=index, w=port_sb: self._mutate(
					i, "Edit Action", lambda a, v=w: setattr(a, "port", int(v.value()))
				)
			)
			h.addWidget(port_sb, 0)

			h.addWidget(QLabel("=" if action.kind == KIND_WAIT_SIGNAL else "to", row), 0)
			state_cb = QComboBox(row)
			for label in _STATE_LABELS:
				state_cb.addItem(label, label == "High")
			state_cb.setCurrentIndex(0 if action.state else 1)
			state_cb.activated.connect(
				lambda _i, i=index, w=state_cb: self._mutate(
					i, "Edit Action", lambda a, v=bool(w.currentData()): setattr(a, "state", v)
				)
			)
			h.addWidget(state_cb, 0)

		if action.kind == KIND_WAIT_TIME:
			dur_sb = QDoubleSpinBox(row)
			dur_sb.setRange(0.0, 3600.0)
			dur_sb.setDecimals(3)
			dur_sb.setSingleStep(0.1)
			dur_sb.setSuffix(" s")
			dur_sb.setValue(float(action.duration_s))
			dur_sb.setMaximumWidth(110)
			dur_sb.editingFinished.connect(
				lambda i=index, w=dur_sb: self._mutate(
					i, "Edit Action", lambda a, v=w: setattr(a, "duration_s", float(v.value()))
				)
			)
			h.addWidget(dur_sb, 0)

		if action.kind == KIND_WAIT_SIGNAL:
			h.addWidget(QLabel("timeout", row), 0)
			to_sb = QDoubleSpinBox(row)
			to_sb.setRange(0.0, 3600.0)
			to_sb.setDecimals(2)
			to_sb.setSingleStep(0.5)
			to_sb.setSuffix(" s")
			to_sb.setSpecialValueText("none")
			to_sb.setValue(float(action.timeout_s))
			to_sb.setToolTip("0 waits forever")
			to_sb.setMaximumWidth(110)
			to_sb.editingFinished.connect(
				lambda i=index, w=to_sb: self._mutate(
					i, "Edit Action", lambda a, v=w: setattr(a, "timeout_s", float(v.value()))
				)
			)
			h.addWidget(to_sb, 0)

		h.addStretch(1)

		up = panel._make_bordered_icon_tool_button(
			row, QStyle.StandardPixmap.SP_ArrowUp, "Move action up"
		)
		up.setEnabled(index > 0)
		up.clicked.connect(lambda _c=False, i=index: self._move_action(i, -1))
		h.addWidget(up, 0)

		down = panel._make_bordered_icon_tool_button(
			row, QStyle.StandardPixmap.SP_ArrowDown, "Move action down"
		)
		down.setEnabled(index < total - 1)
		down.clicked.connect(lambda _c=False, i=index: self._move_action(i, 1))
		h.addWidget(down, 0)

		remove = panel._make_bordered_icon_tool_button(
			row, QStyle.StandardPixmap.SP_TrashIcon, "Remove action"
		)
		remove.clicked.connect(lambda _c=False, i=index: self._remove_action(i))
		h.addWidget(remove, 0)

		return row

	def _change_kind(self, index: int, kind: str) -> None:
		"""Switch kind, retargeting the bank since Set writes but Wait reads."""

		def _apply(action: PathAction) -> None:
			action.kind = kind
			if kind == KIND_WAIT_TIME:
				return
			if bank_spec(action.bank).is_output != (kind == KIND_SET):
				action.bank = default_bank_for_kind(kind)
			action.port = clamp_port(action.bank, action.port)

		self._mutate(index, "Change Action Type", _apply)

	def _change_bank(self, index: int, bank: str) -> None:
		def _apply(action: PathAction) -> None:
			action.bank = bank
			action.port = clamp_port(bank, action.port)

		self._mutate(index, "Edit Action", _apply)

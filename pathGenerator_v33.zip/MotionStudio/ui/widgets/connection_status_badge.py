"""Read-only connection status LED + text badge for the Inspector."""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

from PyQt6.QtCore import QSize, Qt
from PyQt6.QtWidgets import (
	QFrame,
	QHBoxLayout,
	QLabel,
	QPlainTextEdit,
	QSizePolicy,
	QVBoxLayout,
	QWidget,
)

if TYPE_CHECKING:
	from MotionStudio.ui.inspector.metadata import ConnectionStatus

_LED_SIZE = 12
_TEXT_LINES = 3

_LED_COLORS = {
	"connected": ("#2ecc71", "#1a7a42"),
	"busy": ("#e6b84d", "#8a6a18"),
	"other": ("#e85d5d", "#8a2a2a"),
	"mixed": ("#888888", "#555555"),
}


class ConnectionStatusBadge(QWidget):
	"""Circular LED + multiline status text bounded to the Inspector field width."""

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		# Allow the form field column to shrink with the Inspector; do not push width.
		self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		self.setMinimumWidth(0)

		layout = QHBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.setSpacing(8)

		# LED column: top-aligned so it lines up with the QFormLayout label
		# (and with the first line of the status text).
		self._led_col = QWidget(self)
		self._led_col.setFixedWidth(_LED_SIZE)
		self._led_col.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
		led_col_layout = QVBoxLayout(self._led_col)
		led_col_layout.setContentsMargins(0, 0, 0, 0)
		led_col_layout.setSpacing(0)

		self._led = QLabel(self._led_col)
		self._led.setFixedSize(_LED_SIZE, _LED_SIZE)
		self._led.setAlignment(Qt.AlignmentFlag.AlignCenter)
		led_col_layout.addWidget(self._led, 0, Qt.AlignmentFlag.AlignHCenter)
		led_col_layout.addStretch(1)
		layout.addWidget(self._led_col, 0, Qt.AlignmentFlag.AlignTop)

		self._text = QPlainTextEdit(self)
		self._text.setReadOnly(True)
		self._text.setFrameShape(QFrame.Shape.StyledPanel)
		self._text.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
		self._text.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
		self._text.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		self._text.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		self._text.setMinimumWidth(0)
		self._apply_text_height()
		layout.addWidget(self._text, 1)

		self._meta: Optional["ConnectionStatus"] = None
		self.set_status("", None)
		self._sync_led_top_inset()

	def sizeHint(self) -> QSize:
		# Prefer a narrow width so QFormLayout follows the Inspector, not the
		# full status string. Height comes from the fixed multiline editor.
		base = super().sizeHint()
		return QSize(120, base.height())

	def minimumSizeHint(self) -> QSize:
		base = super().minimumSizeHint()
		return QSize(0, base.height())

	def showEvent(self, event) -> None:  # noqa: N802 — Qt override
		super().showEvent(event)
		# Frame metrics are reliable after the widget is shown/styled.
		self._sync_led_top_inset()

	def _apply_text_height(self) -> None:
		fm = self._text.fontMetrics()
		# Enough for a few wrapped lines; longer text scrolls vertically.
		pad = self._text.contentsMargins().top() + self._text.contentsMargins().bottom() + 10
		height = fm.lineSpacing() * _TEXT_LINES + pad
		self._text.setFixedHeight(height)

	def _sync_led_top_inset(self) -> None:
		"""Pad the LED so its center matches the first line of the text editor."""
		frame = int(self._text.frameWidth())
		margin = int(self._text.document().documentMargin())
		line_h = int(self._text.fontMetrics().lineSpacing())
		# Center the LED within the first content line below the frame.
		inset = frame + margin + max(0, (line_h - _LED_SIZE) // 2)
		layout = self._led_col.layout()
		if isinstance(layout, QVBoxLayout):
			layout.setContentsMargins(0, inset, 0, 0)

	def set_status(
		self,
		text: str,
		meta: Optional["ConnectionStatus"] = None,
		*,
		mixed: bool = False,
	) -> None:
		"""Update LED color and label from ``text`` and optional metadata."""
		if meta is not None:
			self._meta = meta
		display = "-" if mixed else str(text or "")
		self._text.setPlainText(display)
		self.setToolTip(display)
		self._text.setToolTip(display)

		if mixed:
			kind = "mixed"
		elif self._meta is not None:
			kind = self._meta.classify(str(text or ""))
		else:
			kind = "other"

		fill, border = _LED_COLORS.get(kind, _LED_COLORS["other"])
		self._led.setStyleSheet(
			f"QLabel {{"
			f" background-color: {fill};"
			f" border: 1px solid {border};"
			f" border-radius: {_LED_SIZE // 2}px;"
			f"}}"
		)
		self._sync_led_top_inset()

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Annotated, Any, Dict, List, Optional, Tuple

from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.collision.utils import entity_is_colliding
from MotionStudio.core.components.feature import CustomFeature, Waypoint
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.robot_ik_component import RobotIKComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	world_matrix,
	world_rotation_quat,
)
from MotionStudio.ui.inspector.metadata import (
	Multiline,
	Order,
	Range,
	ReadOnly,
	Tooltip,
	inspector_button,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def _qvec_norm(v: QVector3D) -> QVector3D:
	if v.length() < 1e-9:
		return QVector3D(0.0, 0.0, 1.0)
	out = QVector3D(v)
	out.normalize()
	return out


def _cone_sample_rotation(r0: QQuaternion, sample_idx: int, n_samples: int, tilt_deg: float) -> QQuaternion:
	"""Sample 0 = ``r0``; samples 1..N-1 tilt TCP +Z by ``tilt_deg`` around azimuth."""
	if sample_idx <= 0 or n_samples <= 1 or abs(tilt_deg) < 1e-6:
		return QQuaternion(r0)
	n = _qvec_norm(r0.rotatedVector(QVector3D(0.0, 0.0, 1.0)))
	t = r0.rotatedVector(QVector3D(1.0, 0.0, 0.0))
	# If +X is nearly parallel to n, fall back to +Y.
	if abs(QVector3D.dotProduct(t, n)) > 0.95:
		t = r0.rotatedVector(QVector3D(0.0, 1.0, 0.0))
	t = t - n * QVector3D.dotProduct(t, n)
	t = _qvec_norm(t)
	b = _qvec_norm(QVector3D.crossProduct(n, t))
	ring_count = max(1, n_samples - 1)
	k = sample_idx - 1
	phi = (2.0 * math.pi * float(k)) / float(ring_count)
	theta = math.radians(float(tilt_deg))
	approach = (
		n * math.cos(theta)
		+ (t * math.cos(phi) + b * math.sin(phi)) * math.sin(theta)
	)
	approach = _qvec_norm(approach)
	q_tilt = QQuaternion.rotationTo(n, approach)
	return q_tilt * r0


def _world_to_local_waypoint(
	target_ent: "Entity",
	world_pos_mm: QVector3D,
	world_quat: QQuaternion,
) -> Waypoint:
	wm = world_matrix(target_ent)
	inv, ok = wm.inverted()
	if not ok:
		local_pos = QVector3D(world_pos_mm)
		local_rot = QQuaternion(world_quat)
	else:
		local_pos = inv.map(world_pos_mm)
		local_rot = world_rotation_quat(target_ent).inverted() * world_quat
	return Waypoint(QVector3D(local_pos), QQuaternion(local_rot))


@register_component
class GPLeakPathGeneratorComponent(Component):
	"""Expand leak-port polylines into approach/touch/retract path segments."""

	type_name = "GPLeakPathGenerator"
	category = "Path generation and planning"
	description = (
		"<p><b>GP Leak Path Generator</b></p>"
		"<p>On the Gas Panel entity (with a sibling <b>PathGeneration</b> of leak-port "
		"polylines), expands each port into approach → touch → retract waypoints using "
		"cone-tilted TCP samples for collision-free IK. Writes one named custom segment "
		"per source segment into another entity's PathGeneration.</p>"
		"<p>While generating, a play routine moves the robot's <b>RobotIK</b> target to "
		"each candidate approach/port pose so you can watch IK and collision checks "
		"in the viewport.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Mark ports with polyline segments on this entity's PathGeneration; name each segment.</li>"
		"<li>Orient a helper Transform as the default probe TCP rotation; assign "
		"<b>Default TCP transform</b>.</li>"
		"<li>Create a Job entity with PathGeneration; assign it to <b>Generate path into</b>.</li>"
		"<li>Bind <b>robot</b> on the source PathGeneration (robot must have RobotIK + Target), "
		"then click <b>Generate leak path</b>.</li>"
		"</ul>"
	)

	generate_path_into: Annotated[
		Optional[PathComponent],
		Order(10),
		Tooltip(
			"Target PathGeneration (usually on another entity) that receives the "
			"generated approach/touch/retract segments. Overwritten on each Generate."
		),
	] = None

	default_tcp_transform: Annotated[
		Optional[TransformComponent],
		Order(20),
		Tooltip(
			"Transform whose world rotation is the untilted TCP orientation (cone apex). "
			"Position is ignored; only orientation is used for conical jog samples."
		),
	] = None

	approach_height_mm: Annotated[
		float,
		Order(30),
		Range(1.0, 1000.0, step=1.0, decimals=1),
		Tooltip(
			"Offset from each port along −TCP +Z for the approach/retract pose (mm)."
		),
	] = 80.0

	cone_tilt_deg: Annotated[
		float,
		Order(40),
		Range(0.0, 89.0, step=1.0, decimals=1),
		Tooltip(
			"Half-angle of the conical jog about the default TCP +Z (degrees). "
			"Sample 0 is untilted; remaining samples lie on this cone."
		),
	] = 20.0

	samples_per_port: Annotated[
		int,
		Order(50),
		Range(1, 32, step=1),
		Tooltip(
			"Orientation samples per port (1 untilted + ring). Port is skipped if all fail."
		),
	] = 8

	status: Annotated[
		str,
		Order(60),
		ReadOnly(),
		Multiline(),
		Tooltip("Generation progress and skipped-port summary."),
	] = ""

	def __init__(
		self,
		approach_height_mm: float = 80.0,
		cone_tilt_deg: float = 20.0,
		samples_per_port: int = 8,
	) -> None:
		self.generate_path_into = None
		self.default_tcp_transform = None
		self.approach_height_mm = float(approach_height_mm)
		self.cone_tilt_deg = float(cone_tilt_deg)
		self.samples_per_port = int(samples_per_port)
		self.status = ""
		self._gen_handle = None
		self._gen_listeners: list = []
		# Runtime state for the play routine (not serialized).
		self._r0 = QQuaternion()
		self._port_positions: List[List[QVector3D]] = []
		self._source_meta: List[Dict[str, Any]] = []
		self._seg_idx = 0
		self._port_idx = 0
		self._sample_idx = 0
		# "approach" then "port" for the current sample (one pose per frame).
		self._phase: str = "approach"
		self._pending_waypoints: List[List[Waypoint]] = []
		self._skipped: List[str] = []
		self._accepted_count = 0
		self._target_path: Optional[PathComponent] = None
		self._source_path: Optional[PathComponent] = None
		self._robot_ik: Optional[RobotIKComponent] = None
		self._ik_target_ent: Optional[Entity] = None
		self._robot_ent: Optional[Entity] = None
		self._saved_ik_enabled: Optional[bool] = None

	def add_generate_listener(self, callback) -> None:
		if callback not in self._gen_listeners:
			self._gen_listeners.append(callback)

	def remove_generate_listener(self, callback) -> None:
		try:
			self._gen_listeners.remove(callback)
		except ValueError:
			pass

	def _notify_generate_done(self, success: bool, message: str = "") -> None:
		for callback in list(self._gen_listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	# ------------------------------------------------------------------ resolve

	def _resolved_source_path(self) -> Optional[PathComponent]:
		entity = self.entity
		if entity is None:
			return None
		return entity.get_component(PathComponent)

	def _resolved_target_path(self) -> Optional[PathComponent]:
		value = self.generate_path_into
		if isinstance(value, PathComponent):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(PathComponent)
				if comp is not None:
					self.generate_path_into = comp
					return comp
		return None

	def _resolved_default_tcp(self) -> Optional[TransformComponent]:
		value = self.default_tcp_transform
		if isinstance(value, TransformComponent):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(TransformComponent)
				if comp is not None:
					self.default_tcp_transform = comp
					return comp
		return None

	def _resolved_robot(self, source: PathComponent) -> Optional[RobotDescriptionComponent]:
		return source._resolved_robot()

	def _resolve_robot_ik(
		self, rd: RobotDescriptionComponent
	) -> Tuple[Optional[RobotIKComponent], Optional[Entity], Optional[Entity], str]:
		"""Return (RobotIK, IK target entity, robot root entity, error)."""
		robot_ent = rd.entity
		if robot_ent is None:
			return None, None, None, "robot has no entity"
		ik = robot_ent.get_component(RobotIKComponent)
		if ik is None:
			return None, None, None, "add RobotIK on the bound robot entity"
		target = ik.target
		if target is None or not isinstance(target, TransformComponent):
			return None, None, None, "RobotIK has no Target transform"
		target_ent = target.entity
		if target_ent is None:
			return None, None, None, "RobotIK Target has no entity"
		return ik, target_ent, robot_ent, ""

	def _collect_port_positions(
		self, source: PathComponent
	) -> Tuple[List[List[QVector3D]], List[Dict[str, Any]], str]:
		"""World positions per source segment (rotation from waypoints ignored)."""
		try:
			for seg in source.segments:
				try:
					seg.generate_waypoints(None, {})
				except Exception:
					pass
			world_groups = source.get_world_waypoints_by_segment()
		except Exception as exc:
			return [], [], f"failed to read source waypoints ({exc})"
		positions: List[List[QVector3D]] = []
		meta: List[Dict[str, Any]] = []
		for i, seg in enumerate(source.segments):
			wps = world_groups[i] if i < len(world_groups) else []
			ports = [QVector3D(float(x), float(y), float(z)) for x, y, z, *_ in wps]
			positions.append(ports)
			meta.append(
				{
					"name": str(getattr(seg, "name", "") or ""),
					"speed_multiplier": float(getattr(seg, "speed_multiplier", 1.0)),
					"cnt_radius": float(getattr(seg, "cnt_radius", 0.0)),
				}
			)
		if not any(positions):
			return [], [], "source PathGeneration has no port waypoints"
		return positions, meta, ""

	# ------------------------------------------------------------------ buttons

	@inspector_button(
		"Generate leak path",
		tooltip=(
			"Play routine: move RobotIK target through cone samples at each leak port, "
			"then write named approach/touch/retract segments into Generate path into"
		),
		order=0,
	)
	def generate_leak_path(self):
		if self._gen_handle is not None and self._gen_handle.is_running:
			return False, "generation is already running"

		entity = self.entity
		if entity is None or entity.scene is None:
			return False, "no entity in a scene"
		scene = entity.scene

		pm = getattr(scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			Debug.warning("GPLeakPathGenerator: refused while Play Mode is active.")
			return False, "refused while Play Mode is active"

		source = self._resolved_source_path()
		if source is None:
			return False, "add a PathGeneration component on this entity (leak ports)"

		target = self._resolved_target_path()
		if target is None:
			return False, "assign Generate path into (PathGeneration on another entity)"
		if target is source:
			return False, "Generate path into must be a different PathGeneration"

		tcp = self._resolved_default_tcp()
		if tcp is None or tcp.entity is None:
			return False, "assign Default TCP transform"

		rd = self._resolved_robot(source)
		if rd is None:
			return False, "bind robot on the source PathGeneration (Export Robot Program)"

		robot_ik, ik_target_ent, robot_ent, ik_err = self._resolve_robot_ik(rd)
		if robot_ik is None or ik_target_ent is None or robot_ent is None:
			return False, ik_err or "RobotIK target is not configured"

		system = getattr(scene, "robot_ik_system", None)
		if system is None:
			return False, "no IK system on scene"

		ports, meta, perr = self._collect_port_positions(source)
		if perr:
			return False, perr

		self._r0 = world_rotation_quat(tcp.entity)
		self._port_positions = ports
		self._source_meta = meta
		self._seg_idx = 0
		self._port_idx = 0
		self._sample_idx = 0
		self._phase = "approach"
		self._pending_waypoints = [[] for _ in ports]
		self._skipped = []
		self._accepted_count = 0
		self._target_path = target
		self._source_path = source
		self._robot_ik = robot_ik
		self._ik_target_ent = ik_target_ent
		self._robot_ent = robot_ent
		self._saved_ik_enabled = bool(robot_ik.enabled)
		robot_ik.enabled = False
		self.status = "Starting…"

		self._gen_handle = self.start_play_routine(
			self._generate_loop, name="gp_leak_path"
		)
		if self._gen_handle is None or not self._gen_handle.is_running:
			self._restore_ik_enabled()
			self._clear_runtime()
			self.status = "Generate did not start"
			return False, "generate did not start"
		return True

	@inspector_button(
		"Cancel generate",
		tooltip="Stop leak-path generation; leave the target path unchanged",
		order=5,
	)
	def cancel_generate(self) -> None:
		if self._gen_handle is not None:
			self._gen_handle.stop()
			self._gen_handle = None
		self._restore_ik_enabled()
		self._clear_runtime()
		self.status = "Cancelled"
		self._emit_self_changed()
		self._notify_generate_done(False, "cancelled")

	def _restore_ik_enabled(self) -> None:
		if self._saved_ik_enabled is None:
			return
		if self._robot_ik is not None:
			self._robot_ik.enabled = bool(self._saved_ik_enabled)
		self._saved_ik_enabled = None

	def _clear_runtime(self) -> None:
		self._port_positions = []
		self._source_meta = []
		self._pending_waypoints = []
		self._target_path = None
		self._source_path = None
		self._robot_ik = None
		self._ik_target_ent = None
		self._robot_ent = None
		self._phase = "approach"

	def _emit_self_changed(self) -> None:
		if self.entity is not None and self.entity.scene is not None:
			try:
				self.entity.scene.events.entity_changed.emit(self.entity.id)
			except Exception:
				pass

	def _finish_success(self, message: str) -> None:
		self._gen_handle = None
		self._restore_ik_enabled()
		self._clear_runtime()
		self.status = message
		self._emit_self_changed()
		self._notify_generate_done(True, message)

	def _finish_fail(self, message: str) -> None:
		self._gen_handle = None
		self._restore_ik_enabled()
		self._clear_runtime()
		self.status = message
		self._emit_self_changed()
		self._notify_generate_done(False, message)

	# ------------------------------------------------------------------ loop

	def _current_sample_poses(self) -> Optional[Tuple[QVector3D, QVector3D, QQuaternion, str, int]]:
		"""Return (approach_pos, port_pos, R, seg_name, n_ports) or None if done."""
		while self._seg_idx < len(self._port_positions):
			ports = self._port_positions[self._seg_idx]
			if self._port_idx < len(ports):
				break
			self._seg_idx += 1
			self._port_idx = 0
			self._sample_idx = 0
			self._phase = "approach"
		else:
			return None

		ports = self._port_positions[self._seg_idx]
		port_pos = ports[self._port_idx]
		n_samples = max(1, int(self.samples_per_port))
		meta = self._source_meta[self._seg_idx] if self._seg_idx < len(self._source_meta) else {}
		seg_name = str(meta.get("name", "") or "") or f"Segment {self._seg_idx + 1}"

		r = _cone_sample_rotation(
			self._r0, self._sample_idx, n_samples, float(self.cone_tilt_deg)
		)
		tcp_z = _qvec_norm(r.rotatedVector(QVector3D(0.0, 0.0, 1.0)))
		height = max(0.0, float(self.approach_height_mm))
		approach_pos = port_pos - tcp_z * height
		return approach_pos, port_pos, r, seg_name, len(ports)

	def _generate_loop(self, _delta_time: float) -> bool:
		target = self._target_path
		robot_ik = self._robot_ik
		ik_target_ent = self._ik_target_ent
		robot_ent = self._robot_ent
		if (
			target is None
			or robot_ik is None
			or ik_target_ent is None
			or robot_ent is None
		):
			self._finish_fail("internal state lost")
			return False

		poses = self._current_sample_poses()
		if poses is None:
			return self._commit_and_finish()

		approach_pos, port_pos, r, seg_name, n_ports = poses
		n_samples = max(1, int(self.samples_per_port))
		phase = self._phase
		pose_pos = approach_pos if phase == "approach" else port_pos

		self.status = (
			f'Segment "{seg_name}": port {self._port_idx + 1}/{n_ports}, '
			f"sample {self._sample_idx + 1}/{n_samples}, {phase}"
		)
		if self._sample_idx == 0 and phase == "approach":
			self._emit_self_changed()

		ok = self._pose_ik_target_and_check(ik_target_ent, robot_ik, robot_ent, pose_pos, r)
		Debug.draw_axes(
			pose_pos,
			length=25.0,
			screen_space=True,
			rotation=r,
			width=3.0,
			x_color=(1, 0.3, 0.3),
			y_color=(0.3, 1, 0.3),
			z_color=(0.3, 0.6, 1),
		)

		if phase == "approach":
			if not ok:
				return self._advance_after_sample_failure(seg_name)
			self._phase = "port"
			return True

		# phase == "port"
		if not ok:
			return self._advance_after_sample_failure(seg_name)

		self._append_port_waypoints(approach_pos, port_pos, r)
		self._accepted_count += 1
		self._port_idx += 1
		self._sample_idx = 0
		self._phase = "approach"
		return True

	def _advance_after_sample_failure(self, seg_name: str) -> bool:
		n_samples = max(1, int(self.samples_per_port))
		self._sample_idx += 1
		self._phase = "approach"
		if self._sample_idx >= n_samples:
			skip_label = f"{seg_name} port {self._port_idx + 1}"
			self._skipped.append(skip_label)
			Debug.warning(f"GPLeakPathGenerator: skipped {skip_label} (no valid sample).")
			self._port_idx += 1
			self._sample_idx = 0
		return True

	def _pose_ik_target_and_check(
		self,
		ik_target_ent: "Entity",
		robot_ik: RobotIKComponent,
		robot_ent: "Entity",
		world_pos: QVector3D,
		world_rot: QQuaternion,
	) -> bool:
		"""Move IK target, solve sync, check live collision. True if reachable + clear."""
		scene = robot_ent.scene
		if scene is None:
			return False
		system = getattr(scene, "robot_ik_system", None)
		if system is None:
			return False

		set_world_position(ik_target_ent, world_pos)
		set_world_rotation_quat(ik_target_ent, world_rot)

		result = system.solve_sync(robot_ik)
		if result is None or not result.joint_values:
			return False
		# Prefer converged solutions; still reject if only a failed apply.
		if not bool(getattr(result, "success", False)):
			return False

		try:
			scene.collision_system.check_all()
		except Exception as exc:
			Debug.warning(f"GPLeakPathGenerator: collision check failed ({exc}).")
			return False
		return not entity_is_colliding(robot_ent)

	def _append_port_waypoints(
		self,
		approach_pos: QVector3D,
		port_pos: QVector3D,
		r: QQuaternion,
	) -> None:
		target = self._target_path
		if target is None or target.entity is None:
			return
		tent = target.entity
		wps = self._pending_waypoints[self._seg_idx]
		wps.append(_world_to_local_waypoint(tent, approach_pos, r))
		wps.append(_world_to_local_waypoint(tent, port_pos, r))
		wps.append(_world_to_local_waypoint(tent, approach_pos, r))

	def _commit_and_finish(self) -> bool:
		target = self._target_path
		if target is None:
			self._finish_fail("target path missing at commit")
			return False

		new_segments: List[CustomFeature] = []
		for i, wps in enumerate(self._pending_waypoints):
			meta = self._source_meta[i] if i < len(self._source_meta) else {}
			feat = CustomFeature()
			feat.name = str(meta.get("name", "") or "")
			feat.speed_multiplier = float(meta.get("speed_multiplier", 1.0))
			feat.cnt_radius = float(meta.get("cnt_radius", 0.0))
			feat.waypoints = [Waypoint.from_dict(wp.to_dict()) for wp in wps]
			new_segments.append(feat)

		target.force_setattr("segments", new_segments)

		scene = target.entity.scene if target.entity is not None else None
		if scene is not None and target.entity is not None:
			try:
				scene.events.entity_changed.emit(target.entity.id)
			except Exception:
				pass

		skip_n = len(self._skipped)
		msg = (
			f"Done: {self._accepted_count} port(s) accepted, {skip_n} skipped, "
			f"{len(new_segments)} segment(s) written."
		)
		if self._skipped:
			msg += "\nSkipped: " + ", ".join(self._skipped)
		Debug.log(f"GPLeakPathGenerator: {msg}")
		self._finish_success(msg)
		return False

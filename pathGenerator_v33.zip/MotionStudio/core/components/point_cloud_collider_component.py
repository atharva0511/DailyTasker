from __future__ import annotations

from typing import Annotated, Literal

from MotionStudio.core.collision.octomap_from_points import (
	MAX_CELL_LIMIT,
	MAX_OCCUPIED_CELLS,
	MAX_VIS_CELLS,
)
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import (
	Group,
	Hidden,
	Order,
	Range,
	ReadOnly,
	Tooltip,
	inspector_button,
)


@register_component
class PointCloudColliderComponent(Component):
	"""
	Registers a PointCloud entity with the scene collision system.

	Occupancy voxels are built from the sibling ``PointCloudComponent``.
	``collider_type`` selects cube-soup BVH (follows Transform) or a world-baked
	FCL OcTree. Pair enabling is controlled in the Physics window.
	"""

	type_name = "PointCloudCollider"
	category = "Collision"
	description = (
		"<p><b>Point Cloud Collider</b></p>"
		"<p>Builds an occupancy collider from this entity's <b>PointCloud</b> "
		"so it can overlap mesh colliders. Pair enabling is controlled in "
		"<b>Window &rarr; Physics</b>.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Attach this to an entity that already has a <b>PointCloud</b> component. "
		"Do not also attach a mesh <b>Collider</b> on the same entity.</li>"
		"<li><b>collider_type</b>: <b>cubes</b> is a triangle voxel mesh that follows "
		"Transform. <b>octomap</b> is a world-baked FCL OcTree (axis-aligned; rebuilds "
		"when the cloud or world pose changes). Octomap speed is an FCL feature; the "
		"VTK Physics backend falls back to cubes.</li>"
		"<li><b>resolution_mm</b> is the occupied voxel size in millimetres "
		"(finer = more voxels, slower).</li>"
		"<li><b>max_occupied_cells</b> caps unique occupied voxels used for collision "
		"(cubes and octomap leaves). Status shows <code>truncated</code> when the cap hits.</li>"
		"<li><b>max_vis_cells</b> caps the selected cyan wireframe only; it does not "
		"change FCL geometry.</li>"
		"<li><b>render_collider</b> draws the voxel wireframe while this entity is selected.</li>"
		"<li><b>repaint_on_collision</b> tints the point cloud red while overlapping; "
		"the runtime <code>collided</code> flag still updates either way.</li>"
		"<li>Enable a <b>collision group</b> to treat this collider as one row in the Physics matrix.</li>"
		"</ul>"
	)

	collider_type: Annotated[
		Literal["cubes", "octomap"],
		Order(-10),
		Tooltip(
			"cubes: triangle voxel mesh, follows Transform. "
			"octomap: world-baked FCL OcTree, faster queries."
		),
	] = "cubes"
	resolution_mm: Annotated[
		float,
		Order(0),
		Range(1.0, 200.0, step=1.0, decimals=1),
		Tooltip("Occupied voxel size in millimetres. Smaller values produce more voxels."),
	] = 10.0
	max_occupied_cells: Annotated[
		int,
		Order(1),
		Range(1000, MAX_CELL_LIMIT, step=1000),
		Tooltip(
			"Maximum unique occupied voxels for collision (cubes and octomap leaves). "
			"Status shows truncated when this cap is hit."
		),
	] = MAX_OCCUPIED_CELLS
	max_vis_cells: Annotated[
		int,
		Order(2),
		Range(1000, MAX_CELL_LIMIT, step=1000),
		Tooltip(
			"Maximum cubes in the selected wireframe overlay. Independent of FCL occupancy."
		),
	] = MAX_VIS_CELLS
	render_collider: Annotated[
		bool,
		Group("Collider Settings"),
		Tooltip("Render the occupancy voxel wireframe in the 3D view when this entity is selected."),
	] = True
	repaint_on_collision: Annotated[
		bool,
		Tooltip(
			"Renderer-only hint: when true, the point cloud is tinted red while colliding. "
			"Does not affect the runtime collided flag."
		),
		Group("Collider Settings"),
		Order(0),
	] = True
	use_collision_group: Annotated[
		bool,
		Group("Collision Group"),
		Tooltip(
			"When enabled, this collider is managed as part of a named group in the Physics window "
			"(one global row for the group; per-member pairs in the group sub-matrix)."
		),
	] = False
	collision_group_name: Annotated[
		str,
		Group("Collision Group"),
		Tooltip(
			"Shared group key for global and internal collision matrix toggles. "
			"Required when Use Collision Group is enabled."
		),
	] = ""
	status: Annotated[
		str,
		Order(80),
		ReadOnly(),
		Tooltip("Occupancy build result (voxel count, missing cloud, or errors)."),
	] = "Needs PointCloud"
	collided: Annotated[
		bool,
		Tooltip(
			"Runtime flag set by the CollisionSystem while the entity is intersecting "
			"another collider. Always reflects real state, independent of repaint_on_collision."
		),
		Hidden(),
	] = False

	def __init__(
		self,
		resolution_mm: float = 10.0,
		render_collider: bool = True,
		repaint_on_collision: bool = True,
		use_collision_group: bool = False,
		collision_group_name: str = "",
		collider_type: str = "cubes",
		max_occupied_cells: int = MAX_OCCUPIED_CELLS,
		max_vis_cells: int = MAX_VIS_CELLS,
	) -> None:
		try:
			res = float(resolution_mm)
		except Exception:
			res = 10.0
		self.resolution_mm = res if res > 0.0 else 10.0
		kind = str(collider_type or "cubes").strip().lower()
		self.collider_type = kind if kind in ("cubes", "octomap") else "cubes"
		self.max_occupied_cells = self._clamp_positive_int(
			max_occupied_cells, MAX_OCCUPIED_CELLS
		)
		self.max_vis_cells = self._clamp_positive_int(max_vis_cells, MAX_VIS_CELLS)
		self.render_collider = bool(render_collider)
		self.repaint_on_collision = bool(repaint_on_collision)
		self.use_collision_group = bool(use_collision_group)
		self.collision_group_name = str(collision_group_name or "")
		self.status = "Needs PointCloud"
		self.collided = False

	@staticmethod
	def _clamp_positive_int(value: object, default: int) -> int:
		try:
			n = int(value)  # type: ignore[arg-type]
		except Exception:
			n = int(default)
		return n if n > 0 else int(default)

	def occupancy_cell_limit(self) -> int:
		return self._clamp_positive_int(
			getattr(self, "max_occupied_cells", MAX_OCCUPIED_CELLS),
			MAX_OCCUPIED_CELLS,
		)

	def vis_cell_limit(self) -> int:
		return self._clamp_positive_int(
			getattr(self, "max_vis_cells", MAX_VIS_CELLS),
			MAX_VIS_CELLS,
		)

	def is_octomap_mode(self) -> bool:
		return str(getattr(self, "collider_type", "cubes") or "cubes").strip().lower() == "octomap"

	def set_status_quiet(self, text: str) -> None:
		"""Update Inspector status. Emits ``entity_changed`` only when the text changes."""
		value = str(text or "")
		try:
			if str(object.__getattribute__(self, "status")) == value:
				return
		except Exception:
			pass
		self.force_setattr("status", value)

	@inspector_button(
		"Rebuild Octomap",
		tooltip="Rebuild occupancy voxels from the sibling PointCloud and refresh collision.",
		order=90,
	)
	def rebuild_octomap(self):
		ent = self.entity
		if ent is None or ent.scene is None:
			return False, "no entity in a scene"
		cs = ent.scene.collision_system
		cs.invalidate_entity_cache(ent.id)
		cs._get_geometry(ent)
		cs.request_collision_update(ent.id)
		return True

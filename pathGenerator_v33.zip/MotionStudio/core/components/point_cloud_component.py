from __future__ import annotations

from typing import Annotated

from PyQt6.QtGui import QColor

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Range, Tooltip


@register_component
class PointCloudComponent(Component):
	"""
	Renders a dense 3D point cloud (``.ply`` / ``.pcd``) in the viewport.

	Geometry follows the owning entity's world transform. Points can be
	selected in Vertex Mode for VertexPick and path tools. Does not
	participate in Edge Mode or Face Mode. Attach ``PointCloudCollider``
	to include the cloud in scene collision.
	"""

	type_name = "PointCloud"
	category = "Rendering"
	description = (
		"<p><b>Point Cloud</b></p>"
		"<p>Renders a dense <code>.ply</code> or <code>.pcd</code> cloud in the viewport. "
		"Points follow this entity's Transform. Cloud points can be picked in Vertex Mode "
		"(Inspector VertexPick fields and path tools). Add PointCloudCollider to "
		"participate in scene collision.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Set <b>file_path</b> (or use Hierarchy &rarr; Import Point Cloud). External files are copied into <code>models/</code>.</li>"
		"<li>Default <b>scale</b> is 1000 (metres &rarr; millimetres). Use 1 if the file is already in mm.</li>"
		"<li>Enable <b>use_vertex_colors</b> when the file has per-point RGB; otherwise the uniform <b>color</b> is used.</li>"
		"<li>Adjust <b>point_size</b> and <b>opacity</b> for readability. Compressed PCD (<code>binary_compressed</code>) is not supported.</li>"
		"<li>With the cloud entity selected, press <b>2</b> (Vertex Mode) or use a component's <b>Pick</b> button to capture points.</li>"
		"<li>Add <b>PointCloudCollider</b> (Add Component → Collision) to collide this cloud with mesh colliders via occupancy voxels.</li>"
		"</ul>"
	)

	file_path: Annotated[
		str,
		FilePath(
			"Point Clouds (*.ply *.pcd);;All Files (*.*)",
			dialog_title="Select Point Cloud",
		),
		Tooltip(
			"Project-relative point-cloud path; external files are copied into "
			"the project's models/ folder. Supported: .ply, .pcd (ASCII or uncompressed binary)."
		),
	] = ""
	color: Annotated[
		QColor,
		ColorField(),
		Tooltip("Uniform point color when vertex colors are unavailable or disabled."),
	]
	use_vertex_colors: Annotated[
		bool,
		Tooltip("When true and the file has RGB, render per-point colors instead of Color."),
	] = True
	point_size: Annotated[
		float,
		Range(1.0, 20.0, step=0.5, decimals=1),
		Tooltip("Point size in screen pixels."),
	] = 2.0
	opacity: Annotated[
		float,
		Range(0.0, 1.0, step=0.05, decimals=2),
		Tooltip("Actor opacity (0 = invisible, 1 = opaque)."),
	] = 1.0
	scale: Annotated[
		float,
		Range(0.001, 10000.0, step=1.0, decimals=3),
		Tooltip(
			"Uniform multiplier applied to XYZ at load. Default 1000 converts "
			"metre-scale clouds to engine millimetres; use 1 if the file is already in mm."
		),
	] = 1.0

	def __init__(
		self,
		file_path: str = "",
		color: QColor | None = None,
		use_vertex_colors: bool = True,
		point_size: float = 2.0,
		opacity: float = 1.0,
		scale: float = 1.0,
	) -> None:
		self.file_path = str(file_path or "")
		self.color = color or QColor(200, 200, 200)
		self.use_vertex_colors = bool(use_vertex_colors)
		try:
			self.point_size = float(point_size)
		except Exception:
			self.point_size = 2.0
		try:
			op = float(opacity)
		except Exception:
			op = 1.0
		self.opacity = max(0.0, min(1.0, op))
		try:
			sc = float(scale)
		except Exception:
			sc = 1000.0
		self.scale = sc if sc > 0.0 else 1000.0

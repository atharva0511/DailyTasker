from __future__ import annotations

from typing import Any, Dict, Iterator, List, Literal, Optional, Set, Tuple, TYPE_CHECKING

import numpy as np  # type: ignore
import pyvista as pv  # type: ignore
import vtk  # type: ignore

from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QMatrix4x4, QVector3D

from MotionStudio.core.collision.octomap_from_points import (
	build_occupancy,
	file_stat_fingerprint,
	polydata_from_triangles,
	transform_points_affine,
	vis_polydata_from_cells,
)
from MotionStudio.core.collision.participants import (
	collision_component,
	entity_is_collision_participant,
)
from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.point_cloud_collider_component import (
	PointCloudColliderComponent,
)
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.matrix import qmatrix_from_prs
from MotionStudio.core.robot.collision_groups import collider_group_name, partition_colliders
from MotionStudio.core.scene.collision_backends import (
	CollisionBackendId,
	CollisionGeom,
	make_collision_backend,
	normalize_backend_id,
)
from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read
from MotionStudio.utils.point_cloud_io import PointCloudLoadError, load_point_cloud

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def _canonical_pair(a: str, b: str) -> Tuple[str, str]:
	"""Return a canonical ordered pair so (a, b) and (b, a) map to the same key."""
	return (a, b) if a <= b else (b, a)


GlobalMatrixEntry = Tuple[Literal["group"], str] | Tuple[Literal["entity"], str]


def _global_key(entry: GlobalMatrixEntry) -> str:
	kind, value = entry
	return f"{kind}:{value}"


def _parse_global_key(key: str) -> Optional[GlobalMatrixEntry]:
	if key.startswith("group:"):
		name = key[6:]
		return ("group", name) if name else None
	if key.startswith("entity:"):
		eid = key[7:]
		return ("entity", eid) if eid else None
	return None


def _canonical_global_pair(a: GlobalMatrixEntry, b: GlobalMatrixEntry) -> Tuple[str, str]:
	ka, kb = _global_key(a), _global_key(b)
	return (ka, kb) if ka <= kb else (kb, ka)


class CollisionMatrix:
	"""
	Symmetric pair-enable matrix keyed by canonical (min_id, max_id) tuples.

	Default behavior: every pair is enabled. Only disabled pairs are stored so the
	matrix footprint stays compact even as scenes grow.
	"""

	def __init__(self) -> None:
		self._disabled: Set[Tuple[str, str]] = set()
		self._group_disabled: Dict[str, Set[Tuple[str, str]]] = {}
		self._global_disabled: Set[Tuple[str, str]] = set()

	def is_enabled(self, a: str, b: str) -> bool:
		if a == b:
			return False
		return _canonical_pair(a, b) not in self._disabled

	def set_enabled(self, a: str, b: str, enabled: bool) -> None:
		if a == b:
			return
		key = _canonical_pair(a, b)
		if enabled:
			self._disabled.discard(key)
		else:
			self._disabled.add(key)

	def is_internal_enabled(self, group_name: str, a: str, b: str) -> bool:
		if a == b:
			return False
		bucket = self._group_disabled.get(group_name)
		if not bucket:
			return True
		return _canonical_pair(a, b) not in bucket

	def set_internal_enabled(self, group_name: str, a: str, b: str, enabled: bool) -> None:
		if a == b or not group_name:
			return
		key = _canonical_pair(a, b)
		bucket = self._group_disabled.setdefault(group_name, set())
		if enabled:
			bucket.discard(key)
			if not bucket:
				self._group_disabled.pop(group_name, None)
		else:
			bucket.add(key)

	def has_group_internal_entries(self, group_name: str) -> bool:
		bucket = self._group_disabled.get(group_name)
		return bool(bucket)

	def is_global_enabled(self, a: GlobalMatrixEntry, b: GlobalMatrixEntry) -> bool:
		if a == b:
			return False
		return _canonical_global_pair(a, b) not in self._global_disabled

	def is_ungrouped_pair_enabled(self, ent_a_id: str, ent_b_id: str) -> bool:
		"""Ungrouped↔ungrouped pairs (Physics global matrix entity rows/columns)."""
		if ent_a_id == ent_b_id:
			return False
		return self.is_global_enabled(("entity", ent_a_id), ("entity", ent_b_id))

	def set_global_enabled(self, a: GlobalMatrixEntry, b: GlobalMatrixEntry, enabled: bool) -> None:
		if a == b:
			return
		key = _canonical_global_pair(a, b)
		if enabled:
			self._global_disabled.discard(key)
		else:
			self._global_disabled.add(key)
		# Physics UI toggles entity↔entity via global keys; keep legacy ``disabled`` in sync.
		if a[0] == "entity" and b[0] == "entity":
			self.set_enabled(a[1], b[1], enabled)

	def remove_entity(self, entity_id: str) -> None:
		"""Purge any stored pair that involves the given entity id."""
		self._disabled = {
			(a, b) for (a, b) in self._disabled if a != entity_id and b != entity_id
		}
		for group_name in list(self._group_disabled.keys()):
			bucket = self._group_disabled[group_name]
			bucket = {(a, b) for (a, b) in bucket if a != entity_id and b != entity_id}
			if bucket:
				self._group_disabled[group_name] = bucket
			else:
				self._group_disabled.pop(group_name, None)
		entity_key = f"entity:{entity_id}"
		self._global_disabled = {
			(ka, kb)
			for (ka, kb) in self._global_disabled
			if ka != entity_key and kb != entity_key
		}

	def prune_orphan_groups(self, registered_group_names: Set[str]) -> None:
		"""Drop group/internal and global entries for groups with no active colliders."""
		for name in list(self._group_disabled.keys()):
			if name not in registered_group_names:
				self._group_disabled.pop(name, None)
		prefix = "group:"
		self._global_disabled = {
			(ka, kb)
			for (ka, kb) in self._global_disabled
			if not (
				(ka.startswith(prefix) and ka[len(prefix) :] not in registered_group_names)
				or (kb.startswith(prefix) and kb[len(prefix) :] not in registered_group_names)
			)
		}

	def clear(self) -> None:
		self._disabled.clear()
		self._group_disabled.clear()
		self._global_disabled.clear()

	def to_dict(self) -> Dict[str, Any]:
		group_payload: Dict[str, List[List[str]]] = {}
		for name in sorted(self._group_disabled.keys()):
			bucket = self._group_disabled[name]
			group_payload[name] = [[a, b] for (a, b) in sorted(bucket)]
		return {
			"disabled": [[a, b] for (a, b) in sorted(self._disabled)],
			"group_disabled": group_payload,
			"global_disabled": [[ka, kb] for (ka, kb) in sorted(self._global_disabled)],
		}

	def from_dict(self, data: Dict[str, Any]) -> None:
		self._disabled.clear()
		self._group_disabled.clear()
		self._global_disabled.clear()
		if not isinstance(data, dict):
			return
		for pair in data.get("disabled", []) or []:
			try:
				a, b = str(pair[0]), str(pair[1])
			except Exception:
				continue
			if a and b and a != b:
				self._disabled.add(_canonical_pair(a, b))
				self._global_disabled.add(
					_canonical_global_pair(("entity", a), ("entity", b))
				)
		group_data = data.get("group_disabled", {})
		if isinstance(group_data, dict):
			for group_name, pairs in group_data.items():
				gname = str(group_name)
				if not gname:
					continue
				bucket: Set[Tuple[str, str]] = set()
				for pair in pairs or []:
					try:
						a, b = str(pair[0]), str(pair[1])
					except Exception:
						continue
					if a and b and a != b:
						bucket.add(_canonical_pair(a, b))
				if bucket:
					self._group_disabled[gname] = bucket
		for pair in data.get("global_disabled", []) or []:
			try:
				ka, kb = str(pair[0]), str(pair[1])
			except Exception:
				continue
			if ka and kb and ka != kb:
				self._global_disabled.add((ka, kb) if ka <= kb else (kb, ka))
				parsed_a = _parse_global_key(ka)
				parsed_b = _parse_global_key(kb)
				if (
					parsed_a is not None
					and parsed_b is not None
					and parsed_a[0] == "entity"
					and parsed_b[0] == "entity"
				):
					self._disabled.add(_canonical_pair(parsed_a[1], parsed_b[1]))


class CollisionSystem:
	"""
	Scene-wide collision manager.

	Maintains an incremental index of entities that own a ``ColliderComponent``
	or ``PointCloudColliderComponent`` (updated on add / remove / component
	change) and performs matrix-gated pair checks over that set. Always updates
	the participant's ``collided`` flag to reflect the entity's current
	collision state and emits ``scene.events.entity_collision_changed`` whenever
	the flag flips. ``repaint_on_collision`` is a renderer-only hint: it does
	not affect when the flag is updated or when the signal fires.

	- Play mode: call :meth:`check_all` each tick from ``PlayModeManager``.
	- Edit mode: ``entity_transform_changed`` calls
	  :meth:`request_collision_update`, which coalesces any number of requests
	  into one scene-wide :meth:`check_all` per event-loop tick.
	- ``entity_changed`` on a collider only drops polydata / backend BVH caches
	  when collision *geometry* changed (mesh path/shape, collider source path,
	  from-mesh flag, collider scale, PointCloud path/scale/mtime, octomap
	  resolution / collider_type, and world pose in octomap mode). Path,
	  Inspector, and color edits reuse the cached trees and only resweep.
	"""

	def __init__(self, scene: "Scene") -> None:
		self._scene = scene
		self.matrix = CollisionMatrix()
		# Cached collision geometry per entity (keyed by a cheap state hash).
		self._geom_cache: Dict[str, Tuple[Any, CollisionGeom]] = {}
		# Maintained set of entities that currently own a collision participant
		# (Collider or PointCloudCollider). Updated on add / remove / component
		# change so check_all and partition_colliders never scan the full scene.
		self._colliders_by_id: Dict[str, "Entity"] = {}
		self._backend_id: CollisionBackendId = "fcl"
		self._backend = make_collision_backend(self._backend_id)
		self._in_sweep: bool = False
		# Coalesce collision recalc requests into one scene-wide check_all per tick.
		self._collision_recalc_requested: bool = False
		self._collision_debounce = QTimer()
		self._collision_debounce.setSingleShot(True)
		self._collision_debounce.timeout.connect(self._flush_collision_recalc_request)
		# When > 0, request_collision_update records intent but does not start the
		# debounce timer (used by live planning checks that call check_all themselves).
		self._defer_suspend_depth: int = 0
		# Active only during check_all / check_entities (matrix-aware pair gating).
		self._sweep_groups: Optional[Dict[str, List["Entity"]]] = None
		self._sweep_ungrouped: Optional[List["Entity"]] = None
		self._sweep_entity_by_id: Dict[str, "Entity"] = {}

		events = scene.events
		events.entity_added.connect(self._on_entity_added)
		events.entity_removed.connect(self._on_entity_removed)
		events.entity_transform_changed.connect(self._on_entity_transform_changed)
		events.entity_changed.connect(self._on_entity_changed)
		# Catch entities that already exist (e.g. tests that attach the system late).
		self._rebuild_collider_index()

	# ------------------------------------------------------------------ public API

	@property
	def backend_id(self) -> CollisionBackendId:
		return self._backend_id

	def set_backend_id(self, backend_id: CollisionBackendId) -> None:
		normalized = normalize_backend_id(backend_id)
		if normalized == self._backend_id:
			return
		self._backend.clear()
		self._backend_id = normalized
		self._backend = make_collision_backend(normalized)
		for ent in self.collider_entities():
			self.invalidate_entity_cache(ent.id)
		self.request_collision_update()

	def collider_entities(self) -> List["Entity"]:
		"""Return entities that currently have a collision participant.

		Backed by an incremental index (see :meth:`_sync_collider_index_for_entity`);
		does not scan ``Scene.entities()``.
		"""
		return list(self._colliders_by_id.values())

	def _rebuild_collider_index(self) -> None:
		"""Full resync from the scene map (startup / recovery only)."""
		self._colliders_by_id.clear()
		for ent in self._scene.entities():
			if entity_is_collision_participant(ent):
				self._colliders_by_id[ent.id] = ent

	def _sync_collider_index_for_entity(self, entity: "Entity") -> bool:
		"""Add or remove ``entity`` from the collider index.

		Returns True when membership changed.
		"""
		eid = entity.id
		has_collider = entity_is_collision_participant(entity)
		was_indexed = eid in self._colliders_by_id
		if has_collider:
			self._colliders_by_id[eid] = entity
			return not was_indexed
		if was_indexed:
			self._colliders_by_id.pop(eid, None)
			return True
		return False

	@staticmethod
	def _pair_enabled(
		ent_a: "Entity",
		ent_b: "Entity",
		groups: Dict[str, List["Entity"]],
		ungrouped: List["Entity"],
		matrix: CollisionMatrix,
	) -> bool:
		"""Return whether collision should be tested between two collider entities."""
		if ent_a.id == ent_b.id:
			return False
		col_a = collision_component(ent_a)
		col_b = collision_component(ent_b)
		if col_a is None or col_b is None:
			return False
		gname_a = collider_group_name(col_a)
		gname_b = collider_group_name(col_b)
		if gname_a and gname_b:
			if gname_a == gname_b:
				return matrix.is_internal_enabled(gname_a, ent_a.id, ent_b.id)
			entry_a: GlobalMatrixEntry = ("group", gname_a)
			entry_b: GlobalMatrixEntry = ("group", gname_b)
			return matrix.is_global_enabled(entry_a, entry_b)
		if gname_a and not gname_b:
			return matrix.is_global_enabled(("group", gname_a), ("entity", ent_b.id))
		if gname_b and not gname_a:
			return matrix.is_global_enabled(("group", gname_b), ("entity", ent_a.id))
		return matrix.is_ungrouped_pair_enabled(ent_a.id, ent_b.id)

	@staticmethod
	def iter_matrix_enabled_pairs(
		groups: Dict[str, List["Entity"]],
		ungrouped: List["Entity"],
		matrix: CollisionMatrix,
	) -> Iterator[Tuple["Entity", "Entity"]]:
		"""
		Yield collider entity pairs that the Physics matrix allows to be tested.

		Same scheduling as :meth:`check_all` (internal, ungrouped, group↔entity,
		group↔group). Narrow-phase backends must only run on pairs from this set.
		"""
		for group_name, members in groups.items():
			n = len(members)
			for i in range(n):
				ent_a = members[i]
				for j in range(i + 1, n):
					ent_b = members[j]
					if matrix.is_internal_enabled(group_name, ent_a.id, ent_b.id):
						yield ent_a, ent_b

		n_u = len(ungrouped)
		for i in range(n_u):
			ent_a = ungrouped[i]
			for j in range(i + 1, n_u):
				ent_b = ungrouped[j]
				if matrix.is_ungrouped_pair_enabled(ent_a.id, ent_b.id):
					yield ent_a, ent_b

		group_entry: GlobalMatrixEntry
		entity_entry: GlobalMatrixEntry
		for group_name, members in groups.items():
			group_entry = ("group", group_name)
			for ent_u in ungrouped:
				entity_entry = ("entity", ent_u.id)
				if not matrix.is_global_enabled(group_entry, entity_entry):
					continue
				for ent_g in members:
					yield ent_g, ent_u

		group_names = sorted(groups.keys())
		for gi in range(len(group_names)):
			gname_a = group_names[gi]
			entry_a: GlobalMatrixEntry = ("group", gname_a)
			for gj in range(gi + 1, len(group_names)):
				gname_b = group_names[gj]
				entry_b: GlobalMatrixEntry = ("group", gname_b)
				if not matrix.is_global_enabled(entry_a, entry_b):
					continue
				for ent_a in groups[gname_a]:
					for ent_b in groups[gname_b]:
						yield ent_a, ent_b

	def _begin_collision_sweep(
		self,
		entities: List["Entity"],
		groups: Dict[str, List["Entity"]],
		ungrouped: List["Entity"],
	) -> None:
		"""Install matrix pair filter on the active backend for this sweep."""
		self._sweep_groups = groups
		self._sweep_ungrouped = ungrouped
		self._sweep_entity_by_id = {ent.id: ent for ent in entities}

		def pair_enabled_by_id(ent_a_id: str, ent_b_id: str) -> bool:
			ent_a = self._sweep_entity_by_id.get(ent_a_id)
			ent_b = self._sweep_entity_by_id.get(ent_b_id)
			if ent_a is None or ent_b is None:
				return False
			return self._pair_enabled(ent_a, ent_b, groups, ungrouped, self.matrix)

		set_filter = getattr(self._backend, "set_pair_enabled_filter", None)
		if callable(set_filter):
			set_filter(pair_enabled_by_id)

	def _end_collision_sweep(self) -> None:
		self._sweep_groups = None
		self._sweep_ungrouped = None
		self._sweep_entity_by_id.clear()
		set_filter = getattr(self._backend, "set_pair_enabled_filter", None)
		if callable(set_filter):
			set_filter(None)

	def _entity_collides(
		self,
		ent: "Entity",
		entities: List["Entity"],
		groups: Dict[str, List["Entity"]],
		ungrouped: List["Entity"],
	) -> bool:
		for other in entities:
			if other.id == ent.id:
				continue
			if not self._pair_enabled(ent, other, groups, ungrouped, self.matrix):
				continue
			if self._pair_collides(ent, other):
				return True
		return False

	def check_entities(self, entity_ids: List[str]) -> None:
		"""Re-check collision only for the given entities and their enabled partners."""
		if self._in_sweep or not entity_ids:
			return
		entities = self.collider_entities()
		if len(entities) < 2:
			for e in entities:
				self._set_entity_collided(e, False)
			return

		groups, ungrouped = partition_colliders(entities)
		id_set = {eid for eid in entity_ids if eid}
		to_refresh: Set[str] = set()
		for ent in entities:
			if ent.id in id_set:
				to_refresh.add(ent.id)
				continue
			for moved_id in id_set:
				moved = self._scene.find_by_id(moved_id)
				if moved is None:
					continue
				if self._pair_enabled(moved, ent, groups, ungrouped, self.matrix):
					to_refresh.add(ent.id)
					break

		if not to_refresh:
			return

		self._in_sweep = True
		self._begin_collision_sweep(entities, groups, ungrouped)
		try:
			for eid in to_refresh:
				ent = self._scene.find_by_id(eid)
				if ent is None or collision_component(ent) is None:
					continue
				self._set_entity_collided(
					ent, self._entity_collides(ent, entities, groups, ungrouped)
				)
		finally:
			self._end_collision_sweep()
			self._in_sweep = False

	def check_all(self) -> None:
		"""Run every enabled pair check (group-aware) and update collision state."""
		if self._in_sweep:
			return
		self._in_sweep = True
		try:
			entities = self.collider_entities()
			if len(entities) < 2:
				for e in entities:
					self._set_entity_collided(e, False)
				return

			is_colliding: Dict[str, bool] = {e.id: False for e in entities}
			groups, ungrouped = partition_colliders(entities)
			self._begin_collision_sweep(entities, groups, ungrouped)
			try:
				for ent_a, ent_b in self.iter_matrix_enabled_pairs(
					groups, ungrouped, self.matrix
				):
					if is_colliding[ent_a.id] and is_colliding[ent_b.id]:
						continue
					if self._pair_collides(ent_a, ent_b):
						is_colliding[ent_a.id] = True
						is_colliding[ent_b.id] = True

				for ent in entities:
					self._set_entity_collided(ent, is_colliding[ent.id])
			finally:
				self._end_collision_sweep()
		finally:
			self._in_sweep = False

	def suspend_deferred_updates(self) -> None:
		"""Suppress debounce-timer starts from :meth:`request_collision_update`.

		Nestable. Callers that apply many transforms and then invoke
		:meth:`check_all` themselves (e.g. live motion-planning validity) must
		pair this with :meth:`resume_deferred_updates` so a 0ms QTimer does not
		re-enter collision while the caller is still on the stack.
		"""
		self._defer_suspend_depth = int(self._defer_suspend_depth) + 1

	def resume_deferred_updates(self, *, discard_pending: bool = False) -> None:
		"""Undo one :meth:`suspend_deferred_updates` level.

		If ``discard_pending`` is True, clear any coalesced request that arrived
		while suspended (caller already ran ``check_all``). Otherwise the next
		resume that reaches depth 0 will schedule a normal coalesced sweep.
		"""
		self._defer_suspend_depth = max(0, int(self._defer_suspend_depth) - 1)
		if discard_pending:
			self._collision_recalc_requested = False
			try:
				self._collision_debounce.stop()
			except Exception:
				pass
			return
		if self._defer_suspend_depth == 0 and self._collision_recalc_requested:
			self._collision_debounce.start(0)

	def request_collision_update(self, entity_id: Optional[str] = None) -> None:
		"""Request a scene-wide collision recalculation.

		Any number of callers (transform changes, FK, etc.) may request an update;
		all requests in the same event-loop tick are coalesced into a single
		:meth:`check_all` run. ``entity_id`` is accepted for API symmetry but is
		not used for partial sweeps — the full scene matrix is always refreshed.
		"""
		_ = entity_id  # reserved; scene-wide sweep is intentional
		self._collision_recalc_requested = True
		if int(self._defer_suspend_depth) > 0:
			return
		self._collision_debounce.start(0)

	def check_entity(self, entity_id: str) -> None:
		"""Request a coalesced scene-wide collision update (see :meth:`request_collision_update`)."""
		self.request_collision_update(entity_id)

	def _flush_collision_recalc_request(self) -> None:
		if not self._collision_recalc_requested:
			return
		self._collision_recalc_requested = False
		self.check_all()
		# Requests that arrived during check_all are honoured on the next tick.
		if self._collision_recalc_requested:
			self._collision_debounce.start(0)

	def invalidate_entity_cache(self, entity_id: str) -> None:
		self._geom_cache.pop(entity_id, None)
		self._backend.invalidate_entity(entity_id)

	# -------------------------------------------------------- collision helpers

	def _set_entity_collided(self, entity: "Entity", collided: bool) -> None:
		collider = collision_component(entity)
		if collider is None:
			return
		# Always reflect the actual collision state on the flag, regardless of
		# ``repaint_on_collision``. Custom components can poll the flag (or
		# listen to ``entity_collision_changed``) even when visual recoloring
		# is disabled. The renderer separately consults ``repaint_on_collision``
		# to decide whether to apply the red overlay.
		new_value = bool(collided)
		if bool(getattr(collider, "collided", False)) == new_value:
			return
		# Bypass the Component __setattr__ auto-emit of entity_changed (which
		# would trigger a full mesh rebuild) and emit the lightweight
		# entity_collision_changed signal instead.
		try:
			object.__setattr__(collider, "collided", new_value)
		except Exception:
			collider.collided = new_value
		try:
			self._scene.events.entity_collision_changed.emit(entity.id)
		except Exception:
			pass

	def _pair_collides(self, ent_a: "Entity", ent_b: "Entity") -> bool:
		if self._sweep_groups is not None and self._sweep_ungrouped is not None:
			if not self._pair_enabled(
				ent_a, ent_b, self._sweep_groups, self._sweep_ungrouped, self.matrix
			):
				return False
		geom_a = self._get_geometry(ent_a)
		geom_b = self._get_geometry(ent_b)
		if geom_a is None or geom_b is None:
			return False
		identity = QMatrix4x4()
		xform_a = identity if geom_a.pose_mode == "identity" else self._world_transform(ent_a)
		xform_b = identity if geom_b.pose_mode == "identity" else self._world_transform(ent_b)
		# Quick AABB reject against world-space bounds to skip the expensive
		# VTK / FCL narrow-phase when the boxes don't overlap.
		if not self._geom_bounds_overlap(geom_a, xform_a, geom_b, xform_b):
			return False
		return self._backend.pair_intersects(
			ent_a.id,
			ent_b.id,
			geom_a,
			xform_a,
			geom_b,
			xform_b,
		)

	# -------------------------------------------------------- mesh / transforms

	def _collision_geometry_state_key(self, entity: "Entity") -> Optional[Tuple[Any, ...]]:
		"""Fingerprint of fields that affect collision source geometry / BVH / OcTree.

		Cube-mode PointCloudCollider omits pose (live ``fcl.Transform``).
		Octomap mode includes world pose so a gizmo move rebuilds the tree.
		Color, path waypoints, and other Inspector fields are not included.
		"""
		pcc = entity.get_component(PointCloudColliderComponent)
		if pcc is not None:
			cloud = entity.get_component(PointCloudComponent)
			file_path = str(getattr(cloud, "file_path", "") or "") if cloud is not None else ""
			try:
				cloud_scale = float(getattr(cloud, "scale", 1.0) or 1.0) if cloud is not None else 1.0
			except Exception:
				cloud_scale = 1.0
			try:
				resolution = float(getattr(pcc, "resolution_mm", 10.0) or 10.0)
			except Exception:
				resolution = 10.0
			max_cells = pcc.occupancy_cell_limit()
			mtime_ns, size = 0, 0
			if file_path.strip():
				root = entity.scene.project_root if entity.scene else None
				abs_path = resolve_mesh_path_for_read(root, file_path)
				mtime_ns, size = file_stat_fingerprint(abs_path)
			kind = "octomap" if pcc.is_octomap_mode() else "cubes"
			key: Tuple[Any, ...] = (
				"point_cloud_octomap",
				kind,
				file_path,
				cloud_scale,
				resolution,
				max_cells,
				int(mtime_ns),
				int(size),
			)
			if kind == "octomap":
				key = key + (self._world_pose_fingerprint(entity),)
			return key

		collider = entity.get_component(ColliderComponent)
		if collider is None:
			return None
		mesh = entity.get_component(MeshComponent)
		use_mesh_component = bool(getattr(collider, "collider_from_mesh_component", True))
		collider_scale = 1.0
		if not use_mesh_component:
			try:
				collider_scale = float(getattr(collider, "scale", 1.0) or 1.0)
			except Exception:
				collider_scale = 1.0
		return (
			"use_mesh_component",
			use_mesh_component,
			"collider_scale",
			collider_scale,
			"mesh_shape",
			getattr(mesh, "shape", None) if mesh is not None else None,
			"mesh_path",
			getattr(mesh, "custom_path", "") if mesh is not None else "",
			"collider_path",
			str(getattr(collider, "collider_mesh_path", "") or ""),
		)

	def _world_pose_fingerprint(self, entity: "Entity") -> Tuple[float, ...]:
		m = self._world_transform(entity)
		return tuple(round(float(m[r, c]), 5) for r in range(3) for c in range(4))

	@staticmethod
	def _qmatrix_to_numpy(m: QMatrix4x4) -> np.ndarray:
		out = np.eye(4, dtype=np.float64)
		for r in range(4):
			for c in range(4):
				out[r, c] = float(m[r, c])
		return out

	def _collision_geometry_changed(self, entity: "Entity") -> bool:
		"""True when a cached geometry fingerprint exists and no longer matches."""
		state_key = self._collision_geometry_state_key(entity)
		if state_key is None:
			return True
		cached = self._geom_cache.get(entity.id)
		if cached is None:
			return False
		return cached[0] != state_key

	def _get_polydata(self, entity: "Entity") -> Optional[vtk.vtkPolyData]:
		geom = self._get_geometry(entity)
		return None if geom is None else geom.poly

	def _get_geometry(self, entity: "Entity") -> Optional[CollisionGeom]:
		state_key = self._collision_geometry_state_key(entity)
		if state_key is None:
			return None
		cached = self._geom_cache.get(entity.id)
		if cached is not None and cached[0] == state_key:
			return cached[1]

		if state_key and state_key[0] == "point_cloud_octomap":
			return self._build_point_cloud_geometry(entity, state_key)

		use_mesh_component = bool(state_key[1])
		mesh = entity.get_component(MeshComponent)
		collider = entity.get_component(ColliderComponent)
		if collider is None:
			return None

		pv_mesh: Optional[pv.DataSet] = None
		try:
			if use_mesh_component:
				if mesh is None:
					pv_mesh = None
				elif mesh.shape == "cube":
					pv_mesh = pv.Cube(center=(0.0, 0.0, 0.0), x_length=1.0, y_length=1.0, z_length=1.0)
				elif mesh.shape == "sphere":
					pv_mesh = pv.Sphere(radius=0.5, center=(0.0, 0.0, 0.0))
				elif mesh.shape == "custom":
					if mesh.custom_path:
						root = entity.scene.project_root if entity.scene else None
						abs_path = resolve_mesh_path_for_read(root, mesh.custom_path)
						pv_mesh = self._normalize_dataset_for_collision(pv.read(abs_path) if abs_path else None)
			else:
				collider_path = str(getattr(collider, "collider_mesh_path", "") or "").strip()
				if collider_path:
					root = entity.scene.project_root if entity.scene else None
					abs_path = resolve_mesh_path_for_read(root, collider_path)
					pv_mesh = self._normalize_dataset_for_collision(pv.read(abs_path) if abs_path else None)
					pv_mesh = self._apply_collider_scale(pv_mesh, collider)
		except Exception:
			pv_mesh = None

		if pv_mesh is None:
			self._geom_cache.pop(entity.id, None)
			return None

		try:
			surface = pv_mesh.extract_surface()
			poly = surface.GetOutput() if hasattr(surface, "GetOutput") else surface
		except Exception:
			return None

		if poly is None:
			return None
		try:
			bounds = tuple(float(v) for v in poly.GetBounds())
		except Exception:
			bounds = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
		geom = CollisionGeom(kind="mesh", poly=poly, bounds=bounds, pose_mode="entity")
		self._geom_cache[entity.id] = (state_key, geom)
		return geom

	def _build_point_cloud_geometry(
		self,
		entity: "Entity",
		state_key: Tuple[Any, ...],
	) -> Optional[CollisionGeom]:
		pcc = entity.get_component(PointCloudColliderComponent)
		cloud = entity.get_component(PointCloudComponent)
		if pcc is None:
			self._geom_cache.pop(entity.id, None)
			return None
		if cloud is None:
			pcc.set_status_quiet("Needs PointCloud")
			self._geom_cache.pop(entity.id, None)
			return None
		file_path = str(getattr(cloud, "file_path", "") or "").strip()
		if not file_path:
			pcc.set_status_quiet("Needs PointCloud")
			self._geom_cache.pop(entity.id, None)
			return None
		root = entity.scene.project_root if entity.scene else None
		abs_path = resolve_mesh_path_for_read(root, file_path)
		if not abs_path:
			pcc.set_status_quiet("Cloud file not found")
			self._geom_cache.pop(entity.id, None)
			return None
		try:
			points, _colors = load_point_cloud(abs_path)
		except PointCloudLoadError as exc:
			pcc.set_status_quiet(f"Load failed: {exc}")
			self._geom_cache.pop(entity.id, None)
			return None
		except Exception as exc:
			pcc.set_status_quiet(f"Load failed: {exc}")
			self._geom_cache.pop(entity.id, None)
			return None
		try:
			scale = float(getattr(cloud, "scale", 1.0) or 1.0)
		except Exception:
			scale = 1.0
		if scale <= 0.0:
			scale = 1.0
		if abs(scale - 1.0) > 1e-12:
			points = np.asarray(points, dtype=np.float64) * float(scale)
		else:
			points = np.asarray(points, dtype=np.float64)
		try:
			resolution = float(getattr(pcc, "resolution_mm", 10.0) or 10.0)
		except Exception:
			resolution = 10.0
		max_cells = pcc.occupancy_cell_limit()
		max_vis = pcc.vis_cell_limit()
		mode = "octomap" if pcc.is_octomap_mode() else "cubes"
		if mode == "octomap":
			points = transform_points_affine(points, self._qmatrix_to_numpy(self._world_transform(entity)))
		need_mesh = mode == "cubes" or self._backend_id == "vtk"
		try:
			result = build_occupancy(
				points,
				resolution,
				mode=mode,
				max_cells=max_cells,
				build_cube_mesh=need_mesh,
			)
		except Exception as exc:
			pcc.set_status_quiet(f"Octomap failed: {exc}")
			self._geom_cache.pop(entity.id, None)
			return None
		if result.voxel_count <= 0:
			self._geom_cache.pop(entity.id, None)
			pcc.set_status_quiet(result.status)
			return None
		poly = None
		if need_mesh:
			poly = polydata_from_triangles(result.vertices, result.triangles)
			if poly is None and mode == "cubes":
				self._geom_cache.pop(entity.id, None)
				pcc.set_status_quiet(result.status)
				return None
		vis_poly = vis_polydata_from_cells(
			result.cells, result.resolution_mm, max_cells=max_vis
		)
		if mode == "octomap":
			if not result.octree_binary:
				self._geom_cache.pop(entity.id, None)
				pcc.set_status_quiet(result.status)
				return None
			geom = CollisionGeom(
				kind="octree",
				poly=poly,
				bounds=result.bounds,
				pose_mode="identity",
				octree_binary=result.octree_binary,
				resolution_mm=result.resolution_mm,
				cells=result.cells,
				vis_poly=vis_poly,
			)
		else:
			if poly is None:
				self._geom_cache.pop(entity.id, None)
				pcc.set_status_quiet(result.status)
				return None
			try:
				bounds = result.bounds if any(result.bounds) else tuple(float(v) for v in poly.GetBounds())
			except Exception:
				bounds = result.bounds
			geom = CollisionGeom(
				kind="mesh",
				poly=poly,
				bounds=bounds,
				pose_mode="entity",
				resolution_mm=result.resolution_mm,
				cells=result.cells,
				vis_poly=vis_poly,
			)
		self._geom_cache[entity.id] = (state_key, geom)
		pcc.set_status_quiet(result.status)
		return geom

	def _normalize_dataset_for_collision(self, dataset) -> Optional[pv.DataSet]:
		"""Flatten MultiBlock inputs into one dataset for surface extraction."""
		if dataset is None:
			return None
		try:
			if isinstance(dataset, pv.MultiBlock):
				blocks = self._collect_leaf_blocks(dataset)
				if not blocks:
					return None
				merged: Optional[pv.DataSet] = None
				for block in blocks:
					try:
						surface = block.extract_surface()
					except Exception:
						surface = block
					try:
						surface = surface.triangulate()
					except Exception:
						pass
					if merged is None:
						merged = surface
					else:
						merged = merged.merge(surface)
				return merged
		except Exception:
			return None
		return dataset

	def _apply_collider_scale(self, dataset: Optional[pv.DataSet], collider: ColliderComponent) -> Optional[pv.DataSet]:
		"""Apply collider-local uniform scaling to source geometry."""
		if dataset is None:
			return None
		try:
			scale = float(getattr(collider, "scale", 1.0) or 1.0)
		except Exception:
			scale = 1.0
		if scale <= 0.0:
			scale = 1.0
		if abs(scale - 1.0) < 1e-12:
			return dataset
		try:
			return dataset.scale([scale, scale, scale], inplace=False)
		except Exception:
			return dataset

	def _collect_leaf_blocks(self, dataset) -> List[pv.DataSet]:
		"""Collect all non-MultiBlock leaf datasets in traversal order."""
		leaves: List[pv.DataSet] = []
		try:
			if isinstance(dataset, pv.MultiBlock):
				for block in dataset:
					leaves.extend(self._collect_leaf_blocks(block))
			elif dataset is not None:
				leaves.append(dataset)
		except Exception:
			pass
		return leaves

	def _world_transform(self, entity: "Entity") -> QMatrix4x4:
		stack: List[QMatrix4x4] = []
		curr = entity
		while curr is not None:
			t = curr.get_component(TransformComponent)
			if t is None:
				stack.append(QMatrix4x4())
			else:
				stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
			curr = curr.parent
		world = QMatrix4x4()
		for m in reversed(stack):
			world = world * m
		return world

	@staticmethod
	def _aabb_to_world(
		bounds: Tuple[float, float, float, float, float, float],
		xform: QMatrix4x4,
	) -> Tuple[float, float, float, float, float, float]:
		xmin, xmax, ymin, ymax, zmin, zmax = bounds
		corners = (
			(xmin, ymin, zmin), (xmin, ymin, zmax),
			(xmin, ymax, zmin), (xmin, ymax, zmax),
			(xmax, ymin, zmin), (xmax, ymin, zmax),
			(xmax, ymax, zmin), (xmax, ymax, zmax),
		)
		xs: List[float] = []
		ys: List[float] = []
		zs: List[float] = []
		for cx, cy, cz in corners:
			mapped = xform.map(QVector3D(float(cx), float(cy), float(cz)))
			xs.append(mapped.x())
			ys.append(mapped.y())
			zs.append(mapped.z())
		return (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))

	@staticmethod
	def _world_bounds(
		poly: vtk.vtkPolyData, xform: QMatrix4x4
	) -> Tuple[float, float, float, float, float, float]:
		xmin, xmax, ymin, ymax, zmin, zmax = poly.GetBounds()
		return CollisionSystem._aabb_to_world(
			(float(xmin), float(xmax), float(ymin), float(ymax), float(zmin), float(zmax)),
			xform,
		)

	@staticmethod
	def _geom_world_aabb(
		geom: CollisionGeom, xform: QMatrix4x4
	) -> Tuple[float, float, float, float, float, float]:
		if geom.pose_mode == "identity":
			return geom.bounds
		return CollisionSystem._aabb_to_world(geom.bounds, xform)

	@staticmethod
	def _geom_bounds_overlap(
		geom_a: CollisionGeom, xform_a: QMatrix4x4,
		geom_b: CollisionGeom, xform_b: QMatrix4x4,
	) -> bool:
		try:
			ba = CollisionSystem._geom_world_aabb(geom_a, xform_a)
			bb = CollisionSystem._geom_world_aabb(geom_b, xform_b)
		except Exception:
			return True
		return not (
			ba[1] < bb[0] or ba[0] > bb[1] or
			ba[3] < bb[2] or ba[2] > bb[3] or
			ba[5] < bb[4] or ba[4] > bb[5]
		)

	@staticmethod
	def _bounds_overlap(
		poly_a: vtk.vtkPolyData, xform_a: QMatrix4x4,
		poly_b: vtk.vtkPolyData, xform_b: QMatrix4x4,
	) -> bool:
		try:
			ba = CollisionSystem._world_bounds(poly_a, xform_a)
			bb = CollisionSystem._world_bounds(poly_b, xform_b)
		except Exception:
			return True
		return not (
			ba[1] < bb[0] or ba[0] > bb[1] or
			ba[3] < bb[2] or ba[2] > bb[3] or
			ba[5] < bb[4] or ba[4] > bb[5]
		)

	# --------------------------------------------------------------- scene events

	def _on_entity_removed(self, entity_id: str) -> None:
		self._colliders_by_id.pop(entity_id, None)
		self._geom_cache.pop(entity_id, None)
		self._backend.invalidate_entity(entity_id)
		self.matrix.remove_entity(entity_id)
		# Another entity may have lost its sole collision partner; re-sweep.
		self.check_all()

	def _on_entity_transform_changed(self, entity_id: str) -> None:
		# Cube / mesh colliders keep cached geometry and only resweep.
		# Octomap mode bakes world pose into the tree — fingerprint mismatch
		# drops the cache so the occupancy rebuilds at the new pose.
		# Walk descendants: moving a parent changes a child's world pose
		# without emitting transform_changed on the child itself.
		ent = self._scene.find_by_id(entity_id)
		if ent is not None:
			stack = [ent]
			guard = 0
			while stack and guard < 4096:
				guard += 1
				cur = stack.pop()
				if cur.id in self._colliders_by_id and self._collision_geometry_changed(cur):
					self.invalidate_entity_cache(cur.id)
				stack.extend(cur.children)
		self.request_collision_update(entity_id)

	def _on_entity_added(self, entity: "Entity") -> None:
		# Index immediately when the entity already carries a collider (preset
		# paste). Most colliders arrive later via add_component → entity_changed.
		self._sync_collider_index_for_entity(entity)
		if entity.id in self._colliders_by_id:
			self.request_collision_update(entity.id)

	def _on_entity_changed(self, entity_id: str) -> None:
		ent = self._scene.find_by_id(entity_id)
		membership_changed = False
		if ent is not None:
			membership_changed = self._sync_collider_index_for_entity(ent)
		elif entity_id in self._colliders_by_id:
			self._colliders_by_id.pop(entity_id, None)
			membership_changed = True

		is_collider = ent is not None and ent.id in self._colliders_by_id
		if not membership_changed and not is_collider:
			# Rename / unrelated component edit on a non-collider entity.
			return

		# Drop polydata / FCL-BVH caches only when collision source geometry
		# actually changed. Path waypoints, Inspector fields, and mesh color
		# still emit entity_changed but must not rebuild high-poly trees.
		geometry_changed = membership_changed
		if is_collider and ent is not None and not membership_changed:
			geometry_changed = self._collision_geometry_changed(ent)
		if geometry_changed:
			self._geom_cache.pop(entity_id, None)
			self._backend.invalidate_entity(entity_id)
		# Adding/removing a collider or changing collision geometry does not emit
		# entity_transform_changed, so schedule a debounced scene-wide sweep here.
		# Non-geometry edits (path, color) reuse cached trees — same as a gizmo drag.
		self.request_collision_update(entity_id)

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Literal, Optional, Protocol, Tuple

import numpy as np
import vtk  # type: ignore
from PyQt6.QtGui import QMatrix4x4

CollisionBackendId = Literal["vtk", "fcl"]


@dataclass
class CollisionGeom:
	"""Narrow-phase handle: triangle mesh (BVH / VTK) or world-baked FCL OcTree."""

	kind: Literal["mesh", "octree"]
	poly: Optional[vtk.vtkPolyData]  # mesh/cubes; VTK fallback for octomap
	bounds: Tuple[float, float, float, float, float, float]
	octree: Any = None
	pose_mode: Literal["entity", "identity"] = "entity"
	octree_binary: bytes = b""
	resolution_mm: float = 10.0
	cells: Optional[np.ndarray] = None
	vis_poly: Optional[vtk.vtkPolyData] = None


def _canonical_pair(a: str, b: str) -> Tuple[str, str]:
	return (a, b) if a <= b else (b, a)


def polydata_to_triangles(poly: vtk.vtkPolyData) -> Tuple[np.ndarray, np.ndarray]:
	"""Extract triangle soup from VTK polydata for FCL BVHModel."""
	tri_filter = vtk.vtkTriangleFilter()
	tri_filter.SetInputData(poly)
	tri_filter.Update()
	out = tri_filter.GetOutput()
	if out is None:
		return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 3), dtype=np.int32)

	pts = out.GetPoints()
	if pts is None or pts.GetNumberOfPoints() == 0:
		return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 3), dtype=np.int32)

	n_pts = int(pts.GetNumberOfPoints())
	vertices = np.zeros((n_pts, 3), dtype=np.float64)
	for i in range(n_pts):
		vertices[i, 0], vertices[i, 1], vertices[i, 2] = pts.GetPoint(i)

	cells = out.GetPolys()
	if cells is None or cells.GetNumberOfCells() == 0:
		return vertices, np.zeros((0, 3), dtype=np.int32)

	id_list = vtk.vtkIdList()
	faces: list[list[int]] = []
	cells.InitTraversal()
	while cells.GetNextCell(id_list):
		n = id_list.GetNumberOfIds()
		if n == 3:
			faces.append(
				[
					int(id_list.GetId(0)),
					int(id_list.GetId(1)),
					int(id_list.GetId(2)),
				]
			)
		elif n > 3:
			# Fan triangulation for quads/ngons
			p0 = int(id_list.GetId(0))
			for k in range(1, n - 1):
				faces.append([p0, int(id_list.GetId(k)), int(id_list.GetId(k + 1))])

	if not faces:
		return vertices, np.zeros((0, 3), dtype=np.int32)
	return vertices, np.array(faces, dtype=np.int32)


def decompose_affine_matrix(
	T: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
	"""
	Split a 4x4 affine matrix into rotation, translation, and per-axis scale.

	FCL collision objects are rigid (rotation + translation only). VTK applies the
	full 4x4 matrix including scale; we bake scale into BVH vertices instead.
	Pure numpy — safe on planner worker threads (no QMatrix4x4).
	"""
	m = np.asarray(T, dtype=np.float64)
	linear = m[:3, :3].copy()
	translation = m[:3, 3].copy()

	rotation = np.zeros((3, 3), dtype=np.float64)
	scale = np.ones(3, dtype=np.float64)
	for c in range(3):
		col = linear[:, c]
		length = float(np.linalg.norm(col))
		scale[c] = length
		if length > 1e-12:
			rotation[:, c] = col / length
		elif c == 0:
			rotation[:, 0] = (1.0, 0.0, 0.0)
		elif c == 1:
			rotation[:, 1] = (0.0, 1.0, 0.0)
		else:
			rotation[:, 2] = (0.0, 0.0, 1.0)

	# Negative scale flips column direction; keep rotation proper.
	if np.linalg.det(rotation) < 0.0:
		rotation[:, 2] *= -1.0

	return rotation, translation, scale


def decompose_qmatrix_affine(
	m: QMatrix4x4,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
	"""Qt wrapper around :func:`decompose_affine_matrix` for live CollisionSystem."""
	linear = np.zeros((4, 4), dtype=np.float64)
	for r in range(4):
		for c in range(4):
			linear[r, c] = float(m[r, c])
	return decompose_affine_matrix(linear)


def qmatrix_to_fcl_transform(m: QMatrix4x4):
	"""Rigid FCL transform (scale must be baked into mesh geometry)."""
	import fcl

	rotation, translation, _scale = decompose_qmatrix_affine(m)
	return fcl.Transform(rotation, translation)


def _scale_vertices(vertices: np.ndarray, scale: np.ndarray) -> np.ndarray:
	if vertices.size == 0:
		return vertices
	if np.allclose(scale, 1.0):
		return vertices
	return vertices * scale.reshape(1, 3)


PairEnabledFilter = Callable[[str, str], bool]


class CollisionBackend(Protocol):
	def pair_intersects(
		self,
		ent_a_id: str,
		ent_b_id: str,
		geom_a: CollisionGeom,
		xform_a: QMatrix4x4,
		geom_b: CollisionGeom,
		xform_b: QMatrix4x4,
	) -> bool: ...

	def set_pair_enabled_filter(self, predicate: Optional[PairEnabledFilter]) -> None: ...

	def invalidate_entity(self, entity_id: str) -> None: ...

	def clear(self) -> None: ...


class VtkCollisionBackend:
	"""Narrow-phase contact via vtkCollisionDetectionFilter + OBBTree pool."""

	def __init__(self) -> None:
		self._pair_enabled_filter: Optional[PairEnabledFilter] = None
		self._filter_pool: dict[
			Tuple[str, str],
			Tuple[
				vtk.vtkPolyData,
				vtk.vtkPolyData,
				vtk.vtkCollisionDetectionFilter,
				vtk.vtkTransform,
				vtk.vtkTransform,
			],
		] = {}

	def set_pair_enabled_filter(self, predicate: Optional[PairEnabledFilter]) -> None:
		self._pair_enabled_filter = predicate

	def pair_intersects(
		self,
		ent_a_id: str,
		ent_b_id: str,
		geom_a: CollisionGeom,
		xform_a: QMatrix4x4,
		geom_b: CollisionGeom,
		xform_b: QMatrix4x4,
	) -> bool:
		if self._pair_enabled_filter is not None and not self._pair_enabled_filter(
			ent_a_id, ent_b_id
		):
			return False
		poly_a = _vtk_poly_for_geom(geom_a)
		poly_b = _vtk_poly_for_geom(geom_b)
		if poly_a is None or poly_b is None:
			return False
		try:
			flt, tr0, tr1, swapped = self._get_or_create_filter(
				ent_a_id, ent_b_id, poly_a, poly_b
			)
			xform_0 = xform_b if swapped else xform_a
			xform_1 = xform_a if swapped else xform_b
			self._update_vtk_transform(tr0, xform_0)
			self._update_vtk_transform(tr1, xform_1)
			flt.Update()
			return flt.GetNumberOfContacts() > 0
		except Exception:
			return True

	def invalidate_entity(self, entity_id: str) -> None:
		if not self._filter_pool:
			return
		stale = [key for key in self._filter_pool if entity_id in key]
		for key in stale:
			self._filter_pool.pop(key, None)

	def clear(self) -> None:
		self._pair_enabled_filter = None
		self._filter_pool.clear()

	def _get_or_create_filter(
		self,
		ent_a_id: str,
		ent_b_id: str,
		poly_a: vtk.vtkPolyData,
		poly_b: vtk.vtkPolyData,
	) -> Tuple[vtk.vtkCollisionDetectionFilter, vtk.vtkTransform, vtk.vtkTransform, bool]:
		key = _canonical_pair(ent_a_id, ent_b_id)
		swapped = key != (ent_a_id, ent_b_id)
		cached = self._filter_pool.get(key)
		if cached is not None:
			cached_poly_0, cached_poly_1, flt, tr0, tr1 = cached
			expected_0 = poly_b if swapped else poly_a
			expected_1 = poly_a if swapped else poly_b
			if cached_poly_0 is expected_0 and cached_poly_1 is expected_1:
				return flt, tr0, tr1, swapped
			self._filter_pool.pop(key, None)

		flt = vtk.vtkCollisionDetectionFilter()
		flt.SetCollisionModeToFirstContact()
		tr0 = vtk.vtkTransform()
		tr1 = vtk.vtkTransform()
		flt.SetTransform(0, tr0)
		flt.SetTransform(1, tr1)
		poly_0 = poly_b if swapped else poly_a
		poly_1 = poly_a if swapped else poly_b
		flt.SetInputData(0, poly_0)
		flt.SetInputData(1, poly_1)
		self._filter_pool[key] = (poly_0, poly_1, flt, tr0, tr1)
		return flt, tr0, tr1, swapped

	@staticmethod
	def _update_vtk_transform(t: vtk.vtkTransform, m: QMatrix4x4) -> None:
		mtx = vtk.vtkMatrix4x4()
		for r in range(4):
			for c in range(4):
				mtx.SetElement(r, c, float(m[r, c]))
		t.SetMatrix(mtx)


def _vtk_poly_for_geom(geom: CollisionGeom) -> Optional[vtk.vtkPolyData]:
	"""Mesh polydata, or a cube-soup fallback from octomap occupied cells."""
	if geom.poly is not None:
		return geom.poly
	if geom.kind != "octree":
		return None
	cells = geom.cells
	if cells is None:
		return None
	c = np.asarray(cells, dtype=np.int64)
	if c.ndim != 2 or c.shape[0] == 0:
		return None
	from MotionStudio.core.collision.octomap_from_points import (
		cube_mesh_from_occupied_cells,
		polydata_from_triangles,
	)

	verts, tris = cube_mesh_from_occupied_cells(c, geom.resolution_mm)
	poly = polydata_from_triangles(verts, tris)
	if poly is not None:
		geom.poly = poly
	return poly


class FclCollisionBackend:
	"""Narrow-phase contact via python-fcl BVH models and OcTrees."""

	def __init__(self) -> None:
		self._pair_enabled_filter: Optional[PairEnabledFilter] = None
		# entity_id -> (polydata identity, scale tuple, BVHModel)
		self._bvh_cache: dict[str, Tuple[vtk.vtkPolyData, Tuple[float, float, float], Any]] = {}
		# entity_id -> (binary payload, resolution, OcTree)
		self._octree_cache: dict[str, Tuple[bytes, float, Any]] = {}

	def set_pair_enabled_filter(self, predicate: Optional[PairEnabledFilter]) -> None:
		self._pair_enabled_filter = predicate

	def pair_intersects(
		self,
		ent_a_id: str,
		ent_b_id: str,
		geom_a: CollisionGeom,
		xform_a: QMatrix4x4,
		geom_b: CollisionGeom,
		xform_b: QMatrix4x4,
	) -> bool:
		if self._pair_enabled_filter is not None and not self._pair_enabled_filter(
			ent_a_id, ent_b_id
		):
			return False
		obj_a = self._collision_object(ent_a_id, geom_a, xform_a)
		obj_b = self._collision_object(ent_b_id, geom_b, xform_b)
		if obj_a is None or obj_b is None:
			return False
		try:
			import fcl

			request = fcl.CollisionRequest(num_max_contacts=1, enable_contact=False)
			result = fcl.CollisionResult()
			ret = fcl.collide(obj_a, obj_b, request, result)
			return bool(ret) or result.is_collision
		except Exception:
			return False

	def invalidate_entity(self, entity_id: str) -> None:
		self._bvh_cache.pop(entity_id, None)
		self._octree_cache.pop(entity_id, None)

	def clear(self) -> None:
		self._pair_enabled_filter = None
		self._bvh_cache.clear()
		self._octree_cache.clear()

	def _collision_object(
		self,
		entity_id: str,
		geom: CollisionGeom,
		xform: QMatrix4x4,
	):
		import fcl

		if geom.kind == "octree":
			tree = self._get_octree(entity_id, geom)
			if tree is None:
				return None
			return fcl.CollisionObject(tree, fcl.Transform())
		poly = geom.poly
		if poly is None:
			return None
		rot, trans, scale = decompose_qmatrix_affine(xform)
		bvh = self._get_bvh(entity_id, poly, scale)
		if bvh is None:
			return None
		return fcl.CollisionObject(bvh, fcl.Transform(rot, trans))

	def _get_octree(self, entity_id: str, geom: CollisionGeom) -> Any:
		from MotionStudio.core.collision.octomap_from_points import fcl_octree_from_binary

		binary = geom.octree_binary
		res = float(geom.resolution_mm)
		cached = self._octree_cache.get(entity_id)
		if cached is not None and cached[0] is binary and cached[1] == res:
			return cached[2]
		if geom.octree is not None:
			self._octree_cache[entity_id] = (binary, res, geom.octree)
			return geom.octree
		tree = fcl_octree_from_binary(res, binary)
		if tree is None:
			self._octree_cache.pop(entity_id, None)
			return None
		self._octree_cache[entity_id] = (binary, res, tree)
		return tree

	def _get_bvh(
		self,
		entity_id: str,
		poly: vtk.vtkPolyData,
		scale: np.ndarray,
	) -> Any:
		import fcl

		scale_key = (float(scale[0]), float(scale[1]), float(scale[2]))
		cached = self._bvh_cache.get(entity_id)
		if cached is not None and cached[0] is poly and cached[1] == scale_key:
			return cached[2]

		vertices, triangles = polydata_to_triangles(poly)
		if len(vertices) == 0 or len(triangles) == 0:
			self._bvh_cache.pop(entity_id, None)
			return None

		vertices = _scale_vertices(vertices, scale)

		model = fcl.BVHModel()
		model.beginModel(len(triangles), len(vertices))
		model.addSubModel(vertices, triangles)
		model.endModel()
		self._bvh_cache[entity_id] = (poly, scale_key, model)
		return model


def make_collision_backend(backend_id: CollisionBackendId) -> CollisionBackend:
	if backend_id == "fcl":
		return FclCollisionBackend()
	return VtkCollisionBackend()


def normalize_backend_id(value: Any) -> CollisionBackendId:
	if str(value).strip().lower() == "vtk":
		return "vtk"
	return "fcl"

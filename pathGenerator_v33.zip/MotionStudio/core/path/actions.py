"""Digital I/O actions attached to path segments.

An action is one instruction the robot performs *after* it reaches an anchored
waypoint of a segment. The vocabulary follows UR PolyScope so the exported
program reads like what an operator sees on the teach pendant:

- ``Set`` writes a digital **output**. Inputs are driven externally and cannot
  be written, so ``Set`` only ever targets an output bank.
- ``Wait`` either dwells for a fixed time (``wait_time``) or polls a digital
  **input** until it reaches a state, with an optional timeout
  (``wait_signal``).

UR exposes several independent I/O banks, so a bare port number is ambiguous;
every signal action carries a :data:`BANKS` id alongside its port.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

# --------------------------------------------------------------------- kinds

KIND_SET = "set"
KIND_WAIT_TIME = "wait_time"
KIND_WAIT_SIGNAL = "wait_signal"

KIND_LABELS: Dict[str, str] = {
	KIND_SET: "Set Output",
	KIND_WAIT_TIME: "Wait Time",
	KIND_WAIT_SIGNAL: "Wait Signal",
}

# --------------------------------------------------------------------- anchor

AT_FIRST = "first"
AT_LAST = "last"
AT_EVERY = "every"
AT_INDEX = "index"

AT_LABELS: Dict[str, str] = {
	AT_FIRST: "First waypoint",
	AT_LAST: "Last waypoint",
	AT_EVERY: "Every waypoint",
	AT_INDEX: "Waypoint N",
}

# ---------------------------------------------------------------------- banks


@dataclass(frozen=True)
class BankSpec:
	"""One UR digital I/O bank."""

	id: str
	label: str
	is_output: bool
	min_port: int
	max_port: int
	getter: str
	setter: str = ""


BANKS: Dict[str, BankSpec] = {
	"standard_out": BankSpec(
		"standard_out", "Standard Out", True, 0, 7,
		"get_standard_digital_out", "set_standard_digital_out",
	),
	"configurable_out": BankSpec(
		"configurable_out", "Configurable Out", True, 0, 7,
		"get_configurable_digital_out", "set_configurable_digital_out",
	),
	"tool_out": BankSpec(
		"tool_out", "Tool Out", True, 0, 1,
		"get_tool_digital_out", "set_tool_digital_out",
	),
	"standard_in": BankSpec(
		"standard_in", "Standard In", False, 0, 7, "get_standard_digital_in",
	),
	"configurable_in": BankSpec(
		"configurable_in", "Configurable In", False, 0, 7, "get_configurable_digital_in",
	),
	"tool_in": BankSpec("tool_in", "Tool In", False, 0, 1, "get_tool_digital_in"),
}

DEFAULT_OUTPUT_BANK = "standard_out"
DEFAULT_INPUT_BANK = "standard_in"


def output_banks() -> List[BankSpec]:
	return [b for b in BANKS.values() if b.is_output]


def input_banks() -> List[BankSpec]:
	return [b for b in BANKS.values() if not b.is_output]


def banks_for_kind(kind: str) -> List[BankSpec]:
	"""Banks a given action kind may target (``Set`` writes, ``Wait`` reads)."""
	return output_banks() if kind == KIND_SET else input_banks()


def default_bank_for_kind(kind: str) -> str:
	return DEFAULT_OUTPUT_BANK if kind == KIND_SET else DEFAULT_INPUT_BANK


def bank_spec(bank: str) -> BankSpec:
	"""Resolve a bank id, falling back to the standard bank of that direction."""
	spec = BANKS.get(str(bank or ""))
	if spec is not None:
		return spec
	return BANKS[DEFAULT_OUTPUT_BANK]


def clamp_port(bank: str, port: int) -> int:
	spec = bank_spec(bank)
	return max(spec.min_port, min(spec.max_port, int(port)))


# --------------------------------------------------------------------- action


@dataclass
class PathAction:
	"""One Set / Wait instruction anchored to waypoints of a segment."""

	kind: str = KIND_SET
	at: str = AT_LAST
	# Only meaningful when ``at`` is AT_INDEX (0-based).
	at_index: int = 0
	# Signal target for KIND_SET / KIND_WAIT_SIGNAL.
	bank: str = DEFAULT_OUTPUT_BANK
	port: int = 0
	# KIND_SET: state to write. KIND_WAIT_SIGNAL: state to wait for.
	state: bool = True
	# KIND_WAIT_TIME dwell, seconds.
	duration_s: float = 1.0
	# KIND_WAIT_SIGNAL give-up time; 0 waits forever.
	timeout_s: float = 0.0
	enabled: bool = True

	def to_dict(self) -> Dict[str, Any]:
		return {
			"kind": str(self.kind),
			"at": str(self.at),
			"at_index": int(self.at_index),
			"bank": str(self.bank),
			"port": int(self.port),
			"state": bool(self.state),
			"duration_s": float(self.duration_s),
			"timeout_s": float(self.timeout_s),
			"enabled": bool(self.enabled),
		}

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "PathAction":
		"""Rebuild from saved data, tolerating missing or unknown keys."""
		raw = data if isinstance(data, dict) else {}
		kind = str(raw.get("kind", KIND_SET))
		if kind not in KIND_LABELS:
			kind = KIND_SET
		at = str(raw.get("at", AT_LAST))
		if at not in AT_LABELS:
			at = AT_LAST
		bank = str(raw.get("bank", "") or default_bank_for_kind(kind))
		if bank not in BANKS:
			bank = default_bank_for_kind(kind)
		return cls(
			kind=kind,
			at=at,
			at_index=max(0, _as_int(raw.get("at_index"), 0)),
			bank=bank,
			port=clamp_port(bank, _as_int(raw.get("port"), 0)),
			state=bool(raw.get("state", True)),
			duration_s=max(0.0, _as_float(raw.get("duration_s"), 1.0)),
			timeout_s=max(0.0, _as_float(raw.get("timeout_s"), 0.0)),
			enabled=bool(raw.get("enabled", True)),
		)

	def clone(self) -> "PathAction":
		return PathAction.from_dict(self.to_dict())


def _as_int(value: Any, fallback: int) -> int:
	try:
		return int(value)
	except (TypeError, ValueError):
		return fallback


def _as_float(value: Any, fallback: float) -> float:
	try:
		return float(value)
	except (TypeError, ValueError):
		return fallback


# ------------------------------------------------------------------- helpers


def actions_to_data(actions: Optional[List[PathAction]]) -> List[Dict[str, Any]]:
	return [a.to_dict() for a in (actions or []) if isinstance(a, PathAction)]


def actions_from_data(data: Any) -> List[PathAction]:
	if not isinstance(data, list):
		return []
	return [PathAction.from_dict(entry) for entry in data if isinstance(entry, dict)]


def clone_actions(actions: Optional[List[PathAction]]) -> List[PathAction]:
	"""Deep copy, used when seeding a new segment from the program defaults."""
	return [a.clone() for a in (actions or []) if isinstance(a, PathAction)]


def new_action(kind: str) -> PathAction:
	"""A sensible starting point for a freshly added row of the given kind."""
	return PathAction(kind=kind, at=AT_LAST, bank=default_bank_for_kind(kind))


def resolve_waypoint_indices(action: PathAction, waypoint_count: int) -> List[int]:
	"""0-based waypoints this action fires at, given the segment length.

	Anchors that fall outside the segment resolve to nothing, so a stale
	``Waypoint N`` after the segment shrinks is skipped instead of raising.
	"""
	count = int(waypoint_count)
	if count <= 0:
		return []
	if action.at == AT_FIRST:
		return [0]
	if action.at == AT_LAST:
		return [count - 1]
	if action.at == AT_EVERY:
		return list(range(count))
	if action.at == AT_INDEX:
		idx = int(action.at_index)
		return [idx] if 0 <= idx < count else []
	return []


def anchor_text(action: PathAction) -> str:
	if action.at == AT_INDEX:
		return f"Waypoint {int(action.at_index) + 1}"
	return AT_LABELS.get(action.at, action.at)


def signal_text(action: PathAction) -> str:
	spec = bank_spec(action.bank)
	return f"{spec.label}[{int(action.port)}]"


def summary_text(action: PathAction) -> str:
	"""One-line description used for row labels and undo text."""
	at = anchor_text(action)
	if action.kind == KIND_SET:
		level = "High" if action.state else "Low"
		return f"Set {signal_text(action)} = {level} at {at}"
	if action.kind == KIND_WAIT_TIME:
		return f"Wait {float(action.duration_s):g} s at {at}"
	if action.kind == KIND_WAIT_SIGNAL:
		level = "High" if action.state else "Low"
		timeout = (
			f", timeout {float(action.timeout_s):g} s"
			if float(action.timeout_s) > 0.0
			else ""
		)
		return f"Wait {signal_text(action)} == {level}{timeout} at {at}"
	return f"Action at {at}"


def has_enabled_actions(actions: Optional[List[PathAction]]) -> bool:
	return any(a.enabled for a in (actions or []))

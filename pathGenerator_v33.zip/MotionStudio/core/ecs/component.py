from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Callable, ClassVar, Dict, List, Optional, Tuple, Type, TypeVar, TYPE_CHECKING

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity

_C = TypeVar("_C", bound="Component")

# Nested Add Component menu node:
#   {"submenus": {name: node}, "components": [(type_name, cls), ...]}
CategoryMenuNode = Dict[str, Any]

# Simple registry to map component type names to concrete classes
_COMPONENT_REGISTRY: Dict[str, Type["Component"]] = {}

# Type converter registry: maps type -> (serialize_func, deserialize_func)
_TYPE_CONVERTERS: Dict[type, tuple[Callable[[Any], Any], Callable[[Any], Any]]] = {}


def register_type_converter(
	type_class: type,
	serialize: Callable[[Any], Any],
	deserialize: Callable[[Any], Any]
) -> None:
	"""
	Register converters for a type (e.g., QColor, QVector3D).
	
	Args:
		type_class: The type to register converters for
		serialize: Function that converts an instance to a JSON-serializable value
		deserialize: Function that converts a JSON value back to an instance
	"""
	_TYPE_CONVERTERS[type_class] = (serialize, deserialize)


# Register common Qt types
try:
	from PyQt6.QtGui import QColor, QVector3D, QQuaternion
	
	register_type_converter(
		QColor,
		lambda c: [c.red(), c.green(), c.blue(), c.alpha()] if c else None,
		lambda v: QColor(int(v[0]), int(v[1]), int(v[2]), int(v[3]) if len(v) > 3 else 255) if v else None
	)
	
	register_type_converter(
		QVector3D,
		lambda v: [v.x(), v.y(), v.z()] if v else None,
		lambda v: QVector3D(float(v[0]), float(v[1]), float(v[2])) if v and len(v) >= 3 else None
	)
	
	register_type_converter(
		QQuaternion,
		lambda q: [q.scalar(), q.x(), q.y(), q.z()] if q else None,
		lambda v: QQuaternion(float(v[0]), float(v[1]), float(v[2]), float(v[3])) if v and len(v) >= 4 else QQuaternion()
	)
except ImportError:
	pass


def register_component(cls: Type[_C]) -> Type[_C]:
	"""
	Class decorator to register a Component subclass by its type_name.
	"""
	type_name = getattr(cls, "type_name", cls.__name__)
	_COMPONENT_REGISTRY[type_name] = cls
	return cls


def get_component_class(type_name: str) -> Optional[Type["Component"]]:
	return _COMPONENT_REGISTRY.get(type_name)

def get_registered_components() -> Dict[str, Type["Component"]]:
	"""
	Return a shallow copy of the component registry mapping type_name -> class.
	"""
	return dict(_COMPONENT_REGISTRY)


# Display order for Add Component top-level menus; unknown roots sort after these, Others last.
# Matched case-insensitively against the first segment of ``category``.
_CATEGORY_MENU_ORDER = (
	"robot",
	"path generation and planning",
	"Collision",
	"Measure",
	"Rendering",
	"Others",
)


def _split_category_path(category: str) -> Tuple[str, ...]:
	"""Split a category path on ``/`` into trimmed non-empty segments.

	Empty / missing categories become ``("Others",)``.
	``"Hardware/Scanners"`` → ``("Hardware", "Scanners")``.
	"""
	raw = str(category or "").strip()
	if not raw:
		return ("Others",)
	parts = tuple(seg for seg in (p.strip() for p in raw.split("/")) if seg)
	return parts if parts else ("Others",)


def _empty_category_menu_node() -> CategoryMenuNode:
	return {"submenus": {}, "components": []}


def _sort_category_menu_node(node: CategoryMenuNode) -> None:
	"""Sort components and nested submenu keys in-place (case-insensitive)."""
	comps: List[tuple[str, Type["Component"]]] = node.get("components") or []
	comps.sort(key=lambda t: t[0].lower())
	node["components"] = comps
	submenus: Dict[str, CategoryMenuNode] = node.get("submenus") or {}
	for child in submenus.values():
		_sort_category_menu_node(child)
	# Rebuild with alphabetical key order for stable iteration.
	node["submenus"] = {k: submenus[k] for k in sorted(submenus.keys(), key=lambda s: s.lower())}


def _order_top_level_submenus(
	submenus: Dict[str, CategoryMenuNode],
) -> Dict[str, CategoryMenuNode]:
	"""Order top-level category menus: preferred list, then alpha, Others last."""
	by_lower = {name.lower(): name for name in submenus}
	ordered: Dict[str, CategoryMenuNode] = {}
	seen_lower: set[str] = set()
	for preferred in _CATEGORY_MENU_ORDER:
		key = preferred.lower()
		if key == "others":
			continue
		actual = by_lower.get(key)
		if actual is None:
			continue
		ordered[actual] = submenus[actual]
		seen_lower.add(key)
	for name in sorted(
		(n for n in submenus if n.lower() not in seen_lower and n.lower() != "others"),
		key=lambda s: s.lower(),
	):
		ordered[name] = submenus[name]
		seen_lower.add(name.lower())
	others_name = by_lower.get("others")
	if others_name is not None:
		ordered[others_name] = submenus[others_name]
	return ordered


def components_by_category(
	*,
	exclude: Optional[set[str]] = None,
) -> Dict[str, list[tuple[str, Type["Component"]]]]:
	"""Group registered components by full ``category`` string (flat map).

	Returns an ordered dict-like mapping: category -> list of (type_name, cls)
	sorted by type_name. Categories follow ``_CATEGORY_MENU_ORDER``, then any
	custom names alphabetically, with ``Others`` last.

	For nested Add Component menus prefer :func:`components_category_menu_tree`.
	"""
	exclude = exclude or set()
	buckets: Dict[str, list[tuple[str, Type["Component"]]]] = {}
	for type_name, cls in _COMPONENT_REGISTRY.items():
		if type_name in exclude:
			continue
		cat = str(getattr(cls, "category", None) or "Others").strip() or "Others"
		buckets.setdefault(cat, []).append((type_name, cls))
	for entries in buckets.values():
		entries.sort(key=lambda t: t[0].lower())

	# Top-level order for flat keys: match preferred names case-insensitively
	# against the full string (legacy) and also against single-segment paths.
	by_lower = {k.lower(): k for k in buckets}
	ordered: Dict[str, list[tuple[str, Type["Component"]]]] = {}
	seen_lower: set[str] = set()
	for preferred in _CATEGORY_MENU_ORDER:
		key = preferred.lower()
		if key == "others":
			continue
		actual = by_lower.get(key)
		if actual is None:
			continue
		ordered[actual] = buckets[actual]
		seen_lower.add(key)
	for cat in sorted(k for k in buckets if k.lower() not in seen_lower and k.lower() != "others"):
		ordered[cat] = buckets[cat]
		seen_lower.add(cat.lower())
	others_key = by_lower.get("others")
	if others_key is not None and others_key not in ordered:
		ordered[others_key] = buckets[others_key]
	return ordered


def components_category_menu_tree(
	*,
	exclude: Optional[set[str]] = None,
) -> CategoryMenuNode:
	"""Build a nested Add Component menu tree from ``category`` paths.

	``category`` may be a ``/``-separated path (e.g. ``"Hardware/Scanners"``).
	Components are attached to the leaf node. A node may have both leaf
	components and nested submenus.

	Returns a root node::

	    {"submenus": {top_level_name: node, ...}, "components": []}
	"""
	exclude = exclude or set()
	root = _empty_category_menu_node()
	for type_name, cls in _COMPONENT_REGISTRY.items():
		if type_name in exclude:
			continue
		cat = str(getattr(cls, "category", None) or "Others").strip() or "Others"
		path = _split_category_path(cat)
		node = root
		for segment in path:
			subs: Dict[str, CategoryMenuNode] = node["submenus"]
			# Preserve first-seen casing for a given case-insensitive key.
			existing = next((k for k in subs if k.lower() == segment.lower()), None)
			if existing is None:
				subs[segment] = _empty_category_menu_node()
				existing = segment
			node = subs[existing]
		node["components"].append((type_name, cls))

	_sort_category_menu_node(root)
	root["submenus"] = _order_top_level_submenus(root["submenus"])
	root["components"] = []  # components always live under a category path
	return root


class Component:
	"""
	Base Component. Subclasses should expose plain attributes or use dataclasses
	so they can be discovered and edited by the inspector.
	
	All field changes automatically emit entity_changed signals to update rendering.
	"""

	# Optional explicit name used for serialization/registry
	type_name: ClassVar[str] = "Component"
	# "Add Component" menu submenu (e.g. "robot", "Collision", "Others")
	category: ClassVar[str] = "Others"
	# Short user-facing blurb shown as the menu action tooltip
	description: ClassVar[str] = ""
	
	# Reference to the entity that owns this component (set automatically when added to entity)
	_entity: Optional["Entity"] = None
	
	# Track if we're in __init__ to avoid emitting signals during initialization
	_initializing: bool = False

	# Header-only instance flags (not Inspector Annotated fields).
	# ``locked``: public field writes are silently ignored (except these flags).
	# ``collapsed``: Inspector shows only the header toolbar until expanded.
	locked: bool = False
	collapsed: bool = False

	# Temporary bypass for deserialize / undo force-apply
	_lock_bypass: bool = False
	
	@property
	def entity(self) -> Optional["Entity"]:
		"""Returns the entity that owns this component, or None if not attached."""
		return self._entity

	def _is_initializing(self) -> bool:
		try:
			return bool(object.__getattribute__(self, "_initializing"))
		except AttributeError:
			# Attribute missing — treat as still constructing
			return True

	def _writes_allowed(self) -> bool:
		"""False when this component is locked and writes are not bypassed."""
		try:
			if bool(object.__getattribute__(self, "_lock_bypass")):
				return True
		except AttributeError:
			pass
		if self._is_initializing():
			return True
		try:
			return not bool(object.__getattribute__(self, "locked"))
		except AttributeError:
			return True

	def force_setattr(self, name: str, value: Any) -> None:
		"""Set an attribute even when ``locked`` (undo / deserialize)."""
		object.__setattr__(self, "_lock_bypass", True)
		try:
			setattr(self, name, value)
		finally:
			object.__setattr__(self, "_lock_bypass", False)
	
	def __setattr__(self, name: str, value: Any) -> None:
		"""
		Override to automatically emit entity_changed signal when component fields are modified.
		This ensures that any programmatic field change (e.g., in update() methods) updates the VTK actors.
		Similar to Unity's behavior where changing any component property automatically updates rendering.

		When ``locked`` is True, public field writes are silently ignored (except
		``locked`` / ``collapsed`` and private ``_`` names).
		"""
		is_initializing = self._is_initializing()

		# Lock gate: block public writes while locked (unless bypass / init / header toggles).
		if (
			not is_initializing
			and name not in ("locked", "collapsed")
			and not name.startswith("_")
			and not self._writes_allowed()
		):
			return
		
		# Get old value before setting (if attribute exists and we're not initializing)
		old_value = None
		if not is_initializing:
			try:
				old_value = object.__getattribute__(self, name)
			except AttributeError:
				pass
		
		# Set the attribute
		super().__setattr__(name, value)
		
		# Only emit signal for public attributes (not private ones starting with _)
		# Skip during initialization, identity ClassVars, and if value didn't change
		_skip_signal = {"type_name", "category", "description"}
		if not is_initializing and not name.startswith("_") and name not in _skip_signal:
			# Only emit if value actually changed and component is attached to entity
			if old_value != value:
				try:
					entity = object.__getattribute__(self, "_entity")
					if entity and entity.scene:
						entity.scene.events.entity_changed.emit(entity.id)
				except (AttributeError, Exception):
					# Silently ignore errors (e.g., if _entity doesn't exist or scene is being destroyed)
					pass
	
	def __init__(self) -> None:
		"""Initialize component. Marks initialization state to prevent signal emission during setup."""
		# Set _initializing first using object.__setattr__ to avoid recursion
		object.__setattr__(self, "_initializing", True)
		object.__setattr__(self, "locked", False)
		object.__setattr__(self, "collapsed", False)
		object.__setattr__(self, "_lock_bypass", False)

	def start(self) -> None:
		"""
		Called once when Play Mode starts, or immediately when a component
		is added during Play Mode (Unity-like behavior).
		Override this method in subclasses to initialize runtime state.
		"""
		pass

	def update(self, delta_time: float) -> None:
		"""
		Called every frame during Play Mode.
		Override this method in subclasses to implement per-frame behavior.
		
		Args:
			delta_time: Time elapsed since last frame in seconds
		"""
		pass
	
	def on_entity_changed(self) -> None:
		"""
		Called when the entity this component is attached to changes.
		This is invoked whenever entity_changed signal is emitted (e.g., when component
		properties are modified, entity name changes, etc.).
		Override this method in subclasses to react to entity changes.
		"""
		pass

	def on_viewport_draw(self) -> None:
		"""
		Called immediately before each 3D viewport render pass (edit and play modes).
		Override for per-frame visual work such as re-issuing one-frame Debug.draw_* calls.
		"""
		pass

	def start_play_routine(
		self,
		loop_fn: Callable[[float], bool],
		*,
		name: str = "",
	):
		"""Start an edit-mode frame loop (bound method). Returns a ``PlayRoutineHandle``.

		``loop_fn(delta_time) -> bool``: return ``True`` to continue, ``False`` to stop.
		Call ``handle.stop()`` to cancel from elsewhere. Does not snapshot the scene.
		Refused while Play Mode is active (use ``update`` instead).
		"""
		from MotionStudio.core.scene.play_routine import PlayRoutineHandle

		entity = self.entity
		if entity is None or entity.scene is None:
			return PlayRoutineHandle(None, -1)
		return entity.scene.play_routine_runner.start(
			loop_fn, owner=self, name=str(name or "")
		)

	def to_dict(self) -> Dict[str, Any]:
		"""
		Default serializer that uses reflection to discover fields (same as Inspector).
		Automatically handles types registered in _TYPE_CONVERTERS.
		Subclasses may override for custom behavior.
		"""
		if is_dataclass(self):
			return asdict(self)

		# Import here to avoid circular dependency
		from MotionStudio.ui.inspector.reflection import iter_editable_fields
		from MotionStudio.ui.inspector.metadata import Hidden

		data: Dict[str, Any] = {}
		
		# Use the same reflection mechanism as Inspector
		for spec in iter_editable_fields(self):
			# Skip hidden fields
			if any(isinstance(m, Hidden) and m.enabled for m in spec.metadata):
				continue
			
			field_name = spec.name
			field_value = spec.getter()
			
			# Handle None
			if field_value is None:
				data[field_name] = None
				continue
			
			# Check if field value is a Component reference (for component-to-component references)
			# Serialize Component references as entity_id
			if isinstance(field_value, Component):
				# This is a Component reference - serialize as entity_id
				if field_value.entity is not None:
					data[field_name] = field_value.entity.id
				else:
					data[field_name] = None
				continue
			
			# Check if we have a registered converter for this type
			converter_found = False
			for type_class, (serialize_func, _) in _TYPE_CONVERTERS.items():
				if isinstance(field_value, type_class):
					try:
						data[field_name] = serialize_func(field_value)
						converter_found = True
						break
					except Exception:
						pass
			
			# Fallback to primitive handling
			if not converter_found:
				if isinstance(field_value, (str, int, float, bool)):
					data[field_name] = field_value
				elif isinstance(field_value, (list, tuple)):
					if all(isinstance(v, (str, int, float, bool)) or v is None for v in field_value):
						data[field_name] = list(field_value)
				# For other types, skip (component can override to_dict for custom handling)

		# Persist header toggles (not Annotated Inspector fields)
		data["locked"] = bool(getattr(self, "locked", False))
		data["collapsed"] = bool(getattr(self, "collapsed", False))
		
		return data

	@classmethod
	def from_dict(cls: Type[_C], data: Dict[str, Any]) -> _C:
		"""
		Default deserializer that uses reflection to discover fields.
		Automatically handles types registered in _TYPE_CONVERTERS.
		Subclasses may override for custom behavior.
		"""
		# Import here to avoid circular dependency
		from MotionStudio.ui.inspector.reflection import iter_editable_fields
		from MotionStudio.ui.inspector.metadata import Hidden
		import typing
		
		instance = cls()  # type: ignore[call-arg]
		# Ensure fields can be restored even if a subclass left locked=True somehow.
		object.__setattr__(instance, "locked", False)
		object.__setattr__(instance, "collapsed", False)
		
		# Use reflection to discover expected fields
		# Create a temporary instance to get field specs
		temp_instance = cls()  # type: ignore[call-arg]
		field_specs = {spec.name: spec for spec in iter_editable_fields(temp_instance)}
		
		# Restore each field from data
		for field_name, field_value in data.items():
			if field_name in ("locked", "collapsed"):
				# Applied after reflected fields so a locked snapshot does not
				# block restoring the rest of the component.
				continue
			if field_name not in field_specs:
				# Field not in current class definition - skip it (don't set as attribute)
				# This prevents old/renamed field names from appearing in Inspector
				# On next save, only the current fields will be saved
				continue
			
			spec = field_specs[field_name]
			
			# Skip hidden fields (shouldn't be in data, but be safe)
			if any(isinstance(m, Hidden) and m.enabled for m in spec.metadata):
				continue
			
			field_type = spec.typ
			
			# Extract base type from Annotated/Optional/Union
			base_type = field_type
			origin = None
			args = ()
			if hasattr(typing, 'get_origin') and typing.get_origin(field_type) is not None:
				origin = typing.get_origin(field_type)
				args = typing.get_args(field_type)
				
				# Handle Optional (Union[T, None])
				if origin is typing.Union and len(args) == 2 and type(None) in args:
					base_type = args[0] if args[0] is not type(None) else args[1]
				# Handle Union (check if any arg matches a converter)
				elif origin is typing.Union:
					base_type = None  # Will check each arg
				else:
					base_type = origin
			
			# Check if this is a Component reference field (Optional[ComponentType])
			# During loading, we store entity_id temporarily, will resolve after all entities are loaded
			is_component_reference = False
			if origin is typing.Union:
				# Extract inner type (first non-None type)
				inner_type = None
				for arg in args:
					if arg is not type(None):
						inner_type = arg
						break
				
				if inner_type is not None:
					# Check if inner type is a Component subclass
					try:
						if issubclass(inner_type, Component):
							# This is a Component reference field
							# Store entity_id temporarily (will be resolved after all entities are loaded)
							# For now, store as entity_id string - resolution happens in json_io.load_scene()
							setattr(instance, field_name, field_value)  # Store entity_id as-is for now
							is_component_reference = True
					except (TypeError, AttributeError):
						# Not a class type, continue to normal handling
						pass
			
			# Skip converter check and direct assignment if this is a Component reference
			if is_component_reference:
				continue
			
			# Check if we have a registered converter for this type
			converter_found = False
			for type_class, (_, deserialize_func) in _TYPE_CONVERTERS.items():
				# Try to match the type
				type_matches = False
				
				if base_type == type_class:
					type_matches = True
				elif base_type is None and origin is typing.Union:
					# Check if type_class is in the union args
					if type_class in args:
						type_matches = True
				elif hasattr(base_type, '__origin__') and base_type.__origin__ == type_class:
					type_matches = True
				
				if type_matches:
					try:
						deserialized_value = deserialize_func(field_value)
						setattr(instance, field_name, deserialized_value)
						converter_found = True
						break
					except Exception:
						pass
			
			# Fallback to direct assignment for primitives
			if not converter_found:
				try:
					setattr(instance, field_name, field_value)
				except Exception:
					pass

		# Restore header toggles last so field writes above were not blocked.
		try:
			instance.collapsed = bool(data.get("collapsed", False))
		except Exception:
			object.__setattr__(instance, "collapsed", bool(data.get("collapsed", False)))
		try:
			instance.locked = bool(data.get("locked", False))
		except Exception:
			object.__setattr__(instance, "locked", bool(data.get("locked", False)))
		
		return instance



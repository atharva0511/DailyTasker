"""Collision participant lookup (mesh Collider or PointCloudCollider)."""

from __future__ import annotations

from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
	from MotionStudio.core.components.collider_component import ColliderComponent
	from MotionStudio.core.components.point_cloud_collider_component import (
		PointCloudColliderComponent,
	)
	from MotionStudio.core.ecs.entity import Entity

	CollisionParticipant = Union[ColliderComponent, PointCloudColliderComponent]
else:
	CollisionParticipant = Any


def collision_component(entity: Optional["Entity"]) -> Optional[CollisionParticipant]:
	"""Return the collision participant on ``entity``, if any.

	When both ``PointCloudCollider`` and ``Collider`` are present, the
	point-cloud collider wins (one body per entity).
	"""
	if entity is None:
		return None
	# Lazy imports: engine components importing this module must not cycle
	# through ``components/__init__.py``.
	from MotionStudio.core.components.point_cloud_collider_component import (
		PointCloudColliderComponent,
	)
	from MotionStudio.core.components.collider_component import ColliderComponent

	pcc = entity.get_component(PointCloudColliderComponent)
	if pcc is not None:
		return pcc
	return entity.get_component(ColliderComponent)


def entity_is_collision_participant(entity: Optional["Entity"]) -> bool:
	return collision_component(entity) is not None

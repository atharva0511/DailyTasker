"""
Collision query helpers.

Read-only convenience functions over collision participants' ``collided``
flags after the scene's ``CollisionSystem`` has run. They do not start a new
sweep — call ``scene.collision_system.check_all()`` first when you need fresh
flags (play-routine ticks and Play Mode already do this after component loops).
"""

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity


def entity_is_colliding(entity: Optional["Entity"]) -> bool:
	"""
	Return ``True`` if ``entity`` or any descendant is currently colliding.

	Walks the child tree and reads each collision participant's ``collided``
	flag from the last ``CollisionSystem.check_all()``. Entities without a
	collider are skipped; ``None`` returns ``False``.
	"""
	from MotionStudio.core.collision.participants import collision_component

	if entity is None:
		return False

	def walk(node: "Entity") -> bool:
		col = collision_component(node)
		if col is not None and bool(getattr(col, "collided", False)):
			return True
		for child in node.children:
			if walk(child):
				return True
		return False

	return walk(entity)

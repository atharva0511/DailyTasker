"""Occupied-leaf octomap voxelization for PointCloudCollider.

Cube mode: occupancy grid → cube-soup triangles → FCL BVH (follows Transform).
Octomap mode: occupancy grid → OccupancyOcTreeBase binary → python-fcl OcTree
(world-baked, axis-aligned). VTK falls back to the cube soup.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional, Tuple

import numpy as np

# Defaults for Inspector occupancy / vis caps (spinbox max is 1_000_000).
MAX_OCCUPIED_CELLS = 200_000
MAX_VIS_CELLS = 200_000
MAX_CELL_LIMIT = 1_000_000

# OctoMap OcTreeBaseImpl defaults (must match python-fcl's bundled octomap).
_TREE_DEPTH = 16
_TREE_MAX_VAL = 1 << (_TREE_DEPTH - 1)  # 32768

_OCCUPIED = 1
_INNER = 2

# Unit-cube corners in cell-local [0, 1] (min-corner origin).
_CUBE_CORNERS = np.array(
	[
		[0.0, 0.0, 0.0],
		[1.0, 0.0, 0.0],
		[1.0, 1.0, 0.0],
		[0.0, 1.0, 0.0],
		[0.0, 0.0, 1.0],
		[1.0, 0.0, 1.0],
		[1.0, 1.0, 1.0],
		[0.0, 1.0, 1.0],
	],
	dtype=np.float64,
)

# 12 triangles (outward-ish winding). Collision does not require watertight normals.
_CUBE_TRIS = np.array(
	[
		[0, 2, 1],
		[0, 3, 2],  # -Z
		[4, 5, 6],
		[4, 6, 7],  # +Z
		[0, 1, 5],
		[0, 5, 4],  # -Y
		[3, 7, 6],
		[3, 6, 2],  # +Y
		[0, 4, 7],
		[0, 7, 3],  # -X
		[1, 2, 6],
		[1, 6, 5],  # +X
	],
	dtype=np.int32,
)


@dataclass(frozen=True)
class OccupancyBuild:
	"""Occupied cells plus optional cube mesh / octomap binary."""

	cells: np.ndarray  # (K, 3) int64 floor(xyz/res)
	voxel_count: int
	truncated: bool
	status: str
	vertices: np.ndarray = field(default_factory=lambda: np.zeros((0, 3), dtype=np.float64))
	triangles: np.ndarray = field(default_factory=lambda: np.zeros((0, 3), dtype=np.int32))
	octree_binary: bytes = b""
	resolution_mm: float = 10.0
	bounds: Tuple[float, float, float, float, float, float] = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)


# Backward-compatible alias used by CollisionSystem cube path.
OctomapBuildResult = OccupancyBuild


class _OctreeNode:
	"""Inner node: 8 children, each None / occupied-leaf / inner."""

	__slots__ = ("children",)

	def __init__(self) -> None:
		self.children: List[Any] = [None] * 8


def _coord_to_key(coord: float, resolution: float) -> int:
	return int(np.floor(coord / resolution)) + _TREE_MAX_VAL


def _child_index(kx: int, ky: int, kz: int, bit: int) -> int:
	pos = 0
	mask = 1 << bit
	if kx & mask:
		pos += 1
	if ky & mask:
		pos += 2
	if kz & mask:
		pos += 4
	return pos


def _insert_occupied(root: _OctreeNode, kx: int, ky: int, kz: int) -> None:
	node = root
	for bit in range(_TREE_DEPTH - 1, -1, -1):
		idx = _child_index(kx, ky, kz, bit)
		if bit == 0:
			node.children[idx] = _OCCUPIED
			return
		child = node.children[idx]
		if child is _OCCUPIED:
			return
		if child is None:
			child = _OctreeNode()
			node.children[idx] = child
		node = child


def _pack_child_byte(children: List[Any], offset: int) -> int:
	val = 0
	for i in range(4):
		ch = children[offset + i]
		if ch is None:
			code = 0  # 00 unknown
		elif ch is _OCCUPIED:
			code = 0b10  # 01 occupied (bitset bit0=0, bit1=1)
		elif isinstance(ch, _OctreeNode):
			code = 0b11  # inner
		else:
			code = 0b01  # 10 free
		val |= code << (i * 2)
	return val & 0xFF


def _write_binary_node(node: _OctreeNode, out: bytearray) -> None:
	out.append(_pack_child_byte(node.children, 0))
	out.append(_pack_child_byte(node.children, 4))
	for ch in node.children:
		if isinstance(ch, _OctreeNode):
			_write_binary_node(ch, out)


def octomap_binary_from_occupied_cells(
	cells: np.ndarray,
	resolution_mm: float,
) -> bytes:
	"""Serialize occupied leaves as OccupancyOcTreeBase ``writeBinaryData`` bytes."""
	res = float(resolution_mm)
	if not np.isfinite(res) or res <= 0.0:
		res = 10.0
	c = np.asarray(cells, dtype=np.int64)
	if c.ndim != 2 or c.shape[0] == 0:
		return b""
	root = _OctreeNode()
	# Occupied integer cells are floor(xyz/res); OctoMap keys add tree_max_val.
	for i in range(int(c.shape[0])):
		kx = int(c[i, 0]) + _TREE_MAX_VAL
		ky = int(c[i, 1]) + _TREE_MAX_VAL
		kz = int(c[i, 2]) + _TREE_MAX_VAL
		if kx < 0 or ky < 0 or kz < 0 or kx >= 2 * _TREE_MAX_VAL or ky >= 2 * _TREE_MAX_VAL or kz >= 2 * _TREE_MAX_VAL:
			continue
		_insert_occupied(root, kx, ky, kz)
	out = bytearray()
	_write_binary_node(root, out)
	return bytes(out)


def occupied_cells_aabb(
	cells: np.ndarray,
	resolution_mm: float,
) -> Tuple[float, float, float, float, float, float]:
	res = float(resolution_mm)
	if not np.isfinite(res) or res <= 0.0:
		res = 10.0
	c = np.asarray(cells, dtype=np.int64)
	if c.ndim != 2 or c.shape[0] == 0:
		return (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
	mins = c[:, :3].min(axis=0).astype(np.float64) * res
	maxs = (c[:, :3].max(axis=0).astype(np.float64) + 1.0) * res
	return (
		float(mins[0]),
		float(maxs[0]),
		float(mins[1]),
		float(maxs[1]),
		float(mins[2]),
		float(maxs[2]),
	)


def fcl_octree_from_binary(resolution_mm: float, data: bytes):
	"""Construct python-fcl OcTree from OccupancyOcTreeBase binary payload."""
	if not data:
		return None
	import fcl

	res = float(resolution_mm)
	if not np.isfinite(res) or res <= 0.0:
		res = 10.0
	# python-fcl copies into std::vector<char>. On MSVC char is signed, so
	# raw bytes 128–255 overflow; pass the same bits as signed integers.
	payload = [int(b) - 256 if int(b) > 127 else int(b) for b in data]
	return fcl.OcTree(res, payload)


def file_stat_fingerprint(abs_path: str) -> Tuple[int, int]:
	"""Return ``(mtime_ns, size)`` for collision-geometry fingerprints, or ``(0, 0)``."""
	if not abs_path:
		return (0, 0)
	try:
		st = Path(abs_path).stat()
		mtime = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
		return (mtime, int(st.st_size))
	except Exception:
		return (0, 0)


def occupied_cells_from_points(
	points: np.ndarray,
	resolution_mm: float,
	*,
	max_cells: int = MAX_OCCUPIED_CELLS,
) -> Tuple[np.ndarray, bool]:
	"""
	Map points to unique occupied integer cells.

	Returns
	-------
	cells : (K, 3) int64
		Occupied ``floor(xyz / resolution)`` indices, unique rows.
	truncated : bool
		True when more unique cells existed than ``max_cells``.
	"""
	res = float(resolution_mm)
	if not np.isfinite(res) or res <= 0.0:
		res = 10.0
	pts = np.asarray(points, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3 or pts.shape[0] == 0:
		return np.zeros((0, 3), dtype=np.int64), False
	ijk = np.floor(pts[:, :3] / res).astype(np.int64, copy=False)
	unique = np.unique(ijk, axis=0)
	cap = int(max_cells) if int(max_cells) > 0 else MAX_OCCUPIED_CELLS
	if unique.shape[0] > cap:
		return unique[:cap], True
	return unique, False


def cube_mesh_from_occupied_cells(
	cells: np.ndarray,
	resolution_mm: float,
) -> Tuple[np.ndarray, np.ndarray]:
	"""Emit a triangle soup of axis-aligned cubes, one per occupied cell."""
	res = float(resolution_mm)
	if not np.isfinite(res) or res <= 0.0:
		res = 10.0
	c = np.asarray(cells, dtype=np.int64)
	if c.ndim != 2 or c.shape[1] < 3 or c.shape[0] == 0:
		return np.zeros((0, 3), dtype=np.float64), np.zeros((0, 3), dtype=np.int32)
	c = c[:, :3]
	n = int(c.shape[0])
	# (n, 8, 3) world-space corners from cell min-corner.
	corners = (c.astype(np.float64)[:, None, :] + _CUBE_CORNERS[None, :, :]) * res
	vertices = np.ascontiguousarray(corners.reshape(n * 8, 3), dtype=np.float64)
	offsets = (np.arange(n, dtype=np.int32) * 8)[:, None, None]
	triangles = np.ascontiguousarray(
		(_CUBE_TRIS[None, :, :] + offsets).reshape(n * 12, 3),
		dtype=np.int32,
	)
	return vertices, triangles


def build_octomap_mesh(
	points: np.ndarray,
	resolution_mm: float,
	*,
	max_cells: int = MAX_OCCUPIED_CELLS,
) -> OccupancyBuild:
	"""Voxelize points into occupied cubes and return mesh + status text."""
	return build_occupancy(
		points, resolution_mm, mode="cubes", max_cells=max_cells, build_cube_mesh=True
	)


def build_occupancy(
	points: np.ndarray,
	resolution_mm: float,
	*,
	mode: str = "cubes",
	max_cells: int = MAX_OCCUPIED_CELLS,
	build_cube_mesh: bool = True,
) -> OccupancyBuild:
	"""Build cube mesh and/or octomap binary from points in the given frame."""
	cells, truncated = occupied_cells_from_points(
		points, resolution_mm, max_cells=max_cells
	)
	count = int(cells.shape[0])
	res = float(resolution_mm) if float(resolution_mm) > 0.0 else 10.0
	if count == 0:
		return OccupancyBuild(
			cells=np.zeros((0, 3), dtype=np.int64),
			voxel_count=0,
			truncated=False,
			status="Cloud empty",
			resolution_mm=res,
		)
	verts = np.zeros((0, 3), dtype=np.float64)
	tris = np.zeros((0, 3), dtype=np.int32)
	if build_cube_mesh:
		verts, tris = cube_mesh_from_occupied_cells(cells, res)
	binary = b""
	kind = str(mode or "cubes").strip().lower()
	if kind == "octomap":
		binary = octomap_binary_from_occupied_cells(cells, res)
		if truncated:
			status = f"Ready ({count} leaves, octomap, truncated)"
		else:
			status = f"Ready ({count} leaves, octomap)"
	else:
		if truncated:
			status = f"Ready ({count} voxels, truncated)"
		else:
			status = f"Ready ({count} voxels, cubes)"
	return OccupancyBuild(
		cells=cells,
		voxel_count=count,
		truncated=truncated,
		status=status,
		vertices=verts,
		triangles=tris,
		octree_binary=binary,
		resolution_mm=res,
		bounds=occupied_cells_aabb(cells, res),
	)


def polydata_from_triangles(vertices: np.ndarray, triangles: np.ndarray):
	"""Convert a triangle soup to ``vtkPolyData``. Returns None when empty."""
	verts = np.ascontiguousarray(vertices, dtype=np.float64)
	tris = np.ascontiguousarray(triangles, dtype=np.int64)
	if verts.ndim != 2 or verts.shape[0] == 0 or tris.ndim != 2 or tris.shape[0] == 0:
		return None
	try:
		import pyvista as pv  # type: ignore
	except Exception:
		return None
	n_tris = int(tris.shape[0])
	faces = np.empty((n_tris, 4), dtype=np.int64)
	faces[:, 0] = 3
	faces[:, 1:] = tris
	try:
		mesh = pv.PolyData(verts, faces.ravel())
	except Exception:
		return None
	try:
		return mesh.GetOutput() if hasattr(mesh, "GetOutput") else mesh
	except Exception:
		return mesh


def vis_polydata_from_cells(
	cells: np.ndarray,
	resolution_mm: float,
	*,
	max_cells: int = MAX_VIS_CELLS,
):
	"""Cube-soup overlay from occupied cells (capped for viewport cost)."""
	c = np.asarray(cells, dtype=np.int64)
	if c.ndim != 2 or c.shape[0] == 0:
		return None
	cap = int(max_cells) if int(max_cells) > 0 else MAX_VIS_CELLS
	if c.shape[0] > cap:
		c = c[:cap]
	verts, tris = cube_mesh_from_occupied_cells(c, resolution_mm)
	return polydata_from_triangles(verts, tris)


def octomap_polydata_from_points(
	points: np.ndarray,
	resolution_mm: float,
	*,
	max_cells: int = MAX_OCCUPIED_CELLS,
) -> Tuple[Optional[object], OccupancyBuild]:
	"""Build voxel polydata for CollisionSystem. Poly may be None when empty."""
	result = build_occupancy(
		points, resolution_mm, mode="cubes", max_cells=max_cells, build_cube_mesh=True
	)
	poly = polydata_from_triangles(result.vertices, result.triangles)
	return poly, result


def transform_points_affine(points: np.ndarray, T_4x4: np.ndarray) -> np.ndarray:
	"""Apply a 4x4 affine transform to Nx3 points (engine millimetres)."""
	pts = np.asarray(points, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[0] == 0 or pts.shape[1] < 3:
		return np.zeros((0, 3), dtype=np.float64)
	T = np.asarray(T_4x4, dtype=np.float64)
	xyz = pts[:, :3]
	ones = np.ones((xyz.shape[0], 1), dtype=np.float64)
	homo = np.concatenate([xyz, ones], axis=1)
	return np.ascontiguousarray((T @ homo.T).T[:, :3], dtype=np.float64)


def assert_fcl_octree_roundtrip() -> None:
	"""Occupied cell at origin collides a unit cube BVH; a far cube misses."""
	import fcl

	res = 1.0
	cells = np.array([[0, 0, 0]], dtype=np.int64)
	data = octomap_binary_from_occupied_cells(cells, res)
	if not data:
		raise AssertionError("octomap binary payload is empty")
	tree = fcl_octree_from_binary(res, data)
	if tree is None:
		raise AssertionError("fcl.OcTree construction failed")
	verts, tris = cube_mesh_from_occupied_cells(cells, res)
	model = fcl.BVHModel()
	model.beginModel(len(tris), len(verts))
	model.addSubModel(verts, tris)
	model.endModel()
	obj_tree = fcl.CollisionObject(tree, fcl.Transform())
	obj_near = fcl.CollisionObject(model, fcl.Transform())
	request = fcl.CollisionRequest(num_max_contacts=1, enable_contact=False)
	near = fcl.CollisionResult()
	hit = fcl.collide(obj_tree, obj_near, request, near)
	if not (bool(hit) or near.is_collision):
		raise AssertionError("expected origin unit cube to collide with octree")
	obj_far = fcl.CollisionObject(
		model,
		fcl.Transform(np.eye(3, dtype=np.float64), np.array([1000.0, 0.0, 0.0])),
	)
	far = fcl.CollisionResult()
	miss = fcl.collide(obj_tree, obj_far, request, far)
	if bool(miss) or far.is_collision:
		raise AssertionError("expected far unit cube to miss octree")


if __name__ == "__main__":
	assert_fcl_octree_roundtrip()
	print("fcl OcTree round-trip collide test passed")

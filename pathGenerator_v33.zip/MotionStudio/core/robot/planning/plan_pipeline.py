"""Shared segment-IK + transition stitch pipeline for motion planners."""

from __future__ import annotations

from typing import Callable, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.planning.planner_backend import PlanRequest, PlanResult
from MotionStudio.core.robot.planning.segment_ik import trace_segment_ik
from MotionStudio.core.robot.planning.trajectory import (
	JointSample,
	JointTrajectory,
	assign_times_constant_speed,
	densify_joint_polyline,
	joint_distance,
	wrap_mask_from_joints,
)

TransitionFn = Callable[..., Tuple[Optional[List[np.ndarray]], str]]


def validate_plan_request(request: PlanRequest) -> Optional[str]:
	"""Return an error message if the request is not plannable, else None."""
	if not request.waypoint_segments_m_rad:
		return "No path segments to plan."
	if not request.joint_names:
		return "Robot has no actuated joints."
	if not request.analytic_solver_path:
		return "Analytic solver path is required for process-segment IK."
	return None


def _plan_transition_samples(
	*,
	q_from: np.ndarray,
	q_to: np.ndarray,
	request: PlanRequest,
	transition_fn: TransitionFn,
	wrap_mask: np.ndarray,
	t0: float,
	trans_speed: float,
	edge_res: float,
	name: str,
	label: str,
) -> Tuple[Optional[List[JointSample]], float, Optional[PlanResult]]:
	"""RRT + densify one C-space transition. Returns (samples, t_end, error_result)."""
	if joint_distance(q_from, q_to, wrap_mask) < 1e-6:
		return [], float(t0), None

	path_q = transition_fn(
		q_from,
		q_to,
		request.collision_world,
		time_limit_s=float(request.planning_time_limit_s),
		simplify=bool(request.simplify_path),
		resolution_rad=edge_res,
	)
	detail = ""
	if isinstance(path_q, tuple):
		path_q, detail = path_q
	if path_q is None:
		extra = f" ({detail})" if detail else ""
		detail_l = (detail or "").lower()
		failure_q = q_to if "goal" in detail_l else q_from
		return None, float(t0), PlanResult(
			False,
			f"{name} failed to connect {label}.{extra}",
			failure_q=np.asarray(failure_q, dtype=np.float64),
			collision_world=request.collision_world,
		)

	interior = path_q[1:-1] if len(path_q) > 2 else []
	chain = densify_joint_polyline(
		[q_from] + interior + [q_to],
		max_step=edge_res,
		wrap_mask=wrap_mask,
	)
	cw_check = request.collision_world
	if cw_check is not None:
		for qi in chain:
			if not cw_check.is_state_valid(qi):
				return None, float(t0), PlanResult(
					False,
					(
						f"{name} transition {label} collides after densify "
						f"(edge resolution too coarse or invalid shortcut)."
					),
					failure_q=np.asarray(qi, dtype=np.float64),
					collision_world=cw_check,
				)

	trans_samples, t_trans_end = assign_times_constant_speed(
		chain,
		kind="transition",
		segment_index=-1,
		t0=t0,
		speed=trans_speed,
		wrap_mask=wrap_mask,
	)
	# Drop duplicates of the adjacent endpoints; keep full duration via t_end.
	if len(trans_samples) >= 2:
		trans_samples = trans_samples[1:-1]
	elif len(trans_samples) == 1:
		trans_samples = []
	return trans_samples, float(t_trans_end), None


def plan_segments_with_transitions(
	request: PlanRequest,
	*,
	backend_name: str,
	transition_fn: TransitionFn,
	ik: Optional[AnalyticIKBackend] = None,
) -> PlanResult:
	"""Dense continuous IK along segments; ``transition_fn`` connects them.

	Step 1 verifies process segments (point-valid starts). Step 2 uses RRT for:
	- current robot pose (``q_seed``) → first process sample
	- end of segment i → start of segment i+1

	``transition_fn`` signature matches OMPL/imove helpers::

	    transition_fn(q_from, q_to, collision_world, *, time_limit_s, simplify, resolution_rad)
	        -> (path_or_None, detail_message)
	"""
	err = validate_plan_request(request)
	if err:
		return PlanResult(False, err)

	if ik is None:
		ik = AnalyticIKBackend()
	if not ik.is_available():
		return PlanResult(False, "ssik is not available for analytic IK.")

	cw = request.collision_world
	collision_note = ""
	if cw is not None and getattr(cw, "octomap_not_ready", False):
		return PlanResult(False, "octomap not ready")
	if cw is None:
		collision_note = " (WARNING: no collision world — planning ignores obstacles)"
	elif not cw.collision_checking_active():
		summary = cw.collision_summary() if hasattr(cw, "collision_summary") else ""
		live = bool(getattr(cw, "uses_live_viewport", False))
		if live:
			# Diagnostics-only oracle; production uses PlanningCollisionWorld.
			collision_note = f" (live viewport: {summary})"
		else:
			try:
				import fcl  # noqa: F401
			except Exception:
				return PlanResult(
					False,
					"Collision checking unavailable: python-fcl is not installed. "
					"Install python-fcl (see requirements.txt) so imove/OMPL can avoid obstacles.",
				)
			if len(getattr(cw, "robot_bodies", []) or []) == 0:
				return PlanResult(
					False,
					"Collision checking inactive: no articulated robot colliders were snapshotted "
					"(URDF link Colliders and/or colliders parented under robot links). "
					f"({summary})",
				)
			collision_note = f" (collision snapshot: {summary})"
	else:
		collision_note = f" (collision: {cw.collision_summary()})"

	# Approach start is the robot pose at Plan Motion; never used as a forced
	# straight edge into the first process sample.
	q_approach = np.asarray(request.q_seed, dtype=np.float64).reshape(-1)
	q_seed = q_approach.copy()
	per_seg: List[List[JointSample]] = []

	for seg_idx, waypoints in enumerate(request.waypoint_segments_m_rad):
		if not waypoints:
			per_seg.append([])
			continue
		samples, q_end, seg_err = trace_segment_ik(
			ik, request, list(waypoints), seg_idx, q_seed, t0=0.0
		)
		if samples is None:
			return PlanResult(
				False,
				seg_err,
				failure_q=np.asarray(q_end, dtype=np.float64),
				collision_world=cw,
			)
		per_seg.append(samples)
		# Seed next segment's start-branch ordering from this segment's end.
		q_seed = q_end

	out: List[JointSample] = []
	t_cursor = 0.0
	joint_names = list(request.joint_names)
	wrap_mask = wrap_mask_from_joints(joint_names, request.joints)
	trans_speed = max(1e-3, float(request.transition_joint_speed_rad_s))
	edge_res = max(1e-4, float(getattr(request, "rrt_edge_resolution_rad", 0.05)))
	name = (backend_name or "planner").strip().lower() or "planner"

	active_indices = [i for i, s in enumerate(per_seg) if s]
	for ai, seg_idx in enumerate(active_indices):
		samples = per_seg[seg_idx]
		if not samples:
			continue

		# Approach: current pose → first process sample (same RRT as inter-segment).
		if ai == 0:
			q_to_first = np.asarray(samples[0].q, dtype=np.float64)
			trans, t_cursor, fail = _plan_transition_samples(
				q_from=q_approach,
				q_to=q_to_first,
				request=request,
				transition_fn=transition_fn,
				wrap_mask=wrap_mask,
				t0=t_cursor,
				trans_speed=trans_speed,
				edge_res=edge_res,
				name=name,
				label="approach (current pose → segment 0)",
			)
			if fail is not None:
				return fail
			out.extend(trans)

		t0_local = samples[0].t
		shifted: List[JointSample] = []
		for s in samples:
			shifted.append(
				JointSample(
					t=t_cursor + (s.t - t0_local),
					q=list(s.q),
					kind=s.kind,
					segment_index=s.segment_index,
				)
			)
		if out and shifted and np.allclose(out[-1].q, shifted[0].q, atol=1e-9):
			shifted = shifted[1:]
		out.extend(shifted)
		if out:
			t_cursor = out[-1].t

		if ai + 1 >= len(active_indices):
			continue
		next_idx = active_indices[ai + 1]
		next_samples = per_seg[next_idx]
		if not next_samples:
			continue
		q_from = np.asarray(out[-1].q, dtype=np.float64)
		q_to = np.asarray(next_samples[0].q, dtype=np.float64)
		trans, t_cursor, fail = _plan_transition_samples(
			q_from=q_from,
			q_to=q_to,
			request=request,
			transition_fn=transition_fn,
			wrap_mask=wrap_mask,
			t0=t_cursor,
			trans_speed=trans_speed,
			edge_res=edge_res,
			name=name,
			label=f"segment {seg_idx} → {next_idx}",
		)
		if fail is not None:
			return fail
		out.extend(trans)

	if not out:
		return PlanResult(False, "Planning produced an empty trajectory.")

	traj = JointTrajectory(
		joint_names=joint_names,
		samples=out,
		meta={
			"backend": name,
			"segments": len(request.waypoint_segments_m_rad),
			"simplify_path": bool(request.simplify_path),
			"imove_algorithm": str(getattr(request, "imove_algorithm", "") or ""),
			# Persist wrap flags so Play Mode sample_at matches planner arcs.
			"wrap_mask": [bool(v) for v in wrap_mask.tolist()],
		},
	)
	return PlanResult(True, f"planned by {name}{collision_note}", traj)

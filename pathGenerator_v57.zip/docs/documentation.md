# MotionStudio Documentation

## Overview
PyVista/VTK-based scene editor built with PyQt6. Architecture centers on an ECS core mirrored to a VTK actor set, with a Hierarchy panel, an Inspector for dynamic property editing, and JSON scene persistence.


## Runtime Entry Points
- `MotionStudio.app.main()`: Launches the QApplication and shows the MainWindow (defaults to the `Test Project` folder; optional CLI path as `sys.argv[1]`).
- `launcher.py`: Project launcher window with **New Project…** and **Open Project…**. After a choice, opens `MainWindow` with that project root set (`spawn_demo=False`). Opening an existing project also loads `project.scn` (or the first `.scn` in the folder) once the editor is shown.

## Rendering (PyVista / VTK)
- The editor embeds a VTK render window via `pyvistaqt.QtInteractor` as the central widget.

- `MotionStudio.render.vtk.window.create_vtk_container(parent) -> (QWidget, QtInteractor)`
  - Creates the embedded viewport, sets a themed background gradient (dark navy for dark UI; white→skyblue for light UI via `apply_viewport_background`), and configures a **Z-up** camera.
  - Installs **world origin axes** via `MotionStudio.render.vtk.origin_axes.install_world_origin_axes`: RGB line segments along +X (red), +Y (green), and +Z (blue) from `(0, 0, 0)`, always visible for every scene/project load, **40% opacity**, non-pickable. Length is **screen-space constant** (~64 px by default): world endpoints are recomputed on camera move/zoom via `world_length_for_pixels` (same approach as gizmo/waypoint HUD sizing). **Reset Camera** (`R` / View menu) frames scene content only — origin axes are excluded in `view_controls.reset_camera` (PyVista’s `reset_camera=False` on `add_actor` only skips the initial add-time reset).
  - **Screen-space sync on reset**: `view_controls.reset_camera` calls `camera_view_sync.notify_camera_view_changed` after moving the camera so gizmos, origin axes, path waypoint discs, and vertex-pick highlights rescale (orbit/zoom already update via interactor observers).
  - **Camera navigation**: installs `VtkCameraController` — right-drag orbit, **middle-drag or Shift+right-drag pan**, wheel zoom (see **Input Mappings (Camera)**).
  - Creates the interactor with `auto_update=False` (no free-running pyvistaqt render timer) and `multi_samples` from `PYVISTA_MULTI_SAMPLES` (default `0`, set in `main.py`).

- **Render scheduler** (`MotionStudio.render.vtk.render_scheduler.RenderScheduler`, installed by `create_vtk_container`):
  - Replaces `plotter.render` on the instance: every `plotter.render()` / `request_render(plotter, tag)` call is a **request**. Requests are coalesced into one frame via a single-shot `QTimer` (at most one frame per 16 ms).
  - Main-thread only (off-thread requests are re-posted with a one-time `[render-guard]` warning) and never re-entrant.
  - Skips frames while the viewport is hidden, minimized, or ≤1 px (retries every 250 ms) and while suspended (`suspend(reason)` / `resume(reason)`; `VtkSceneRoot` suspends during bulk scene load).
  - Runs `pre_frame` callbacks (viewport draw hooks + debug draw sync) **before** `Render()`, so no scene/actor mutation happens inside a VTK render pass.
  - There is no background redraw: anything that changes visuals must request a frame. `VtkSceneRoot` requests one on every scene event (add/remove/reparent/changed/transform); camera, path bridge, gizmos, collision overlay, and Debug requests do the same.
  - **Mutation guard:** `plotter.add_actor` / `remove_actor` and `guarded_renderer_add(renderer, actor, plotter)` / `guarded_renderer_remove(...)` are deferred until after the frame when called during a VTK render or from another thread (one-time `[render-guard]` warning naming the caller). Use the guarded helpers instead of raw `renderer.AddActor` / `RemoveActor`.
  - `render_now(tag)` forces a synchronous frame (still guarded); `run_after_frame(label, fn)` queues work for after the current frame.
- **Crash / render logs** (in `%LOCALAPPDATA%\iMOVE\logs`, fallback `logs/` next to the exe):
  - `imove-crash.log` — `faulthandler` Python stacks for all threads on native crashes (enabled in `main.py` before the app imports).
  - `vtk.log` — VTK error/warning output (`vtkFileOutputWindow`, append mode).
  - `imove-console.log` — all `print` / stdout / stderr output of the windowed exe (`redirect_std_streams_to_log` in `main.py`; rolled to `.1` above 10 MB). The exe has no console because a console in QuickEdit/selection mode blocks `print()` and froze the GUI thread.
  - Hang watchdog: if the GUI thread stalls for 10 s, all thread stacks are written to `imove-crash.log` (repeated every 10 s while stalled).
  - Qt messages: `install_qt_message_handler` (in `main.py`) prints Qt warnings as `[qt-warning] …` to stderr and writes Qt fatals (which fast-fail with `0xc0000409`, bypassing faulthandler) plus all Python thread stacks to `imove-crash.log`. Nothing extra to install: `qInstallMessageHandler` / `QtMsgType` are part of `PyQt6.QtCore`.
  - Uncaught Python exceptions: `install_excepthook` logs the traceback to `imove-console.log` and `imove-crash.log` and does **not** abort. Without this, PyQt6 turns a slot/timer exception into a Qt fatal.
  - `imove-sdk-ur.log` / `imove-sdk-mecheye.log` — stdout, stderr, native SDK console output (fds 1/2) and faulthandler stacks of the SDK helper processes (see below).
- **Worker thread lifetime** (`MotionStudio.utils.thread_guard`): deleting a `QThread` that is still running is a Qt fatal. Worker `stop()` methods (UniversalRobot, MechmindScanner, IK, motion planner) signal the worker, wait briefly (2 s; planner 5 s), then `stop_and_retire` keeps a worker still blocked in a native call alive until it exits (`[thread-guard]` lines in `imove-console.log`). Done-signal slots call `release_thread(worker, label)` before clearing their reference (`LoadingController`, GP leak offline generator). On quit, `app.py` waits up to 5 s for retired workers, then exits with `os._exit` instead of tearing down a running thread.
- **SDK helper processes** (`MotionStudio/core/hardwares/sdk_host.py`): `ur_rtde` and the Mech-Eye SDK never load in the editor process. Each connection starts one helper (`multiprocessing` spawn child, no Qt) that imports only the service class (`universal_robot_sdk.UrRtdeService`, `mechmind_scanner_sdk.MechEyeService`) and serves synchronous calls over a pipe. The component worker `QThread`s call it through `universal_robot_client` / `mechmind_scanner_client`, which keep the old function names and raise the usual `UniversalRobotSdkError` / `MechmindSdkError`.
  - A native crash or heap corruption inside an SDK kills only the helper; the next call fails with `connection lost: <name> SDK helper process exited (code …)` and the component shows `Disconnected (connection lost)`. A dead helper is not restarted mid-session; **Connect** starts a fresh one.
  - A blocking native call (e.g. the `RTDEReceiveInterface` constructor waiting ~21 s on an unreachable IP) holds the helper's GIL, not the editor's, so the GUI stays responsive.
  - Every call has an upper bound (query 10 s, connect `timeout_ms` + 15 s, capture `timeout_ms` + 30 s, world-scan merge 600 s, script/IO longer); on expiry the helper is killed and the call fails. Worker `stop()` waits 2 s, then kills the helper so a pending call returns at once, then hands the thread to `stop_and_retire`.
  - Mech-Eye **append merge** (`merge_world_scan`) runs in the `mecheye` helper, not the editor: downsample the new frame, transform to world, voxel-filter, and rewrite `temp/scan.ply`. The helper keeps a `VoxelKeyCache` for that connection so later cells test the new frame against stored voxel keys instead of sorting the whole cloud again. Clear Scan (file gone or a different point count) rebuilds the keys once. Numpy occupancy no longer shares a heap with the viewport.
  - Helpers exit by themselves when the editor process dies (parent watch). Logs: `imove-sdk-<name>.log`.
  - `main.py` keeps all app startup under `if __name__ == "__main__":` after `multiprocessing.freeze_support()`; the frozen exe re-runs itself as the helper and the dev child imports `main.py` as `__mp_main__`. Do not add module-level work to `main.py` beyond path / env setup.
  - OpenBLAS: `main.py` sets `OPENBLAS_NUM_THREADS=1`, `OMP_NUM_THREADS=1`, and `OPENBLAS_CORETYPE=Haswell` (setdefault; a `.bat` or user env can override) **before** numpy loads. The bundled OpenBLAS is `MAX_THREADS=24` / `DYNAMIC_ARCH`; the IPC has 32 logical processors. Startup prints `OpenBLAS: NUM_THREADS=… CORETYPE=… logical_cpus=…` to `imove-console.log`.
  - `render-trace.log` — ring buffer of the last 200 scheduled frames and guard warnings (`render_diagnostics.diagnostics`), flushed about once per second.

- `MotionStudio.render.vtk.scene_root.VtkSceneRoot(plotter, scene, selection)`
  - Mirrors the ECS `Scene` hierarchy into **VTK actors** added to the plotter.
  - Listens to scene signals (add/remove/reparent/changed) and updates actor geometry + transforms.
  - Uses `TransformComponent` PRS (position/rotation/scale) to build a 4x4 world matrix per entity.

### Picking / Selection
- Picking is done via a VTK `vtkCellPicker` connected to mouse click events in the viewport.
- `MotionStudio.render.vtk.picking.VtkPickerBridge(...)` maps picked actors back to entity ids and updates `SelectionModel` (plain click = single selection; **Ctrl+click** toggles entities in the set).
- Selection highlight is handled in `VtkSceneRoot` (one outline/bbox per selected entity).
- **Multi-selection**: Hold **Ctrl** and click entities in the **Hierarchy** or **3D viewport**. The **last clicked** entity is the **primary** selection (`SelectionModel.current`). Gizmos and path tools use the primary entity only.


## ECS Core
- MotionStudio.core.ecs.component
  - Component (base class)
    - ClassVars: `type_name` (registry / `.scn` key), `category` (Add Component menu path; `/` nests submenus, e.g. `"Hardware/Scanners"`; default `"Others"`), `description` (menu tooltip, 1–2 lines).
    - Unregistered abstract subclasses (`Robot`, `Scanner`) exist so Inspector `Optional[Robot]` / `Optional[Scanner]` can bind any hardware driver that subclasses them. They are not `@register_component` and do not appear in Add Component.
    - Instance: `locked` (bool, default `False`) — Inspector header lock toggle (right side of the component header). When locked, public field writes are silently ignored; Inspector fields/buttons disable; Transform gizmos ignore drags; **Remove (✕) is disabled**. Persisted in `to_dict` / restored last in `from_dict`. Undo uses `force_setattr` to bypass the lock. Toggle `locked` / `collapsed` is always allowed.
    - Instance: `collapsed` (bool, default `False`) — Inspector header collapse toggle (**up arrow** at the top-left of the component, before the info button). When collapsed, only the header row (collapse, info, lock, remove) is shown and the fields/group below are hidden. Clicking again (down arrow) expands and re-renders all Inspector fields. Persisted in `to_dict` / `from_dict` like `locked`.
    - to_dict() -> dict: **Automatic serializer** that uses reflection to discover fields (same mechanism as Inspector), plus `locked` and `collapsed`. Automatically handles registered types (QColor, QVector3D, QQuaternion). Subclasses can override for custom behavior.
    - from_dict(data: dict) -> Component: **Automatic deserializer** that uses reflection to discover fields and restore values, then applies `collapsed` and `locked` last. Automatically handles registered types. Subclasses can override for custom behavior.
    - start() -> None: **Called once when Play Mode starts**, or immediately when a component is added during Play Mode (Unity-like behavior). Override this method to initialize runtime state.
    - update(delta_time: float) -> None: **Called every frame during Play Mode**. Override this method to implement per-frame behavior.
    - on_entity_changed() -> None: **Called when the entity is edited** (component properties modified, entity name changes, etc.). Override this method to react to entity changes. Works in both edit mode and play mode.
    - on_viewport_draw() -> None: **Called on the main thread immediately before each scheduled 3D viewport frame** (edit and play modes). Override for per-frame visual work such as re-issuing one-frame `Debug.draw_*` calls. Do not mutate public component fields here: writes during the draw pass are applied but their `entity_changed` is deferred until after the frame (one `[render-guard]` warning per class/field).
    - **Automatic Signal Emission**: All public field changes automatically emit `entity_changed` signals to update VTK actors. This works for both Inspector edits and programmatic changes (e.g., in `update()` methods). Similar to Unity's behavior where changing any component property automatically updates rendering.
    - **Type Converters**: Common Qt types (QColor, QVector3D, QQuaternion) are automatically serialized/deserialized. Use `register_type_converter()` to add custom type converters.
  - register_component(cls): Class decorator registering a component class (by `type_name` or class name).
    - **Important**: The decorator only executes when the module is imported. Components must be imported somewhere (e.g., in `MotionStudio/core/components/__init__.py` for core components) to appear in the Inspector's "Add Component" menu.
  - get_component_class(type_name: str) -> Optional[Type[Component]]: Lookup by registered type name.
  - get_registered_components() -> Dict[str, Type[Component]]: Returns all registered components.
  - components_by_category(*, exclude=...) -> ordered flat map of full `category` string -> [(type_name, cls), ...].
  - components_category_menu_tree(*, exclude=...) -> nested `{submenus, components}` tree used by the Inspector **Add Component** menu. Splits `category` on `/`; top-level order prefers Robot / Path generation and planning / Collision / Measure / Rendering (case-insensitive), then other roots alphabetically, with `Others` last.

- MotionStudio.core.ecs.entity.Entity
  - Fields: id (str), name (str), parent (Entity | None), children (list[Entity]), components (list[Component])
  - Methods:
    - add_child(child: Entity), remove_child(child: Entity)
    - add_component(component: Component), remove_component(component: Component)
    - get_component(cls_type) -> Optional[Component]

## Core Components

All standard components are located in `MotionStudio.core.components`:

- **Package**: `MotionStudio.core.components`
  - Contains all standard component implementations
  - Components can be imported directly: `from MotionStudio.core.components import TransformComponent, MeshComponent, PathComponent`

- MotionStudio.core.components.transform_component.TransformComponent (Component)
  - Properties:
    - position: QVector3D
    - rotation_quat: QQuaternion
    - euler_deg: tuple[float, float, float] (degrees, XYZ)
    - scale3d: QVector3D
  - Serialization: to_dict()/from_dict() round-trips PRS values.
  - **Note**: Transform properties automatically emit `entity_changed` signals when modified, ensuring rendering updates.

- MotionStudio.core.components.mesh_component.MeshComponent (Component)
  - Properties:
    - shape: Literal["cube", "sphere", "custom"]
    - custom_path: str (project-relative path when shape is "custom"; see mesh assets below)
    - source_material: bool (when true, render imported source-material diffuse colors for supported assets instead of the component's uniform `color`)
    - color: QColor
    - decimate_ratio: float (0.01–1.0, default `0.2`) — fraction of faces to **keep** when baking an LOD (Blender Collapse analogue)
    - use_decimated_mesh: bool (default `false`) — when on, viewport and collision load the baked LOD; when off, they load `custom_path`
    - decimated_path: str (read-only) — project-relative LOD STL written by **Decimate**
  - **Decimate** (Inspector Group): **Decimate** bakes a lower-poly STL via VTK `vtkQuadricDecimation` (`MotionStudio.utils.mesh_decimate.decimate_mesh_to_stl`) on the loading-overlay worker. Writes `models/<stem>_lod.stl` (same file overwritten on later Decimate runs) onto `decimated_path` and turns **use_decimated_mesh** on (undoable). `custom_path` stays the detailed source. Disabled for cube/sphere or an empty path. Changing `custom_path` clears the LOD fields. While the LOD is shown, Vertex/Edge/Face picks and Path Generation CAD **vertex ids** on this mesh are stale; Custom Segments that store positions stay valid. Turn **use_decimated_mesh** off to display the original mesh again.
  - Serialization: to_dict()/from_dict() round-trips mesh properties.
  - **Mesh assets**: Files picked from outside the active project folder are copied into `<project>/models/` and `custom_path` stores a path relative to the project root (for example `models/part.stl`). The editor resolves relative paths against `Scene.project_root` when loading geometry. Copying the project folder therefore includes referenced meshes without external file dependencies.
  - **DAE import normalization**: `.dae` is normalized at import time to `.glb` under `models/` for deterministic runtime loading. Import also reads Collada `<asset><unit meter="...">` and scales geometry to engine millimetres (`1 unit = 1 mm`) before writing GLB.
  - **STEP import normalization**: `.step` / `.stp` is tessellated at import time to `.stl` under `models/` (or beside the source file when no project is open). Conversion uses OpenCASCADE via `cascadio` with absolute linear deflection **0.1 mm** and angular tolerance **20°**. The intermediate GLB is glTF **metres**; vertices are scaled ×1000 so the stored STL is engine millimetres. Assemblies become one merged STL / one entity. The original STEP is not stored on `MeshComponent.custom_path`. STL has no materials so `source_material` stays off.
  - **Source material sidecar**: During DAE->GLB conversion, the importer writes `<mesh>.glb.materials.json` containing diffuse RGB colors per source submesh. When the sidecar exists, `source_material` is auto-enabled for new imports from the Hierarchy/Inspector path picker.

- MotionStudio.core.components.point_cloud_component.PointCloudComponent (Component)
  - Type name: `"PointCloud"`
  - Properties:
    - `file_path`: project-relative path to a `.ply` or `.pcd` cloud (external picks are copied into `<project>/models/` like mesh assets)
    - `color`: uniform `QColor` when vertex colors are unavailable or `use_vertex_colors` is false
    - `use_vertex_colors`: when true and the file has RGB, render per-point colors
    - `point_size`: screen-pixel point size (VTK `SetPointSize`)
    - `opacity`: actor opacity 0–1
    - `scale`: uniform XYZ multiplier at load (default `1000` = metres → engine mm; use `1` if the file is already in mm)
    - `downsample_ratio`: float (0.01–1.0, default `0.2`) — fraction of points to **keep** when baking an LOD (Mesh Decimate analogue)
    - `use_downsampled_cloud`: bool (default `false`) — when on, viewport and PointCloudCollider load the baked LOD; when off, they load `file_path`
    - `downsampled_path`: str (read-only) — project-relative LOD PLY written by **Downsample**
  - **Downsample** (Inspector Group): **Downsample** bakes a lighter PLY via even-index keep-fraction (`MotionStudio.utils.point_cloud_downsample.downsample_point_cloud_to_ply`) on the loading-overlay worker. `0.98` keeps ~98% of points. Writes `models/<stem>_lod.ply` (same file overwritten on later Downsample runs) onto `downsampled_path` and turns **use_downsampled_cloud** on (undoable). `file_path` stays the detailed source. Coordinates stay in file units (component `scale` still applies at load). Disabled when `file_path` is empty. Changing `file_path` (Inspector or Mechmind Capture) clears the LOD fields. While the LOD is shown, Vertex picks on this cloud are stale. Turn **use_downsampled_cloud** off to display the original cloud again. For live **append** captures, set **MechmindScanner.downsample_ratio** instead of clicking Downsample after every Capture. Overlapping Scan Mission FOV is **ScanMission.overlap_voxel_mm**, not whole-cloud Downsample.
  - Rendering: `VtkSceneRoot` keeps a separate `_point_cloud_actors` map (independent of `MeshComponent`). Loads `effective_file_path()` via `MotionStudio.utils.point_cloud_io.load_point_cloud(..., allow_vtk=False)` (numpy PLY reader only — no VTK on the GUI thread). Actor fingerprint uses `content_revision` (bumped by Capture / Downsample), not file mtime, so a write still in progress cannot trigger a mid-file reload. `save_point_cloud` writes via a temp file and `os.replace` (retried; never overwrites in place). Worker threads also pass `allow_vtk=False`. Points render with `style="points"` and follow the entity world matrix via `SetUserMatrix`.
  - Participates in **Vertex Mode** / Inspector **VertexPick** and path-tool point picks (same click path as mesh vertices). Does **not** participate in Edge Mode or Face Mode. Attach **PointCloudCollider** to include the cloud in scene collision.
  - Hierarchy: **Import Point Cloud** creates an entity with `Transform` + `PointCloud`.
  - Serialization: automatic `to_dict()` / `from_dict()`.

- MotionStudio.core.components.robot.Robot (abstract Component; not registered)
  - Type name: `"Robot"`; category: `"Hardware/Robots"`. **Not** in Add Component. Inspector `Optional[Robot]` accepts any subclass (`UniversalRobot` today). Methods: `add_job_listener` / `remove_job_listener` / `set_move_target` / `move_to_target` / `stop_robot` / `set_io_target` / `apply_io` / `read_io` / `apply_actual_configuration` / `read_tcp_pose` / `jog_tcp`. Distinct from `RobotDescription`. Inspector **Joystick** gear (any `Robot`) opens a floating dock with Position / Rotation `Vector3Editor`s plus jog pads. Typing a pose (edit finished) `movel`s those values. Pad clicks call `jog_tcp`: read live TCP, add the step, `movel` — they never add onto leftover type-field values.
  - Implementation: `MotionStudio/core/components/robot.py`.

- MotionStudio.core.components.scanner.Scanner (abstract Component; not registered)
  - Type name: `"Scanner"`; category: `"Hardware/Scanners"`. **Not** in Add Component. Inspector `Optional[Scanner]` accepts any subclass (`MechmindScanner` today). Methods: `add_job_listener` / `remove_job_listener` / `capture_scan` / `clear_scan`.
  - Implementation: `MotionStudio/core/components/scanner.py`.

- MotionStudio.core.components.mechmind_scanner_component.MechmindScannerComponent (Scanner)
  - Type name: `"MechmindScanner"`; category: `"Hardware/Scanners"` (Add Component → Hardware → Scanners). Subclasses `Scanner`.
  - Connects to a Mech-Eye (Mechmind) area-scan 3D camera and writes each capture onto a referenced `PointCloud` component.
  - Fields:
    - `ip_address`: camera IPv4 (default `"192.168.1.100"`)
    - `timeout_ms`: timeout for **Connect and Capture**, range 1000–180000 (default `60000`). Passed to `Camera.connect` and to `capture_2d_and_3d` / `capture_3d` (SDK defaults are 5–10 s and time out after the projector fires). Older scenes that stored `10000` are raised to `60000` on load. Also applied via `Camera.set_timeout` when that method exists.
    - `capture_color`: when true, `capture_2d_and_3d` + textured PLY; otherwise untextured `capture_3d` (default true)
    - `append_scan`: when true (default), each Capture transforms camera-frame points into **world space** using the **Camera Frame** transform's world matrix (snapshotted when Capture is clicked) and **appends** them onto `<project>/temp/scan.ply`. When false, Capture overwrites that file with a single camera-frame scan.
    - `downsample_ratio`: float (0.01–1.0, default `1.0`) — keep-fraction applied to **this Capture only** before write/append (`MotionStudio.utils.point_cloud_downsample`). `1.0` keeps the full frame. `0.2` keeps 20% of the new frame. Already-stored points in `temp/scan.ply` are not thinned again (do not re-run PointCloud **Downsample** after every append — that would reduce older captures repeatedly). Linear keep-fraction does **not** remove overlapping-FOV duplicates; overlapping Scan Mission grids set **ScanMission.overlap_voxel_mm**.
    - `connection_status` (`ConnectionStatus` badge): `"Disconnected"` / `"Connecting…"` / `"Connected"` / `"Capturing…"` / `"Disconnecting…"` / `"Error: …"`. Inspector shows a LED (green = Connected, amber = Connecting/Capturing/Disconnecting, red otherwise) plus the full text. `from_dict` always restores `"Disconnected"` because the SDK handle is not serialized.
    - `camera_frame`: optional `TransformComponent` reference (required for Capture). Optical frame, typically a child of this CAD scanner entity. Mech-Eye +X right, +Y down, +Z optical axis. This is the pose Capture uses, not the scanner mesh origin.
    - `target`: optional `PointCloudComponent` reference. Capture sets its `file_path` to `temp/scan.ply`.
  - Inspector buttons: **Connect**, **Disconnect**, **Capture**, **Clear Scan** (deletes `temp/scan.ply` / staging file and clears the Target `file_path`). Connect / Capture / Disconnect run on the worker thread; TCP `RUN` and Inspector `logs.txt` wait until the job finishes. **`PASS` means the intent succeeded** (camera connected, scan written and Target updated, disconnected). A failed connect/capture is `FAIL` with `Error: …` matching `connection_status`. Busy / missing SDK / not connected reject immediately with `FAIL`. Clear Scan is synchronous file I/O. A Capture command timeout **drops the SDK session** (`Camera session dropped`) so the next Connect starts clean; if Connect still times out, power-cycle the scanner (exclusive client lock). `disconnect()` errors are reported, not swallowed; the handle is still dropped.
  - Capture requires a live connection, a `target`, and `scene.project_root`. It creates `<project>/temp/` if needed. Append mode captures to a staging PLY in the helper, then `merge_world_scan` (same helper: numpy only, `allow_vtk=False`) keep-fraction-downsamples that frame, voxel-filters it, and appends onto the Target. The editor reloads the Target after the helper returns. If the existing `temp/scan.ply` cannot be read, Capture fails instead of overwriting earlier captures (use **Clear Scan**). Optional kw-only `capture_scan(overlap_voxel_mm=…)` (Inspector **Capture** omits it, so `0`) occupancy-filters the **new** world points against voxels already filled in `temp/scan.ply` (`MotionStudio.utils.point_cloud_overlap`); stored points are not re-filtered. Overwrite mode uses the Mech-Eye SDK save, then downsamples the dest in place when `downsample_ratio` < 1 (occupancy is append-only). After a successful Capture (Inspector or Scan Mission cell) the Target's `content_revision` is bumped so the viewport reloads the finished file once (they do not watch mtime). PointCloudCollider occupancy does **not** rebuild per cell unless `auto_update` is on; click **Update collider** after the mission. Occupancy (octomap / cubes) is built on a worker thread, never inside `check_all`.
  - **Pose / frames**: The scanner entity is the CAD housing. Mech-Eye points are in the camera optical frame (+X right, +Y down, +Z along the optical axis). Assign **Camera Frame** to that optical transform (child of the CAD entity). **Append (default):** points are stored in world millimetres using Camera Frame's world matrix; Target is snapped to the world origin (identity pose) so multi-position captures stay aligned. **Overwrite:** Target world pose is copied from Camera Frame. Capture also sets the target cloud's `scale` to `1`. Capture fails if Camera Frame is unset.
  - Threading: a dedicated `QThread` owns the camera session (connect / capture / disconnect). The SDK `Camera` itself lives in the `mecheye` helper process (see **SDK helper processes** under Rendering); the Mech-Eye SDK writes the capture PLY there. Inspector buttons only enqueue jobs. Results arrive on a queued `pyqtSignal` on the main thread. Starting the worker registers the session with `scene.hardware_runtime` (key `{entity_id}:MechmindScanner`). Entity or component teardown, scene clear, `MainWindow.closeEvent`, and `QApplication.aboutToQuit` call cooperative `shutdown()` (never `QThread.terminate()`).
  - SDK: optional. Install Mech-Eye SDK on the machine and `pip install MechEyeAPI`. The editor starts without it; Connect/Capture then set `connection_status` to `Error: MechEyeAPI not installed…`. `MechEyeAPI` is **not** a hard package dependency.
  - Implementation: `MotionStudio/core/components/mechmind_scanner_component.py`, `MotionStudio/core/hardwares/mechmind_scanner_client.py` (editor side) plus `MotionStudio/core/hardwares/mechmind_scanner_sdk.py` (runs in the helper: version-tolerant connect / capture timeout / `FileFormat_PLY` vs `FileFormat.PLY`, and `merge_world_scan`).

- MotionStudio.core.components.universal_robot_component.UniversalRobotComponent (Robot)
  - Type name: `"UniversalRobot"`; category: `"Hardware/Robots"` (Add Component → Hardware → Robots). Subclasses `Robot`.
  - Connects to a Universal Robots controller via optional `ur_rtde` (`RTDEReceiveInterface` on port 30004), can send a `.script` file (**RUN**), or a TCP `movel` (**Move To Target**). **STOP** sends `halt` and cancels either wait. **Connect does not open `RTDEControlInterface`**: that constructor uploads ur_rtde's own control script, which a later 30002 `.script` send replaces, dropping the RTDE session — the previous cause of "connection lost" during RUN.
  - Fields:
    - `ip_address` / `timeout_ms`: Inspector group **Connection Settings** (with **Connect** / **Disconnect**).
    - `connection_status` (`ConnectionStatus` badge, main form): `"Disconnected"` / `"Connecting…"` / `"Connected"` / `"Running script…"` / `"Moving…"` / `"Setting I/O…"` / `"Syncing joints…"` / `"Reading TCP…"` / `"Stopping…"` / `"Disconnecting…"` / `"Disconnected (connection lost)"` / `"Error: …"`. LED is green when Connected, amber when Connecting/Running script/Moving/Setting I/O/Syncing joints/Reading TCP/Stopping/Disconnecting, red otherwise. `from_dict` always restores `"Disconnected"` because RTDE handles are not serialized.
    - `robot`: optional `RobotDescriptionComponent` reference (virtual URDF root). **Set actual configuration** / Scan Mission copy live joints onto it; **Update TCP** copies the controller TCP offset onto that robot's `RobotIK` TCP (child of `tool0`); **Path Mission** uses it as the arm base / `root_link` frame.
    - `script_path`: `FilePath` in Inspector group **Robot Control**, header **Script** (URScript `*.script`).
  - `target_position` (mm, engine units) / `target_rotation` (UR rotation vector, degrees; converted to radians for `movel`) / `move_speed_m_s` / `move_accel_m_s2`: same group, header **Move To Target**. Position is converted to metres for `movel`.
  - `io_type` / `io_index` / `io_value`: same group, header **Trigger DI/DO**. `io_type` is a PolyScope bank dropdown (`Standard Out` / `Configurable Out` / `Tool Out` / `Standard In` / `Configurable In` / `Tool In`). Index is 0–7 (Tool 0–1). Value is High when checked. **Apply I/O** writes an output via `RTDEIOInterface` (does not replace a running program; falls back to a short URScript on 30002 if `rtde_io` is missing). Digital inputs cannot be written — Apply I/O **reads** them into `io_value`.
  - Inspector: **Connection Settings** gear (IP, timeout, Connect, Disconnect), then `connection_status`, then `robot`, then **Set actual configuration** (reads `getActualQ` on the worker, maps onto `RobotDescription.actuated_joint_names`, runs FK). Then **Robot Control** gear (**TCP** + **Update TCP**, **Script** + **RUN**, **Move To Target** + button, **Trigger DI/DO** + **Apply I/O**, **Stop** + **STOP**), then a **Joystick** gear. TCP `RUN` / Inspector logs wait until the **robot program stops** (or fails): **`PASS` only when connected**, disconnected, the script finished, or the `movel` finished. **Set actual configuration** `PASS` when joints are applied to the virtual robot. **Update TCP** `PASS` when the PolyScope TCP offset is written onto `RobotIK.tcp` (child of `tool0`). **Apply I/O** `PASS` when the pin write/read finishes. Failures are `FAIL` with `Error: …` (`connection_status`). Missing `ur_rtde` / not connected reject immediately with `FAIL`. RUN, Move To Target, Apply I/O, Set actual configuration, and Update TCP require a live Connect. **STOP** and **Disconnect** are allowed while a script or `movel` is running (STOP cancels the wait and sends `halt`; Disconnect cancels the wait and closes RTDE). Connect / RUN / Move To Target / Apply I/O still reject with `FAIL` when another job is in flight.
  - **Joystick** (floating dockable window, same host as Inspector `Group` docks): **Position** (`mm`) and **Rotation** (UR rotvec `deg`) `Vector3Editor`s, translation pad (X pink, Y green, Z blue), rotation pad (RX / RY / RZ), and one **Move step size** (`mm / deg`, default 10). Finishing a type-field edit `movel`s to those values (`set_move_target` + `move_to_target`; typed axes debounce ~250 ms). **Pad clicks must not use leftover field values** — they call `Robot.jog_tcp` (`getActualTCPPose`, add the step in the hardware base, `movel`). After a jog the type fields update to the commanded live+offset pose. Buttons/fields disable while disconnected, busy, or locked. Title: `Entity -> UniversalRobot -> Joystick`. UI-only (not a TCP `RUN` button). **STOP** cancels an in-flight move.
  - RUN resolves `script_path` as an absolute file or as project-relative under `scene.project_root`, then the worker sends the file on the **secondary interface (port 30002)** and polls `RTDEReceiveInterface.isProgramRunning()` until the program ends. Move To Target sends a one-shot `movel(p[x,y,z,rx,ry,rz], a, v)` the same way, then polls `getActualTCPPose` until the live TCP is within 1 mm / 0.01 rad for three samples — not `isProgramRunning`, which 30002 scripts often never set, so Path Mission used to fire the next waypoint while the arm was still moving. Arrival is the exact 1 mm / 0.01 rad band **or** moved-then-rest just outside it (a real `movel` often settles a few millimetres short). If TCP never leaves the start pose, fail in **2.5 s** with `robot_not_ready_message` (`getRobotMode` / `getSafetyMode`) instead of the 10-minute deadline — IDLE / POWER_ON is brakes-on, not Started; Local mode is not in RTDE so the message falls back to Remote Control. Arrival and timeout print the residual (`settled 3.42 mm / 0.11° from target (tol 1.00 mm / 0.57°)`). The pose-timeout deadline is **10 minutes**. Neither uses `sendCustomScriptFile` (that call blocks in native code waiting for a ur_rtde control-script handshake a normal exported `.script` never sends, which left status stuck on Running script). e-Series must be in **Remote Control**. Protective / emergency stop, STOP, Disconnect, a dropped RTDE link, or a Move To Target pose timeout end the wait so RUN / Move To Target can be used again without restarting the editor. After send, and on brief RTDE drops, receive is re-opened up to **3 times** (~0.5 s apart) before status becomes `"Disconnected (connection lost)"`. Re-opening calls `reconnect()` on the **same** `RTDEReceiveInterface` (one instance per session); it is not destroyed and re-created per drop, which churned native ur_rtde objects.
  - While connected and idle, the worker probes receive `isConnected()` / `getActualQ` every ~400 ms (never a dummy TCP to 30004 — that steals the controller's single RTDE client slot). Three consecutive misses try the same bounded `reconnect_receive` used during RUN / Move To Target (a 30002 `movel` often drops RTDE after the pose has already arrived; Scan Mission’s Capture wait used to hit that idle path and show `"Disconnected (connection lost)"` after the first cell). If reconnect fails, receive+IO are disposed and status becomes `"Disconnected (connection lost)"`. **Connect** retries RTDE receive until `timeout_ms`, waiting for a live recipe handshake, so PolyScope need not be restarted.
  - Threading: worker thread owns the session; the ur_rtde handles live in the `ur` helper process (see **SDK helper processes** under Rendering). Session registers with `scene.hardware_runtime` as `{entity_id}:UniversalRobot`. Same shutdown path as MechmindScanner. Connect to an unreachable IP fails after `timeout_ms` + 15 s with `Connect timed out: …` (ur_rtde's constructor ignores the timeout while the OS TCP connect waits); the GUI stays responsive meanwhile.
  - SDK: optional. `pip install ur_rtde`. The editor starts without it; Connect sets `Error: ur_rtde is not installed…`. Not a hard package dependency. Editor side: `MotionStudio/core/hardwares/universal_robot_client.py`; helper side: `MotionStudio/core/hardwares/universal_robot_sdk.py` (`UrRtdeService`, `send_script_text` / `send_movel` / `send_halt` / `apply_digital_io` / `get_tcp_pose` / `get_tcp_offset` / `get_joints` / `robot_not_ready_message`).
  - Implementation: `MotionStudio/core/components/universal_robot_component.py`. `set_io_target(bank, port, state)` maps PathAction bank ids to Inspector `io_type` / `io_index` / `io_value` for Path Mission. `apply_actual_configuration` and `read_tcp_pose` are on the `Robot` ABC. `read_tcp_pose` queues worker job `get_tcp` (`getActualTCPPose`, payload `tcp:x,y,z,rx,ry,rz` metres + rotvec rad). Inspector **TCP** (`RobotTcp`) writes XYZ millimetres (`× 1000`); V2R Scan uses the full 6D pose to drive RobotIK Target. **Update TCP** (`update_tcp`) is UniversalRobot-only: worker job reads RTDE `tcp_offset` (payload `offset:x,y,z,rx,ry,rz` metres + rotvec rad) and writes it as the local Transform of `RobotIK.tcp` under `tool0`.

- MotionStudio.core.components.scan_mission_component.ScanMissionComponent (Component)
  - Type name: `"ScanMission"`; category: `"Path generation and planning"` (Add Component → Path generation and planning).
  - Job-side orchestrator: binds `Optional[Robot]` + `Optional[Scanner]`, authors a parallelogram grid, then a play routine `movel`s and Captures at each cell.
  - Fields: `mission_type` (`Literal["Grid"]`, default Grid); `robot`; `scanner`; `mission_status` (`Idle` / `Running…` / `Stopping…`, restored to Idle); Grid Settings `show_grid` (viewport overlay, default true), `grid_origin` / `grid_along_columns` / `grid_along_rows` (`VertexPick`, owner-local mm), `grid_rows` / `grid_cols` (1–200), `overlap_voxel_mm` (0–50, default `0` — millimetres; `0` concatenates every capture; overlapping cells drop new points in voxels the accumulated cloud already occupies; stored points are not re-filtered; typical overlapping FOV `1.0`–`2.0`), `tcp_rotation` (`Optional[TransformComponent]`, world orientation). `downsample_ratio` stays on MechmindScanner (per-frame keep-fraction) and does not remove spatial duplicates.
  - Buttons: **Run Scan Mission** / **Stop Scan Mission** (main Inspector). Run requires connected hardware, TCP rotation, and a **RobotDescription** resolved from the UniversalRobot `robot` field or a RobotDescription sibling on the controller entity. Run calls `clear_scan` first (deletes `temp/scan.ply` and clears the Target). Each cell Capture bumps the Target `content_revision` so the viewport reloads the growing cloud. PointCloudCollider occupancy stays idle unless `auto_update` is on; click **Update collider** after the mission. Cell poses: owner-local → world → robot base; then `set_move_target` + `move_to_target` so the **robot TCP** reaches each cell. The scanner CAD / Camera Frame are not moved by the job. After each hardware move, Scan Mission sets the **RobotIK Target** to that cell’s world pose (the same point as the grid overlay) and `solve_sync`s under `robot_ik_system.suppress_async()` so posing the Target does not also enqueue a worker solve. Virtual URDF / Camera Frame match the scene — not `apply_actual_configuration`. Copying `getActualQ` onto the URDF FK often snaps the CAD into the opposite quadrant (controller Base vs URDF `base_link` joint zeros) while the live arm is already correct. If RobotIK Target is missing, it still falls back to live-joint FK. Capture then stamps the cloud with Camera Frame’s world matrix, passing `overlap_voxel_mm` into `capture_scan` for that job only (Inspector Capture stays concat). Other `Scanner` subclasses that reject the kwarg fall back to `capture_scan()`. Abort on move/sync/capture FAIL, or if the robot dropped during Capture (`robot disconnected during capture`). Stop calls `stop_robot`, stops the play routine, notifies `(False, "cancelled")`. In-flight Capture is not cancellable.
  - TCP/Sequencer: `_ASYNC_HANDLERS` `("ScanMission", "run_scan_mission")` waits on `add_mission_listener`; `cancel_attr="stop_scan_mission"`. Whole-mission timeout is `prefs.tcp_timeout_s` (raise it for large grids, or Run from the Inspector).
  - Viewport: `on_viewport_draw` shows corners, grid nodes, and TCP +Z rays when `show_grid` is on **and the Scan Mission entity is selected**. Markers are world-space (not screen-pixel discs), so orbiting the camera does not rebuild those line batches.
  - Implementation: `MotionStudio/core/components/scan_mission_component.py`.

- MotionStudio.core.components.v2r_calibration_component.V2RCalibrationComponent (Component)
  - Type name: `"V2RCalibration"`; category: `"Alignment and datum"` (Add Component → Alignment and datum). Put it on a **Job** entity, not on the scanner CAD.
  - Eye-in-hand: binds `Optional[Robot]` + `Optional[Scanner]`, captures one cloud, pairs six `VertexPick` cloud points with six live-hardware TCP millimetres in the robot base, solves a rigid `T_base_cam` (Kabsch, scale locked), and writes it onto the scanner **Camera Frame**.
  - Fields: `configuration` (`Literal["EyeInHand"]`, default EyeInHand); `robot`; `scanner`; read-only multiline `status` (restored to Idle); Cloud points gear `cloud_1`…`cloud_6` (`VertexPick`, owner-local mm); Robot TCP gear `robot_1`…`robot_6` (`RobotTcp` — **TCP** writes hardware-base mm from Primary Robot, else this **robot**; not VertexPick / not CAD `root_link`).
  - Buttons: **Scan** / **Calibrate** / **Clear** (main Inspector). Scan requires connected hardware, Camera Frame assigned, RobotDescription, and **RobotIK Target** on the robot root. It calls `clear_scan`, then `read_tcp_pose` (`getActualTCPPose` in the hardware base), maps that pose through CAD `root_link` into world, `solve_sync`s RobotIK to that Target (not `apply_actual_configuration` — live joints snap the URDF into the opposite quadrant), then `capture_scan` and snapshots Camera Frame / scanner CAD / robot-base world matrices at Capture queue time. Prefer `append_scan` off so picks belong to this capture. Calibrate maps picks through `inv(T_world_cam_snap)`, solves Kabsch into base millimetres, and `set_world`s Camera Frame to `T_world_base_snap · T_base_cam` (parent-local is `T_cad_cam` when Camera Frame is a child of the CAD). Clear zeros the twelve vectors and drops the snapshot. Reject coincident / degenerate sets. Viewport markers while selected: C1–C6 (cloud world) and R1–R6 (`transform_point(base, robot_i)`).
  - TCP/Sequencer: `_ASYNC_HANDLERS` `("V2RCalibration", "scan")` waits on `add_scan_listener`; `cancel_attr="cancel_scan"`. **Calibrate** and **Clear** are synchronous.
  - Implementation: `MotionStudio/core/components/v2r_calibration_component.py`. Shared Kabsch: `MotionStudio/core/transform/rigid.py`.

- MotionStudio.core.components.three_point_calibration.ThreePointCalibrationComponent (Component)
  - Type name: `"ThreePointCalibration"`; category: `"Alignment and datum"`.
  - Part-to-robot alignment: three `VertexPick` model vertices (`model_a` / `model_b` / `model_c`, owner-local) paired with three measured points `robot_a` / `robot_b` / `robot_c` (`RobotTcp`). **TCP** writes the live hardware TCP origin in the connected robot’s base frame (mm). Align interprets those vectors in **Robot Frame** (or world if empty) — set Robot Frame to the robot base when using **TCP**. The button never converts into world or owner-local.
  - Assign **Primary Robot** on the Sequencer ribbon (this component has no `Optional[Robot]` field).
  - Implementation: `MotionStudio/core/components/three_point_calibration.py`.

- MotionStudio.core.components.path_mission_component.PathMissionComponent (Component)
  - Type name: `"PathMission"`; category: `"Path generation and planning"` (Add Component → Path generation and planning).
  - Job-side orchestrator: binds `Optional[PathComponent]` + `Optional[Robot]`, then a play routine `movel`s each path waypoint and runs that waypoint's `PathAction`s (Set Output, Wait Time, Wait Signal).
  - Fields: `path`; `robot`; `mission_status` (`Idle` / `Running…` / `Stopping…`, restored to Idle); `segment_name` (unique PathGeneration `Feature.name` for **Run Segment Mission**).
  - Buttons: **Run Path Mission** / **Run Segment Mission** / **Stop Path Mission** (main Inspector). Run requires a connected Robot and a **RobotDescription** resolved from the UniversalRobot `robot` field, the PathGeneration Export Robot binding, or a RobotDescription sibling on the controller entity. Poses: PathGeneration local → world → robot base (`get_waypoints_in_robot_frame`); Euler deg → rotvec deg for `set_move_target`. Each waypoint is a discrete `move_to_target` (`movel`); no `movep` / CNT blend. Per-segment `path.speed * speed_multiplier` and `path.acceleration` are copied onto the mover before each move. Set Output uses `set_io_target` + `apply_io` (job `set_io`). Wait Signal uses `set_io_target` + `read_io` (same job, read path) so Standard / Configurable / Tool Out are polled, not written. Wait Time uses play-routine `delta_time`. Wait Signal with `timeout_s == 0` waits forever; a non-zero timeout that expires logs and **continues** (same as exported URScript, not a mission `FAIL`). **Run Segment Mission** runs only the unique named segment (waypoints + that segment's actions); empty / missing / duplicate names `FAIL`. Stop calls `stop_robot`, stops the play routine, notifies `(False, "cancelled")`. In-flight Apply I/O is not cancelled.
  - TCP/Sequencer: `_ASYNC_HANDLERS` `("PathMission", "run_path_mission")` and `("PathMission", "run_segment_mission")` wait on `add_mission_listener`; `cancel_attr="stop_path_mission"`. Whole-mission timeout is `prefs.tcp_timeout_s`.
  - Viewport: while Running, `on_viewport_draw` marks the current waypoint world position. Console: `PathMission: waypoint N/M → movel base=(x, y, z) mm`, `PathMission: action Set Output / Wait Time / Wait Signal (...)`, `PathMission: <kind> FAILED — <message>`.
  - Implementation: `MotionStudio/core/components/path_mission_component.py`.

- MotionStudio.core.hardwares.hardware_runtime.HardwareRuntime
  - Owned by `Scene` (`scene.hardware_runtime`). Maps `{entity_id}:{type_name}` → live `HardwareSession` (`shutdown()`). Only *running* workers are registered, not every hardware component in the scene.
  - `shutdown_all()` is cooperative (stop + `QThread.wait` up to 8 s); never `terminate()`. **New Project and Open Project call it first** from `MainWindow._clear_scene_state` before entities are deleted, so hardware worker threads (UR, Mechmind, …) are asked to exit before the new scene is applied. The same path runs from `MainWindow.closeEvent` and `QApplication.aboutToQuit`.
  - Sessions make `shutdown()` idempotent so entity teardown after `shutdown_all` is a no-op. UniversalRobot RUN / Move To Target waits are interruptible (`_cancel` via STOP or Disconnect), so a script in progress does not block project load the way a native `sendCustomScriptFile` hang used to.

- MotionStudio.core.components.path_component.PathComponent (Component)
  - Type name: "PathGeneration"
  - Properties:
    - segments: List[Feature]  # user-facing: path segments; `features` property is a backward-compatible alias
    - export_format: `"URScript"` (only option today) — robot program language for export
    - robot: optional `RobotDescriptionComponent` reference — robot base frame used when exporting coordinates
    - export_path: `FilePath(..., save=True)` — destination file for **Export...**; blank asks with a Save dialog
    - default_actions: List[PathAction]  # template of digital I/O actions copied onto each newly created segment
  - Serialization: to_dict()/from_dict() round-trips path data.
  - Direction indicators: `on_viewport_draw()` issues one `Debug.draw_cone` (green, opacity 0.2, base diameter = `SEGMENT_DIRECTION_CONE_SIZE` = 15.0, height = 2× diameter) at the first waypoint of every segment with more than 2 waypoints. The cone's axis points toward the segment's second waypoint (both transformed into world space), giving a per-segment travel-direction hint. Class constants `SEGMENT_DIRECTION_CONE_SIZE`, `SEGMENT_DIRECTION_CONE_COLOR`, `SEGMENT_DIRECTION_CONE_OPACITY` control the appearance.

- MotionStudio.core.components.collider_component.ColliderComponent (Component)
  - Type name: "Collider"
  - Properties:
    - collider_from_mesh_component: bool (default True) - when true, collision uses the entity's `MeshComponent` geometry.
    - collider_mesh_path: str (used when `collider_from_mesh_component` is false) - mesh file path for dedicated collider geometry.
    - render_collider: bool (default False) - when true, draw collider geometry in the 3D view **only while the entity is selected**.
    - repaint_on_collision: bool (default True) - renderer-only hint. When true the entity's mesh is tinted red while colliding; when false the visual is suppressed. Does **not** gate the runtime `collided` flag or the `entity_collision_changed` signal.
    - collided: bool (default False, hidden in Inspector and from serialization) - runtime flag set by the `CollisionSystem` whenever this entity is intersecting another collider this frame. Always reflects real collision state regardless of `repaint_on_collision`, so custom components can poll it (or subscribe to `entity_collision_changed`) to react to collisions even with the visual overlay disabled.
    - use_collision_group: bool (default False) - when true, this collider is part of a named group (see `collision_group_name`). Grouped colliders appear as **one row** in the global Physics matrix; per-link pairs are edited in the group sub-matrix popup.
    - collision_group_name: str (default `""`) - shared key for the group in global and internal collision matrices. Required when `use_collision_group` is true.
- Usage: attach to any entity that should participate in the scene-wide collision system. `CollisionSystem.check_all()` is group-aware: internal pairs within a group, global pairs between groups/ungrouped entities, and legacy ungrouped↔ungrouped pairs.
  - Serialization: to_dict()/from_dict() round-trips the boolean.

- MotionStudio.core.components.point_cloud_collider_component.PointCloudColliderComponent (Component)
  - Type name: `"PointCloudCollider"`; category: `"Collision"`
  - Sibling of `Collider` for **PointCloud** entities. Occupancy voxels are built from the sibling `PointCloudComponent` (`effective_file_path()` + `scale` — the baked downsample LOD when `use_downsampled_cloud` is on). Inspector dropdown **`collider_type`**:
    - **`cubes`** (default): occupied cells → cube-soup triangle mesh → FCL `BVHModel`. Voxels are in cloud-local space and **rotate with the entity** via live `fcl.Transform` (same as mesh colliders).
    - **`octomap`**: points are transformed by the entity **world pose** at build time, then serialized as OccupancyOcTreeBase binary and loaded as python-fcl `OcTree`. Cells stay **world-axis-aligned**. With `auto_update`, occupancy rebuilds when cloud data **or** world pose changes; otherwise click **Update collider**. Narrow-phase uses `fcl.collide(OcTree, BVH)` (and OcTree–OcTree); no triangle conversion on the FCL path.
  - VTK Physics backend: octomap **falls back** to cube-soup polydata from the same occupied cells. Octomap query speed is an **FCL** feature.
  - Properties:
    - `collider_type`: `"cubes"` | `"octomap"` (default `"cubes"`).
    - `resolution_mm`: occupied voxel size in engine millimetres (default `10`).
    - `max_occupied_cells`: unique occupied voxels used for collision (cubes and octomap leaves; default `200000`, Inspector max `1000000`). Status includes `truncated` when the cap is hit.
    - `max_vis_cells`: cyan selected wireframe cap (default `200000`, Inspector max `1000000`). Independent of FCL; changing it does not rebuild occupancy.
    - `auto_update`: bool (default `false`). When true, occupancy rebuilds on a worker whenever the PointCloud file changes (Capture / Downsample) or, in octomap mode, when world pose changes. When false, occupancy stays idle until **Update collider**.
    - `render_collider`: cyan voxel wireframe while the entity is selected (capped independently of FCL, vis overlay from occupied leaves). In octomap mode the overlay is already in world millimetres — the actor user matrix is identity so cubes are not double-transformed.
    - `repaint_on_collision`: tints the **point-cloud actor** red while colliding (does not gate `collided`).
    - `use_collision_group` / `collision_group_name`: same Physics matrix grouping as `Collider`.
    - `status` (read-only): e.g. `Ready (12480 voxels, cubes)`, `Ready (12480 leaves, octomap)`, `Needs PointCloud`, `Cloud empty`.
    - `collided`: hidden runtime flag, same semantics as `ColliderComponent.collided`.
  - Inspector button **Update collider** starts a worker occupancy rebuild from the current cloud (and world pose, in octomap mode). Use this after Scan Mission when `auto_update` is off. Occupancy never runs on the GUI thread.
  - Fingerprint includes `collider_type`, cloud **effective** path, `PointCloud.scale`, `resolution_mm`, `max_occupied_cells`, `auto_update`, and a build generation (bumped by **Update collider**). Live `PointCloud.content_revision` (Capture / Downsample; file mtime is not watched) is included **only when `auto_update` is on**. **Octomap** also includes entity world pose (translation + rotation + scale). Cube mode does **not** include pose. `max_vis_cells` is vis-only and is not part of the occupancy fingerprint.
  - If both `Collider` and `PointCloudCollider` are present, `PointCloudCollider` is the single collision body. Do not attach both.
  - Registers in `CollisionSystem.collider_entities()` and the Physics matrix like mesh colliders.
  - Motion planning: octomap snapshots **octree bytes** on the main thread (not a live `fcl.OcTree`); the worker constructs `fcl.OcTree` and collides at identity pose. If octomap geometry is not ready, Plan Motion status is `octomap not ready`.

- MotionStudio.core.components.measure_distance_component.MeasureDistanceComponent (Component)
  - Type name: `"MeasureDistance"`; category: `"Measure"`
  - Fields: `point_a` / `point_b` (`QVector3D` with `VertexPick` — stored in the owner entity's local frame) and a read-only `distance` string (`"123.45 mm"`).
  - Distance is the world-space length between the two points (engine units are millimetres). `on_entity_changed()` refreshes the string after Inspector / pick edits.
  - Overlay: while the owning entity is selected, `on_viewport_draw()` draws point markers, the connecting line, and a midpoint millimetre label via `Debug.draw_*`.

- MotionStudio.core.components.measure_angle_component.MeasureAngleComponent (Component)
  - Type name: `"MeasureAngle"`; category: `"Measure"`
  - Fields: `point_a` / `point_b` / `point_c` (`VertexPick` vectors — angle **ABC** at B) and a read-only `angle` string (`"45.67°"`). Degenerate input (zero-length arm or colinear points that cannot form an arc) shows `"—"`.
  - Overlay: while the owning entity is selected, draws point markers, arms BA and BC, a polyline arc of radius `0.25 * min(|AB|, |BC|)`, and a degree label just outside the arc midpoint.

- MotionStudio.core.components.robot_description_component.RobotDescriptionComponent (Component)
  - Type name: "RobotDescription"
  - Attached to the **robot root** entity after URDF import.
  - Stores the full imported model: `urdf_path`, `robot_name`, `root_link`, `tool_link`, optional `analytic_solver_path`, `joint_positions` (rad), `links`, `joints`, `transmissions`, `actuated_joint_names`.
  - Inspector: metadata fields plus per-joint sliders; **Reset Pose** sets actuated joints to zero and runs FK. While `RobotIK` is enabled with a Target, joint edits / Reset Pose snap the Target to the TCP/`tool_link` pose (see **Manual joint edits** under Inverse Kinematics).
  - FK: `MotionStudio.core.robot.robot_kinematics.update_robot_fk` writes each child link's `TransformComponent` from `joint_positions`.

- MotionStudio.core.components.robot_ik_component.RobotIKComponent (Component)
  - Type name: "RobotIK"
  - Attached to the **robot root** entity alongside `RobotDescription`.
  - Fields: `enabled`, `target` (entity reference to a `TransformComponent`), `tcp` (optional custom Tool Control Point entity reference), `backend` (`"analytic"` default, or `"ikpy"`), `analytic_solver_path` (optional per-component solver path override), `solve_hz`, `position_tolerance_m`, `orientation_tolerance_rad`, `max_iterations`.
  - Drives 6D pose tracking: when the target (or robot base) moves, IK solves and writes `RobotDescription.joint_positions`, then runs FK. Inspector exposes **Solve IK Now** (TCP / logs `PASS` only if that solve **converged**) and **Regenerate Analytical IK**. See **Inverse Kinematics** below.
- MotionStudio.core.components.motion_planner_component.MotionPlannerComponent (Component)
  - Type name: "MotionPlanner"
  - Attach to a Job entity (typically alongside `PathGeneration`). Ungrouped **backend** (`"ompl"` default, or `"imove"`) sits at the top of the Inspector. **Bindings** gear: `path` / `robot`. **Planner settings** gear: shared Process knobs (`process_sample_spacing_m`, `max_joint_jump_rad`, `transition_joint_speed_rad_s`); **OMPL** section (`ompl_planning_time_limit_s`, `ompl_simplify_path`, `ompl_rrt_edge_resolution_rad`); **iMOVE** section (`imove_algorithm` = `RRT-Connect` | `RRT*`, time/simplify/edge, `imove_goal_bias`, `imove_workspace_bound_diameter` = job-AABB-diagonal multiple for the TCP proximity sphere). **Preview** gear: playback + planned-path overlay color/width.
  - **Plan Motion** / **Clear Trajectory** buttons (Planner settings). Persists a joint-space `JointTrajectory`. Play Mode streams joints onto the bound robot. See **Motion Planning**.
- MotionStudio.core.components.gp_leak_path_generator_component.GPLeakPathGeneratorComponent (Component)
  - Type name: "GPLeakPathGenerator"
  - Attach to the Gas Panel entity alongside the leak-port `PathGeneration`. Fields: `generate_path_into`, `segment_name`, read-only `reach_array` (last Generate segment comma-separated `1`/`0` mask), `default_tcp_transform`; Inspector group **Planner Settings** (`approach_height_mm`, `offset_from_port` default `5` mm along −TCP +Z so the touch waypoint stops short of the port, `cone_tilt_deg`, `samples_per_port`, `position_offset_radius_mm`, `position_offset_samples`, `preview`); **Action at leak port** (`leak_port_actions`, shared PathAction list editor — cloned onto each leak-port touch waypoint); read-only `status`. Buttons: **Generate leak path** / **Generate segment** / **Cancel generate**. **Generate segment** `PASS` JSON `return` is that same `1`/`0` mask (and is stored on `reach_array`). See **GP Leak Path Generator**.

- MotionStudio.core.components.urdf_link_component.UrdfLinkComponent (Component)
  - Type name: "UrdfLink"
  - Marker on each imported link entity (`link_name`, `parent_joint_name`). Link `TransformComponent` fields are read-only in the Inspector (FK-driven).

### URDF import

- Menu: **File → Import URDF...** (requires an open project with `scene.project_root` set).
- Parser: `MotionStudio/core/robot/urdf_parser.py` (stdlib XML; `.xacro` not supported — use a flattened `.urdf`).
- Assets copied to `<project>/robots/<robot_name>/` with project-relative mesh paths.
- Entity hierarchy: robot root → `root_link` chain matching URDF parent/child joints (one entity per link).
- Units: joint origins in URDF are metres → `TransformComponent` positions in **mm**; URDF collision STLs (metres) use `ColliderComponent` with `collider_from_mesh_component=False`, dedicated `collider_mesh_path`, and **`scale=1000`**.
- **Package folder**: `RobotDescription.package_folder` points at the ROS package root (e.g. `.../ur_description`, the folder that contains `meshes/`). Set via Browse in the Inspector, then click **Reload Meshes** to resolve `package://` URIs and assign `MeshComponent` / `ColliderComponent` on all links. On import, this is auto-filled from the source URDF location when possible. Re-importing a URDF that already lives in `<project>/robots/<name>/` (next to the localized `package/meshes/` copy) uses that `package/` folder as the package root so `package://` URIs still resolve.
- Visual meshes: routed through `MotionStudio.core.robot.urdf_visual_assets` (calls `mesh_assets.convert_scene_to_glb` — same DAE→GLB path as Hierarchy import: Collada unit scaling, material sidecar, mm coordinates). URDF `<origin>` is baked in metre space, then the standard converter runs. Re-import or **Reload Meshes** to refresh assets. DAE conversion uses **trimesh + pycollada**; the frozen app must ship `collada/resources/schema-1.4.1.xml` (see **Build exe** / `build.spec` `collect_all("collada")`) or Import URDF fails with a missing-schema `FileNotFoundError` under `_MEI*`.
- Undo: `ImportUrdfCommand` removes the robot root subtree on undo.
- Scene load: `_post_load_robot_kinematics` resolves link entity ids and applies FK.
- **Collision grouping (automatic):** each link `ColliderComponent` gets `use_collision_group=True` and `collision_group_name=<robot_name>`. Adjacent link pairs (connected by a URDF joint) are pre-disabled in the group's internal matrix via `apply_urdf_collision_group_defaults`. The global Physics matrix then shows one row for the robot instead of one row per link.
- **IK setup (automatic):** a `RobotIK` component is added to the robot root, and a `TCP` entity (identity offset) is created as a child of the `tool_link` entity and referenced as the component's `tcp`. The arm is IK-ready immediately — the user only assigns a **Target** (and may reposition the `TCP` entity to the real tool tip). See **Inverse Kinematics**.


## Inverse Kinematics

Robot IK lets an end-effector follow a movable target pose. It is built as a pluggable solver layer (the `IKBackend` protocol) so backends swap without touching the ECS or UI. Two backends ship today — **Analytic** (ssik, default) and **IKPy**. There is **no automatic fallback** between them: a misconfigured or unavailable backend raises `IKBackendError` (printed for continuous tracking; shown by **Solve IK Now**).

**Workflow**

1. Import a URDF robot. This already creates a `RobotDescription` on the root, link entities with FK from `joint_positions`, **and** an IK setup: a `RobotIK` component on the root plus a `TCP` entity under the `tool_link` referenced as `RobotIK.tcp` (adding `RobotIK` manually is only needed for non-URDF rigs). On import, MotionStudio also tries to generate `<urdf_stem>_analytic_ik.py` via `ssik build` and stores it on `RobotDescription.analytic_solver_path`.
2. Create any entity with a `TransformComponent` to act as the goal, and assign it to **Target** in the Inspector (the standard entity-reference picker; serialized as an `entity_id` and re-resolved on load).
3. Pick the **backend** in the Inspector dropdown (`analytic` or `ikpy`). Default is `analytic`.
4. Move or rotate the target with the gizmo. The controlled point (the `TCP` entity, or `tool_link` if `tcp` is cleared) tracks the target's full 6D pose.

**Custom Tool Control Point (TCP)**

By default IK drives the URDF `tool_link` frame to the target. To control a different point — e.g. the tip of a torch/gripper that is not a URDF link — assign the optional **TCP** field on `RobotIK`:

1. Create an entity with a `TransformComponent` and parent it under the tool-link entity (so it is rigidly attached and moves with the arm via FK).
2. Position/orient it at the real tool tip using the gizmo.
3. Assign it to **TCP** on the `RobotIK` component.

Now IK drives that point to the target instead of `tool_link`. The system captures the rigid offset `T_ee_tcp = inv(world(tool_link)) · world(tcp)` (translation mm → m) and aims the solver's end-effector at `T_goal · inv(T_ee_tcp)`, so `tool_link · T_ee_tcp == target`. The offset is recomputed per solve from live transforms, so re-positioning the TCP entity (which also re-triggers a solve) immediately updates the controlled point. The TCP need not be a child of the tool link, but it should be rigidly attached to it for the offset to stay meaningful across poses.

**How it solves**

- `RobotIKSystem` (`MotionStudio/core/robot/ik/robot_ik_system.py`) is owned by the `Scene` (mirrors `collision_system`, reachable via `scene.robot_ik_system`). It subscribes to `scene.events.entity_transform_changed` and, for each event, evaluates every enabled `RobotIK` component with `_affects(changed_entity_id)` — so **multiple robots may share one target** and each matching robot gets its own solve enqueued.
- When the target — or the robot base, TCP entity, or any of their ancestors — moves, each affected robot builds an `IKSolveRequest` on the main thread: it reads the target pose in the robot base frame (`ik_frames.goal_in_base_frame`, converting translation **mm → m**), seeds the current joint angles, resolves the absolute URDF path, and copies the parsed joint records + `root_link`.
- The request is handed to a background `QThread` worker. Requests are **latest-wins per robot** (not global), so a fast drag only solves the most recent goal for that arm; `solve_hz` caps the submit rate per robot (default 20 Hz). One backend instance is created per backend name and reused across solves. Only the **selected** backend runs — there is no fallback chain. Hard failures (unknown backend, missing dependency, analytic solver path not configured) raise `IKBackendError` and are printed; unreachable poses return `success=False` without applying joints.
- The result is delivered on the main thread: `solved` is connected with `Qt.QueuedConnection` to a `QObject` relay created on the GUI thread. `RobotIKSystem` itself is not a `QObject`, so a bare Python slot would run inside the worker and write link `QQuaternion`s while the viewport reads them (access violation while jogging the Target). Only **successful** solves are applied (partial / non-converged numerical results are discarded to avoid drift). The system sets `RobotDescription._ik_updating`, writes the solved angles into `joint_positions`, calls `update_robot_fk`, then clears the flag. The Target axes overlay is drawn only while the Target or the robot entity is selected.

**Backends** (`RobotIKComponent.backend`, switchable at runtime)

| Backend | Module | Solver | Install |
|---------|--------|--------|---------|
| `analytic` (default) | `analytic_backend.py` | Loads an ssik-generated closed-form module (`solve`); nearest-to-seed for continuous tracking | `pip install ssik` (runtime); `pip install "ssik[urdf]"` for URDF→module generation |
| `ikpy` | `ikpy_backend.py` | `Chain.inverse_kinematics_frame(..., orientation_mode="all")` (full 6D, least-squares) | `pip install ikpy` — pure Python, all platforms |

- **AnalyticIKBackend** loads `RobotDescription.analytic_solver_path` (or the component override). At URDF import, `urdf_importer` looks for `<urdf_stem>_analytic_ik.py` next to the URDF; if missing it runs ssik build (requires `ssik[urdf]`). In **dev**, that is `python -m ssik.cli build ...`; in a **frozen** PyInstaller app it calls `ssik.cli.main([...])` **in-process** — never `sys.executable -m ...`, which would re-launch the GUI. Generation failures are non-fatal for import, but selecting `analytic` without a solver path raises at solve time. **Regenerate Analytical IK** on `RobotIK` re-runs that build and shows a success/failure dialog (needed because the exe is windowed with no console). Continuous teleop requests only the nearest-to-seed branch (`max_solutions=1`). Set `IKSolveRequest.enumerate_all_solutions=True` to fill `IKSolveResult.all_solutions` with every FK-verified branch (used by motion planning when a continuous seed fails).
- **IKPyIKBackend** builds the kinematic chain `root_link → tool_link` directly from the joint records carried on the request (already parsed by the importer, in metres). It never re-reads the URDF file, so `package://` mesh paths are irrelevant; fixed joints are kept as inactive links so only their origin transform applies. Chains are cached per `(urdf_path, root_link, ee_link)`.
- The factory `make_ik_backend(name)` / `solve_ik_request(...)` (in `ik/backend_runtime.py`) construct and run exactly one backend. Unknown names (`ikfast`, `pinocchio`, …) raise `IKBackendError`.

**Frames and units**

| Layer | Position | Joint angles |
|-------|----------|--------------|
| Engine (ECS) | mm, `world_matrix` | rad in `joint_positions` |
| URDF / solver | metres, 4×4 SE3 | rad |

Conversion happens only at the IK boundary; FK math is unchanged.

**Reentrancy** — `RobotDescription.on_entity_changed` skips FK while `_ik_updating` is set (IK already ran it), and `RobotIKSystem` ignores transform events emitted while it is applying a solution (`_applying_ik`). Together these stop FK and IK from fighting each other. FK link writes run inside `scene.batch_transform_events()` (per-link `TransformComponent` setters do not emit while `scene.transform_events_batched()` is true); after FK, `update_robot_fk` emits **one** `entity_transform_changed` on the robot root (VTK syncs the subtree recursively) and calls `collision_system.request_collision_update()` so link motion does not spam per-link transform signals.

**Manual joint edits (FK drives Target)** — Editing joint sliders (or **Reset Pose**) while `RobotIK` is enabled used to lose the pose: FK updated the links, `_affects` treated the robot-root transform signal as a base move, and IK re-solved toward the *old* Target. `RobotIKSystem.apply_fk_from_joints` now runs FK under `_applying_ik`, then snaps the Target’s world pose to the controlled frame (TCP if set, otherwise `tool_link`). Subsequent Target moves still drive IK as before.

**Performance** — Continuous IK only runs for robots whose target/base/TCP subtree actually changed (`_affects`). Collision recalc from transform/FK bursts is coalesced (see **Collision System**); avoid sharing one target across many robots if you need all arms to track the same pose in real time, since each arm still runs its own solver at `solve_hz`.

**Threading note** — All ECS and VTK mutation stays on the Qt main thread; only the solver math runs on the worker, which touches just its own model/chain cache.

**Dependencies** — Analytic (`ssik`) and IKPy ship in `requirements.txt`. Analytic artifact generation needs `pip install "ssik[urdf]"` (see `requirements-robot.txt`). Backends do not fall back to each other: if the selected backend is missing or misconfigured, `IKBackendError` is raised.

**Adding cuRobo IK (future)** — Implement the `IKBackend` protocol (`is_available` / `solve` / `invalidate_cache`) in a new `CuRoboIKBackend`, add it to `make_ik_backend` in `ik/backend_runtime.py`, and select it via `RobotIKComponent.backend = "curobo"`. The `IKSolveRequest` already carries the URDF path, joint-name list, and chain records, and the async worker queue keeps GPU calls off the main thread, so no other layer changes.


## Motion Planning

Job-level joint-space planning lives beside PathGeneration. It is a pluggable planner layer (the `MotionPlannerBackend` protocol) so backends swap without changing the component or the Simulate play routine.

**Workflow**

1. Create / select a Job entity with `PathGeneration` (ordered segments).
2. Bind Export → **Robot** on PathGeneration (or set Robot on MotionPlanner).
3. Add **MotionPlanner** on the same Job entity.
4. Pick **backend** at the top of MotionPlanner (`ompl` default, or `imove`). For imove, open **Planner settings** and choose **iMOVE → Algorithm** (`RRT-Connect` or `RRT*`). Click **Plan Motion**. The editor shows the same loading overlay as Open Project / Import URDF; planning runs on a background thread in three steps:
   1. **Verify process segments** — densify each Cartesian segment; enumerate analytic IK solutions for sample 0 (nearest-to-seed first for ordering only); for each start branch, re-trace the whole segment with continuous edge-aware IK. Sample 0 is **point-only** (current robot pose does not have to reach it by a straight joint edge). Mid-segment collision, reach failure, or a sudden config change (`‖Δq‖ > max_joint_jump_rad`) aborts that start branch and retries the next. Exhausted start branches → fail.
   2. **Transitions** — joint-space planning for (a) **approach**: current pose → first process sample, and (b) between stored segment endpoints (active backend’s edge resolution + time limit). Backend `ompl` uses OMPL RRT-Connect; `imove` uses the selected algorithm (`RRT-Connect` or Informed `RRT*`).
   3. **Optimize transitions** (when simplify is on) — reserve ~25% of the transition time budget (min 0.5 s) for post-RRT pruning: greedy farthest-vertex, then ~100 random C-space shortcuts (direct free chord between non-adjacent waypoints deletes intermediates), then partial/Steiner polish.
   - Validity checks run against an **offline collision snapshot** (no viewport posing, no Qt/VTK during sampling).
   - **Project log** (`logs.txt`): on Plan Motion, writes `execute: Starting motion planner (ompl|imove[/algo])`; on success writes `execute: OK — … traj <playback_s>s, planned in <wall_s>s …` where **planned in** is wall-clock from Plan Motion press to completion (not trajectory playback duration); failures include the same wall-clock note. Console RRT validity prints include per-transition `workspace_rejects` (and plan-total).
5. Click **Simulate** with **Enabled Playback** on — an edit-mode play routine streams the stored joint trajectory onto `RobotDescription.joint_positions` via FK (and disables `RobotIK` while simulating). **Stop simulate** cancels. This does not enter Play Mode.

**Planned path overlay** — After a successful plan (and when loading a scene with a stored trajectory), `MotionPlannerComponent.on_viewport_draw()` evaluates TCP poses along the joint timeline via FK (`trajectory_preview.trajectory_tcp_path_base_mm`), transforms them into world space with the robot base, and draws them with `Debug.draw_polyline` using inspector fields `planned_path_color` (`QColor` / `ColorField`) and `planned_path_width` (float). Toggle with inspector **Show Planned Path**. Clear Trajectory removes the overlay.

**Architecture**

- `MotionPlannerComponent` (`MotionStudio/core/components/motion_planner_component.py`) — Job entity config, persisted `JointTrajectory`, Plan/Clear buttons, **Simulate** / **Stop simulate** play routine, planned TCP debug polyline.
- `MotionPlanningSystem` (`MotionStudio/core/robot/planning/motion_planning_system.py`) — owned by `Scene` (`scene.motion_planning_system`); builds a plain-data `PlanRequest` (waypoints in metres/radians, collision snapshot) and runs the backend on a `QThread` worker.
- `plan_pipeline.plan_segments_with_transitions` — shared process-IK + stitch; backends only supply a transition function.
- `PlanningCollisionWorld` — default collision oracle: snapshotted on the main thread before planning; worker queries FCL only. `LiveViewportCollisionOracle` is diagnostics/tests only.

**Backends** (`MotionPlannerComponent.backend`)

| Backend | Module | Transitions | Install |
|---------|--------|-------------|---------|
| `ompl` (default) | `ompl_backend.py` | OMPL RRT-Connect | `pip install ompl` (Linux/macOS); Windows: `conda install -c conda-forge ompl` |
| `imove` | `imove/` | Built-in numpy `RRT-Connect` or Informed `RRT*` (Inspector dropdown) | None (numpy only) |

Unknown names raise `MotionPlannerError` (no silent fallback). Future algorithms under `imove/` (PRM, etc.) can extend the iMOVE algorithm dropdown without a new top-level backend name.

**imove (3-step)** — (1) Process segments: exhaust start IK branches with full segment re-traces + `max_joint_jump_rad` gate. (2) Transitions via `imove_algorithm`: **RRT-Connect** (`imove/rrt_connect.py`, bidirectional multi-attempt) or **RRT*** / Informed RRT* (`imove/rrt_star.py`, rewiring + ellipsoid sampling after the first path). Uses the iMOVE section’s time budget, edge resolution, and `imove_goal_bias`. Samples whose TCP FK lands outside the **workspace proximity sphere** (center = job waypoint AABB center; diameter = `imove_workspace_bound_diameter` × AABB diagonal; radius expanded so each transition’s start/goal TCP stay inside) are rejected before BVH/FCL (`imove/workspace_limit.py`). (3) Optimize: greedy farthest-vertex + iterative random + **partial/Steiner** shortcutting when iMOVE simplify is on. Densify/playback use the same edge spacing. OMPL maps its own absolute spacing to a state-validity fraction of the joint box.

**Wrap-aware playback** — Continuous / full-range joints use the same short-arc metric for RRT validity, transition densify, timing, and Simulate `sample_at` (mask stored in `JointTrajectory.meta['wrap_mask']`). That prevents the classic bug where the planner validates the pink short chord while densify/playback lerps the long blue way around ±π.

**Collision checking (isolated from viewport)** — Process IK and imove/OMPL transitions call ``is_state_valid`` on a `PlanningCollisionWorld` built by `build_planning_collision_world` on the **main thread** before the worker starts:

1. **Same scene-wide CollisionMatrix** — enabled pairs come from `partition_colliders` + `all_matrix_pairs` (identical to live Physics pairing rules).
2. **Same geometry sources** — `CollisionSystem._get_geometry` (mesh verts from `_get_polydata` / cube voxels, or octomap binary bytes).
3. **Same transforms** — static bodies freeze live `_world_transform` at snapshot; articulated bodies use `T_world_base @ FK(q) @ T_link_local` where `T_link_local` is the relative offset from live world matrices at snapshot (URDF links and attached tool/TCP colliders).
4. **Worker-only queries** — each sample runs FCL collide with decompose/bake matching `FclCollisionBackend.pair_intersects`. **No** `apply_solution`, **no** `CollisionSystem.check_all`, **no** Qt signals, **no** VTK renders during sampling.

On plan failure, the main thread may pose `failure_q` once for debugging; that is separate from the sampling path.

Articulated geometry:

- URDF link colliders move with off-scene FK.
- **Attached colliders** parented under a URDF link (e.g. a mesh+Collider child of `tool0` / TCP) also move with that link via a snapshotted `T_link_local` offset.

Requirements:

- `python-fcl` installed (`requirements.txt`).
- Obstacles / tools need a `ColliderComponent` or `PointCloudColliderComponent` with resolvable geometry.
- Disabling a pair in the Physics matrix excludes it from planning the same way as live collision.
- Process segments validate **joint-space edges** between successive IK samples inside a segment. Segment entry (including the first waypoint) is point-only; RRT handles approach from the current pose and gaps between segments. On mid-segment failure the planner re-traces from the next start IK branch until branches are exhausted; `max_joint_jump_rad` rejects sudden config changes.

Snapshot summary is appended to Plan Motion status (`robot_links=… attached=… world_colliders=… pairs=…`).

**Dependencies** — Analytic IK (`ssik`) is required for process-segment tracing. OMPL is optional (needed only for `backend=ompl`). Use `imove` on Windows pip venvs without conda. See `requirements-robot.txt`.

**Adding CuRobo planning (future)** — Implement `MotionPlannerBackend`, register in `planning/backend_runtime.py`, extend `MotionPlannerComponent.backend`. Reuse `PlanRequest` / `PlanResult` / `JointTrajectory`.


## TCP Command Server

A third-party app (e.g. a sequencer) can drive Motion Studio over TCP: `RUN` presses an Inspector button, `EDIT` writes an Inspector field, `GET` reads one, `WAIT` pauses for a number of seconds, `OPEN` loads a project folder, `PLAY` / `STOP` click the Sequencer ribbon. The module is `MotionStudio.core.remote`:

- `protocol.py` — `parse_command()` / `format_request()` / `format_response()` (wire format below). Inspector right-click copy uses `format_request` so the clipboard line is exactly what the server parses.
- `dispatcher.py` — `RemoteCommandDispatcher(QObject)`; resolves entity → component → button/field and applies it **on the Qt main thread**. `execute()` takes a `threading.RLock` so TCP clients and the Sequencer dock cannot interleave scene mutations. `WAIT` / `PLAY` / `STOP` skip that lock so ribbon Stop (and TCP `STOP`) can interrupt an in-flight step.
- `value_parser.py` — `coerce_value()` / `format_field_value()`; casts an `EDIT` payload to the field's declared type, and serializes a live value for `GET` in the same grammar.
- `tcp_server.py` — `TcpCommandServer`; raw sockets + daemon threads (not `QTcpServer`, which could not block a connection without freezing the editor). Also mirrors every request/reply into `logs.txt`.

**Wire format** — one UTF-8 line per message, `\n` terminated, connection stays open for further commands.

```
request   RUN,<entity_name>,<component_type_name>,<function_name>
          EDIT,<entity_name>,<component_type_name>,<property_name>,<value>
          GET,<entity_name>,<component_type_name>,<property_name>
          WAIT,<seconds>
          OPEN,<project_folder_path>
          PLAY
          STOP
response  {"status": "PASS", "return": ""}                        succeeded, nothing to report
          {"status": "PASS", "return": "150,0,25"}                succeeded with a return value
          {"status": "FAIL", "return": "entity not found: Cube"}  failed, with the reason
```

- **Requests are CSV, replies are JSON.** Every reply from every verb is one JSON object built by `format_response(ok, output)` — the single choke point for the response format; nothing else in the app constructs or parses a reply.
- **Both keys are always present.** `status` is `STATUS_PASS` (`"PASS"`) or `STATUS_FAIL` (`"FAIL"`); `return` is always a string, `""` when there is nothing to report, so a client never has to test for a missing key or a missing payload. Constants `STATUS_KEY` / `RETURN_KEY` / `STATUS_PASS` / `STATUS_FAIL` are exported from `MotionStudio.core.remote`.
- `json.dumps(..., ensure_ascii=False)` — the socket is already UTF-8, so status text keeps its em dashes and units instead of turning into `\uXXXX` escapes.
- The verb is case-insensitive and all fields are stripped. A malformed line answers `{"status": "FAIL", "return": "expected RUN,<entity>,<component>,<function>"}` (or the `EDIT` / `GET` / `WAIT` / `OPEN` / `PLAY` / `STOP` equivalent).
- Splitting is bounded — four fields for `RUN` and `GET`, five for `EDIT`, two for `WAIT` / `OPEN`, none for `PLAY` / `STOP` — so **an `EDIT` value may contain commas**: `EDIT,Cube,Transform,position,10,20,30`. A `GET` of that field answers `{"status": "PASS", "return": "10,20,30"}`. Quoting the payload is what makes this unambiguous; the previous `1,10,20,30` form left the client guessing which comma was the separator. `WAIT,<seconds>` is a finite number `>= 0` (`WAIT,1.5`). Duration longer than `tcp_timeout_s` is `FAIL` without sleeping. `WAIT` sleeps on the caller thread and does not take the dispatcher scene lock. `OPEN,<folder>` takes the rest of the line as a path (spaces and commas allowed; wrapping quotes stripped). It runs on the main thread, waits until scene apply + bulk-load finish, and answers `PASS` with the `.scn` file name. Missing folder, no `.scn`, or a load already in progress is `FAIL`. Does not save the current project. TCP/Sequencer OPEN retargets `sequence/` **without** aborting the running program (File → Open still aborts). `PLAY` and `STOP` are bare verbs (extra payload after a comma is `FAIL`). They queue to the main thread without the scene lock, invoke the Sequencer ribbon Play / Stop actions, and `PASS` immediately — they do **not** wait for the sequence to finish. `PLAY` while already running or with no commands is still `PASS`. `STOP` with nothing running is still `PASS`.
- `return` is always a **string**, never a JSON number or boolean, even for numeric or checkbox fields (`"30"`, `"true"`). That is deliberate: it preserves the exact text `EDIT` accepts, so a `GET` → `EDIT` round-trip is lossless.
- **`False` (or `(False, reason)`) is a failure**, not a payload: `status` is `FAIL`. `True` is success with an empty `return` (same as `None`). Anything else is success carrying `str(return_value)`. See `interpret_button_result`.
- `sanitize_output` still collapses newlines. JSON would escape them rather than break framing, but collapsing keeps the mirrored `logs.txt` line readable.

**Resolution rules**

- Entity: exact `Entity.name` match, else `Scene.find_by_id`. Duplicate names answer `FAIL` with `multiple entities named X` — give the sequencer unique names or use UUIDs.
- Component: case/space-insensitive match on `type_name` (`ThreePointCalibration`, `MotionPlanner`, `RobotIK`).
- Function (`RUN`): only methods decorated with `@inspector_button` are reachable (`collect_inspector_buttons`), matched by either method name (`align`) or button label (`Align`, `Plan Motion`). This is the whitelist — arbitrary attributes such as `to_dict` answer `FAIL` with `function not found: …`. Buttons take no arguments, so neither does the protocol.
- Property (`EDIT`): only fields returned by `iter_editable_fields` — the same set the Inspector renders. `Hidden()` fields are invisible (`property not found: …`), `ReadOnly()` and `ConnectionStatus` fields answer `property is read-only: …`, and a property without a setter answers `property is not writable: …` — each as the `return` of a `FAIL`.
- Property (`GET`): the same Inspector-visible set as `EDIT`, **including `ReadOnly()` / `ConnectionStatus`** (e.g. `MechmindScanner.connection_status`). Hidden fields stay unreachable. Success puts the value in `return` using the same grammar `EDIT` accepts (`true`/`false`, `x,y,z`, `#rrggbb`, entity name or `none` for a cleared component reference). An empty string is `""`. Dicts and lists answer `FAIL` with `unsupported field type …`.
- On a successful `RUN` the dispatcher emits `entity_changed` for the entity, the same refresh `InspectorPanel._invoke_inspector_button` does. `EDIT` relies on the component setters' own signals. `GET` does not mutate the scene.
- **Every `RUN` produces a reply, and `PASS` means the action's intent succeeded.** `None` / `True` → `PASS` with `""`. A success payload → `PASS` with that text. `False` or `(False, reason)` → `FAIL`. Exceptions → `FAIL` with `<method> raised: …`. There is no silent `RUN`.

**EDIT value casting** (`value_parser.coerce_value`) — the declared annotation wins; a field with no usable annotation falls back to the current value's runtime type.

| Field type | Accepted value | Example |
| --- | --- | --- |
| `bool` | `true/false`, `1/0`, `yes/no`, `on/off`, `enabled/disabled` | `EDIT,Cube,Mesh,source_material,true` |
| `int` | decimal or `0x` hex | `EDIT,Arm,RobotIK,max_iterations,200` |
| `float` | any number | `EDIT,Arm,RobotIK,solve_hz,30` |
| `str` | verbatim (paths included) | `EDIT,Cube,Mesh,custom_path,models/arm.glb` |
| `Literal[...]` | one of the choices, case-insensitive | `EDIT,Arm,RobotIK,backend,ikpy` |
| `QVector3D` | 3 numbers, comma and/or space separated | `EDIT,Cube,Transform,position,10,20,30` |
| `QColor` | `#rrggbb`, color name, or `r,g,b[,a]` (0-255) | `EDIT,Cube,Mesh,color,#ff8800` |
| `Optional[SomeComponent]` | entity name or UUID owning that component; `none`/blank clears | `EDIT,Arm,RobotIK,target,GoalPose` |

- A `Range(min, max)` annotation is **enforced, not clamped**: out-of-range numbers answer `FAIL` with `value 99999 out of range [1, 120] for solve_hz`.
- Dicts, lists, and other non-scalar fields answer `FAIL` with `unsupported field type …` rather than being guessed at.
- `EDIT` goes through `PropertyChangeCommand` on the editor's `QUndoStack`, so a remote edit appears in the status bar, `logs.txt`, and **Ctrl+Z** exactly like an Inspector edit. Setting a field to its current value is a success that pushes no undo entry.

**Logging** — `TcpCommandServer` writes every request and every reply to the project `logs.txt` through the same `CommandLogger` as undo commands and Plan Motion, under the action `tcp`:

```
[2026-08-27 20:38:30] tcp: 127.0.0.1:49369 > EDIT,UUT,Transform,position,150,0,25
[2026-08-27 20:38:30] tcp: 127.0.0.1:49369 < {"status": "PASS", "return": ""}
[2026-08-27 20:38:31] tcp: 127.0.0.1:49369 > GET,UUT,Transform,position
[2026-08-27 20:38:31] tcp: 127.0.0.1:49369 < {"status": "PASS", "return": "150,0,25"}
[2026-08-27 20:38:33] tcp: 127.0.0.1:49369 > RUN,PlannerJob,MotionPlanner,Plan Motion
[2026-08-27 20:38:36] tcp: 127.0.0.1:49369 < {"status": "PASS", "return": "OK — 120 samples, traj 4.20s …"}
```

- `>` is the received line, `<` is the reply; the `host:port` prefix keeps concurrent clients apart. The two timestamps bracket how long a command actually took.
- The request is logged **on arrival**, before the serialization lock, so a queued or long-running command is visible in the log while it is still executing.
- Everything that produces a reply is logged, including parse failures, timeouts, and `command line too long`. A blank line produces neither a reply nor a log entry.
- `MainWindow` passes its `CommandLogger` into the server, so entries follow the active project root and stop when no project is loaded. An `EDIT` therefore appears twice: once as the `tcp` request/reply pair and once as the `execute` entry from its `PropertyChangeCommand`.
- Clicking an Inspector `@inspector_button` (main Inspector or a Group dock) writes the same reply grammar under the action `inspector`, without a peer prefix. The click is logged immediately; the `<` line is written when the TCP-equivalent reply would have been sent (so **Plan Motion** logs the planner result when planning finishes, not when the button is pressed):

```
[2026-08-30 22:20:01] inspector: PlannerJob.MotionPlanner Plan Motion clicked
[2026-08-30 22:20:04] inspector: PlannerJob.MotionPlanner Plan Motion < {"status": "PASS", "return": "OK — 120 samples, traj 4.20s …"}
[2026-08-30 22:20:10] inspector: Arm.RobotDescription Reset Pose clicked
[2026-08-30 22:20:10] inspector: Arm.RobotDescription Reset Pose < {"status": "PASS", "return": ""}
```

- `CommandLogger.log_event` serializes writes with a lock — connection threads log concurrently with the main thread. Each line also appears on the status bar via `event_logged` (queued to the UI thread).

**Blocking semantics** — the connection blocks until the action finishes; the Qt event loop never does. Commands are serialized by `RemoteCommandDispatcher.execute` (`threading.RLock`), so a TCP client and the Sequencer dock cannot interleave scene mutations. `WAIT` / `PLAY` / `STOP` skip that lock: `STOP` can interrupt an in-flight sequence step the same way the ribbon Stop button does.

- `EDIT` and `GET` reply as soon as the write / read returns. Synchronous buttons reply when the method returns. `False` or `(False, reason)` from a button is a `FAIL` (Align with coincident points, Capture with no Target, Solve IK that did not converge, …).
- **Plan Motion** is asynchronous: `_ASYNC_HANDLERS` in `dispatcher.py` maps `("MotionPlanner", "plan_motion")` to a waiter that registers `MotionPlanningSystem.add_plan_listener(cb)` and holds the reply until `cb(job_entity_id, success, message)` fires; the message is the final `MotionPlanner.status`. If `submit_plan` rejects the setup synchronously (no worker started), the reply is `FAIL` with `planning did not start …`. Add further async actions by extending that table.
- Hardware **Connect** / **Disconnect** / **Capture** / UniversalRobot **RUN** / **Move To Target** / **Apply I/O** / **Set actual configuration** / **Update TCP** / **STOP** are asynchronous the same way: the reply waits for the worker `job_succeeded` / `job_failed` signal. Connect answers `PASS` only when `connection_status` becomes Connected; a refused or timed-out connect is `FAIL` with `Error: …`. UniversalRobot **RUN** answers `PASS` when the program on the controller has stopped; **Move To Target** answers `PASS` when live TCP is at the commanded pose; **Apply I/O** answers `PASS` when the pin write/read finishes; **Set actual configuration** answers `PASS` when live joints are applied to the virtual URDF; **Update TCP** answers `PASS` when the PolyScope TCP offset is written onto `RobotIK.tcp`; **STOP** or Disconnect during RUN / Move To Target cancels that wait (`FAIL` with `Cancelled.`). **Lift to safety** waits until the play routine stops and the robot is collision-free (`PASS`) or gave up (`FAIL` with the reason). **Generate leak path** / **Generate segment** (`GPLeakPathGenerator`) wait until the play routine commits the target path (`PASS`) or fails/cancels (`FAIL`). **Generate segment** `PASS` `return` is a comma-separated `1`/`0` mask (one leak port); the same string is stored on `reach_array` (`GET` that field). **Scan Mission** waits until every grid cell has moved and captured (`PASS`) or the routine fails/cancels (`FAIL`). **V2R Calibration** **Scan** waits until live joints are applied and Capture finishes (`PASS`) or either step fails/cancels (`FAIL`); **Calibrate** is synchronous. **Path Mission** **Run Path Mission** / **Run Segment Mission** wait until the selected waypoints and path actions have run (`PASS`) or the routine fails/cancels (`FAIL`). **Simulate** on MotionPlanner waits until joint playback finishes or is cancelled; **Simulate** on ToolTrace waits until one waypoint pass finishes or is cancelled.
- Inspector `logs.txt` entries use the same completion rule as TCP.
- `MotionPlanningSystem` notifies plan listeners **before** `_apply_failure_q` / `_plan_alert`, so a failure dialog does not delay the TCP reply.
- A command that exceeds `timeout_s` answers `FAIL` with `timeout after Ns: …`; the underlying action is not cancelled.

**Configuration** — `preferences.ini` `[tcp]` section (`enabled`, `host`, `port`, `timeout_s`; defaults `true` / `127.0.0.1` / `5555` / `300`). **Edit → Preferences… → TCP Command Server** exposes Enabled, Port, and Command Timeout; they apply on OK (unlike theme/font, they are not previewed live). `host` is file-only — set it for non-loopback access. `MainWindow` starts the server after the scene exists, restarts it when TCP settings change, and stops it in `closeEvent` (which also shuts down hardware sessions). A port that is already in use only warns in the status bar.

**Caveat** — modal dialogs are left as-is. A button that pops a `QMessageBox` on a validation failure (e.g. `submit_plan` on "Cannot plan while Play Mode is active") blocks the main thread until someone clicks OK, delaying that command and any queued behind it.

Example session:

```
> EDIT,UUT,Transform,position,150,0,25
< {"status": "PASS", "return": ""}
> GET,UUT,Transform,position
< {"status": "PASS", "return": "150,0,25"}
> GET,Cam,MechmindScanner,connection_status
< {"status": "PASS", "return": "Connected"}
> GET,Arm,RobotIK,target
< {"status": "PASS", "return": "GoalPose"}
> RUN,UUT,ThreePointCalibration,Align
< {"status": "PASS", "return": ""}
> EDIT,PlannerJob,MotionPlanner,robot,ur10e_robot
< {"status": "PASS", "return": ""}
> RUN,PlannerJob,MotionPlanner,Plan Motion
< {"status": "PASS", "return": "OK — 120 samples, traj 4.20s, planned in 3.14s — …"}
> RUN,Ghost,ThreePointCalibration,Align
< {"status": "FAIL", "return": "entity not found: Ghost"}
> EDIT,Arm,RobotIK,backend,quantum
< {"status": "FAIL", "return": "expected one of [analytic, ikpy] for backend, got 'quantum'"}
> GET,Ghost,Transform,position
< {"status": "FAIL", "return": "entity not found: Ghost"}
> PLAY
< {"status": "PASS", "return": ""}
> STOP
< {"status": "PASS", "return": ""}
```


## Sequencer

The **Sequencer** dock runs the same `RUN` / `EDIT` / `GET` / `WAIT` / `OPEN` / `PLAY` / `STOP` lines as the TCP Command Server, in order, without opening a socket. It calls `RemoteCommandDispatcher.execute` from a worker thread (the same path TCP uses). Do **not** call `execute()` from the UI thread — it waits on `job.done` while `_run_job` also needs the main thread.

- `MotionStudio.core.sequencer.store` — JSON load/save under `<project>/sequence/`. Each program is `<sanitized-name>.seq`; the dropdown default is `default` → `sequence/default.seq`. `sequence/active.json` stores `{"current": "default"}` so Open Project restores the selection. Names are sanitized like project names (`MainWindow.sanitize_project_name`). Sequences are **not** stored in `project.scn`.
- `MotionStudio.core.sequencer.runner.SequencerRunner` — daemon thread; `parse_command` then `dispatcher.execute` per step; honors `continue_on_fail`. Ribbon **Stop** runs that file's **Stop Sequence** anytime: idle (`stop_only`), during a standalone play routine (`play_routine_runner.stop_all()` first, then `stop_only`), or by interrupting Main. Interrupting Main cancels an in-flight `WAIT` **and** an in-flight async `RUN` that registered a cancel hook (`GPLeakPathGenerator` **Cancel generate**, Lift to safety, Simulate, UniversalRobot **STOP**, Scan Mission **Stop Scan Mission**, V2R Calibration **Scan** (`cancel_scan`), Path Mission **Stop Path Mission**). Then it runs the Stop Sequence (which can still call **Cancel generate** — it is idempotent). A second Stop, project switch, or window close **aborts** remaining lines and does not run the stop sequence (or stops it if it already started). Timeout is `prefs.tcp_timeout_s`. Blank lines are skipped. Malformed lines are `FAIL` and honor Continue on fail.
- `MotionStudio.ui.sequencer.sequencer_panel.SequencerPanel` — hosted as `QDockWidget` **Sequencer** (`SequencerDock`) in `MainWindow._init_docks`, allowed left/right/bottom, default **bottom-left** under Hierarchy. Toggle via **Window → Sequencer**. The top ribbon **Play** / **Stop** run this panel (`play()` / `stop()`); Pause is disabled. The dock toolbar is info | combo | **New…** | **Delete**, then tabs **Main Sequence** / **Stop Sequence**.

JSON shape:

```json
{
  "name": "default",
  "steps": [
    { "command": "RUN,PlannerJob,MotionPlanner,Plan Motion", "continue_on_fail": false }
  ],
  "stop_steps": [
    { "command": "RUN,ur10e_robot,UniversalRobot,Disconnect", "continue_on_fail": true }
  ]
}
```

- **Toolbar:** info button (usage tooltip) | sequence combo | **New…** | **Delete**. New prompts for a name and writes an empty `.seq`. Play / Stop live on the top ribbon. The ribbon status label is **Idle**, **Running \<name\> sequence**, or **Stopping \<name\> sequence**.
- **Tabs:** **Main Sequence** (ribbon Play) and **Stop Sequence** (ribbon Stop: idle, during a play routine, or after Main is interrupted). The command list below the tabs is the active tab. Play always runs Main even if the Stop tab is visible. Files without `stop_steps` load an empty Stop Sequence.
- **WAIT:** `WAIT,<seconds>` (e.g. `WAIT,1.5`) sleeps on the worker thread and does not take the dispatcher scene lock. Duration must be a finite number `>= 0`. Longer than `tcp_timeout_s` is `FAIL` without sleeping. Ribbon Stop cancels an in-flight wait (`FAIL` with `wait cancelled`) **and** in-flight Generate leak path / Lift / Simulate (`FAIL` with `cancelled`), then runs the Stop Sequence.
- **OPEN:** `OPEN,<project folder path>` (e.g. `OPEN,C:\Projects\Cell`) calls `MainWindow.open_project_folder` with no dialogs. Requires a `project.scn` or other `*.scn`. The sequencer step waits until load finishes; later lines run against the new scene (`load_from_project(..., abort_run=False)`).
- **PLAY / STOP:** TCP `PLAY` and `STOP` call `SequencerPanel.play()` / `stop()` — the same as the top ribbon buttons. The reply is `PASS` as soon as the click is invoked, not when the sequence ends. As a sequencer step, `PLAY` is a no-op (the runner is already running). `STOP` as a step is the same as the ribbon: idle or blue ribbon starts the Stop Sequence; during Main it interrupts then runs Stop Sequence.
- **Step list:** serial number, `QLineEdit` (full command string), a checkable icon for **Continue on fail** (stop icon = halt on `FAIL`; skip-forward icon = continue), and a remove control. New Main Sequence rows default the toggle **off**; new Stop Sequence rows default it **on** (so shutdown lines keep going after a FAIL unless you turn it off). Trailing empty row so typing adds steps; empty rows in the middle are skipped at run time. Paste from Inspector copy (`GET,…` / `EDIT,…` / `RUN,…`) is the intended authoring path.
- **Status strip:** current index and last `PASS`/`FAIL` plus `return` text. Stop-sequence steps are labelled **Stop step**.
- While running: combo / New / Delete and row editing are disabled (tabs stay available so you can inspect the other list); the active row is highlighted; rows tint PASS/FAIL after each step. The ribbon stays green with Stop enabled (even if the current step is a play routine such as Simulate / Lift). Pressing Stop switches to the Stop Sequence tab when that list starts.
- Autosave (~300 ms debounce on line edits; immediate on Continue-on-fail, New, Delete, tab change, and combo change). **File → Save Project** also flushes the current sequence. Open / New Project rescan `*.seq`, ensure `default.seq` exists, and load `active.json` (fall back to `default`).
- Replies are logged under action `sequencer` with the same JSON `format_response` produces, so `logs.txt` matches TCP (`>` request, `<` reply). Stop-sequence lines are prefixed `stop ` (`stop 1 > …`).


## Collision System

Scene-wide collision detection lives in `MotionStudio.core.scene.collision_system`:

- MotionStudio.core.scene.collision_system.CollisionMatrix
  - Three tiers (all default to **enabled**; only disabled pairs are stored):
    - `disabled`: ungrouped entity-id pairs (legacy / props without a group).
    - `group_disabled`: per-group internal pairs keyed by `collision_group_name` → `[[entity_id_a, entity_id_b], ...]`.
    - `global_disabled`: external pairs using `group:<name>` and `entity:<id>` keys.
  - Methods:
    - is_enabled(a, b) / set_enabled — legacy ungrouped entity-id pairs (kept in sync with global entity↔entity toggles)
    - is_ungrouped_pair_enabled(id_a, id_b) — ungrouped↔ungrouped checks (uses ``global_disabled`` ``entity:`` keys; matches the Physics global matrix)
    - is_internal_enabled(group, a, b) / set_internal_enabled — within-group pairs
    - is_global_enabled(entry_a, entry_b) / set_global_enabled — group↔group and group↔entity (`GlobalMatrixEntry`)
    - prune_orphan_groups(registered_names) — drop matrix data for group names with no active grouped colliders (runs after scene load)
    - remove_entity(entity_id) — purge all tiers involving the id
    - clear() / to_dict() / from_dict()

- MotionStudio.core.scene.collision_system.CollisionSystem
  - Instantiated automatically by `Scene` and exposed via `scene.collision_system`.
  - `matrix` attribute is the `CollisionMatrix`.
  - **Collider index:** `collider_entities()` returns entities that currently own a `ColliderComponent` or `PointCloudColliderComponent` from an incremental `_colliders_by_id` map — **not** a full `Scene.entities()` scan. Membership updates on `entity_added` / `entity_removed` / `entity_changed` (add/remove `Collider` or `PointCloudCollider` via `add_component` / `remove_component`). A one-shot `_rebuild_collider_index()` runs at system construction for late-attach cases. `check_all()`, `partition_colliders`, Physics UI axes, and `registered_collision_group_names` all consume this index. Non-collider `entity_changed` events (e.g. rename) do not invalidate caches or schedule a sweep. Collider `entity_changed` drops geometry/BVH/OcTree caches only when collision source geometry changed (`Mesh.shape` / effective mesh path from `custom_path` or `decimated_path` when `use_decimated_mesh` is on, `Collider.collider_from_mesh_component` / `collider_mesh_path` / `scale`, PointCloud effective path/scale, `PointCloudCollider.resolution_mm` / `collider_type` / `auto_update` / build generation, live `content_revision` only when `auto_update` is on, octomap world pose, or collider add/remove). Mesh caches drop immediately; point-cloud occupancy stays stale until the worker finishes. Path waypoints, mesh color, and other Inspector fields resweep with the existing trees.
  - **Collision backends** (`MotionStudio/core/scene/collision_backends.py`): narrow-phase contact is pluggable. `backend_id` is `"fcl"` (default) or `"vtk"`. Shared pipeline: per-entity `CollisionGeom` cache, world transforms (identity for world-baked octrees), AABB broad-phase reject; then either VTK `vtkCollisionDetectionFilter` + OBBTree pool (`VtkCollisionBackend`) or python-fcl `BVHModel` / `OcTree` + `fcl.collide` (`FclCollisionBackend`). Switch via `set_backend_id()` (clears backend caches and requests a collision refresh).
  - **Collision matrix gating:** `check_all()` and `check_entities()` only schedule pairs allowed by `CollisionMatrix` (`iter_matrix_enabled_pairs`). During a sweep, `CollisionSystem` installs the same predicate on the active backend via `set_pair_enabled_filter`, and `_pair_collides` re-checks `_pair_enabled` before narrow-phase. Disabled Physics toggles never call VTK or FCL for that pair.
  - `check_all()` runs every matrix-enabled pair check over the indexed collider set (internal per group, global between groups/ungrouped, ungrouped↔ungrouped), caches per-entity polydata, AABB-prerejects, then runs the active backend on overlapping pairs.
  - Collision source selection per entity:
    - `PointCloudCollider`: occupancy from sibling `PointCloudComponent.effective_file_path()`. **`cubes`**: occupied-leaf cube mesh (BVH). **`octomap`**: world-baked FCL `OcTree` (VTK falls back to cubes).
    - `collider_from_mesh_component=True`: build polydata from `MeshComponent` (`cube`/`sphere`/`custom`).
    - `collider_from_mesh_component=False`: build polydata from `ColliderComponent.collider_mesh_path`.
  - `request_collision_update(entity_id=None)` — preferred API for “recalculate collisions.” Any number of callers (transform changes, FK, etc.) may request an update; requests are coalesced into **one** scene-wide `check_all()` and sweeps are throttled to at most one per 33 ms (`_MIN_SWEEP_INTERVAL_S`) during drags. The trailing request is always swept. The optional `entity_id` is accepted for symmetry but does not select a partial sweep.
  - `suspend_deferred_updates()` / `resume_deferred_updates(discard_pending=False)` — nestable; while suspended, `request_collision_update` records intent but does **not** start the 0ms debounce timer. Used by live motion-planning validity checks that call `check_all()` themselves so the timer cannot re-enter mid-check. Pass `discard_pending=True` when the caller already swept.
  - `check_entity(entity_id)` — alias that calls `request_collision_update(entity_id)`.
  - `check_entities(entity_ids)` — incremental pair refresh for the given ids and their enabled partners (used only when a targeted sweep is explicitly needed; not the transform hot path).
  - When a pair check fires, the system always sets the participant's `collided` flag (without triggering a full mesh rebuild) to reflect the entity's current collision state and emits `scene.events.entity_collision_changed(entity_id)` whenever the flag flips. The renderer reads `collided` and `repaint_on_collision` together to decide whether to apply or clear the red overlay. Unicolor meshes tint `MeshComponent.color`. Source-material meshes (URDF GLBs) keep per-cell scalars for their base look; while colliding the renderer turns scalar visibility off and paints the actor red, then restores scalars when the flag clears. Point-cloud actors follow the same overlay (vertex RGB vs uniform color). Overlay updates are coalesced into one VTK render per event-loop tick. `repaint_on_collision` is purely a renderer-side hint and does not affect when the flag is updated or the signal fires.
  - VTK backend caching: `VtkCollisionBackend` keeps a pair-keyed pool of `vtkCollisionDetectionFilter` instances. Each filter owns two OBBTrees built from its input polydata; subsequent pair checks only update `vtkTransform` matrices until geometry changes.
  - FCL backend caching: `FclCollisionBackend` keeps a per-entity `BVHModel` (rebuilt when collider polydata or scale changes) and a per-entity `OcTree` (from snapshotted octomap bytes). `fcl.CollisionObject`s are cached per entity and moved with `setTransform` (python-fcl leaks native memory when collision objects are freed, so they are not recreated per pair); the cache entry is dropped with the geometry. Each **matrix-enabled** pair check calls `fcl.collide` (BVH↔BVH, OcTree↔BVH, OcTree↔OcTree). World-baked octrees use identity `fcl.Transform()`. Pairs disabled in the Physics matrix return immediately without calling `fcl.collide`.
  - GLB/DAE collision extraction: custom meshes loaded as nested `pyvista.MultiBlock` trees are recursively flattened to leaf datasets, triangulated, and merged before OBBTree generation. This is required for converted DAE/GLB assets so collision checks operate on actual triangle surfaces.
  - Cache invalidation: polydata and backend BVH/OBBTree caches are rebuilt for an entity only when its **collision source geometry** changes. That is:
    1. `entity_changed` where `Mesh.shape` / effective mesh path (`custom_path` or `decimated_path` when `use_decimated_mesh` is on) or `Collider.collider_from_mesh_component` / `collider_mesh_path` / `scale` or PointCloud effective path/scale / `PointCloudCollider.resolution_mm` / `collider_type` / `max_occupied_cells` / `auto_update` / build generation actually differ from the cached fingerprint (or a collider participant was added/removed). Live `content_revision` is in the fingerprint only when `auto_update` is on. Octomap mode also fingerprints world pose (`entity_transform_changed` on the entity or an ancestor); occupancy rebuilds on a worker only when `auto_update` is on or **Update collider** is clicked. Point-cloud occupancy is built on a worker (`_CloudOccupancyJob`); `check_all` uses stale cache or skips the cloud until that job finishes. Mesh collider caches drop immediately on fingerprint mismatch; point-cloud caches stay until the worker replaces them.
    2. The entity is removed from the scene (`entity_removed`).
    3. External code calls `invalidate_entity_cache(entity_id)`.
    Transform edits, path/waypoint edits, mesh color, renames, reparenting, and other non-geometry Inspector fields do **not** drop cube/mesh trees — they only schedule a pair sweep that reuses the existing BVH (same as gizmo drags). Octomap mode **does** drop the tree on pose change because occupancy is world-baked.
  - Timing:
    - Edit mode: `entity_transform_changed` and FK call `request_collision_update()` (coalesced, at most one `check_all` per 33 ms). `entity_changed` resweeps colliders; caches are invalidated only for geometry fingerprint changes. `entity_removed` invalidates and resweeps.
    - Play mode and edit-mode play routines tick at **20 Hz** (`QTimer.singleShot(50)`). They do **not** call `check_all()` every tick. Collision follows `request_collision_update` from FK / transform events (coalesced, ≤30 Hz). Scan Mission waits for hardware without hammering FCL or the viewport.

### Physics Window (`MotionStudio.ui.collision_matrix_panel.CollisionMatrixPanel`)

- **Collision detection system** (top of panel): dropdown to choose **VTK Collision Filter** or **FCL** (`scene.collision_system.backend_id`). Changing the selection swaps the narrow-phase backend, clears backend geometry caches, and runs `check_all()`.
- **Global matrix:** one row/column per **collision group** (label shows member count) plus one row per **ungrouped** collider. Toggles `global_disabled` (robot↔environment, group↔group, etc.).
- **Group sub-matrix:** buttons stacked **vertically** below the global matrix (e.g. `ur10e (7 links)`); each opens `CollisionGroupMatrixDialog` with the familiar triangular grid for link↔link pairs inside that group (`group_disabled`). The whole Physics panel (matrix + buttons) lives in a **vertically scrollable** area so many robots do not overflow the dock.
- Unity-style triangular layout: row labels on the left, column labels rotated -45°, checkbox at `(row, col)` where `col < row`; diagonal cells are non-interactive.
- Clicking a cell flips the pair and runs `check_all()` immediately.
- Rebuilds from `entity_added`, `entity_removed`, and `entity_changed`.
- Hosted in `MainWindow` as a `QDockWidget` named **Physics**. Hidden by default; toggle via **Window → Physics**.

### Collider Visualization in Viewport

- `render_collider` draws the active collider geometry as a cyan wireframe overlay.
- The overlay is selection-gated: it is shown **only** when the entity is selected.
- Geometry source matches collision source selection:
  - occupancy voxel cubes from `PointCloudCollider` (sibling `PointCloud`); octomap mode uses the occupied-leaf overlay in world millimetres with an identity user matrix
  - from `MeshComponent` when `collider_from_mesh_component=True`
  - from `collider_mesh_path` when `collider_from_mesh_component=False`
- MultiBlock collider inputs (e.g. GLB/DAE-derived) are recursively flattened and triangulated before rendering.
- Transform changes only update the existing wireframe actor's user matrix. The wireframe is rebuilt only when its geometry fingerprint (collision state key + octomap cell limit) changes; octomap overlays (world-baked) rebuild on pose change through a 150 ms debounce.
- Selection outlines and bounding boxes are updated diff-wise: unchanged selections only get a new user matrix.

### Persistence (`.scn`)

`save_scene` / `load_scene` round-trip the collision matrix using a top-level key alongside entities:

```json
{
  "entities": [...],
  "collision_matrix": {
    "disabled": [["<id_a>", "<id_b>"]],
    "group_disabled": {
      "ur10e": [["<link_id_a>", "<link_id_b>"]]
    },
    "global_disabled": [["group:ur10e", "entity:<prop_id>"]]
  },
  "collision_backend": "fcl",
  "primary_robot_id": "<entity_id or null>"
}
```

- Only disabled pairs are written; omitted buckets default to all-enabled.
- `collision_backend` is `"fcl"` or `"vtk"`; omitted key defaults to FCL.
- `primary_robot_id` is the entity id of the scene **Primary Robot** (ribbon picker; Inspector **TCP**). Missing key (old `.scn`) or a stale id → None. Not stored in `preferences.ini`.
- On load, the matrix is cleared before entity creation, restored after components exist, then `prune_orphan_groups` removes entries for group names with no registered grouped colliders (handles renamed/removed groups).
- Preset (`.pre`) files are unaffected - the collision matrix is scene-scoped.


## Scene Graph, Selection, Events
- MotionStudio.core.scene.scene.Scene (QObject)
  - Attributes:
    - events: SceneEvents (Qt signals broadcaster)
    - collision_system / robot_ik_system / motion_planning_system / hardware_runtime (always present)
    - play_routine_runner: edit-mode frame routines (always present)
    - play_mode_manager / selection / viewport / project_root (optional until editor wires them)
    - primary_robot_id / primary_robot() (scene Primary Robot for Inspector TCP; None if unset or the entity is gone)
  - Methods:
    - entities() -> list[Entity]
    - root_entities() -> list[Entity]
    - find_by_id(entity_id: str) -> Optional[Entity]
    - set_primary_robot_id(entity_id) / primary_robot() -> Optional[Robot]
    - create_entity(name: str = \"Entity\", parent: Optional[Entity] = None) -> Entity
    - delete_entity(entity: Entity) -> None
    - reparent(child: Entity, new_parent: Optional[Entity], *, index: Optional[int] = None) -> None
    - duplicate_entity(source: Entity, new_parent: Optional[Entity] = None) -> Entity

- MotionStudio.core.scene.events.SceneEvents (QObject)
  - Signals:
    - entity_added(object): Emits the added Entity.
    - entity_removed(str): Emits the removed entity id.
    - entity_reparented(str, object): Emits child id and new parent id (str or None).
    - entity_changed(str): Emits the entity id when a notable property changes.
    - entity_transform_changed(str): Emits the entity id when only transform properties change (skips mesh sync for performance).
    - entity_collision_changed(str): Emits the entity id when its `ColliderComponent.collided` flag flips. The VTK renderer recolors the actor in place without rebuilding polydata.
    - primary_robot_changed(): Scene Primary Robot assignment changed (ribbon picker; no undo).

- MotionStudio.core.scene.selection.SelectionModel (QObject)
  - `current` / `primary` (property): Primary (last-clicked) selected `Entity`, or `None`.
  - `selected_ids()` / `selected_entities()`: Full multi-selection set (ordered; last id = primary).
  - Methods:
    - `set_selection(entities, *, primary=None)`: Replace selection.
    - `select_exclusive(entity)` / `set_current(entity)`: Single selection (plain click).
    - `toggle_entity(entity)`: Ctrl+click add/remove.
    - `clear()`, `remove_entity_id(id)`, `is_entity_selected(entity)`.
  - Signals:
    - `selection_changed()`: Selection set changed (Inspector rebuild).
    - `current_entity_changed(object)`: Primary entity changed.

### Creating Your Own Components (How-To)

You can add your own data/logic as Components and expose their UI in the Inspector.

1) Define and register a new Component

```python
# MotionStudio/core/your_feature/rotator_component.py
from __future__ import annotations
from typing import Annotated
from PyQt6.QtGui import QVector3D
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Tooltip, Range

@register_component
class RotatorComponent(Component):
    type_name = "Rotator"

    # Declare fields with type annotations for automatic Inspector UI and serialization
    speed_deg_per_sec: Annotated[float, Range(0.0, 360.0, step=1.0), Tooltip("Rotation speed in degrees per second")]
    axis: Annotated[QVector3D, Tooltip("Rotation axis (normalized)")]

    def __init__(self, speed_deg_per_sec: float = 45.0, axis: QVector3D | None = None) -> None:
        self.speed_deg_per_sec = float(speed_deg_per_sec)
        self.axis = axis or QVector3D(0.0, 0.0, 1.0)
    
    # No need to implement to_dict()/from_dict() - automatic serialization handles it!
    # The base Component class uses reflection to discover and serialize all annotated fields.
```

- The `@register_component` decorator makes the component discoverable by the serializer and the component-creation menu.
- **Important**: The component must be imported somewhere for the decorator to execute. For core components, add the import to `MotionStudio/core/components/__init__.py`. For custom components, place them in `Project/Components/` folder - they are automatically discovered and registered at startup (Unity-like behavior).
- **Automatic Serialization**: Fields declared with type annotations are automatically serialized/deserialized. No need to implement `to_dict()`/`from_dict()` unless you have special needs (e.g., property aliases, custom type handling, polymorphic collections).

2) **Import the component to register it**

**Important**: The `@register_component` decorator only executes when the module is imported. For the component to appear in the Inspector's "Add Component" menu, you must import it somewhere:

- **For core components**: Add the import to `MotionStudio/core/components/__init__.py`
- **For project components**: Place Python files in `Project/Components/` folder - they are automatically discovered and registered (Unity-like behavior, no manual imports needed)

3) Attach the component to an entity

```python
from MotionStudio.core.your_feature.rotator_component import RotatorComponent
from PyQt6.QtGui import QVector3D

ent = scene.create_entity("Spinner")
ent.add_component(RotatorComponent(speed_deg_per_sec=90.0, axis=QVector3D(0.0, 0.0, 1.0)))
```

4) Implement runtime behavior (optional)

Components can implement lifecycle methods:

- `start()`: Called once when Play Mode starts, or immediately when the component is added during Play Mode
- `update(delta_time: float)`: Called every frame during Play Mode
- `on_entity_changed()`: Called when the entity is edited (component properties modified, entity name changes, etc.). Works in both edit mode and play mode.
- `on_viewport_draw()`: Called on the main thread immediately before each scheduled 3D viewport frame (edit and play modes). Use for per-frame debug/visual overlays; re-issue `Debug.draw_*` each call because primitives are one-frame. Don't write public component fields here (their `entity_changed` is deferred until after the frame and warned).

```python
@register_component
class RotatorComponent(Component):
    type_name = "Rotator"
    
    speed_deg_per_sec: Annotated[float, Range(0.0, 360.0), Tooltip("Rotation speed")]
    axis: Annotated[QVector3D, Tooltip("Rotation axis")]
    
    def __init__(self, speed_deg_per_sec: float = 45.0, axis: QVector3D | None = None) -> None:
        self.speed_deg_per_sec = speed_deg_per_sec
        self.axis = axis or QVector3D(0.0, 0.0, 1.0)
        self._initial_rotation = None
    
    def start(self) -> None:
        """Called once when play mode starts or when component is added during play mode."""
        if self.entity is None:
            return
        transform = self.entity.get_component(TransformComponent)
        if transform is not None:
            # Save initial rotation for reference
            self._initial_rotation = transform.rotation_quat
    
    def update(self, delta_time: float) -> None:
        """Called every frame during Play Mode."""
        if self.entity is None:
            return
        transform = self.entity.get_component(TransformComponent)
        if transform is None:
            return
        
        # Rotate the entity
        angle = self.speed_deg_per_sec * delta_time
        q = QQuaternion.fromAxisAndAngle(self.axis, angle)
        transform.rotation_quat = q * transform.rotation_quat
        # Transform setter automatically emits entity_changed signal
```

5) **UI in the Inspector is automatic!**

The Inspector automatically generates UI for all annotated fields. No manual UI code needed! The Inspector will:
- Create appropriate widgets based on field types (checkbox for `bool`, spinbox for `int`/`float`, etc.)
- Apply metadata (tooltips, ranges, file pickers, etc.)
- Handle undo/redo automatically
- Update the 3D view when fields change (via automatic `entity_changed` signal emission)

6) Add to the Inspector "+" menu

The "+" button in the Inspector is populated from the component registry automatically. **Make sure you've imported your component** (step 2) so it gets registered. It will appear in the add-component dropdown (except Transform which is hidden by design).

7) Save/Load

**Automatic!** The serializer uses the registry to store/load your component. Since you're using annotated fields, `to_dict()`/`from_dict()` are handled automatically by the base `Component` class. Your scene will round-trip correctly without any additional code.


## UI
- MotionStudio.ui.main_window.MainWindow (QMainWindow)
  - Composes central VTK view, Hierarchy dock (left), Inspector dock (right), Sequencer dock (bottom-left under Hierarchy), and Physics dock (hidden by default; **Window → Physics**). Inspector `Group` gear rows each open their own floating dockable window (`Entity -> Component -> Group`). Toggle docks via **Window → Hierarchy / Inspector / Physics / Sequencer**.
  - Top ribbon **Play** / **Stop** run the Sequencer (Pause is unused). A compact **Primary Robot** picker (`ComponentReferenceWidget(Robot)`, type chip hidden) sits on the right after the stretch; it sets `Scene.primary_robot_id` (no undo) for Inspector **TCP** buttons. Play Mode is constructed but not started from the UI.
  - UI theme and font: `qdarktheme` via `MotionStudio.ui.theme`, configured in **Edit → Preferences…** (Color Theme: Dark / Light; Font Size: global UI point size). Values load from and save to ``preferences.ini`` beside the executable when packaged (`sys.frozen`), or at the repository root in development (`MotionStudio.core.preferences`). Applying a theme also refreshes the play ribbon and the 3D viewport background gradient. Inspector/PathGeneration icon tool buttons (group gears, segment move/delete) use the `msBorderedToolButton` property and theme `additional_qss` — not a hardcoded local dark stylesheet.
  - Wires `Scene`, `SelectionModel`, `VtkSceneRoot`, and `VtkPickerBridge`.
  - File menu actions:
    - **New Project** (`Ctrl+N`): Prompts for project name and location, creates a new project folder, clears the current scene, and sets the new folder as the project root. Ensures `sequence/default.seq` exists.
    - **Open Project** (`Ctrl+O`): Opens a project folder and loads the first `.scn` file found (or `project.scn` if present). Shows a loading overlay while the scene file is read and applied. Rescans `sequence/*.seq` and restores the last Sequencer selection.
    - **Save Project** (`Ctrl+S`): Saves the current scene to `project.scn` in the project root directory, and flushes the Sequencer's current `.seq` file (sequences are not stored in the scene).
  - View menu: **Solid View** / **Wireframe View**, selection highlight, **Reset Camera**, **Enable Debug Draw**, and **Open Logs** (opens `<project>/logs.txt` with the OS default application via `subprocess`; creates an empty file if none exists yet).
  - Edit menu: **Preferences…** opens `PreferencesDialog` (Color Theme Dark/Light, Font Size 8–20 pt, plus the **TCP Command Server** group: Enabled / Port / Command Timeout). Theme and font preview live; TCP settings apply on OK. OK writes `preferences.ini` and restarts the TCP server when its settings changed. Cancel restores the previous theme/font.
  - **Loading indicator** (`MotionStudio/ui/loading_controller.py`, `MotionStudio/ui/widgets/loading_popup.py`): A small centered overlay on the main window (message + indeterminate progress bar) during long operations. File parsing and asset copying/conversion run on a **background `QThread`**; ECS and VTK updates stay on the **main thread**. While a bulk scene apply runs, `VtkSceneRoot.begin_bulk_load()` / `end_bulk_load()` defer mesh/collider VTK builds and flush them in small chunks so the overlay can repaint. Shown for:
    - **Open Project** (JSON read in worker; `apply_scene_data` + deferred mesh flush on main thread)
    - **Hierarchy → Import Model** (`ingest_mesh_source` / `import_mesh_into_project` in worker, including STEP→STL tessellation; entity creation on main thread)
    - **Inspector mesh/collider path** (STEP/STP picks convert to STL in the same worker overlay)
    - **Mesh → Decimate** (`decimate_mesh_to_stl` in worker; `decimated_path` / `use_decimated_mesh` update on main thread)
    - **PointCloud → Downsample** (`downsample_point_cloud_to_ply` in worker; `downsampled_path` / `use_downsampled_cloud` update on main thread)
    - **Hierarchy → Import URDF** (`prepare_urdf_import` in worker; `apply_urdf_import` / undo command on main thread)
    - **Plan Motion** (`LoadingController.begin_external` / `end_external` while `MotionPlanningSystem`'s planner worker runs; collision snapshot builds on the main thread under the overlay, then RRT/IK sample off-thread). Message includes the collision snapshot summary when available.
    - Only one loading job runs at a time; overlapping requests are ignored with a warning.

- MotionStudio.ui.hierarchy_panel.HierarchyPanel (QWidget)
  - Displays entities in a tree with drag-and-drop parenting.
  - Context menu actions:
    - Create Empty: Adds a new entity (with a default TransformComponent) as a child of the selection or as a root.
    - Import Model: Copies/converts mesh assets into the project (when a project is open) and creates an entity with `MeshComponent` (loading overlay during conversion). `.step` / `.stp` is tessellated to STL (0.1 mm / 20°) even if no project is open.
    - Import Point Cloud: Copies `.ply` / `.pcd` into `models/` and creates an entity with `Transform` + `PointCloudComponent`.
    - Import URDF: Parses URDF, bundles meshes into the project, and builds the robot hierarchy (loading overlay during bundling).
    - Delete (`Del`): Removes selected entity and its descendants. Also available as a global **Edit → Delete** shortcut and from the keyboard (`Del`) whenever a non-text-editing widget has focus (Hierarchy tree, 3D viewport, docks). Text-input widgets (`QLineEdit`, `QSpinBox`, ...) suppress the shortcut via Qt's `ShortcutOverride` handshake so `Del` still deletes characters in fields.
    - Duplicate (`Ctrl+D`): Clones the selected entity (and children). Also available as a global **Edit → Duplicate** shortcut and from the keyboard (`Ctrl+D`) under the same focus rules as Delete.
    - Save Preset: Serializes the right-clicked entity and its full subtree to a self-contained `.pre` **bundle**. A `.pre` is a zip archive containing `preset.json` (the entity records, same shape as `.scn`) plus every dependent file the components reference, stored under `assets/<project-relative-path>`. The save dialog defaults to `<project>/presets/<entity name>.pre`. See **Self-contained preset bundles** below for the bundling rules.
    - Load Preset: Instantiates a `.pre` file under the right-clicked entity (or at scene root if the menu was opened on empty space). On load, bundled assets are first extracted back into the project (preserving their relative paths) so component path references resolve, then the entity subtree is instantiated. Undo removes the loaded subtree. Open dialog defaults to `<project>/presets`.
    - Drag and drop: reorder or reparent entities in the tree (undoable via `ReparentEntityCommand`). `.pre` files can be dropped from the system file manager onto the hierarchy tree; the preset loads under the row under the cursor, or at scene root when dropping on empty space. Multiple files load in one undo step when the undo stack is used.
  - Optional selection integration: updates `SelectionModel` on tree selection changes.

- MotionStudio.ui.inspector_panel.InspectorPanel (QWidget)
  - bind_selection(selection: SelectionModel): Rebuilds UI for the current selection (single or multi).
  - **Multi-selection Inspector**: When multiple entities are selected, shows only **component types common to all** selected entities. Fields with differing values show placeholder **`-`** (strings/numbers), **tristate** checkboxes (mixed), or a gray **`-`** color button. Edits apply to **all** selected instances; undo uses `QUndoStack.beginMacro` / `endMacro`. **PathGeneration** is hidden unless exactly one entity is selected. Bulk **Delete** / **Duplicate** in the Hierarchy operate on the full selection (one undo step per macro).
  - Auto-generates component UI from type annotations (Unity-like) and routes edits through undo/redo.
  - **TCP copy**: with a single entity selected, right-click a reflected field **label** for **Copy GET command** / **Copy EDIT command** (EDIT omitted for `ReadOnly` / `ConnectionStatus`; value formatted at click time via `format_field_value`), or right-click an `@inspector_button` for **Copy RUN command**. Implemented in `MotionStudio/ui/inspector/tcp_copy.py`; menus stay available on locked components (labels and RUN hosts are not disabled with the editors). Copied text goes to the clipboard and the status bar. Multi-select Inspector does not attach these menus.
  - Each component `QGroupBox` has a header toolbar: **collapse/expand** (up arrow when expanded, down arrow when collapsed — leftmost, before info), **info**, **lock**, and **remove (✕)**. Collapse hides all fields below that row; the state is stored on `component.collapsed` and round-trips in the scene file like `locked`. Remove is disabled while the component is locked.
  - Uses a global `QUndoStack`: property edits, **Add Component**, and remove-component (×) on each component block.

### Auto-Inspector (Unity-like)

Components can declare editable fields using `typing.Annotated` plus metadata markers. **Fields are automatically serialized** using the same reflection mechanism - no need to manually implement `to_dict()`/`from_dict()` for simple components!

Example:

```python
from typing import Annotated, Literal
from PyQt6.QtGui import QColor, QVector3D
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Range, Tooltip, FilePath, ColorField, Hidden

@register_component
class ExampleComponent(Component):
    type_name = "Example"

    enabled: Annotated[bool, Tooltip("Enable this feature")]
    speed: Annotated[float, Range(0.0, 100.0, step=0.5), Tooltip("Units per second")]
    mode: Annotated[Literal["a", "b", "c"], Tooltip("Mode")]
    offset: Annotated[QVector3D, Tooltip("Local offset")]
    source: Annotated[str, FilePath("Data (*.json);;All Files (*.*)")]
    tint: Annotated[QColor, ColorField()]
    internal_flag: Annotated[bool, Hidden()]  # Hidden from Inspector and serialization
    
    # No need to override to_dict()/from_dict() - it's automatic!
```

Supported initial widget mapping:
- `bool` → checkbox
- `int` → spinbox (+ `Range`)
- `float` → double spinbox (+ `Range`)
- `str` → line edit (or file picker if `FilePath`; or LED + text badge if `ConnectionStatus`)
- `Literal[...]` → combo box
- `QVector3D` → `Vector3Editor`
- `QColor` → color picker button (`ColorField(alpha=True)` enables the alpha channel; invalid `ColorField(...)` kwargs break annotation reflection and drop that field out of its `Group`)
- `Optional[ComponentType]` → Component reference widget (entity browser)

**`ConnectionStatus`** — Marks a `str` field as a read-only connection badge (`MotionStudio.ui.widgets.connection_status_badge.ConnectionStatusBadge`). LED is green when the value is in `connected` (default `("Connected",)`), amber when in `busy` (per-component list of transitional strings), red otherwise. Status text wraps in a multiline vertically scrollable editor sized to the Inspector field width. TCP `EDIT` is refused like `ReadOnly`; `GET` returns the raw string.

**Inspector `Group` docks** — Fields (and `@inspector_button(..., group=...)`) that share a `Group("Label")` are not shown inline. The main Inspector shows a gear row for that label; clicking it opens (or focuses) a **separate floating dockable window** titled `Entity Name -> Component Name -> Group Name`. Each group gets its own window (initially floating; can be re-docked). Closing the window or deleting the bound entity dismisses it. Right-click GET / EDIT / RUN copy works in these docks the same as in the main Inspector, because they reuse `_append_inspector_row_single`.

**Robot Joystick dock** — Any `Robot` Inspector shows a **Joystick** gear (`MotionStudio/ui/inspector/robot_joystick_dialog.py`). Opens `Entity -> <type> -> Joystick` with Position/Rotation type fields plus jog pads (`MotionStudio.ui.widgets.robot_joystick.RobotJoystick`). Content is in a scroll area so the window can re-dock into the main window (left/right/top/bottom or tabbed with Inspector). See UniversalRobot **Joystick**.

### Component References

Components can reference other components using `Optional[ComponentType]` annotations:

```python
from typing import Optional
from MotionStudio.core.components import TransformComponent

@register_component
class MyComponent(Component):
    target: Annotated[Optional[TransformComponent], Tooltip("Target transform")]
```

- **Serialization**: Component references are automatically serialized as entity IDs (strings) in the scene file.
- **Loading**: During scene loading, component references are resolved in two phases:
  1. First, all entities and components are loaded, with references stored as entity_id strings.
  2. After all entities are loaded, references are resolved to Component instances.
- **Inspector UI**: Component reference fields automatically get a special widget (`ComponentReferenceWidget`) that allows selecting entities containing the required component type. Clicking the input button selects the referenced entity in the scene. Field chrome is theme-aware via `msComponentRefInput` / `msComponentRefTypeLabel` in `MotionStudio.ui.theme` (follows **Edit → Preferences… → Color Theme**).
- **Runtime**: The field stores the Component instance directly (not the entity_id), making it easy to access the referenced component's properties.

### Undo/Redo

Undo/redo is handled via a global `QUndoStack` and commands in `MotionStudio\core\undo\commands.py`:
- `PropertyChangeCommand(scene, entity_id, component_type, field, old, new)` — Inspector field edits, gizmo commits, etc. Multi-edit wraps several of these in one undo macro.
- `AddComponentCommand(scene, entity_id, component_type, component_snapshot)` — Inspector **Add Component** menu.
- `RemoveComponentCommand(scene, entity_id, component_type, component_snapshot)` — Inspector component remove (×).
- `ReparentEntityCommand(scene, child_id, new_parent_id, old_parent_id=..., old_index=..., new_index=...)` — Hierarchy drag-and-drop reparent / sibling reorder. Undo restores the previous parent and sibling slot. Cycle drops (onto self or a descendant) are ignored.
- `DeleteWaypointCommand(scene, entity_id, feature_idx, waypoint_idx, selection=None)` — deletes one waypoint from a `CustomFeature` segment (no-op for parametric segments). Snapshots the removed waypoint on first redo so undo restores the exact position + rotation at the original index and re-selects it. Fired by the `Del` shortcut when a `CustomFeature` waypoint is currently selected (see **Entity editing shortcuts** under Selection Modes).
- All commands in `commands.py` implement `get_description()` for status bar and `logs.txt` entries on execute, undo, and redo.
- `MainWindow` resolves the correct stack command on undo via `command_for_stack_action()` (undo uses `command(index)`, not `command(index - 1)`).
- Rapid consecutive edits on the **same** property or path segment field are merged within a **1 second sliding window** (`MotionStudio\core\undo\merge_policy.py`); after a pause of at least 1s, each commit becomes its own undo step so undo can restore intermediate values. Gizmo drags commit on mouse release and follow the same merge rule (two releases on the same field within 1s share one undo step; releases more than 1s apart are separate steps).

### Status Bar and Command Logging

The editor includes a status bar at the bottom of the main window that displays human-readable descriptions when commands are executed, undone, or redone, and whenever any other line is written to `logs.txt`.

- **Status Bar** (`QStatusBar`):
  - Shows command descriptions when actions are performed
  - Displays "Undid: {description}" for undo operations
  - Displays "Redid: {description}" for redo operations
  - Shows plain descriptions for new command executions
  - Shows `{action}: {description}` for every other log line at the same moment it is appended to `logs.txt` (Inspector button clicks/replies, TCP request/reply pairs, Sequencer request/reply pairs, Plan Motion, hardware Connect, …)
  - Messages automatically clear after 5 seconds
  - TCP connection threads marshal the update onto the UI thread via `CommandLogger.event_logged`

- **Command Logging** (`MotionStudio.core.logging.command_logger.CommandLogger`):
  - All command executions are logged to `logs.txt` in the active project's root folder
  - Log entries include timestamps and action type (execute/undo/redo)
  - Format: `[YYYY-MM-DD HH:MM:SS] {action}: {description}`
  - `log_event(action, description)` writes the same line format for non-command editor events (e.g. Plan Motion, the `tcp` request/reply pairs from the TCP Command Server, `sequencer` request/reply pairs from the Sequencer dock, and `inspector` click/reply pairs when an Inspector button is pressed) and emits `event_logged` so the status bar mirrors the file
  - Writes are guarded by a lock so TCP connection threads and the Sequencer worker can log alongside the main thread
  - Logging is automatically disabled when no project is loaded
  - The log file is created automatically when the first command is executed

- **Command Descriptions**:
  - Each command class implements a `get_description()` method that returns a human-readable description
  - Descriptions include entity names and relevant context (e.g., "Created entity 'Cube'", "Changed TransformComponent.position on 'MyEntity'")
  - If `get_description()` is not available, the command's text is used as a fallback

- MotionStudio.ui.widgets.vector3_editor.Vector3Editor (QWidget)
  - value() -> QVector3D
  - set_value(v: QVector3D) -> None
  - Emits on change via supplied callback in constructor.


## Persistence (JSON .scn)
- MotionStudio.core.serialization.json_io
  - save_scene(scene: Scene, path: str) -> None
  - load_scene(scene: Scene, path: str) -> None
  - save_entity_preset(root: Entity, path: str, project_root: Path | None = None) -> None — writes a self-contained `.pre` **zip bundle** for one subtree (root has `parent_id` null). The archive holds `preset.json` (`{ "entities": [...] }`) plus dependent files under `assets/<relpath>`. When `project_root` is provided, path-bearing component fields are scraped and bundled (see below); otherwise only `preset.json` is written.
  - load_entity_preset(scene: Scene, path: str, attach_under: Entity | None) -> List[Entity] — opens the `.pre` zip, extracts bundled `assets/*` back into `scene.project_root` (preserving relative paths, overwriting on conflict, with a path-traversal guard), then clones the preset with new entity ids, parents the former root under `attach_under`, and resolves component references within the loaded subtree.
  - read_preset_entities(path: str) -> list | None — reads only `preset.json` from a `.pre` zip (no asset extraction); used for lightweight validation/preview. Returns `None` for non-preset files.
  - Schema (simplified):
    - { \"entities\": [ { \"id\", \"name\", \"parent_id\", \"components\": [ {\"type\", \"data\"} ] } ] }
    - TransformComponent data uses { position: [x,y,z], euler_deg: [x,y,z], scale3d: [x,y,z] }
  - **Entity IDs are preserved**: When saving and loading scenes, entity IDs are preserved. The `load_scene()` function accepts an `entity_id` parameter to restore the original entity IDs from the JSON file.
  - **Component References**: Component reference fields (e.g., `Optional[TransformComponent]`) are serialized as entity IDs (strings) and automatically resolved to Component instances after all entities are loaded. This ensures that component references work correctly even when entities are loaded in any order.
  - **New Project**: Creates a new project folder at the selected location. The folder name is sanitized to remove invalid filesystem characters. If a folder with the same name already exists, the user is prompted to use it or cancel.
  - When a scene is loaded via the "Open Project" menu action, the camera automatically resets to frame all loaded entities (preserving Z-up orientation).

### Self-contained preset bundles (.pre)

A `.pre` is always a zip archive (never plain JSON). Its layout is:

```
my_preset.pre  (zip)
|-- preset.json                 # { "entities": [...] } - the subtree records
\-- assets/                     # dependent files, mirroring project-relative paths
    |-- models/arm.glb
    |-- models/arm.glb.materials.json
    \-- robots/ur10e/...
```

- **Asset collection (fully generic):** On save, every component on the root entity and its descendants is reflected with `iter_editable_fields`. Any field annotated `FilePath` contributes a single file; any field annotated `FolderPath` contributes every file beneath that directory. For each collected file, a `<file>.materials.json` sidecar (GLB diffuse-color metadata) is also bundled when present. There is no per-component code — `MeshComponent.custom_path`, `ColliderComponent.collider_mesh_path`, `RobotDescriptionComponent.urdf_path` (FilePath) and `package_folder` (FolderPath, whole source-mesh tree), and any future path field are all captured automatically.
- **Robots:** Each link's generated visual GLB / collision STL is referenced by that link entity's own `MeshComponent` / `ColliderComponent` `FilePath` fields, so walking the subtree captures them. Paths stored only inside non-field serialized data (e.g. `RobotDescriptionComponent.links[].visual_mesh_paths`) are intentionally not scraped; they duplicate the link-entity component paths, so nothing is lost.
- **Extract on import:** On load, each `assets/<relpath>` member is written to `<project_root>/<relpath>` (parent dirs created, overwriting on conflict). A normalized-prefix traversal guard skips any member that would resolve outside the project root. Because component paths stay project-relative and the files are restored at those paths, references resolve with no rewriting. If the scene has no `project_root`, assets are not extracted (only the entity structure is instantiated).
- **Limitations:**
  - Conflict policy is overwrite; two different assets sharing the same project-relative path (e.g. two robots both imported as `ur10e_robot`) will collide. Acceptable because assets are normally project-relative and self-contained.
  - Paths that resolve outside `project_root` (legacy absolute references) are skipped from the bundle. Re-import the mesh / run Reload Meshes to localize such paths before saving a preset.
  - Older plain-JSON `.pre` files (pre-bundle format) are no longer supported; re-save them from a project to upgrade.


## Utilities
- MotionStudio.utils.ids.generate_uuid() -> str
  - Returns a new UUID4 string used for entity ids.
- MotionStudio.utils.mesh_assets
  - `import_mesh_into_project(project_root, source_path) -> str`: If the file already lives under the project directory, returns a posix relative path; otherwise copies into `models/` and returns `models/<filename>`. Special cases: `.dae` is converted to `.glb` in `models/` (with unit scaling to mm); `.step` / `.stp` is tessellated to `.stl` in `models/` (0.1 mm linear deflection, 20° angular) and returns the converted path.
  - `ingest_mesh_source(project_root, source_path) -> str`: Project-aware wrapper used by Hierarchy / Inspector. With a project, calls `import_mesh_into_project`. Without a project, STEP/STP is still converted to a sibling `.stl`; other formats are returned unchanged.
  - `convert_step_to_stl(source, dest_dir) -> Path`: OpenCASCADE tessellation via `cascadio` (GLB is metres, scaled ×1000 to mm, then discarded) then binary STL export through trimesh.
  - `resolve_mesh_path_for_read(project_root, stored_path) -> str`: Joins a relative stored path with the project root for VTK/Qt3D file loading (absolute stored paths are left unchanged for legacy scenes).
  - `has_source_material_sidecar(project_root, stored_path) -> bool`: Returns true when `<mesh>.glb.materials.json` exists and source-material colors can be used.
- MotionStudio.utils.mesh_decimate
  - `decimate_mesh_to_stl(source, dest_dir, ratio) -> DecimateResult`: Quadric-collapse (VTK / PyVista `decimate`) a triangulated surface. `ratio` is the fraction of faces to keep. Writes `<stem>_lod.stl` under `dest_dir` (replaces that file on later runs) without overwriting `source`. Coordinates stay in engine millimetres.
- MotionStudio.utils.point_cloud_downsample
  - `downsample_point_cloud_to_ply(source, dest_dir, ratio) -> DownsampleResult`: Even-index keep-fraction of a `.ply` / `.pcd`. `ratio` is the fraction of points to keep (`0.5` keeps ~50%). Writes `<stem>_lod.ply` under `dest_dir` (replaces that file on later runs) without overwriting `source`. Coordinates stay in file units (PointCloud `scale` still applies at load).
  - `downsample_arrays(points, colors, ratio)` / `downsample_ply_inplace(path, ratio)`: same keep-fraction on arrays or an existing PLY (used by Mechmind Capture so each new frame is thinned before append).
- MotionStudio.utils.point_cloud_overlap
  - `filter_new_points_by_voxel(old_pts, new_pts, new_rgb, voxel_mm)`: keep-first occupancy. Drops new points whose `floor(xyz / voxel_mm)` is already occupied by `old_pts`; marks kept new voxels occupied so intra-frame duplicates collapse. `0` mm is a no-op. Stored points are not returned and are not thinned.
  - `filter_new_points_against_keys(old_keys, new_pts, new_rgb, voxel_mm)` plus `VoxelKeyCache`: the Mech-Eye helper keeps sorted unique keys for the scan file. A later cell uniques **only the new frame** and tests it against the cache. The cache misses when the path, voxel size, or stored point count changes (Clear Scan, a new file).

## Debug API (Unity-like)
- Module: `MotionStudio.core.debug`
- Import from any component script:
  - `from MotionStudio.core.debug import Debug`

### Logging helpers
- `Debug.log(message)`
- `Debug.warning(message)`
- `Debug.error(message)`
- Behavior: prints timestamped lines to console (`[Debug HH:MM:SS] ...`).

### Draw helpers
- `Debug.draw_line(start, end, color=(1, 0.95, 0.2), width=2.0, opacity=1.0, on_top=True)`
- `Debug.draw_ray(origin, direction, length=1.0, color=(1, 0.95, 0.2), width=2.0, opacity=1.0, on_top=True)`
- `Debug.draw_sphere(center, radius=0.05, color=(0.3, 0.85, 1.0), filled=False, opacity=1.0, on_top=True)`
- `Debug.draw_bounding_box(center, size, color=(1, 0.95, 0.2), width=2.0, opacity=1.0, on_top=True)` — wireframe AABB; `size` is full width/height/depth
- `Debug.draw_axes(origin, length=1.0, screen_space=False, rotation=None, width=2.0, x_color=..., y_color=..., z_color=..., on_top=True)` — RGB XYZ axes; optional `QQuaternion` for local orientation; when `screen_space=True`, `length` is each axis arm length in **pixels** (constant on screen)
- `Debug.draw_point(position, size=8.0, screen_space=True, color=(1, 0.95, 0.2), opacity=1.0, on_top=True)` — camera-facing filled disc; default `screen_space=True` uses **pixel radius** (constant on screen); `screen_space=False` uses world-space radius
- `Debug.draw_label(position, text, color=(1, 1, 1), font_size=14, on_top=True)` — billboard 3D text overlay facing the camera
- `Debug.draw_cone(position, direction, size=0.1, color=(0.3, 0.85, 1.0), filled=True, opacity=1.0, on_top=True)` — cone with base circle centered at `position` and axis aligned along `direction` (apex at `position + normalize(direction) * 2 * size`). `size` is the base **diameter** in world units; height is always locked to `2 * size` for visual consistency. Zero-length `direction` is a no-op. Useful as arrow heads / direction indicators when paired with `draw_line` or `draw_ray`.
- `Debug.draw_polyline(points, color=(1, 0.95, 0.2), width=2.0, opacity=1.0, closed=False, on_top=True)` — connected polyline through a sequence of world-space points (`QVector3D` or 3-number sequences). Needs ≥2 points. When `closed=True`, an extra segment joins the last point back to the first. Useful for path / trajectory overlays. `opacity` is 0..1 for line/box/polyline (same clamp as sphere/point/cone).
- **`on_top` parameter (all draw methods above)**: `on_top=True` (default) disables VTK depth testing on the debug actor so the primitive **renders over the scene** and stays visible when meshes occlude it — this matches the historic Debug behavior and is what you want for most editor overlays. Pass `on_top=False` to have the primitive respect the depth buffer so scene geometry can occlude it (useful for spatial debug where you want the shape to feel embedded in the scene). Billboard labels attempt to honor the flag via `SetForceOpaque` / `SetDepthTest` where those methods exist on the current VTK build; on builds without those hooks, `on_top=False` degrades gracefully to the default behavior.
- Inputs accept `QVector3D` or 3-number sequences for vectors, and `QColor` or RGB float triples for colors.

### Lifetime model (one-frame, high performance)
- Primitives are queued and consumed in the render scheduler's **pre-frame step** (after `on_viewport_draw()` hooks run, before VTK `Render()`).
- They are automatically cleared at the following scheduled frame unless redrawn. Qt paint/expose renders reuse the existing actors without consuming the queue.
- Actors are **pooled and batched**: lines, axes, boxes, and polylines share one line-batch actor per (renderer, width, opacity); spheres, cones, point discs, and labels reuse pooled actors (max 1024 per pool) that are hidden when unused. If the frame's primitives (and the camera, for screen-space ones) are unchanged, the sync is skipped.
- In Play Mode, call `Debug.draw_*` from `on_viewport_draw()` (or every `update()` if you only use play mode) so visuals persist each frame.
- In Edit Mode (no `update()` loop), override `on_viewport_draw()` and re-issue `Debug.draw_*` each pass so previews stay visible while orbiting the camera. A single draw outside a render pass still works via `request_render`; `on_entity_changed` alone is not enough for continuous previews.

### Runtime toggles
- `Debug.set_enabled(bool)` — global on/off for debug rendering.
- `Debug.set_mode_enabled(edit_mode=..., play_mode=...)` — optional per-mode gates.
- Menu integration:
  - `Edit → Preferences…` opens the preferences dialog: **Color Theme** (Dark / Light), **Font Size** (global UI), and the **TCP Command Server** group (see **TCP Command Server**). Settings persist in `preferences.ini` next to the exe when built (`MotionStudio.core.preferences`), under `[ui]` and `[tcp]`. Theme changes use `MotionStudio.ui.theme.apply_theme`; font size uses `QApplication.setFont`.
  - `View → Enable Debug Draw` toggles `Debug.set_enabled(...)`.
  - `View → Open Logs` opens the active project's `logs.txt` in the default editor (`subprocess`; `cmd /c start` on Windows, `open` on macOS, `xdg-open` elsewhere).

### Renderer integration
- `MainWindow` wires `Debug.configure(scene=..., request_render=...)` in `_init_central_view`.
- `MotionStudio/render/vtk/viewport_frame_bridge.py`:
  - Registers a `pre_frame` callback on the `RenderScheduler` (no VTK `StartEvent` observer).
  - Invokes `on_viewport_draw()` on components that override it, then syncs queued `Debug` primitives into the pooled actors.
- `MotionStudio/render/vtk/debug_draw_bridge.py`:
  - Renders `on_top` primitives in the overlay renderer (`_pyengine_overlay_renderer`) and the rest in the main renderer. Pooled actors are added once via `guarded_renderer_add`.


## Globals and Singletons
- Component registry (module-level, internal): maps component `type_name` to class (in `MotionStudio.core.ecs.component`).
- Package version:
  - MotionStudio.__version__: current package version string.
- No framework-wide singletons are used; `Scene`, `SelectionModel`, and `SceneEvents` instances are owned and wired by `MainWindow`.


## Input Mappings (Camera)
Implemented by `MotionStudio.render.vtk.camera_controller.VtkCameraController` (neutral VTK style; gizmos/picking can abort first).
- Right Mouse Drag: Orbit around view center.
- Middle Mouse Drag: Pan.
- **Shift + Right Mouse Drag**: Pan (same as middle-drag). Shift must be held when the right button goes down.
- Mouse Wheel: Zoom (dolly).
- Left Mouse Drag: No-op (reserved for selection/gizmos).


## Transform Gizmos (Translate & Rotate)

The editor provides visual gizmos for transforming entities in 3D space. Both translate and rotate gizmos are visible simultaneously when an entity is selected.

### Translate Gizmo

- **Visual**: Three colored arrows (red=X, green=Y, blue=Z) pointing along the entity's local axes.
- **Interaction**: Left-click and drag an arrow to move the entity along that local axis.
- **Behavior**:
  - Gizmo size scales with camera zoom to maintain a constant ~180px on-screen size.
  - Gizmo is always rendered on top of other geometry.
  - Position changes are applied in the entity's parent-local space.
  - Undo/redo support: Each drag operation creates a single undo step.

### Rotate Gizmo

- **Visual**: Three colored arc rings (270° partial circles) in planes perpendicular to each local axis:
  - X-axis ring: lies in the YZ plane (red)
  - Y-axis ring: lies in the XZ plane (green)
  - Z-axis ring: lies in the XY plane (blue)
- **Interaction**: Left-click and drag a ring to rotate the entity around that local axis.
- **Behavior**:
  - Rings are semi-transparent (70% opacity) for better visibility.
  - Ring size matches the translate gizmo size (~180px on screen).
  - Rotation is applied in local space using quaternion multiplication.
  - Undo/redo support: Each drag operation creates a single undo step.
- **Implementation**: Rotation angle is calculated by projecting the mouse ray onto the ring plane and computing the angle delta from the initial click position.

### Gizmo Priority

- Translate gizmo has higher event priority (checked first).
- If a translate arrow is clicked, rotation gizmo does not respond.
- If no translate arrow is hit, rotation rings are checked.
- Both gizmos use the same overlay renderer for always-on-top rendering.

### Technical Details

- **Location**: `MotionStudio/render/vtk/gizmo/translate_gizmo.py` and `MotionStudio/render/vtk/gizmo/rotate_gizmo.py`
- **Integration**: Both gizmos are instantiated in `MainWindow._init_central_view()`.
- **Rendering**: Gizmos are added to the layer-1 overlay renderer (`_pyengine_overlay_renderer`). That layer preserves the scene color buffer but clears depth before drawing, so handles are not occluded by meshes. (`vtkProperty::SetDepthTest` is not available on VTK 9.5's OpenGL backend; do not rely on it.)
- **Updates**: Gizmos automatically reposition when:
  - Selection changes
  - Entity transform changes (from Inspector edits or hierarchy reparenting)
  - Camera moves (orbit/pan/zoom)


## Play Mode

**Currently suppressed.** `PlayModeManager` is still constructed (so `is_playing` guards and `start()` / `update()` hooks remain), but the UI does not start Play Mode. The top ribbon **Play** / **Stop** run the Sequencer. Per-frame previews use edit-mode play routines (**Simulate** on MotionPlanner / ToolTrace, Lift to safety, Generate leak path).

The editor includes a Play Mode system similar to Unity3D that runs a simulation loop during which components can update every frame.

### Overview

- **Play Mode Manager**: `MotionStudio.core.scene.play_mode.PlayModeManager` manages the play state and update loop (unused from the ribbon while suppressed)
- **Update Loop**: Runs with variable timing, calling `update(delta_time)` on all components and rendering after each update
- **Ribbon UI**: Play/Pause/Stop in a toolbar below the menu bar. A status label on the left shows **Idle** when no sequence is running, **Running \<name\> sequence** during Main, and **Stopping \<name\> sequence** while that file's Stop Sequence is running (a play-routine-only blue ribbon stays **Idle** until Stop starts the Stop Sequence). On the right, **Primary Robot** is a compact `Robot` entity picker (persisted as `primary_robot_id` in `.scn`). **Play** starts the current Sequencer **Main Sequence** (green while running, including the Stop Sequence). **Pause** is disabled (sequences do not pause; the in-flight command is not cancelled except `WAIT`). **Stop** runs that file's **Stop Sequence** anytime: idle, during a standalone play routine (`stop_all()` first), or by interrupting Main; Stop again aborts. While an edit-mode play routine runs *and no sequence is playing*, the ribbon turns **blue**; Play stays disabled and Stop stays enabled. During a sequence, Stop stays enabled even if a step is a play routine.
- **Editing Disabled**: When play mode is active, editing features (gizmos, undo/redo, etc.) are disabled
- **State Restoration**: When play mode stops, the scene is automatically restored to its pre-play state (Unity-like behavior)
- **Stop sync**: Stop uses `VtkSceneRoot` bulk load so mesh rebuilds are deferred until restore finishes. Mesh actors are skipped when shape/path/color are unchanged (`_entity_mesh_state` recorded after a successful add). This prevents orphan VTK solids (e.g. a duplicated UUT mesh) when play-stop storms `entity_changed` after Plan Motion + playback.

### Usage

Play Mode is not started from the ribbon. To preview a planned trajectory or tool path, use **Simulate** on the component (play routine). To run a command list, use ribbon **Play** on the Sequencer.

### Component Lifecycle Methods

Components can implement lifecycle methods similar to Unity's MonoBehaviour:

#### Start Method

Components can implement a `start()` method that is called once when Play Mode starts, or immediately when a component is added during Play Mode:

```python
@register_component
class RotatorComponent(Component):
    type_name = "Rotator"
    
    def __init__(self, speed_deg_per_sec: float = 45.0):
        self.speed_deg_per_sec = speed_deg_per_sec
        self._initial_rotation = None
    
    def start(self) -> None:
        """Called once when play mode starts or when component is added during play mode."""
        if self.entity is None:
            return
        transform = self.entity.get_component(TransformComponent)
        if transform is not None:
            # Save initial rotation for reference
            self._initial_rotation = transform.rotation_quat
```

#### Update Method

Components can implement an `update(delta_time: float)` method to receive per-frame updates:

```python
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QQuaternion, QVector3D

@register_component
class RotatorComponent(Component):
    type_name = "Rotator"
    
    def __init__(self, speed_deg_per_sec: float = 45.0):
        self.speed_deg_per_sec = speed_deg_per_sec
    
    def start(self) -> None:
        """Called once when play mode starts."""
        # Initialize runtime state here
        pass
    
    def update(self, delta_time: float) -> None:
        """Called every frame during play mode."""
        if self.entity is None:
            return
        transform = self.entity.get_component(TransformComponent)
        if transform is None:
            return
        
        # Rotate around Z axis
        angle = self.speed_deg_per_sec * delta_time
        q = QQuaternion.fromAxisAndAngle(QVector3D(0, 0, 1), angle)
        transform.rotation_quat = q * transform.rotation_quat
        # Transform setter automatically emits entity_changed signal
```

#### On Entity Changed Method

Components can implement an `on_entity_changed()` method that is called whenever the entity is edited (e.g., when component properties are modified, entity name changes, etc.):

```python
@register_component
class MyComponent(Component):
    type_name = "MyComponent"
    
    def on_entity_changed(self) -> None:
        """Called when the entity is edited (component properties changed, etc.)"""
        if self.entity is None:
            return
        # React to entity changes here
        print(f"Entity {self.entity.name} was changed!")
        # You can access other components, update internal state, etc.
```

This method is called:
- When component properties are modified (via Inspector or programmatically)
- When entity name changes
- Any time the `entity_changed` signal is emitted
- Works in both edit mode and play mode

### Behavior During Play Mode

When play mode is active:
- **Gizmos are disabled**: Translate and rotate gizmos don't respond to mouse input
- **Path tools are disabled**: Path generation tools are canceled
- **Undo/Redo**: New commands are not created (existing undo stack remains)
- **Inspector**: Read-only (editing disabled)
- **Hierarchy**: Editing disabled

When play mode stops:
- All editing features are re-enabled
- **Scene state is automatically restored** to its pre-play state (Unity-like behavior):
  - Entities deleted during play mode are restored
  - Entities created during play mode are deleted
  - Component state for all entities is restored to pre-play values
  - Components removed during play mode are restored
  - Components added during play mode are removed

### Technical Details

- **Update Timing**: Uses variable timing (`QTimer.singleShot(0)`) to adapt to actual performance, ensuring rendering happens after each update tick
- **Delta Time**: Calculated as time since last frame, clamped to max 100ms to prevent large spikes
- **Component Lifecycle**: 
  - `start()` is called once when play mode starts (for all existing components) or immediately when a component is added during play mode
  - `update(delta_time)` is called every frame during play mode
  - `on_entity_changed()` is called whenever the entity is edited (works in both edit mode and play mode)
- **Component Discovery**: Uses `hasattr()` and `callable()` to check if components implement `start()` or `update()`
- **Error Handling**: Component lifecycle method errors are logged but don't crash the play mode loop
- **State Snapshot**: Before play mode starts, the entire scene (all entities and components) is serialized to memory
- **State Restoration**: When play mode stops, the scene is restored from the snapshot, discarding all changes made during play mode

### Edit-mode play routines

For per-frame work **without** entering Play Mode (no scene snapshot), use
`scene.play_routine_runner` / `Component.start_play_routine(bound_loop)`.

- Register a bound method `loop(dt) -> bool` (`True` = continue, `False` = stop).
- Or call `handle.stop()` from a Cancel button.
- Each tick (20 Hz): active loops → viewport render. Collision is not forced; FK / transforms request a coalesced sweep.
- Starting Play Mode stops all edit routines; starting a routine while playing is refused.
- While a sequence is running, the ribbon stays green and Stop remains enabled (so you can interrupt Main and run the Stop Sequence even if the current step is Simulate / Lift / Generate).
- While a play routine is active *and no sequence is running*, the ribbon turns blue; Play stays disabled and Stop stays enabled. Stop cancels standalone routines (`stop_all()`) then runs the Stop Sequence (put Cancel generate / Stop simulate in that list so IK and hardware restore).

See **[PlayRoutines.md](PlayRoutines.md)** for implementation instructions and **ComponentGuide.md** §2a for the short example.

## Selection Modes (Object / Vertex / Edge / Face)

The editor supports 4 selection modes, similar to common DCC tools.

Shortcuts:
- `1`: **Object Mode**
- `2`: **Vertex Mode** (requires `MeshComponent` on the selected entity)
- `3`: **Edge Mode** (requires `MeshComponent`)
- `4`: **Face Mode** (requires `MeshComponent`)

Entity editing shortcuts (fire when the focused widget is **not** a text input — Hierarchy tree, 3D viewport, docks all qualify):
- `Del`: Context-sensitive delete dispatched by `MainWindow._on_delete_shortcut`:
  - **Waypoint-first**: if a waypoint on a `CustomFeature` is currently selected (`SelectionModel.current_waypoint` + `current_waypoint_entity_id` on a `CustomFeature`), that single waypoint is deleted via `DeleteWaypointCommand`. The command snapshots the removed `Waypoint` (position + rotation) so undo restores it at its original index and reselects it; if the sub-selection pointed at the removed slot (or a later slot on the same segment that shifted down), it is cleared on redo and re-set on undo.
  - **Non-CustomFeature waypoint selection**: `Del` is intentionally a no-op — parametric segments regenerate their waypoints from control points so individual waypoints cannot be deleted, and falling back to entity deletion would surprise the user while they're focused on a waypoint marker.
  - **Otherwise** (no waypoint selected): delegates to `HierarchyPanel.delete_selected()` — deletes the current multi-selection (or the primary entity when a single row is selected). Each entity becomes one `DeleteEntityCommand`, batched into a single undo macro when more than one entity is selected.
- `Ctrl+D`: **Duplicate** the current multi-selection (or the primary entity). Wired to `HierarchyPanel.duplicate_selected()`; each duplicate is parented under its source entity's parent. Batched into a single undo macro for multi-selection. Waypoint-level duplicate is not currently supported.

Behavior:
- **Object Mode**:
  - Left click selects entities (object picking).
  - Selection highlight uses a **silhouette/outline** around the selected mesh.

- **Vertex / Edge / Face Modes** (mesh sub-selection):
  - These modes are only enabled when the current selection has a `MeshComponent`. If you select a non-mesh entity, the editor automatically returns to Object Mode.
  - The silhouette highlight is disabled.
  - The selected mesh shows **all edges** in dark grey for visual clarity.
  - Left click performs sub-selection on the selected mesh:
    - **Vertex Mode**: picks a vertex (`vtkCellPicker.GetPointId()`) and highlights it with a small yellow marker. The marker scales with camera zoom to remain roughly constant in screen space.
    - **Edge Mode**: picks the nearest edge of the picked face and highlights it with a thick yellow line.
    - **Face Mode**: picks the face (`vtkCellPicker.GetCellId()`) and highlights it with a translucent yellow overlay.

Vertex hover preview:
- In Vertex Mode the picker continuously ray-casts the mesh under the mouse and shows a **translucent cyan ghost marker** at the vertex that would be picked on click. The ghost uses an independent `vtkCellPicker` (`_hover_picker`) so it doesn't disturb the click picker's state, scales with camera zoom like the yellow click marker, and is hidden when leaving Vertex Mode, on viewport mouse-leave, or while the mouse is dragging (camera orbit).
- See `_on_mouse_move` / `_update_hover_marker` in `MotionStudio/render/vtk/picking.py`.

Selection lock (programmatic, used by VertexPick):
- `VtkPickerBridge.set_lock_entity_selection(True)` freezes `SelectionModel.current` for the duration of the lock. Sub-selection still works and `vertex_picked` / `face_picked` still fire; only entity selection is suppressed. Used by `VertexPickToolManager` so that picking a vertex on a non-selected mesh doesn't move the entity selection or rebuild the Inspector.

Show-edges-on-all-meshes (programmatic, used by VertexPick):
- `VtkSceneRoot.set_show_all_edges(True)` toggles dark-grey edges on every mesh actor (independent from the regular `_apply_edges` path which is keyed on `_edges_entity_id`). `VertexPickToolManager` enables it for the duration of an armed pick so the user can see and target vertices on **any** mesh in the scene, not just the selected one. Point-cloud actors are already pickable as points (no edge overlay). Disabling restores the regular per-entity edge behaviour without disturbing the currently selected mesh's edge state.

VertexPick inspector tool:
- `VertexPickToolManager` (`MotionStudio/ui/tools/vertex_pick_tool_manager.py`) is the editor-side glue between an `Annotated[QVector3D, VertexPick()]` field and the picker. On arm it records the owner entity id, requests Vertex Mode, enables `set_show_all_edges`, and engages `set_lock_entity_selection`. On a successful vertex pick (mesh or point-cloud point) it converts the picked `(picked_entity_id, point_id)` into the **owner entity's local frame**:
  1. Read the raw local point from the picked entity's geometry actor (`actor_for_vertex_pick` — mesh or the cloud that was clicked).
  2. `world_pt = transform_point(picked_entity, local)`.
  3. `result = inverse_transform_point(owner_entity, world_pt)`.
  When the owner and the picked entity are the same, the round-trip cancels and the raw local point is returned directly. The result is pushed to the field via the same `PropertyChangeCommand` used for manual edits, so undo / redo work normally. Owner-side world conversion at use-site: `transform_point(owner_entity, value)` from `MotionStudio/core/transform/utils.py`.
- **Multi-field retarget:** clicking **Pick** on a second `VertexPick` field while a pick is already armed retargets the manager (new callback / label / owner) without emitting `tool_active_changed(False)`. The Inspector clears the previous button's yellow "Picking..." state and highlights the newly armed field. Re-clicking the same field's Pick button still cancels.

Inspector **TCP** (`RobotTcp`) is a separate marker, not a VertexPick flag. It does not enter vertex mode. The written `QVector3D` is the live TCP origin in the **connected hardware robot’s base frame, millimetres** (`getActualTCPPose` × 1000). Resolve robot: scene **Primary Robot**, else the owning component’s `Optional[Robot]`. See `ComponentGuide.md` → **RobotTcp**.

Implementation overview:
- Mode actions are defined in `MotionStudio/ui/main_window.py` (Edit menu) and are wired to:
  - `VtkPickerBridge.set_selection_mode(mode)` in `MotionStudio/render/vtk/picking.py` (picking + sub-selection highlight actors + hover preview).
  - `VtkSceneRoot.set_selection_mode(mode)` in `MotionStudio/render/vtk/scene_root.py` (silhouette vs edge-visual selection visuals).

## GP Leak Path Generator

`GPLeakPathGenerator` (`MotionStudio/core/components/gp_leak_path_generator_component.py`) expands leak-port polylines on a Gas Panel into a full approach → touch → retract path for another Job entity.

**Setup**

1. On the Gas Panel entity: add **PathGeneration**, mark ports with **polyline** segments (name each segment), bind **robot** under Export Robot Program, and add **GPLeakPathGenerator**.
2. Orient a helper entity’s Transform as the default probe TCP rotation; assign it to **Default TCP transform** (position ignored; world rotation is the cone apex).
3. Create another entity with **PathGeneration** and assign it to **Generate path into**.
4. Open **Planner Settings** and tune `approach_height_mm`, `cone_tilt_deg`, `samples_per_port`, optional `position_offset_radius_mm` / `position_offset_samples`, and **Preview**. Optionally open **Action at leak port** (same PathGeneration I/O editor) and Add one or more Set Output / Wait Time / Wait Signal rows. Then click **Generate leak path** (all sticks) or set **segment_name** and click **Generate segment**.

**Behaviour**

- Source path is the sibling `PathGeneration` on the same entity; robot comes from that path’s Export binding.
- For each port (source segment order): try every conical approach sample at the original port first (untilted TCP from **Default TCP transform**, then jogs at `cone_tilt_deg`). If none are IK + collision-free, shift the port on a **world-XY** circle of `position_offset_radius_mm` (`position_offset_samples` even azimuth, starting at +X) and retry the full angle set at each offset. Radius `0` skips offsets. Skip the port if every offset/angle pair fails.
- **Viewport:** with **Preview** on, each play-routine frame moves the bound robot’s **RobotIK Target** to the candidate approach or touch pose, runs sync IK, then live `check_all` collision. Approach and touch are checked on consecutive frames so both are visible. Debug axes are drawn at the pose under test. With **Preview** off, the same cone/offset search runs on a background thread using `PlanningCollisionWorld` + `solve_ik_request` (Plan Motion style); the viewport arm is not posed.
- Approach / retract poses sit `approach_height_mm` along **−TCP +Z** from the port (same rotation). The touch waypoint (and its IK check) sits `offset_from_port` along that same line (`0` = TCP on the port; default `5` mm short). If the offset is larger than approach height it is clamped to approach height.
- On success, **Generate leak path** **replaces** the target path’s segments with one `CustomFeature` per source segment (same `name`, speed/CNT copied). **Generate segment** requires a unique source `segment_name` and **upserts** that one `CustomFeature` on the target (replace same name, else append). Its TCP JSON `return` is a comma-separated `1`/`0` mask, one flag per leak port in stick order (`1` reachable, `0` skipped); the same string is written to Inspector **`reach_array`**. Generate leak path does not update `reach_array`. Generate is not undoable.
- **Action at leak port** stores `leak_port_actions` (`List[PathAction]`) using the shared PathGeneration editor (`PathActionList` / `PathActionListEditor`). Generate clones every row onto each **touch** waypoint (`at=index`, indices 1, 4, 7, … in the approach → touch → retract triplet) so Path Mission and URScript fire them in list order after `movel` to that port. Anchor widgets are hidden on the generator because waypoint numbers are assigned at Generate, not by hand. Empty list writes waypoints only. After Generate you can still edit the copied actions on the target PathGeneration segment.
- Runs as an edit-mode **play routine** when Preview is on (blue ribbon); offline Generate keeps the viewport free and shows the same 3D-view loading overlay as Plan Motion (`scene.loading_controller.begin_external`). **Cancel generate** leaves the target unchanged (offline cancel interrupts the worker, overlay stays until the worker exits). Requires RobotIK + Target on the bound robot.

## Path Generation (Robot / CAD Assisted)

The editor includes a CAD-assisted robot path generator implemented as an ECS component plus a custom Inspector UI and a segment-creation toolbox dock.

### Overview

- **Component**: `MotionStudio.core.components.path_component.PathComponent` (serialized as type `"PathGeneration"`).
- **Segment model**: A `PathComponent` holds an ordered list of **segments** (traced sequentially). Python types remain `*Feature` classes for serialization compatibility; user-facing labels use **Segment** (e.g. Two-Point Line Segment).
- **Rendering**: The entire path is rendered as **one VTK actor per entity** (single polyline dataset) by `MotionStudio/render/vtk/path_bridge.py`.
- **Picking**: Segment creation uses **Vertex Mode** picking on the mesh (CAD references are stored as vertex ids).

### Quick Workflows

1) Select a mesh entity (must have `MeshComponent`).
2) Add the **PathGeneration** component in the Inspector.
3) Open **Toolbox** (button at the top of PathGeneration) and choose a segment tool:
   - **Two-Point Line Segment**: click 2 vertices in order.
   - **Three-Point Arc Segment**: click 3 vertices in order (Start, End, Mid).
   - **Polyline Segment**: click vertices in travel order (as many as needed). A yellow preview line tracks the picks. Press **Enter** to finish (writes a **Custom Segment** with sequenced waypoints); **Esc** or Toolbox **Cancel** aborts.
   - **Single-Point Segment**: click 1 vertex. The pick is stored immediately as a **Custom Segment** (one waypoint, Z along the surface normal) so it is gizmo-editable without an extra **Edit** conversion.
4) Adjust segments in the Inspector (top-down segment list). Open **Segment Settings** (gear) for offsets and arc options. The VTK path actor updates automatically.

### Inspector UI (Custom)

When an entity with `PathGeneration` is selected, the Inspector shows:

- **PathGeneration**:
  - **Toolbox** (floating dockable window, same pattern as Inspector `Group` docks): segment creation tools (line, arc, polyline, point, cancel). Title: `Entity -> PathGeneration -> Toolbox`.
  - **Path Program Settings** (floating dockable window): base **Speed** (m/s), **Acceleration** (m/s²), and **Default CNT Radius** (m, default `0.0`) used when exporting URScript, plus a **Default Actions** gear row (see **Segment I/O Actions**).
  - **Segments** (in sequence), each in a clickable group titled `N: <Segment Type>`:
    - **Edit** (parametric line/arc segments only): convert to a custom segment for direct waypoint editing. Single-point toolbox picks are already custom.
    - **Segment Settings** (floating dockable window): **Name** (optional label shown on the segment group box as `N: <name>`; empty keeps the type label, e.g. `1: Custom Segment`), **Speed Multiplier** (default `1.0`), **CNT Radius** (m, all segment types) and an **Actions** gear row (see **Segment I/O Actions**). Arc segments also expose axial/radial offsets, density, and rotations. Two-point line segments do not expose axial/radial offsets. **Flip Sequence** (line, arc, custom with two or more waypoints) reverses travel direction. Custom segments also offer **Apply Fixed Rotation** (copies the first waypoint’s rotation onto all waypoints).
    - **Move Up** / **Move Down**
    - **Remove Segment**
  - Custom segments show waypoint count in Segment Settings (with speed multiplier).
  - **Export Robot Program** (floating dockable `Group` window):
    - **Export Format** dropdown (`URScript` only for now).
    - **Robot** — entity picker for a `RobotDescription` (defines the reference frame for exported poses).
    - **Export Path** — `FilePath` line edit + **Browse** (a *Save* dialog, since the target need not exist). Pre-specifies the destination so **Export...** writes straight to it.
    - **Export...** (`@inspector_button(..., group="Export Robot Program")`) — writes the program file using poses expressed in that robot's base/`root_link` frame. Right-click **Export...** / `export_format` / `robot` / `export_path` copies the matching RUN / GET / EDIT TCP command. Program Settings and segment fields are not reflected TCP properties, so they have no copy menu.

Edits are undoable:
- Adding a segment uses a single undo step (`AddPathFeatureCommand`).
- Editing segment fields uses `PathFeaturePropertyChangeCommand`.
- Removing a segment uses `RemovePathFeatureCommand`.
- Editing either action list uses `PathActionsChangeCommand`.

### Segment I/O Actions

Each segment carries an ordered list of digital I/O **actions** that run *after* the robot reaches an anchored waypoint. Terminology follows UR PolyScope, since URScript is the export target:

- **Set** writes a digital **output**. Inputs are driven externally and cannot be written, so Set only offers output banks.
- **Wait Time** dwells for a fixed duration.
- **Wait Signal** polls a digital pin until it reaches a state, with an optional timeout (`0` waits forever). Banks include Standard / Configurable / Tool **In and Out** (`get_standard_digital_out` and the matching getters). Exported as a `sync()` loop so the pin is sampled every control cycle; see **URScript Export**. Path Mission uses `read_io` so waiting on an output does not write it. A non-zero timeout that expires logs and continues the mission (same as URScript); it is not a `FAIL`.
- **At** anchors the action: `First waypoint`, `Last waypoint`, `Every waypoint`, or `Waypoint N` (1-based in the UI, 0-based in the model). An anchor outside the segment resolves to nothing rather than raising, so a stale `Waypoint N` is simply skipped after the segment shrinks.
- **Bank** disambiguates the port number. Outputs: `standard_out` / `configurable_out` (ports 0-7), `tool_out` (0-1). Inputs: the matching `standard_in` / `configurable_in` / `tool_in`. Set Output lists outputs only; Wait Signal lists all six. Tables live in `MotionStudio/core/path/actions.py` (`BANKS`), which also owns `PathAction`, `to_dict` / `from_dict`, `summary_text()` and `resolve_waypoint_indices()`.

**Editor** — `MotionStudio/ui/inspector/path_actions_dialog.py`. `open_path_actions_dock(panel, entity, segment_idx)` opens one floating dock per PathGeneration target (`segment_idx=None` = program defaults), titled `Entity -> PathGeneration -> Segment N Actions` / `... -> Default Actions`. Other components reuse the same widget: annotate a `List[PathAction]` field with `PathActionList` (see ComponentGuide) and call `open_component_path_actions_dock(...)`. `PathActionListEditor` renders one compact row per action rather than a table, because the three kinds carry different fields. Rows offer an enable checkbox, kind / anchor / bank / state combos, port and duration spin boxes, reorder arrows (actions at the same waypoint run in list order), and remove. `show_anchors=False` hides the At / Waypoint N widgets when the host stamps indices itself (GP leak touch waypoints). Every edit pushes a whole-list `PathActionsChangeCommand`; the resulting `entity_changed` rebuilds the rows from the model, deferred through `QTimer.singleShot(0, ...)` so a row is never destroyed inside its own signal handler. Spin boxes commit on `editingFinished`, since these commands do not merge.

**Defaults** — `PathComponent.default_actions` is a template, not a live link. `path_tool_manager._commit_feature` copies it onto a new segment *before* the `AddPathFeatureCommand` snapshot, so undo/redo carries the seeded actions; editing the defaults afterwards never changes existing segments. `ConvertToCustomFeatureCommand` copies `actions` alongside `name` / `speed_multiplier` / `cnt_radius`, so converting a segment keeps them.

**Blend interaction** — Segment Settings shows a warning when a segment has both enabled actions and a non-zero CNT Radius; see the export rule under **URScript Export**.

**Out of scope** — Live execution and Play Mode ignore actions. `MotionPlannerComponent` reads only waypoint poses and `speed_multiplier`, and `universal_robot_sdk.py` has no digital I/O today, so actions reach the robot only through the exported `.script`.

### Segment types

#### Two-Point Line Segment (`TwoPointLineFeature`)

- **CAD references**: `local_points = [start, end]` (entity-local)
- **Parameters** (Segment Settings):
  - `axial_offset`: per-segment
  - `radial_offset`: per-segment
  - **Flip Sequence**: swaps start/end and regenerates waypoints so travel direction reverses.
- **Waypoints**: currently generates start/end waypoints (interpolation can be extended).

#### Polyline Segment (Toolbox → CustomFeature)

- **CAD references**: an open-ended sequence of mesh vertices in travel order (entity-local).
- **Interaction**: Vertex Mode stays on until **Enter** (finish) or **Esc** / Toolbox **Cancel**. Each click appends a vertex; a yellow preview polyline (with point markers) updates after every pick. The viewport overlay shows the current waypoint count and the Enter / Esc hints.
- **Result**: Enter writes a **Custom Segment** (`CustomFeature`) — one sequenced waypoint per clicked vertex. Z follows the averaged adjacent-face normal; X is aligned along travel in that tangent plane. After that it behaves like any other custom segment (gizmo edit, Flip Sequence, Apply Fixed Rotation).

#### Three-Point Arc Segment (`ThreePointArcFeature`)

- **CAD references**: `local_points = [start, end, mid]` (entity-local)
- **Parameters** (Segment Settings):
  - `axial_offset`: per-segment
  - `radial_offset`: per-segment
  - `density_multiplier`: controls sampling resolution along the arc
  - **Flip Sequence**: swaps start/end (mid unchanged) and regenerates waypoints so the same arc is traversed opposite.
- **Waypoint generation**:
  - Computes circle center through the 3 points.
  - Chooses CW/CCW sweep so the arc goes from start to end **and passes through mid** (prevents wrap-around).
  - Samples along the arc and computes a per-waypoint orientation.

#### Custom Segment (`CustomFeature`)

- Created via the **Edit** button on a parametric line/arc segment in the Inspector; **immediately** when the Toolbox **Single-Point Segment** tool finishes a vertex pick (one waypoint, orientation from the averaged adjacent-face normal); or when the Toolbox **Polyline Segment** tool is confirmed with **Enter** (one waypoint per clicked vertex, in click order).
- Stores waypoints directly (`position` + `rotation`) instead of regenerating from CAD vertex ids.
- **Flip Sequence**: reverses the stored waypoint list (travel order).
- **Apply Fixed Rotation**: copies the first waypoint’s rotation onto every waypoint so the segment keeps a constant orientation while positions stay unchanged.
- Waypoint visualization and editing in the viewport:
  - Custom-segment waypoints render as camera-facing discs. On the **selected** custom segment they match the path overlay (**light green**). Other custom segments stay **yellow**.
  - Clicking a waypoint selects it; the selected waypoint stays **orange** and slightly larger (unchanged). Sibling waypoints on that custom segment remain light green.
  - Sphere radii are camera-aware (screen-space stable) so waypoints keep a near-constant on-screen size while zooming.
  - Translate and rotate gizmo handles appear on the selected waypoint so its pose can be edited interactively.
- **Waypoint frame composition** (`MotionStudio/render/vtk/gizmo/waypoint_gizmo.py`):
  - Waypoints are stored in the **owning entity's local (mesh) frame** (`waypoint.position`, `waypoint.rotation`).
  - The waypoint gizmo positions itself using a hidden **proxy entity** (`__waypoint_proxy__`) that lives outside the hierarchy but inside `Scene._entities_by_id` so the translate / rotate gizmos can read its `TransformComponent`.
  - On selection, `_update_proxy_entity` / `_update_gizmo_position` lift the waypoint into world space:
    - position: `world = mesh_actor.GetUserMatrix() * local`
    - rotation: `q_world = world_rotation_quat(entity) * q_local` — composing with the entity's world rotation is essential, otherwise gizmo handles point along the mesh-local axes regardless of the entity's pose.
  - On drag, `_on_entity_transform_changed` reverses both transforms (`mesh_actor.GetUserMatrix().inverse()` for position; `world_rotation_quat(entity).inverted() * q_world` for rotation) before writing back to the waypoint.

### Rendering Details (Single Actor)

`MotionStudio/render/vtk/path_bridge.py` rebuilds a `vtkPolyData` line set when the entity changes:

- Each waypoint contributes a point to the polydata.
- Line segments are created between consecutive waypoints.
- A mapping `vtk_point_id -> (segment_index, waypoint_index)` is maintained for per-waypoint selection/editing.

### Segment selection (click path / click Inspector)

PathGeneration supports selecting individual segments (within the selected entity) by clicking either:

- The **path polyline** in the 3D view, or
- The **segment GroupBox** in the Inspector.

Behavior:

- Selecting a segment highlights it visually:
  - The selected segment’s path cells render in a **brighter green** (per-cell colors on a single VTK actor).
  - The selected segment’s GroupBox shows a **highlighted outline** in the Inspector.
- Changing the selected entity clears the segment selection (Unity-like).

Implementation overview:

- **Selection state**:
  - `MotionStudio/core/scene/selection.py` extends `SelectionModel` with:
    - `current_feature_idx: Optional[int]`
    - `current_feature_changed` signal
    - `set_current_feature(feature_idx)` to select/clear feature selection
- **VTK picking**:
  - `MotionStudio/render/vtk/picking.py` detects clicks on the path actor (via `VtkPathBridge` actor registry),
    resolves the clicked point id to a feature index, then calls `SelectionModel.set_current_feature(...)`.
- **VTK highlighting**:
  - `MotionStudio/render/vtk/path_bridge.py` builds a `cell_id -> feature_idx` map and assigns a `vtkUnsignedCharArray`
    on cell data for per-segment coloring (default green vs selected green).
  - The bridge listens to `current_feature_changed` and updates the path colors immediately.
- **Inspector interaction**:
  - `MotionStudio/ui/widgets/clickable_group_box.py` provides a `ClickableGroupBox`.
  - `MotionStudio/ui/inspector_panel.py` uses it for each segment group and highlights the selected one via stylesheet.
  - Parametric fields open via `open_path_segment_settings_dock` (floating `QDockWidget`, same host pattern as Inspector `Group` docks in `MotionStudio/ui/inspector/inspector_dock.py`).
  - Segment tools open via `open_path_toolbox_dock` (`MotionStudio/ui/inspector/path_toolbox_dialog.py`); path program settings via `open_path_program_settings_dock`.
  - Closing the Toolbox dock cancels any active path tool.
  - Segment / program settings dock refresh is deferred with `QTimer.singleShot(0, ...)` on `entity_changed` / undo-redo to avoid rebuilding Qt editors during `editingFinished` callbacks.

### Selection Mode Integration

- Activating a path tool from the Toolbox dialog requests **Vertex Mode** automatically so the next clicks pick CAD references on the mesh. The single-point tool also uses Vertex Mode; on click it writes a `CustomFeature` rather than leaving a `SinglePointFeature` in the path. The polyline tool stays in Vertex Mode until **Enter** (or **Esc** / Cancel): each click appends a vertex, and Enter bakes a `CustomFeature` with sequenced waypoints (Z along the averaged adjacent-face normal, X along travel).

### Persistence (.scn)

`PathGeneration` saves as a normal component entry:

- `PathComponent.to_dict()` stores:
  - `segments`: list of `{ "type": <FeatureClassName>, "data": {...} }` (legacy saves may use `features`; both load correctly)
- Path-level: `speed`, `acceleration`, `default_cnt_radius` (URScript defaults `0.25` m/s, `1.2` m/s², CNT `0.0` m), plus `export_format`, `robot` (entity id of the selected `RobotDescription`), `export_path`, and `default_actions`.
- Each segment stores:
  - `name` (optional Inspector label; empty → type title such as `Custom Segment`)
  - `speed_multiplier` (default `1.0`)
  - `cnt_radius` (default copied from `default_cnt_radius` when created via toolbox)
  - `local_points` (control points in entity-local millimetres; legacy `vertex_ids` are dropped on load)
  - `axial_offset`, `radial_offset`
  - `actions` (list of I/O action dicts; see **Segment I/O Actions**)
  - Arc: `density_multiplier`
- `actions` and `default_actions` are lists of `{kind, at, at_index, bank, port, state, duration_s, timeout_s, enabled}`. `PathAction.from_dict` tolerates missing or unknown keys and clamps the port to its bank, so older saves load with empty lists and hand-edited files cannot produce an out-of-range port. Note that `CustomFeature.to_dict` / `from_dict` do **not** call the `Feature._base_dict` helpers, so they serialize `actions` themselves.

### Robot Program Export

The PathGeneration component supports exporting waypoint paths to robot programming languages:

- **Export Robot Program** Inspector gear group (`Group("Export Robot Program")` on `export_format` / `robot` / `export_path`, plus `@inspector_button(..., group=...)`).
- **Destination** (`export_path`) — when set, **Export...** writes there with no dialog, which is what makes the button usable unattended (e.g. from a TCP `RUN`). Resolution mirrors `UniversalRobot.script_path`: absolute paths are used as-is, relative ones resolve under `scene.project_root`, and a missing `.script` suffix is appended (`_configured_export_path()`). Missing parent folders are created. Left blank, the old Save dialog appears and the chosen path is written back into the field, so only the first export needs a human.
- Coordinates are transformed into the selected robot's base frame before writing the file:
  - Resolve `RobotDescription.root_link` entity (fallback: robot root entity).
  - Build each world waypoint pose from `get_world_waypoints_by_segment()`.
  - Compute `T_base_wp = inv(T_world_base) · T_world_wp` via `PathComponent.get_waypoints_in_robot_frame()`.
  - Positions remain in millimetres until the format exporter converts units.
- Export requires a **Robot** reference; otherwise the Inspector warns and aborts.

- **URScript Export** (`MotionStudio/core/path/exporters/urscript_exporter.py`):
  - Exports path waypoints to Universal Robots URScript format (`.script` files).
  - Converts Euler angles (degrees) to rotation vectors (axis * angle in radians).
  - Converts positions from engine millimetres to URScript metres on export.
  - Wraps the entire move sequence inside a `def move_path(): ... end` function and emits `move_path()` at the bottom of the script so the program can be invoked as a single call.
  - Uses `movel()` to reach the first waypoint of every segment and `movep()` for subsequent in-segment waypoints, giving clean linear transitions between segments and blended tool-space motion within a segment.
  - **Speed** per move: `Path Program Settings.speed × segment.speed_multiplier`.
  - **Acceleration** from Path Program Settings (`acceleration` on `PathComponent`).
  - **CNT radius** per segment: `segment.cnt_radius` emitted as URScript `r=` when greater than zero (metres).
  - **I/O actions** per segment (`segment_actions` parameter, passed as `[seg.actions for seg in segments]`): enabled actions are resolved to waypoint indices and emitted immediately after the move that reaches them, in list order. `Set` becomes `set_<bank>_digital_out(port, True|False)` and `Wait Time` becomes `sleep(seconds)` (a dwell is what `sleep` is for).
  - **Wait Signal** becomes a `while <getter>(port) != <state>:` loop polled with `sync()`, using that bank's URScript getter (`get_standard_digital_in` / `get_standard_digital_out` and the configurable / tool variants). `sync()` yields exactly the remainder of the control cycle — 2 ms on e-Series (500 Hz), 8 ms on CB3 (125 Hz) — so the pin is sampled every frame and short pulses are not missed. `sleep()` is deliberately *not* used to poll: it rounds up to whole cycles, and UR's manual warns it can raise `Runtime is too much behind` when used in loops. A non-zero timeout adds `t_wait_<n>` / `step_wait_<n>` variables (unique per loop across the program) that advance by `get_steptime()`, the duration of one `sync()`, so the timeout stays accurate on either controller rather than drifting against a hardcoded period. On expiry a `textmsg(...)` guard reports the signal and the program continues.
  - **Exact-stop rule**: URScript continues to the next statement when the robot *enters* the blend zone, so an action on a blended waypoint would fire early and a `Wait` would be meaningless. A waypoint carrying at least one enabled action is therefore emitted without `r=`, tagged `exact stop for action` in the trailing comment. Other waypoints in the same segment keep their blend.
  - Empty segments stay in place: export writes `# Segment N/M (0 waypoints, v=… m/s)` and continues. Their speed / CNT / actions are **not** applied to the next segment, and later `# Segment N/M` numbering stays aligned with the Inspector.
  - Source methods: `get_waypoints_in_robot_frame()` for export; `get_world_waypoints_by_segment()` / `get_world_waypoint_transforms()` remain available for world-space queries.


## Quick Usage Examples
- Create an entity and add a Transform:
```python
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.components.transform_component import TransformComponent
from PyQt6.QtGui import QVector3D

scene = Scene()
ent = scene.create_entity(\"Actor\")
ent.add_component(TransformComponent(position=QVector3D(0, 1, 0)))
```

- Save and load a scene:
```python
from MotionStudio.core.serialization.json_io import save_scene, load_scene
save_scene(scene, \"assets/scenes/example.scn\")
load_scene(scene, \"assets/scenes/example.scn\")
```


## Run
```bash
python scripts/run_dev.py
```
Ensure dependencies are installed:
```bash
pip install -r requirements.txt
```

## Build exe

Use the project PyInstaller spec (keeps Qt binding forced to PyQt6 and bundles non-code data):

```bash
pyinstaller build.spec
```

Output is **one-dir**: run `dist/iMOVE/iMOVE.exe` (ship the whole `dist/iMOVE/` folder). Prefer this over onefile for faster startup with the heavy ssik/scipy stack.

`build.spec` notes:

- Entry: `main.py` → one-dir `dist/iMOVE/` (`EXE` + `COLLECT`, `console=False`). Preferences and other beside-exe paths resolve next to `iMOVE.exe` inside that folder.
- Theme: `collect_all("qdarktheme")` + `collect_all("darkdetect")` (package import name is `qdarktheme`).
- **Collada / URDF DAE meshes:** `collect_all("collada")` so `collada/resources/schema-1.4.1.xml` is available under `sys._MEIPASS` (the app folder in onedir). Without this, Import URDF / DAE→GLB fails only in the frozen build (dev uses site-packages resources on disk).
- **STEP / STP import:** `collect_all("cascadio")` plus the sibling `cascadio.libs` folder (OpenCASCADE DLLs installed by delvewheel) so tessellation works in the frozen app. Without this, STEP→STL fails only in the exe (dev uses the pip-installed `cascadio` wheel).
- **Analytical IK (ssik):** MotionStudio imports `ssik` / `urchin` lazily, so PyInstaller will not pull them unless forced. `build.spec` uses `collect_all` for `ssik`, `urchin`, `sympy`, `scipy`, `Cython`, `lxml`, and `networkx` (URDF parse + closed-form codegen + runtime of generated `*_analytic_ik.py` modules). Without this, **Regenerate Analytical IK** / import-time generation produces no `.py` in the build (and the analytic backend cannot load solvers). Failures show a dialog (windowed builds have no console).
- App icons / SVG tools: `datas += ("resources", "resources")`.
- `excludes=["PySide6"]` so pyqtdarktheme does not bind a missing Qt.
- Runtime option `X faulthandler` is passed to the `EXE` so native crashes dump Python stacks (see **Crash / render logs** under Rendering).
- Graphics env defaults (`__GL_THREADED_OPTIMIZATIONS=0`, `PYVISTA_MULTI_SAMPLES=0`) and OpenBLAS (`OPENBLAS_NUM_THREADS=1`, `OPENBLAS_CORETYPE=Haswell`) are set in `main.py` via `os.environ.setdefault`, so no launcher `.bat` is needed; set them externally to override.
- **SDK helper processes:** `main.py` calls `multiprocessing.freeze_support()` first under `__main__`, so `iMOVE.exe` started as a helper runs the helper instead of a second editor. The helper service modules (`sdk_host`, `universal_robot_sdk`, `mechmind_scanner_sdk`, `ply_numpy`) and `rtde_receive` / `rtde_control` / `rtde_io` / `mecheye.*` are listed in `hiddenimports` because helpers import them by name. Expect extra `iMOVE.exe` processes in Task Manager while a robot or scanner is connected.



"""Scan Mission: walk a parallelogram grid and capture at each cell."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Annotated, Any, Dict, List, Literal, Optional, Tuple

from PyQt6.QtGui import QMatrix4x4, QQuaternion, QVector3D

from MotionStudio.core.components.robot import Robot
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.robot_ik_component import RobotIKComponent
from MotionStudio.core.components.scanner import Scanner, clear_scanner_cloud
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.path.exporters.urscript_exporter import euler_to_rotation_vector
from MotionStudio.core.remote.protocol import interpret_button_result
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	transform_point,
	world_matrix,
	world_rotation_quat,
)
from MotionStudio.ui.inspector.metadata import (
	ConnectionStatus,
	Group,
	Order,
	Range,
	ReadOnly,
	Tooltip,
	VertexPick,
	inspector_button,
)
from MotionStudio.utils.point_cloud_overlap import (
	MAX_OVERLAP_VOXEL_MM,
	MIN_OVERLAP_VOXEL_MM,
	clamp_overlap_voxel_mm,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity


STATUS_IDLE = "Idle"
STATUS_RUNNING = "Running…"
STATUS_STOPPING = "Stopping…"
GROUP_GRID = "Grid Settings"
_EPS_MM = 1e-3
_PARALLEL_COS = 0.999


@dataclass
class _ScanCell:
	world_pos: QVector3D
	world_quat: QQuaternion
	base_pos_mm: QVector3D
	base_rotvec: QVector3D


def _qvec(value: Optional[QVector3D]) -> QVector3D:
	if isinstance(value, QVector3D):
		return QVector3D(value)
	return QVector3D(0.0, 0.0, 0.0)


def _rotvec_rad_to_deg(v: QVector3D) -> QVector3D:
	return QVector3D(
		math.degrees(float(v.x())),
		math.degrees(float(v.y())),
		math.degrees(float(v.z())),
	)


def _quat_to_rotvec(q: QQuaternion) -> QVector3D:
	euler = QQuaternion(q).toEulerAngles()
	rx, ry, rz = euler_to_rotation_vector(float(euler.x()), float(euler.y()), float(euler.z()))
	return QVector3D(float(rx), float(ry), float(rz))


def _rotation_from_matrix(matrix: QMatrix4x4) -> QQuaternion:
	return QQuaternion.fromRotationMatrix(matrix.normalMatrix())


def _hw_connected(component: Any) -> bool:
	return bool(getattr(component, "_was_connected", False))


@register_component
class ScanMissionComponent(Component):
	type_name = "ScanMission"
	category = "Path generation and planning"
	description = (
		"<p><b>Scan Mission</b></p>"
		"<p>Walks a parallelogram grid and, at each cell, <b>Move To Target</b> on a "
		"bound <b>Robot</b> then <b>Capture</b> on a bound <b>Scanner</b>.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Assign <b>robot</b> (UniversalRobot) and <b>scanner</b> (MechmindScanner). "
		"Connect both first. Bind <b>RobotDescription</b> on the UniversalRobot "
		"<b>robot</b> field, or as a sibling on the controller entity, so poses "
		"are in the arm base frame.</li>"
		"<li>Open <b>Grid Settings</b>: pick origin, along-columns, and along-rows "
		"corners (parallelogram), set rows/columns, assign a <b>TCP rotation</b> "
		"Transform. <b>Show Grid</b> toggles the viewport overlay. "
		"<b>overlap_voxel_mm</b> drops new points in voxels the accumulated cloud "
		"already occupies (0 = keep every captured point). "
		"Scanner <b>downsample_ratio</b> is per-frame keep-fraction and does not "
		"remove spatial duplicates.</li>"
		"<li><b>Run Scan Mission</b> / <b>Stop Scan Mission</b>. Run clears the "
		"previous cloud first. After each hardware move, the virtual arm is posed "
		"by setting the <b>RobotIK Target</b> to the scan cell (same world pose "
		"as the grid overlay) and solving IK — not by copying controller joints. "
		"Stop aborts the routine and UR motion; an in-flight Capture still finishes.</li>"
		"</ul>"
	)

	mission_type: Annotated[
		Literal["Grid"],
		Order(0),
		Tooltip("Scan pattern. Grid Settings apply when Grid is selected."),
	] = "Grid"
	robot: Annotated[
		Optional[Robot],
		Order(10),
		Tooltip(
			"Hardware robot controller (UniversalRobot or other Robot subclass). "
			"Bind RobotDescription on that controller's robot field, or as a "
			"sibling on the controller entity."
		),
	]
	scanner: Annotated[
		Optional[Scanner],
		Order(20),
		Tooltip("Hardware scanner (MechmindScanner or other Scanner subclass)."),
	]
	mission_status: Annotated[
		str,
		ConnectionStatus(connected=(STATUS_IDLE,), busy=(STATUS_RUNNING, STATUS_STOPPING)),
		ReadOnly(),
		Order(30),
		Tooltip("Live mission state. Not restored from the scene file."),
	]
	show_grid: Annotated[
		bool,
		Group(GROUP_GRID),
		Order(90),
		Tooltip("Draw grid corners, nodes, and TCP +Z rays in the 3D viewport."),
	] = True
	grid_origin: Annotated[
		QVector3D,
		Group(GROUP_GRID),
		VertexPick(),
		Order(100),
		Tooltip("Parallelogram corner at cell (0, 0). Owner-local millimetres."),
	]
	grid_along_columns: Annotated[
		QVector3D,
		Group(GROUP_GRID),
		VertexPick(),
		Order(110),
		Tooltip("Parallelogram corner at cell (0, cols-1). Owner-local millimetres."),
	]
	grid_along_rows: Annotated[
		QVector3D,
		Group(GROUP_GRID),
		VertexPick(),
		Order(120),
		Tooltip("Parallelogram corner at cell (rows-1, 0). Owner-local millimetres."),
	]
	grid_rows: Annotated[
		int,
		Group(GROUP_GRID),
		Order(130),
		Range(1, 200, step=1),
		Tooltip("Number of cells along the origin → along-rows edge."),
	] = 2
	grid_cols: Annotated[
		int,
		Group(GROUP_GRID),
		Order(140),
		Range(1, 200, step=1),
		Tooltip("Number of cells along the origin → along-columns edge."),
	] = 2
	overlap_voxel_mm: Annotated[
		float,
		Group(GROUP_GRID),
		Order(145),
		Range(MIN_OVERLAP_VOXEL_MM, MAX_OVERLAP_VOXEL_MM, step=0.1, decimals=2),
		Tooltip(
			"Millimetres. 0 disables (concat every capture). Overlapping cells "
			"drop new points in voxels the accumulated cloud already occupies; "
			"stored points are not re-filtered. Typical overlapping FOV: 1–2 mm."
		),
	] = 0.0
	tcp_rotation: Annotated[
		Optional[TransformComponent],
		Group(GROUP_GRID),
		Order(150),
		Tooltip(
			"Transform whose world rotation is the TCP orientation at every cell. "
			"Position is ignored."
		),
	]

	def __init__(self) -> None:
		self.mission_type = "Grid"
		self.robot = None
		self.scanner = None
		self.mission_status = STATUS_IDLE
		self.show_grid = True
		self.grid_origin = QVector3D(0.0, 0.0, 0.0)
		self.grid_along_columns = QVector3D(100.0, 0.0, 0.0)
		self.grid_along_rows = QVector3D(0.0, 100.0, 0.0)
		self.grid_rows = 2
		self.grid_cols = 2
		self.overlap_voxel_mm = 0.0
		self.tcp_rotation = None
		self._handle = None
		self._listeners: list = []
		self._notified = False
		self._cancel = False
		self._cells: List[_ScanCell] = []
		self._cell_index = 0
		self._phase = "idle"
		self._await_kind = ""
		self._job_done = False
		self._job_ok = False
		self._job_message = ""
		self._bound_robot: Optional[Robot] = None
		self._bound_scanner: Optional[Scanner] = None

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "ScanMissionComponent":
		inst = super().from_dict(data)
		inst.force_setattr("mission_status", STATUS_IDLE)
		return inst

	def add_mission_listener(self, callback) -> None:
		if callback not in self._listeners:
			self._listeners.append(callback)

	def remove_mission_listener(self, callback) -> None:
		try:
			self._listeners.remove(callback)
		except ValueError:
			pass

	def _notify_done(self, success: bool, message: str = "") -> None:
		if self._notified:
			return
		self._notified = True
		for callback in list(self._listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	@inspector_button(
		"Run Scan Mission",
		tooltip=(
			"Clear the previous cloud, then move to each grid cell and capture "
			"(requires connected Robot and Scanner)"
		),
		order=200,
	)
	def run_scan_mission(self):
		if self._handle is not None and self._handle.is_running:
			return False, "scan mission is already running"
		entity = self.entity
		if entity is None:
			return False, "no entity"
		scene = entity.scene
		if scene is None:
			return False, "entity is not in a scene"
		pm = getattr(scene, "play_mode_manager", None)
		if pm is not None and getattr(pm, "is_playing", False):
			return False, "refused while Play Mode is active"
		if str(self.mission_type or "Grid") != "Grid":
			return False, f"unsupported mission type: {self.mission_type}"

		mover = self._resolved_robot()
		if mover is None:
			return False, "assign a Robot"
		scanner = self._resolved_scanner()
		if scanner is None:
			return False, "assign a Scanner"
		if not _hw_connected(mover):
			return False, "robot is not connected"
		if not _hw_connected(scanner):
			return False, "scanner is not connected"

		tcp = self._resolved_tcp()
		if tcp is None or tcp.entity is None:
			return False, "assign TCP rotation"

		rd = self._resolved_robot_description(mover)
		if rd is None:
			return False, (
				"bind RobotDescription on the UniversalRobot robot field "
				"(or as a sibling on the controller entity)"
			)
		base_ent = self._robot_base_entity(rd)
		if base_ent is None:
			return False, "could not resolve robot base / root_link"

		err = self._grid_error()
		if err:
			return False, err

		cells, build_err = self._build_cells(entity, tcp.entity, base_ent)
		if build_err:
			return False, build_err
		if not cells:
			return False, "grid has no cells"

		clear_err = clear_scanner_cloud(scanner)
		if clear_err:
			return False, clear_err

		self._cells = cells
		self._cell_index = 0
		self._phase = "start_move"
		self._cancel = False
		self._notified = False
		self._await_kind = ""
		self._job_done = False
		self._bound_robot = mover
		self._bound_scanner = scanner
		mover.add_job_listener(self._on_hw_job)
		scanner.add_job_listener(self._on_hw_job)
		self.mission_status = STATUS_RUNNING
		self._handle = self.start_play_routine(self._loop, name="scan_mission")
		if self._handle is None or not self._handle.is_running:
			self._teardown_hw()
			self.mission_status = STATUS_IDLE
			return False, "scan mission did not start"
		return True

	@inspector_button(
		"Stop Scan Mission",
		tooltip="Abort the grid walk and halt the robot (in-flight Capture still finishes)",
		order=210,
	)
	def stop_scan_mission(self) -> None:
		running = self._handle is not None and self._handle.is_running
		if not running and self._bound_robot is None:
			return
		self._cancel = True
		self.mission_status = STATUS_STOPPING
		mover = self._bound_robot
		if mover is not None:
			try:
				mover.stop_robot()
			except Exception:
				pass
		if self._handle is not None:
			self._handle.stop()
			self._handle = None
		self._teardown_hw()
		self.mission_status = STATUS_IDLE
		self._notify_done(False, "cancelled")

	def _loop(self, _delta_time: float) -> bool:
		if self._cancel:
			self._finish(False, "cancelled")
			return False
		mover = self._bound_robot
		scanner = self._bound_scanner
		if mover is None or scanner is None:
			self._finish(False, "robot or scanner unbound")
			return False

		if self._phase == "wait_move" or self._phase == "wait_sync" or self._phase == "wait_capture":
			if not self._job_done:
				return True
			if not self._job_ok:
				kind = (
					"move"
					if self._phase == "wait_move"
					else "sync joints"
					if self._phase == "wait_sync"
					else "capture"
				)
				self._finish(False, self._job_message or f"{kind} failed")
				return False
			if self._phase == "wait_move":
				# Hardware is at the cell. Pose the virtual URDF via IK Target
				# (grid world pose), not getActualQ FK — controller joints on a
				# UR base_link chain snap the CAD into the opposite quadrant.
				ik_err = self._pose_virtual_to_current_cell()
				if ik_err is None:
					self._phase = "start_capture"
				elif ik_err == "no_ik":
					self._phase = "start_sync"
				else:
					self._finish(False, ik_err)
					return False
			elif self._phase == "wait_sync":
				self._phase = "start_capture"
			else:
				if not _hw_connected(mover):
					self._finish(False, "robot disconnected during capture")
					return False
				self._cell_index += 1
				self._phase = "start_move"

		if self._phase == "start_move":
			if self._cell_index >= len(self._cells):
				n = len(self._cells)
				self._finish(True, f"scanned {n} cell{'s' if n != 1 else ''}")
				return False
			cell = self._cells[self._cell_index]
			Debug.log(
				f"ScanMission: cell {self._cell_index + 1}/{len(self._cells)}"
			)
			try:
				mover.set_move_target(cell.base_pos_mm, _rotvec_rad_to_deg(cell.base_rotvec))
			except Exception as exc:
				self._finish(False, f"set_move_target failed ({exc})")
				return False
			self._arm_wait("move_to_target")
			result = mover.move_to_target()
			if result is True:
				self._phase = "wait_move"
				return True
			_ok, output = interpret_button_result(result)
			self._finish(False, output or "move_to_target did not start")
			return False

		if self._phase == "start_sync":
			self._arm_wait("apply_actual_configuration")
			result = mover.apply_actual_configuration()
			if result is True:
				self._phase = "wait_sync"
				return True
			_ok, output = interpret_button_result(result)
			self._finish(False, output or "apply_actual_configuration did not start")
			return False

		if self._phase == "start_capture":
			self._arm_wait("capture")
			voxel = clamp_overlap_voxel_mm(self.overlap_voxel_mm)
			try:
				result = scanner.capture_scan(overlap_voxel_mm=voxel)
			except TypeError:
				result = scanner.capture_scan()
			if result is True:
				self._phase = "wait_capture"
				return True
			_ok, output = interpret_button_result(result)
			self._finish(False, output or "capture did not start")
			return False

		self._finish(False, f"unknown phase: {self._phase}")
		return False

	def _current_cell(self) -> Optional[_ScanCell]:
		if 0 <= self._cell_index < len(self._cells):
			return self._cells[self._cell_index]
		return None

	def _resolve_scan_ik(
		self, mover: Robot
	) -> Optional[Tuple[RobotIKComponent, "Entity"]]:
		rd = self._resolved_robot_description(mover)
		robot_ent = rd.entity if rd is not None else getattr(mover, "entity", None)
		if robot_ent is None:
			return None
		ik = robot_ent.get_component(RobotIKComponent)
		if ik is None:
			return None
		target = getattr(ik, "target", None)
		if not isinstance(target, TransformComponent):
			return None
		target_ent = target.entity
		if target_ent is None:
			return None
		return ik, target_ent

	def _pose_virtual_to_current_cell(self) -> Optional[str]:
		"""Drive RobotIK Target to the scan cell in world, then solve.

		Returns None on success, ``\"no_ik\"`` to fall back to live-joint FK,
		or an error string to abort.
		"""
		mover = self._bound_robot
		cell = self._current_cell()
		if mover is None or cell is None:
			return "scan cell is missing"
		resolved = self._resolve_scan_ik(mover)
		if resolved is None:
			return "no_ik"
		ik, target_ent = resolved
		scene = target_ent.scene if target_ent is not None else None
		ik_sys = getattr(scene, "robot_ik_system", None) if scene is not None else None
		if ik_sys is None:
			return "no_ik"
		# Posing the Target would otherwise enqueue an async solve on the IK
		# worker, then solve_sync would run a second ssik/LAPACK call at once.
		with ik_sys.suppress_async():
			set_world_position(target_ent, cell.world_pos)
			set_world_rotation_quat(target_ent, cell.world_quat)
			result = ik_sys.solve_sync(ik)
		if result is None or not getattr(result, "joint_values", None):
			msg = getattr(result, "message", None) if result is not None else None
			return str(msg or "IK to scan cell failed")
		if not bool(getattr(result, "success", False)):
			return str(getattr(result, "message", None) or "IK to scan cell did not converge")
		robot_ent = ik.entity
		if robot_ent is not None and scene is not None:
			try:
				scene.events.entity_changed.emit(robot_ent.id)
			except Exception:
				pass
		return None

	def _arm_wait(self, kind: str) -> None:
		self._await_kind = kind
		self._job_done = False
		self._job_ok = False
		self._job_message = ""

	def _on_hw_job(self, kind: str, success: bool, message: str) -> None:
		if kind != self._await_kind:
			return
		self._job_done = True
		self._job_ok = bool(success)
		self._job_message = str(message or "")

	def _finish(self, success: bool, message: str) -> None:
		self._handle = None
		self._teardown_hw()
		self.mission_status = STATUS_IDLE
		self._notify_done(success, message)

	def _teardown_hw(self) -> None:
		mover = self._bound_robot
		scanner = self._bound_scanner
		self._bound_robot = None
		self._bound_scanner = None
		self._await_kind = ""
		self._phase = "idle"
		self._cells = []
		if mover is not None:
			try:
				mover.remove_job_listener(self._on_hw_job)
			except Exception:
				pass
		if scanner is not None:
			try:
				scanner.remove_job_listener(self._on_hw_job)
			except Exception:
				pass

	def on_viewport_draw(self) -> None:
		if not self.show_grid:
			return
		entity = self.entity
		if entity is None or entity.scene is None:
			return
		selection = getattr(entity.scene, "selection", None)
		if selection is None or not selection.is_entity_selected(entity):
			return
		local_pts = self._grid_local_positions()
		if not local_pts:
			return
		world_pts = [transform_point(entity, p) for p in local_pts]
		rows = max(1, int(self.grid_rows or 1))
		cols = max(1, int(self.grid_cols or 1))
		origin_w = transform_point(entity, _qvec(self.grid_origin))
		col_w = transform_point(entity, _qvec(self.grid_along_columns))
		row_w = transform_point(entity, _qvec(self.grid_along_rows))
		Debug.draw_point(origin_w, size=8.0, screen_space=False, color=(0.2, 0.9, 0.3))
		Debug.draw_point(col_w, size=8.0, screen_space=False, color=(0.3, 0.5, 1.0))
		Debug.draw_point(row_w, size=8.0, screen_space=False, color=(1.0, 0.45, 0.2))
		for p in world_pts:
			Debug.draw_point(
				p, size=4.0, screen_space=False, color=(0.95, 0.85, 0.2), opacity=0.85
			)
		for r in range(rows):
			for c in range(cols):
				i = r * cols + c
				if c + 1 < cols:
					Debug.draw_line(world_pts[i], world_pts[i + 1], color=(0.7, 0.75, 0.4), width=1.0)
				if r + 1 < rows:
					Debug.draw_line(
						world_pts[i],
						world_pts[i + cols],
						color=(0.7, 0.75, 0.4),
						width=1.0,
					)
		tcp = self._resolved_tcp()
		if tcp is not None and tcp.entity is not None:
			q = world_rotation_quat(tcp.entity)
			z = q.rotatedVector(QVector3D(0.0, 0.0, 1.0))
			for p in world_pts:
				Debug.draw_ray(p, z, length=15.0, color=(0.4, 0.85, 1.0))

	def _grid_local_positions(self) -> List[QVector3D]:
		origin = _qvec(self.grid_origin)
		u = _qvec(self.grid_along_columns) - origin
		v = _qvec(self.grid_along_rows) - origin
		rows = max(1, int(self.grid_rows or 1))
		cols = max(1, int(self.grid_cols or 1))
		out: List[QVector3D] = []
		for r in range(rows):
			sr = 0.0 if rows <= 1 else float(r) / float(rows - 1)
			for c in range(cols):
				sc = 0.0 if cols <= 1 else float(c) / float(cols - 1)
				out.append(origin + u * sc + v * sr)
		return out

	def _grid_error(self) -> str:
		origin = _qvec(self.grid_origin)
		u = _qvec(self.grid_along_columns) - origin
		v = _qvec(self.grid_along_rows) - origin
		rows = max(1, int(self.grid_rows or 1))
		cols = max(1, int(self.grid_cols or 1))
		if cols > 1 and u.length() < _EPS_MM:
			return "grid along-columns must differ from origin when cols > 1"
		if rows > 1 and v.length() < _EPS_MM:
			return "grid along-rows must differ from origin when rows > 1"
		if rows > 1 and cols > 1:
			ul = u.length()
			vl = v.length()
			if ul > _EPS_MM and vl > _EPS_MM:
				cos = abs(QVector3D.dotProduct(u, v)) / (ul * vl)
				if cos > _PARALLEL_COS:
					return "grid edges are parallel; pick a parallelogram"
		return ""

	def _build_cells(
		self,
		owner: "Entity",
		tcp_ent: "Entity",
		base_ent: "Entity",
	) -> Tuple[List[_ScanCell], str]:
		inv_base, ok = world_matrix(base_ent).inverted()
		if not ok:
			return [], "could not invert robot base world matrix"
		world_quat = world_rotation_quat(tcp_ent)
		cells: List[_ScanCell] = []
		for local in self._grid_local_positions():
			world_pos = transform_point(owner, local)
			t_world = QMatrix4x4()
			t_world.translate(world_pos)
			t_world.rotate(world_quat)
			t_base = inv_base * t_world
			base_pos = t_base.column(3).toVector3D()
			base_q = _rotation_from_matrix(t_base)
			cells.append(
				_ScanCell(
					world_pos=QVector3D(world_pos),
					world_quat=QQuaternion(world_quat),
					base_pos_mm=QVector3D(base_pos),
					base_rotvec=_quat_to_rotvec(base_q),
				)
			)
		return cells, ""

	def _resolve_ref(self, value: Any, cls: type) -> Any:
		if isinstance(value, cls):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(cls)
				if comp is not None:
					return comp
		return None

	def _resolved_robot(self) -> Optional[Robot]:
		comp = self._resolve_ref(self.robot, Robot)
		if isinstance(comp, Robot):
			self.robot = comp
			return comp
		return None

	def _resolved_scanner(self) -> Optional[Scanner]:
		comp = self._resolve_ref(self.scanner, Scanner)
		if isinstance(comp, Scanner):
			self.scanner = comp
			return comp
		return None

	def _resolved_tcp(self) -> Optional[TransformComponent]:
		comp = self._resolve_ref(self.tcp_rotation, TransformComponent)
		if isinstance(comp, TransformComponent):
			self.tcp_rotation = comp
			return comp
		return None

	def _resolved_robot_description(self, mover: Robot) -> Optional[RobotDescriptionComponent]:
		"""RobotDescription for base-frame poses.

		Order: hardware ``robot`` field, then a RobotDescription sibling on the
		controller entity.
		"""
		rd = self._robot_description_from_value(
			getattr(mover, "robot", None),
			getattr(mover, "entity", None),
		)
		if rd is not None:
			return rd
		mover_ent = getattr(mover, "entity", None)
		if mover_ent is not None:
			comp = mover_ent.get_component(RobotDescriptionComponent)
			if isinstance(comp, RobotDescriptionComponent):
				return comp
		return None

	def _robot_description_from_value(
		self,
		value: Any,
		owner_entity: Any,
	) -> Optional[RobotDescriptionComponent]:
		if isinstance(value, RobotDescriptionComponent):
			return value
		scene = None
		if owner_entity is not None:
			scene = getattr(owner_entity, "scene", None)
		if scene is None and self.entity is not None:
			scene = self.entity.scene
		if isinstance(value, str) and scene is not None:
			ent = scene.find_by_id(value)
			if ent is None:
				name = value.strip()
				if name:
					for candidate in scene.entities():
						if str(getattr(candidate, "name", "") or "") == name:
							ent = candidate
							break
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if isinstance(comp, RobotDescriptionComponent):
					return comp
		get_comp = getattr(value, "get_component", None)
		if callable(get_comp):
			comp = get_comp(RobotDescriptionComponent)
			if isinstance(comp, RobotDescriptionComponent):
				return comp
		return None

	def _robot_base_entity(self, rd: RobotDescriptionComponent) -> Optional["Entity"]:
		robot_ent = rd.entity
		if robot_ent is None:
			return None
		root_id = rd.find_link_entity_id(rd.root_link)
		if root_id and robot_ent.scene is not None:
			base = robot_ent.scene.find_by_id(root_id)
			if base is not None:
				return base
		return robot_ent

"""Process-wide crash logging: Python ``faulthandler`` and the VTK error log.

Native crashes (access violations inside VTK / numpy / Qt) are invisible in the
console of a frozen build. ``faulthandler`` prints the Python stack of every
thread into ``imove-crash.log`` when the process faults, which identifies the
Python call that triggered the native crash.
"""

from __future__ import annotations

import faulthandler
import os
import sys
import time
from pathlib import Path
from typing import IO, Optional

_CRASH_FILE: Optional[IO[str]] = None
_VTK_LOG_INSTALLED = False


def log_dir() -> Path:
	"""``%LOCALAPPDATA%/iMOVE/logs``, falling back to ``logs`` next to the exe / cwd."""
	candidates = []
	local = os.environ.get("LOCALAPPDATA")
	if local:
		candidates.append(Path(local) / "iMOVE" / "logs")
	if getattr(sys, "frozen", False):
		candidates.append(Path(sys.executable).parent / "logs")
	candidates.append(Path.cwd() / "logs")
	for path in candidates:
		try:
			path.mkdir(parents=True, exist_ok=True)
			return path
		except OSError:
			continue
	return Path.cwd()


def install_crash_logging() -> Optional[Path]:
	"""Enable ``faulthandler`` into ``imove-crash.log`` (append). Idempotent."""
	global _CRASH_FILE
	if _CRASH_FILE is not None:
		return Path(_CRASH_FILE.name)
	path = log_dir() / "imove-crash.log"
	try:
		# The handle must stay open for the process lifetime: faulthandler writes
		# to its file descriptor from the signal handler.
		_CRASH_FILE = open(path, "a", encoding="utf-8", buffering=1)
		_CRASH_FILE.write(
			f"\n===== iMOVE start {time.strftime('%Y-%m-%d %H:%M:%S')} pid={os.getpid()} =====\n"
		)
		_CRASH_FILE.flush()
		faulthandler.enable(file=_CRASH_FILE, all_threads=True)
	except Exception as exc:
		_CRASH_FILE = None
		try:
			faulthandler.enable(all_threads=True)
		except Exception:
			pass
		print(f"Crash log unavailable ({exc!r}); faulthandler writes to stderr", file=sys.stderr)
		return None
	print(f"Crash log: {path}", flush=True)
	return path


def install_vtk_error_log() -> Optional[Path]:
	"""Route VTK warnings/errors to ``vtk.log`` instead of a popup / lost stderr. Idempotent."""
	global _VTK_LOG_INSTALLED
	if _VTK_LOG_INSTALLED:
		return None
	try:
		import vtk  # type: ignore

		path = log_dir() / "vtk.log"
		window = vtk.vtkFileOutputWindow()
		window.SetFileName(str(path))
		window.SetAppend(True)
		window.SetFlush(True)
		vtk.vtkOutputWindow.SetInstance(window)
		_VTK_LOG_INSTALLED = True
		return path
	except Exception as exc:
		print(f"VTK error log unavailable: {exc!r}", file=sys.stderr)
		return None

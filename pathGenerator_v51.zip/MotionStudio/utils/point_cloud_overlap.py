"""Keep-first voxel occupancy for overlapping scan appends.

Stored points are never deleted. New points whose voxel is already occupied
are dropped; kept new voxels are marked occupied so intra-frame duplicates
also collapse to one point per voxel.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

MIN_OVERLAP_VOXEL_MM = 0.0
MAX_OVERLAP_VOXEL_MM = 50.0

# Pack signed voxel ijk into one int64. Offset 2^20 covers ±1 km at 1 mm.
_VOXEL_COORD_OFFSET = np.int64(1 << 20)
_VOXEL_COORD_SHIFT = 21
_VOXEL_COORD_MASK = np.int64((1 << 21) - 1)


def clamp_overlap_voxel_mm(voxel_mm: float) -> float:
	"""Clamp occupancy voxel size. ``0`` disables the filter."""
	try:
		value = float(voxel_mm)
	except (TypeError, ValueError):
		return 0.0
	if not np.isfinite(value):
		return 0.0
	return max(MIN_OVERLAP_VOXEL_MM, min(MAX_OVERLAP_VOXEL_MM, value))


def overlap_voxel_is_noop(voxel_mm: float) -> bool:
	"""True when occupancy merge should be skipped (current concat)."""
	return clamp_overlap_voxel_mm(voxel_mm) <= 0.0


def filter_new_points_by_voxel(
	old_pts: Optional[np.ndarray],
	new_pts: np.ndarray,
	new_rgb: Optional[np.ndarray],
	voxel_mm: float,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	"""Keep new XYZ (+ optional RGB) whose voxel is empty in ``old_pts``.

	Old points are not returned and are not modified. First-wins within the
	new frame: later new points that share a newly occupied voxel are dropped.
	``voxel_mm <= 0`` returns the new arrays unchanged.
	"""
	pts = np.asarray(new_pts, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3:
		empty = np.empty((0, 3), dtype=np.float64)
		return empty, _empty_rgb(new_rgb)
	pts = np.ascontiguousarray(pts[:, :3], dtype=np.float64)
	rgb = _aligned_rgb(new_rgb, int(pts.shape[0]))

	size = clamp_overlap_voxel_mm(voxel_mm)
	if size <= 0.0 or pts.shape[0] == 0:
		return pts, rgb

	old = _xyz(old_pts)
	new_keys = _voxel_keys(pts, size)
	_, first_idx = np.unique(new_keys, return_index=True)
	keep_idx = np.sort(first_idx)
	if old.shape[0] > 0:
		old_keys = np.unique(_voxel_keys(old, size))
		keep_idx = keep_idx[~np.isin(new_keys[keep_idx], old_keys)]
	if keep_idx.size == 0:
		empty = np.empty((0, 3), dtype=np.float64)
		return empty, _empty_rgb(rgb)
	kept_pts = np.ascontiguousarray(pts[keep_idx], dtype=np.float64)
	kept_rgb = None if rgb is None else np.ascontiguousarray(rgb[keep_idx], dtype=np.float64)
	return kept_pts, kept_rgb


def _xyz(points: Optional[np.ndarray]) -> np.ndarray:
	if points is None:
		return np.empty((0, 3), dtype=np.float64)
	arr = np.asarray(points, dtype=np.float64)
	if arr.ndim != 2 or arr.shape[1] < 3 or arr.shape[0] <= 0:
		return np.empty((0, 3), dtype=np.float64)
	return np.ascontiguousarray(arr[:, :3], dtype=np.float64)


def _aligned_rgb(colors: Optional[np.ndarray], n: int) -> Optional[np.ndarray]:
	if colors is None or n <= 0:
		return None
	arr = np.asarray(colors, dtype=np.float64)
	if arr.ndim != 2 or arr.shape[0] != n or arr.shape[1] < 3:
		return None
	return np.ascontiguousarray(arr[:, :3], dtype=np.float64)


def _empty_rgb(colors: Optional[np.ndarray]) -> Optional[np.ndarray]:
	if colors is None:
		return None
	return np.empty((0, 3), dtype=np.float64)


def _voxel_keys(points: np.ndarray, voxel_mm: float) -> np.ndarray:
	q = np.floor(points / float(voxel_mm)).astype(np.int64)
	ox = np.clip(q[:, 0] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	oy = np.clip(q[:, 1] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	oz = np.clip(q[:, 2] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	return (ox << (2 * _VOXEL_COORD_SHIFT)) | (oy << _VOXEL_COORD_SHIFT) | oz

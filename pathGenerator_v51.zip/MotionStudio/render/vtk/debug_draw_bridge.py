from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Optional, Tuple

import vtk  # type: ignore

from MotionStudio.core.debug import _runtime
from MotionStudio.render.vtk.render_diagnostics import diagnostics
from MotionStudio.render.vtk.render_scheduler import guarded_renderer_add

# Hard cap per pool / per line batch so a runaway draw loop cannot grow VTK state unbounded.
_MAX_POOL_SLOTS = 1024
_MAX_BATCH_SEGMENTS = 200_000

_Vec = Tuple[float, float, float]
_Rgb = Tuple[float, float, float]


def _v(q) -> _Vec:
	return (float(q.x()), float(q.y()), float(q.z()))


def _rgb_u8(rgb) -> Tuple[int, int, int]:
	return tuple(max(0, min(255, int(round(float(c) * 255.0)))) for c in rgb[:3])  # type: ignore[return-value]


def _configure_unlit(prop, rgb: _Rgb, opacity: float, *, wireframe: bool = False) -> None:
	prop.SetColor(float(rgb[0]), float(rgb[1]), float(rgb[2]))
	prop.SetOpacity(float(opacity))
	if wireframe:
		prop.SetRepresentationToWireframe()
	else:
		prop.SetRepresentationToSurface()
	prop.SetAmbient(1.0)
	prop.SetDiffuse(0.0)
	prop.SetSpecular(0.0)
	prop.SetLighting(False)


class _LineBatch:
	"""All line segments sharing (renderer, width, opacity) in one persistent actor."""

	def __init__(self, renderer, plotter, width: float, opacity: float) -> None:
		self.poly = vtk.vtkPolyData()
		self.mapper = vtk.vtkPolyDataMapper()
		self.mapper.SetInputData(self.poly)
		self.mapper.SetScalarModeToUseCellData()
		self.mapper.SetColorModeToDirectScalars()
		self.mapper.ScalarVisibilityOn()
		self.actor = vtk.vtkActor()
		self.actor.SetMapper(self.mapper)
		self.actor.SetPickable(False)
		self.actor.SetUseBounds(False)
		prop = self.actor.GetProperty()
		_configure_unlit(prop, (1.0, 1.0, 1.0), opacity)
		prop.SetLineWidth(float(width))
		self.actor.SetVisibility(0)
		guarded_renderer_add(renderer, self.actor, plotter)

	def update(self, segments: List[Tuple[_Vec, _Vec, Tuple[int, int, int]]]) -> None:
		pts = vtk.vtkPoints()
		pts.SetDataTypeToDouble()
		pts.SetNumberOfPoints(2 * len(segments))
		cells = vtk.vtkCellArray()
		colors = vtk.vtkUnsignedCharArray()
		colors.SetNumberOfComponents(3)
		colors.SetName("debug_rgb")
		colors.SetNumberOfTuples(len(segments))
		for i, (a, b, rgb) in enumerate(segments):
			pts.SetPoint(2 * i, a)
			pts.SetPoint(2 * i + 1, b)
			cells.InsertNextCell(2)
			cells.InsertCellPoint(2 * i)
			cells.InsertCellPoint(2 * i + 1)
			colors.SetTuple3(i, rgb[0], rgb[1], rgb[2])
		self.poly.SetPoints(pts)
		self.poly.SetLines(cells)
		self.poly.GetCellData().SetScalars(colors)
		self.poly.Modified()
		self.actor.SetVisibility(1 if segments else 0)

	def hide(self) -> None:
		self.actor.SetVisibility(0)


class _Slot:
	__slots__ = ("actor", "source")

	def __init__(self, actor, source) -> None:
		self.actor = actor
		self.source = source


class _Pool:
	"""Persistent actors of one kind on one renderer; reused frame to frame."""

	def __init__(self, name: str, renderer, plotter, factory: Callable[[], _Slot]) -> None:
		self.name = name
		self._renderer = renderer
		self._plotter = plotter
		self._factory = factory
		self._slots: List[_Slot] = []
		self._used = 0

	def begin(self) -> None:
		self._used = 0

	def acquire(self) -> Optional[_Slot]:
		if self._used < len(self._slots):
			slot = self._slots[self._used]
		else:
			if len(self._slots) >= _MAX_POOL_SLOTS:
				diagnostics.warn_once(
					f"debug-pool-cap:{self.name}",
					f"Debug draw pool '{self.name}' hit {_MAX_POOL_SLOTS} primitives per frame; extra primitives dropped",
				)
				return None
			slot = self._factory()
			slot.actor.SetPickable(False)
			slot.actor.SetUseBounds(False)
			guarded_renderer_add(self._renderer, slot.actor, self._plotter)
			self._slots.append(slot)
		self._used += 1
		slot.actor.SetVisibility(1)
		return slot

	def end(self) -> None:
		for slot in self._slots[self._used:]:
			slot.actor.SetVisibility(0)

	def hide(self) -> None:
		self._used = 0
		self.end()


def _sphere_slot() -> _Slot:
	src = vtk.vtkSphereSource()
	src.SetThetaResolution(18)
	src.SetPhiResolution(18)
	mapper = vtk.vtkPolyDataMapper()
	mapper.SetInputConnection(src.GetOutputPort())
	actor = vtk.vtkActor()
	actor.SetMapper(mapper)
	return _Slot(actor, src)


def _cone_slot() -> _Slot:
	src = vtk.vtkConeSource()
	src.SetResolution(24)
	src.SetCapping(True)
	mapper = vtk.vtkPolyDataMapper()
	mapper.SetInputConnection(src.GetOutputPort())
	actor = vtk.vtkActor()
	actor.SetMapper(mapper)
	return _Slot(actor, src)


def _disc_slot_factory(camera_getter: Callable[[], Any]) -> Callable[[], _Slot]:
	def make() -> _Slot:
		src = vtk.vtkDiskSource()
		src.SetInnerRadius(0.0)
		src.SetCircumferentialResolution(8)
		src.SetCenter(0.0, 0.0, 0.0)
		mapper = vtk.vtkPolyDataMapper()
		mapper.SetInputConnection(src.GetOutputPort())
		follower = vtk.vtkFollower()
		follower.SetMapper(mapper)
		camera = camera_getter()
		if camera is not None:
			follower.SetCamera(camera)
		return _Slot(follower, src)

	return make


def _label_slot() -> _Slot:
	actor = vtk.vtkBillboardTextActor3D()
	actor.SetInput("")
	tp = actor.GetTextProperty()
	tp.SetBold(False)
	tp.SetItalic(False)
	tp.SetShadow(False)
	return _Slot(actor, None)


class VtkDebugDrawBridge:
	"""
	Syncs one-frame primitives from MotionStudio.core.debug.Debug into a fixed
	set of persistent VTK actors.

	Actors are created once (pooled / batched) and only updated or hidden per
	frame; they are never removed and re-added while the app runs. on_top
	primitives live in the overlay renderer (depth cleared → always visible),
	the others in the base renderer (depth-tested against the scene).

	Invoked by VtkViewportFrameBridge before each scheduled frame.
	"""

	def __init__(self, plotter) -> None:
		self._plotter = plotter
		self._overlay = getattr(plotter, "_pyengine_overlay_renderer", None)
		try:
			self._base = plotter.renderer
		except Exception:
			self._base = None
		self._line_batches: Dict[Tuple[str, float, float], _LineBatch] = {}
		self._pools: Dict[Tuple[str, str], _Pool] = {}
		self._last_signature: Optional[tuple] = None

	# ------------------------------------------------------------------ public

	def render_cycle(self) -> None:
		"""Consume this frame's primitives and sync them into the pooled actors."""
		lines, spheres, boxes, axes_list, points, labels, cones, polylines = (
			_runtime.consume_for_render()
		)
		needs_camera = any(p.screen_space for p in points) or any(a.screen_space for a in axes_list)
		signature = (
			tuple((_v(ln.start), _v(ln.end), ln.color_rgb, ln.width, ln.opacity, ln.on_top) for ln in lines),
			tuple((_v(s.center), s.radius, s.color_rgb, s.filled, s.opacity, s.on_top) for s in spheres),
			tuple((_v(b.center), _v(b.size), b.color_rgb, b.width, b.opacity, b.on_top) for b in boxes),
			tuple(
				(_v(a.origin), a.length, a.screen_space, a.rotation, a.width,
				 a.x_color_rgb, a.y_color_rgb, a.z_color_rgb, a.on_top)
				for a in axes_list
			),
			tuple((_v(p.position), p.size, p.screen_space, p.color_rgb, p.opacity, p.on_top) for p in points),
			tuple((_v(l.position), l.text, l.color_rgb, l.font_size, l.on_top) for l in labels),
			tuple(
				(_v(c.base_center), _v(c.direction), c.diameter, c.height, c.color_rgb, c.filled, c.opacity, c.on_top)
				for c in cones
			),
			tuple(
				(tuple(_v(p) for p in pl.points), pl.color_rgb, pl.width, pl.closed, pl.opacity, pl.on_top)
				for pl in polylines
			),
			self._camera_signature() if needs_camera else None,
		)
		if signature == self._last_signature:
			return
		self._last_signature = signature

		segments: Dict[Tuple[str, float, float], List[Tuple[_Vec, _Vec, Tuple[int, int, int]]]] = {}

		def add_segment(a: _Vec, b: _Vec, rgb, width: float, opacity: float, on_top: bool) -> None:
			key = (self._renderer_key(on_top), round(float(width) * 2.0) / 2.0, round(float(opacity), 2))
			segments.setdefault(key, []).append((a, b, _rgb_u8(rgb)))

		for ln in lines:
			add_segment(_v(ln.start), _v(ln.end), ln.color_rgb, ln.width, ln.opacity, ln.on_top)
		for axes in axes_list:
			self._axes_segments(axes, add_segment)
		for box in boxes:
			self._box_segments(box, add_segment)
		for pl in polylines:
			pts = [_v(p) for p in pl.points]
			if len(pts) < 2:
				continue
			if pl.closed:
				pts.append(pts[0])
			for a, b in zip(pts, pts[1:]):
				add_segment(a, b, pl.color_rgb, pl.width, pl.opacity, pl.on_top)

		self._sync_line_batches(segments)

		for pool in self._pools.values():
			pool.begin()
		for sph in spheres:
			self._sync_sphere(sph)
		for pt in points:
			self._sync_point(pt)
		for lbl in labels:
			self._sync_label(lbl)
		for cn in cones:
			self._sync_cone(cn)
		for pool in self._pools.values():
			pool.end()

	def clear_actors(self) -> None:
		"""Hide every debug actor (they stay allocated for reuse)."""
		for batch in self._line_batches.values():
			batch.hide()
		for pool in self._pools.values():
			pool.hide()
		self._last_signature = None

	# ------------------------------------------------------------------ renderers

	def _renderer_key(self, on_top: bool) -> str:
		if self._overlay is None or self._base is None:
			return "overlay" if self._overlay is not None else "base"
		return "overlay" if on_top else "base"

	def _renderer_for(self, key: str):
		return self._overlay if key == "overlay" else self._base

	def _pool(self, kind: str, on_top: bool, factory: Callable[[], _Slot]) -> Optional[_Pool]:
		rkey = self._renderer_key(on_top)
		key = (kind, rkey)
		pool = self._pools.get(key)
		if pool is None:
			renderer = self._renderer_for(rkey)
			if renderer is None:
				return None
			pool = _Pool(f"{kind}/{rkey}", renderer, self._plotter, factory)
			pool.begin()
			self._pools[key] = pool
		return pool

	def _active_camera(self):
		ren = self._base or self._overlay
		if ren is None:
			return None
		try:
			return ren.GetActiveCamera()
		except Exception:
			return None

	def _camera_signature(self) -> tuple:
		cam = self._active_camera()
		height = self._window_height()
		if cam is None:
			return (height,)
		return (
			tuple(cam.GetPosition()),
			tuple(cam.GetFocalPoint()),
			float(cam.GetViewAngle()),
			bool(cam.GetParallelProjection()),
			float(cam.GetParallelScale()),
			height,
		)

	def _window_height(self) -> int:
		ren = self._base or self._overlay
		try:
			rw = ren.GetRenderWindow() if ren is not None else None
			if rw is not None:
				return max(1, int(rw.GetSize()[1]))
		except Exception:
			pass
		return 720

	# ------------------------------------------------------------------ lines

	def _sync_line_batches(self, segments: Dict[Tuple[str, float, float], list]) -> None:
		for key, segs in segments.items():
			batch = self._line_batches.get(key)
			if batch is None:
				renderer = self._renderer_for(key[0])
				if renderer is None:
					continue
				batch = _LineBatch(renderer, self._plotter, width=key[1], opacity=key[2])
				self._line_batches[key] = batch
			if len(segs) > _MAX_BATCH_SEGMENTS:
				diagnostics.warn_once(
					f"debug-batch-cap:{key}",
					f"Debug draw line batch {key} exceeded {_MAX_BATCH_SEGMENTS} segments; truncated",
				)
				segs = segs[:_MAX_BATCH_SEGMENTS]
			batch.update(segs)
		for key, batch in self._line_batches.items():
			if key not in segments:
				batch.hide()

	def _axes_segments(self, axes, add_segment) -> None:
		ox, oy, oz = _v(axes.origin)
		length = float(axes.length)
		if axes.screen_space:
			length = self._pixel_radius_to_world(ox, oy, oz, length)
		basis = (
			(1.0, 0.0, 0.0, axes.x_color_rgb),
			(0.0, 1.0, 0.0, axes.y_color_rgb),
			(0.0, 0.0, 1.0, axes.z_color_rgb),
		)
		for bx, by, bz, rgb in basis:
			ex, ey, ez = bx * length, by * length, bz * length
			if axes.rotation is not None:
				ex, ey, ez = self._rotate_vector(axes.rotation, ex, ey, ez)
			add_segment((ox, oy, oz), (ox + ex, oy + ey, oz + ez), rgb, axes.width, 1.0, axes.on_top)

	@staticmethod
	def _box_segments(box, add_segment) -> None:
		cx, cy, cz = _v(box.center)
		hx, hy, hz = (0.5 * float(box.size.x()), 0.5 * float(box.size.y()), 0.5 * float(box.size.z()))
		corners = [
			(cx + sx * hx, cy + sy * hy, cz + sz * hz)
			for sx in (-1.0, 1.0)
			for sy in (-1.0, 1.0)
			for sz in (-1.0, 1.0)
		]
		# Corner index bits: x=4, y=2, z=1. Edges connect corners differing by one bit.
		for i in range(8):
			for bit in (4, 2, 1):
				j = i | bit
				if j != i:
					add_segment(corners[i], corners[j], box.color_rgb, box.width, box.opacity, box.on_top)

	@staticmethod
	def _rotate_vector(
		quat_wxyz: Tuple[float, float, float, float],
		x: float, y: float, z: float,
	) -> Tuple[float, float, float]:
		w, qx, qy, qz = quat_wxyz
		ix = w * x + qy * z - qz * y
		iy = w * y + qz * x - qx * z
		iz = w * z + qx * y - qy * x
		iw = -qx * x - qy * y - qz * z
		rx = ix * w + iw * -qx + iy * -qz - iz * -qy
		ry = iy * w + iw * -qy + iz * -qx - ix * -qz
		rz = iz * w + iw * -qz + ix * -qy - iy * -qx
		return float(rx), float(ry), float(rz)

	# ------------------------------------------------------------------ pooled shapes

	def _sync_sphere(self, sph) -> None:
		pool = self._pool("sphere", sph.on_top, _sphere_slot)
		slot = pool.acquire() if pool is not None else None
		if slot is None:
			return
		slot.source.SetCenter(*_v(sph.center))
		slot.source.SetRadius(float(sph.radius))
		prop = slot.actor.GetProperty()
		_configure_unlit(prop, sph.color_rgb, sph.opacity, wireframe=not sph.filled)
		prop.SetLineWidth(2.0)

	def _sync_cone(self, cn) -> None:
		pool = self._pool("cone", cn.on_top, _cone_slot)
		slot = pool.acquire() if pool is not None else None
		if slot is None:
			return
		bx, by, bz = _v(cn.base_center)
		dx, dy, dz = _v(cn.direction)
		length = math.sqrt(dx * dx + dy * dy + dz * dz)
		if length <= 1e-12:
			ux, uy, uz = 1.0, 0.0, 0.0
		else:
			ux, uy, uz = dx / length, dy / length, dz / length
		# vtkConeSource.SetCenter is the axis midpoint, not the base: offset by height/2.
		half_h = 0.5 * float(cn.height)
		slot.source.SetCenter(bx + ux * half_h, by + uy * half_h, bz + uz * half_h)
		slot.source.SetDirection(ux, uy, uz)
		slot.source.SetHeight(float(cn.height))
		slot.source.SetRadius(0.5 * float(cn.diameter))
		prop = slot.actor.GetProperty()
		_configure_unlit(prop, cn.color_rgb, cn.opacity, wireframe=not bool(cn.filled))
		prop.SetLineWidth(2.0)

	def _sync_point(self, pt) -> None:
		"""Camera-facing filled disc; ``size`` is a pixel radius when ``screen_space``."""
		pool = self._pool("disc", pt.on_top, _disc_slot_factory(self._active_camera))
		slot = pool.acquire() if pool is not None else None
		if slot is None:
			return
		x, y, z = _v(pt.position)
		radius = float(pt.size)
		if pt.screen_space:
			radius = self._pixel_radius_to_world(x, y, z, radius)
		slot.source.SetOuterRadius(max(1e-6, radius))
		camera = self._active_camera()
		if camera is not None and slot.actor.GetCamera() is not camera:
			slot.actor.SetCamera(camera)
		slot.actor.SetPosition(x, y, z)
		_configure_unlit(slot.actor.GetProperty(), pt.color_rgb, pt.opacity)

	def _sync_label(self, lbl) -> None:
		pool = self._pool("label", lbl.on_top, _label_slot)
		slot = pool.acquire() if pool is not None else None
		if slot is None:
			return
		actor = slot.actor
		text = str(lbl.text)
		if actor.GetInput() != text:
			actor.SetInput(text)
		actor.SetPosition(*_v(lbl.position))
		tp = actor.GetTextProperty()
		tp.SetFontSize(int(lbl.font_size))
		tp.SetColor(float(lbl.color_rgb[0]), float(lbl.color_rgb[1]), float(lbl.color_rgb[2]))
		if hasattr(actor, "SetForceOpaque"):
			actor.SetForceOpaque(bool(lbl.on_top))

	# ------------------------------------------------------------------ helpers

	def _pixel_radius_to_world(self, x: float, y: float, z: float, pixel_radius: float) -> float:
		"""Convert a desired on-screen radius (pixels) to a world-space length at (x, y, z)."""
		camera = self._active_camera()
		h = self._window_height()
		if camera is None:
			return max(1e-6, pixel_radius * 0.001)
		try:
			cam_pos = camera.GetPosition()
			dx = float(x) - float(cam_pos[0])
			dy = float(y) - float(cam_pos[1])
			dz = float(z) - float(cam_pos[2])
			dist = math.sqrt(dx * dx + dy * dy + dz * dz)
			if camera.GetParallelProjection():
				world_height = 2.0 * float(camera.GetParallelScale())
			else:
				view_angle_rad = math.radians(float(camera.GetViewAngle()))
				world_height = 2.0 * dist * math.tan(view_angle_rad * 0.5)
			world_per_pixel = world_height / float(h)
			return max(1e-6, float(pixel_radius) * world_per_pixel)
		except Exception:
			return max(1e-6, pixel_radius * 0.001)

"""Universal Robots controller hardware component.

Connect, Run Script, Move To Target, Joystick jog, Apply I/O, Set actual
configuration, read_tcp_pose, and STOP run on a dedicated QThread that owns
the ur_rtde receive handle. Optional ``robot`` links a virtual
``RobotDescription`` for joint streaming and base-frame poses.
"""

from __future__ import annotations

import math
import time
from pathlib import Path
from typing import Annotated, Any, Dict, Literal, Optional, Tuple, TYPE_CHECKING

from PyQt6.QtCore import QMutex, QMutexLocker, QObject, QThread, QWaitCondition, pyqtSignal
from PyQt6.QtGui import QVector3D

from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.robot import Robot
from MotionStudio.core.path.actions import bank_spec, clamp_port
from MotionStudio.core.ecs.component import register_component
from MotionStudio.core.hardwares.hardware_runtime import HardwareJobHub
from MotionStudio.core.hardwares.universal_robot_sdk import (
	UniversalRobotSdkError,
	UrRtdeSession,
	connect_robot,
	disconnect_robot,
	is_program_running,
	reconnect_receive,
	safety_fault_message,
	robot_not_ready_message,
	sdk_available,
	sdk_missing_message,
	apply_digital_io,
	io_type_is_input,
	send_halt,
	send_movel,
	send_script_file,
	session_is_connected,
	get_joints,
	get_tcp_pose,
)
from MotionStudio.core.debug import Debug
from MotionStudio.core.robot.jog import JOG_AXES, apply_tcp_jog, tcp_pose_to_mm_deg
from MotionStudio.ui.inspector.metadata import (
	ConnectionStatus,
	FilePath,
	Group,
	Header,
	Order,
	Range,
	Tooltip,
	inspector_button,
)

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene


STATUS_DISCONNECTED = "Disconnected"
STATUS_CONNECTING = "Connecting…"
STATUS_CONNECTED = "Connected"
STATUS_RUNNING_SCRIPT = "Running script…"
STATUS_MOVING = "Moving…"
STATUS_STOPPING = "Stopping…"
STATUS_DISCONNECTING = "Disconnecting…"
STATUS_SETTING_IO = "Setting I/O…"
STATUS_SYNCING_JOINTS = "Syncing joints…"
STATUS_READING_TCP = "Reading TCP…"
STATUS_CONNECTION_LOST = "Disconnected (connection lost)"
STATUS_CANCELLED = "Cancelled."

GROUP_ROBOT_CONTROL = "Robot Control"
_MM_TO_M = 0.001
_MOVE_POS_TOL_M = 0.001
_MOVE_ORI_TOL_RAD = 0.01
_MOVE_SETTLE_POLLS = 3
_MOVE_POLL_MS = 50
# Path Mission dense waypoints used to time out on a 5 s floor: the wait is
# estimated from Cartesian distance at send time, which is tiny between cells,
# ignores Reduced-mode TCP speed, and is 0 s if the first getActualTCPPose
# fails after the 30002 reconnect. Success still returns as soon as TCP
# settles; this is only the deadline.
_MOVE_MIN_TIMEOUT_S = 600.0
_MOVE_MAX_TIMEOUT_S = 600.0
# Wrist-arc length used when orientation change dominates the move.
_MOVE_ORI_TOOL_RADIUS_M = 0.15
# Controller accepted RTDE but ignored the 30002 movel (IDLE / Local).
_MOVE_START_TIMEOUT_S = 2.5
# Per-poll translation / orientation that counts as "the arm started moving".
_MOVE_MOTION_DELTA_M = 0.0003
_MOVE_MOTION_ORI_RAD = 0.005
# Moved-then-rest may stop a few mm short of the 1 mm / 0.57° band (repeatability
# + TCP / base-frame bias). Farther than this is not "just outside".
_MOVE_REST_POS_TOL_M = 0.015
_MOVE_REST_ORI_TOL_RAD = math.radians(5.0)
# Idle RTDE drops after a 30002 movel are common (Scan Mission capture wait).
# Require this many consecutive failed probes (~400 ms each) before reconnect.
_PROBE_MISS_LIMIT = 3


def _rotvec_to_quat(rx: float, ry: float, rz: float) -> Tuple[float, float, float, float]:
	angle = math.sqrt(rx * rx + ry * ry + rz * rz)
	if angle < 1e-12:
		return (1.0, 0.0, 0.0, 0.0)
	half = 0.5 * angle
	s = math.sin(half) / angle
	return (math.cos(half), rx * s, ry * s, rz * s)


def _quat_angle_rad(
	a: Tuple[float, float, float, float],
	b: Tuple[float, float, float, float],
) -> float:
	dot = abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3])
	if dot > 1.0:
		dot = 1.0
	return 2.0 * math.acos(dot)


def _tcp_translation_delta(
	a: Tuple[float, ...],
	b: Tuple[float, ...],
) -> float:
	"""Metres of XYZ change between two TCP samples."""
	if len(a) < 3 or len(b) < 3:
		return 0.0
	dx = float(a[0]) - float(b[0])
	dy = float(a[1]) - float(b[1])
	dz = float(a[2]) - float(b[2])
	return math.sqrt(dx * dx + dy * dy + dz * dz)


def _tcp_pose_error(
	actual: Tuple[float, ...],
	target: Tuple[float, float, float, float, float, float],
) -> Tuple[float, float]:
	"""Residual (metres, radians) of live TCP vs commanded pose."""
	if len(actual) < 3:
		return (float("inf"), float("inf"))
	dx = float(actual[0]) - target[0]
	dy = float(actual[1]) - target[1]
	dz = float(actual[2]) - target[2]
	dist = math.sqrt(dx * dx + dy * dy + dz * dz)
	if len(actual) < 6:
		return (dist, float("inf"))
	ang = _quat_angle_rad(
		_rotvec_to_quat(float(actual[3]), float(actual[4]), float(actual[5])),
		_rotvec_to_quat(target[3], target[4], target[5]),
	)
	return (dist, ang)


def _tcp_sample_moved(prev: Tuple[float, ...], actual: Tuple[float, ...]) -> bool:
	if _tcp_translation_delta(prev, actual) >= _MOVE_MOTION_DELTA_M:
		return True
	if len(prev) < 6 or len(actual) < 6:
		return False
	return (
		_quat_angle_rad(
			_rotvec_to_quat(float(prev[3]), float(prev[4]), float(prev[5])),
			_rotvec_to_quat(float(actual[3]), float(actual[4]), float(actual[5])),
		)
		>= _MOVE_MOTION_ORI_RAD
	)


def _tcp_reached(
	actual: Tuple[float, ...],
	target: Tuple[float, float, float, float, float, float],
) -> bool:
	dist, ang = _tcp_pose_error(actual, target)
	return dist <= _MOVE_POS_TOL_M and ang <= _MOVE_ORI_TOL_RAD


def _tcp_rest_near_target(
	actual: Tuple[float, ...],
	target: Tuple[float, float, float, float, float, float],
) -> bool:
	dist, ang = _tcp_pose_error(actual, target)
	return dist <= _MOVE_REST_POS_TOL_M and ang <= _MOVE_REST_ORI_TOL_RAD


def _format_tcp_residual(
	actual: Tuple[float, ...],
	target: Tuple[float, float, float, float, float, float],
) -> str:
	dist_m, ang_rad = _tcp_pose_error(actual, target)
	return (
		f"{dist_m * 1000.0:.2f} mm / {math.degrees(ang_rad):.2f}° from target "
		f"(tol {_MOVE_POS_TOL_M * 1000.0:.2f} mm / "
		f"{math.degrees(_MOVE_ORI_TOL_RAD):.2f}°)"
	)


def _movel_not_ready_suffix(session: Optional[UrRtdeSession]) -> str:
	reason = robot_not_ready_message(session)
	if reason:
		return f" {reason}."
	return (
		" Controller accepted RTDE but ignored the movel "
		"(pendant not in Remote Control?)."
	)


def _movel_timeout_s(
	actual: Optional[Tuple[float, ...]],
	target: Tuple[float, float, float, float, float, float],
	speed_m_s: float,
	accel_m_s2: float,
) -> float:
	if actual is None or len(actual) < 3:
		return _MOVE_MAX_TIMEOUT_S
	v = max(1e-4, float(speed_m_s))
	a = max(1e-4, float(accel_m_s2))
	dx = float(actual[0]) - target[0]
	dy = float(actual[1]) - target[1]
	dz = float(actual[2]) - target[2]
	dist = math.sqrt(dx * dx + dy * dy + dz * dz)
	if len(actual) >= 6:
		ang = _quat_angle_rad(
			_rotvec_to_quat(float(actual[3]), float(actual[4]), float(actual[5])),
			_rotvec_to_quat(target[3], target[4], target[5]),
		)
		dist = max(dist, ang * _MOVE_ORI_TOOL_RADIUS_M)
	# Accel + cruise + decel, then slack for RTDE drops, Reduced mode, blends.
	est = (2.0 * v / a) + (dist / v) + 2.0
	return min(_MOVE_MAX_TIMEOUT_S, max(_MOVE_MIN_TIMEOUT_S, est * 3.0))


class _UrJob:
	__slots__ = (
		"kind",
		"ip_address",
		"timeout_ms",
		"script_path",
		"pose_m_rotvec",
		"speed_m_s",
		"accel_m_s2",
		"io_type",
		"io_index",
		"io_value",
		"io_read",
		"jog_axis",
		"jog_delta",
	)

	def __init__(
		self,
		kind: str,
		*,
		ip_address: str = "",
		timeout_ms: int = 10000,
		script_path: str = "",
		pose_m_rotvec: Optional[Tuple[float, float, float, float, float, float]] = None,
		speed_m_s: float = 0.25,
		accel_m_s2: float = 1.2,
		io_type: str = "Standard Out",
		io_index: int = 0,
		io_value: bool = False,
		io_read: bool = False,
		jog_axis: str = "",
		jog_delta: float = 0.0,
	) -> None:
		self.kind = kind
		self.ip_address = ip_address
		self.timeout_ms = timeout_ms
		self.script_path = script_path
		self.pose_m_rotvec = pose_m_rotvec
		self.speed_m_s = float(speed_m_s)
		self.accel_m_s2 = float(accel_m_s2)
		self.io_type = str(io_type or "Standard Out")
		self.io_index = int(io_index)
		self.io_value = bool(io_value)
		self.io_read = bool(io_read)
		self.jog_axis = str(jog_axis or "")
		self.jog_delta = float(jog_delta)


class _UniversalRobotWorker(QThread):
	"""Owns ur_rtde handles; processes connect / disconnect / run / move / stop jobs."""

	job_succeeded = pyqtSignal(str, str)
	job_failed = pyqtSignal(str, str)
	connection_lost = pyqtSignal(str)

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		self._pending: Optional[_UrJob] = None
		self._stop = False
		self._cancel = False
		self._session: Optional[UrRtdeSession] = None
		self._probe_misses = 0

	def submit(self, job: _UrJob) -> None:
		with QMutexLocker(self._mutex):
			if job.kind in ("disconnect", "stop"):
				self._cancel = True
			self._pending = job
			self._wait.wakeOne()

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._cancel = True
			self._pending = None
			self._wait.wakeOne()
		self.wait(8000)

	def _cancelled(self) -> bool:
		with QMutexLocker(self._mutex):
			return bool(self._stop or self._cancel)

	def run(self) -> None:
		while True:
			job: Optional[_UrJob] = None
			probe = False
			with QMutexLocker(self._mutex):
				while self._pending is None and not self._stop:
					if not self._wait.wait(self._mutex, 400):
						probe = True
						break
				if self._stop:
					break
				job = self._pending
				self._pending = None
			if job is not None:
				self._probe_misses = 0
				self._run_job(job)
			elif probe:
				self._probe_connection()
		disconnect_robot(self._session)
		self._session = None

	def _probe_connection(self) -> None:
		if self._session is None:
			return
		if session_is_connected(self._session):
			self._probe_misses = 0
			return
		self._probe_misses += 1
		if self._probe_misses < _PROBE_MISS_LIMIT:
			return
		# A 30002 movel often drops RTDE after the pose has already arrived.
		# The move waiter reconnects; idle (Scan Mission Capture, Path Mission
		# Wait Time) must too. One bounded reconnect_receive — not a dummy TCP
		# to 30004, and not an unbounded retry loop that occupied the slot.
		if reconnect_receive(self._session):
			self._probe_misses = 0
			return
		disconnect_robot(self._session)
		self._session = None
		self._probe_misses = 0
		self.connection_lost.emit(STATUS_CONNECTION_LOST)

	def _run_job(self, job: _UrJob) -> None:
		kind = job.kind
		try:
			if kind == "connect":
				disconnect_robot(self._session)
				self._session = None
				# Let the controller drop a dead 30004 client (Local/Remote,
				# unplugged cable) before opening a new RTDEReceiveInterface.
				time.sleep(0.5)
				self._session = connect_robot(job.ip_address, job.timeout_ms)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "disconnect":
				disconnect_robot(self._session)
				self._session = None
				with QMutexLocker(self._mutex):
					self._cancel = False
				self.job_succeeded.emit(kind, STATUS_DISCONNECTED)
			elif kind == "run_script":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				send_script_file(self._session, job.script_path)
				self._await_script_finished()
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "move_to_target":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				if job.pose_m_rotvec is None:
					raise UniversalRobotSdkError("Move To Target pose is missing.")
				send_movel(
					self._session,
					job.pose_m_rotvec,
					speed_m_s=job.speed_m_s,
					accel_m_s2=job.accel_m_s2,
				)
				self._await_movel_arrived(
					job.pose_m_rotvec,
					job.speed_m_s,
					job.accel_m_s2,
				)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "stop":
				with QMutexLocker(self._mutex):
					self._cancel = False
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				send_halt(self._session)
				self._await_script_finished()
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "set_io":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				read = bool(getattr(job, "io_read", False)) or io_type_is_input(job.io_type)
				level = apply_digital_io(
					self._session,
					job.io_type,
					job.io_index,
					job.io_value,
					read=read,
				)
				if read:
					self.job_succeeded.emit(kind, f"read:{1 if level else 0}")
				else:
					self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "apply_actual_configuration":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				q = get_joints(self._session)
				payload = "q:" + ",".join(f"{v:.9g}" for v in q)
				self.job_succeeded.emit(kind, payload)
			elif kind == "get_tcp":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				pose = get_tcp_pose(self._session)
				if len(pose) < 6:
					raise UniversalRobotSdkError("getActualTCPPose returned no pose.")
				payload = "tcp:" + ",".join(f"{v:.9g}" for v in pose[:6])
				self.job_succeeded.emit(kind, payload)
			elif kind == "jog":
				if self._session is None:
					raise UniversalRobotSdkError("Robot is not connected.")
				pose = get_tcp_pose(self._session)
				if len(pose) < 6:
					raise UniversalRobotSdkError("getActualTCPPose returned no pose.")
				try:
					new_pose = apply_tcp_jog(pose[:6], job.jog_axis, job.jog_delta)
				except ValueError as exc:
					raise UniversalRobotSdkError(str(exc)) from exc
				send_movel(
					self._session,
					new_pose,
					speed_m_s=job.speed_m_s,
					accel_m_s2=job.accel_m_s2,
				)
				self._await_movel_arrived(
					new_pose,
					job.speed_m_s,
					job.accel_m_s2,
				)
				payload = "tcp:" + ",".join(f"{v:.9g}" for v in new_pose)
				self.job_succeeded.emit(kind, payload)
			else:
				raise UniversalRobotSdkError(f"Unknown job: {kind}")
		except UniversalRobotSdkError as exc:
			self._fail_job(kind, str(exc))
		except Exception as exc:
			self._fail_job(kind, str(exc))

	def _fail_job(self, kind: str, error: str) -> None:
		lost = "connection lost" in error.lower()
		if lost:
			disconnect_robot(self._session)
			self._session = None
		self.job_failed.emit(kind, error)

	def _wait_session_heartbeat(self, link_misses: int) -> int:
		"""Cancel / RTDE drop / protective stop while a 30002 program is running."""
		if self._cancelled():
			raise UniversalRobotSdkError(STATUS_CANCELLED)
		# Never TCP-probe 30002 here — that port is carrying the program.
		if not session_is_connected(self._session, probe_host=False):
			link_misses += 1
			if link_misses >= 3:
				if reconnect_receive(self._session):
					return 0
				raise UniversalRobotSdkError("Connection lost.")
			return link_misses
		fault = safety_fault_message(self._session)
		if fault:
			raise UniversalRobotSdkError(fault)
		return 0

	def _await_script_finished(self) -> None:
		"""Poll RTDE until the program stops, or disconnect / link loss.

		Used by RUN / STOP. Secondary-interface (30002) scripts often never
		set ``isProgramRunning``; Move To Target must not use this waiter.
		"""
		start_deadline = time.monotonic() + 2.0
		seen_running = False
		idle_polls = 0
		link_misses = 0
		while True:
			link_misses = self._wait_session_heartbeat(link_misses)
			running = is_program_running(self._session)
			if running:
				seen_running = True
				idle_polls = 0
			else:
				idle_polls += 1
				if idle_polls >= 3 and (seen_running or time.monotonic() >= start_deadline):
					return
			self.msleep(_MOVE_POLL_MS)

	def _await_movel_arrived(
		self,
		pose_m_rotvec: Tuple[float, float, float, float, float, float],
		speed_m_s: float,
		accel_m_s2: float,
	) -> None:
		"""Block until live TCP has arrived (not ``isProgramRunning``).

		Exact 1 mm / 0.01 rad is the fast path. A real ``movel`` often settles
		a few millimetres short (repeatability + TCP / base-frame bias); waiting
		only for that band blocked until the 600 s deadline.

		If the TCP never leaves the start pose, fail in ``_MOVE_START_TIMEOUT_S``
		(controller ignored the 30002 script: IDLE / POWER_ON or Local mode)
		instead of sitting on the same 10-minute deadline.
		"""
		target = (
			float(pose_m_rotvec[0]),
			float(pose_m_rotvec[1]),
			float(pose_m_rotvec[2]),
			float(pose_m_rotvec[3]),
			float(pose_m_rotvec[4]),
			float(pose_m_rotvec[5]),
		)
		actual: Optional[Tuple[float, ...]] = None
		try:
			actual = get_tcp_pose(self._session)
		except Exception:
			actual = None
		started = time.monotonic()
		deadline = started + _movel_timeout_s(
			actual, target, speed_m_s, accel_m_s2
		)
		start_deadline = started + _MOVE_START_TIMEOUT_S
		settled = 0
		rest_polls = 0
		moved = False
		prev = actual
		link_misses = 0
		while True:
			link_misses = self._wait_session_heartbeat(link_misses)
			try:
				actual = get_tcp_pose(self._session)
			except Exception:
				link_misses += 1
				if link_misses >= 3:
					if reconnect_receive(self._session):
						link_misses = 0
					else:
						raise UniversalRobotSdkError("Connection lost.")
				self.msleep(_MOVE_POLL_MS)
				continue
			if _tcp_reached(actual, target):
				settled += 1
				if settled >= _MOVE_SETTLE_POLLS:
					Debug.log(
						f"Move To Target: settled {_format_tcp_residual(actual, target)}"
					)
					return
			else:
				settled = 0
			if prev is not None:
				if _tcp_sample_moved(prev, actual):
					moved = True
					rest_polls = 0
				else:
					rest_polls += 1
					if (
						moved
						and rest_polls >= _MOVE_SETTLE_POLLS
						and _tcp_rest_near_target(actual, target)
					):
						Debug.log(
							f"Move To Target: settled "
							f"{_format_tcp_residual(actual, target)}"
						)
						return
			prev = actual
			now = time.monotonic()
			if not moved and settled == 0 and now >= start_deadline:
				raise UniversalRobotSdkError(
					"Move To Target: robot did not start moving within "
					f"{_MOVE_START_TIMEOUT_S:.1f} s (TCP still at previous pose; "
					f"{_format_tcp_residual(actual, target)})."
					f"{_movel_not_ready_suffix(self._session)}"
				)
			if now >= deadline:
				raise UniversalRobotSdkError(
					"Move To Target timed out "
					f"({_format_tcp_residual(actual, target)})."
					f"{_movel_not_ready_suffix(self._session)}"
				)
			self.msleep(_MOVE_POLL_MS)


class _UrWorkerHost(QObject):
	"""Main-thread owner of the worker thread (signals must land here)."""

	def __init__(self, component: "UniversalRobotComponent") -> None:
		super().__init__()
		self._component = component
		self._stopped = False
		self.worker = _UniversalRobotWorker()
		self.worker.job_succeeded.connect(self._on_ok)
		self.worker.job_failed.connect(self._on_fail)
		self.worker.connection_lost.connect(self._on_lost)
		self.worker.start()

	def _on_ok(self, kind: str, message: str) -> None:
		self._component._on_worker_ok(kind, message)

	def _on_fail(self, kind: str, error: str) -> None:
		self._component._on_worker_fail(kind, error)

	def _on_lost(self, message: str) -> None:
		self._component._on_connection_lost(message)

	def shutdown(self) -> None:
		if self._stopped:
			return
		self._stopped = True
		try:
			self.worker.job_succeeded.disconnect(self._on_ok)
			self.worker.job_failed.disconnect(self._on_fail)
			self.worker.connection_lost.disconnect(self._on_lost)
		except Exception:
			pass
		self.worker.stop()


@register_component
class UniversalRobotComponent(Robot):
	type_name = "UniversalRobot"
	category = "Hardware/Robots"
	description = (
		"<p><b>Universal Robot</b></p>"
		"<p>Connects to a Universal Robots controller (ur_rtde), can send a "
		"<code>.script</code> file, or <b>Move To Target</b> with a TCP "
		"<code>movel</code>. <b>STOP</b> halts either. Link a virtual "
		"<b>RobotDescription</b> for later joint/TCP streaming.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Install <code>ur_rtde</code> (<code>pip install ur_rtde</code>).</li>"
		"<li>Put the e-Series teach pendant in <b>Remote Control</b>.</li>"
		"<li>Open <b>Connection Settings</b>, set the controller <b>IP address</b>, "
		"then click <b>Connect</b>.</li>"
		"<li>Optionally assign <b>robot</b> to the virtual URDF root "
		"(<b>RobotDescription</b>). <b>Set actual configuration</b> copies "
		"live joint angles onto that model.</li>"
		"<li>Open <b>Robot Control</b>: <b>Script</b> (file + RUN), "
		"<b>Move To Target</b> (position mm, rotation vector degrees, then Move To Target), "
		"<b>Trigger DI/DO</b> (bank, index, value, then Apply I/O), "
		"or <b>STOP</b> to halt motion.</li>"
		"</ul>"
	)

	ip_address: Annotated[
		str,
		Group("Connection Settings"),
		Order(0),
		Tooltip("IPv4 address of the UR controller (same subnet as this PC)."),
	]
	timeout_ms: Annotated[
		int,
		Group("Connection Settings"),
		Order(10),
		Range(1000, 60000, step=1000),
		Tooltip("Connect probe timeout in milliseconds (RTDE port 30004)."),
	]
	connection_status: Annotated[
		str,
		ConnectionStatus(
			busy=(
				STATUS_CONNECTING,
				STATUS_RUNNING_SCRIPT,
				STATUS_MOVING,
				STATUS_STOPPING,
				STATUS_DISCONNECTING,
				STATUS_SETTING_IO,
				STATUS_SYNCING_JOINTS,
				STATUS_READING_TCP,
			),
		),
		Order(40),
		Tooltip("Live connection state. Not restored from the scene file."),
	]
	robot: Annotated[
		Optional[RobotDescriptionComponent],
		Order(50),
		Tooltip(
			"Virtual robot (RobotDescription / URDF root). Set actual configuration "
			"and Scan Mission copy live joints onto it; Path Mission uses it as the "
			"arm base / root_link frame."
		),
	]
	script_path: Annotated[
		str,
		FilePath("URScript (*.script);;All Files (*.*)"),
		Group(GROUP_ROBOT_CONTROL),
		Header("Script"),
		Order(60),
		Tooltip("URScript file to send to the controller (project-relative or absolute)."),
	] = ""
	target_position: Annotated[
		QVector3D,
		Group(GROUP_ROBOT_CONTROL),
		Header("Move To Target"),
		Order(80),
		Tooltip(
			"TCP target position in millimetres (engine units). Sent as metres in movel."
		),
	]
	target_rotation: Annotated[
		QVector3D,
		Group(GROUP_ROBOT_CONTROL),
		Order(81),
		Tooltip(
			"TCP target orientation as a UR rotation vector (axis × angle, degrees). "
			"Converted to radians before movel."
		),
	]
	move_speed_m_s: Annotated[
		float,
		Group(GROUP_ROBOT_CONTROL),
		Order(82),
		Range(0.001, 3.0, step=0.01, decimals=3),
		Tooltip("movel tool speed (m/s)."),
	] = 0.25
	move_accel_m_s2: Annotated[
		float,
		Group(GROUP_ROBOT_CONTROL),
		Order(83),
		Range(0.01, 12.0, step=0.05, decimals=2),
		Tooltip("movel tool acceleration (m/s²)."),
	] = 1.2
	io_type: Annotated[
		Literal[
			"Standard Out",
			"Configurable Out",
			"Tool Out",
			"Standard In",
			"Configurable In",
			"Tool In",
		],
		Group(GROUP_ROBOT_CONTROL),
		Header("Trigger DI/DO"),
		Order(92),
		Tooltip(
			"UR digital bank (PolyScope). Outputs can be written. Inputs are "
			"external signals — Apply I/O reads them into Value."
		),
	] = "Standard Out"
	io_index: Annotated[
		int,
		Group(GROUP_ROBOT_CONTROL),
		Order(93),
		Range(0, 7, step=1),
		Tooltip("Pin index. Standard / Configurable: 0–7. Tool: 0–1."),
	] = 0
	io_value: Annotated[
		bool,
		Group(GROUP_ROBOT_CONTROL),
		Order(94),
		Tooltip(
			"Digital level (checked = High). Written on outputs; filled from "
			"the controller when applying an input."
		),
	] = False

	def __init__(
		self,
		ip_address: str = "192.168.0.1",
		timeout_ms: int = 10000,
		script_path: str = "",
	) -> None:
		self.ip_address = str(ip_address or "192.168.0.1")
		try:
			self.timeout_ms = int(timeout_ms)
		except Exception:
			self.timeout_ms = 10000
		self.connection_status = STATUS_DISCONNECTED
		self.robot = None
		self.script_path = str(script_path or "")
		self.target_position = QVector3D(0.0, 0.0, 0.0)
		self.target_rotation = QVector3D(0.0, 0.0, 0.0)
		self.move_speed_m_s = 0.25
		self.move_accel_m_s2 = 1.2
		self.io_type = "Standard Out"
		self.io_index = 0
		self.io_value = False
		self._busy = False
		self._host: Optional[_UrWorkerHost] = None
		self._bound_scene: Optional["Scene"] = None
		self._hw_session_key: Optional[str] = None
		self._was_connected = False
		self._disconnecting = False
		self._stopping = False
		self._job_hub = HardwareJobHub()

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "UniversalRobotComponent":
		inst = super().from_dict(data)
		inst.force_setattr("connection_status", STATUS_DISCONNECTED)
		return inst

	def add_job_listener(self, callback) -> None:
		self._job_hub.add(callback)

	def remove_job_listener(self, callback) -> None:
		self._job_hub.remove(callback)

	def set_move_target(self, position_mm: QVector3D, rotation_rotvec: QVector3D) -> None:
		self.target_position = QVector3D(position_mm)
		self.target_rotation = QVector3D(rotation_rotvec)

	def set_io_target(self, bank: str, port: int, state: bool) -> None:
		spec = bank_spec(bank)
		self.io_type = spec.label
		self.io_index = int(clamp_port(bank, port))
		self.io_value = bool(state)

	@inspector_button(
		"Connect",
		tooltip="Connect to the UR controller via ur_rtde (background thread)",
		order=20,
		group="Connection Settings",
	)
	def connect_robot(self):
		if self._busy:
			return False, "robot is busy"
		if not sdk_available():
			self.connection_status = f"Error: {sdk_missing_message()}"
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_CONNECTING
		self._ensure_host().worker.submit(
			_UrJob(
				"connect",
				ip_address=str(self.ip_address or "").strip(),
				timeout_ms=int(self.timeout_ms),
			)
		)
		return True

	@inspector_button(
		"Disconnect",
		tooltip="Disconnect from the UR controller (allowed while a script or movel is running)",
		order=30,
		group="Connection Settings",
	)
	def disconnect_robot(self):
		if self._host is None:
			self.connection_status = STATUS_DISCONNECTED
			self._was_connected = False
			self._busy = False
			self._disconnecting = False
			return None
		self._disconnecting = True
		self._busy = True
		self.connection_status = STATUS_DISCONNECTING
		self._host.worker.submit(_UrJob("disconnect"))
		return True

	@inspector_button(
		"RUN",
		tooltip="Send the selected .script file to the connected controller",
		order=70,
		group=GROUP_ROBOT_CONTROL,
	)
	def run_script(self):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		abs_path = self._resolve_script_path()
		if abs_path is None:
			self.connection_status = "Error: Assign a valid .script file under Script."
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_RUNNING_SCRIPT
		self._ensure_host().worker.submit(_UrJob("run_script", script_path=str(abs_path)))
		return True

	@inspector_button(
		"Move To Target",
		tooltip=(
			"movel the TCP to target position (mm) and rotation vector "
			"(degrees → radians). Completes when live TCP is at the pose, "
			"not when the 30002 script looks idle."
		),
		order=90,
		group=GROUP_ROBOT_CONTROL,
	)
	def move_to_target(self):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		pos = self.target_position or QVector3D()
		rot = self.target_rotation or QVector3D()
		pose = (
			float(pos.x()) * _MM_TO_M,
			float(pos.y()) * _MM_TO_M,
			float(pos.z()) * _MM_TO_M,
			math.radians(float(rot.x())),
			math.radians(float(rot.y())),
			math.radians(float(rot.z())),
		)
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_MOVING
		self._ensure_host().worker.submit(
			_UrJob(
				"move_to_target",
				pose_m_rotvec=pose,
				speed_m_s=float(self.move_speed_m_s),
				accel_m_s2=float(self.move_accel_m_s2),
			)
		)
		return True

	@inspector_button(
		"Apply I/O",
		tooltip=(
			"Write a digital output, or read a digital input into Value "
			"(requires Connect; uses RTDE I/O so a running program is not replaced)"
		),
		order=97,
		group=GROUP_ROBOT_CONTROL,
	)
	def apply_io(self):
		return self._submit_io(read=False)

	def read_io(self):
		return self._submit_io(read=True)

	def _submit_io(self, *, read: bool):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_SETTING_IO
		self._ensure_host().worker.submit(
			_UrJob(
				"set_io",
				io_type=str(self.io_type or "Standard Out"),
				io_index=int(self.io_index),
				io_value=bool(self.io_value),
				io_read=bool(read),
			)
		)
		return True

	@inspector_button(
		"Set actual configuration",
		tooltip=(
			"Read live joint angles from the controller (getActualQ) and apply "
			"them to the bound RobotDescription via FK"
		),
		order=55,
	)
	def apply_actual_configuration(self):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		rd = self._resolved_robot_description()
		if rd is None:
			self.connection_status = "Error: Bind RobotDescription on the robot field."
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_SYNCING_JOINTS
		self._ensure_host().worker.submit(_UrJob("apply_actual_configuration"))
		return True

	def read_tcp_pose(self):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_READING_TCP
		self._ensure_host().worker.submit(_UrJob("get_tcp"))
		return True

	def jog_tcp(self, axis: str, delta: float):
		if self._busy:
			return False, "robot is busy"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		key = str(axis or "").strip().lower()
		if key not in JOG_AXES:
			return False, f"unknown jog axis {axis}"
		try:
			amount = float(delta)
		except (TypeError, ValueError):
			return False, "invalid jog step"
		if abs(amount) < 1e-12:
			return False, "jog step is zero"
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_MOVING
		self._ensure_host().worker.submit(
			_UrJob(
				"jog",
				jog_axis=key,
				jog_delta=amount,
				speed_m_s=float(self.move_speed_m_s),
				accel_m_s2=float(self.move_accel_m_s2),
			)
		)
		return True

	@inspector_button(
		"STOP",
		tooltip="Halt the controller program (stops RUN, Move To Target, and Joystick jog)",
		order=100,
		group=GROUP_ROBOT_CONTROL,
		header="Stop",
	)
	def stop_robot(self):
		if self._disconnecting:
			return False, "robot is disconnecting"
		if not self._was_connected:
			self.connection_status = "Error: Robot is not connected."
			return False, self.connection_status
		if self._host is None:
			return False, "robot is not connected"
		self._stopping = True
		self._busy = True
		self.connection_status = STATUS_STOPPING
		self._ensure_host().worker.submit(_UrJob("stop"))
		return True

	def _on_worker_ok(self, kind: str, message: str) -> None:
		if self._disconnecting and kind != "disconnect":
			self._job_hub.notify(kind, True, message)
			return
		if self._stopping and kind != "stop":
			self._job_hub.notify(kind, True, message)
			return
		self._busy = False
		self._disconnecting = False
		self._stopping = False
		if kind == "connect":
			self._was_connected = True
			self.connection_status = message or STATUS_CONNECTED
		elif kind == "disconnect":
			self._was_connected = False
			self.connection_status = STATUS_DISCONNECTED
		elif kind in ("run_script", "move_to_target", "stop", "set_io"):
			self._was_connected = True
			if kind == "set_io" and str(message or "").startswith("read:"):
				self.io_value = str(message).split(":", 1)[-1].strip() in ("1", "true", "True")
			self.connection_status = STATUS_CONNECTED
		elif kind == "jog":
			self._was_connected = True
			self._apply_tcp_payload_to_target(message)
			self.connection_status = STATUS_CONNECTED
		elif kind == "apply_actual_configuration":
			self._was_connected = True
			err = self._apply_q_to_description(self._parse_q_message(message))
			if err:
				self.connection_status = f"Error: {err}"
				self._job_hub.notify(kind, False, self.connection_status)
				return
			self.connection_status = STATUS_CONNECTED
		elif kind == "get_tcp":
			self._was_connected = True
			self.connection_status = STATUS_CONNECTED
			self._job_hub.notify(kind, True, message)
			return
		self._job_hub.notify(kind, True, self.connection_status)

	def _on_worker_fail(self, kind: str, error: str) -> None:
		if self._disconnecting and kind != "disconnect":
			self._job_hub.notify(kind, False, error)
			return
		if self._stopping and kind != "stop":
			self._job_hub.notify(kind, False, error)
			return
		self._busy = False
		self._disconnecting = False
		self._stopping = False
		lost = "connection lost" in str(error or "").lower()
		cancelled = str(error or "").strip().lower().startswith("cancelled")
		if kind in ("connect", "disconnect") or lost:
			self._was_connected = False
		if lost:
			self.connection_status = STATUS_CONNECTION_LOST
		elif cancelled:
			self.connection_status = STATUS_CONNECTED if self._was_connected else STATUS_DISCONNECTED
		else:
			self.connection_status = f"Error: {error}"
		self._job_hub.notify(kind, False, self.connection_status)

	def _apply_tcp_payload_to_target(self, message: str) -> None:
		raw = str(message or "")
		if raw.startswith("tcp:"):
			raw = raw[4:]
		parts = [p.strip() for p in raw.split(",") if p.strip()]
		if len(parts) < 6:
			return
		try:
			pose = tuple(float(p) for p in parts[:6])
			mm, deg = tcp_pose_to_mm_deg(pose)
		except (TypeError, ValueError):
			return
		self.target_position = QVector3D(mm[0], mm[1], mm[2])
		self.target_rotation = QVector3D(deg[0], deg[1], deg[2])

	@staticmethod
	def _parse_q_message(message: str) -> Tuple[float, ...]:
		raw = str(message or "")
		if raw.startswith("q:"):
			raw = raw[2:]
		parts = [p.strip() for p in raw.split(",") if p.strip()]
		out: list[float] = []
		for part in parts:
			try:
				out.append(float(part))
			except ValueError:
				return ()
		return tuple(out)

	def _resolved_robot_description(self) -> Optional[RobotDescriptionComponent]:
		value = getattr(self, "robot", None)
		if isinstance(value, RobotDescriptionComponent):
			return value
		entity = getattr(self, "entity", None)
		scene = getattr(entity, "scene", None) if entity is not None else None
		if isinstance(value, str) and scene is not None:
			ent = scene.find_by_id(value)
			if ent is None:
				name = value.strip()
				if name:
					for candidate in scene.entities():
						if str(getattr(candidate, "name", "") or "") == name:
							ent = candidate
							break
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if isinstance(comp, RobotDescriptionComponent):
					self.robot = comp
					return comp
		if entity is not None:
			comp = entity.get_component(RobotDescriptionComponent)
			if isinstance(comp, RobotDescriptionComponent):
				return comp
		return None

	def _apply_q_to_description(self, q: Tuple[float, ...]) -> Optional[str]:
		if not q:
			return "controller returned no joint angles"
		rd = self._resolved_robot_description()
		if rd is None or rd.entity is None:
			return "bind RobotDescription on the robot field"
		names = list(rd.actuated_joint_names)
		if not names:
			return "RobotDescription has no actuated joints"
		if len(q) < len(names):
			return f"controller returned {len(q)} joints, URDF has {len(names)}"
		for i, name in enumerate(names):
			rd.joint_positions[name] = float(q[i])
		entity = rd.entity
		scene = entity.scene
		ik_sys = getattr(scene, "robot_ik_system", None) if scene is not None else None
		if ik_sys is not None:
			ik_sys.apply_fk_from_joints(entity)
		else:
			from MotionStudio.core.robot.robot_kinematics import update_robot_fk

			update_robot_fk(rd)
			if scene is not None:
				try:
					scene.events.entity_changed.emit(entity.id)
				except Exception:
					pass
		return None

	def _on_connection_lost(self, message: str) -> None:
		self._busy = False
		self._disconnecting = False
		self._stopping = False
		self._was_connected = False
		self.connection_status = message or STATUS_CONNECTION_LOST

	def _ensure_host(self) -> _UrWorkerHost:
		if self._host is None:
			self._host = _UrWorkerHost(self)
			self._register_hardware_session()
		return self._host

	def _session_key(self) -> str:
		entity = self.entity
		eid = entity.id if entity is not None else "unbound"
		return f"{eid}:{self.type_name}"

	def _register_hardware_session(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is None or self._host is None:
			return
		key = self._session_key()
		self._hw_session_key = key
		scene.hardware_runtime.register(key, self._host)

	def _unregister_hardware_session(self) -> None:
		key = self._hw_session_key
		self._hw_session_key = None
		scene = self._bound_scene
		entity = self.entity
		if entity is not None and entity.scene is not None:
			scene = entity.scene
		if scene is None or not key:
			return
		scene.hardware_runtime.unregister(key)

	def _shutdown_host(self) -> None:
		self._unregister_hardware_session()
		host = self._host
		self._host = None
		self._busy = False
		self._was_connected = False
		self._disconnecting = False
		self._stopping = False
		if host is not None:
			try:
				host.shutdown()
			except Exception:
				pass

	def _bind_scene(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is self._bound_scene:
			return
		self._unbind_scene()
		if scene is None:
			return
		try:
			scene.events.entity_removed.connect(self._on_entity_removed)
			scene.events.entity_changed.connect(self._on_owning_entity_changed)
		except Exception:
			return
		self._bound_scene = scene

	def _unbind_scene(self) -> None:
		scene = self._bound_scene
		self._bound_scene = None
		if scene is None:
			return
		try:
			scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		try:
			scene.events.entity_changed.disconnect(self._on_owning_entity_changed)
		except Exception:
			pass

	def _on_entity_removed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None or entity.id != entity_id:
			return
		self._teardown()

	def _on_owning_entity_changed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None:
			self._teardown()
			return
		if entity.id != entity_id:
			return
		if self not in getattr(entity, "components", []):
			self._teardown()

	def _teardown(self) -> None:
		self._unbind_scene()
		self._shutdown_host()
		self.connection_status = STATUS_DISCONNECTED

	def _resolve_script_path(self) -> Optional[Path]:
		raw = str(self.script_path or "").strip()
		if not raw:
			return None
		p = Path(raw)
		if p.is_file():
			return p.resolve()
		entity = self.entity
		scene = entity.scene if entity is not None else None
		root = scene.project_root if scene is not None else None
		if root is not None:
			cand = (Path(root) / raw).resolve()
			if cand.is_file():
				return cand
		return None

"""Offline (worker-thread) GP leak-path search.

Same cone / offset search as the edit-mode play routine, but IK and collision
run against a Plan Motion snapshot — no viewport posing, no play-routine ticks.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.robot.ik.backend_runtime import solve_ik_request
from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest
from MotionStudio.core.robot.ik.ik_frames import MM_TO_M, project_to_se3, quat_to_rotation_matrix
from MotionStudio.core.robot.planning.collision_world import PlanningCollisionWorld


CancelFn = Callable[[], bool]


@dataclass
class LeakGenJob:
	ports: List[List[Tuple[float, float, float]]]
	seg_names: List[str]
	r0_wxyz: Tuple[float, float, float, float]
	approach_height_mm: float
	cone_tilt_deg: float
	samples_per_port: int
	offset_radius_mm: float
	offset_samples: int
	ik_template: IKSolveRequest
	ik_backend: str
	T_world_base: np.ndarray
	T_ee_tcp: np.ndarray
	collision_world: PlanningCollisionWorld
	joint_names: List[str]


@dataclass
class LeakGenHit:
	approach: Tuple[float, float, float]
	port: Tuple[float, float, float]
	quat_wxyz: Tuple[float, float, float, float]


@dataclass
class LeakGenResult:
	ok: bool
	message: str = ""
	cancelled: bool = False
	hits: List[List[LeakGenHit]] = field(default_factory=list)
	reach: List[List[int]] = field(default_factory=list)
	skipped: List[str] = field(default_factory=list)
	accepted_count: int = 0


def _qvec(xyz: Tuple[float, float, float]) -> QVector3D:
	return QVector3D(float(xyz[0]), float(xyz[1]), float(xyz[2]))


def _qvec_norm(v: QVector3D) -> QVector3D:
	if v.length() < 1e-9:
		return QVector3D(0.0, 0.0, 1.0)
	out = QVector3D(v)
	out.normalize()
	return out


def _cone_sample_rotation(
	r0: QQuaternion,
	sample_idx: int,
	n_samples: int,
	tilt_deg: float,
) -> QQuaternion:
	if sample_idx <= 0 or n_samples <= 1 or abs(tilt_deg) < 1e-6:
		return QQuaternion(r0)
	n = _qvec_norm(r0.rotatedVector(QVector3D(0.0, 0.0, 1.0)))
	t = r0.rotatedVector(QVector3D(1.0, 0.0, 0.0))
	if abs(QVector3D.dotProduct(t, n)) > 0.95:
		t = r0.rotatedVector(QVector3D(0.0, 1.0, 0.0))
	t = t - n * QVector3D.dotProduct(t, n)
	t = _qvec_norm(t)
	b = _qvec_norm(QVector3D.crossProduct(n, t))
	ring_count = max(1, n_samples - 1)
	k = sample_idx - 1
	phi = (2.0 * np.pi * float(k)) / float(ring_count)
	theta = np.radians(float(tilt_deg))
	approach = (
		n * float(np.cos(theta))
		+ (t * float(np.cos(phi)) + b * float(np.sin(phi))) * float(np.sin(theta))
	)
	approach = _qvec_norm(approach)
	q_tilt = QQuaternion.rotationTo(n, approach)
	return q_tilt * r0


def _xy_circle_offset(
	port_pos: QVector3D,
	offset_idx: int,
	n_ring: int,
	radius_mm: float,
) -> QVector3D:
	if offset_idx <= 0 or n_ring <= 0 or abs(float(radius_mm)) < 1e-6:
		return QVector3D(port_pos)
	k = offset_idx - 1
	phi = (2.0 * np.pi * float(k)) / float(n_ring)
	return QVector3D(
		float(port_pos.x()) + float(radius_mm) * float(np.cos(phi)),
		float(port_pos.y()) + float(radius_mm) * float(np.sin(phi)),
		float(port_pos.z()),
	)


def _quat_wxyz(q: QQuaternion) -> Tuple[float, float, float, float]:
	qn = QQuaternion(q).normalized()
	return (float(qn.scalar()), float(qn.x()), float(qn.y()), float(qn.z()))


def _xyz(v: QVector3D) -> Tuple[float, float, float]:
	return (float(v.x()), float(v.y()), float(v.z()))


def _goal_ee_in_base(
	pos_mm: QVector3D,
	rot: QQuaternion,
	T_world_base: np.ndarray,
	T_ee_tcp: np.ndarray,
) -> np.ndarray:
	t_world = np.eye(4, dtype=np.float64)
	t_world[:3, :3] = quat_to_rotation_matrix(rot)
	t_world[0, 3] = float(pos_mm.x()) * MM_TO_M
	t_world[1, 3] = float(pos_mm.y()) * MM_TO_M
	t_world[2, 3] = float(pos_mm.z()) * MM_TO_M
	t_goal = project_to_se3(np.linalg.inv(T_world_base) @ t_world)
	try:
		t_tcp_inv = np.linalg.inv(T_ee_tcp)
	except np.linalg.LinAlgError:
		t_tcp_inv = np.eye(4, dtype=np.float64)
	return project_to_se3(t_goal @ t_tcp_inv)


def _q_from_joints(joint_names: List[str], values: Dict[str, float], seed: np.ndarray) -> np.ndarray:
	q = np.asarray(seed, dtype=np.float64).reshape(-1).copy()
	for i, name in enumerate(joint_names):
		if i < len(q) and name in values:
			q[i] = float(values[name])
	return q


def _pose_reachable(
	job: LeakGenJob,
	pos_mm: QVector3D,
	rot: QQuaternion,
	q_seed: np.ndarray,
	backends: dict,
) -> Tuple[bool, np.ndarray]:
	t_goal = _goal_ee_in_base(pos_mm, rot, job.T_world_base, job.T_ee_tcp)
	request = replace(job.ik_template, T_goal_base=t_goal, q_seed=np.asarray(q_seed, dtype=np.float64))
	try:
		result = solve_ik_request(job.ik_backend, request, backends)
	except Exception:
		return False, q_seed
	if result is None or not bool(getattr(result, "success", False)) or not result.joint_values:
		return False, q_seed
	q = _q_from_joints(job.joint_names, result.joint_values, q_seed)
	try:
		if not job.collision_world.is_state_valid(q):
			return False, q_seed
	except Exception:
		return False, q_seed
	return True, q


def run_leak_gen_job(job: LeakGenJob, is_cancelled: CancelFn) -> LeakGenResult:
	n_samples = max(1, int(job.samples_per_port))
	radius = float(job.offset_radius_mm or 0.0)
	n_ring = max(0, int(job.offset_samples or 0))
	if radius < 1e-6 or n_ring <= 0:
		n_ring = 0
	n_offsets = 1 + n_ring
	height = max(0.0, float(job.approach_height_mm))
	r0 = QQuaternion(
		float(job.r0_wxyz[0]),
		float(job.r0_wxyz[1]),
		float(job.r0_wxyz[2]),
		float(job.r0_wxyz[3]),
	)
	q_seed = np.asarray(job.ik_template.q_seed, dtype=np.float64).reshape(-1).copy()
	backends: dict = {}
	hits: List[List[LeakGenHit]] = [[] for _ in job.ports]
	reach: List[List[int]] = [[0] * len(p) for p in job.ports]
	skipped: List[str] = []
	accepted_count = 0

	for seg_idx, ports in enumerate(job.ports):
		seg_name = job.seg_names[seg_idx] if seg_idx < len(job.seg_names) else ""
		seg_name = str(seg_name or "") or f"Segment {seg_idx + 1}"
		for port_idx, xyz in enumerate(ports):
			if is_cancelled():
				return LeakGenResult(False, "cancelled", cancelled=True)
			port0 = _qvec(xyz)
			ok_port = False
			for offset_idx in range(n_offsets):
				if ok_port:
					break
				port_pos = _xy_circle_offset(port0, offset_idx, n_ring, radius)
				for sample_idx in range(n_samples):
					if is_cancelled():
						return LeakGenResult(False, "cancelled", cancelled=True)
					r = _cone_sample_rotation(r0, sample_idx, n_samples, float(job.cone_tilt_deg))
					tcp_z = _qvec_norm(r.rotatedVector(QVector3D(0.0, 0.0, 1.0)))
					approach_pos = port_pos - tcp_z * height
					ok_a, q_mid = _pose_reachable(job, approach_pos, r, q_seed, backends)
					if not ok_a:
						continue
					ok_p, q_end = _pose_reachable(job, port_pos, r, q_mid, backends)
					if not ok_p:
						continue
					hits[seg_idx].append(
						LeakGenHit(
							approach=_xyz(approach_pos),
							port=_xyz(port_pos),
							quat_wxyz=_quat_wxyz(r),
						)
					)
					reach[seg_idx][port_idx] = 1
					accepted_count += 1
					q_seed = q_end
					ok_port = True
					break
			if not ok_port:
				skipped.append(f"{seg_name} port {port_idx + 1}")

	return LeakGenResult(
		ok=True,
		message="",
		hits=hits,
		reach=reach,
		skipped=skipped,
		accepted_count=accepted_count,
	)


class LeakGenThread(QThread):
	"""One-shot worker: run ``LeakGenJob`` then emit ``finished_job``."""

	finished_job = pyqtSignal(object)

	def __init__(self, job: LeakGenJob) -> None:
		super().__init__()
		self._job = job

	def run(self) -> None:
		try:
			result = run_leak_gen_job(self._job, self.isInterruptionRequested)
		except Exception as exc:
			result = LeakGenResult(False, f"offline generate failed ({exc})")
		self.finished_job.emit(result)

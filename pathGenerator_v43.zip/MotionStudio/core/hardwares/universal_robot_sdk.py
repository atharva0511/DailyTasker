"""Optional ur_rtde adapter for Universal Robots controllers.

Connect / send-script / digital I/O / disconnect live here so the component
can start without ``ur_rtde`` installed. Callables raise ``UniversalRobotSdkError``
with a user-facing message when the package is missing or a call fails.

Handles are owned by the hardware worker thread only.
"""

from __future__ import annotations

import socket
import time
from pathlib import Path
from typing import Any, Optional, Tuple


RTDE_PORT = 30004
SCRIPT_PORT = 30002
# Transient RTDE drops are common when a .script starts on 30002.
RECONNECT_ATTEMPTS = 3
RECONNECT_DELAY_S = 1.0
# ur_rtde may return an object before the recipe handshake; PolyScope Local /
# Remote and an unplugged cable leave the single 30004 slot occupied until
# disconnect() + watchdog. Do not dummy-TCP 30004 (that steals the slot).
_RECEIVE_HANDSHAKE_S = 2.0
_SLOT_RELEASE_S = 0.5


class UniversalRobotSdkError(RuntimeError):
	"""ur_rtde missing, connect failed, or script send failed."""


class UrRtdeSession:
	"""Paired control + receive interfaces for one controller session."""

	__slots__ = ("control", "receive", "io", "ip_address")

	def __init__(
		self,
		control: Any,
		receive: Any,
		ip_address: str = "",
		io: Any = None,
	) -> None:
		self.control = control
		self.receive = receive
		self.io = io
		self.ip_address = str(ip_address or "")


def sdk_available() -> bool:
	return _load_sdk()[0] is not None


def sdk_missing_message() -> str:
	return "ur_rtde is not installed. pip install ur_rtde"


def connect_robot(ip_address: str, timeout_ms: int) -> UrRtdeSession:
	"""Open RTDE receive (worker-thread only).

	Does **not** open ``RTDEControlInterface``. That constructor uploads
	ur_rtde's own control script, which a later 30002 ``.script`` send
	replaces — the control handle then dies and often takes the receive
	link with it. Receive on 30004 is enough for ``isProgramRunning``,
	safety flags, and TCP/joint reads while exported programs run.

	Retries until ``timeout_ms`` so a slot left occupied after Local/Remote
	or a dropped cable can expire without restarting PolyScope.
	"""
	_control_mod, receive_mod, err = _load_sdk()
	if receive_mod is None:
		raise UniversalRobotSdkError(err or sdk_missing_message())
	ip = str(ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	try:
		timeout = int(timeout_ms)
	except Exception:
		timeout = 10000
	timeout = max(1, timeout)
	deadline = time.monotonic() + (timeout / 1000.0)
	last = "RTDE receive is not connected."
	while True:
		remaining = deadline - time.monotonic()
		if remaining <= 0.0:
			raise UniversalRobotSdkError(last)
		wait_s = min(_RECEIVE_HANDSHAKE_S, remaining)
		try:
			receive = _construct_receive(receive_mod, ip, wait_s=wait_s)
			return UrRtdeSession(None, receive, ip)
		except UniversalRobotSdkError as exc:
			last = str(exc)
		time.sleep(min(_SLOT_RELEASE_S, max(0.1, remaining)))


def disconnect_robot(session: Optional[UrRtdeSession]) -> None:
	if session is None:
		return
	_close_io(session)
	_close_receive(session)
	control = session.control
	session.control = None
	_dispose_rtde_handle(control)


def send_script_file(session: Optional[UrRtdeSession], abs_script_path: str) -> None:
	"""Send a URScript file on the secondary interface (port 30002).

	Does **not** use ``sendCustomScriptFile``. That ur_rtde call blocks in
	native code until a control-script handshake a normal ``.script`` never
	sends, so status would stay on Running script after the robot finished.
	"""
	path = str(abs_script_path or "").strip()
	if not path:
		raise UniversalRobotSdkError("Script path is empty.")
	try:
		text = Path(path).read_text(encoding="utf-8")
	except OSError as exc:
		raise UniversalRobotSdkError(f"Could not read script: {exc}") from exc
	send_script_text(session, text)


def send_script_text(session: Optional[UrRtdeSession], script_text: str) -> None:
	"""Send URScript source on the secondary interface (port 30002)."""
	if session is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	ip = str(session.ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	text = str(script_text or "")
	if not text.strip():
		raise UniversalRobotSdkError("Script is empty.")
	if not text.endswith("\n"):
		text += "\n"
	try:
		sock = socket.create_connection((ip, SCRIPT_PORT), timeout=5.0)
		try:
			sock.sendall(text.encode("utf-8"))
		finally:
			sock.close()
	except OSError as exc:
		raise UniversalRobotSdkError(
			f"Could not send script to {ip}:{SCRIPT_PORT} (not in Remote Control, "
			f"or the controller is unreachable). ({exc})"
		) from exc
	# Starting a program on 30002 often flickers RTDE receive. Give the
	# controller a beat, then restore receive if it dropped.
	time.sleep(0.35)
	if not reconnect_receive(session, attempts=RECONNECT_ATTEMPTS):
		raise UniversalRobotSdkError(
			"Connection lost after sending the script (RTDE receive did not recover)."
		)


def send_movel(
	session: Optional[UrRtdeSession],
	pose_m_rotvec: Tuple[float, float, float, float, float, float],
	*,
	speed_m_s: float = 0.25,
	accel_m_s2: float = 1.2,
) -> None:
	"""Send a one-shot ``movel`` to ``p[x,y,z,rx,ry,rz]`` (metres, UR rotvec)."""
	x, y, z, rx, ry, rz = (float(v) for v in pose_m_rotvec)
	v = max(1e-4, float(speed_m_s))
	a = max(1e-4, float(accel_m_s2))
	text = (
		"def move_to_target():\n"
		f"    movel(p[{x:.6f}, {y:.6f}, {z:.6f}, {rx:.6f}, {ry:.6f}, {rz:.6f}], "
		f"a={a:.6f}, v={v:.6f})\n"
		"end\n"
		"move_to_target()\n"
	)
	send_script_text(session, text)


def send_halt(session: Optional[UrRtdeSession]) -> None:
	"""Replace the running program with ``halt`` so motion and scripts stop."""
	send_script_text(session, "halt\n")


# PolyScope digital banks (same labels as path segment I/O actions).
IO_TYPE_STANDARD_OUT = "Standard Out"
IO_TYPE_CONFIGURABLE_OUT = "Configurable Out"
IO_TYPE_TOOL_OUT = "Tool Out"
IO_TYPE_STANDARD_IN = "Standard In"
IO_TYPE_CONFIGURABLE_IN = "Configurable In"
IO_TYPE_TOOL_IN = "Tool In"

_OUTPUT_IO_TYPES = {
	IO_TYPE_STANDARD_OUT: ("setStandardDigitalOut", "set_standard_digital_out", 0, 7),
	IO_TYPE_CONFIGURABLE_OUT: (
		"setConfigurableDigitalOut",
		"set_configurable_digital_out",
		0,
		7,
	),
	IO_TYPE_TOOL_OUT: ("setToolDigitalOut", "set_tool_digital_out", 0, 1),
}
_OUTPUT_READ_IO_TYPES = {
	IO_TYPE_STANDARD_OUT: ("getStandardDigitalOut", 0, 0, 7),
	IO_TYPE_CONFIGURABLE_OUT: ("getConfigurableDigitalOut", 8, 0, 7),
	IO_TYPE_TOOL_OUT: ("getToolDigitalOut", 16, 0, 1),
}
_INPUT_IO_TYPES = {
	IO_TYPE_STANDARD_IN: ("getStandardDigitalIn", 0, 0, 7),
	IO_TYPE_CONFIGURABLE_IN: ("getConfigurableDigitalIn", 8, 0, 7),
	IO_TYPE_TOOL_IN: ("getToolDigitalIn", 16, 0, 1),
}


def io_type_is_input(io_type: str) -> bool:
	return str(io_type or "").strip() in _INPUT_IO_TYPES


def apply_digital_io(
	session: Optional[UrRtdeSession],
	io_type: str,
	index: int,
	value: bool,
	*,
	read: bool = False,
) -> bool:
	"""Write a digital output or read a digital pin. Returns the pin level.

	Outputs prefer ``RTDEIOInterface`` so a running program is not replaced.
	Falls back to a one-shot URScript on port 30002 (same path as ``movel``).
	Inputs are always read from RTDE receive. ``read=True`` also reads an
	output bank (Wait Signal) instead of writing it.
	"""
	if session is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	kind = str(io_type or "").strip()
	if io_type_is_input(kind) or read:
		return _read_digital_io(session, kind, index)
	if kind not in _OUTPUT_IO_TYPES:
		raise UniversalRobotSdkError(f"Unknown I/O type: {io_type}")
	rtde_name, script_name, lo, hi = _OUTPUT_IO_TYPES[kind]
	idx = _clamp_io_index(index, lo, hi, kind)
	level = bool(value)
	if not _set_digital_out_rtde(session, rtde_name, idx, level):
		b = "True" if level else "False"
		send_script_text(
			session,
			"def apply_io():\n"
			f"    {script_name}({idx}, {b})\n"
			"end\n"
			"apply_io()\n",
		)
	return level


def _read_digital_io(session: UrRtdeSession, io_type: str, index: int) -> bool:
	if io_type_is_input(io_type):
		method, bit_offset, lo, hi = _INPUT_IO_TYPES[io_type]
		outputs = False
	elif io_type in _OUTPUT_READ_IO_TYPES:
		method, bit_offset, lo, hi = _OUTPUT_READ_IO_TYPES[io_type]
		outputs = True
	else:
		raise UniversalRobotSdkError(f"Unknown I/O type: {io_type}")
	idx = _clamp_io_index(index, lo, hi, io_type)
	return _read_digital_bit(session, method, bit_offset, idx, outputs=outputs)


def _clamp_io_index(index: int, lo: int, hi: int, io_type: str) -> int:
	try:
		idx = int(index)
	except Exception:
		idx = lo
	if idx < lo or idx > hi:
		raise UniversalRobotSdkError(
			f"{io_type} index must be {lo}–{hi} (got {idx})."
		)
	return idx


def _set_digital_out_rtde(
	session: UrRtdeSession,
	method_name: str,
	index: int,
	value: bool,
) -> bool:
	"""True if RTDE IO applied the pin. False = caller should use URScript."""
	io = _ensure_io(session)
	if io is None:
		return False
	fn = getattr(io, method_name, None)
	if not callable(fn):
		return False
	try:
		result = fn(int(index), bool(value))
	except Exception:
		return False
	if result is False:
		return False
	return True


def _read_digital_bit(
	session: UrRtdeSession,
	method_name: str,
	bit_offset: int,
	index: int,
	*,
	outputs: bool,
) -> bool:
	recv = session.receive
	if recv is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	fn = getattr(recv, method_name, None)
	if callable(fn):
		try:
			return bool(fn(int(index)))
		except Exception:
			pass
	bits_fn_names = (
		("getActualDigitalOutputBits", "getDigitalOutBits")
		if outputs
		else ("getActualDigitalInputBits", "getDigitalInBits")
	)
	last_exc: Optional[Exception] = None
	for name in bits_fn_names:
		fn = getattr(recv, name, None)
		if not callable(fn):
			continue
		try:
			bits = int(fn())
			return bool((bits >> (int(bit_offset) + int(index))) & 1)
		except Exception as exc:
			last_exc = exc
			continue
	detail = f" ({last_exc})" if last_exc else ""
	raise UniversalRobotSdkError(f"Could not read {method_name}[{index}].{detail}")


def _ensure_io(session: UrRtdeSession) -> Any:
	if session.io is not None:
		return session.io
	mod, err = _load_io()
	if mod is None:
		return None
	ip = str(session.ip_address or "").strip()
	if not ip:
		return None
	try:
		handle = mod.RTDEIOInterface(ip)
	except Exception:
		return None
	session.io = handle
	return handle


def _load_io() -> Tuple[Optional[Any], str]:
	try:
		import rtde_io  # type: ignore
	except Exception as exc:
		return None, str(exc)
	if not hasattr(rtde_io, "RTDEIOInterface"):
		return None, "ur_rtde is installed but RTDEIOInterface is missing."
	return rtde_io, ""


def session_is_connected(
	session: Optional[UrRtdeSession],
	*,
	probe_host: bool = False,
) -> bool:
	"""True when RTDE receive still has a live recipe (``getActualQ``).

	``probe_host`` is ignored: a dummy TCP connect to 30004 steals the
	controller's single RTDE client slot and is what left reconnect
	stuck until PolyScope restart.
	"""
	del probe_host
	if session is None or session.receive is None:
		return False
	recv = session.receive
	try:
		if hasattr(recv, "isConnected") and not bool(recv.isConnected()):
			return False
	except Exception:
		return False
	try:
		if hasattr(recv, "getActualQ"):
			recv.getActualQ()
	except Exception:
		return False
	return True


def reconnect_receive(
	session: Optional[UrRtdeSession],
	*,
	attempts: int = RECONNECT_ATTEMPTS,
	delay_s: float = RECONNECT_DELAY_S,
) -> bool:
	"""Re-open RTDE receive after a dropped link. Worker-thread only.

	Returns True if the session is (or became) connected. Does not open
	``RTDEControlInterface``. Disposes IO + receive first so a dead client
	does not keep the 30004 slot. Sleeps ``delay_s`` between attempts.
	"""
	if session is None:
		return False
	if session_is_connected(session):
		return True
	_control_mod, receive_mod, err = _load_sdk()
	if receive_mod is None:
		return False
	ip = str(session.ip_address or "").strip()
	if not ip:
		return False
	n = max(1, int(attempts))
	wait = max(0.2, float(delay_s))
	last_exc = err
	for i in range(n):
		_close_io(session)
		_close_receive(session)
		time.sleep(wait)
		try:
			session.receive = _construct_receive(
				receive_mod, ip, wait_s=_RECEIVE_HANDSHAKE_S
			)
			if session_is_connected(session):
				if i > 0:
					print(
						f"UniversalRobot: RTDE receive reconnected on attempt {i + 1}/{n}.",
						flush=True,
					)
				return True
		except Exception as exc:
			last_exc = exc
			_close_receive(session)
		print(
			f"UniversalRobot: RTDE receive reconnect {i + 1}/{n} failed ({last_exc}).",
			flush=True,
		)
	return False


def _dispose_rtde_handle(handle: Any) -> None:
	if handle is None:
		return
	for name in ("disconnect", "stop"):
		fn = getattr(handle, name, None)
		if not callable(fn):
			continue
		try:
			fn()
		except Exception:
			pass


def _close_receive(session: UrRtdeSession) -> None:
	recv = session.receive
	session.receive = None
	_dispose_rtde_handle(recv)


def _close_io(session: UrRtdeSession) -> None:
	io = session.io
	session.io = None
	_dispose_rtde_handle(io)


def is_program_running(session: Optional[UrRtdeSession]) -> bool:
	if session is None:
		return False
	for handle in (session.receive, session.control):
		if handle is None or not hasattr(handle, "isProgramRunning"):
			continue
		try:
			return bool(handle.isProgramRunning())
		except Exception:
			continue
	return False


def safety_fault_message(session: Optional[UrRtdeSession]) -> str:
	"""Empty unless protective or emergency stop is active."""
	if session is None:
		return ""
	recv = session.receive
	if recv is None:
		return ""
	try:
		if hasattr(recv, "isEmergencyStopped") and recv.isEmergencyStopped():
			return "Emergency stop."
	except Exception:
		pass
	try:
		if hasattr(recv, "isProtectiveStopped") and recv.isProtectiveStopped():
			return "Protective stop."
	except Exception:
		pass
	return ""


def get_tcp_pose(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""TCP pose in metres / rotation vector (ur_rtde ``getActualTCPPose``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		pose = session.receive.getActualTCPPose()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualTCPPose failed: {exc}") from exc
	return tuple(float(v) for v in pose)


def get_joints(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""Actual joint positions in radians (ur_rtde ``getActualQ``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		q = session.receive.getActualQ()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualQ failed: {exc}") from exc
	return tuple(float(v) for v in q)


def _wait_receive_connected(handle: Any, wait_s: float) -> bool:
	"""Poll until the recipe handshake is live (constructor is often async)."""
	deadline = time.monotonic() + max(0.05, float(wait_s))
	while True:
		try:
			if hasattr(handle, "isConnected") and not bool(handle.isConnected()):
				pass
			elif hasattr(handle, "getActualQ"):
				handle.getActualQ()
				return True
			elif hasattr(handle, "isConnected") and bool(handle.isConnected()):
				return True
		except Exception:
			pass
		if time.monotonic() >= deadline:
			return False
		time.sleep(0.05)


def _construct_receive(receive_mod: Any, ip: str, *, wait_s: float = _RECEIVE_HANDSHAKE_S) -> Any:
	cls = receive_mod.RTDEReceiveInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(f"RTDE receive connect failed: {exc}") from exc
	if _wait_receive_connected(handle, wait_s):
		return handle
	_dispose_rtde_handle(handle)
	raise UniversalRobotSdkError("RTDE receive is not connected.")


def _construct_control(control_mod: Any, ip: str) -> Any:
	cls = control_mod.RTDEControlInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(
			f"RTDE control connect failed: {exc}. On e-Series the robot must be "
			f"in Remote Control."
		) from exc
	return handle


def _load_sdk() -> Tuple[Optional[Any], Optional[Any], str]:
	try:
		import rtde_control  # type: ignore
		import rtde_receive  # type: ignore
	except Exception as exc:
		return None, None, f"{sdk_missing_message()} ({exc})"
	if not hasattr(rtde_control, "RTDEControlInterface"):
		return None, None, "ur_rtde is installed but RTDEControlInterface is missing."
	if not hasattr(rtde_receive, "RTDEReceiveInterface"):
		return None, None, "ur_rtde is installed but RTDEReceiveInterface is missing."
	return rtde_control, rtde_receive, ""

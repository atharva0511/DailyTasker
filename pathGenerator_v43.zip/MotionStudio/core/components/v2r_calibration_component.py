"""Eye-in-hand vision-to-robot calibration.

Scan a cloud, pick six points, capture matching TCP millimetres in the
hardware robot base (Inspector TCP), then write the optical Camera Frame as a
rigid offset on the scanner CAD.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated, Any, Dict, List, Literal, Optional

from PyQt6.QtGui import QColor, QMatrix4x4, QQuaternion, QVector3D

from MotionStudio.core.components.robot import Robot
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.scanner import Scanner, clear_scanner_cloud
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.remote.protocol import interpret_button_result
from MotionStudio.core.transform.rigid import kabsch_rigid
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	transform_point,
	world_matrix,
)
from MotionStudio.ui.inspector.metadata import (
	Group,
	Header,
	Multiline,
	Order,
	ReadOnly,
	RobotTcp,
	Tooltip,
	VertexPick,
	inspector_button,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity


STATUS_IDLE = "Idle"
STATUS_SCANNING = "Scanning…"
GROUP_CLOUD = "Cloud points"
GROUP_ROBOT = "Robot TCP (base mm)"
_EPS = 1e-6


def _hw_connected(component: Any) -> bool:
	return bool(getattr(component, "_was_connected", False))


def _qvec(value: Optional[QVector3D]) -> QVector3D:
	if isinstance(value, QVector3D):
		return QVector3D(value)
	return QVector3D(0.0, 0.0, 0.0)


def _matrix_from_rt(R: Any, t: Any) -> QMatrix4x4:
	return QMatrix4x4(
		float(R[0, 0]), float(R[0, 1]), float(R[0, 2]), float(t[0]),
		float(R[1, 0]), float(R[1, 1]), float(R[1, 2]), float(t[1]),
		float(R[2, 0]), float(R[2, 1]), float(R[2, 2]), float(t[2]),
		0.0, 0.0, 0.0, 1.0,
	)


def _rotation_from_matrix(matrix: QMatrix4x4) -> QQuaternion:
	return QQuaternion.fromRotationMatrix(matrix.normalMatrix())


@register_component
class V2RCalibrationComponent(Component):
	type_name = "V2RCalibration"
	category = "Alignment and datum"
	description = (
		"<p><b>V2R Calibration</b></p>"
		"<p>Eye-in-hand calibration: mount the scanner CAD on <b>tool0</b>, assign "
		"<b>Camera Frame</b> as an optical child, capture a cloud, pick six points, "
		"type the matching TCP positions in the robot base, then write the optical "
		"frame onto Camera Frame.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Add this component on a <b>Job</b> entity. Assign <b>robot</b> and "
		"<b>scanner</b>. Connect both. Prefer <b>append_scan</b> off for a single cloud.</li>"
		"<li><b>Scan</b> clears the previous cloud, copies live joints onto the "
		"virtual URDF, then Captures and snapshots Camera Frame / CAD / robot-base "
		"world poses.</li>"
		"<li>Pick six cloud vertices. Jog the real TCP to those physical points and "
		"enter millimetres in the robot base.</li>"
		"<li><b>Calibrate</b> solves a rigid transform (scale preserved) and sets "
		"Camera Frame. <b>Clear</b> resets the pairs.</li>"
		"</ul>"
	)

	configuration: Annotated[
		Literal["EyeInHand"],
		Order(0),
		Tooltip("Calibration model. EyeInHand: camera mounted on the robot flange / tool0."),
	] = "EyeInHand"
	robot: Annotated[
		Optional[Robot],
		Order(10),
		Tooltip("Hardware robot (UniversalRobot). Scan copies live joints onto its RobotDescription."),
	]
	scanner: Annotated[
		Optional[Scanner],
		Order(20),
		Tooltip(
			"Hardware scanner (MechmindScanner). Camera Frame must be assigned. "
			"Prefer append_scan off so picks come from this capture only."
		),
	]
	status: Annotated[
		str,
		ReadOnly(),
		Multiline(),
		Order(30),
		Tooltip("Scan / calibrate progress and RMSE. Not restored from the scene file."),
	] = STATUS_IDLE

	cloud_1: Annotated[QVector3D, Group(GROUP_CLOUD), Header("Pick on the captured cloud"), VertexPick(), Order(100), Tooltip("Cloud point 1 (owner-local mm).")]
	cloud_2: Annotated[QVector3D, Group(GROUP_CLOUD), VertexPick(), Order(110), Tooltip("Cloud point 2 (owner-local mm).")]
	cloud_3: Annotated[QVector3D, Group(GROUP_CLOUD), VertexPick(), Order(120), Tooltip("Cloud point 3 (owner-local mm).")]
	cloud_4: Annotated[QVector3D, Group(GROUP_CLOUD), VertexPick(), Order(130), Tooltip("Cloud point 4 (owner-local mm).")]
	cloud_5: Annotated[QVector3D, Group(GROUP_CLOUD), VertexPick(), Order(140), Tooltip("Cloud point 5 (owner-local mm).")]
	cloud_6: Annotated[QVector3D, Group(GROUP_CLOUD), VertexPick(), Order(150), Tooltip("Cloud point 6 (owner-local mm).")]

	robot_1: Annotated[QVector3D, Group(GROUP_ROBOT), Header("TCP in robot base (mm)"), RobotTcp(), Order(200), Tooltip("TCP origin at cloud point 1, millimetres in the connected hardware robot base.")]
	robot_2: Annotated[QVector3D, Group(GROUP_ROBOT), RobotTcp(), Order(210), Tooltip("TCP origin at cloud point 2, millimetres in the connected hardware robot base.")]
	robot_3: Annotated[QVector3D, Group(GROUP_ROBOT), RobotTcp(), Order(220), Tooltip("TCP origin at cloud point 3, millimetres in the connected hardware robot base.")]
	robot_4: Annotated[QVector3D, Group(GROUP_ROBOT), RobotTcp(), Order(230), Tooltip("TCP origin at cloud point 4, millimetres in the connected hardware robot base.")]
	robot_5: Annotated[QVector3D, Group(GROUP_ROBOT), RobotTcp(), Order(240), Tooltip("TCP origin at cloud point 5, millimetres in the connected hardware robot base.")]
	robot_6: Annotated[QVector3D, Group(GROUP_ROBOT), RobotTcp(), Order(250), Tooltip("TCP origin at cloud point 6, millimetres in the connected hardware robot base.")]

	def __init__(self) -> None:
		self.configuration = "EyeInHand"
		self.robot = None
		self.scanner = None
		self.status = STATUS_IDLE
		self.cloud_1 = QVector3D()
		self.cloud_2 = QVector3D()
		self.cloud_3 = QVector3D()
		self.cloud_4 = QVector3D()
		self.cloud_5 = QVector3D()
		self.cloud_6 = QVector3D()
		self.robot_1 = QVector3D()
		self.robot_2 = QVector3D()
		self.robot_3 = QVector3D()
		self.robot_4 = QVector3D()
		self.robot_5 = QVector3D()
		self.robot_6 = QVector3D()
		self._listeners: list = []
		self._notified = False
		self._scanning = False
		self._phase = "idle"
		self._await_kind = ""
		self._bound_robot: Optional[Robot] = None
		self._bound_scanner: Optional[Scanner] = None
		self._snap_cam: Optional[QMatrix4x4] = None
		self._snap_cad: Optional[QMatrix4x4] = None
		self._snap_base: Optional[QMatrix4x4] = None

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "V2RCalibrationComponent":
		inst = super().from_dict(data)
		inst.force_setattr("status", STATUS_IDLE)
		return inst

	def add_scan_listener(self, callback) -> None:
		if callback not in self._listeners:
			self._listeners.append(callback)

	def remove_scan_listener(self, callback) -> None:
		try:
			self._listeners.remove(callback)
		except ValueError:
			pass

	def _notify_scan_done(self, success: bool, message: str = "") -> None:
		if self._notified:
			return
		self._notified = True
		for callback in list(self._listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	def _cloud_points(self) -> List[QVector3D]:
		return [
			_qvec(self.cloud_1), _qvec(self.cloud_2), _qvec(self.cloud_3),
			_qvec(self.cloud_4), _qvec(self.cloud_5), _qvec(self.cloud_6),
		]

	def _robot_points(self) -> List[QVector3D]:
		return [
			_qvec(self.robot_1), _qvec(self.robot_2), _qvec(self.robot_3),
			_qvec(self.robot_4), _qvec(self.robot_5), _qvec(self.robot_6),
		]

	@inspector_button(
		"Scan",
		tooltip=(
			"Clear the previous cloud, copy live joints onto the virtual robot, Capture, "
			"and snapshot Camera Frame / CAD / robot-base poses. Prefer append_scan off."
		),
		order=40,
	)
	def scan(self):
		if self._scanning:
			return False, "scan is already running"
		if str(self.configuration or "EyeInHand") != "EyeInHand":
			return False, f"unsupported configuration: {self.configuration}"
		mover = self._resolved_robot()
		if mover is None:
			return False, "assign a Robot"
		scanner = self._resolved_scanner()
		if scanner is None:
			return False, "assign a Scanner"
		if not _hw_connected(mover):
			return False, "robot is not connected"
		if not _hw_connected(scanner):
			return False, "scanner is not connected"
		if self._scanner_camera_entity(scanner) is None:
			return False, "assign Camera Frame on the scanner"
		if scanner.entity is None:
			return False, "scanner has no entity"
		rd = self._resolved_robot_description(mover)
		if rd is None:
			return False, (
				"bind RobotDescription on the UniversalRobot robot field "
				"(or as a sibling on the controller entity)"
			)
		if self._robot_base_entity(rd) is None:
			return False, "could not resolve robot base / root_link"

		clear_err = clear_scanner_cloud(scanner)
		if clear_err:
			self.status = f"Error: {clear_err}"
			return False, clear_err

		self._notified = False
		self._scanning = True
		self._bound_robot = mover
		self._bound_scanner = scanner
		self._phase = "sync"
		self._await_kind = "apply_actual_configuration"
		self.status = STATUS_SCANNING
		mover.add_job_listener(self._on_hw_job)
		scanner.add_job_listener(self._on_hw_job)
		result = mover.apply_actual_configuration()
		if result is True:
			return True
		self._teardown_hw()
		_ok, output = interpret_button_result(result)
		msg = output or "apply_actual_configuration did not start"
		self.status = f"Error: {msg}"
		self._notify_scan_done(False, msg)
		return False, msg

	@inspector_button(
		"Calibrate",
		tooltip="Solve Camera Frame from six cloud picks and six robot-base TCP points",
		order=50,
	)
	def calibrate(self):
		if self._scanning:
			return False, "scan is still running"
		if self._snap_cam is None or self._snap_cad is None or self._snap_base is None:
			return False, "Scan first so Camera Frame / CAD / base poses are snapshotted"
		entity = self.entity
		if entity is None:
			return False, "no entity"
		scanner = self._resolved_scanner()
		if scanner is None:
			return False, "assign a Scanner"
		cam_ent = self._scanner_camera_entity(scanner)
		if cam_ent is None:
			return False, "assign Camera Frame on the scanner"
		if cam_ent.get_component(TransformComponent) is None:
			return False, "Camera Frame has no Transform"

		cloud_local = self._cloud_points()
		robot_base = self._robot_points()
		err = self._validate_pairs(cloud_local, robot_base)
		if err:
			self.status = f"Error: {err}"
			return False, err

		inv_cam, ok = QMatrix4x4(self._snap_cam).inverted()
		if not ok:
			return False, "could not invert Camera Frame snapshot"
		p_cam: List[QVector3D] = []
		for local in cloud_local:
			world = transform_point(entity, local)
			p_cam.append(inv_cam.map(world))

		ok_k, R, t, rmse = kabsch_rigid(p_cam, robot_base)
		if not ok_k:
			msg = "degenerate points (coincident or colinear)"
			self.status = f"Error: {msg}"
			return False, msg

		t_base_cam = _matrix_from_rt(R, t)
		t_world_cam = QMatrix4x4(self._snap_base) * t_base_cam
		pos = t_world_cam.column(3).toVector3D()
		rot = _rotation_from_matrix(t_world_cam)
		set_world_rotation_quat(cam_ent, rot)
		set_world_position(cam_ent, pos)
		msg = f"Calibrated Camera Frame (RMSE {rmse:.4g} mm)"
		self.status = msg
		Debug.log(f"V2RCalibration: {msg}")
		return None

	@inspector_button(
		"Clear",
		tooltip="Reset cloud picks, robot TCP points, and the Scan snapshot",
		order=60,
	)
	def clear(self) -> None:
		if self._scanning:
			self.cancel_scan()
		self.cloud_1 = QVector3D()
		self.cloud_2 = QVector3D()
		self.cloud_3 = QVector3D()
		self.cloud_4 = QVector3D()
		self.cloud_5 = QVector3D()
		self.cloud_6 = QVector3D()
		self.robot_1 = QVector3D()
		self.robot_2 = QVector3D()
		self.robot_3 = QVector3D()
		self.robot_4 = QVector3D()
		self.robot_5 = QVector3D()
		self.robot_6 = QVector3D()
		self._drop_snapshot()
		self.status = STATUS_IDLE

	def cancel_scan(self) -> None:
		if not self._scanning:
			return
		self._teardown_hw()
		self.status = STATUS_IDLE
		self._notify_scan_done(False, "cancelled")

	def _on_hw_job(self, kind: str, success: bool, message: str) -> None:
		if kind != self._await_kind:
			return
		if not self._scanning:
			return
		if not success:
			if self._phase == "capture":
				self._drop_snapshot()
			self._teardown_hw()
			msg = message or f"{kind} failed"
			self.status = f"Error: {msg}"
			self._notify_scan_done(False, msg)
			return
		if self._phase == "sync":
			self._start_capture()
			return
		if self._phase == "capture":
			self._teardown_hw()
			self.status = "Scan ready — pick six cloud points, then enter TCP millimetres"
			self._notify_scan_done(True, self.status)
			return

	def _start_capture(self) -> None:
		scanner = self._bound_scanner
		mover = self._bound_robot
		if scanner is None or mover is None:
			self._teardown_hw()
			self.status = "Error: robot or scanner unbound"
			self._notify_scan_done(False, "robot or scanner unbound")
			return
		cam_ent = self._scanner_camera_entity(scanner)
		cad_ent = scanner.entity
		rd = self._resolved_robot_description(mover)
		base_ent = self._robot_base_entity(rd) if rd is not None else None
		if cam_ent is None or cad_ent is None or base_ent is None:
			self._teardown_hw()
			self.status = "Error: Camera Frame / CAD / robot base missing at capture"
			self._notify_scan_done(False, "Camera Frame / CAD / robot base missing at capture")
			return
		# Same instant Mechmind snapshots Camera Frame for append_scan.
		self._snap_cam = QMatrix4x4(world_matrix(cam_ent))
		self._snap_cad = QMatrix4x4(world_matrix(cad_ent))
		self._snap_base = QMatrix4x4(world_matrix(base_ent))
		self._phase = "capture"
		self._await_kind = "capture"
		result = scanner.capture_scan()
		if result is True:
			return
		self._drop_snapshot()
		self._teardown_hw()
		_ok, output = interpret_button_result(result)
		msg = output or "capture did not start"
		self.status = f"Error: {msg}"
		self._notify_scan_done(False, msg)

	def _drop_snapshot(self) -> None:
		self._snap_cam = None
		self._snap_cad = None
		self._snap_base = None

	def _teardown_hw(self) -> None:
		mover = self._bound_robot
		scanner = self._bound_scanner
		self._bound_robot = None
		self._bound_scanner = None
		self._scanning = False
		self._phase = "idle"
		self._await_kind = ""
		if mover is not None:
			try:
				mover.remove_job_listener(self._on_hw_job)
			except Exception:
				pass
		if scanner is not None:
			try:
				scanner.remove_job_listener(self._on_hw_job)
			except Exception:
				pass

	def on_viewport_draw(self) -> None:
		entity = self.entity
		if entity is None or entity.scene is None:
			return
		selection = getattr(entity.scene, "selection", None)
		if selection is None or getattr(selection, "current", None) is not entity:
			return
		for i, local in enumerate(self._cloud_points(), start=1):
			world = transform_point(entity, local)
			Debug.draw_point(world, size=10.0, screen_space=True, color=QColor(80, 200, 255), opacity=0.9, on_top=False)
			Debug.draw_label(world + QVector3D(0.0, 12.0, 0.0), f"C{i}", color=QColor(80, 200, 255), font_size=12)
		mover = self._resolved_robot()
		rd = self._resolved_robot_description(mover) if mover is not None else None
		base = self._robot_base_entity(rd) if rd is not None else None
		if base is None:
			return
		for i, local in enumerate(self._robot_points(), start=1):
			world = transform_point(base, local)
			Debug.draw_point(world, size=10.0, screen_space=True, color=QColor(255, 170, 40), opacity=0.9, on_top=False)
			Debug.draw_label(world + QVector3D(0.0, 12.0, 0.0), f"R{i}", color=QColor(255, 170, 40), font_size=12)

	@staticmethod
	def _validate_pairs(cloud: List[QVector3D], robot: List[QVector3D]) -> str:
		if len(cloud) != 6 or len(robot) != 6:
			return "need six cloud points and six robot TCP points"
		for label, pts in (("cloud", cloud), ("robot", robot)):
			for i in range(len(pts)):
				for j in range(i + 1, len(pts)):
					if (pts[i] - pts[j]).lengthSquared() < _EPS:
						return f"two {label} points coincide ({i + 1} and {j + 1})"
		return ""

	def _resolve_ref(self, value: Any, cls: type) -> Any:
		if isinstance(value, cls):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(cls)
				if comp is not None:
					return comp
		return None

	def _resolved_robot(self) -> Optional[Robot]:
		comp = self._resolve_ref(self.robot, Robot)
		if isinstance(comp, Robot):
			self.robot = comp
			return comp
		return None

	def _resolved_scanner(self) -> Optional[Scanner]:
		comp = self._resolve_ref(self.scanner, Scanner)
		if isinstance(comp, Scanner):
			self.scanner = comp
			return comp
		return None

	def _scanner_camera_entity(self, scanner: Scanner) -> Optional["Entity"]:
		fn = getattr(scanner, "capture_pose_entity", None)
		if callable(fn):
			return fn()
		return None

	def _resolved_robot_description(self, mover: Robot) -> Optional[RobotDescriptionComponent]:
		rd = self._robot_description_from_value(
			getattr(mover, "robot", None),
			getattr(mover, "entity", None),
		)
		if rd is not None:
			return rd
		mover_ent = getattr(mover, "entity", None)
		if mover_ent is not None:
			comp = mover_ent.get_component(RobotDescriptionComponent)
			if isinstance(comp, RobotDescriptionComponent):
				return comp
		return None

	def _robot_description_from_value(
		self,
		value: Any,
		owner_entity: Any,
	) -> Optional[RobotDescriptionComponent]:
		if isinstance(value, RobotDescriptionComponent):
			return value
		scene = None
		if owner_entity is not None:
			scene = getattr(owner_entity, "scene", None)
		if scene is None and self.entity is not None:
			scene = self.entity.scene
		if isinstance(value, str) and scene is not None:
			ent = scene.find_by_id(value)
			if ent is None:
				name = value.strip()
				if name:
					for candidate in scene.entities():
						if str(getattr(candidate, "name", "") or "") == name:
							ent = candidate
							break
			if ent is not None:
				comp = ent.get_component(RobotDescriptionComponent)
				if isinstance(comp, RobotDescriptionComponent):
					return comp
		get_comp = getattr(value, "get_component", None)
		if callable(get_comp):
			comp = get_comp(RobotDescriptionComponent)
			if isinstance(comp, RobotDescriptionComponent):
				return comp
		return None

	def _robot_base_entity(self, rd: RobotDescriptionComponent) -> Optional["Entity"]:
		robot_ent = rd.entity
		if robot_ent is None:
			return None
		root_id = rd.find_link_entity_id(rd.root_link)
		if root_id and robot_ent.scene is not None:
			base = robot_ent.scene.find_by_id(root_id)
			if base is not None:
				return base
		return robot_ent

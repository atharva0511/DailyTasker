from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QToolBar, QWidget

from MotionStudio.ui.theme import play_ribbon_stylesheet

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene
	from MotionStudio.ui.widgets.component_reference_widget import ComponentReferenceWidget


class PlayModeRibbon(QWidget):
	"""Top Play / Stop strip. Play runs the Sequencer; Pause is unused."""

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._on_play_clicked: Optional[Callable[[], None]] = None
		self._on_stop_clicked: Optional[Callable[[], None]] = None
		self._on_pause_clicked: Optional[Callable[[], None]] = None
		self._on_resume_clicked: Optional[Callable[[], None]] = None
		self._ribbon_mode = "default"
		self._is_playing = False
		self._is_paused = False
		self._routine_running = False
		self._scene: Optional["Scene"] = None
		self._primary_robot_picker: Optional["ComponentReferenceWidget"] = None

		layout = QHBoxLayout(self)
		layout.setContentsMargins(8, 6, 8, 6)
		layout.setSpacing(8)
		self._hbox = layout

		self._status_label = QLabel("Idle", self)
		self._status_label.setObjectName("play_sequence_status")
		self._status_label.setAlignment(
			Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
		)
		self._status_label.setSizePolicy(
			QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
		)
		self._status_label.setMinimumWidth(160)
		self._status_label.setToolTip("Sequencer run status")
		layout.addWidget(self._status_label, 1)

		self._play_button = QPushButton("▶ Play", self)
		self._play_button.setObjectName("play_button")
		self._play_button.setToolTip("Run the current Sequencer Main Sequence")
		self._play_button.clicked.connect(self._on_play_button_clicked)
		layout.addWidget(self._play_button)

		self._pause_button = QPushButton("⏸ Pause", self)
		self._pause_button.setObjectName("pause_button")
		self._pause_button.setEnabled(False)
		self._pause_button.setToolTip(
			"Pause is not used for sequences. Stop runs the Stop Sequence after interrupting Main."
		)
		self._pause_button.clicked.connect(self._on_pause_button_clicked)
		layout.addWidget(self._pause_button)

		self._stop_button = QPushButton("⏹ Stop", self)
		self._stop_button.setObjectName("stop_button")
		self._stop_button.setEnabled(False)
		self._stop_button.setToolTip(
			"Interrupt the Main Sequence, then run this file's Stop Sequence. Stop again aborts."
		)
		self._stop_button.clicked.connect(self._on_stop_button_clicked)
		layout.addWidget(self._stop_button)

		layout.addStretch(1)

		self._primary_robot_label = QLabel("Primary Robot", self)
		self._primary_robot_label.setToolTip(
			"Robot used by Inspector TCP buttons. Live TCP origin is written in "
			"this hardware robot's base frame (mm)."
		)
		layout.addWidget(self._primary_robot_label)

		self.apply_theme_stylesheet()

	def bind_primary_robot(self, scene: "Scene") -> None:
		"""Compact Robot picker on the right of the Sequencer strip (no undo)."""
		from MotionStudio.core.components.robot import Robot
		from MotionStudio.ui.widgets.component_reference_widget import ComponentReferenceWidget

		if self._primary_robot_picker is not None:
			return
		self._scene = scene
		picker = ComponentReferenceWidget(
			Robot,
			scene,
			scene.primary_robot_id,
			on_entity_selected=self._on_primary_robot_selected,
			selection=scene.selection,
			parent=self,
			show_type_label=False,
		)
		picker.setMaximumWidth(240)
		picker.setToolTip(self._primary_robot_label.toolTip())
		self._primary_robot_picker = picker
		self._hbox.addWidget(picker)
		try:
			scene.events.entity_removed.connect(self._refresh_primary_robot)
			scene.events.entity_changed.connect(self._refresh_primary_robot)
			scene.events.primary_robot_changed.connect(self._refresh_primary_robot)
		except Exception:
			pass

	def _on_primary_robot_selected(self, entity_id: Optional[str]) -> None:
		if self._scene is None:
			return
		self._scene.set_primary_robot_id(entity_id)

	def _refresh_primary_robot(self, *_args) -> None:
		if self._primary_robot_picker is None or self._scene is None:
			return
		self._primary_robot_picker.set_current_entity_id(
			self._scene.primary_robot_id, notify=False
		)

	def set_play_callbacks(
		self,
		on_play: Callable[[], None],
		on_stop: Callable[[], None],
		on_pause: Optional[Callable[[], None]] = None,
		on_resume: Optional[Callable[[], None]] = None,
	) -> None:
		"""Set callbacks for Play, Stop, Pause, and Resume button clicks."""
		self._on_play_clicked = on_play
		self._on_stop_clicked = on_stop
		self._on_pause_clicked = on_pause
		self._on_resume_clicked = on_resume

	def apply_theme_stylesheet(self) -> None:
		"""Re-apply ribbon QSS for the current UI theme and play state."""
		stylesheet = play_ribbon_stylesheet(self._ribbon_mode)
		self.setStyleSheet(stylesheet)
		parent = self.parent()
		if isinstance(parent, QToolBar):
			parent.setStyleSheet(stylesheet)
		self.update()
		if isinstance(parent, QToolBar):
			parent.update()

	def set_play_mode(self, is_playing: bool, is_paused: bool = False) -> None:
		"""Green chrome while the Sequencer is running. Pause is ignored."""
		self._is_playing = bool(is_playing)
		self._is_paused = bool(is_paused)
		self._apply_ribbon_state()

	def set_routine_running(self, running: bool) -> None:
		"""Blue ribbon while an edit-mode play routine runs and no sequence is playing."""
		self._routine_running = bool(running)
		self._apply_ribbon_state()

	def set_sequence_run(self, name: str, phase: str = "") -> None:
		"""Update the left status: Idle, running, or stopping a named sequence."""
		kind = str(phase or "").strip().lower()
		seq = str(name or "").strip()
		if kind == "stop" and seq:
			text = f"Stopping {seq} sequence"
		elif kind in ("main", "running") and seq:
			text = f"Running {seq} sequence"
		elif kind and seq:
			text = f"Running {seq} sequence"
		else:
			text = "Idle"
		self._status_label.setText(text)
		self._status_label.setToolTip(text)

	def _apply_ribbon_state(self) -> None:
		self._pause_button.setEnabled(False)
		self._pause_button.setText("⏸ Pause")

		# Sequencer owns the ribbon: Stop stays enabled even if a play routine
		# (Simulate / Lift / Generate) is the in-flight sequence step.
		if self._is_playing:
			self._play_button.setEnabled(False)
			self._stop_button.setEnabled(True)
			self._ribbon_mode = "active"
			self.apply_theme_stylesheet()
			return

		if self._routine_running:
			self._play_button.setEnabled(False)
			self._stop_button.setEnabled(False)
			self._ribbon_mode = "routine"
			self.apply_theme_stylesheet()
			return

		self._play_button.setEnabled(True)
		self._stop_button.setEnabled(False)
		self._ribbon_mode = "default"
		self.apply_theme_stylesheet()

	def _on_play_button_clicked(self) -> None:
		if self._on_play_clicked:
			self._on_play_clicked()

	def _on_stop_button_clicked(self) -> None:
		if self._on_stop_clicked:
			self._on_stop_clicked()

	def _on_pause_button_clicked(self) -> None:
		if self._pause_button.text() == "⏸ Pause":
			if self._on_pause_clicked:
				self._on_pause_clicked()
		else:
			if self._on_resume_clicked:
				self._on_resume_clicked()

"""Sequencer dock widgets."""

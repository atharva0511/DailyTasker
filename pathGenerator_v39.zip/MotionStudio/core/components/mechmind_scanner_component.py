"""Mech-Eye (Mechmind) area-scan 3D camera component.

Connect and capture run on a dedicated QThread that owns the SDK Camera.
Capture writes ``<project>/temp/scan.ply`` and points the referenced
``PointCloudComponent.file_path`` at that file.
"""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any, Dict, Optional, Tuple, TYPE_CHECKING

from PyQt6.QtCore import QMutex, QMutexLocker, QObject, QThread, QWaitCondition, pyqtSignal
from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.hardwares.hardware_runtime import HardwareJobHub
from MotionStudio.core.hardwares.mechmind_scanner_sdk import (
	MechmindSdkError,
	capture_to_ply,
	connect_camera,
	disconnect_camera,
	merge_camera_ply_into_world_scan,
	sdk_available,
	sdk_missing_message,
)
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.scanner import Scanner
from MotionStudio.core.ecs.component import register_component
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	world_matrix,
	world_position,
	world_rotation_quat,
)
from MotionStudio.ui.inspector.metadata import (
	ConnectionStatus,
	Order,
	Range,
	Tooltip,
	inspector_button,
)

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


SCAN_REL_PATH = "temp/scan.ply"
SCAN_STAGING_NAME = "scan_capture.tmp.ply"
DEFAULT_TIMEOUT_MS = 60000
LEGACY_CONNECT_ONLY_TIMEOUT_MS = 10000
SESSION_DROPPED_HINT = "Camera session dropped."
TIMEOUT_RECOVERY_HINT = "If Connect still times out, power-cycle the scanner."

STATUS_DISCONNECTED = "Disconnected"
STATUS_CONNECTING = "Connecting…"
STATUS_CONNECTED = "Connected"
STATUS_CAPTURING = "Capturing…"
STATUS_DISCONNECTING = "Disconnecting…"


def _matrix16_row_major(m) -> Tuple[float, ...]:
	return tuple(float(m[r, c]) for r in range(4) for c in range(4))


def _session_dropped_message(exc: BaseException) -> str:
	text = str(exc).strip() or "Capture failed."
	lower = text.lower()
	if SESSION_DROPPED_HINT.lower() not in lower:
		text = f"{text} {SESSION_DROPPED_HINT}"
	if ("timed out" in lower or "timeout" in lower) and TIMEOUT_RECOVERY_HINT not in text:
		text = f"{text} {TIMEOUT_RECOVERY_HINT}"
	return text


class _ScannerJob:
	__slots__ = (
		"kind",
		"ip_address",
		"timeout_ms",
		"capture_color",
		"ply_path",
		"append",
		"world_matrix",
	)

	def __init__(
		self,
		kind: str,
		*,
		ip_address: str = "",
		timeout_ms: int = DEFAULT_TIMEOUT_MS,
		capture_color: bool = True,
		ply_path: str = "",
		append: bool = False,
		world_matrix: Tuple[float, ...] = (),
	) -> None:
		self.kind = kind
		self.ip_address = ip_address
		self.timeout_ms = timeout_ms
		self.capture_color = capture_color
		self.ply_path = ply_path
		self.append = append
		self.world_matrix = world_matrix


class _MechmindScannerWorker(QThread):
	"""Owns the Mech-Eye Camera; processes connect / disconnect / capture jobs."""

	job_succeeded = pyqtSignal(str, str)  # kind, message
	job_failed = pyqtSignal(str, str)  # kind, error

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		self._pending: Optional[_ScannerJob] = None
		self._stop = False
		self._camera: Any = None

	def submit(self, job: _ScannerJob) -> None:
		with QMutexLocker(self._mutex):
			self._pending = job
			self._wait.wakeOne()

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._pending = None
			self._wait.wakeOne()
		self.wait(8000)

	def run(self) -> None:
		while True:
			with QMutexLocker(self._mutex):
				while self._pending is None and not self._stop:
					self._wait.wait(self._mutex)
				if self._stop:
					break
				job = self._pending
				self._pending = None
			if job is None:
				continue
			self._run_job(job)
		self._drop_camera(ignore_errors=True)

	def _drop_camera(self, *, ignore_errors: bool = True) -> None:
		cam = self._camera
		self._camera = None
		if cam is None:
			return
		try:
			disconnect_camera(cam)
		except Exception:
			if not ignore_errors:
				raise

	def _run_job(self, job: _ScannerJob) -> None:
		kind = job.kind
		try:
			if kind == "connect":
				self._drop_camera(ignore_errors=True)
				self._camera = connect_camera(job.ip_address, job.timeout_ms)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			elif kind == "disconnect":
				self._drop_camera(ignore_errors=False)
				self.job_succeeded.emit(kind, STATUS_DISCONNECTED)
			elif kind == "capture":
				if self._camera is None:
					raise MechmindSdkError("Camera is not connected.")
				self._run_capture(job)
				self.job_succeeded.emit(kind, STATUS_CONNECTED)
			else:
				raise MechmindSdkError(f"Unknown job: {kind}")
		except MechmindSdkError as exc:
			self.job_failed.emit(kind, str(exc))
		except Exception as exc:
			self.job_failed.emit(kind, str(exc))

	def _run_capture(self, job: _ScannerJob) -> None:
		dest = Path(job.ply_path)
		if job.append:
			staging = dest.with_name(SCAN_STAGING_NAME)
			try:
				self._capture_frame(job, str(staging))
				merge_camera_ply_into_world_scan(
					str(staging),
					str(dest),
					job.world_matrix,
				)
			finally:
				try:
					staging.unlink(missing_ok=True)
				except Exception:
					pass
		else:
			self._capture_frame(job, str(dest))

	def _capture_frame(self, job: _ScannerJob, path: str) -> None:
		try:
			capture_to_ply(
				self._camera,
				path,
				job.capture_color,
				job.timeout_ms,
			)
		except Exception as exc:
			self._drop_camera(ignore_errors=True)
			raise MechmindSdkError(_session_dropped_message(exc)) from exc


class _ScannerWorkerHost(QObject):
	"""Main-thread owner of the worker thread (signals must land here)."""

	def __init__(self, component: "MechmindScannerComponent") -> None:
		super().__init__()
		self._component = component
		self._stopped = False
		self.worker = _MechmindScannerWorker()
		self.worker.job_succeeded.connect(self._on_ok)
		self.worker.job_failed.connect(self._on_fail)
		self.worker.start()

	def _on_ok(self, kind: str, message: str) -> None:
		self._component._on_worker_ok(kind, message)

	def _on_fail(self, kind: str, error: str) -> None:
		self._component._on_worker_fail(kind, error)

	def shutdown(self) -> None:
		if self._stopped:
			return
		self._stopped = True
		try:
			self.worker.job_succeeded.disconnect(self._on_ok)
			self.worker.job_failed.disconnect(self._on_fail)
		except Exception:
			pass
		self.worker.stop()


@register_component
class MechmindScannerComponent(Scanner):
	type_name = "MechmindScanner"
	category = "Hardware/Scanners"
	description = (
		"<p><b>Mechmind Scanner</b></p>"
		"<p>Connects to a Mech-Eye (Mechmind) area-scan 3D camera and dumps a captured "
		"point cloud onto a referenced <b>PointCloud</b> component.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Install Mech-Eye SDK.</li>"
		"<li>Set the camera <b>IP address</b> and <b>timeout_ms</b> (Connect and Capture; "
		"60 s default — 10 s is too short for 3D), then click <b>Connect</b>.</li>"
		"<li>Assign <b>Target</b> to an entity that has a PointCloud component.</li>"
		"<li>This scanner entity is the CAD housing. Create a child <b>Camera Frame</b> "
		"(+X right, +Y down, +Z optical axis) and assign it — Capture projects "
		"points with that transform, not the mesh origin.</li>"
		"<li>With <b>append_scan</b> on (default), each Capture transforms points into world space and "
		"appends them to <code>temp/scan.ply</code>; the Target entity is snapped to the world origin.</li>"
		"<li>With <b>append_scan</b> off, Capture overwrites the PLY in camera frame and snaps Target to "
		"<b>Camera Frame</b>.</li>"
		"<li><b>Clear Scan</b> deletes <code>temp/scan.ply</code> and clears the Target cloud.</li>"
		"</ul>"
	)

	ip_address: Annotated[
		str,
		Order(0),
		Tooltip("IPv4 address of the Mech-Eye camera (same subnet as this PC)."),
	]
	timeout_ms: Annotated[
		int,
		Order(10),
		Range(1000, 180000, step=1000),
		Tooltip(
			"Timeout in milliseconds for Connect and Capture. 3D capture often "
			"needs 30–60 s (SDK default is 5–10 s and will time out after the "
			"projector fires)."
		),
	]
	capture_color: Annotated[
		bool,
		Order(20),
		Tooltip("When true, capture a textured (RGB) point cloud; otherwise XYZ only."),
	]
	append_scan: Annotated[
		bool,
		Order(25),
		Tooltip(
			"When true, each Capture appends world-space points onto temp/scan.ply "
			"(move the scanner between captures). When false, overwrite with a single "
			"camera-frame scan."
		),
	]
	connection_status: Annotated[
		str,
		ConnectionStatus(
			busy=(STATUS_CONNECTING, STATUS_CAPTURING, STATUS_DISCONNECTING),
		),
		Order(30),
		Tooltip("Live connection state. Not restored from the scene file."),
	]
	camera_frame: Annotated[
		Optional[TransformComponent],
		Order(35),
		Tooltip(
			"Optical camera frame (child of this CAD scanner). Capture projects "
			"Mech-Eye points with this world pose (+X right, +Y down, +Z optical axis). "
			"Required for Capture."
		),
	]
	target: Annotated[
		Optional[PointCloudComponent],
		Order(40),
		Tooltip(
			"PointCloud that receives temp/scan.ply. Append mode snaps it to the world "
			"origin; overwrite mode snaps it to Camera Frame."
		),
	]

	def __init__(
		self,
		ip_address: str = "192.168.1.100",
		timeout_ms: int = DEFAULT_TIMEOUT_MS,
		capture_color: bool = True,
		append_scan: bool = True,
	) -> None:
		self.ip_address = str(ip_address or "192.168.1.100")
		try:
			self.timeout_ms = int(timeout_ms)
		except Exception:
			self.timeout_ms = DEFAULT_TIMEOUT_MS
		self.capture_color = bool(capture_color)
		self.append_scan = bool(append_scan)
		self.connection_status = STATUS_DISCONNECTED
		self.camera_frame = None
		self.target = None
		self._busy = False
		self._host: Optional[_ScannerWorkerHost] = None
		self._bound_scene: Optional["Scene"] = None
		self._hw_session_key: Optional[str] = None
		self._was_connected = False
		self._pending_capture_append = False
		self._job_hub = HardwareJobHub()

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "MechmindScannerComponent":
		inst = super().from_dict(data)
		# May load locked; force so status reset is not blocked.
		inst.force_setattr("connection_status", STATUS_DISCONNECTED)
		# Older scenes stored 10s as a connect-only timeout; that is too short
		# for capture_2d_and_3d (SDK default 5–10 s times out after the flash).
		try:
			if int(getattr(inst, "timeout_ms", 0) or 0) == LEGACY_CONNECT_ONLY_TIMEOUT_MS:
				inst.force_setattr("timeout_ms", DEFAULT_TIMEOUT_MS)
		except Exception:
			pass
		return inst

	def add_job_listener(self, callback) -> None:
		self._job_hub.add(callback)

	def remove_job_listener(self, callback) -> None:
		self._job_hub.remove(callback)

	@inspector_button("Connect", tooltip="Connect to the camera at IP address (background thread)", order=100)
	def connect_scanner(self):
		if self._busy:
			return False, "scanner is busy"
		if not sdk_available():
			self.connection_status = f"Error: {sdk_missing_message()}"
			return False, self.connection_status
		self._bind_scene()
		self._busy = True
		self.connection_status = STATUS_CONNECTING
		self._ensure_host().worker.submit(
			_ScannerJob(
				"connect",
				ip_address=str(self.ip_address or "").strip(),
				timeout_ms=int(self.timeout_ms),
			)
		)
		return True

	@inspector_button("Disconnect", tooltip="Disconnect from the camera", order=110)
	def disconnect_scanner(self):
		if self._busy:
			return False, "scanner is busy"
		if self._host is None:
			self.connection_status = STATUS_DISCONNECTED
			self._was_connected = False
			return None
		self._busy = True
		self.connection_status = STATUS_DISCONNECTING
		self._host.worker.submit(_ScannerJob("disconnect"))
		return True

	@inspector_button("Capture", tooltip="Capture to temp/scan.ply (append or overwrite) and update Target", order=120)
	def capture_scan(self):
		if self._busy:
			return False, "scanner is busy"
		if not self._was_connected:
			self.connection_status = "Error: Camera is not connected."
			return False, self.connection_status
		target = self._resolve_target()
		if target is None:
			self.connection_status = "Error: Assign a PointCloud Target first."
			return False, self.connection_status
		frame_ent = self.capture_pose_entity()
		if frame_ent is None:
			self.connection_status = "Error: Assign Camera Frame (optical transform)."
			return False, self.connection_status
		root = self._project_root()
		if root is None:
			self.connection_status = "Error: No project folder is open."
			return False, self.connection_status
		if self.entity is None:
			self.connection_status = "Error: Scanner entity is missing."
			return False, self.connection_status
		try:
			abs_path = self._prepare_scan_path(root)
		except Exception as exc:
			self.connection_status = f"Error: Could not create temp folder ({exc})"
			return False, self.connection_status
		append = bool(self.append_scan)
		mat16: Tuple[float, ...] = ()
		if append:
			mat16 = _matrix16_row_major(world_matrix(frame_ent))
		self._bind_scene()
		self._busy = True
		self._pending_capture_append = append
		self.connection_status = STATUS_CAPTURING
		self._ensure_host().worker.submit(
			_ScannerJob(
				"capture",
				timeout_ms=int(self.timeout_ms),
				capture_color=bool(self.capture_color),
				ply_path=abs_path,
				append=append,
				world_matrix=mat16,
			)
		)
		return True

	@inspector_button(
		"Clear Scan",
		tooltip="Delete temp/scan.ply and clear the Target PointCloud",
		order=130,
	)
	def clear_scan(self):
		if self._busy:
			return False, "scanner is busy"
		root = self._project_root()
		if root is None:
			self.connection_status = "Error: No project folder is open."
			return False, self.connection_status
		temp_dir = Path(root) / "temp"
		for name in ("scan.ply", SCAN_STAGING_NAME):
			path = temp_dir / name
			try:
				path.unlink(missing_ok=True)
			except Exception as exc:
				self.connection_status = f"Error: Could not delete {name} ({exc})"
				return False, self.connection_status
		target = self._resolve_target()
		if target is not None:
			# Drop the actor; empty/missing PLY would fail to load.
			if str(getattr(target, "file_path", "") or "") != "":
				target.file_path = ""
			entity = getattr(target, "entity", None)
			if entity is not None and entity.scene is not None:
				entity.scene.events.entity_changed.emit(entity.id)
		return None

	# ------------------------------------------------------------------ worker callbacks (main thread)

	def _on_worker_ok(self, kind: str, message: str) -> None:
		self._busy = False
		if kind == "connect":
			self._was_connected = True
			self.connection_status = message or STATUS_CONNECTED
			self._job_hub.notify(kind, True, self.connection_status)
		elif kind == "disconnect":
			self._was_connected = False
			self.connection_status = STATUS_DISCONNECTED
			self._job_hub.notify(kind, True, self.connection_status)
		elif kind == "capture":
			self._was_connected = True
			try:
				self._apply_scan_to_target()
				self.connection_status = STATUS_CONNECTED
				self._job_hub.notify(kind, True, self.connection_status)
			except Exception as exc:
				self.connection_status = f"Error: Saved scan but could not update PointCloud ({exc})"
				self._job_hub.notify(kind, False, self.connection_status)
		else:
			self._job_hub.notify(kind, True, message or "")

	def _on_worker_fail(self, kind: str, error: str) -> None:
		self._busy = False
		if kind == "connect":
			self._was_connected = False
		elif kind == "disconnect":
			self._was_connected = False
		elif kind == "capture" and SESSION_DROPPED_HINT in str(error or ""):
			self._was_connected = False
		self.connection_status = f"Error: {error}"
		self._job_hub.notify(kind, False, self.connection_status)

	def _apply_scan_to_target(self) -> None:
		target = self._resolve_target()
		if target is None:
			raise RuntimeError("PointCloud Target is missing.")
		if self._pending_capture_append:
			self._align_target_to_world_origin(target)
		else:
			self._align_target_to_camera_frame(target)
		# Mech-Eye / merged PLY is millimetres; default PointCloud scale is 1000 (m→mm).
		if abs(float(getattr(target, "scale", 1.0) or 1.0) - 1.0) > 1e-9:
			target.scale = 1.0
		# Textured captures need vertex colors enabled on the Target actor.
		if bool(self.capture_color) and not bool(getattr(target, "use_vertex_colors", True)):
			target.use_vertex_colors = True
		rel = SCAN_REL_PATH
		# Same path + overwritten/appended file would skip VTK reload (fingerprint match).
		if str(getattr(target, "file_path", "") or "") == rel:
			target.file_path = ""
		target.file_path = rel
		entity = getattr(target, "entity", None)
		if entity is not None and entity.scene is not None:
			entity.scene.events.entity_changed.emit(entity.id)

	def _align_target_to_camera_frame(self, target: PointCloudComponent) -> None:
		"""Pose the cloud entity so camera-frame PLY points sit on Camera Frame."""
		frame_entity = self.capture_pose_entity()
		cloud_entity = getattr(target, "entity", None)
		if frame_entity is None or cloud_entity is None:
			return
		if cloud_entity is frame_entity:
			return
		xf = cloud_entity.get_component(TransformComponent)
		if xf is not None:
			xf.scale3d = QVector3D(1.0, 1.0, 1.0)
		set_world_rotation_quat(cloud_entity, world_rotation_quat(frame_entity))
		set_world_position(cloud_entity, world_position(frame_entity))

	def _align_target_to_world_origin(self, target: PointCloudComponent) -> None:
		"""Pose the cloud entity at identity so world-space appended points line up."""
		cloud_entity = getattr(target, "entity", None)
		if cloud_entity is None:
			return
		xf = cloud_entity.get_component(TransformComponent)
		if xf is not None:
			xf.scale3d = QVector3D(1.0, 1.0, 1.0)
		set_world_rotation_quat(cloud_entity, QQuaternion())
		set_world_position(cloud_entity, QVector3D(0.0, 0.0, 0.0))

	# ------------------------------------------------------------------ internals

	def _ensure_host(self) -> _ScannerWorkerHost:
		if self._host is None:
			self._host = _ScannerWorkerHost(self)
			self._register_hardware_session()
		return self._host

	def _session_key(self) -> str:
		entity = self.entity
		eid = entity.id if entity is not None else "unbound"
		return f"{eid}:{self.type_name}"

	def _register_hardware_session(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is None or self._host is None:
			return
		key = self._session_key()
		self._hw_session_key = key
		scene.hardware_runtime.register(key, self._host)

	def _unregister_hardware_session(self) -> None:
		key = self._hw_session_key
		self._hw_session_key = None
		scene = self._bound_scene
		entity = self.entity
		if entity is not None and entity.scene is not None:
			scene = entity.scene
		if scene is None or not key:
			return
		scene.hardware_runtime.unregister(key)

	def _shutdown_host(self) -> None:
		self._unregister_hardware_session()
		host = self._host
		self._host = None
		self._busy = False
		self._was_connected = False
		if host is not None:
			try:
				host.shutdown()
			except Exception:
				pass

	def _bind_scene(self) -> None:
		entity = self.entity
		scene = entity.scene if entity is not None else None
		if scene is self._bound_scene:
			return
		self._unbind_scene()
		if scene is None:
			return
		try:
			scene.events.entity_removed.connect(self._on_entity_removed)
			scene.events.entity_changed.connect(self._on_owning_entity_changed)
		except Exception:
			return
		self._bound_scene = scene

	def _unbind_scene(self) -> None:
		scene = self._bound_scene
		self._bound_scene = None
		if scene is None:
			return
		try:
			scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		try:
			scene.events.entity_changed.disconnect(self._on_owning_entity_changed)
		except Exception:
			pass

	def _on_entity_removed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None or entity.id != entity_id:
			return
		self._teardown()

	def _on_owning_entity_changed(self, entity_id: str) -> None:
		entity = self.entity
		if entity is None:
			self._teardown()
			return
		if entity.id != entity_id:
			return
		if self not in getattr(entity, "components", []):
			self._teardown()

	def _teardown(self) -> None:
		self._unbind_scene()
		self._shutdown_host()
		self.connection_status = STATUS_DISCONNECTED

	def _resolve_target(self) -> Optional[PointCloudComponent]:
		value = self.target
		if isinstance(value, PointCloudComponent):
			return value
		if isinstance(value, str):
			entity = self.entity
			scene = entity.scene if entity is not None else None
			if scene is None:
				return None
			found = scene.find_by_id(value)
			if found is None:
				return None
			comp = found.get_component(PointCloudComponent)
			if comp is not None:
				self.target = comp
			return comp
		return None

	def _resolved_camera_frame(self) -> Optional[TransformComponent]:
		value = self.camera_frame
		if isinstance(value, TransformComponent):
			return value
		if isinstance(value, str):
			entity = self.entity
			scene = entity.scene if entity is not None else None
			if scene is None:
				return None
			found = scene.find_by_id(value)
			if found is None:
				return None
			comp = found.get_component(TransformComponent)
			if comp is not None:
				self.camera_frame = comp
			return comp
		return None

	def capture_pose_entity(self) -> Optional["Entity"]:
		"""Entity whose world pose is the Mech-Eye optical frame, or None."""
		xf = self._resolved_camera_frame()
		if xf is None:
			return None
		ent = getattr(xf, "entity", None)
		if ent is None:
			return None
		if ent.get_component(TransformComponent) is None:
			return None
		return ent

	def _project_root(self) -> Optional[Path]:
		entity = self.entity
		if entity is None or entity.scene is None:
			return None
		root = entity.scene.project_root
		if root is None:
			return None
		return Path(root)

	@staticmethod
	def _prepare_scan_path(project_root: Path) -> str:
		temp_dir = project_root / "temp"
		temp_dir.mkdir(parents=True, exist_ok=True)
		return str((temp_dir / "scan.ply").resolve())

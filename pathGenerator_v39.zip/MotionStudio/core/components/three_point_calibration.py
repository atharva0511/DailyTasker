"""
Three-point calibration component.

The user picks three vertices on the entity's mesh ("model points", stored in
the entity's local frame via :class:`VertexPick`), then types in the three
corresponding **robot / physical** coordinates. The ``Align`` button computes
the least-squares rigid transformation (rotation + translation, preserving
scale) that best maps the model points to the robot points and re-poses the
entity so the model points sit on top of the robot points.

This is the classic 3-point part-to-robot calibration used in robotic
machining/inspection workflows.

Algorithm
---------

For the three model points :math:`P_i` (entity-local) and three robot points
:math:`Q_i` (in the optional **Robot Frame**, or world if that field is empty)
we want the *new* entity world matrix
:math:`M_{new}` such that :math:`M_{new} P_i \\approx Q_i^{world}` for ``i = 1..3``.

``Q_i^{world}`` is ``transform_point(robot_frame, Q_i)`` when a Robot Frame is
assigned, otherwise ``Q_i`` itself (scene origin / global frame).

We express the new transform as a delta applied on top of the current world
transform :math:`M_{cur}`:

.. math:: M_{new} = D \\cdot M_{cur}

Working in world space:

1. Compute the current world positions of the model points:
   :math:`p_i = M_{cur} P_i` (using :func:`transform_point`).
2. Solve Kabsch / Umeyama between :math:`(p_i, Q_i)` for the rigid delta
   :math:`D = (R_\\Delta, t_\\Delta)` minimising :math:`\\sum \\lVert R_\\Delta p_i + t_\\Delta - Q_i \\rVert^2`.
3. New world rotation: :math:`R_\\Delta \\cdot R_{cur}`. New world position:
   :math:`R_\\Delta \\cdot \\mathrm{pos}_{cur} + t_\\Delta`.
4. Push via :func:`set_world_rotation_quat` and :func:`set_world_position` —
   these route through the public :class:`TransformComponent` properties, so
   the viewport and any other listeners refresh automatically and the
   entity's existing scale is preserved.
"""

from __future__ import annotations

from typing import Annotated, List, Optional

from PyQt6.QtGui import QColor, QVector3D

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.transform.rigid import kabsch_rigid as _kabsch_rigid, matrix_to_quaternion as _matrix_to_quaternion
from MotionStudio.core.transform.utils import (
	set_world_position,
	set_world_rotation_quat,
	transform_point,
	world_position,
	world_rotation_quat,
)
from MotionStudio.ui.inspector.metadata import (
	Group,
	Header,
	Tooltip,
	VertexPick,
	inspector_button,
)


@register_component
class ThreePointCalibrationComponent(Component):
	type_name = "ThreePointCalibration"
	category = "Alignment and datum"
	description = (
		"<p><b>Three-Point Calibration</b></p>"
		"<p>Part-to-robot alignment: pick three vertices on this model, type the three "
		"matching coordinates in the Robot Frame (or world if that field is empty), then "
		"compute a rigid transform (rotation + translation, scale preserved) that maps "
		"the model onto those measurements.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Optionally assign <b>Robot Frame</b> to the transform the measured points "
		"are expressed in (for example the robot base). Leave empty for the scene origin.</li>"
		"<li>Click <b>Pick</b> for Model A / B / C and click three distinct mesh vertices.</li>"
		"<li>Enter the corresponding physical positions in <b>robot_a</b> / <b>robot_b</b> / <b>robot_c</b>.</li>"
		"<li>Click <b>Align</b>. Markers for P1&ndash;P3 appear in the viewport while this entity is selected.</li>"
		"<li>Points must not be coincident or colinear. <b>Clear</b> resets all six vectors to zero.</li>"
		"</ul>"
	)

	model_a: Annotated[QVector3D, Group('Configure'),VertexPick(), Header("Model points (pick a mesh vertex)"), Tooltip("Pick the first reference vertex on the model")]
	model_b: Annotated[QVector3D, Group('Configure'),VertexPick(), Tooltip("Pick the second reference vertex on the model")]
	model_c: Annotated[QVector3D, Group('Configure'),VertexPick(), Tooltip("Pick the third reference vertex on the model")]

	robot_frame: Annotated[
		Optional[TransformComponent],
		Group('Configure'),
		Header("Robot coordinates"),
		Tooltip(
			"Frame the robot coordinates are expressed in (entity picker). "
			"Leave empty to treat robot_a / robot_b / robot_c as scene-origin (world) points."
		),
	] = None
	robot_a: Annotated[QVector3D, Group('Configure'), Tooltip("First measured point in the Robot Frame (or world if Robot Frame is empty)")]
	robot_b: Annotated[QVector3D, Group('Configure'), Tooltip("Second measured point in the Robot Frame (or world if Robot Frame is empty)")]
	robot_c: Annotated[QVector3D, Group('Configure'), Tooltip("Third measured point in the Robot Frame (or world if Robot Frame is empty)")]

	def __init__(self) -> None:
		self.model_a = QVector3D()
		self.model_b = QVector3D()
		self.model_c = QVector3D()
		self.robot_frame = None
		self.robot_a = QVector3D()
		self.robot_b = QVector3D()
		self.robot_c = QVector3D()

	# ------------------------------------------------------------------
	# Inspector actions
	# ------------------------------------------------------------------

	def on_viewport_draw(self) -> None:
		selection = self.entity.scene.selection
		if selection is None:
			return
		if selection.current is not self.entity:
			return
		
		model_a_world = transform_point(self.entity, self.model_a)
		model_b_world = transform_point(self.entity, self.model_b)
		model_c_world = transform_point(self.entity, self.model_c)
		Debug.draw_point(model_a_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9, on_top=False)
		Debug.draw_point(model_b_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9, on_top=False)
		Debug.draw_point(model_c_world, size=10.0, screen_space=True, color=QColor(255, 255, 0), opacity=0.9, on_top=False)
		Debug.draw_label(model_a_world + QVector3D(0, 0.12, 0), "P1", color=QColor(255, 200, 200), font_size=14)
		Debug.draw_label(model_b_world + QVector3D(0, 0.12, 0), "P2", color=QColor(255, 200, 200), font_size=14)
		Debug.draw_label(model_c_world + QVector3D(0, 0.12, 0), "P3", color=QColor(255, 200, 200), font_size=14)

	@inspector_button(
		"Align",
		tooltip="Compute the least-squares rigid transform mapping the 3 model "
		"points onto the 3 robot points (in Robot Frame, or world) and apply it",
		order=0,
	)
	def align(self):
		if self.entity is None:
			print("ThreePointCalibration: no entity attached.", flush=True)
			return False, "no entity attached"
		if self.entity.get_component(TransformComponent) is None:
			print("ThreePointCalibration: entity has no TransformComponent.", flush=True)
			return False, "entity has no TransformComponent"

		model_pts_local = [self.model_a, self.model_b, self.model_c]
		robot_pts_frame = [self.robot_a, self.robot_b, self.robot_c]

		if not self._validate_inputs(model_pts_local, robot_pts_frame):
			return False, "two model or robot points coincide"

		# Step 1: bring the model points into the entity's *current* world frame.
		model_world = [transform_point(self.entity, p) for p in model_pts_local]
		# Robot measurements are in Robot Frame (or world if that field is empty).
		robot_pts_world = self._robot_points_in_world(robot_pts_frame)

		# Step 2: rigid Kabsch in world space.
		ok, R, t, rmse = _kabsch_rigid(model_world, robot_pts_world)
		if not ok:
			print(
				"ThreePointCalibration: degenerate input (points colinear or coincident); cannot solve.",
				flush=True,
			)
			return False, "degenerate input (points colinear or coincident)"

		# Step 3: compose the delta with the current world pose.
		R_delta = _matrix_to_quaternion(R)
		t_delta = QVector3D(float(t[0]), float(t[1]), float(t[2]))

		cur_pos = world_position(self.entity)
		cur_rot = world_rotation_quat(self.entity)
		new_pos = R_delta.rotatedVector(cur_pos) + t_delta
		new_rot = (R_delta * cur_rot).normalized()

		# Step 4: write back (scale preserved by these setters).
		set_world_rotation_quat(self.entity, new_rot)
		set_world_position(self.entity, new_pos)

		print(
			f"ThreePointCalibration: aligned '{self.entity.name}' "
			f"(RMSE = {rmse:.6g} world units).",
			flush=True,
		)
		return None

	def _robot_points_in_world(self, pts: List[QVector3D]) -> List[QVector3D]:
		"""Map robot-frame (or world) measurements into scene world coordinates."""
		frame = self.robot_frame
		if frame is None or not isinstance(frame, TransformComponent):
			return list(pts)
		frame_ent = frame.entity
		if frame_ent is None:
			print(
				"ThreePointCalibration: Robot Frame has no entity; using scene origin.",
				flush=True,
			)
			return list(pts)
		return [transform_point(frame_ent, p) for p in pts]

	@inspector_button(
		"Clear",
		group='Configure',
		tooltip="Reset model and robot coordinates to zero",
		order=1,
	)
	def clear(self) -> None:
		self.model_a = QVector3D()
		self.model_b = QVector3D()
		self.model_c = QVector3D()
		self.robot_a = QVector3D()
		self.robot_b = QVector3D()
		self.robot_c = QVector3D()

	# ------------------------------------------------------------------
	# Validation
	# ------------------------------------------------------------------

	@staticmethod
	def _validate_inputs(model: List[QVector3D], robot: List[QVector3D]) -> bool:
		eps = 1e-9
		# All three model points must be distinct; same for robot points.
		for label, pts in (("model", model), ("robot", robot)):
			if (pts[0] - pts[1]).lengthSquared() < eps or (pts[1] - pts[2]).lengthSquared() < eps or (pts[0] - pts[2]).lengthSquared() < eps:
				print(
					f"ThreePointCalibration: two {label} points coincide; "
					"pick three distinct points and try again.",
					flush=True,
				)
				return False
		return True


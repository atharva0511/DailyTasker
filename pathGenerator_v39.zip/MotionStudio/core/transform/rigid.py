"""Rigid alignment helpers (Kabsch / Umeyama, rotation matrix to quaternion)."""

from __future__ import annotations

from typing import List, Tuple

import numpy as np
from PyQt6.QtGui import QQuaternion, QVector3D


def kabsch_rigid(
	src: List[QVector3D],
	dst: List[QVector3D],
) -> Tuple[bool, np.ndarray, np.ndarray, float]:
	"""Kabsch / Umeyama rigid alignment (no scale).

	Returns ``(ok, R, t, rmse)`` such that ``R @ src_i + t  ≈  dst_i`` minimises
	the sum of squared residuals. ``R`` is a 3×3 rotation (det = +1), ``t`` is a
	length-3 translation. ``ok`` is False if the input is degenerate.
	"""
	if len(src) < 3 or len(src) != len(dst):
		return False, np.eye(3), np.zeros(3), float("inf")
	P = np.array([[p.x(), p.y(), p.z()] for p in src], dtype=np.float64)
	Q = np.array([[q.x(), q.y(), q.z()] for q in dst], dtype=np.float64)
	cp = P.mean(axis=0)
	cq = Q.mean(axis=0)
	Pc = P - cp
	Qc = Q - cq

	if np.linalg.matrix_rank(Pc, tol=1e-8) < 2 or np.linalg.matrix_rank(Qc, tol=1e-8) < 2:
		return False, np.eye(3), np.zeros(3), float("inf")

	H = Pc.T @ Qc
	try:
		U, _S, Vt = np.linalg.svd(H)
	except np.linalg.LinAlgError:
		return False, np.eye(3), np.zeros(3), float("inf")

	d = np.sign(np.linalg.det(Vt.T @ U.T))
	D = np.diag([1.0, 1.0, d if d != 0 else 1.0])
	R = Vt.T @ D @ U.T

	t = cq - R @ cp
	residual = (P @ R.T + t) - Q
	rmse = float(np.sqrt((residual ** 2).sum(axis=1).mean()))
	return True, R, t, rmse


def matrix_to_quaternion(R: np.ndarray) -> QQuaternion:
	"""Convert a 3×3 rotation matrix to a unit :class:`QQuaternion`.

	Uses Shepperd's method (the largest-trace branch) for numerical stability.
	"""
	m00, m01, m02 = float(R[0, 0]), float(R[0, 1]), float(R[0, 2])
	m10, m11, m12 = float(R[1, 0]), float(R[1, 1]), float(R[1, 2])
	m20, m21, m22 = float(R[2, 0]), float(R[2, 1]), float(R[2, 2])
	trace = m00 + m11 + m22
	if trace > 0.0:
		s = 0.5 / float(np.sqrt(trace + 1.0))
		w = 0.25 / s
		x = (m21 - m12) * s
		y = (m02 - m20) * s
		z = (m10 - m01) * s
	elif m00 > m11 and m00 > m22:
		s = 2.0 * float(np.sqrt(1.0 + m00 - m11 - m22))
		w = (m21 - m12) / s
		x = 0.25 * s
		y = (m01 + m10) / s
		z = (m02 + m20) / s
	elif m11 > m22:
		s = 2.0 * float(np.sqrt(1.0 + m11 - m00 - m22))
		w = (m02 - m20) / s
		x = (m01 + m10) / s
		y = 0.25 * s
		z = (m12 + m21) / s
	else:
		s = 2.0 * float(np.sqrt(1.0 + m22 - m00 - m11))
		w = (m10 - m01) / s
		x = (m02 + m20) / s
		y = (m12 + m21) / s
		z = 0.25 * s
	q = QQuaternion(float(w), float(x), float(y), float(z))
	return q.normalized()

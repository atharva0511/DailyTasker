"""Keep worker ``QThread`` objects alive until their thread has fully finished.

Deleting a ``QThread`` whose thread is still running makes Qt call
``qFatal("QThread: Destroyed while thread is still running")``, which
fast-fails the whole process (``0xc0000409`` / ``FAST_FAIL_FATAL_APP_EXIT``,
no Python traceback). Two ways to get there:

- A done signal (``finished``, or a custom one emitted at the end of
  ``run()``) is queued to the GUI thread, and its slot drops the last
  reference while Qt is still finishing the thread.
- An owner gives up on a worker blocked in a native call (``ur_rtde``
  connect, Mech-Eye capture) after a timed-out ``wait()``; the last reference
  then goes away on the worker thread itself when ``run()`` returns.

Call ``release_thread`` before clearing the last reference to a worker, and
``stop_and_retire`` after signalling a worker to stop.
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from PyQt6.QtCore import QThread

_FINISHING_WAIT_MS = 50

_retired: Dict[int, "QThread"] = {}
_labels: Dict[int, str] = {}


def retire_thread(thread: QThread, label: str) -> None:
	"""Hold ``thread`` until it finishes; no-op once it has already stopped."""
	try:
		if not thread.isRunning():
			return
	except RuntimeError:
		return
	key = id(thread)
	if key in _retired:
		return
	_retired[key] = thread
	_labels[key] = label
	print(f"[thread-guard] {label} is still running; kept alive until it exits", flush=True)
	thread.finished.connect(lambda key=key: _release(key))
	if thread.isFinished():
		_release(key)


def _release(key: int) -> None:
	thread = _retired.pop(key, None)
	label = _labels.pop(key, "worker")
	if thread is None:
		return
	try:
		# ``finished`` is queued from the worker; make sure run() has fully returned.
		thread.wait()
		thread.finished.disconnect()
	except (RuntimeError, TypeError):
		pass
	print(f"[thread-guard] {label} exited", flush=True)


def release_thread(thread: Optional[QThread], label: str) -> None:
	"""Call before dropping the last reference to ``thread`` (e.g. in its done slot)."""
	if thread is None:
		return
	try:
		if not thread.isRunning():
			return
		# Done signals arrive just before Qt marks the thread finished.
		if thread.wait(_FINISHING_WAIT_MS):
			return
	except RuntimeError:
		return
	retire_thread(thread, label)


def stop_and_retire(thread: QThread, label: str, timeout_ms: int) -> bool:
	"""Wait up to ``timeout_ms`` for an already-signalled stop, else retire. True if stopped."""
	try:
		if thread.wait(max(0, int(timeout_ms))):
			return True
	except RuntimeError:
		return True
	retire_thread(thread, label)
	return False


def running_retired_threads() -> List[str]:
	"""Labels of retired workers whose native call has still not returned."""
	out = []
	for key, thread in list(_retired.items()):
		try:
			if thread.isRunning():
				out.append(_labels.get(key, "worker"))
		except RuntimeError:
			pass
	return out


def wait_retired_threads(timeout_ms: int) -> bool:
	"""Give retired workers a shared deadline to finish. True if none are still running."""
	deadline = time.monotonic() + max(0, int(timeout_ms)) / 1000.0
	for thread in list(_retired.values()):
		remaining_ms = int((deadline - time.monotonic()) * 1000)
		if remaining_ms <= 0:
			break
		try:
			thread.wait(remaining_ms)
		except RuntimeError:
			pass
	return not running_retired_threads()

"""Keep-first voxel occupancy for overlapping scan appends.

Stored points are never deleted. New points whose voxel is already occupied
are dropped; kept new voxels are marked occupied so intra-frame duplicates
also collapse to one point per voxel.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

MIN_OVERLAP_VOXEL_MM = 0.0
MAX_OVERLAP_VOXEL_MM = 50.0

# Pack signed voxel ijk into one int64. Offset 2^20 covers ±1 km at 1 mm.
_VOXEL_COORD_OFFSET = np.int64(1 << 20)
_VOXEL_COORD_SHIFT = 21
_VOXEL_COORD_MASK = np.int64((1 << 21) - 1)


def clamp_overlap_voxel_mm(voxel_mm: float) -> float:
	"""Clamp occupancy voxel size. ``0`` disables the filter."""
	try:
		value = float(voxel_mm)
	except (TypeError, ValueError):
		return 0.0
	if not np.isfinite(value):
		return 0.0
	return max(MIN_OVERLAP_VOXEL_MM, min(MAX_OVERLAP_VOXEL_MM, value))


def overlap_voxel_is_noop(voxel_mm: float) -> bool:
	"""True when occupancy merge should be skipped (current concat)."""
	return clamp_overlap_voxel_mm(voxel_mm) <= 0.0


def filter_new_points_by_voxel(
	old_pts: Optional[np.ndarray],
	new_pts: np.ndarray,
	new_rgb: Optional[np.ndarray],
	voxel_mm: float,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	"""Keep new XYZ (+ optional RGB) whose voxel is empty in ``old_pts``.

	Old points are not returned and are not modified. First-wins within the
	new frame: later new points that share a newly occupied voxel are dropped.
	``voxel_mm <= 0`` returns the new arrays unchanged.
	"""
	pts = np.asarray(new_pts, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3:
		empty = np.empty((0, 3), dtype=np.float64)
		return empty, _empty_rgb(new_rgb)
	pts = np.ascontiguousarray(pts[:, :3], dtype=np.float64)
	rgb = _aligned_rgb(new_rgb, int(pts.shape[0]))

	size = clamp_overlap_voxel_mm(voxel_mm)
	if size <= 0.0 or pts.shape[0] == 0:
		return pts, rgb

	old = _xyz(old_pts)
	old_keys = (
		np.unique(_voxel_keys(old, size))
		if old.shape[0] > 0
		else np.empty((0,), dtype=np.int64)
	)
	kept_pts, kept_rgb, _union = _filter_against_keys(old_keys, pts, rgb, size)
	return kept_pts, kept_rgb


def filter_new_points_against_keys(
	old_keys: np.ndarray,
	new_pts: np.ndarray,
	new_rgb: Optional[np.ndarray],
	voxel_mm: float,
) -> Tuple[np.ndarray, Optional[np.ndarray], np.ndarray]:
	"""Like :func:`filter_new_points_by_voxel` using already-unique ``old_keys``.

	``old_keys`` is a 1-D int64 array from :func:`_voxel_keys` (sorted unique).
	The third return is the sorted unique union of ``old_keys`` and the voxels
	kept from this frame, for the next append. ``voxel_mm <= 0`` returns the
	new arrays unchanged and ``old_keys`` as the union.
	"""
	pts = np.asarray(new_pts, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3:
		empty = np.empty((0, 3), dtype=np.float64)
		return empty, _empty_rgb(new_rgb), _as_keys(old_keys)
	pts = np.ascontiguousarray(pts[:, :3], dtype=np.float64)
	rgb = _aligned_rgb(new_rgb, int(pts.shape[0]))
	size = clamp_overlap_voxel_mm(voxel_mm)
	keys = _as_keys(old_keys)
	if size <= 0.0 or pts.shape[0] == 0:
		return pts, rgb, keys
	return _filter_against_keys(keys, pts, rgb, size)


class VoxelKeyCache:
	"""Sorted unique occupancy keys for one scan file.

	A hit skips re-quantizing and sorting the accumulated cloud. The cache
	misses when the path, voxel size, or stored point count changes (Clear
	Scan, a different file, or a voxel-size change).
	"""

	def __init__(self) -> None:
		self._path = ""
		self._voxel_mm = 0.0
		self._n_points = -1
		self._keys: Optional[np.ndarray] = None

	def reset(self) -> None:
		self._path = ""
		self._voxel_mm = 0.0
		self._n_points = -1
		self._keys = None

	def keys_for(
		self,
		path: str,
		voxel_mm: float,
		old_pts: Optional[np.ndarray],
	) -> np.ndarray:
		"""Return occupancy keys for ``old_pts``, rebuilding only on a miss."""
		n = 0 if old_pts is None else int(np.asarray(old_pts).shape[0])
		size = clamp_overlap_voxel_mm(voxel_mm)
		path_s = str(path or "")
		if (
			self._keys is not None
			and self._path == path_s
			and self._voxel_mm == size
			and self._n_points == n
		):
			return self._keys
		if n <= 0 or old_pts is None or size <= 0.0:
			keys = np.empty((0,), dtype=np.int64)
		else:
			keys = np.unique(_voxel_keys(_xyz(old_pts), size))
		self._store(path_s, size, n, keys)
		return keys

	def commit(self, path: str, voxel_mm: float, n_points: int, keys: np.ndarray) -> None:
		"""Remember keys after a successful append (point count is the merged cloud)."""
		self._store(
			str(path or ""),
			clamp_overlap_voxel_mm(voxel_mm),
			int(n_points),
			_as_keys(keys),
		)

	def _store(self, path: str, voxel_mm: float, n_points: int, keys: np.ndarray) -> None:
		self._path = path
		self._voxel_mm = float(voxel_mm)
		self._n_points = int(n_points)
		self._keys = keys


def _as_keys(keys: Optional[np.ndarray]) -> np.ndarray:
	if keys is None:
		return np.empty((0,), dtype=np.int64)
	arr = np.asarray(keys, dtype=np.int64).reshape(-1)
	return arr


def _filter_against_keys(
	old_keys: np.ndarray,
	pts: np.ndarray,
	rgb: Optional[np.ndarray],
	voxel_mm: float,
) -> Tuple[np.ndarray, Optional[np.ndarray], np.ndarray]:
	"""Keep first new point per empty voxel. ``old_keys`` must be unique."""
	new_keys = _voxel_keys(pts, voxel_mm)
	_, first_idx = np.unique(new_keys, return_index=True)
	keep_idx = np.sort(first_idx)
	if old_keys.size > 0:
		keep_idx = keep_idx[~np.isin(new_keys[keep_idx], old_keys, assume_unique=True)]
	if keep_idx.size == 0:
		empty = np.empty((0, 3), dtype=np.float64)
		return empty, _empty_rgb(rgb), old_keys
	kept_pts = np.ascontiguousarray(pts[keep_idx], dtype=np.float64)
	kept_rgb = None if rgb is None else np.ascontiguousarray(rgb[keep_idx], dtype=np.float64)
	union = np.union1d(old_keys, new_keys[keep_idx])
	return kept_pts, kept_rgb, union


def _xyz(points: Optional[np.ndarray]) -> np.ndarray:
	if points is None:
		return np.empty((0, 3), dtype=np.float64)
	arr = np.asarray(points, dtype=np.float64)
	if arr.ndim != 2 or arr.shape[1] < 3 or arr.shape[0] <= 0:
		return np.empty((0, 3), dtype=np.float64)
	return np.ascontiguousarray(arr[:, :3], dtype=np.float64)


def _aligned_rgb(colors: Optional[np.ndarray], n: int) -> Optional[np.ndarray]:
	if colors is None or n <= 0:
		return None
	arr = np.asarray(colors, dtype=np.float64)
	if arr.ndim != 2 or arr.shape[0] != n or arr.shape[1] < 3:
		return None
	return np.ascontiguousarray(arr[:, :3], dtype=np.float64)


def _empty_rgb(colors: Optional[np.ndarray]) -> Optional[np.ndarray]:
	if colors is None:
		return None
	return np.empty((0, 3), dtype=np.float64)


def _voxel_keys(points: np.ndarray, voxel_mm: float) -> np.ndarray:
	q = np.floor(points / float(voxel_mm)).astype(np.int64)
	ox = np.clip(q[:, 0] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	oy = np.clip(q[:, 1] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	oz = np.clip(q[:, 2] + _VOXEL_COORD_OFFSET, 0, _VOXEL_COORD_MASK)
	return (ox << (2 * _VOXEL_COORD_SHIFT)) | (oy << _VOXEL_COORD_SHIFT) | oz

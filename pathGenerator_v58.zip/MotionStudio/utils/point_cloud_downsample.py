"""Linear keep-fraction downsample for point-cloud LODs and live captures."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

from MotionStudio.utils.mesh_assets import lod_sidecar_path
from MotionStudio.utils.point_cloud_io import (
	PointCloudLoadError,
	load_point_cloud,
	save_point_cloud,
)

DEFAULT_DOWNSAMPLE_RATIO = 0.2
MIN_DOWNSAMPLE_RATIO = 0.01
MAX_DOWNSAMPLE_RATIO = 1.0


@dataclass(frozen=True)
class DownsampleResult:
	"""Baked LOD PLY plus point counts for the Inspector summary."""

	dest: Path
	points_before: int
	points_after: int


def clamp_downsample_ratio(ratio: float) -> float:
	"""Clamp a keep-fraction to the Inspector range."""
	try:
		value = float(ratio)
	except (TypeError, ValueError):
		value = DEFAULT_DOWNSAMPLE_RATIO
	return max(MIN_DOWNSAMPLE_RATIO, min(MAX_DOWNSAMPLE_RATIO, value))


def downsample_is_noop(ratio: float) -> bool:
	"""True when ``ratio`` keeps every point (skip file rewrite)."""
	return clamp_downsample_ratio(ratio) >= 1.0


def downsample_arrays(
	points: np.ndarray,
	colors: Optional[np.ndarray],
	ratio: float,
) -> Tuple[np.ndarray, Optional[np.ndarray], int, int]:
	"""Keep-fraction downsample of in-memory XYZ (+ optional RGB).

	Returns ``(points, colors, count_before, count_after)``. ``ratio`` 1.0
	leaves the arrays unchanged (still returned as contiguous XYZ).
	"""
	pts = np.asarray(points, dtype=np.float64)
	if pts.ndim != 2 or pts.shape[1] < 3 or pts.shape[0] <= 0:
		raise OSError("Point cloud has no points to downsample.")
	pts = np.ascontiguousarray(pts[:, :3], dtype=np.float64)
	rgb = None
	if colors is not None:
		arr = np.asarray(colors, dtype=np.float64)
		if arr.ndim == 2 and arr.shape[0] == pts.shape[0] and arr.shape[1] >= 3:
			rgb = np.ascontiguousarray(arr[:, :3], dtype=np.float64)

	before = int(pts.shape[0])
	keep = clamp_downsample_ratio(ratio)
	if keep >= 1.0 or before <= 1:
		return pts, rgb, before, before
	target = max(1, int(round(before * keep)))
	out_pts, out_rgb = _linear_downsample(pts, rgb, target)
	after = int(out_pts.shape[0])
	if after <= 0:
		raise OSError("Downsample produced no points.")
	return out_pts, out_rgb, before, after


def downsample_ply_inplace(path: Path | str, ratio: float, *, allow_vtk: bool = True) -> Tuple[int, int]:
	"""Rewrite ``path`` with a keep-fraction of its points. No-op at ratio 1.0.

	Pass ``allow_vtk=False`` from worker threads (see ``load_point_cloud``).
	"""
	dest = Path(path)
	if not dest.is_file():
		raise FileNotFoundError(f"Point cloud file not found: {dest}")
	if downsample_is_noop(ratio):
		return 0, 0
	try:
		points, colors = load_point_cloud(dest, allow_vtk=allow_vtk)
	except PointCloudLoadError as exc:
		raise OSError(str(exc)) from exc
	out_pts, out_rgb, before, after = downsample_arrays(points, colors, ratio)
	if after < before:
		try:
			save_point_cloud(dest, out_pts, out_rgb)
		except PointCloudLoadError as exc:
			raise OSError(str(exc)) from exc
	return before, after


def downsample_point_cloud_to_ply(
	source: Path,
	dest_dir: Path,
	ratio: float,
) -> DownsampleResult:
	"""
	Bake a linear keep-fraction LOD as a binary PLY.

	``ratio`` is the fraction of points to **keep** (0.5 keeps ~50%). Points are
	taken at even indices so the count follows the slider; this is not a voxel
	grid (AABB voxel sizing collapsed surface scans to a few thousand points).
	Coordinates stay in **file units** (caller still applies PointCloud ``scale``).
	The source file is not overwritten; the dest is always ``<stem>_lod.ply``
	and is replaced on later Downsample runs.
	"""
	source = Path(source)
	if not source.is_file():
		raise FileNotFoundError(f"Point cloud file not found: {source}")

	keep = clamp_downsample_ratio(ratio)
	try:
		points, colors = load_point_cloud(source)
	except PointCloudLoadError as exc:
		raise OSError(str(exc)) from exc
	try:
		out_pts, out_rgb, before, after = downsample_arrays(points, colors, keep)
	except OSError as exc:
		raise OSError(f"{exc} {source}") from exc
	if after <= 0:
		raise OSError(f"Downsample produced no points: {source}")

	dest = lod_sidecar_path(source, Path(dest_dir), ".ply")
	try:
		save_point_cloud(dest, out_pts, out_rgb)
	except PointCloudLoadError as exc:
		raise OSError(str(exc)) from exc
	if not dest.is_file() or dest.stat().st_size <= 0:
		raise OSError(f"Failed to write downsampled PLY: {dest}")
	return DownsampleResult(dest=dest, points_before=before, points_after=after)


def _linear_downsample(
	points: np.ndarray,
	colors: Optional[np.ndarray],
	target_count: int,
) -> Tuple[np.ndarray, Optional[np.ndarray]]:
	"""Keep ``target_count`` points at even file-order strides."""
	n = int(points.shape[0])
	target = max(1, min(n, int(target_count)))
	if target >= n:
		return points, colors
	idx = (np.arange(target, dtype=np.int64) * n) // target
	out_pts = points[idx]
	out_rgb = colors[idx] if colors is not None else None
	return out_pts, out_rgb

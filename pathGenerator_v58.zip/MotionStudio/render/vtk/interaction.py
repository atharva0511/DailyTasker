from __future__ import annotations

import vtk  # type: ignore


class EditorInteractorStyle(vtk.vtkInteractorStyleTrackballCamera):
	"""
	Editor navigation bindings:
	- Right mouse drag: orbit/rotate camera
	- Middle mouse drag **or Shift+right drag**: pan
	- Mouse wheel: zoom (VTK default)
	- Left click: reserved for picking (no camera rotate)
	"""

	def __init__(self) -> None:
		super().__init__()

	def OnLeftButtonDown(self) -> None:  # noqa: N802 (VTK naming)
		# Disable default left-drag rotate.
		return

	def OnLeftButtonUp(self) -> None:  # noqa: N802 (VTK naming)
		return

	def OnMiddleButtonDown(self) -> None:  # noqa: N802
		# Keep default middle-button pan
		super().OnMiddleButtonDown()

	def OnMiddleButtonUp(self) -> None:  # noqa: N802
		super().OnMiddleButtonUp()

	def OnRightButtonDown(self) -> None:  # noqa: N802 (VTK naming)
		# Shift+right pans (same as middle-drag); otherwise orbit.
		try:
			iren = self.GetInteractor()
			if iren is not None and iren.GetShiftKey():
				self.StartPan()
				return
		except Exception:
			pass
		self.StartRotate()

	def OnRightButtonUp(self) -> None:  # noqa: N802 (VTK naming)
		self.EndPan()
		self.EndRotate()



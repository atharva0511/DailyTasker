"""Ring buffer of recent viewport renders, persisted to ``render-trace.log``.

``faulthandler`` can print the Python stack at a native crash but cannot read
Python data, so the last renders are flushed to disk periodically. After a
crash the file shows what the viewport was doing just before it died.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from pathlib import Path
from typing import Deque, Optional, Tuple

from MotionStudio.utils.crash_log import log_dir

_MAX_EVENTS = 200
_FLUSH_INTERVAL_S = 1.0

# (wall time, tag, base actor count, overlay actor count, duration ms, note)
_Event = Tuple[float, str, int, int, float, str]


class RenderDiagnostics:
	def __init__(self) -> None:
		self._events: Deque[_Event] = deque(maxlen=_MAX_EVENTS)
		self._lock = threading.Lock()
		self._last_flush = 0.0
		self._path: Optional[Path] = None
		self._render_count = 0
		self._warned: set[str] = set()
		self._unflushed = False

	@property
	def render_count(self) -> int:
		return self._render_count

	def record(self, tag: str, base_actors: int, overlay_actors: int, duration_ms: float, note: str = "") -> None:
		with self._lock:
			self._render_count += 1
			self._events.append((time.time(), tag, base_actors, overlay_actors, duration_ms, note))
			self._unflushed = True
		now = time.monotonic()
		if now - self._last_flush >= _FLUSH_INTERVAL_S:
			self._last_flush = now
			self.flush()

	def note(self, message: str) -> None:
		"""Record a non-render event (guard warning, deferred mutation, error)."""
		with self._lock:
			self._events.append((time.time(), "note", -1, -1, 0.0, message))
			self._unflushed = True

	def flush_if_unflushed(self) -> None:
		"""Heartbeat hook: persist events the 1 s record throttle has not written yet."""
		if self._unflushed:
			self._last_flush = time.monotonic()
			self.flush()

	def warn_once(self, key: str, message: str) -> None:
		if key in self._warned:
			return
		self._warned.add(key)
		print(f"[render-guard] {message}", flush=True)
		self.note(message)
		self.flush()

	def flush(self) -> None:
		try:
			if self._path is None:
				self._path = log_dir() / "render-trace.log"
			with self._lock:
				events = list(self._events)
				self._unflushed = False
			lines = [f"renders={self._render_count}"]
			for ts, tag, base, overlay, dur, note in events:
				stamp = time.strftime("%H:%M:%S", time.localtime(ts)) + f".{int((ts % 1) * 1000):03d}"
				lines.append(f"{stamp} {tag:<24} base={base:<5} overlay={overlay:<4} {dur:7.2f}ms {note}")
			self._path.write_text("\n".join(lines) + "\n", encoding="utf-8")
		except Exception:
			pass


diagnostics = RenderDiagnostics()

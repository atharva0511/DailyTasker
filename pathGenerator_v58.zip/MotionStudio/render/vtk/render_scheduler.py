"""Single, main-thread render path for the viewport.

Every ``plotter.render()`` call in the app becomes a *request*. Requests are
coalesced into at most one VTK render per frame interval, always on the GUI
thread, never re-entrantly, and never while the window cannot be drawn.

Guard rails enforced here:

- Scene-graph mutations (``add_actor`` / ``remove_actor`` / overlay
  ``AddActor`` / ``RemoveActor``) issued while VTK is rendering, or from a
  worker thread, are deferred to the main thread after the frame instead of
  touching the renderer's prop list mid-pass.
- ``pre_frame`` callbacks (``on_viewport_draw`` hooks, debug-draw sync) run
  before ``Render()`` in plain Python, not inside a VTK observer.
- Exceptions never escape into VTK; they are logged once per site.
"""

from __future__ import annotations

import os
import sys
import threading
import time
import traceback
from typing import Any, Callable, List, Optional, Tuple

from PyQt6.QtCore import QEvent, QObject, QTimer, Qt, pyqtSignal

from MotionStudio.render.vtk.render_diagnostics import diagnostics

_MIN_INTERVAL_MS = 16
_HIDDEN_RETRY_MS = 250

_active_scheduler: Optional["RenderScheduler"] = None


def _on_main_thread() -> bool:
	return threading.current_thread() is threading.main_thread()


def _caller_tag(depth: int = 2) -> str:
	try:
		frame = sys._getframe(depth)
		return f"{os.path.basename(frame.f_code.co_filename)}:{frame.f_lineno}"
	except Exception:
		return "?"


def scheduler_for(plotter: Any = None) -> Optional["RenderScheduler"]:
	"""Scheduler installed on ``plotter`` (or the app's active viewport scheduler)."""
	if plotter is not None:
		sched = getattr(plotter, "_ms_render_scheduler", None)
		if sched is not None:
			return sched
	return _active_scheduler


class RenderScheduler(QObject):
	_post_to_main = pyqtSignal(object)

	def __init__(self, plotter: Any, *, min_interval_ms: int = _MIN_INTERVAL_MS) -> None:
		super().__init__()
		self._plotter = plotter
		self._min_interval_ms = max(0, int(min_interval_ms))
		# Bound class method: unaffected by the instance-level ``render`` override.
		self._raw_render: Callable[[], Any] = plotter._render
		self._timer = QTimer(self)
		self._timer.setSingleShot(True)
		self._timer.timeout.connect(self._on_timer)
		self._dirty = False
		self._pending_tags: List[str] = []
		self._last_render_t = 0.0
		self._in_scheduled_render = False
		self._in_vtk_render = 0
		self._suspend_reasons: dict[str, int] = {}
		self._deferred: List[Tuple[str, Callable[[], Any]]] = []
		self._pre_frame: List[Callable[[], None]] = []
		self._post_to_main.connect(self._run_posted, Qt.ConnectionType.QueuedConnection)

		ren_win = getattr(plotter, "ren_win", None)
		if ren_win is not None:
			try:
				# Observers only flip a flag: no Python scene work happens inside VTK's pass.
				ren_win.AddObserver("StartEvent", self._on_vtk_start, 10.0)
				ren_win.AddObserver("EndEvent", self._on_vtk_end, -10.0)
			except Exception:
				pass
		try:
			plotter.installEventFilter(self)
		except Exception:
			pass

	# ------------------------------------------------------------------ install

	def install(self) -> None:
		"""Route ``plotter.render`` / actor add-remove through this scheduler."""
		global _active_scheduler
		plotter = self._plotter
		plotter._ms_render_scheduler = self
		plotter._ms_render_immediate = self._raw_render
		plotter.render = self.request_from_plotter

		orig_add = plotter.add_actor
		orig_remove = plotter.remove_actor

		def add_actor(actor, *args, **kwargs):
			if self._must_defer():
				self._defer_mutation("plotter.add_actor", lambda: orig_add(actor, *args, **kwargs))
				prop = actor.GetProperty() if hasattr(actor, "GetProperty") else None
				return actor, prop
			return orig_add(actor, *args, **kwargs)

		def remove_actor(actor, *args, **kwargs):
			if self._must_defer():
				self._defer_mutation("plotter.remove_actor", lambda: orig_remove(actor, *args, **kwargs))
				return True
			return orig_remove(actor, *args, **kwargs)

		plotter.add_actor = add_actor
		plotter.remove_actor = remove_actor
		_active_scheduler = self

	# ------------------------------------------------------------------ public API

	def add_pre_frame(self, callback: Callable[[], None]) -> None:
		if callback not in self._pre_frame:
			self._pre_frame.append(callback)

	def is_rendering(self) -> bool:
		return self._in_vtk_render > 0 or self._in_scheduled_render

	def request_from_plotter(self, *_args: Any, **_kwargs: Any) -> None:
		self.request(_caller_tag())

	def request(self, tag: str = "") -> None:
		"""Ask for a frame. Cheap and safe from anywhere; coalesced per frame interval."""
		if not _on_main_thread():
			diagnostics.warn_once(
				f"offthread-render:{tag}",
				f"render requested off the main thread ({tag}); marshalled to GUI thread",
			)
			self._post_to_main.emit(lambda: self.request(tag))
			return
		self._dirty = True
		if tag and len(self._pending_tags) < 8:
			self._pending_tags.append(tag)
		if self.is_rendering():
			return
		self._schedule()

	def render_now(self, tag: str = "render_now") -> None:
		"""Synchronous frame for the rare caller that needs pixels immediately."""
		if not _on_main_thread() or self.is_rendering():
			self.request(tag)
			return
		self._dirty = True
		self._pending_tags.append(tag)
		self._timer.stop()
		self._do_render()

	def suspend(self, reason: str) -> None:
		self._suspend_reasons[reason] = self._suspend_reasons.get(reason, 0) + 1

	def resume(self, reason: str) -> None:
		count = self._suspend_reasons.get(reason, 0) - 1
		if count <= 0:
			self._suspend_reasons.pop(reason, None)
		else:
			self._suspend_reasons[reason] = count
		if not self._suspend_reasons and self._dirty:
			self._schedule()

	def run_after_frame(self, label: str, fn: Callable[[], Any]) -> None:
		"""Run ``fn`` now if safe, otherwise right after the current VTK pass."""
		if self._must_defer():
			self._defer_mutation(label, fn)
			return
		fn()

	# ------------------------------------------------------------------ guards

	def _must_defer(self) -> bool:
		return (not _on_main_thread()) or self._in_vtk_render > 0

	def _defer_mutation(self, label: str, fn: Callable[[], Any]) -> None:
		if not _on_main_thread():
			diagnostics.warn_once(
				f"offthread:{label}",
				f"{label} called off the main thread; deferred to GUI thread\n"
				+ "".join(traceback.format_stack(limit=8)),
			)
			self._post_to_main.emit(lambda: self.run_after_frame(label, fn))
			return
		diagnostics.warn_once(
			f"during-render:{label}:{_caller_tag(4)}",
			f"{label} called while VTK was rendering ({_caller_tag(4)}); deferred until after the frame",
		)
		self._deferred.append((label, fn))

	def _run_posted(self, fn: Callable[[], Any]) -> None:
		try:
			fn()
		except Exception:
			diagnostics.warn_once("posted-call", "posted call failed:\n" + traceback.format_exc())

	def _flush_deferred(self) -> None:
		if not self._deferred or self._in_vtk_render > 0:
			return
		pending, self._deferred = self._deferred, []
		for label, fn in pending:
			try:
				fn()
			except Exception:
				diagnostics.warn_once(f"deferred:{label}", f"deferred {label} failed:\n{traceback.format_exc()}")
		self.request("deferred-mutations")

	def _drawable(self) -> bool:
		plotter = self._plotter
		try:
			if not plotter.isVisible():
				return False
			win = plotter.window()
			if win is not None and win.isMinimized():
				return False
			ren_win = getattr(plotter, "ren_win", None)
			if ren_win is not None:
				w, h = ren_win.GetSize()
				if int(w) <= 1 or int(h) <= 1:
					return False
		except Exception:
			return False
		return True

	# ------------------------------------------------------------------ scheduling

	def _schedule(self) -> None:
		if self._suspend_reasons or self._timer.isActive():
			return
		elapsed_ms = (time.monotonic() - self._last_render_t) * 1000.0
		self._timer.start(max(0, int(self._min_interval_ms - elapsed_ms)))

	def _on_timer(self) -> None:
		if self._dirty:
			self._do_render()

	def _do_render(self) -> None:
		if self.is_rendering() or self._suspend_reasons:
			return
		if not self._drawable():
			# Stay dirty; eventFilter re-requests on show / resize, with a slow retry
			# for restore-from-minimize (delivered to the top-level window only).
			self._timer.start(_HIDDEN_RETRY_MS)
			return
		tags = ",".join(dict.fromkeys(self._pending_tags)) or "request"
		self._pending_tags = []
		self._dirty = False
		self._in_scheduled_render = True
		t0 = time.perf_counter()
		note = ""
		try:
			for callback in list(self._pre_frame):
				try:
					callback()
				except Exception:
					diagnostics.warn_once(
						f"pre_frame:{getattr(callback, '__qualname__', callback)!s}",
						f"pre_frame callback failed:\n{traceback.format_exc()}",
					)
			try:
				self._raw_render()
			except Exception as exc:
				note = f"render error: {exc!r}"
				diagnostics.warn_once(f"render:{type(exc).__name__}", f"VTK render failed:\n{traceback.format_exc()}")
		finally:
			self._in_scheduled_render = False
			self._last_render_t = time.monotonic()
		diagnostics.record(tags[:120], *self._actor_counts(), (time.perf_counter() - t0) * 1000.0, note)
		self._flush_deferred()
		if self._dirty:
			self._schedule()

	def _actor_counts(self) -> Tuple[int, int]:
		base = overlay = -1
		try:
			base = int(self._plotter.renderer.GetActors().GetNumberOfItems())
		except Exception:
			pass
		try:
			ov = getattr(self._plotter, "_pyengine_overlay_renderer", None)
			if ov is not None:
				overlay = int(ov.GetActors().GetNumberOfItems())
		except Exception:
			pass
		return base, overlay

	# ------------------------------------------------------------------ VTK / Qt hooks

	def _on_vtk_start(self, _obj, _ev) -> None:
		self._in_vtk_render += 1

	def _on_vtk_end(self, _obj, _ev) -> None:
		self._in_vtk_render = max(0, self._in_vtk_render - 1)
		if self._in_vtk_render == 0 and self._deferred and not self._in_scheduled_render:
			# Paint-driven render finished: apply deferred mutations on the next tick.
			QTimer.singleShot(0, self._flush_deferred)

	def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # noqa: N802
		try:
			et = event.type()
			if et in (QEvent.Type.Show, QEvent.Type.Resize, QEvent.Type.WindowStateChange):
				if self._dirty:
					self._schedule()
		except Exception:
			pass
		return False


# ---------------------------------------------------------------------- helpers


def guarded_renderer_add(renderer: Any, actor: Any, plotter: Any = None) -> None:
	"""``renderer.AddActor(actor)`` that is deferred while VTK is rendering / off-thread."""
	sched = scheduler_for(plotter)
	if sched is None:
		renderer.AddActor(actor)
		return
	sched.run_after_frame("renderer.AddActor", lambda: renderer.AddActor(actor))


def guarded_renderer_remove(renderer: Any, actor: Any, plotter: Any = None) -> None:
	"""``renderer.RemoveActor(actor)`` that is deferred while VTK is rendering / off-thread."""
	sched = scheduler_for(plotter)
	if sched is None:
		renderer.RemoveActor(actor)
		return
	sched.run_after_frame("renderer.RemoveActor", lambda: renderer.RemoveActor(actor))


def request_render(plotter: Any = None, tag: str = "") -> None:
	"""Request a coalesced viewport frame (falls back to ``plotter.render()``)."""
	sched = scheduler_for(plotter)
	if sched is not None:
		sched.request(tag or _caller_tag())
		return
	if plotter is not None:
		try:
			plotter.render()
		except Exception:
			pass


def install_render_scheduler(plotter: Any) -> RenderScheduler:
	sched = RenderScheduler(plotter)
	sched.install()
	return sched

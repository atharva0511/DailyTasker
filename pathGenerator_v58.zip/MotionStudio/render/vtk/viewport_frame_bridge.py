from __future__ import annotations

from MotionStudio.core.debug import _runtime
from MotionStudio.core.ecs.viewport_lifecycle import invoke_on_viewport_draw
from MotionStudio.render.vtk.debug_draw_bridge import VtkDebugDrawBridge
from MotionStudio.render.vtk.render_scheduler import scheduler_for


class VtkViewportFrameBridge:
	"""
	Runs viewport lifecycle hooks and debug draw sync before each scheduled frame.

	Hooks run as a RenderScheduler ``pre_frame`` callback, i.e. in plain Python on
	the GUI thread *before* ``Render()`` — never inside a VTK observer, so actor
	add/remove and component writes cannot land in the middle of a VTK pass.
	Qt paint/expose renders redraw the existing actors without running hooks.
	"""

	def __init__(self, plotter, scene, debug_draw_bridge: VtkDebugDrawBridge) -> None:
		self._plotter = plotter
		self._scene = scene
		self._debug_draw_bridge = debug_draw_bridge
		self._in_cycle: bool = False
		sched = scheduler_for(plotter)
		if sched is None:
			raise RuntimeError("VtkViewportFrameBridge requires the viewport RenderScheduler")
		sched.add_pre_frame(self._on_pre_frame)

	def _on_pre_frame(self) -> None:
		if self._in_cycle:
			return
		self._in_cycle = True
		try:
			_runtime.begin_render_pass()
			try:
				invoke_on_viewport_draw(self._scene)
			finally:
				self._debug_draw_bridge.render_cycle()
		finally:
			_runtime.end_render_pass()
			self._in_cycle = False

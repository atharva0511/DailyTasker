"""Run a native hardware SDK (``ur_rtde``, Mech-Eye) in a child process.

The SDK's native code then never shares the editor's heap or GIL: a crash or
heap corruption inside the SDK kills only the helper (the worker sees a
"connection lost" error), and a constructor that blocks while holding the GIL
freezes only the helper, not the GUI.

Parent side: ``SdkHostClient(name, "package.module:ServiceClass")``. Each
``call(method, *args, timeout_s=...)`` is a synchronous request/reply over a
``multiprocessing`` pipe, issued from the hardware worker QThread. The child
imports only the service module (no Qt / VTK), owns one service instance, and
exits when the parent goes away.

Arguments and results must be picklable plain data (str / float / tuple ...).
Frozen builds need ``multiprocessing.freeze_support()`` at the top of
``main.py`` (the helper re-launches ``iMOVE.exe``).
"""

from __future__ import annotations

import importlib
import multiprocessing as mp
import os
import sys
import threading
import time
from typing import Any, Optional

_CTX = mp.get_context("spawn")
_POLL_S = 0.1
_SHUTDOWN_WAIT_S = 3.0
_PARENT_CHECK_S = 1.0


class SdkHostError(RuntimeError):
	"""The helper process failed, timed out, or rejected the call."""


class SdkHostCrashed(SdkHostError):
	"""The helper process exited (native crash, kill, or failed start)."""


class SdkRemoteError(SdkHostError):
	"""The service method raised inside the helper; ``type_name`` is its class name."""

	def __init__(self, type_name: str, message: str) -> None:
		super().__init__(message)
		self.type_name = type_name


class SdkHostClient:
	"""Parent-side handle to one helper process. Thread-safe; one call at a time."""

	def __init__(self, name: str, service_spec: str) -> None:
		self._name = str(name)
		self._service_spec = str(service_spec)
		self._lock = threading.Lock()
		self._proc: Optional[Any] = None
		self._conn: Optional[Any] = None
		self._seq = 0

	@property
	def name(self) -> str:
		return self._name

	def is_alive(self) -> bool:
		proc = self._proc
		return proc is not None and proc.is_alive()

	def start(self) -> None:
		"""Launch the helper process (restarts it if a previous one died)."""
		with self._lock:
			if not self.is_alive():
				self._start()
		if not self.is_alive():
			raise SdkHostCrashed(f"{self._name} SDK helper exited during start; see imove-sdk-{self._name}.log")

	def call(self, method: str, *args: Any, timeout_s: Optional[float] = None, **kwargs: Any) -> Any:
		"""Run ``service.method(*args, **kwargs)`` in the helper and return its result.

		Never restarts a dead helper: SDK session state lived in it. Raises
		``SdkRemoteError`` when the method raised, ``SdkHostCrashed`` when the
		helper is gone, and ``SdkHostError`` on timeout (the helper is killed:
		its state is unknown).
		"""
		with self._lock:
			if not self.is_alive():
				proc = self._proc
				self._reap()
				if proc is None:
					raise SdkHostCrashed(f"connection lost: {self._name} SDK helper is not running")
				raise SdkHostCrashed(self._exit_text(proc))
			conn = self._conn
			proc = self._proc
			self._seq += 1
			seq = self._seq
			try:
				conn.send((seq, method, args, kwargs))
			except (OSError, EOFError, ValueError) as exc:
				self._reap()
				raise SdkHostCrashed(self._exit_text(proc, f"send failed: {exc}")) from exc
			deadline = None if timeout_s is None else time.monotonic() + max(0.1, float(timeout_s))
			while True:
				try:
					ready = conn.poll(_POLL_S)
				except (OSError, EOFError):
					ready = False
					if not proc.is_alive():
						self._reap()
						raise SdkHostCrashed(self._exit_text(proc))
				if ready:
					try:
						reply_seq, status, payload = conn.recv()
					except (OSError, EOFError) as exc:
						self._reap()
						raise SdkHostCrashed(self._exit_text(proc)) from exc
					if reply_seq != seq:
						continue
					if status == "ok":
						return payload
					type_name, message = payload
					raise SdkRemoteError(str(type_name), str(message))
				if not proc.is_alive():
					self._reap()
					raise SdkHostCrashed(self._exit_text(proc))
				if deadline is not None and time.monotonic() >= deadline:
					self._kill_locked()
					raise SdkHostError(
						f"{self._name} SDK helper did not answer {method} within "
						f"{float(timeout_s):.0f} s; helper was stopped"
					)

	def close(self) -> None:
		"""Ask the service to clean up and exit; kill it if it does not."""
		with self._lock:
			proc, conn = self._proc, self._conn
			if proc is None:
				return
			try:
				if proc.is_alive():
					self._seq += 1
					conn.send((self._seq, "__shutdown__", (), {}))
					proc.join(_SHUTDOWN_WAIT_S)
			except (OSError, EOFError, ValueError):
				pass
			self._kill_locked()

	def kill(self) -> None:
		"""Terminate the helper immediately (any thread). A blocked ``call`` then fails fast."""
		proc = self._proc
		if proc is not None and proc.is_alive():
			try:
				proc.kill()
			except Exception:
				pass

	# ------------------------------------------------------------------ internals

	def _start(self) -> None:
		self._reap()
		from MotionStudio.utils.crash_log import log_dir

		parent_conn, child_conn = _CTX.Pipe(duplex=True)
		proc = _CTX.Process(
			target=serve,
			args=(child_conn, self._service_spec, self._name, str(log_dir())),
			name=f"imove-sdk-{self._name}",
			daemon=True,
		)
		try:
			proc.start()
		except Exception as exc:
			parent_conn.close()
			child_conn.close()
			raise SdkHostCrashed(f"{self._name} SDK helper failed to start: {exc}") from exc
		child_conn.close()
		self._proc, self._conn = proc, parent_conn
		print(f"[sdk-host] {self._name} helper started (pid {proc.pid})", flush=True)

	def _kill_locked(self) -> None:
		proc = self._proc
		if proc is not None and proc.is_alive():
			try:
				proc.kill()
				proc.join(1.0)
			except Exception:
				pass
		self._reap()

	def _reap(self) -> None:
		conn, proc = self._conn, self._proc
		self._conn, self._proc = None, None
		if conn is not None:
			try:
				conn.close()
			except Exception:
				pass
		if proc is not None:
			try:
				proc.join(0.1)
			except Exception:
				pass

	def _exit_text(self, proc: Any, detail: str = "") -> str:
		code = None
		try:
			proc.join(0.2)
			code = proc.exitcode
		except Exception:
			pass
		if code is None:
			code_text = "?"
		elif code > 255:
			code_text = f"0x{code:08X}"
		else:
			code_text = str(code)
		extra = f"; {detail}" if detail else ""
		return (
			f"connection lost: {self._name} SDK helper process exited (code {code_text}{extra}). "
			f"See imove-sdk-{self._name}.log"
		)


# ---------------------------------------------------------------------- child side


def serve(conn: Any, service_spec: str, name: str, log_dir: str) -> None:
	"""Helper process entry point: serve requests until shutdown or parent exit."""
	_setup_child_logging(name, log_dir)
	_watch_parent()
	try:
		module_name, class_name = service_spec.split(":", 1)
		service = getattr(importlib.import_module(module_name), class_name)()
	except BaseException as exc:
		print(f"[sdk-host] {name}: could not create service {service_spec}: {exc!r}", flush=True)
		_reply_forever_with_error(conn, f"SDK helper could not load {service_spec}: {exc}")
		return
	print(f"[sdk-host] {name} helper ready (pid {os.getpid()})", flush=True)
	while True:
		try:
			seq, method, args, kwargs = conn.recv()
		except (EOFError, OSError):
			break
		if method == "__shutdown__":
			_close_service(service)
			try:
				conn.send((seq, "ok", None))
			except (OSError, EOFError):
				pass
			break
		fn = getattr(service, method, None) if not str(method).startswith("_") else None
		if not callable(fn):
			_send(conn, (seq, "err", ("AttributeError", f"unknown SDK helper method: {method}")))
			continue
		try:
			result = fn(*args, **kwargs)
		except BaseException as exc:
			_send(conn, (seq, "err", (type(exc).__name__, str(exc))))
			continue
		_send(conn, (seq, "ok", result))
	_close_service(service)


def _send(conn: Any, message: Any) -> None:
	try:
		conn.send(message)
	except (OSError, EOFError):
		os._exit(0)
	except Exception as exc:
		seq = message[0] if isinstance(message, tuple) and message else 0
		try:
			conn.send((seq, "err", ("SdkHostError", f"reply not picklable: {exc}")))
		except Exception:
			os._exit(0)


def _close_service(service: Any) -> None:
	close = getattr(service, "close", None)
	if callable(close):
		try:
			close()
		except Exception as exc:
			print(f"[sdk-host] service close failed: {exc!r}", flush=True)


def _reply_forever_with_error(conn: Any, message: str) -> None:
	while True:
		try:
			seq, method, _args, _kwargs = conn.recv()
		except (EOFError, OSError):
			return
		_send(conn, (seq, "err", ("SdkHostError", message)))
		if method == "__shutdown__":
			return


def _setup_child_logging(name: str, log_dir: str) -> None:
	"""stdout/stderr and native-crash stacks of the helper go to ``imove-sdk-<name>.log``."""
	import faulthandler

	try:
		path = os.path.join(log_dir, f"imove-sdk-{name}.log")
		log = open(path, "a", encoding="utf-8", errors="replace", buffering=1)
	except OSError:
		return
	log.write(f"\n===== {name} SDK helper start {time.strftime('%Y-%m-%d %H:%M:%S')} pid={os.getpid()} =====\n")
	log.flush()
	# Native SDK output (printf / std::cout) writes to fds 1 and 2, not sys.stdout.
	for fd in (1, 2):
		try:
			os.dup2(log.fileno(), fd)
		except OSError:
			pass
	sys.stdout = log
	sys.stderr = log
	try:
		faulthandler.enable(file=log, all_threads=True)
	except Exception:
		pass


def _watch_parent() -> None:
	"""Exit when the editor is gone, even while the SDK is blocked in a native call."""
	parent = mp.parent_process()
	if parent is None:
		return

	def watch() -> None:
		while True:
			time.sleep(_PARENT_CHECK_S)
			if not parent.is_alive():
				os._exit(0)

	threading.Thread(target=watch, name="sdk-host-parent-watch", daemon=True).start()

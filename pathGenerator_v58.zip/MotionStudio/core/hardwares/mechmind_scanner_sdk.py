"""Optional Mech-Eye (Mechmind) SDK adapter.

Connect / capture / save-PLY live here so the component can start without
``MechEyeAPI`` installed. Callables raise ``MechmindSdkError`` with a
user-facing message when the SDK is missing or a camera call fails.

The camera calls run inside the ``mecheye`` SDK helper process through
``MechEyeService`` (see ``sdk_host`` / ``mechmind_scanner_client``); the app
process never imports ``mecheye``. ``merge_camera_ply_into_world_scan`` is
pure numpy and runs inside this helper (``MechEyeService.merge_world_scan``),
not in the editor process.
"""

from __future__ import annotations

from typing import Any, Optional


class MechmindSdkError(RuntimeError):
	"""SDK missing, connect failed, or capture/save failed."""


def sdk_available() -> bool:
	return _load_sdk()[0] is not None


def sdk_missing_message() -> str:
	return "MechEyeAPI not installed. Install Mech-Eye SDK."


def connect_camera(ip_address: str, timeout_ms: int) -> Any:
	"""Create a Camera, connect by IP, return the live handle (worker-thread only)."""
	Camera, _fmt, err = _load_sdk()
	if Camera is None:
		raise MechmindSdkError(err or sdk_missing_message())
	ip = str(ip_address or "").strip()
	if not ip:
		raise MechmindSdkError("IP address is empty.")
	timeout = _normalize_timeout_ms(timeout_ms)
	# Static timeout (older SDKs) must be set before connect.
	apply_command_timeout(None, timeout)
	try:
		camera = Camera()
	except Exception as exc:
		raise MechmindSdkError(f"Could not create Camera: {exc}") from exc
	try:
		status = camera.connect(ip, timeout)
	except TypeError:
		try:
			status = camera.connect(ip)
		except Exception as exc:
			raise MechmindSdkError(f"Connect failed: {exc}") from exc
	except Exception as exc:
		raise MechmindSdkError(f"Connect failed: {exc}") from exc
	_raise_if_bad(status, "Connect")
	apply_command_timeout(camera, timeout)
	return camera


def disconnect_camera(camera: Any) -> None:
	if camera is None:
		return
	try:
		status = camera.disconnect()
	except Exception as exc:
		raise MechmindSdkError(f"Disconnect failed: {exc}") from exc
	_raise_if_bad(status, "Disconnect")


def capture_to_ply(
	camera: Any,
	abs_ply_path: str,
	capture_color: bool,
	timeout_ms: int = 60000,
) -> None:
	"""Capture one frame and write ``abs_ply_path`` as PLY (overwrites)."""
	if camera is None:
		raise MechmindSdkError("Camera is not connected.")
	Camera, file_format, err = _load_sdk()
	if Camera is None:
		raise MechmindSdkError(err or sdk_missing_message())
	path = str(abs_ply_path or "").strip()
	if not path:
		raise MechmindSdkError("Capture path is empty.")
	timeout = _normalize_timeout_ms(timeout_ms)
	apply_command_timeout(camera, timeout)
	try:
		if capture_color:
			_capture_textured(camera, path, file_format, timeout)
		else:
			_capture_untextured(camera, path, file_format, timeout)
	except MechmindSdkError:
		raise
	except Exception as exc:
		raise MechmindSdkError(f"Capture failed: {exc}") from exc


def merge_camera_ply_into_world_scan(
	staging_path: str,
	dest_path: str,
	camera_world_matrix_rowmajor: tuple,
	downsample_ratio: float = 1.0,
	overlap_voxel_mm: float = 0.0,
	occupancy: Optional[Any] = None,
) -> None:
	"""Transform a camera-frame PLY into world space and append onto ``dest_path``.

	``camera_world_matrix_rowmajor`` is a length-16 row-major 4x4 tuple
	(``p_world = M @ p_camera``) snapped when Capture was queued.
	``downsample_ratio`` is applied to the **new frame only** before the
	append, so earlier captures already stored in ``dest_path`` are not
	thinned again.
	``overlap_voxel_mm`` > 0 drops new world points whose voxel is already
	occupied by the accumulated cloud (and collapses unique new coverage to
	one point per voxel). Stored points are not re-filtered. ``0`` concatenates
	as before.

	Runs in the ``mecheye`` helper process (numpy only, ``allow_vtk=False``)
	so occupancy and the PLY merge do not share a heap with the viewport.
	``occupancy`` is an optional :class:`VoxelKeyCache` kept on the helper
	session so later cells do not re-sort the accumulated cloud.
	"""
	from pathlib import Path

	import numpy as np

	from MotionStudio.utils.point_cloud_downsample import (
		downsample_arrays,
		downsample_is_noop,
	)
	from MotionStudio.utils.point_cloud_io import (
		PointCloudLoadError,
		load_point_cloud,
		save_point_cloud,
	)
	from MotionStudio.utils.point_cloud_overlap import (
		VoxelKeyCache,
		filter_new_points_against_keys,
		overlap_voxel_is_noop,
	)

	staging = Path(staging_path)
	dest = Path(dest_path)
	try:
		new_pts, new_cols = load_point_cloud(staging, allow_vtk=False)
	except PointCloudLoadError as exc:
		raise MechmindSdkError(f"Could not read capture PLY: {exc}") from exc
	if not downsample_is_noop(downsample_ratio):
		try:
			new_pts, new_cols, _, _ = downsample_arrays(
				new_pts, new_cols, downsample_ratio
			)
		except OSError as exc:
			raise MechmindSdkError(f"Could not downsample capture: {exc}") from exc

	if len(camera_world_matrix_rowmajor) != 16:
		raise MechmindSdkError("Invalid camera world matrix.")
	M = np.asarray(camera_world_matrix_rowmajor, dtype=np.float64).reshape(4, 4)
	n = int(new_pts.shape[0])
	homo = np.concatenate([new_pts, np.ones((n, 1), dtype=np.float64)], axis=1)
	world_pts = (M @ homo.T).T[:, :3]
	finite = np.isfinite(world_pts).all(axis=1)
	world_pts = np.ascontiguousarray(world_pts[finite], dtype=np.float64)
	if new_cols is not None:
		new_cols = np.ascontiguousarray(new_cols[finite], dtype=np.float64)
	if world_pts.shape[0] == 0:
		raise MechmindSdkError("Capture contained no finite XYZ points.")

	old_pts, old_cols = None, None
	if dest.is_file():
		try:
			old_pts, old_cols = load_point_cloud(dest, allow_vtk=False)
		except PointCloudLoadError as exc:
			# Refuse rather than overwrite earlier captures with this frame alone.
			raise MechmindSdkError(
				f"Could not read the existing scan PLY to append to ({exc}). "
				"Clear the scan or pick another file."
			) from exc
		if old_pts is not None and old_pts.shape[0] <= 0:
			old_pts, old_cols = None, None

	cache = occupancy if isinstance(occupancy, VoxelKeyCache) else None
	if not overlap_voxel_is_noop(overlap_voxel_mm):
		if cache is None:
			cache = VoxelKeyCache()
		old_keys = cache.keys_for(str(dest), overlap_voxel_mm, old_pts)
		world_pts, new_cols, union_keys = filter_new_points_against_keys(
			old_keys, world_pts, new_cols, overlap_voxel_mm
		)
		if world_pts.shape[0] == 0:
			if old_pts is not None:
				return
			raise MechmindSdkError("Capture contained no finite XYZ points.")
	else:
		union_keys = None

	merged_pts = world_pts
	merged_cols = new_cols
	if old_pts is not None:
		merged_pts = np.vstack([old_pts, world_pts])
		merged_cols = _merge_color_blocks(old_pts, old_cols, world_pts, new_cols)

	try:
		save_point_cloud(dest, merged_pts, merged_cols)
	except PointCloudLoadError as exc:
		raise MechmindSdkError(f"Could not write scan PLY: {exc}") from exc
	if cache is not None and union_keys is not None:
		cache.commit(str(dest), overlap_voxel_mm, int(merged_pts.shape[0]), union_keys)


def _merge_color_blocks(
	a_pts,
	a_cols,
	b_pts,
	b_cols,
):
	import numpy as np

	if a_cols is None and b_cols is None:
		return None
	n_a = int(a_pts.shape[0])
	n_b = int(b_pts.shape[0])
	gray = np.array([[0.8, 0.8, 0.8]], dtype=np.float64)
	if a_cols is None:
		a_cols = np.repeat(gray, n_a, axis=0)
	if b_cols is None:
		b_cols = np.repeat(gray, n_b, axis=0)
	return np.vstack([a_cols, b_cols])


# ------------------------------------------------------------------ internals

_CACHE: Optional[tuple] = None


def _load_sdk() -> tuple:
	"""Return ``(Camera, file_format, error_message)``. Cached after first try."""
	global _CACHE
	if _CACHE is not None:
		return _CACHE
	try:
		from mecheye.area_scan_3d_camera import Camera  # type: ignore
	except Exception as exc:
		_CACHE = (None, None, f"MechEyeAPI not installed ({exc})")
		return _CACHE
	file_format = _resolve_ply_format()
	_CACHE = (Camera, file_format, None)
	return _CACHE


def _resolve_ply_format() -> Any:
	try:
		from mecheye.shared import FileFormat_PLY  # type: ignore

		return FileFormat_PLY
	except Exception:
		pass
	try:
		from mecheye.area_scan_3d_camera import FileFormat  # type: ignore

		return getattr(FileFormat, "PLY", FileFormat)
	except Exception:
		return None


def _normalize_timeout_ms(timeout_ms: int) -> int:
	try:
		timeout = int(timeout_ms)
	except Exception:
		timeout = 60000
	return max(1, timeout)


def apply_command_timeout(camera: Any, timeout_ms: int) -> None:
	"""Best-effort SDK command timeout (connect, capture, disconnect).

	Newer Mech-Eye builds take ``timeoutMs`` on each capture call instead of
	``Camera.set_timeout``. Older builds expose a static/instance setter.
	Failures are ignored so a missing method does not block I/O.
	"""
	timeout = _normalize_timeout_ms(timeout_ms)
	Camera, _, _ = _load_sdk()
	for obj in (camera, Camera):
		if obj is None:
			continue
		for name in ("set_timeout", "setTimeout"):
			fn = getattr(obj, name, None)
			if not callable(fn):
				continue
			try:
				status = fn(timeout)
			except TypeError:
				continue
			except Exception:
				continue
			try:
				_raise_if_bad(status, "Set timeout")
			except MechmindSdkError:
				continue
			return


def _invoke_capture(camera: Any, method_name: str, frame: Any, timeout_ms: int) -> Any:
	method = getattr(camera, method_name)
	timeout = _normalize_timeout_ms(timeout_ms)
	try:
		return method(frame, timeout)
	except TypeError:
		pass
	for kwargs in ({"timeout_ms": timeout}, {"timeoutMs": timeout}):
		try:
			return method(frame, **kwargs)
		except TypeError:
			continue
	return method(frame)


def _raise_if_bad(status: Any, action: str) -> None:
	if status is None:
		return
	ok = True
	try:
		if hasattr(status, "is_ok"):
			ok = bool(status.is_ok())
		elif hasattr(status, "ok"):
			ok = bool(status.ok())
	except Exception:
		ok = True
	if ok:
		return
	detail = ""
	for attr in ("error_description", "description", "errorDescription"):
		try:
			value = getattr(status, attr, None)
			if callable(value):
				value = value()
			if value:
				detail = str(value)
				break
		except Exception:
			pass
	if not detail:
		detail = str(status)
	raise MechmindSdkError(f"{action} failed: {detail}")


def _capture_untextured(camera: Any, path: str, file_format: Any, timeout_ms: int) -> None:
	from mecheye.area_scan_3d_camera import Frame3D  # type: ignore

	frame = Frame3D()
	_raise_if_bad(_invoke_capture(camera, "capture_3d", frame, timeout_ms), "Capture")
	_save_untextured(frame, path, file_format)


def _capture_textured(camera: Any, path: str, file_format: Any, timeout_ms: int) -> None:
	from mecheye.area_scan_3d_camera import Frame2DAnd3D  # type: ignore

	frame = Frame2DAnd3D()
	_raise_if_bad(
		_invoke_capture(camera, "capture_2d_and_3d", frame, timeout_ms),
		"Capture",
	)
	_save_textured(frame, path, file_format)


def _save_untextured(frame: Any, path: str, file_format: Any) -> None:
	fmt = file_format
	try:
		status = frame.save_untextured_point_cloud(fmt, path) if fmt is not None else None
		if status is None and fmt is None:
			status = frame.save_untextured_point_cloud(path)
		_raise_if_bad(status, "Save PLY")
	except TypeError:
		status = frame.save_untextured_point_cloud(path)
		_raise_if_bad(status, "Save PLY")


def _save_textured(frame: Any, path: str, file_format: Any) -> None:
	fmt = file_format
	try:
		status = frame.save_textured_point_cloud(fmt, path) if fmt is not None else None
		if status is None and fmt is None:
			status = frame.save_textured_point_cloud(path)
		_raise_if_bad(status, "Save PLY")
	except TypeError:
		# Some builds only expose save on the nested 3D frame.
		inner = None
		try:
			inner = frame.frame_3d() if hasattr(frame, "frame_3d") else None
		except Exception:
			inner = None
		if inner is None:
			raise
		_save_untextured(inner, path, file_format)


class MechEyeService:
	"""One camera session, served from the ``mecheye`` SDK helper process."""

	def __init__(self) -> None:
		self._camera: Any = None
		self._occupancy: Any = None

	def connect(self, ip_address: str, timeout_ms: int) -> bool:
		self.disconnect(ignore_errors=True)
		self._camera = connect_camera(ip_address, timeout_ms)
		return True

	def disconnect(self, ignore_errors: bool = False) -> None:
		camera, self._camera = self._camera, None
		try:
			disconnect_camera(camera)
		except MechmindSdkError:
			if not ignore_errors:
				raise

	def close(self) -> None:
		self.disconnect(ignore_errors=True)

	def is_connected(self) -> bool:
		return self._camera is not None

	def capture_to_ply(self, abs_ply_path: str, capture_color: bool, timeout_ms: int = 60000) -> None:
		capture_to_ply(self._camera, abs_ply_path, capture_color, timeout_ms)

	def merge_world_scan(
		self,
		staging_path: str,
		dest_path: str,
		camera_world_matrix_rowmajor: tuple,
		downsample_ratio: float = 1.0,
		overlap_voxel_mm: float = 0.0,
	) -> None:
		"""Append a camera-frame PLY in this process (numpy). Keeps voxel keys across calls."""
		from MotionStudio.utils.point_cloud_overlap import VoxelKeyCache

		if self._occupancy is None:
			self._occupancy = VoxelKeyCache()
		merge_camera_ply_into_world_scan(
			staging_path,
			dest_path,
			camera_world_matrix_rowmajor,
			downsample_ratio=downsample_ratio,
			overlap_voxel_mm=overlap_voxel_mm,
			occupancy=self._occupancy,
		)

"""Cartesian TCP jog in the hardware robot-base frame.

Translation adds millimetres to a base-frame axis. Rotation left-multiplies
``Rot(axis, delta_deg)`` onto the current TCP rotation (base-axis jog), then
converts back to a UR rotation vector. Do not add to rx/ry/rz components.
"""

from __future__ import annotations

import math
from typing import Iterable, Sequence, Tuple

import numpy as np

from MotionStudio.core.robot.frame_math import axis_angle_rotation_matrix

JOG_AXES = ("x", "y", "z", "rx", "ry", "rz")
_TRANS_INDEX = {"x": 0, "y": 1, "z": 2}
_ROT_UNIT = {
	"rx": (1.0, 0.0, 0.0),
	"ry": (0.0, 1.0, 0.0),
	"rz": (0.0, 0.0, 1.0),
}
_MM_TO_M = 0.001
_ANGLE_EPS = 1e-12


def apply_tcp_jog(
	pose_m_rotvec: Sequence[float],
	axis: str,
	delta: float,
) -> Tuple[float, float, float, float, float, float]:
	"""Return a new TCP pose (metres, rotvec rad) after a base-frame jog.

	``delta`` is millimetres for ``x``/``y``/``z`` and degrees for ``rx``/``ry``/``rz``.
	"""
	if len(pose_m_rotvec) < 6:
		raise ValueError("TCP pose must have 6 values (xyz metres, rotvec rad).")
	key = str(axis or "").strip().lower()
	if key not in JOG_AXES:
		raise ValueError(f"Unknown jog axis {axis!r}.")
	try:
		amount = float(delta)
	except (TypeError, ValueError) as exc:
		raise ValueError("Jog step is not a number.") from exc

	x = float(pose_m_rotvec[0])
	y = float(pose_m_rotvec[1])
	z = float(pose_m_rotvec[2])
	rx = float(pose_m_rotvec[3])
	ry = float(pose_m_rotvec[4])
	rz = float(pose_m_rotvec[5])
	if abs(amount) < 1e-15:
		return (x, y, z, rx, ry, rz)

	if key in _TRANS_INDEX:
		i = _TRANS_INDEX[key]
		xyz = [x, y, z]
		xyz[i] += amount * _MM_TO_M
		return (xyz[0], xyz[1], xyz[2], rx, ry, rz)

	dR = axis_angle_rotation_matrix(_ROT_UNIT[key], math.radians(amount))
	R = rotvec_to_matrix(rx, ry, rz)
	r_new = matrix_to_rotvec(dR @ R)
	return (x, y, z, float(r_new[0]), float(r_new[1]), float(r_new[2]))


def tcp_pose_to_mm_deg(
	pose_m_rotvec: Iterable[float],
) -> Tuple[Tuple[float, float, float], Tuple[float, float, float]]:
	"""Split a TCP pose into Inspector units (mm, rotation-vector degrees)."""
	vals = [float(v) for v in pose_m_rotvec]
	if len(vals) < 6:
		raise ValueError("TCP pose must have 6 values.")
	mm = (vals[0] * 1000.0, vals[1] * 1000.0, vals[2] * 1000.0)
	deg = (
		math.degrees(vals[3]),
		math.degrees(vals[4]),
		math.degrees(vals[5]),
	)
	return mm, deg


def rotvec_to_matrix(rx: float, ry: float, rz: float) -> np.ndarray:
	"""3x3 rotation from a UR rotation vector (rad)."""
	vec = np.array([float(rx), float(ry), float(rz)], dtype=np.float64)
	angle = float(np.linalg.norm(vec))
	if angle < _ANGLE_EPS:
		return np.eye(3, dtype=np.float64)
	axis = (float(vec[0] / angle), float(vec[1] / angle), float(vec[2] / angle))
	return axis_angle_rotation_matrix(axis, angle)


def matrix_to_rotvec(matrix: np.ndarray) -> np.ndarray:
	"""UR rotation vector (rad) from a 3x3 rotation matrix."""
	R = np.asarray(matrix, dtype=np.float64)
	if R.shape != (3, 3):
		raise ValueError("Expected a 3x3 rotation matrix.")
	cos_theta = float((np.trace(R) - 1.0) * 0.5)
	cos_theta = max(-1.0, min(1.0, cos_theta))
	theta = math.acos(cos_theta)
	if theta < _ANGLE_EPS:
		return np.zeros(3, dtype=np.float64)
	if abs(theta - math.pi) < 1e-6:
		diag = np.clip((np.diag(R) + 1.0) * 0.5, 0.0, 1.0)
		axis = np.sqrt(diag)
		if R[2, 1] < R[1, 2]:
			axis[0] = -axis[0]
		if R[0, 2] < R[2, 0]:
			axis[1] = -axis[1]
		if R[1, 0] < R[0, 1]:
			axis[2] = -axis[2]
		n = float(np.linalg.norm(axis))
		if n < _ANGLE_EPS:
			axis = np.array([1.0, 0.0, 0.0], dtype=np.float64)
		else:
			axis = axis / n
		return axis * theta
	axis = np.array(
		[
			R[2, 1] - R[1, 2],
			R[0, 2] - R[2, 0],
			R[1, 0] - R[0, 1],
		],
		dtype=np.float64,
	)
	axis /= 2.0 * math.sin(theta)
	return axis * theta

from __future__ import annotations

from typing import Annotated

from PyQt6.QtGui import QColor

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import (
	ColorField,
	FilePath,
	Group,
	Order,
	Range,
	ReadOnly,
	Tooltip,
	inspector_button,
)
from MotionStudio.utils.point_cloud_downsample import (
	DEFAULT_DOWNSAMPLE_RATIO,
	MAX_DOWNSAMPLE_RATIO,
	MIN_DOWNSAMPLE_RATIO,
)

_CLOUD_FILE_FILTER = "Point Clouds (*.ply *.pcd);;All Files (*.*)"
_LOD_FILE_FILTER = "Point Clouds (*.ply);;All Files (*.*)"


@register_component
class PointCloudComponent(Component):
	"""
	Renders a dense 3D point cloud (``.ply`` / ``.pcd``) in the viewport.

	Geometry follows the owning entity's world transform. Points can be
	selected in Vertex Mode for VertexPick and path tools. Does not
	participate in Edge Mode or Face Mode. Attach ``PointCloudCollider``
	to include the cloud in scene collision.
	"""

	type_name = "PointCloud"
	category = "Rendering"
	description = (
		"<p><b>Point Cloud</b></p>"
		"<p>Renders a dense <code>.ply</code> or <code>.pcd</code> cloud in the viewport. "
		"Points follow this entity's Transform. Cloud points can be picked in Vertex Mode "
		"(Inspector VertexPick fields and path tools). Add PointCloudCollider to "
		"participate in scene collision.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Set <b>file_path</b> (or use Hierarchy &rarr; Import Point Cloud). External files are copied into <code>models/</code>.</li>"
		"<li>Default <b>scale</b> is 1000 (metres &rarr; millimetres). Use 1 if the file is already in mm.</li>"
		"<li>Enable <b>use_vertex_colors</b> when the file has RGB; otherwise the uniform <b>color</b> is used.</li>"
		"<li>Adjust <b>point_size</b> and <b>opacity</b> for readability. Compressed PCD (<code>binary_compressed</code>) is not supported.</li>"
		"<li>Open <b>Downsample</b> to bake a lighter PLY (linear keep-fraction) next to the original. Turn on <b>use_downsampled_cloud</b> so the viewport and PointCloudCollider use the LOD; turn it off to show the detailed file again.</li>"
		"<li>With the cloud entity selected, press <b>2</b> (Vertex Mode) or use a component's <b>Pick</b> button to capture points.</li>"
		"<li>Add <b>PointCloudCollider</b> (Add Component → Collision) to collide this cloud with mesh colliders via occupancy voxels.</li>"
		"</ul>"
	)

	file_path: Annotated[
		str,
		FilePath(
			_CLOUD_FILE_FILTER,
			dialog_title="Select Point Cloud",
		),
		Tooltip(
			"Project-relative point-cloud path; external files are copied into "
			"the project's models/ folder. Supported: .ply, .pcd (ASCII or uncompressed binary)."
		),
	] = ""
	color: Annotated[
		QColor,
		ColorField(),
		Tooltip("Uniform point color when vertex colors are unavailable or disabled."),
	]
	use_vertex_colors: Annotated[
		bool,
		Tooltip("When true and the file has RGB, render per-point colors instead of Color."),
	] = True
	point_size: Annotated[
		float,
		Range(1.0, 20.0, step=0.5, decimals=1),
		Tooltip("Point size in screen pixels."),
	] = 2.0
	opacity: Annotated[
		float,
		Range(0.0, 1.0, step=0.05, decimals=2),
		Tooltip("Actor opacity (0 = invisible, 1 = opaque)."),
	] = 1.0
	scale: Annotated[
		float,
		Range(0.001, 10000.0, step=1.0, decimals=3),
		Tooltip(
			"Uniform multiplier applied to XYZ at load. Default 1000 converts "
			"metre-scale clouds to engine millimetres; use 1 if the file is already in mm."
		),
	] = 1.0
	use_downsampled_cloud: Annotated[
		bool,
		Group("Downsample"),
		Order(0),
		Tooltip(
			"When on, the viewport and PointCloudCollider use the baked LOD. "
			"When off, the original file_path is used. Run Downsample first."
		),
	]
	downsample_ratio: Annotated[
		float,
		Range(MIN_DOWNSAMPLE_RATIO, MAX_DOWNSAMPLE_RATIO, step=0.01, decimals=2),
		Group("Downsample"),
		Order(1),
		Tooltip("Fraction of points to keep (Mesh Decimate analogue). 0.2 keeps 20%."),
	]
	downsampled_path: Annotated[
		str,
		Group("Downsample"),
		Order(2),
		ReadOnly(),
		FilePath(_LOD_FILE_FILTER),
		Tooltip(
			"Baked lighter PLY written by Downsample. Used only when Use Downsampled Cloud is on."
		),
	]

	def __init__(
		self,
		file_path: str = "",
		color: QColor | None = None,
		use_vertex_colors: bool = True,
		point_size: float = 2.0,
		opacity: float = 1.0,
		scale: float = 1.0,
		downsample_ratio: float = DEFAULT_DOWNSAMPLE_RATIO,
		use_downsampled_cloud: bool = False,
		downsampled_path: str = "",
	) -> None:
		self.file_path = str(file_path or "")
		self.color = color or QColor(200, 200, 200)
		self.use_vertex_colors = bool(use_vertex_colors)
		try:
			self.point_size = float(point_size)
		except Exception:
			self.point_size = 2.0
		try:
			op = float(opacity)
		except Exception:
			op = 1.0
		self.opacity = max(0.0, min(1.0, op))
		try:
			sc = float(scale)
		except Exception:
			sc = 1000.0
		self.scale = sc if sc > 0.0 else 1000.0
		self.downsample_ratio = float(downsample_ratio)
		self.use_downsampled_cloud = bool(use_downsampled_cloud)
		self.downsampled_path = str(downsampled_path or "")
		# Bumped when the file contents change in place (Capture / Downsample).
		# Viewport fingerprints this instead of mtime, so a write still in
		# progress cannot trigger a mid-file reload. PointCloudCollider only
		# follows it when auto_update is on. Scan Mission holds the viewport
		# reload so each cell does not rebuild the VTK actor.
		self._content_revision = 0
		self._live_reload_held = False

	def content_revision(self) -> int:
		return int(getattr(self, "_content_revision", 0) or 0)

	def bump_content_revision(self) -> int:
		self._content_revision = self.content_revision() + 1
		return self._content_revision

	def live_reload_held(self) -> bool:
		return bool(getattr(self, "_live_reload_held", False))

	def hold_live_reload(self) -> None:
		"""Skip VTK actor rebuilds until :meth:`release_live_reload`."""
		self._live_reload_held = True

	def release_live_reload(self) -> None:
		self._live_reload_held = False

	def can_downsample(self) -> bool:
		"""True when this cloud has a source file that can be baked to an LOD PLY."""
		return bool(str(self.file_path or "").strip())

	def effective_file_path(self) -> str:
		"""Path used for viewport / collision: LOD when enabled and present, else file_path."""
		if bool(self.use_downsampled_cloud):
			lod = str(self.downsampled_path or "").strip()
			if lod:
				return lod
		return str(self.file_path or "")

	@inspector_button(
		"Downsample",
		tooltip=(
			"Bake a lighter PLY (linear keep-fraction: 0.5 keeps ~50% of points) from file_path. "
			"The original file is kept. Turn on Use Downsampled Cloud so the viewport "
			"and PointCloudCollider use the LOD. Vertex picks on this cloud are stale "
			"while the LOD is shown."
		),
		group="Downsample",
		order=10,
	)
	def downsample(self):
		"""Bake an LOD PLY onto downsampled_path (undoable)."""
		from pathlib import Path

		from PyQt6.QtWidgets import QMessageBox

		from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read
		from MotionStudio.utils.point_cloud_downsample import (
			clamp_downsample_ratio,
			downsample_point_cloud_to_ply,
		)

		if not self.can_downsample():
			QMessageBox.warning(
				None,
				"Downsample",
				"Downsample requires a point-cloud file.",
			)
			return False, "downsample requires a point-cloud file"

		entity = self.entity
		scene = entity.scene if entity is not None else None
		project_root = scene.project_root if scene is not None else None
		abs_path = resolve_mesh_path_for_read(project_root, self.file_path)
		if not abs_path or not Path(abs_path).is_file():
			QMessageBox.warning(
				None, "Downsample", f"Point cloud file not found:\n{self.file_path}"
			)
			return False, "point cloud file not found"

		source = Path(abs_path)
		if project_root is not None:
			out_dir = Path(project_root) / "models"
		else:
			out_dir = source.parent
		ratio = clamp_downsample_ratio(self.downsample_ratio)

		def _run():
			return downsample_point_cloud_to_ply(source, out_dir, ratio)

		def _apply(result) -> None:
			stored = str(result.dest)
			if project_root is not None:
				try:
					stored = (
						result.dest.resolve()
						.relative_to(Path(project_root).resolve())
						.as_posix()
					)
				except ValueError:
					stored = str(result.dest)
			self._commit_downsampled_path(stored)
			QMessageBox.information(
				None,
				"Downsample",
				(
					f"Wrote {stored} ({result.points_before} → {result.points_after} points).\n\n"
					"Use Downsampled Cloud is on. Turn it off to show the original file. "
					"While the LOD is shown, Vertex picks on this cloud are stale."
				),
			)

		loading = scene.loading_controller if scene is not None else None
		if loading is None:
			try:
				_apply(_run())
			except (FileNotFoundError, OSError) as exc:
				QMessageBox.warning(None, "Downsample", str(exc))
				return False, str(exc)
			return True, "downsampled"

		def _on_error(exc: Exception) -> None:
			QMessageBox.warning(None, "Downsample", str(exc))

		if not loading.run("Downsampling point cloud...", _run, _apply, on_error=_on_error):
			QMessageBox.warning(
				None, "Downsample", "Another load operation is already in progress."
			)
			return False, "another load operation is already in progress"
		return True, "downsampling"

	def _commit_downsampled_path(self, stored_path: str) -> None:
		"""Store the LOD path and enable Use Downsampled Cloud (undoable)."""
		self.bump_content_revision()
		old_path = str(self.downsampled_path or "")
		old_use = bool(self.use_downsampled_cloud)
		need_path = stored_path != old_path
		need_use = not old_use
		if not need_path and not need_use:
			# File was overwritten in place; path/toggle did not change.
			entity = self.entity
			if entity is not None and entity.scene is not None:
				entity.scene.events.entity_changed.emit(entity.id)
			return
		entity = self.entity
		scene = entity.scene if entity is not None else None
		stack = _editor_undo_stack()
		if scene is not None and entity is not None and stack is not None:
			from MotionStudio.core.undo.commands import PropertyChangeCommand

			stack.beginMacro("PointCloud.Downsample")
			try:
				if need_path:
					stack.push(
						PropertyChangeCommand(
							scene,
							entity.id,
							self.type_name,
							"downsampled_path",
							old_path,
							stored_path,
							text="PointCloud.downsampled_path",
						)
					)
				if need_use:
					stack.push(
						PropertyChangeCommand(
							scene,
							entity.id,
							self.type_name,
							"use_downsampled_cloud",
							old_use,
							True,
							text="PointCloud.use_downsampled_cloud",
						)
					)
			finally:
				stack.endMacro()
			return
		self.downsampled_path = stored_path
		self.use_downsampled_cloud = True


def _editor_undo_stack():
	"""Best-effort QUndoStack from the editor main window."""
	try:
		from PyQt6.QtWidgets import QApplication

		app = QApplication.instance()
		if app is None:
			return None
		for widget in app.topLevelWidgets():
			stack = getattr(widget, "_undo_stack", None)
			if stack is not None:
				return stack
	except Exception:
		return None
	return None

"""Brand-agnostic hardware robot controller.

Not ``@register_component`` — it does not appear in Add Component. Bind
``Optional[Robot]`` on a job component to accept UniversalRobot or a future
Fanuc (or other) subclass. ``Entity.get_component(Robot)`` uses
``isinstance``, so those concrete drivers match.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar

from PyQt6.QtGui import QVector3D

from MotionStudio.core.ecs.component import Component
from MotionStudio.core.hardwares.hardware_runtime import HardwareJobListener


class Robot(Component, ABC):
	"""Controller that can ``movel`` / halt / digital I/O / live-joint sync on a live arm.

	Distinct from ``RobotDescription`` (virtual URDF). Concrete classes keep
	their own ``type_name`` (e.g. ``UniversalRobot``).
	"""

	type_name: ClassVar[str] = "Robot"
	category: ClassVar[str] = "Hardware/Robots"
	description: ClassVar[str] = (
		"Abstract hardware robot. Assign a UniversalRobot (or other Robot "
		"subclass) entity; do not add this type from the Inspector."
	)

	@abstractmethod
	def add_job_listener(self, callback: HardwareJobListener) -> None:
		"""Register ``callback(kind, success, message)`` for worker jobs."""

	@abstractmethod
	def remove_job_listener(self, callback: HardwareJobListener) -> None:
		"""Unregister a listener added with ``add_job_listener``."""

	@abstractmethod
	def set_move_target(self, position_mm: QVector3D, rotation_rotvec: QVector3D) -> None:
		"""Store the next Cartesian target (mm, UR rotation vector in degrees)."""

	@abstractmethod
	def move_to_target(self) -> Any:
		"""Queue a Cartesian move to this component's target pose."""

	@abstractmethod
	def stop_robot(self) -> Any:
		"""Halt motion and cancel an in-flight move / program wait."""

	@abstractmethod
	def set_io_target(self, bank: str, port: int, state: bool) -> None:
		"""Store the next digital pin (PathAction bank id, port, High/Low)."""

	@abstractmethod
	def apply_io(self) -> Any:
		"""Write a digital output or read a digital input (queued worker job)."""

	@abstractmethod
	def read_io(self) -> Any:
		"""Read a digital input or output pin into ``io_value`` (queued worker job)."""

	@abstractmethod
	def apply_actual_configuration(self) -> Any:
		"""Read live joint angles from the controller and apply them to RobotDescription."""

	@abstractmethod
	def read_tcp_pose(self) -> Any:
		"""Queue a worker read of the live TCP origin in the hardware robot base."""

	@abstractmethod
	def jog_tcp(self, axis: str, delta: float) -> Any:
		"""Queue a live-TCP jog in the hardware robot base.

		``axis`` is ``x`` / ``y`` / ``z`` / ``rx`` / ``ry`` / ``rz``. Translation
		``delta`` is millimetres; rotation ``delta`` is degrees. Reads the
		current TCP, increments that axis, then ``movel``s.
		"""

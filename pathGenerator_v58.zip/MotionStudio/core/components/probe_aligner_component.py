"""Aim a Z-up cylinder probe at a TCP and scale its length to reach it."""

from __future__ import annotations

from typing import Annotated, Optional

from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.debug import Debug
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.core.transform.utils import (
	set_world_rotation_quat,
	transform_point,
	world_position,
)
from MotionStudio.ui.inspector.metadata import (
	Order,
	Range,
	Tooltip,
	inspector_button,
)

_EPS_MM = 1e-6


@register_component
class ProbeAlignerComponent(Component):
	type_name = "ProbeAligner"
	category = "Alignment and datum"
	description = (
		"<p><b>Probe Aligner</b></p>"
		"<p>Aims this entity (a cylinder mesh: origin on the circular base, "
		"+Z along the axis) at a TCP and scales <b>Z</b> so the shaft reaches "
		"the TCP minus an offset.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Put this component on the probe entity. Assign <b>tcp</b> to the "
		"TCP Transform (usually the RobotIK TCP under <code>tool0</code>).</li>"
		"<li>Set <b>default_length</b> to the cylinder height in millimetres "
		"when Z-scale is 1.0.</li>"
		"<li>Click <b>Align</b>. Local +Z points at the TCP. Z-scale becomes "
		"<code>(distance − offset) / default_length</code>. X/Y scale is unchanged. "
		"<b>offset</b> (default 5 mm) shortens the tip so it does not sit on the TCP.</li>"
		"</ul>"
	)

	tcp: Annotated[
		Optional[TransformComponent],
		Order(0),
		Tooltip(
			"TCP Transform to aim at (entity picker). Align uses its world position."
		),
	] = None
	default_length: Annotated[
		float,
		Order(10),
		Range(0.01, 10000.0, step=0.1, decimals=2),
		Tooltip(
			"Cylinder height along +Z in millimetres when this entity's Z-scale is 1.0."
		),
	] = 100.0
	offset: Annotated[
		float,
		Order(20),
		Range(0.0, 1000.0, step=0.5, decimals=2),
		Tooltip(
			"Millimetres to leave between the probe tip and the TCP (default 5)."
		),
	] = 5.0

	def __init__(
		self,
		default_length: float = 100.0,
		offset: float = 5.0,
	) -> None:
		self.tcp = None
		self.default_length = float(default_length)
		self.offset = float(offset)

	@inspector_button(
		"Align",
		tooltip=(
			"Point this probe's +Z at the TCP and set Z-scale so length is "
			"distance minus offset (uses default_length at Z-scale 1)"
		),
		order=0,
	)
	def align(self):
		entity = self.entity
		if entity is None:
			return False, "no entity"
		xform = entity.get_component(TransformComponent)
		if xform is None:
			return False, "entity has no Transform"

		tcp = self._resolved_tcp()
		if tcp is None or tcp.entity is None:
			return False, "assign tcp"
		if tcp.entity is entity:
			return False, "tcp must be a different entity"

		origin = world_position(entity)
		target_pos = world_position(tcp.entity)
		delta = target_pos - origin
		distance = float(delta.length())
		if distance < _EPS_MM:
			return False, "probe origin and TCP coincide"

		try:
			default_len = float(self.default_length)
		except (TypeError, ValueError):
			default_len = 0.0
		if default_len <= _EPS_MM:
			return False, "default_length must be greater than 0"

		try:
			gap = float(self.offset)
		except (TypeError, ValueError):
			gap = 0.0
		if gap < 0.0:
			gap = 0.0
		reach = distance - gap
		if reach <= _EPS_MM:
			return False, f"offset ({gap:g} mm) is not smaller than distance ({distance:g} mm)"

		direction = QVector3D(delta)
		direction.normalize()
		world_rot = QQuaternion.rotationTo(QVector3D(0.0, 0.0, 1.0), direction)
		set_world_rotation_quat(entity, world_rot)

		sx = float(xform.scale.x())
		sy = float(xform.scale.y())
		xform.scale = QVector3D(sx, sy, 1.0)
		tip = transform_point(entity, QVector3D(0.0, 0.0, default_len))
		measured = float((tip - world_position(entity)).length())
		if measured <= _EPS_MM:
			return False, "could not measure default length in world (degenerate scale)"
		z_scale = reach / measured
		xform.scale = QVector3D(sx, sy, z_scale)

		Debug.log(
			f"ProbeAligner: distance {distance:.3f} mm, reach {reach:.3f} mm, "
			f"z-scale {z_scale:.6g} (default_length {default_len:g} mm)"
		)
		return None

	def _resolved_tcp(self) -> Optional[TransformComponent]:
		value = self.tcp
		if isinstance(value, TransformComponent):
			return value
		entity = self.entity
		if isinstance(value, str) and entity is not None and entity.scene is not None:
			ent = entity.scene.find_by_id(value)
			if ent is not None:
				comp = ent.get_component(TransformComponent)
				if comp is not None:
					self.tcp = comp
					return comp
		return None

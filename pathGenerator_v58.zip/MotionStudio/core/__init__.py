__all__ = ["ecs", "Debug"]


def __getattr__(name: str):
	# Lazy so SDK helper processes (core.hardwares.sdk_host) can import
	# MotionStudio.core.hardwares without loading Qt.
	if name == "Debug":
		from .debug import Debug

		return Debug
	raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

# TCP Commands

Drive Motion Studio from an external app: `RUN` presses an Inspector button,
`EDIT` changes an Inspector value, `GET` reads one, `WAIT` pauses for a number
of seconds. If you can click, type, or see it in the Inspector, you can send
it — nothing else is reachable (except `WAIT`).

**Connect** to `127.0.0.1:5555` (default). Toggle it, change the port, or set the
command timeout in **Edit → Preferences… → TCP Command Server**, or in the
`[tcp]` section of `preferences.ini` (`host` is file-only; loopback by default,
no authentication).

## Format

One UTF-8 line per command, `\n` terminated. One reply per command. The
connection stays open.

```
RUN,<entity>,<component>,<function>
EDIT,<entity>,<component>,<property>,<value>
GET,<entity>,<component>,<property>
WAIT,<seconds>
```

Every reply — for all four verbs, success or failure — is a single-line JSON
object with the same two keys:

```json
{"status": "PASS", "return": ""}
```

- **`status`** is `"PASS"` or `"FAIL"`. `PASS` means the action actually
  succeeded, not just that the command was understood.
- **`return`** is the return value on `PASS`, the reason on `FAIL`, and `""`
  when there is nothing to report. It is **always a string and always present**,
  so you never have to check whether the key exists.

Fields in the *request* are trimmed and matched ignoring case and spaces.
Everything after the fourth comma of an `EDIT` is the value, so values may
contain commas — and because the reply is JSON, a returned value containing
commas is unambiguous. `WAIT` takes one number of seconds (`WAIT,1.5` or
`WAIT, 1.5`). Never send a blank line; it gets no reply.

```
> EDIT,UUT,Transform,position,150,0,25
< {"status": "PASS", "return": ""}
> GET,UUT,Transform,position
< {"status": "PASS", "return": "150,0,25"}
> GET,Cam,MechmindScanner,connection_status
< {"status": "PASS", "return": "Connected"}
> RUN,ur10e_robot,RobotDescription,Reset Pose
< {"status": "PASS", "return": ""}
> RUN,PlannerJob,MotionPlanner,Plan Motion
< {"status": "PASS", "return": "OK — 120 samples, traj 4.20s"}
> WAIT,1.5
< {"status": "PASS", "return": ""}
> GET,Ghost,Transform,position
< {"status": "FAIL", "return": "entity not found: Ghost"}
```

Reading a reply in Python is just:

```python
reply = json.loads(line)
if reply["status"] == "PASS":
    value = reply["return"]
else:
    raise RuntimeError(reply["return"])
```

`RUN` and `GET` need four fields — `RUN,ur10e_robot,Reset Pose` is missing the
component. Use the button caption (`Plan Motion`) or the method name
(`plan_motion`). Entity names must be unique; a UUID also works.

## Copy from the Inspector

You do not have to type these lines by hand. With **one entity** selected:

- Right-click a **field name** → **Copy GET command** / **Copy EDIT command**.
  EDIT is filled with the live value (`EDIT,DefaultCube,Transform,position,1.5,0,25`).
  Read-only fields (`status`, connection badges) offer GET only.
- Right-click an Inspector **action button** → **Copy RUN command**
  (`RUN,DefaultCube,GPLeakPathGenerator,Generate leak path`). Left-click still
  runs the action.

The status bar flashes `Copied …`. Hover the name or button for a reminder.
This covers the same reflected fields and `@inspector_button`s that TCP can
reach, including those inside Group docks (Export…, Connection Settings, …).
Custom PathGeneration rows (segment Speed / CNT / Actions) and the Entity
**Name** field are not TCP properties, so they have no copy menu. Multi-select
does not copy (one command cannot name several entities).

## Sequencer dock

The **Sequencer** dock (**Window → Sequencer**) runs these same command lines
in order, without opening a socket. It calls the same dispatcher as the TCP
server, so a TCP client waits while a sequence step is in flight (and the
other way around). Paste lines copied from the Inspector.

The top ribbon **Play** / **Stop** drive the sequence file currently selected in the
dock. **Play** runs **Main Sequence**. **Stop** interrupts Main (a `WAIT` is
cancelled immediately) and then runs **Stop Sequence** — shutdown or cancel
lines for that program. Stop again aborts the stop sequence. Pause is unused.
The dock itself has no Play/Stop buttons. Tabs under the sequence dropdown
switch which command list you edit.

Play runs each non-blank Main line; the next line starts only after `PASS`, unless
the row's continue-on-fail icon is on (skip-forward). Natural completion or FAIL
does **not** run the Stop Sequence. Bad syntax is `FAIL` and honors Continue on fail.

`WAIT,<seconds>` pauses the sequence on the worker thread (the UI stays
responsive). A duration larger than the command timeout is `FAIL` without
sleeping. Hover the Sequencer info button for a short command summary.

Sequences are JSON files under `<project>/sequence/*.seq` (not inside
`project.scn`). The dropdown default is `default` (`sequence/default.seq`).
Edits autosave; **File → Save Project** also flushes the current sequence.
Open / New Project restores the last selected name from
`sequence/active.json`. Older files without `stop_steps` load an empty Stop
Sequence.

```json
{
  "name": "default",
  "steps": [
    { "command": "RUN,PlannerJob,MotionPlanner,Plan Motion", "continue_on_fail": false }
  ],
  "stop_steps": [
    { "command": "RUN,ur10e_robot,UniversalRobot,Disconnect", "continue_on_fail": true }
  ]
}
```

Replies are written to `logs.txt` under the action `sequencer` with the same
JSON shape as TCP.

## `EDIT` values

| Property type | Send | Example value |
| --- | --- | --- |
| number | any number | `30` |
| whole number | decimal or `0x` hex | `200` |
| yes/no | `true`/`false`, `1`/`0`, `yes`/`no`, `on`/`off` | `true` |
| text | verbatim, paths included | `C:/models/arm.glb` |
| dropdown | one of the listed choices | `ikpy` |
| vector | 3 numbers, commas and/or spaces | `150,0,25` |
| color | `#rrggbb`, a name, or `r,g,b[,a]` | `#ff8800` |
| component reference | name/UUID of the owning entity; `none` clears | `ur10e_robot` |

Ranges are **rejected, not clamped**: `{"status": "FAIL", "return": "value 99999
out of range [1, 120] for solve_hz"}`. Lists and other structured fields are not
editable remotely.

Remote edits use the normal undo stack — they appear in the status bar, in
`logs.txt`, and undo with Ctrl+Z. `GET` does not create an undo entry.

## `GET` values

The `return` string uses the same grammar as the `EDIT` table above, so you can
round-trip: `GET` a field, then later `EDIT` it with that exact text. Read-only
Inspector fields (`connection_status`, planner `status`, …) are readable. A
cleared component reference is `none`.

Values are always JSON **strings**, never JSON numbers or booleans — `GET` of a
number gives `"return": "30"` and of a checkbox `"return": "true"`. That is what
keeps the round-trip into `EDIT` exact; cast on your side if you need a number.

## Logging

Every command and every reply is written to `logs.txt` in the project folder, so
a sequence can be audited afterwards — `>` is what you sent, `<` is what you got
back, and the timestamps show how long each command took. The same line appears
on the editor status bar as it is written.

```
[2026-08-27 20:38:33] tcp: 127.0.0.1:49369 > RUN,PlannerJob,MotionPlanner,Plan Motion
[2026-08-27 20:38:36] tcp: 127.0.0.1:49369 < {"status": "PASS", "return": "OK — 120 samples, traj 4.20s"}
```

Inspector button clicks (not only TCP) write the same reply grammar under `inspector`:
`… Plan Motion clicked` when the button is pressed, then `… Plan Motion < {"status": …}` when that action's reply is ready. The Sequencer dock uses the same `>` / `<` JSON lines under `sequencer`, with a 1-based step index instead of a TCP peer.

## Timing

**The reply is the completion signal** — a command answers only when the action
has actually finished, and the UI stays responsive meanwhile. `Plan Motion`
replies when planning completes. Hardware **Connect** replies `PASS` only when
the camera/robot is connected (`FAIL` with `Error: …` otherwise). `Capture` / UR
**RUN** wait for the worker the same way.

Commands run one at a time across all TCP connections **and** the Sequencer
dock (shared dispatcher lock). Past `timeout_s` (300 s
default) you get `{"status": "FAIL", "return": "timeout after 300s: …"}`, but the
action itself keeps running. Set your client's socket timeout higher than
`timeout_s`.

## Failures

`"status": "FAIL"` is a failed step and `return` is the reason. Common ones:
`entity not found: X`, `multiple entities named X`,
`component not found: X on Y`, `function not found: X on Y`,
`property not found / is read-only: X on Y`, `expected GET,<entity>,<component>,<property>`, `expected one of [a, b] for X`,
`expected 3 numbers for a vector`, `value N out of range`, `X raised: …`.

A `FAIL` always carries a reason except when a button returns a bare `False`
with no message, which gives `{"status": "FAIL", "return": ""}`.

## Available commands

The Inspector is the authority — the labels and field names it shows are what
you send. Buttons currently available:

| Component | Functions |
| --- | --- |
| `MotionPlanner` | `Plan Motion`, `Clear Trajectory`, `Simulate`, `Stop simulate` |
| `RobotIK` | `Solve IK Now`, `Regenerate Analytical IK` |
| `RobotDescription` | `Reset Pose` |
| `ThreePointCalibration` | `Align`, `Clear` |
| `PathGeneration` | `Export...` |
| `MechmindScanner` | `Connect`, `Disconnect`, `Capture`, `Clear Scan` |
| `UniversalRobot` | `Connect`, `Disconnect`, `RUN`, `Move To Target`, `Apply I/O`, `STOP` |
| `LiftToSafety` | `Lift to safety`, `Cancel lift` |
| `GPLeakPathGenerator` | `Generate leak path`, `Cancel generate` |
| `ScanMission` | `Run Scan Mission`, `Stop Scan Mission` |
| `ToolTrace` | `Simulate`, `Stop simulate` |

Editable properties include `Transform.position/rotation/scale` (rotation is
Euler degrees), `Mesh.shape/color`, the `MotionPlanner` backend and tuning
fields, `RobotIK.target/tcp/backend/solve_hz`, and the same for custom
components in `<Project>/Components/`.


Keep one connection open for the whole sequence, check `status` on every reply,
and rely on replies instead of sleeps.


#!/usr/bin/env python3
"""
Motion Studio project launcher.

Shows a small startup window with **New Project** and **Open Project**, then
launches the main editor with that project directory set (and the scene loaded
when opening an existing project).

Usage:
    python launcher.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("QT_API", "pyqt6")

_BASE_DIR = Path(__file__).resolve().parent
if str(_BASE_DIR) not in sys.path:
	sys.path.insert(0, str(_BASE_DIR))

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtWidgets import (
	QApplication,
	QFileDialog,
	QFrame,
	QInputDialog,
	QLabel,
	QMessageBox,
	QPushButton,
	QVBoxLayout,
	QWidget,
)

import qdarktheme
from MotionStudio.core.preferences import apply_preferences, load_preferences
from MotionStudio.core.project_components import discover_all_components
from MotionStudio.platform.windows_taskbar import configure_windows_taskbar_identity
from MotionStudio.ui.main_window import MainWindow
from resources.resources_rc import load_application_icon


def _default_projects_parent() -> Path:
	return _BASE_DIR


class ProjectLauncherWindow(QWidget):
	"""Compact startup chooser: create a new project or open an existing one."""

	finished = pyqtSignal()

	def __init__(self) -> None:
		super().__init__()
		self.setWindowTitle("Motion Studio")
		self.setFixedSize(420, 260)
		self.setWindowFlags(
			Qt.WindowType.Window
			| Qt.WindowType.WindowCloseButtonHint
			| Qt.WindowType.WindowTitleHint
		)

		root = QVBoxLayout(self)
		root.setContentsMargins(28, 28, 28, 28)
		root.setSpacing(14)

		title = QLabel("Motion Studio", self)
		title_font = title.font()
		title_font.setPointSize(18)
		title_font.setBold(True)
		title.setFont(title_font)
		title.setAlignment(Qt.AlignmentFlag.AlignCenter)
		root.addWidget(title)

		subtitle = QLabel("Create a new project or open an existing one to continue.", self)
		subtitle.setWordWrap(True)
		subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
		subtitle.setStyleSheet("color: #a8a8a8;")
		root.addWidget(subtitle)

		divider = QFrame(self)
		divider.setFrameShape(QFrame.Shape.HLine)
		divider.setStyleSheet("color: #444;")
		root.addWidget(divider)

		root.addSpacing(4)

		new_btn = QPushButton("New Project…", self)
		new_btn.setMinimumHeight(40)
		new_btn.setCursor(Qt.CursorShape.PointingHandCursor)
		new_btn.clicked.connect(self._on_new_project)
		root.addWidget(new_btn)

		open_btn = QPushButton("Open Project…", self)
		open_btn.setMinimumHeight(40)
		open_btn.setCursor(Qt.CursorShape.PointingHandCursor)
		open_btn.clicked.connect(self._on_open_project)
		root.addWidget(open_btn)

		root.addStretch(1)

		self._result_project: Path | None = None
		self._result_load_scene = False
		self._emitted_finished = False

	@property
	def selected_project(self) -> Path | None:
		return self._result_project

	@property
	def should_load_scene(self) -> bool:
		return self._result_load_scene

	def _emit_finished(self) -> None:
		if self._emitted_finished:
			return
		self._emitted_finished = True
		self.finished.emit()

	def closeEvent(self, event) -> None:  # type: ignore[override]
		super().closeEvent(event)
		self._emit_finished()

	def _accept(self, project_dir: Path, *, load_scene: bool) -> None:
		self._result_project = project_dir
		self._result_load_scene = load_scene
		self.close()

	def _on_new_project(self) -> None:
		name, ok = QInputDialog.getText(
			self,
			"New Project",
			"Enter project name:",
			text="New Project",
		)
		if not ok or not name.strip():
			return

		project_name = MainWindow.sanitize_project_name(name)
		if not project_name:
			QMessageBox.warning(self, "New Project", "Invalid project name.")
			return

		parent_dir = QFileDialog.getExistingDirectory(
			self,
			"Select Location for New Project",
			str(_default_projects_parent()),
		)
		if not parent_dir:
			return

		project_path = Path(parent_dir) / project_name
		if project_path.exists():
			reply = QMessageBox.question(
				self,
				"Project Exists",
				f"A folder named '{project_name}' already exists at:\n{project_path}\n\n"
				"Do you want to use it?",
				QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
				QMessageBox.StandardButton.No,
			)
			if reply != QMessageBox.StandardButton.Yes:
				return
		else:
			try:
				project_path.mkdir(parents=True, exist_ok=True)
			except Exception as exc:
				QMessageBox.critical(self, "New Project", f"Failed to create project folder:\n{exc}")
				return

		self._accept(project_path, load_scene=False)

	def _on_open_project(self) -> None:
		dir_path = QFileDialog.getExistingDirectory(
			self,
			"Open Project Folder",
			str(_default_projects_parent()),
		)
		if not dir_path:
			return

		project_path = Path(dir_path)
		scene_path = MainWindow._find_scene_path(project_path)
		if scene_path is None:
			reply = QMessageBox.question(
				self,
				"Open Project",
				"No .scn file found in the selected folder.\n\n"
				"Open it as an empty project anyway?",
				QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
				QMessageBox.StandardButton.Yes,
			)
			if reply != QMessageBox.StandardButton.Yes:
				return
			self._accept(project_path, load_scene=False)
			return

		self._accept(project_path, load_scene=True)


def launch_main_window(app: QApplication, project_dir: Path, *, load_scene: bool) -> int:
	"""Create and show MainWindow for ``project_dir``. Returns ``app.exec()`` code."""
	discover_all_components(project_dir)

	window = MainWindow(
		project_dir,
		load_scene_on_start=load_scene,
		spawn_demo=False,
	)
	app_icon = load_application_icon()
	if app_icon is not None:
		window.setWindowIcon(app_icon)
	window.show()
	window.raise_()
	window.activateWindow()
	return app.exec()


def main() -> None:
	# Defense: if something still spawns ``iMOVE.exe -m <module> ...`` (frozen
	# PyInstaller sets sys.executable to the GUI), dispatch that module instead
	# of opening a second launcher window.
	if getattr(sys, "frozen", False) and len(sys.argv) >= 3 and sys.argv[1] == "-m":
		import runpy

		module_name = sys.argv[2]
		sys.argv = [sys.argv[0], *sys.argv[3:]]
		runpy.run_module(module_name, run_name="__main__", alter_sys=True)
		return

	configure_windows_taskbar_identity()

	app = QApplication(sys.argv)
	app.setQuitOnLastWindowClosed(False)
	app_icon = load_application_icon()
	if app_icon is not None:
		app.setWindowIcon(app_icon)

	qdarktheme.enable_hi_dpi()
	apply_preferences(load_preferences())

	from PyQt6.QtCore import QEventLoop

	launcher = ProjectLauncherWindow()
	if app_icon is not None:
		launcher.setWindowIcon(app_icon)

	loop = QEventLoop()
	launcher.finished.connect(loop.quit)
	launcher.show()
	loop.exec()

	project = launcher.selected_project
	load_scene = launcher.should_load_scene
	launcher.deleteLater()
	app.processEvents()

	if project is None:
		sys.exit(0)

	app.setQuitOnLastWindowClosed(True)
	sys.exit(launch_main_window(app, project, load_scene=load_scene))


if __name__ == "__main__":
	main()

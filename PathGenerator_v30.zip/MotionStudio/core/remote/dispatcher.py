"""Executes remote commands on the Qt main thread and reports the result.

Connection threads call :meth:`RemoteCommandDispatcher.execute`, which hands the
job to the main thread through a queued signal and blocks on a
:class:`threading.Event` until the job finishes. The Qt event loop therefore
stays responsive while the client socket waits.

``RUN`` can only reach methods decorated with ``@inspector_button`` and ``EDIT``
only fields the Inspector would render as editable, so the remote surface is
exactly what a user could click or type in the Inspector.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Tuple

from PyQt6.QtCore import QObject, Qt, pyqtSignal

from MotionStudio.core.remote.protocol import EDIT_OP, RemoteCommand, sanitize_output

if TYPE_CHECKING:
	from PyQt6.QtGui import QUndoStack

	from MotionStudio.core.ecs.component import Component
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene
	from MotionStudio.ui.inspector.reflection import FieldSpec


@dataclass
class _Job:
	"""One in-flight remote command."""

	command: RemoteCommand
	done: threading.Event = field(default_factory=threading.Event)
	ok: bool = False
	output: str = ""
	# Set while an asynchronous action (e.g. Plan Motion) is still running so
	# ``_run_job`` knows not to complete the job itself.
	pending: bool = False
	# Kept alive for the duration of an async wait (listener de-registration).
	cleanup: Optional[Callable[[], None]] = None

	def finish(self, ok: bool, output: object = None) -> None:
		if self.done.is_set():
			return
		self.ok = bool(ok)
		self.output = sanitize_output(output)
		cleanup = self.cleanup
		self.cleanup = None
		if cleanup is not None:
			try:
				cleanup()
			except Exception:
				pass
		self.done.set()


def _normalize_label(text: str) -> str:
	"""Fold a method name or button label for tolerant matching."""
	return "".join(ch for ch in str(text or "").lower() if ch.isalnum())


class RemoteCommandDispatcher(QObject):
	"""Resolves and runs ``RUN`` commands against the live scene."""

	_job_ready = pyqtSignal(object)

	def __init__(
		self,
		scene: "Scene",
		parent: Optional[QObject] = None,
		*,
		undo_stack: Optional["QUndoStack"] = None,
	) -> None:
		super().__init__(parent)
		self._scene = scene
		self._undo_stack = undo_stack
		self._job_ready.connect(self._run_job, Qt.ConnectionType.QueuedConnection)

	def set_undo_stack(self, undo_stack: Optional["QUndoStack"]) -> None:
		"""Route ``EDIT`` through the editor's undo stack so Ctrl+Z reverts it."""
		self._undo_stack = undo_stack

	# ------------------------------------------------------------------ public

	def execute(self, command: RemoteCommand, timeout_s: float) -> Tuple[bool, str]:
		"""Run ``command`` on the main thread; blocks the calling thread.

		Returns ``(ok, output)``. A command that outlives ``timeout_s`` reports
		failure, but the underlying action is not cancelled.
		"""
		job = _Job(command=command)
		self._job_ready.emit(job)
		if not job.done.wait(float(timeout_s)):
			return False, f"timeout after {float(timeout_s):.0f}s: {command.describe()}"
		return job.ok, job.output

	# ------------------------------------------------------------- main thread

	def _run_job(self, job: _Job) -> None:
		try:
			self._dispatch(job)
		except Exception as exc:
			job.finish(False, f"internal error: {exc}")
		if not job.pending and not job.done.is_set():
			job.finish(False, "command produced no result")

	def _dispatch(self, job: _Job) -> None:
		cmd = job.command

		entity, error = self._resolve_entity(cmd.entity)
		if entity is None:
			job.finish(False, error)
			return

		component, error = self._resolve_component(entity, cmd.component)
		if component is None:
			job.finish(False, error)
			return

		if cmd.op == EDIT_OP:
			self._dispatch_edit(job, entity, component)
			return
		self._dispatch_run(job, entity, component)

	def _dispatch_run(self, job: _Job, entity: "Entity", component: "Component") -> None:
		cmd = job.command
		method, error = self._resolve_button(component, cmd.member)
		if method is None:
			job.finish(False, error)
			return

		waiter = _ASYNC_HANDLERS.get(
			(str(getattr(component, "type_name", "")), method.__name__)
		)
		if waiter is not None:
			waiter(self._scene, entity, component, method, job)
			return

		try:
			result = method()
		except Exception as exc:
			job.finish(False, f"{cmd.member} raised: {exc}")
			return

		self._notify_entity_changed(entity)
		job.finish(True, result)

	def _dispatch_edit(self, job: _Job, entity: "Entity", component: "Component") -> None:
		from MotionStudio.core.remote.value_parser import coerce_value

		cmd = job.command
		spec, error = self._resolve_field(component, cmd.member)
		if spec is None:
			job.finish(False, error)
			return

		value, error = coerce_value(spec, cmd.value or "", self._scene)
		if error:
			job.finish(False, error)
			return

		try:
			self._apply_field_change(entity, component, spec, value)
		except Exception as exc:
			job.finish(False, f"could not set {cmd.member}: {exc}")
			return

		job.finish(True, None)

	def _apply_field_change(
		self,
		entity: "Entity",
		component: "Component",
		spec: "FieldSpec",
		value: Any,
	) -> None:
		"""Write the field the same way the Inspector does (undoable when possible)."""
		from MotionStudio.core.undo.commands import PropertyChangeCommand
		from MotionStudio.ui.inspector.reflection import clone_value

		old = clone_value(spec.getter())
		if old == value:
			return
		if self._undo_stack is None:
			spec.setter(value)
			return
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		self._undo_stack.push(
			PropertyChangeCommand(
				self._scene,
				entity.id,
				comp_type,
				spec.name,
				old,
				clone_value(value),
				text=f"{comp_type}.{spec.name}",
			)
		)

	# -------------------------------------------------------------- resolution

	def _resolve_entity(self, key: str) -> Tuple[Optional["Entity"], str]:
		matches = [e for e in self._scene.entities() if e.name == key]
		if len(matches) == 1:
			return matches[0], ""
		if len(matches) > 1:
			return None, f"multiple entities named {key}"
		by_id = self._scene.find_by_id(key)
		if by_id is not None:
			return by_id, ""
		return None, f"entity not found: {key}"

	@staticmethod
	def _resolve_component(
		entity: "Entity", type_name: str
	) -> Tuple[Optional["Component"], str]:
		wanted = _normalize_label(type_name)
		for comp in entity.components:
			if _normalize_label(getattr(comp, "type_name", comp.__class__.__name__)) == wanted:
				return comp, ""
		return None, f"component not found: {type_name} on {entity.name}"

	@staticmethod
	def _resolve_button(
		component: "Component", function: str
	) -> Tuple[Optional[Callable[[], Any]], str]:
		from MotionStudio.ui.inspector.metadata import collect_inspector_buttons

		buttons = collect_inspector_buttons(component)
		wanted = _normalize_label(function)
		for method_name, (spec, bound) in buttons.items():
			if _normalize_label(method_name) == wanted:
				return bound, ""
		for method_name, (spec, bound) in buttons.items():
			if _normalize_label(spec.label) == wanted:
				return bound, ""
		type_name = getattr(component, "type_name", component.__class__.__name__)
		return None, f"function not found: {function} on {type_name}"

	@staticmethod
	def _resolve_field(
		component: "Component", property_name: str
	) -> Tuple[Optional["FieldSpec"], str]:
		from MotionStudio.ui.inspector.metadata import ReadOnly
		from MotionStudio.ui.inspector.reflection import iter_editable_fields

		type_name = getattr(component, "type_name", component.__class__.__name__)
		wanted = _normalize_label(property_name)
		# Hidden fields never appear here, matching what the Inspector shows.
		for spec in iter_editable_fields(component):
			if _normalize_label(spec.name) != wanted:
				continue
			if any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata):
				return None, f"property is read-only: {spec.name} on {type_name}"
			if spec.setter is None:
				return None, f"property is not writable: {spec.name} on {type_name}"
			return spec, ""
		return None, f"property not found: {property_name} on {type_name}"

	def _notify_entity_changed(self, entity: "Entity") -> None:
		try:
			self._scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass


# --------------------------------------------------------------------- async

def _wait_for_plan(
	scene: "Scene",
	entity: "Entity",
	component: "Component",
	method: Callable[[], Any],
	job: _Job,
) -> None:
	"""Run Plan Motion and keep the job open until the planner reports back."""
	system = getattr(scene, "motion_planning_system", None)
	if system is None:
		job.finish(False, "motion planning system unavailable")
		return

	job_entity_id = entity.id

	def _on_plan_finished(finished_id: str, success: bool, message: str) -> None:
		if finished_id != job_entity_id:
			return
		job.finish(bool(success), message)

	system.add_plan_listener(_on_plan_finished)
	job.cleanup = lambda: system.remove_plan_listener(_on_plan_finished)
	job.pending = True

	try:
		method()
	except Exception as exc:
		job.pending = False
		job.finish(False, f"plan_motion raised: {exc}")
		return

	if job.done.is_set():
		job.pending = False
		return

	# ``submit_plan`` rejects invalid setups synchronously (no worker started),
	# in which case the listener will never fire.
	if not system.is_busy(job_entity_id):
		job.pending = False
		job.finish(False, "planning did not start (see Motion Studio for details)")


_ASYNC_HANDLERS: Dict[Tuple[str, str], Callable[..., None]] = {
	("MotionPlanner", "plan_motion"): _wait_for_plan,
}

"""Wire format for the TCP command server.

Requests (one UTF-8 line, ``\\n`` terminated)::

	RUN,<entity_name>,<component_type_name>,<function_name>
	EDIT,<entity_name>,<component_type_name>,<property_name>,<value>

Response (one UTF-8 line, ``\\n`` terminated)::

	1               success with nothing to report
	1,<output>      success carrying a return value
	0,<reason>      failure

Splitting is bounded so only the leading fields are structural: a ``RUN`` line
splits into four fields and an ``EDIT`` line into five, which lets a value carry
commas (``EDIT,Cube,Transform,position,10,20,30``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

RUN_OP = "RUN"
EDIT_OP = "EDIT"
RESPONSE_TERMINATOR = "\n"

_USAGE = {
	RUN_OP: "expected RUN,<entity>,<component>,<function>",
	EDIT_OP: "expected EDIT,<entity>,<component>,<property>,<value>",
}


@dataclass(frozen=True)
class RemoteCommand:
	"""A parsed request line.

	``member`` is the button name for ``RUN`` and the property name for
	``EDIT``; ``value`` is only set for ``EDIT``.
	"""

	op: str
	entity: str
	component: str
	member: str
	value: Optional[str] = None

	def describe(self) -> str:
		suffix = f" = {self.value}" if self.value is not None else ""
		return f"{self.op} {self.entity}.{self.component}.{self.member}{suffix}"


def parse_command(line: str) -> Tuple[Optional[RemoteCommand], str]:
	"""Parse one request line.

	Returns ``(command, "")`` on success or ``(None, reason)`` on a malformed
	line. The verb is case-insensitive and every field except the ``EDIT``
	value is stripped.
	"""
	text = str(line or "").strip()
	if not text:
		return None, "empty command"

	op = text.split(",", 1)[0].strip().upper()
	if op not in _USAGE:
		return None, f"unknown command: {text.split(',', 1)[0].strip()}"

	field_count = 4 if op == RUN_OP else 5
	parts = text.split(",", field_count - 1)
	if len(parts) < field_count:
		return None, _USAGE[op]

	entity = parts[1].strip()
	component = parts[2].strip()
	member = parts[3].strip()
	# Keep the value verbatim apart from surrounding whitespace so vectors,
	# colors, and paths survive intact.
	value = parts[4].strip() if op == EDIT_OP else None

	if not entity:
		return None, "entity name is empty"
	if not component:
		return None, "component name is empty"
	if not member:
		return None, ("property name is empty" if op == EDIT_OP else "function name is empty")

	return RemoteCommand(op=op, entity=entity, component=component, member=member, value=value), ""


def sanitize_output(value: object) -> str:
	"""Flatten a value to a single response line.

	``None`` becomes a blank output (per protocol); everything else is stringified
	with newlines collapsed so one response always occupies one line.
	"""
	if value is None:
		return ""
	text = str(value)
	text = text.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
	return " ".join(text.split())


def format_response(ok: bool, output: object = None) -> str:
	"""Build ``"1,<output>\\n"`` / ``"0,<output>\\n"``.

	With nothing to report the comma is dropped too, so a bare success is ``"1"``
	rather than ``"1,"``.
	"""
	status = "1" if ok else "0"
	text = sanitize_output(output)
	if not text:
		return f"{status}{RESPONSE_TERMINATOR}"
	return f"{status},{text}{RESPONSE_TERMINATOR}"

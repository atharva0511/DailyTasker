"""Cast an ``EDIT`` command's string payload to a component field's type.

Field types come from the same reflection the Inspector uses
(:mod:`MotionStudio.ui.inspector.reflection`), so remote edits accept the values
a user could type into the corresponding widget. Anything the Inspector cannot
edit as a scalar (dicts, lists) is rejected rather than guessed at.
"""

from __future__ import annotations

import typing
from typing import TYPE_CHECKING, Any, Optional, Tuple, get_args, get_origin

from MotionStudio.ui.inspector.metadata import Range
from MotionStudio.ui.inspector.reflection import is_literal_type, literal_choices

if TYPE_CHECKING:
	from MotionStudio.core.scene.scene import Scene
	from MotionStudio.ui.inspector.reflection import FieldSpec

_TRUE_TOKENS = {"1", "true", "yes", "on", "enabled"}
_FALSE_TOKENS = {"0", "false", "no", "off", "disabled"}
_NONE_TOKENS = {"", "none", "null", "nil"}


def _split_numbers(raw: str) -> list:
	"""Split ``"1,2 3"`` into ``["1", "2", "3"]`` (comma and/or whitespace)."""
	return [part for part in raw.replace(",", " ").split() if part]


def _range_of(spec: "FieldSpec") -> Optional[Range]:
	for meta in spec.metadata:
		if isinstance(meta, Range):
			return meta
	return None


def _check_range(spec: "FieldSpec", value: float) -> str:
	rng = _range_of(spec)
	if rng is None:
		return ""
	if value < float(rng.min) or value > float(rng.max):
		return f"value {value:g} out of range [{rng.min:g}, {rng.max:g}] for {spec.name}"
	return ""


def _optional_component_type(typ: Any) -> Optional[type]:
	"""Return ``T`` for an ``Optional[T]`` component-reference annotation."""
	from MotionStudio.core.ecs.component import Component

	if get_origin(typ) is not typing.Union:
		return None
	for arg in get_args(typ):
		if arg is type(None):
			continue
		try:
			if issubclass(arg, Component):
				return arg
		except TypeError:
			continue
	return None


def _parse_bool(raw: str) -> Tuple[Any, str]:
	token = raw.strip().lower()
	if token in _TRUE_TOKENS:
		return True, ""
	if token in _FALSE_TOKENS:
		return False, ""
	return None, f"expected a boolean (true/false), got {raw!r}"


def _parse_vector3(raw: str) -> Tuple[Any, str]:
	from PyQt6.QtGui import QVector3D

	parts = _split_numbers(raw)
	if len(parts) != 3:
		return None, f"expected 3 numbers for a vector, got {raw!r}"
	try:
		x, y, z = (float(p) for p in parts)
	except ValueError:
		return None, f"expected 3 numbers for a vector, got {raw!r}"
	return QVector3D(x, y, z), ""


def _parse_color(raw: str) -> Tuple[Any, str]:
	from PyQt6.QtGui import QColor

	text = raw.strip()
	parts = _split_numbers(text)
	if len(parts) in (3, 4) and not text.startswith("#"):
		try:
			channels = [int(p) for p in parts]
		except ValueError:
			return None, f"expected integer color channels, got {raw!r}"
		if any(c < 0 or c > 255 for c in channels):
			return None, f"color channels must be 0-255, got {raw!r}"
		return QColor(*channels), ""

	color = QColor(text)
	if not color.isValid():
		return None, f"expected a color (#rrggbb, name, or r,g,b[,a]), got {raw!r}"
	return color, ""


def _parse_literal(spec: "FieldSpec", raw: str) -> Tuple[Any, str]:
	choices = literal_choices(spec.typ)
	token = raw.strip().lower()
	for choice in choices:
		if str(choice).lower() == token:
			return choice, ""
	allowed = ", ".join(str(c) for c in choices)
	return None, f"expected one of [{allowed}] for {spec.name}, got {raw!r}"


def _parse_component_reference(
	inner_type: type, raw: str, scene: Optional["Scene"]
) -> Tuple[Any, str]:
	if raw.strip().lower() in _NONE_TOKENS:
		return None, ""
	if scene is None:
		return None, "no scene available to resolve the reference"

	key = raw.strip()
	matches = [e for e in scene.entities() if e.name == key]
	if len(matches) > 1:
		return None, f"multiple entities named {key}"
	target = matches[0] if matches else scene.find_by_id(key)
	if target is None:
		return None, f"entity not found: {key}"

	component = target.get_component(inner_type)
	if component is None:
		wanted = getattr(inner_type, "type_name", inner_type.__name__)
		return None, f"entity {target.name} has no {wanted} component"
	return component, ""


def coerce_value(
	spec: "FieldSpec", raw: str, scene: Optional["Scene"] = None
) -> Tuple[Any, str]:
	"""Cast ``raw`` for the field described by ``spec``.

	Returns ``(value, "")`` or ``(None, reason)``. The declared annotation wins;
	when a field has no usable annotation the current value's runtime type is
	used instead.
	"""
	typ = spec.typ

	if is_literal_type(typ):
		return _parse_literal(spec, raw)

	inner_component = _optional_component_type(typ)
	if inner_component is not None:
		return _parse_component_reference(inner_component, raw, scene)

	current = None
	try:
		current = spec.getter()
	except Exception:
		pass

	if typ is bool or isinstance(current, bool):
		return _parse_bool(raw)

	if typ is int or (isinstance(current, int) and not isinstance(current, bool)):
		try:
			number = int(raw.strip(), 0) if raw.strip().lower().startswith("0x") else int(raw.strip())
		except ValueError:
			return None, f"expected an integer for {spec.name}, got {raw!r}"
		error = _check_range(spec, float(number))
		return (None, error) if error else (number, "")

	if typ is float or isinstance(current, float):
		try:
			number = float(raw.strip())
		except ValueError:
			return None, f"expected a number for {spec.name}, got {raw!r}"
		error = _check_range(spec, number)
		return (None, error) if error else (number, "")

	from PyQt6.QtGui import QColor, QVector3D

	if typ is QVector3D or isinstance(current, QVector3D):
		return _parse_vector3(raw)

	if typ is QColor or isinstance(current, QColor):
		return _parse_color(raw)

	if typ is str or isinstance(current, str) or current is None:
		return raw, ""

	type_label = getattr(typ, "__name__", str(typ))
	return None, f"unsupported field type {type_label} for {spec.name}"

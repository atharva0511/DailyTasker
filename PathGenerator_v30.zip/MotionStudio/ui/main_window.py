from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import QDockWidget, QMainWindow, QWidget, QFileDialog, QMessageBox, QMenuBar, QInputDialog, QStatusBar
from pathlib import Path
from typing import Optional, Union
from PyQt6.QtGui import QAction, QActionGroup, QKeySequence
from PyQt6.QtGui import QUndoStack
import os

from MotionStudio.render.vtk.window import create_vtk_container
from MotionStudio.render.vtk.scene_root import VtkSceneRoot
from MotionStudio.render.vtk.picking import VtkPickerBridge
from MotionStudio.render.vtk.path_bridge import VtkPathBridge
from MotionStudio.render.vtk.debug_draw_bridge import VtkDebugDrawBridge
from MotionStudio.render.vtk.viewport_frame_bridge import VtkViewportFrameBridge
from MotionStudio.ui.tools.path_tool_manager import PathToolManager
from MotionStudio.ui.tools.vertex_pick_tool_manager import VertexPickToolManager
from MotionStudio.ui.widgets.instruction_overlay import InstructionOverlay
from MotionStudio.ui.loading_controller import LoadingController
from MotionStudio.render.vtk.gizmo.translate_gizmo import VtkTranslateGizmo
from MotionStudio.render.vtk.gizmo.rotate_gizmo import VtkRotateGizmo
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.scene.play_mode import PlayModeManager
from MotionStudio.ui.hierarchy_panel import HierarchyPanel
from MotionStudio.ui.inspector_panel import InspectorPanel
from MotionStudio.ui.collision_matrix_panel import CollisionMatrixPanel
from MotionStudio.ui.widgets.play_mode_ribbon import PlayModeRibbon
from MotionStudio.core.components import TransformComponent
from MotionStudio.core.components import MeshComponent
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from PyQt6.QtGui import QVector3D
from MotionStudio.render.vtk.view_controls import reset_camera, set_solid, set_wireframe
from MotionStudio.core.logging.command_logger import CommandLogger
from MotionStudio.core.preferences import load_preferences
from MotionStudio.core.remote.dispatcher import RemoteCommandDispatcher
from MotionStudio.core.remote.tcp_server import TcpCommandServer
from MotionStudio.core.debug import Debug

class MainWindow(QMainWindow):
	"""
	Main editor window that hosts the VTK (PyVista) view and the editor docks.
	"""

	def __init__(
		self,
		project_dir: Optional[Union[Path, str]] = None,
		*,
		load_scene_on_start: bool = False,
		spawn_demo: bool = True,
	) -> None:
		super().__init__()
		self.setWindowTitle("Motion Studio")
		self._scene = Scene()
		self._selection = SelectionModel()
		self._selection.set_scene(self._scene)
		self._scene.set_selection_model(self._selection)
		self._undo_stack = QUndoStack(self)
		# Project directory: caller-provided (launcher) or default Test Project.
		if project_dir is not None:
			self._project_dir = Path(project_dir)
		else:
			self._project_dir = self._default_project_dir()
		self._scene.set_project_root(self._project_dir)
		self._load_scene_on_start = bool(load_scene_on_start)
		self._spawn_demo = bool(spawn_demo)
		# Ensure project directory exists for logging
		try:
			if not self._project_dir.exists():
				self._project_dir.mkdir(parents=True, exist_ok=True)
		except Exception:
			pass
		
		# Discover project components when MainWindow is created
		from MotionStudio.core.project_components import discover_project_components
		discovered = discover_project_components(self._project_dir)
		if discovered:
			print(f"Loaded {len(discovered)} project component(s) from {self._project_dir}: {', '.join(discovered)}", flush=True)
		
		# Command logger for logging command executions
		self._command_logger = CommandLogger(self._project_dir)
		# Track last undo stack index for detecting undo/redo
		self._last_undo_index = -1
		# Track if we can undo (to distinguish execute from redo)
		self._last_can_undo = False

		self._loading = LoadingController(self)
		# Same overlay as Open Project / Import URDF while Plan Motion runs.
		self._scene.motion_planning_system.set_loading_controller(self._loading)
		self._scene.motion_planning_system.set_command_logger(self._command_logger)
		# Initialize the central view
		self._init_menu()
		self._init_play_mode()
		self._init_central_view()
		self._init_docks()
		self._init_status_bar()
		self.resize(1280, 800)
		# Demo content after SceneRoot is ready (skipped when launched with a project)
		if self._spawn_demo:
			self._spawn_demo_content()

		# Remote control for third-party sequencers (Edit → Preferences → TCP).
		# The undo stack lets remote EDIT commands participate in Ctrl+Z.
		self._tcp_dispatcher = RemoteCommandDispatcher(
			self._scene, self, undo_stack=self._undo_stack
		)
		self._tcp_server: Optional[TcpCommandServer] = None
		self._start_tcp_server(load_preferences())

	def showEvent(self, event) -> None:  # type: ignore[override]
		super().showEvent(event)
		if self._load_scene_on_start:
			self._load_scene_on_start = False
			QTimer.singleShot(0, self._load_startup_project_scene)

	def _load_startup_project_scene(self) -> None:
		"""Load ``project.scn`` (or first ``.scn``) after the window is shown."""
		scene_path = self._find_scene_path(self._project_dir)
		if scene_path is None:
			self._status_bar.showMessage("Project opened (no .scn scene file found)", 4000)
			return
		self._load_project_scene(scene_path, show_success_dialog=False)

	@staticmethod
	def _find_scene_path(project_dir: Path) -> Optional[Path]:
		scene_path = project_dir / "project.scn"
		if scene_path.exists():
			return scene_path
		candidates = list(project_dir.glob("*.scn"))
		return candidates[0] if candidates else None

	@staticmethod
	def sanitize_project_name(name: str) -> str:
		"""Sanitize a user-entered project name for filesystem use."""
		project_name = name.strip()
		invalid_chars = '<>:"/\\|?*'
		for char in invalid_chars:
			project_name = project_name.replace(char, "_")
		return project_name.strip(". ")

	def apply_project_directory(self, project_dir: Path, *, discover: bool = True) -> None:
		"""Point the editor at ``project_dir`` (root, logger, optional components)."""
		self._project_dir = Path(project_dir)
		self._scene.set_project_root(self._project_dir)
		self._command_logger.set_project_root(self._project_dir)
		if discover:
			from MotionStudio.core.project_components import discover_project_components

			discovered = discover_project_components(self._project_dir)
			if discovered:
				print(
					f"Loaded {len(discovered)} project component(s) from {self._project_dir}: "
					f"{', '.join(discovered)}",
					flush=True,
				)

	def _clear_scene_state(self) -> None:
		for ent in list(self._scene.entities()):
			self._scene.delete_entity(ent)
		self._selection.set_current(None)
		self._undo_stack.clear()
		self._last_undo_index = -1
		self._last_can_undo = False

	def _default_project_dir(self) -> Path:
		try:
			repo_root = Path(__file__).resolve().parents[2]
		except Exception:
			repo_root = Path.cwd()
		return (repo_root / "Test Project")

	def _init_menu(self) -> None:
		menubar: QMenuBar = self.menuBar()
		file_menu = menubar.addMenu("File")
		edit_menu = menubar.addMenu("Edit")
		self._window_menu = menubar.addMenu("Window")
		view_menu = menubar.addMenu("View")

		act_new = QAction("New Project...", self)
		act_new.setShortcut(QKeySequence.StandardKey.New)
		act_new.triggered.connect(self._action_new_project)
		file_menu.addAction(act_new)

		act_open = QAction("Open Project...", self)
		act_open.setShortcut(QKeySequence.StandardKey.Open)
		act_open.triggered.connect(self._action_open_project)
		file_menu.addAction(act_open)

		act_save = QAction("Save Project", self)
		act_save.setShortcut(QKeySequence.StandardKey.Save)
		act_save.triggered.connect(self._action_save_project)
		file_menu.addAction(act_save)

		file_menu.addSeparator()

		act_exit = QAction("Exit", self)
		act_exit.triggered.connect(self.close)
		file_menu.addAction(act_exit)

		# Undo/Redo
		act_undo = QAction("Undo", self)
		act_undo.setShortcut(QKeySequence.StandardKey.Undo)
		act_undo.triggered.connect(self._undo_stack.undo)
		edit_menu.addAction(act_undo)

		act_redo = QAction("Redo", self)
		act_redo.setShortcut(QKeySequence.StandardKey.Redo)
		act_redo.triggered.connect(self._undo_stack.redo)
		edit_menu.addAction(act_redo)

		# Delete / Duplicate selected entities. Actions are created here so they
		# appear in the Edit menu with their shortcut hints; their triggers are
		# wired to HierarchyPanel later once the panel exists (see
		# _wire_entity_edit_shortcuts). WindowShortcut context lets QLineEdit /
		# QSpinBox / etc. consume Delete for text editing via ShortcutOverride.
		edit_menu.addSeparator()
		self._act_delete_entity = QAction("Delete", self)
		self._act_delete_entity.setShortcut(QKeySequence(Qt.Key.Key_Delete))
		self._act_delete_entity.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
		edit_menu.addAction(self._act_delete_entity)

		self._act_duplicate_entity = QAction("Duplicate", self)
		self._act_duplicate_entity.setShortcut(QKeySequence("Ctrl+D"))
		self._act_duplicate_entity.setShortcutContext(Qt.ShortcutContext.WindowShortcut)
		edit_menu.addAction(self._act_duplicate_entity)

		edit_menu.addSeparator()
		act_preferences = QAction("Preferences...", self)
		act_preferences.setStatusTip("Color theme and global font size")
		act_preferences.triggered.connect(self._open_preferences)
		edit_menu.addAction(act_preferences)

		# Selection modes: Object / Vertex / Edge / Face
		edit_menu.addSeparator()
		self._sel_mode_group = QActionGroup(self)
		self._sel_mode_group.setExclusive(True)

		self._act_mode_object = QAction("Object Mode", self)
		self._act_mode_object.setCheckable(True)
		self._act_mode_object.setShortcut(QKeySequence("1"))
		self._act_mode_object.setChecked(True)
		self._act_mode_object.triggered.connect(lambda _=False: self._set_selection_mode("object"))
		self._sel_mode_group.addAction(self._act_mode_object)
		edit_menu.addAction(self._act_mode_object)

		self._act_mode_vertex = QAction("Vertex Mode", self)
		self._act_mode_vertex.setCheckable(True)
		self._act_mode_vertex.setShortcut(QKeySequence("2"))
		self._act_mode_vertex.setEnabled(False)
		self._act_mode_vertex.triggered.connect(lambda _=False: self._set_selection_mode("vertex"))
		self._sel_mode_group.addAction(self._act_mode_vertex)
		edit_menu.addAction(self._act_mode_vertex)

		self._act_mode_edge = QAction("Edge Mode", self)
		self._act_mode_edge.setCheckable(True)
		self._act_mode_edge.setShortcut(QKeySequence("3"))
		self._act_mode_edge.setEnabled(False)
		self._act_mode_edge.triggered.connect(lambda _=False: self._set_selection_mode("edge"))
		self._sel_mode_group.addAction(self._act_mode_edge)
		edit_menu.addAction(self._act_mode_edge)

		self._act_mode_face = QAction("Face Mode", self)
		self._act_mode_face.setCheckable(True)
		self._act_mode_face.setShortcut(QKeySequence("4"))
		self._act_mode_face.setEnabled(False)
		self._act_mode_face.triggered.connect(lambda _=False: self._set_selection_mode("face"))
		self._sel_mode_group.addAction(self._act_mode_face)
		edit_menu.addAction(self._act_mode_face)

		# View modes
		view_group = QActionGroup(self)
		view_group.setExclusive(True)

		self._act_view_solid = QAction("Solid View", self)
		self._act_view_solid.setCheckable(True)
		self._act_view_solid.setChecked(True)
		self._act_view_solid.setShortcut(QKeySequence("s"))
		self._act_view_solid.triggered.connect(lambda _=False: set_solid(self._vtk_view))
		view_group.addAction(self._act_view_solid)
		view_menu.addAction(self._act_view_solid)

		self._act_view_wire = QAction("Wireframe View", self)
		self._act_view_wire.setCheckable(True)
		self._act_view_wire.setShortcut(QKeySequence("w"))
		self._act_view_wire.triggered.connect(lambda _=False: set_wireframe(self._vtk_view))
		view_group.addAction(self._act_view_wire)
		view_menu.addAction(self._act_view_wire)

		view_menu.addSeparator()
		
		# Selection highlight mode
		highlight_group = QActionGroup(self)
		highlight_group.setExclusive(True)
		
		self._act_highlight_outline = QAction("Edge Outline Highlight", self)
		self._act_highlight_outline.setCheckable(True)
		self._act_highlight_outline.triggered.connect(lambda _=False: self._set_selection_highlight_mode("outline"))
		highlight_group.addAction(self._act_highlight_outline)
		view_menu.addAction(self._act_highlight_outline)
		
		self._act_highlight_bbox = QAction("Bounding Box Highlight", self)
		self._act_highlight_bbox.setCheckable(True)
		self._act_highlight_bbox.setChecked(True)
		self._act_highlight_bbox.triggered.connect(lambda _=False: self._set_selection_highlight_mode("bbox"))
		highlight_group.addAction(self._act_highlight_bbox)
		view_menu.addAction(self._act_highlight_bbox)
		
		view_menu.addSeparator()
		self._act_view_reset_cam = QAction("Reset Camera", self)
		self._act_view_reset_cam.setShortcut(QKeySequence("r"))
		self._act_view_reset_cam.triggered.connect(lambda _=False: reset_camera(self._vtk_view))
		view_menu.addAction(self._act_view_reset_cam)

		view_menu.addSeparator()
		self._act_debug_draw_enabled = QAction("Enable Debug Draw", self)
		self._act_debug_draw_enabled.setCheckable(True)
		self._act_debug_draw_enabled.setChecked(True)
		self._act_debug_draw_enabled.triggered.connect(self._on_toggle_debug_draw_enabled)
		view_menu.addAction(self._act_debug_draw_enabled)

	def _init_play_mode(self) -> None:
		"""Initialize Play Mode system with ribbon toolbar and manager."""
		# Create Play Mode Manager
		self._play_mode_manager = PlayModeManager(self._scene)
		self._scene.set_play_mode_manager(self._play_mode_manager)
		self._play_mode_manager.play_mode_changed.connect(self._on_play_mode_changed)
		# Connect frame_ready signal to render after each update
		self._play_mode_manager.frame_ready.connect(self._on_play_mode_frame_ready)
		# Edit-mode play routines reuse the same post-tick render path.
		self._scene.play_routine_runner.frame_ready.connect(self._on_play_mode_frame_ready)
		
		# Create Play Mode Ribbon
		self._play_mode_ribbon = PlayModeRibbon(self)
		self._play_mode_ribbon.set_play_callbacks(
			on_play=self._play_mode_manager.start_play_mode,
			on_stop=self._stop_play_mode_with_bulk_sync,
			on_pause=self._play_mode_manager.pause_play_mode,
			on_resume=self._play_mode_manager.resume_play_mode
		)
		# Connect pause state changes to update ribbon
		self._play_mode_manager.pause_state_changed.connect(self._on_pause_state_changed)
		
		# Add ribbon as a toolbar below the menu bar
		from PyQt6.QtWidgets import QToolBar
		play_toolbar = QToolBar("Play Mode", self)
		play_toolbar.setMovable(False)
		play_toolbar.addWidget(self._play_mode_ribbon)
		play_toolbar.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
		self.addToolBar(Qt.ToolBarArea.TopToolBarArea, play_toolbar)
		# Parent is now the toolbar — apply theme QSS to ribbon + toolbar strip.
		self._play_mode_ribbon.apply_theme_stylesheet()

	def _init_central_view(self) -> None:
		print("Initializing central view")
		container, plotter = create_vtk_container(self)
		self._vtk_view = plotter
		self.setCentralWidget(container)
		from MotionStudio.render.vtk.viewport_service import VtkViewportService
		self._scene.set_viewport_service(VtkViewportService(self._vtk_view))
		# Mirror ECS scene to VTK
		self._scene_root = VtkSceneRoot(self._vtk_view, self._scene, self._selection)
		# Default selection highlight: bounding box.
		try:
			self._scene_root.set_selection_highlight_mode("bbox")
		except Exception:
			pass
		# Debug draw bridge + viewport lifecycle (on_viewport_draw) + global Debug API wiring.
		self._debug_draw_bridge = VtkDebugDrawBridge(self._vtk_view)
		self._viewport_frame_bridge = VtkViewportFrameBridge(
			self._vtk_view, self._scene, self._debug_draw_bridge
		)
		self._debug_draw_reentrant = False
		Debug.configure(scene=self._scene, request_render=self._on_debug_draw_requested)
		Debug.set_enabled(True)
		# Path Bridge
		self._path_bridge = VtkPathBridge(self._vtk_view, self._scene, self._selection, self._scene_root)
		# Picking -> SelectionModel
		self._picker_bridge = VtkPickerBridge(self._vtk_view, self._scene, self._selection, self._scene_root, self._path_bridge)
		# Path Tool Manager
		self._path_tool_manager = PathToolManager(self._scene, self._selection, self._path_bridge, self._picker_bridge, self._undo_stack)
		self._path_tool_manager.request_selection_mode.connect(self._set_selection_mode)
		# Instruction Overlay (UI Overlay for path tool instructions)
		self._instruction_overlay = InstructionOverlay(container)
		self._path_tool_manager.instruction_changed.connect(self._on_instruction_changed)

		# Vertex Pick Tool Manager (for Inspector VertexPick metadata)
		self._vertex_pick_tool_manager = VertexPickToolManager(
			self._scene, self._selection, self._scene_root, self._picker_bridge, self._undo_stack
		)
		self._vertex_pick_tool_manager.request_selection_mode.connect(self._set_selection_mode)
		self._vertex_pick_tool_manager.instruction_changed.connect(self._on_instruction_changed)
		# Cross-cancel: starting one tool cancels the other.
		self._path_tool_manager.tool_active_changed.connect(
			lambda active: self._vertex_pick_tool_manager.cancel_pick() if active else None
		)
		self._vertex_pick_tool_manager.tool_active_changed.connect(
			lambda active: self._path_tool_manager.cancel_tool() if active else None
		)

		self._selection.current_entity_changed.connect(self._on_selection_for_subselect_modes)
		# Translate gizmo (local-space)
		self._translate_gizmo = VtkTranslateGizmo(self._vtk_view, self._scene, self._selection, self._scene_root, self._undo_stack)
		# Rotate gizmo (local-space) - works alongside translate gizmo
		self._rotate_gizmo = VtkRotateGizmo(self._vtk_view, self._scene, self._selection, self._scene_root, self._undo_stack)
		# Let both pickers see both handle sets so top-most (depth-resolved) handle wins.
		try:
			self._translate_gizmo.register_external_pick_actors(self._rotate_gizmo.pickable_actors())
			self._rotate_gizmo.register_external_pick_actors(self._translate_gizmo.pickable_actors())
		except Exception:
			pass
		# Waypoint gizmo (for editing individual waypoints)
		from MotionStudio.render.vtk.gizmo.waypoint_gizmo import VtkWaypointGizmo
		self._waypoint_gizmo = VtkWaypointGizmo(
			self._vtk_view, self._scene, self._selection, self._scene_root,
			self._translate_gizmo, self._rotate_gizmo, self._undo_stack
		)
		
		# Store references for play mode control
		self._gizmos_enabled = True
		self._allow_editing_in_play_mode = True  # Flag to control whether gizmos work during play mode
	
	@property
	def allow_editing_in_play_mode(self) -> bool:
		"""Get whether editing (gizmos) is allowed during play mode."""
		return self._allow_editing_in_play_mode
	
	@allow_editing_in_play_mode.setter
	def allow_editing_in_play_mode(self, value: bool) -> None:
		"""Set whether editing (gizmos) is allowed during play mode."""
		if self._allow_editing_in_play_mode == value:
			return
		self._allow_editing_in_play_mode = value
		# If play mode is active, update gizmo state immediately
		if hasattr(self, '_play_mode_manager') and self._play_mode_manager.is_playing:
			if value:
				# Enable gizmos
				self._gizmos_enabled = True
				if hasattr(self, '_translate_gizmo'):
					self._translate_gizmo.set_enabled(True)
				if hasattr(self, '_rotate_gizmo'):
					self._rotate_gizmo.set_enabled(True)
			else:
				# Disable gizmos
				self._gizmos_enabled = False
				if hasattr(self, '_translate_gizmo'):
					self._translate_gizmo.set_enabled(False)
				if hasattr(self, '_rotate_gizmo'):
					self._rotate_gizmo.set_enabled(False)

	def _init_docks(self) -> None:
		left_right = (
			Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea
		)

		# Hierarchy (default left; user may dock left or right)
		self._hierarchy_dock = QDockWidget("Hierarchy", self)
		self._hierarchy_dock.setAllowedAreas(left_right)
		self._hierarchy_dock.setObjectName("HierarchyDock")
		self._hierarchy_panel = HierarchyPanel(
			self._scene,
			self._hierarchy_dock,
			self._selection,
			self._undo_stack,
			loading=self._loading,
			scene_root=self._scene_root,
		)
		self._hierarchy_dock.setWidget(self._hierarchy_panel)
		self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self._hierarchy_dock)
		# Now that the hierarchy panel exists, wire its Delete / Duplicate shortcuts
		# to the Edit menu QActions that were created earlier.
		self._wire_entity_edit_shortcuts()

		# Inspector (default right; user may dock left or right)
		self._inspector_dock = QDockWidget("Inspector", self)
		self._inspector_dock.setAllowedAreas(left_right)
		self._inspector_dock.setObjectName("InspectorDock")
		inspector = InspectorPanel(self._inspector_dock)
		inspector.bind_selection(self._selection)
		inspector.bind_scene(self._scene)
		try:
			inspector.bind_undo_stack(self._undo_stack)
		except Exception:
			pass
		try:
			inspector.bind_vertex_pick_manager(self._vertex_pick_tool_manager)
		except Exception:
			pass
		try:
			inspector.bind_path_tool_manager(self._path_tool_manager)
		except Exception:
			pass
		self._inspector_dock.setWidget(inspector)
		self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self._inspector_dock)

		# Physics window (Left bottom by default)
		self._collision_matrix_dock = QDockWidget("Physics", self)
		self._collision_matrix_dock.setAllowedAreas(Qt.DockWidgetArea.RightDockWidgetArea | Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.BottomDockWidgetArea)
		self._collision_matrix_dock.setObjectName("CollisionMatrixDock")
		self._collision_matrix_dock.setWidget(CollisionMatrixPanel(self._scene, self._collision_matrix_dock))
		self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea, self._collision_matrix_dock)
		# Put Physics in the lower half of the left dock stack.
		self.splitDockWidget(self._hierarchy_dock, self._collision_matrix_dock, Qt.Orientation.Vertical)

		self._init_window_menu()

	def _init_window_menu(self) -> None:
		"""Window menu: show/hide the primary dock windows."""
		act_hierarchy = self._hierarchy_dock.toggleViewAction()
		act_hierarchy.setText("Hierarchy")
		act_hierarchy.setStatusTip("Show or hide the Hierarchy panel")
		self._window_menu.addAction(act_hierarchy)

		act_inspector = self._inspector_dock.toggleViewAction()
		act_inspector.setText("Inspector")
		act_inspector.setStatusTip("Show or hide the Inspector panel")
		self._window_menu.addAction(act_inspector)

		act_physics = self._collision_matrix_dock.toggleViewAction()
		act_physics.setText("Physics")
		act_physics.setStatusTip("Show or hide the Physics panel")
		self._window_menu.addAction(act_physics)

	def _init_status_bar(self) -> None:
		"""Initialize the status bar and connect to undo stack signals."""
		self._status_bar = QStatusBar(self)
		self.setStatusBar(self._status_bar)
		# Show initial message to verify status bar is visible (longer timeout)
		self._status_bar.showMessage("Ready - Status bar is working", 10000)
		
		# Connect to undo stack to detect command execution
		self._undo_stack.indexChanged.connect(self._on_command_executed)
		
		# Debug: verify connection
		print(f"Status bar initialized, undo stack index: {self._undo_stack.index()}, count: {self._undo_stack.count()}", flush=True)

	def _stop_play_mode_with_bulk_sync(self) -> None:
		"""Stop Play Mode while deferring VTK mesh rebuilds until restore finishes.

		Play-stop emits ``entity_changed`` for every entity. Without bulk load,
		each event can remove+readd meshes mid-restore; a flaky remove then
		leaves orphan actors (duplicated UUT solids in the viewport).
		"""
		root = getattr(self, "_scene_root", None)
		if root is not None and hasattr(root, "begin_bulk_load"):
			root.begin_bulk_load()
			try:
				self._play_mode_manager.stop_play_mode()
			finally:
				root.end_bulk_load()
			if hasattr(self, "_vtk_view") and self._vtk_view is not None:
				try:
					self._vtk_view.render()
				except Exception:
					pass
			return
		self._play_mode_manager.stop_play_mode()

	def _on_play_mode_frame_ready(self) -> None:
		"""Handle frame_ready signal from PlayModeManager - render the frame after updates."""
		if hasattr(self, '_vtk_view') and self._vtk_view is not None:
			try:
				self._vtk_view.render()
			except Exception:
				pass

	def _on_debug_draw_requested(self) -> None:
		"""
		Called by `MotionStudio.core.debug.Debug` when a primitive is queued.
		We render immediately so one-frame debug calls are visible in edit mode
		(where there is no continuous update loop).
		"""
		if not hasattr(self, "_debug_draw_bridge") or self._vtk_view is None:
			return
		if self._debug_draw_reentrant:
			return
		try:
			self._debug_draw_reentrant = True
			self._vtk_view.render()
		except Exception:
			pass
		finally:
			self._debug_draw_reentrant = False
	
	def _on_play_mode_changed(self, is_playing: bool) -> None:
		"""Handle play mode state changes - enable/disable editing features."""
		# Update ribbon button states
		self._play_mode_ribbon.set_play_mode(is_playing, self._play_mode_manager.is_paused)
		
		if is_playing:
			# Check if editing is allowed during play mode
			if self._allow_editing_in_play_mode:
				# Keep gizmos enabled during play mode
				self._gizmos_enabled = True
				if hasattr(self, '_translate_gizmo'):
					self._translate_gizmo.set_enabled(True)
				if hasattr(self, '_rotate_gizmo'):
					self._rotate_gizmo.set_enabled(True)
			else:
				# Disable gizmos during play mode
				self._gizmos_enabled = False
				if hasattr(self, '_translate_gizmo'):
					self._translate_gizmo.set_enabled(False)
				if hasattr(self, '_rotate_gizmo'):
					self._rotate_gizmo.set_enabled(False)
			
			# Disable path tool manager
			if hasattr(self, '_path_tool_manager'):
				self._path_tool_manager.cancel_tool()  # Cancel any active tool
			# Disable undo/redo (prevent new commands)
			# Note: We don't disable the actions, but commands won't be pushed during play
			# Disable hierarchy editing (handled in HierarchyPanel if needed)
			# Disable inspector editing (handled in InspectorPanel if needed)
		else:
			# Re-enable editing features when play mode stops
			self._gizmos_enabled = True
			if hasattr(self, '_translate_gizmo'):
				self._translate_gizmo.set_enabled(True)
			if hasattr(self, '_rotate_gizmo'):
				self._rotate_gizmo.set_enabled(True)

	def _on_pause_state_changed(self, is_paused: bool) -> None:
		"""Handle pause state changes - update ribbon appearance."""
		if hasattr(self, '_play_mode_ribbon') and hasattr(self, '_play_mode_manager'):
			self._play_mode_ribbon.set_play_mode(self._play_mode_manager.is_playing, is_paused)
	
	def _on_entity_changed_for_toolbox(self, entity_id: str) -> None:
		if self._selection.current and self._selection.current.id == entity_id:
			self._path_toolbox.show_for_entity(self._selection.current)

	def _on_selection_for_subselect_modes(self, entity) -> None:
		# Vertex mode: Mesh or PointCloud. Edge/Face need Mesh topology.
		has_mesh = False
		has_cloud = False
		try:
			if entity is not None:
				has_mesh = entity.get_component(MeshComponent) is not None
				has_cloud = entity.get_component(PointCloudComponent) is not None
		except Exception:
			has_mesh = False
			has_cloud = False
		self._act_mode_vertex.setEnabled(has_mesh or has_cloud)
		self._act_mode_edge.setEnabled(has_mesh)
		self._act_mode_face.setEnabled(has_mesh)
		if not (has_mesh or has_cloud):
			# Auto return to object mode if leaving mesh/cloud selection
			self._set_selection_mode("object")
		elif not has_mesh and self._picker_bridge is not None:
			# Drop edge/face if current mode is topology-only
			mode = getattr(self._picker_bridge, "_selection_mode", "object")
			if mode in ("edge", "face"):
				self._set_selection_mode("object")

	def _wire_entity_edit_shortcuts(self) -> None:
		"""
		Bind Delete / Duplicate QActions to their handlers.

		Delete goes through :meth:`_on_delete_shortcut` so that a selected
		waypoint on a ``CustomFeature`` is deleted instead of the owning entity
		when applicable; otherwise it falls back to hierarchy entity deletion.
		Duplicate always applies to the entity selection.

		Called after the panel is instantiated (the QActions themselves are
		created earlier in _setup_ui so they show their shortcuts in the Edit
		menu). Using WindowShortcut context means text-input widgets
		(QLineEdit / QSpinBox / QTextEdit / ...) still consume the Delete key
		for text editing via Qt's ShortcutOverride handshake.
		"""
		panel = getattr(self, "_hierarchy_panel", None)
		if panel is None:
			return
		try:
			self._act_delete_entity.triggered.connect(lambda _=False: self._on_delete_shortcut())
			self._act_duplicate_entity.triggered.connect(lambda _=False: panel.duplicate_selected())
		except Exception:
			pass

	def _on_delete_shortcut(self) -> None:
		"""
		Dispatcher for the ``Del`` shortcut:

		1. If a waypoint is currently selected on a ``CustomFeature`` segment,
		   delete just that waypoint via :class:`DeleteWaypointCommand`.
		2. Otherwise, fall back to entity deletion via
		   :meth:`HierarchyPanel.delete_selected`.

		Non-CustomFeature waypoints (auto-generated by parametric segments) are
		not individually deletable, so we intentionally do NOT fall back to
		entity delete in that case — that would surprise the user by deleting
		the whole entity while their attention is on a waypoint marker.
		"""
		selection = getattr(self, "_selection", None)
		panel = getattr(self, "_hierarchy_panel", None)

		wp = getattr(selection, "current_waypoint", None) if selection is not None else None
		owner_id = getattr(selection, "current_waypoint_entity_id", None) if selection is not None else None

		if wp is not None and owner_id:
			f_idx, w_idx = wp
			entity = self._scene.find_by_id(owner_id) if self._scene is not None else None
			if entity is not None:
				from MotionStudio.core.components.path_component import PathComponent
				from MotionStudio.core.components.feature import CustomFeature

				path_comp = entity.get_component(PathComponent)
				if (
					path_comp is not None
					and 0 <= f_idx < len(path_comp.features)
					and isinstance(path_comp.features[f_idx], CustomFeature)
					and 0 <= w_idx < len(path_comp.features[f_idx].waypoints)
				):
					from MotionStudio.core.undo.commands import DeleteWaypointCommand

					self._undo_stack.push(
						DeleteWaypointCommand(
							self._scene, owner_id, f_idx, w_idx, selection=selection,
						)
					)
					return
				# Non-CustomFeature waypoint or stale index: swallow the key so
				# we don't accidentally delete the entity while the user is
				# focused on a waypoint marker.
				return

		if panel is not None:
			panel.delete_selected()

	def _set_selection_mode(self, mode: str) -> None:
		try:
			self._picker_bridge.set_selection_mode(mode)
		except Exception:
			pass
		try:
			self._scene_root.set_selection_mode(mode)
		except Exception:
			pass

	def _spawn_demo_content(self) -> None:
		# Create an ECS entity with a transform and attach a visible cube under its VTK peer
		entity = self._scene.create_entity("DefaultCube")
		entity.add_component(TransformComponent())
		entity.add_component(MeshComponent("cube"))
		self._scene.events.entity_changed.emit(entity.id)

	def _action_new_project(self) -> None:
		"""
		Create a new project: prompt for project name and location, create folder, set as project root.
		"""
		# Prompt for project name
		project_name, ok = QInputDialog.getText(
			self,
			"New Project",
			"Enter project name:",
			text="New Project"
		)
		if not ok or not project_name.strip():
			return

		project_name = self.sanitize_project_name(project_name)
		if not project_name:
			QMessageBox.warning(self, "New Project", "Invalid project name.")
			return

		# Prompt for directory where project folder should be created
		start_dir = str(self._project_dir.parent if self._project_dir.exists() else self._default_project_dir().parent)
		parent_dir = QFileDialog.getExistingDirectory(
			self,
			"Select Location for New Project",
			start_dir
		)
		if not parent_dir:
			return

		parent_path = Path(parent_dir)
		project_path = parent_path / project_name

		# Check if folder already exists
		if project_path.exists():
			reply = QMessageBox.question(
				self,
				"Project Exists",
				f"A folder named '{project_name}' already exists at:\n{project_path}\n\nDo you want to use it?",
				QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
				QMessageBox.StandardButton.No
			)
			if reply != QMessageBox.StandardButton.Yes:
				return
		else:
			# Create the project folder
			try:
				project_path.mkdir(parents=True, exist_ok=True)
			except Exception as e:
				QMessageBox.critical(self, "New Project", f"Failed to create project folder:\n{e}")
				return

		self.apply_project_directory(project_path)
		self._clear_scene_state()
		self._status_bar.showMessage("New project created", 3000)

		try:
			reset_camera(self._vtk_view)
		except Exception:
			pass

		QMessageBox.information(
			self,
			"New Project",
			f"Created new project:\n{project_path}\n\nYou can now add entities and save your scene."
		)

	def _action_open_project(self) -> None:
		start_dir = str(self._project_dir if self._project_dir.exists() else self._default_project_dir())
		dir_path = QFileDialog.getExistingDirectory(self, "Open Project Folder", start_dir)
		if not dir_path:
			return
		self.apply_project_directory(Path(dir_path))

		scene_path = self._find_scene_path(self._project_dir)
		if scene_path is None:
			QMessageBox.information(self, "Open Project", "No .scn file found in selected folder.")
			return
		self._load_project_scene(scene_path, show_success_dialog=True)

	def _load_project_scene(self, scene_path: Path, *, show_success_dialog: bool = True) -> None:
		"""Load a ``.scn`` file into the editor (async JSON read + main-thread apply)."""
		scene_path_str = str(scene_path)
		scene_display_name = scene_path.name

		def _background():
			from MotionStudio.core.serialization.json_io import load_scene_json

			return load_scene_json(scene_path_str)

		def _apply(data) -> None:
			from MotionStudio.core.serialization.json_io import apply_scene_data

			apply_error: Exception | None = None
			self._clear_scene_state()

			def _finish() -> None:
				self._loading.hide()
				if apply_error is not None:
					QMessageBox.critical(
						self,
						"Open Project",
						f"Failed to load scene:\n{apply_error}",
					)
					return
				try:
					self._path_bridge.sync_pending_paths()
				except Exception:
					pass
				try:
					reset_camera(self._vtk_view)
				except Exception:
					pass
				self._status_bar.showMessage(f"Loaded scene: {scene_display_name}", 3000)
				if show_success_dialog:
					QMessageBox.information(self, "Open Project", f"Loaded scene: {scene_display_name}")

			try:
				self._scene_root.begin_bulk_load()
				try:
					apply_scene_data(self._scene, data)
				except Exception as e:
					apply_error = e
			finally:
				self._scene_root.end_bulk_load(
					on_progress=self._loading.set_message,
					on_complete=_finish,
				)

		def _on_load_error(exc: Exception) -> None:
			self._loading.hide()
			QMessageBox.critical(self, "Open Project", f"Failed to load scene:\n{exc}")

		if not self._loading.run(
			"Loading project...",
			_background,
			_apply,
			on_error=_on_load_error,
			hide_when_apply_returns=False,
		):
			QMessageBox.warning(self, "Open Project", "Another load operation is already in progress.")

	def _action_save_project(self) -> None:
		try:
			self._project_dir.mkdir(parents=True, exist_ok=True)
			scene_path = self._project_dir / "project.scn"
			from MotionStudio.core.serialization.json_io import save_scene
			save_scene(self._scene, str(scene_path))
			QMessageBox.information(self, "Save Project", f"Saved scene to:\n{scene_path}")
		except Exception as e:
			QMessageBox.critical(self, "Save Project", f"Failed to save scene:\n{e}")

	def _on_instruction_changed(self, instruction_text: str) -> None:
		"""Shows or hides the instruction overlay based on tool state."""
		if instruction_text:
			self._instruction_overlay.show_instruction(instruction_text)
		else:
			self._instruction_overlay.clear_instruction()
	
	def _set_selection_highlight_mode(self, mode: str) -> None:
		"""Sets the selection highlight mode (outline or bbox)."""
		if self._scene_root is not None:
			self._scene_root.set_selection_highlight_mode(mode)

	def _on_toggle_collision_matrix(self, checked: bool) -> None:
		"""Show or hide the Collision Matrix dock (wired from the View menu)."""
		if not hasattr(self, "_collision_matrix_dock") or self._collision_matrix_dock is None:
			return
		if checked:
			self._collision_matrix_dock.show()
			self._collision_matrix_dock.raise_()
		else:
			self._collision_matrix_dock.hide()

	def _open_preferences(self) -> None:
		"""Edit → Preferences: theme + font size, persisted to preferences.ini."""
		from MotionStudio.core.preferences import (
			Preferences,
			load_preferences,
			save_preferences,
		)
		from MotionStudio.ui.preferences_dialog import PreferencesDialog
		from MotionStudio.ui.theme import current_theme
		from PyQt6.QtWidgets import QApplication, QMessageBox

		app = QApplication.instance()
		current_size = app.font().pointSize() if app is not None else 10
		if current_size <= 0:
			current_size = 10
		try:
			initial = load_preferences()
		except Exception:
			initial = Preferences(theme=current_theme(), font_size=current_size).normalized()

		def _preview(prefs: Preferences) -> None:
			self._apply_ui_preferences(prefs)

		dlg = PreferencesDialog(self, initial=initial, on_preview=_preview)
		if dlg.exec():
			final = dlg.current_preferences()
			self._apply_ui_preferences(final)
			try:
				path = save_preferences(final)
				self._status_bar.showMessage(f"Preferences saved ({path})", 4000)
			except Exception as exc:
				QMessageBox.warning(self, "Preferences", f"Could not save preferences.ini:\n{exc}")
			if final.tcp_settings() != initial.tcp_settings():
				self._start_tcp_server(final)
		# Cancel restores via dialog.reject → on_preview(initial)

	def _apply_ui_preferences(self, prefs) -> None:
		"""Apply theme + font and refresh theme-dependent chrome."""
		from MotionStudio.core.preferences import apply_preferences
		from MotionStudio.render.vtk.window import apply_viewport_background

		apply_preferences(prefs)
		if hasattr(self, "_play_mode_ribbon") and self._play_mode_ribbon is not None:
			self._play_mode_ribbon.apply_theme_stylesheet()
		if hasattr(self, "_vtk_view") and self._vtk_view is not None:
			apply_viewport_background(self._vtk_view)

	def _start_tcp_server(self, prefs) -> None:
		"""Bind the TCP command server; a taken port only warns in the status bar."""
		self._stop_tcp_server()
		if not prefs.tcp_enabled:
			return
		server = TcpCommandServer(
			self._tcp_dispatcher,
			host=prefs.tcp_host,
			port=prefs.tcp_port,
			timeout_s=prefs.tcp_timeout_s,
			command_logger=self._command_logger,
		)
		try:
			server.start()
		except OSError as exc:
			print(f"TCP command server could not bind {server.address}: {exc}", flush=True)
			if hasattr(self, "_status_bar") and self._status_bar is not None:
				self._status_bar.showMessage(
					f"TCP command server unavailable on {server.address}: {exc}", 8000
				)
			return
		self._tcp_server = server
		if hasattr(self, "_status_bar") and self._status_bar is not None:
			self._status_bar.showMessage(f"TCP commands on {server.address}", 4000)

	def _stop_tcp_server(self) -> None:
		server = self._tcp_server
		self._tcp_server = None
		if server is not None:
			try:
				server.stop()
			except Exception:
				pass

	def closeEvent(self, event) -> None:  # noqa: N802 (Qt override)
		self._stop_tcp_server()
		super().closeEvent(event)

	def _on_toggle_debug_draw_enabled(self, checked: bool) -> None:
		"""Global on/off switch for Debug.draw_* rendering."""
		Debug.set_enabled(bool(checked))
		# Clear any currently displayed debug actors when disabling.
		if not checked and hasattr(self, "_debug_draw_bridge"):
			try:
				self._debug_draw_bridge.clear_actors()
				if self._vtk_view is not None:
					self._vtk_view.render()
			except Exception:
				pass

	def _on_collision_matrix_visibility_changed(self, visible: bool) -> None:
		"""Keep the View menu checkable action in sync with the dock's own close button."""
		if hasattr(self, "_act_view_collision_matrix"):
			try:
				self._act_view_collision_matrix.setChecked(bool(visible))
			except Exception:
				pass

	def _on_command_executed(self, index: int) -> None:
		"""
		Handle command execution (execute/undo/redo) and update status bar + log.
		
		Args:
			index: Current index in the undo stack
		"""
		try:
			# QUndoStack.indexChanged emits the new index (0-based)
			# When a command is pushed: index increases, redo() is called automatically
			# When undo is called: index decreases
			# When redo is called: index increases
			
			current_can_undo = self._undo_stack.canUndo()
			current_can_redo = self._undo_stack.canRedo()
			
			# Determine action
			if index > self._last_undo_index:
				# Index increased - could be execute (new command) or redo
				# Key insight: if we can redo, it means we're in the middle of the stack (redo)
				# If we can't redo, we're at the top (new command)
				if current_can_redo:
					action = "redo"
				else:
					action = "execute"
			elif index < self._last_undo_index:
				action = "undo"
			else:
				# Index unchanged - this shouldn't normally happen, but handle it
				# This might occur on initial setup, so skip
				if self._last_undo_index == -1:
					# First time, just update state
					self._last_undo_index = index
					self._last_can_undo = current_can_undo
				return
			
			self._last_undo_index = index
			self._last_can_undo = current_can_undo
			
			from MotionStudio.core.logging.command_logger import command_for_stack_action

			command = command_for_stack_action(self._undo_stack, index, action)
			if command is None:
				return

			try:
				if hasattr(command, "get_description"):
					description = command.get_description()
				else:
					description = command.text()
			except Exception:
				description = command.text() if command else "Unknown command"

			if action == "undo":
				status_msg = f"Undid: {description}"
			elif action == "redo":
				status_msg = f"Redid: {description}"
			else:
				status_msg = description

			if hasattr(self, "_status_bar") and self._status_bar is not None:
				self._status_bar.showMessage(status_msg, 5000)

			self._command_logger.log_command(command, action)
		except Exception as e:
			# Log error for debugging
			print(f"Error in _on_command_executed: {e}", flush=True)
			import traceback
			traceback.print_exc()



from __future__ import annotations
from typing import List, Optional

import vtk  # type: ignore
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QVector3D

from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.feature import (
    TwoPointLineFeature,
    ThreePointArcFeature,
    SinglePointFeature,
)
from MotionStudio.core.transform.utils import (
    inverse_transform_point,
    inverse_transform_direction,
    world_matrix,
)
from MotionStudio.render.vtk.path_bridge import VtkPathBridge


class PathToolManager(QObject):
    """
    Manages the stateful sequential picking for path segment creation.

    Picks are captured in the entity's LOCAL frame using ``transform.utils`` so
    that segments follow reparented / transformed parent hierarchies correctly.
    """
    request_selection_mode = pyqtSignal(str)
    tool_active_changed = pyqtSignal(bool)  # Emits True when tool is active, False when inactive
    instruction_changed = pyqtSignal(str)  # Emits instruction text for current step

    def __init__(self, scene: Scene, selection: SelectionModel, path_bridge: VtkPathBridge, picker_bridge, undo_stack=None) -> None:
        super().__init__()
        self._scene = scene
        self._selection = selection
        self._path_bridge = path_bridge
        self._picker_bridge = picker_bridge
        self._undo_stack = undo_stack

        self._active_feature_type: Optional[str] = None  # "line", "arc", or "point"
        self._picked_local_points: List[QVector3D] = []
        # Entity the tool was armed on; cleared when the tool ends.
        self._armed_entity_id: Optional[str] = None

        self._picker_bridge.vertex_picked.connect(self._on_vertex_picked)
        # Cancel automatically when the user selects a different entity while a
        # tool is armed (see plan section 3b).
        self._selection.current_entity_changed.connect(self._on_selection_changed)

    def start_feature_tool(self, feature_type: str) -> None:
        """Starts the sequential picking tool for a specific segment type."""
        self._active_feature_type = feature_type
        self._picked_local_points = []
        self._armed_entity_id = (
            self._selection.current.id if self._selection.current is not None else None
        )

        # All segment tools now pick vertices (single-point too — see plan #2).
        self.request_selection_mode.emit("vertex")

        self.tool_active_changed.emit(True)
        self._emit_current_instruction()

    def cancel_tool(self) -> None:
        """Resets the tool state and clears previews. Idempotent: a no-op when no tool is active."""
        if (
            self._active_feature_type is None
            and not self._picked_local_points
            and self._armed_entity_id is None
        ):
            # Nothing to cancel; avoid spurious mode/instruction emissions that
            # would clobber other tools (e.g. VertexPickToolManager).
            return
        self._active_feature_type = None
        self._picked_local_points = []
        self._armed_entity_id = None
        self._path_bridge.set_preview_points([])
        # Return to normal selection behavior
        self.request_selection_mode.emit("object")
        self.tool_active_changed.emit(False)
        # Clear instruction
        self.instruction_changed.emit("")

    def _on_selection_changed(self, entity) -> None:
        """Cancel the active tool when the user selects a different entity."""
        if self._active_feature_type is None:
            return
        new_id = entity.id if entity is not None else None
        if new_id != self._armed_entity_id:
            self.cancel_tool()

    def _on_vertex_picked(self, entity_id: str, vertex_id: int) -> None:
        if not self._active_feature_type:
            return

        current = self._selection.current
        if current is None or current.id != entity_id:
            # We only allow picking on the currently selected mesh entity
            return

        path_comp = current.get_component(PathComponent)
        if path_comp is None:
            # Proactively add PathComponent if it doesn't exist
            path_comp = PathComponent()
            current.add_component(path_comp)

        # Resolve the picked vertex's world position (composes the parent
        # chain via mesh_actor.GetUserMatrix), then map to entity-local space.
        world_pt = self._pick_world_position(entity_id, vertex_id)
        if world_pt is None:
            return
        local_pt = inverse_transform_point(current, world_pt)

        # Single-point segment: capture normal + finish immediately.
        if self._active_feature_type == "point":
            world_normal = self._pick_world_normal(entity_id, vertex_id)
            if world_normal is None:
                world_normal = QVector3D(0.0, 0.0, 1.0)
            local_normal = inverse_transform_direction(current, world_normal)
            if local_normal.length() < 1e-6:
                local_normal = QVector3D(0.0, 0.0, 1.0)
            else:
                local_normal.normalize()

            feature = SinglePointFeature()
            feature.local_position = local_pt
            feature.local_normal = local_normal
            self._picked_local_points = [local_pt]
            self._finish_feature(feature)
            return

        self._picked_local_points.append(local_pt)
        self._update_preview()

        # Update instruction for next step
        self._emit_current_instruction()

        # Check if feature is complete
        if self._active_feature_type == "line" and len(self._picked_local_points) == 2:
            self._finish_feature(TwoPointLineFeature())
        elif self._active_feature_type == "arc" and len(self._picked_local_points) == 3:
            # Ordered as: start, end, mid (as per requirement)
            self._finish_feature(ThreePointArcFeature())

    def _pick_world_position(self, entity_id: str, vertex_id: int) -> Optional[QVector3D]:
        """Return the picked mesh vertex in world space, or None on failure."""
        mesh_actor = self._path_bridge._scene_root.actor_for_vertex_pick(entity_id)
        if mesh_actor is None:
            return None
        try:
            mesh_poly = mesh_actor.GetMapper().GetInput()
            local_pt = mesh_poly.GetPoint(int(vertex_id))
            m4 = mesh_actor.GetUserMatrix()
            out = [0.0, 0.0, 0.0, 1.0]
            m4.MultiplyPoint(
                [float(local_pt[0]), float(local_pt[1]), float(local_pt[2]), 1.0],
                out,
            )
            w = float(out[3]) if abs(out[3]) > 1e-9 else 1.0
            return QVector3D(out[0] / w, out[1] / w, out[2] / w)
        except Exception:
            return None

    def _pick_world_normal(self, entity_id: str, vertex_id: int) -> Optional[QVector3D]:
        """
        Average the per-cell normals of the faces adjacent to ``vertex_id``,
        rotate the result into world space via the mesh actor's matrix, and
        return a normalised vector. Returns None if the vertex has no usable
        adjacent cells.
        """
        mesh_actor = self._path_bridge._scene_root.actor_for_vertex_pick(entity_id)
        if mesh_actor is None:
            return None
        try:
            mesh_poly = mesh_actor.GetMapper().GetInput()
            if mesh_poly is None:
                return None
            cell_ids = vtk.vtkIdList()
            mesh_poly.BuildLinks()  # Required for GetPointCells to work reliably.
            mesh_poly.GetPointCells(int(vertex_id), cell_ids)
            n = cell_ids.GetNumberOfIds()
            if n == 0:
                return None
            acc = QVector3D(0.0, 0.0, 0.0)
            contributors = 0
            for i in range(n):
                cid = int(cell_ids.GetId(i))
                cell = mesh_poly.GetCell(cid)
                if cell is None:
                    continue
                n_local = self._cell_normal(cell, mesh_poly)
                if n_local is None:
                    continue
                acc = acc + n_local
                contributors += 1
            if contributors == 0 or acc.length() < 1e-9:
                return None
            local_normal = acc.normalized()

            # Rotate normal into world space using the actor matrix (upper 3x3).
            m4 = mesh_actor.GetUserMatrix()
            wx = (m4.GetElement(0, 0) * local_normal.x()
                  + m4.GetElement(0, 1) * local_normal.y()
                  + m4.GetElement(0, 2) * local_normal.z())
            wy = (m4.GetElement(1, 0) * local_normal.x()
                  + m4.GetElement(1, 1) * local_normal.y()
                  + m4.GetElement(1, 2) * local_normal.z())
            wz = (m4.GetElement(2, 0) * local_normal.x()
                  + m4.GetElement(2, 1) * local_normal.y()
                  + m4.GetElement(2, 2) * local_normal.z())
            world_normal = QVector3D(float(wx), float(wy), float(wz))
            if world_normal.length() < 1e-9:
                return None
            world_normal.normalize()
            return world_normal
        except Exception:
            return None

    @staticmethod
    def _cell_normal(cell, poly_data) -> Optional[QVector3D]:
        """Compute a mesh-local face normal from a VTK cell's first three points."""
        try:
            ids = cell.GetPointIds()
            if ids.GetNumberOfIds() < 3:
                return None
            p0 = poly_data.GetPoint(ids.GetId(0))
            p1 = poly_data.GetPoint(ids.GetId(1))
            p2 = poly_data.GetPoint(ids.GetId(2))
            v1 = QVector3D(float(p1[0] - p0[0]), float(p1[1] - p0[1]), float(p1[2] - p0[2]))
            v2 = QVector3D(float(p2[0] - p0[0]), float(p2[1] - p0[1]), float(p2[2] - p0[2]))
            n = QVector3D.crossProduct(v1, v2)
            if n.length() < 1e-9:
                return None
            n.normalize()
            return n
        except Exception:
            return None

    def _update_preview(self) -> None:
        if not self._active_feature_type or not self._picked_local_points:
            self._path_bridge.set_preview_points([])
            return

        entity = self._selection.current
        if entity is None:
            return

        # Map local -> world for the preview actor via the entity's world matrix
        # (composes the parent chain automatically).
        wm = world_matrix(entity)
        preview: List[QVector3D] = []
        for lp in self._picked_local_points:
            preview.append(QVector3D(wm.map(lp)))
        self._path_bridge.set_preview_points(preview)

    def _finish_feature(self, feature) -> None:
        entity = self._selection.current
        if entity is None:
            return

        path_comp = entity.get_component(PathComponent)
        if path_comp is None:
            return

        # All parametric segments now share the local_points storage.
        feature.local_points = [QVector3D(p) for p in self._picked_local_points]

        feature.cnt_radius = float(getattr(path_comp, "default_cnt_radius", 0.0))

        # Feature index after insertion (append semantics)
        new_feature_idx = len(path_comp.features)

        if self._undo_stack:
            from MotionStudio.core.undo.commands import AddPathFeatureCommand
            cmd = AddPathFeatureCommand(self._scene, entity.id, feature.__class__.__name__, feature.to_dict())
            self._undo_stack.push(cmd)
        else:
            path_comp.features.append(feature)
            # Trigger visuals rebuild
            self._scene.events.entity_changed.emit(entity.id)

        # Auto-select the newly created feature
        try:
            self._selection.set_current_feature(new_feature_idx)
        except Exception:
            pass

        # Reset tool
        self.cancel_tool()

    def _emit_current_instruction(self) -> None:
        """Emits the instruction text for the current step."""
        if not self._active_feature_type:
            self.instruction_changed.emit("")
            return

        num_picked = len(self._picked_local_points)

        if self._active_feature_type == "line":
            if num_picked == 0:
                self.instruction_changed.emit("[Two-point line segment] Select starting point")
            elif num_picked == 1:
                self.instruction_changed.emit("[Two-point line segment] Select end point")

        elif self._active_feature_type == "arc":
            if num_picked == 0:
                self.instruction_changed.emit("[Three-point arc segment] Select starting point")
            elif num_picked == 1:
                self.instruction_changed.emit("[Three-point arc segment] Select end point")
            elif num_picked == 2:
                self.instruction_changed.emit("[Three-point arc segment] Select any intermediate point")

        elif self._active_feature_type == "point":
            self.instruction_changed.emit("[Single-point segment] Select vertex to place waypoint")

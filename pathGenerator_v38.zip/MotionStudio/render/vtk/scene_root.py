from __future__ import annotations

from typing import Callable, Dict, Optional, Set
import json
from pathlib import Path

from PyQt6.QtGui import QColor, QMatrix4x4

import numpy as np  # type: ignore
import pyvista as pv  # type: ignore
import vtk  # type: ignore

from MotionStudio.core.collision.participants import collision_component
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.point_cloud_collider_component import (
	PointCloudColliderComponent,
)
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.transform.matrix import qmatrix_from_prs, vtk_transform_from_qmatrix, vtk_matrix_from_qmatrix
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read
from MotionStudio.utils.point_cloud_io import PointCloudLoadError, load_point_cloud


class VtkSceneRoot:
	"""
	Mirrors ECS Scene entities into VTK actors added to a PyVista Plotter (QtInteractor).
	"""

	def __init__(self, plotter, scene: Scene, selection: Optional[SelectionModel] = None) -> None:
		self._plotter = plotter
		self._scene = scene
		self._selection = selection

		self._id_to_actor: Dict[str, vtk.vtkActor] = {}
		self._actor_to_id: Dict[int, str] = {}
		self._entity_mesh_state: Dict[str, dict] = {} # Store hash of mesh state to avoid flicker
		self._entity_uses_material_colors: Dict[str, bool] = {}
		self._collision_overlay_render_pending: bool = False
		self._point_cloud_actors: Dict[str, vtk.vtkActor] = {}
		self._point_cloud_state: Dict[str, dict] = {}
		self._point_cloud_uses_scalars: Dict[str, bool] = {}
		self._last_vertex_pick_entity_id: Optional[str] = None
		self._last_vertex_pick_actor: Optional[vtk.vtkActor] = None
		self._collider_vis_by_id: Dict[str, vtk.vtkActor] = {}
		self._selection_outline_by_id: Dict[str, vtk.vtkActor] = {}
		self._selection_outline_pipeline_by_id: Dict[str, object] = {}
		self._selection_bbox_by_id: Dict[str, vtk.vtkActor] = {}
		self._outline_enabled: bool = True
		self._selection_highlight_mode: str = "outline"  # "outline" or "bbox"
		self._selection_mode: str = "object"  # object|vertex|edge|face
		self._edges_entity_id: Optional[str] = None
		self._show_all_edges: bool = False

		self._loading: bool = False
		self._bulk_loading: bool = False
		self._deferred_visual_sync: Set[str] = set()

		# Initial population
		for ent in scene.root_entities():
			self._create_actor_recursive(ent)

		# Wire scene events
		scene.events.entity_added.connect(self._on_entity_added)
		scene.events.entity_removed.connect(self._on_entity_removed)
		scene.events.entity_reparented.connect(self._on_entity_reparented)
		scene.events.entity_changed.connect(self._on_entity_changed)
		scene.events.entity_transform_changed.connect(self._on_entity_transform_changed)
		scene.events.entity_collision_changed.connect(self._on_entity_collision_changed)

		# Wire selection highlight
		if self._selection is not None:
			self._selection.selection_changed.connect(self._refresh_selection_highlights)
			self._selection.current_entity_changed.connect(self._refresh_selection_highlights)

	def set_loading(self, is_loading: bool) -> None:
		self._loading = is_loading

	def begin_bulk_load(self) -> None:
		"""Defer VTK mesh/collider sync until ``end_bulk_load`` (keeps UI responsive)."""
		self._loading = True
		self._bulk_loading = True
		self._deferred_visual_sync.clear()

	def end_bulk_load(
		self,
		*,
		on_progress: Optional[Callable[[str], None]] = None,
		on_complete: Optional[Callable[[], None]] = None,
	) -> None:
		"""Flush deferred visual sync in small main-thread chunks."""
		self._bulk_loading = False
		self._loading = False
		ids = list(self._deferred_visual_sync)
		self._deferred_visual_sync.clear()
		if not ids:
			if on_complete is not None:
				on_complete()
			return
		self._flush_deferred_visual_sync(ids, 0, on_progress, on_complete)

	def _queue_deferred_visual_sync(self, entity_id: str) -> None:
		self._deferred_visual_sync.add(entity_id)

	def _flush_deferred_visual_sync(
		self,
		ids: list[str],
		index: int,
		on_progress: Optional[Callable[[str], None]],
		on_complete: Optional[Callable[[], None]] = None,
		*,
		chunk_size: int = 3,
	) -> None:
		end = min(index + chunk_size, len(ids))
		for i in range(index, end):
			eid = ids[i]
			self._sync_mesh(eid)
			self._sync_point_cloud(eid)
			self._sync_collider_visual(eid)
			entity = self._scene.find_by_id(eid)
			if entity is not None:
				self._sync_transform_recursive(entity)
				self._sync_collider_visual_recursive(entity)
				# Path lines need mesh polydata; re-notify after VTK mesh exists.
				try:
					from MotionStudio.core.components.path_component import PathComponent

					if entity.get_component(PathComponent) is not None:
						self._scene.events.entity_changed.emit(eid)
				except Exception:
					pass
		if on_progress is not None and len(ids) > 0:
			on_progress(f"Building meshes ({end}/{len(ids)})...")
		if end < len(ids):
			from PyQt6.QtCore import QTimer

			QTimer.singleShot(
				0,
				lambda: self._flush_deferred_visual_sync(ids, end, on_progress, on_complete),
			)
		else:
			try:
				self._plotter.render()
			except Exception:
				pass
			if on_complete is not None:
				on_complete()

	def set_outline_enabled(self, enabled: bool) -> None:
		self._outline_enabled = enabled
		for actor in self._selection_outline_by_id.values():
			try:
				actor.SetVisibility(1 if enabled else 0)
			except Exception:
				pass
	
	def set_selection_highlight_mode(self, mode: str) -> None:
		"""
		Set selection highlight mode:
		- "outline": silhouette/edge outline (default)
		- "bbox": bounding box
		"""
		mode = str(mode).lower()
		if mode not in ("outline", "bbox"):
			mode = "outline"
		self._selection_highlight_mode = mode
		# Refresh selection highlight
		if self._selection is not None:
			self._refresh_selection_highlights()

	def set_show_all_edges(self, enabled: bool) -> None:
		"""
		When enabled, render dark-grey edges on every mesh actor in the scene
		(makes vertices visible everywhere — used while a VertexPick is armed).
		Independent from `_apply_edges`, which is driven by the active selection.
		Calling with False restores normal behaviour, but preserves the edges on
		the currently selected entity if it would be shown by the regular flow.
		"""
		enabled = bool(enabled)
		self._show_all_edges = enabled
		if enabled:
			for eid, actor in self._id_to_actor.items():
				try:
					prop = actor.GetProperty()
					prop.SetRepresentationToSurface()
					try:
						prop.EdgeVisibilityOn()
					except Exception:
						prop.SetEdgeVisibility(1)
					prop.SetEdgeColor(0.25, 0.25, 0.25)
					prop.SetLineWidth(1.0)
				except Exception:
					pass
		else:
			for eid, actor in self._id_to_actor.items():
				# Keep edges on the entity currently driven by _apply_edges
				# (i.e. the selected mesh while in vertex/edge/face mode).
				if eid == self._edges_entity_id:
					continue
				try:
					try:
						actor.GetProperty().EdgeVisibilityOff()
					except Exception:
						actor.GetProperty().SetEdgeVisibility(0)
				except Exception:
					pass
		try:
			self._plotter.render()
		except Exception:
			pass

	def set_selection_mode(self, mode: str) -> None:
		"""
		Set selection visuals mode:
		- object: silhouette highlight
		- vertex/edge/face: show dark-grey edges on selected mesh and suppress silhouette
		"""
		mode = str(mode).lower()
		if mode not in ("object", "vertex", "edge", "face"):
			mode = "object"
		self._selection_mode = mode
		if mode == "object":
			self._apply_edges(None)
			self.set_outline_enabled(True)
			if self._selection is not None:
				self._refresh_selection_highlights()
		else:
			self.set_outline_enabled(False)
			self._clear_selection_outline()
			self._apply_edges(self._selection.current.id if self._selection and self._selection.current else None)

	def _apply_edges(self, entity_id: Optional[str]) -> None:
		# Turn off edges for previous
		if self._edges_entity_id is not None:
			prev = self._id_to_actor.get(self._edges_entity_id)
			if prev is not None:
				try:
					prev.GetProperty().EdgeVisibilityOff()
				except Exception:
					try:
						prev.GetProperty().SetEdgeVisibility(0)
					except Exception:
						pass
		self._edges_entity_id = None

		if self._selection_mode == "object":
			return
		if entity_id is None:
			return
		actor = self._id_to_actor.get(entity_id)
		if actor is None:
			return
		try:
			prop = actor.GetProperty()
			prop.SetRepresentationToSurface()
			try:
				prop.EdgeVisibilityOn()
			except Exception:
				prop.SetEdgeVisibility(1)
			# Dark grey edge lines
			prop.SetEdgeColor(0.25, 0.25, 0.25)
			prop.SetLineWidth(1.0)
		except Exception:
			return
		self._edges_entity_id = entity_id
		try:
			self._plotter.render()
		except Exception:
			pass

	def mesh_actor_for(self, entity_id: str) -> Optional[vtk.vtkActor]:
		"""MeshComponent actor only (excludes point-cloud actors)."""
		return self._id_to_actor.get(entity_id)

	def point_cloud_actor_for(self, entity_id: str) -> Optional[vtk.vtkActor]:
		"""PointCloudComponent actor only (excludes mesh actors)."""
		return self._point_cloud_actors.get(entity_id)

	def actor_for(self, entity_id: str) -> Optional[vtk.vtkActor]:
		"""Preferred geometry actor: mesh if present, otherwise point cloud."""
		return self.mesh_actor_for(entity_id) or self.point_cloud_actor_for(entity_id)

	def note_vertex_pick_actor(self, entity_id: str, actor: Optional[vtk.vtkActor]) -> None:
		"""
		Remember which geometry actor supplied the last vertex/point pick.

		Needed when an entity has both a Mesh and a PointCloud: ``actor_for``
		prefers the mesh, but the click may have hit the cloud.
		"""
		self._last_vertex_pick_entity_id = entity_id
		self._last_vertex_pick_actor = actor

	def actor_for_vertex_pick(self, entity_id: str) -> Optional[vtk.vtkActor]:
		"""Geometry actor for resolving a vertex/point id after a pick."""
		if (
			self._last_vertex_pick_entity_id == entity_id
			and self._last_vertex_pick_actor is not None
		):
			return self._last_vertex_pick_actor
		return self.actor_for(entity_id)

	def entity_id_for_actor(self, actor: Optional[vtk.vtkActor]) -> Optional[str]:
		if actor is None:
			return None
		return self._actor_to_id.get(self._actor_key(actor))

	# --- Scene event handlers ---
	def _on_entity_added(self, entity: Entity) -> None:
		if self._bulk_loading:
			self._queue_deferred_visual_sync(entity.id)
			return
		self._sync_mesh(entity.id)
		self._sync_point_cloud(entity.id)
		self._sync_transform(entity.id)

	def _on_entity_removed(self, entity_id: str) -> None:
		self._remove_actor(entity_id)
		self._remove_point_cloud_actor(entity_id)
		self._remove_collider_visual(entity_id)
		# Clear outline if it referenced this entity (actor removed)
		if entity_id in self._selection_outline_by_id:
			self._remove_selection_outline(entity_id)
		if entity_id in self._selection_bbox_by_id:
			self._remove_selection_bbox(entity_id)

	def _on_entity_reparented(self, child_id: str, _new_parent_id: str | None) -> None:
		# ECS stores local transforms; preserving world transforms on reparent is
		# handled here by adjusting local PRS (approx: position only for now).
		if self._loading:
			return
		# For now, resync transforms so actor ends up in the correct place.
		# (A full PRS decomposition is a follow-up.)
		self._sync_transform(child_id)

	def _on_entity_changed(self, entity_id: str) -> None:
		# Call on_entity_changed() on all components of this entity
		entity = self._scene.find_by_id(entity_id)
		if entity is not None:
			for component in entity.components:
				try:
					if hasattr(component, 'on_entity_changed') and callable(getattr(component, 'on_entity_changed', None)):
						component.on_entity_changed()
				except Exception as e:
					# Log error but don't crash
					print(f"Error calling on_entity_changed on component {component.__class__.__name__} on entity {entity.name}: {e}", flush=True)
		
		if self._bulk_loading:
			self._queue_deferred_visual_sync(entity_id)
			return
		self._sync_mesh(entity_id)
		self._sync_point_cloud(entity_id)
		self._sync_collider_visual(entity_id)
		# If a parent transform changes, all descendants' world matrices change too,
		# so update transforms recursively.
		if entity is None:
			self._sync_transform(entity_id)
			return
		self._sync_transform_recursive(entity)
		self._sync_collider_visual_recursive(entity)

	def _on_entity_transform_changed(self, entity_id: str) -> None:
		"""
		Handle transform-only changes. Skips mesh sync to avoid flicker during
		gizmo dragging or continuous transform updates (e.g., in update loops).
		"""
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			self._sync_transform(entity_id)
			return
		self._sync_transform_recursive(entity)
		self._sync_collider_visual_recursive(entity)

	def _on_entity_collision_changed(self, entity_id: str) -> None:
		"""
		Lightweight recolor: the entity's ``ColliderComponent.collided`` flag flipped.
		Update only the actor's material color without rebuilding its polydata.
		"""
		self._apply_collision_repaint(entity_id)
		self._request_collision_overlay_render()

	def _collider_wants_red_overlay(self, entity: Entity) -> bool:
		collider = collision_component(entity)
		return bool(
			collider is not None
			and getattr(collider, "collided", False)
			and getattr(collider, "repaint_on_collision", True)
		)

	def _apply_collision_repaint(self, entity_id: str) -> None:
		"""Tint the actor red while colliding, or restore mesh/material/cloud colors.

		Source-material meshes use VTK cell scalars. ``SetColor`` is ignored while
		scalar visibility is on, so the overlay turns scalars off and paints the
		actor property red, then restores scalars when the flag clears. Point-cloud
		actors follow the same pattern (vertex RGB vs uniform color).
		"""
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return
		show_red = self._collider_wants_red_overlay(entity)
		self._apply_mesh_collision_repaint(entity, entity_id, show_red)
		self._apply_point_cloud_collision_repaint(entity, entity_id, show_red)

	def _apply_mesh_collision_repaint(
		self, entity: Entity, entity_id: str, show_red: bool
	) -> None:
		mesh = entity.get_component(MeshComponent)
		actor = self._id_to_actor.get(entity_id)
		if mesh is None or actor is None:
			return
		uses_mat = self._entity_uses_material_colors.get(entity_id, False)
		mapper = None
		try:
			mapper = actor.GetMapper()
		except Exception:
			mapper = None
		try:
			if show_red:
				if mapper is not None:
					mapper.SetScalarVisibility(0)
				actor.GetProperty().SetColor(1.0, 0.0, 0.0)
			elif uses_mat:
				if mapper is not None:
					mapper.SetScalarVisibility(1)
			else:
				if mapper is not None:
					mapper.SetScalarVisibility(0)
				col = mesh.color
				if isinstance(col, QColor):
					r, g, b, _a = col.getRgbF()
					actor.GetProperty().SetColor(float(r), float(g), float(b))
			if mapper is not None:
				mapper.Modified()
			actor.Modified()
		except Exception:
			pass

	def _apply_point_cloud_collision_repaint(
		self, entity: Entity, entity_id: str, show_red: bool
	) -> None:
		cloud = entity.get_component(PointCloudComponent)
		actor = self._point_cloud_actors.get(entity_id)
		if cloud is None or actor is None:
			return
		uses_scalars = self._point_cloud_uses_scalars.get(entity_id, False)
		mapper = None
		try:
			mapper = actor.GetMapper()
		except Exception:
			mapper = None
		try:
			if show_red:
				if mapper is not None:
					mapper.SetScalarVisibility(0)
				actor.GetProperty().SetColor(1.0, 0.0, 0.0)
			elif uses_scalars:
				if mapper is not None:
					mapper.SetScalarVisibility(1)
			else:
				if mapper is not None:
					mapper.SetScalarVisibility(0)
				col = getattr(cloud, "color", None)
				if isinstance(col, QColor):
					r, g, b, _a = col.getRgbF()
					actor.GetProperty().SetColor(float(r), float(g), float(b))
			if mapper is not None:
				mapper.Modified()
			actor.Modified()
		except Exception:
			pass

	def _request_collision_overlay_render(self) -> None:
		"""Coalesce overlay updates from one ``check_all`` into a single VTK render."""
		if self._collision_overlay_render_pending:
			return
		self._collision_overlay_render_pending = True
		from PyQt6.QtCore import QTimer

		QTimer.singleShot(0, self._flush_collision_overlay_render)

	def _flush_collision_overlay_render(self) -> None:
		self._collision_overlay_render_pending = False
		try:
			self._plotter.render()
		except Exception:
			pass

	# --- Creation / sync ---
	def _create_actor_recursive(self, entity: Entity) -> None:
		self._sync_mesh(entity.id)
		self._sync_point_cloud(entity.id)
		for child in entity.children:
			self._create_actor_recursive(child)

	def _sync_mesh(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return

		mesh = entity.get_component(MeshComponent)
		if mesh is None:
			# No mesh => no actor
			self._remove_actor(entity_id)
			return

		# Check if we actually need to rebuild the actor
		effective_path = (
			mesh.effective_custom_path()
			if hasattr(mesh, "effective_custom_path")
			else mesh.custom_path
		)
		current_state = {
			"shape": mesh.shape,
			"path": effective_path,
			"source_material": bool(getattr(mesh, "source_material", False)),
			"color": mesh.color.name() if hasattr(mesh.color, "name") else str(mesh.color)
		}
		if entity_id in self._id_to_actor and self._entity_mesh_state.get(entity_id) == current_state:
			# Only transform changed; SetUserTransform is handled by _sync_transform (called by _on_entity_changed)
			return

		pv_mesh: Optional[pv.DataSet] = None
		use_material_colors: bool = False
		if mesh.shape == "cube":
			pv_mesh = pv.Cube(center=(0.0, 0.0, 0.0), x_length=1.0, y_length=1.0, z_length=1.0)
		elif mesh.shape == "sphere":
			pv_mesh = pv.Sphere(radius=0.5, center=(0.0, 0.0, 0.0))
		elif mesh.shape == "custom":
			if effective_path:
				try:
					abs_path = resolve_mesh_path_for_read(
						self._scene.project_root,
						effective_path,
					)
					pv_mesh, use_material_colors = self._normalize_dataset_for_actor(
						pv.read(abs_path) if abs_path else None,
						abs_path,
						bool(getattr(mesh, "source_material", False)),
					)
				except Exception:
					pv_mesh = None
					use_material_colors = False

		if pv_mesh is None:
			# Invalid mesh => no actor
			self._remove_actor(entity_id)
			return

		# Remove and re-add actor (simpler + reliable across PyVista versions).
		# Mesh state is recorded *after* a successful add — ``_remove_actor``
		# clears it, and recording beforehand made every play-stop
		# ``entity_changed`` force a rebuild (orphan actors → duplicated UUT).
		self._remove_actor(entity_id)

		# Disable internal render and camera reset to prevent "origin flash"
		actor = self._plotter.add_mesh(pv_mesh, pickable=True, reset_camera=False, render=False)
		self._id_to_actor[entity_id] = actor
		self._actor_to_id[self._actor_key(actor)] = entity_id
		self._entity_uses_material_colors[entity_id] = use_material_colors
		self._entity_mesh_state[entity_id] = current_state

		# Color (apply red overlay if the collider says we're currently intersecting).
		if use_material_colors:
			try:
				mapper = actor.GetMapper()
				if mapper is not None:
					mapper.SetScalarVisibility(1)
			except Exception:
				pass
		self._apply_collision_repaint(entity_id)

		actor.SetVisibility(True)
		self._sync_transform(entity_id)
		if self._selection is not None and self._selection.is_entity_id_selected(entity_id):
			if self._selection_highlight_mode == "bbox":
				self._update_selection_bbox(entity_id)
			else:
				self._update_selection_outline(entity_id)

	def _sync_point_cloud(self, entity_id: str) -> None:
		"""Create/update/remove the VTK points actor for ``PointCloudComponent``."""
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return

		cloud = entity.get_component(PointCloudComponent)
		if cloud is None:
			self._remove_point_cloud_actor(entity_id)
			return

		try:
			point_size = float(getattr(cloud, "point_size", 2.0) or 2.0)
		except Exception:
			point_size = 2.0
		try:
			opacity = float(getattr(cloud, "opacity", 1.0) or 1.0)
		except Exception:
			opacity = 1.0
		opacity = max(0.0, min(1.0, opacity))
		try:
			scale = float(getattr(cloud, "scale", 1000.0) or 1000.0)
		except Exception:
			scale = 1000.0
		if scale <= 0.0:
			scale = 1000.0
		use_vertex_colors = bool(getattr(cloud, "use_vertex_colors", True))
		file_path = str(getattr(cloud, "file_path", "") or "")
		color = getattr(cloud, "color", None)
		color_key = color.name() if hasattr(color, "name") else str(color)

		current_state = {
			"path": file_path,
			"color": color_key,
			"use_vertex_colors": use_vertex_colors,
			"point_size": point_size,
			"opacity": opacity,
			"scale": scale,
		}
		if (
			entity_id in self._point_cloud_actors
			and self._point_cloud_state.get(entity_id) == current_state
		):
			return

		self._remove_point_cloud_actor(entity_id)

		if not file_path.strip():
			self._point_cloud_state.pop(entity_id, None)
			return

		abs_path = resolve_mesh_path_for_read(self._scene.project_root, file_path)
		if not abs_path:
			return

		try:
			points, colors = load_point_cloud(abs_path)
		except PointCloudLoadError as exc:
			print(f"PointCloud load failed ({entity.name}): {exc}", flush=True)
			return
		except Exception as exc:
			print(f"PointCloud load failed ({entity.name}): {exc}", flush=True)
			return

		if scale != 1.0:
			points = np.asarray(points, dtype=np.float64) * float(scale)

		try:
			poly = pv.PolyData(points)
		except Exception as exc:
			print(f"PointCloud PolyData failed ({entity.name}): {exc}", flush=True)
			return

		scalars_name = None
		if use_vertex_colors and colors is not None and len(colors) == len(points):
			try:
				poly.point_data["RGB"] = np.asarray(colors, dtype=np.float64)
				poly.set_active_scalars("RGB")
				scalars_name = "RGB"
			except Exception:
				scalars_name = None

		try:
			actor = self._plotter.add_mesh(
				poly,
				style="points",
				point_size=point_size,
				opacity=opacity,
				pickable=True,
				reset_camera=False,
				render=False,
				scalars=scalars_name,
				rgb=bool(scalars_name),
			)
		except TypeError:
			# Older pyvista may not accept rgb=
			try:
				actor = self._plotter.add_mesh(
					poly,
					style="points",
					point_size=point_size,
					opacity=opacity,
					pickable=True,
					reset_camera=False,
					render=False,
					scalars=scalars_name,
				)
			except Exception as exc:
				print(f"PointCloud add_mesh failed ({entity.name}): {exc}", flush=True)
				return
		except Exception as exc:
			print(f"PointCloud add_mesh failed ({entity.name}): {exc}", flush=True)
			return

		self._point_cloud_actors[entity_id] = actor
		self._actor_to_id[self._actor_key(actor)] = entity_id
		self._point_cloud_state[entity_id] = current_state
		self._point_cloud_uses_scalars[entity_id] = bool(scalars_name)

		if scalars_name is None:
			try:
				if isinstance(color, QColor):
					r, g, b, _a = color.getRgbF()
					actor.GetProperty().SetColor(float(r), float(g), float(b))
					mapper = actor.GetMapper()
					if mapper is not None:
						mapper.SetScalarVisibility(0)
			except Exception:
				pass
		else:
			try:
				mapper = actor.GetMapper()
				if mapper is not None:
					mapper.SetScalarVisibility(1)
			except Exception:
				pass

		try:
			actor.GetProperty().SetPointSize(float(point_size))
			actor.GetProperty().SetOpacity(float(opacity))
		except Exception:
			pass

		actor.SetVisibility(True)
		self._sync_transform(entity_id)
		self._apply_collision_repaint(entity_id)

	def _remove_point_cloud_actor(self, entity_id: str) -> None:
		self._point_cloud_state.pop(entity_id, None)
		self._point_cloud_uses_scalars.pop(entity_id, None)
		actor = self._point_cloud_actors.pop(entity_id, None)
		if actor is None:
			return
		removed = False
		try:
			result = self._plotter.remove_actor(
				actor, reset_camera=False, render=False
			)
			removed = True if result is None else bool(result)
		except TypeError:
			try:
				result = self._plotter.remove_actor(actor, reset_camera=False)
				removed = True if result is None else bool(result)
			except Exception:
				removed = False
		except Exception:
			removed = False
		if not removed:
			try:
				ren = getattr(self._plotter, "renderer", None)
				if ren is not None:
					ren.RemoveActor(actor)
			except Exception:
				pass
		try:
			self._actor_to_id.pop(self._actor_key(actor), None)
		except Exception:
			pass

	def _normalize_dataset_for_actor(
		self,
		dataset,
		abs_path: str = "",
		source_material_enabled: bool = False,
	) -> tuple[Optional[pv.DataSet], bool]:
		"""
		Flatten reader output (including MultiBlock from glTF-like assets) into
		a renderable single dataset for add_mesh().
		"""
		if dataset is None:
			return None, False
		try:
			if isinstance(dataset, pv.MultiBlock):
				blocks = self._collect_leaf_blocks(dataset)
				if not blocks:
					return None, False
				material_colors = self._load_material_colors(abs_path) if source_material_enabled else []
				merged: Optional[pv.DataSet] = None
				use_material_colors = len(material_colors) > 0
				for i, block in enumerate(blocks):
					try:
						surface = block.extract_surface()
					except Exception:
						surface = block
					if use_material_colors and getattr(surface, "n_cells", 0) > 0:
						rgb = material_colors[i] if i < len(material_colors) else material_colors[-1]
						cell_colors = np.tile(np.array(rgb, dtype=np.float32), (int(surface.n_cells), 1))
						surface = surface.copy(deep=True)
						surface.cell_data["__ms_material_rgb_base"] = cell_colors
						surface.cell_data["__ms_material_rgb"] = np.array(cell_colors, copy=True)
					if merged is None:
						merged = surface
					else:
						merged = merged.merge(surface)
				if merged is not None and use_material_colors and "__ms_material_rgb" in merged.cell_data:
					try:
						merged.set_active_scalars("__ms_material_rgb", preference="cell")
					except Exception:
						pass
				return merged, bool(use_material_colors and merged is not None)
		except Exception:
			return None, False
		return dataset, False

	def _collect_leaf_blocks(self, dataset) -> list[pv.DataSet]:
		"""Collect all non-MultiBlock leaves in traversal order."""
		leaves: list[pv.DataSet] = []
		try:
			if isinstance(dataset, pv.MultiBlock):
				for block in dataset:
					leaves.extend(self._collect_leaf_blocks(block))
			elif dataset is not None:
				leaves.append(dataset)
		except Exception:
			pass
		return leaves

	def _load_material_colors(self, abs_path: str) -> list[list[float]]:
		"""Load optional sidecar diffuse colors generated during DAE->GLB conversion."""
		if not abs_path:
			return []
		p = Path(abs_path)
		if p.suffix.lower() not in (".glb", ".gltf"):
			return []
		sidecar = p.with_suffix(p.suffix + ".materials.json")
		if not sidecar.is_file():
			return []
		try:
			payload = json.loads(sidecar.read_text(encoding="utf-8"))
			colors = payload.get("diffuse_colors_rgb", [])
			if isinstance(colors, list):
				return [c for c in colors if isinstance(c, list) and len(c) >= 3]
		except Exception:
			return []
		return []

	def _sync_transform(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			return
		world = self._world_matrix_from_ecs(entity)
		vtk_m = vtk_matrix_from_qmatrix(world)

		actor = self._id_to_actor.get(entity_id)
		if actor is not None:
			# SetUserMatrix is faster and avoids creating a full vtkTransform pipeline per frame.
			# Ensure UserTransform is None to avoid conflicting pipelines.
			actor.SetUserTransform(None)
			actor.SetUserMatrix(vtk_m)
			actor.Modified()

		cloud = self._point_cloud_actors.get(entity_id)
		if cloud is not None:
			cloud.SetUserTransform(None)
			cloud.SetUserMatrix(vtk_m)
			cloud.Modified()

		if self._outline_enabled and entity_id in self._selection_outline_by_id:
			out = self._selection_outline_by_id[entity_id]
			out.SetUserTransform(None)
			out.SetUserMatrix(vtk_m)
			out.Modified()
		if entity_id in self._selection_bbox_by_id:
			bbox = self._selection_bbox_by_id[entity_id]
			bbox.SetUserTransform(None)
			bbox.SetUserMatrix(vtk_m)
			bbox.Modified()

	def _sync_transform_recursive(self, entity: Entity) -> None:
		self._sync_transform(entity.id)
		for child in entity.children:
			self._sync_transform_recursive(child)

	def _world_matrix_from_ecs(self, entity: Entity) -> QMatrix4x4:
		# Accumulate local matrices up to root
		stack: list[QMatrix4x4] = []
		curr: Optional[Entity] = entity
		while curr is not None:
			t = curr.get_component(TransformComponent)
			if t is None:
				stack.append(QMatrix4x4())
			else:
				stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
			curr = curr.parent
		world = QMatrix4x4()
		for m in reversed(stack):
			world = world * m
		return world

	# --- Selection highlight ---
	_HIGHLIGHT_PRIMARY_RGB = (1.0, 0.9, 0.2)
	_HIGHLIGHT_SECONDARY_RGB = (1.0, 0.6, 0.1)

	def _is_primary_selection(self, entity_id: str) -> bool:
		if self._selection is None:
			return True
		primary = self._selection.current
		return primary is None or primary.id == entity_id

	def _selection_highlight_rgb(self, entity_id: str) -> tuple[float, float, float]:
		if self._is_primary_selection(entity_id):
			return self._HIGHLIGHT_PRIMARY_RGB
		return self._HIGHLIGHT_SECONDARY_RGB

	def _refresh_selection_highlights(self, *_args) -> None:
		self._clear_selection_outline()
		self._clear_selection_bbox()
		primary = self._selection.current if self._selection is not None else None
		if self._selection_mode != "object":
			self._apply_edges(primary.id if primary is not None else None)
		elif self._selection is not None and self._outline_enabled:
			for eid in self._selection.selected_ids():
				if self._selection_highlight_mode == "bbox":
					self._update_selection_bbox(eid)
				else:
					self._update_selection_outline(eid)
		try:
			self._refresh_collider_visuals()
			self._plotter.render()
		except Exception:
			pass

	def _refresh_collider_visuals(self) -> None:
		if self._selection is None:
			# No selection model: hide all collider visuals.
			for eid in list(self._collider_vis_by_id.keys()):
				self._remove_collider_visual(eid)
			return
		selected = set(self._selection.selected_ids())
		# Remove visuals for non-selected entities.
		for eid in list(self._collider_vis_by_id.keys()):
			if eid not in selected:
				self._remove_collider_visual(eid)
		# Sync visuals for selected entities.
		for eid in selected:
			self._sync_collider_visual(eid)

	def _sync_collider_visual_recursive(self, entity: Entity) -> None:
		self._sync_collider_visual(entity.id)
		for child in entity.children:
			self._sync_collider_visual_recursive(child)

	def _sync_collider_visual(self, entity_id: str) -> None:
		entity = self._scene.find_by_id(entity_id)
		if entity is None:
			self._remove_collider_visual(entity_id)
			return
		collider = collision_component(entity)
		if collider is None:
			self._remove_collider_visual(entity_id)
			return
		if not bool(getattr(collider, "render_collider", False)):
			self._remove_collider_visual(entity_id)
			return
		if self._selection is None or not self._selection.is_entity_id_selected(entity_id):
			self._remove_collider_visual(entity_id)
			return

		pv_mesh = self._collider_dataset_for_entity(entity, collider)
		if pv_mesh is None:
			self._remove_collider_visual(entity_id)
			return
		try:
			surface = pv_mesh.extract_surface()
		except Exception:
			surface = pv_mesh

		self._remove_collider_visual(entity_id)
		try:
			actor = self._plotter.add_mesh(
				surface,
				pickable=False,
				reset_camera=False,
				render=False,
				style="wireframe",
				color=(0.2, 0.9, 1.0),
				line_width=2.0,
				opacity=0.9,
			)
		except Exception:
			return
		try:
			actor.GetProperty().SetLighting(False)
		except Exception:
			pass
		self._collider_vis_by_id[entity_id] = actor
		self._sync_collider_visual_transform(entity_id)

	def _sync_collider_visual_transform(self, entity_id: str) -> None:
		actor = self._collider_vis_by_id.get(entity_id)
		entity = self._scene.find_by_id(entity_id)
		if actor is None or entity is None:
			return
		collider = collision_component(entity)
		# World-baked octomap overlay is already in world millimetres.
		if isinstance(collider, PointCloudColliderComponent) and collider.is_octomap_mode():
			vtk_m = vtk_matrix_from_qmatrix(QMatrix4x4())
		else:
			world = self._world_matrix_from_ecs(entity)
			vtk_m = vtk_matrix_from_qmatrix(world)
		try:
			actor.SetUserTransform(None)
			actor.SetUserMatrix(vtk_m)
			actor.Modified()
		except Exception:
			pass

	def _remove_collider_visual(self, entity_id: str) -> None:
		actor = self._collider_vis_by_id.pop(entity_id, None)
		if actor is None:
			return
		try:
			self._plotter.remove_actor(actor, reset_camera=False)
		except Exception:
			try:
				self._plotter.remove_actor(actor)
			except Exception:
				pass

	def _collider_dataset_for_entity(self, entity: Entity, collider) -> Optional[pv.DataSet]:
		if isinstance(collider, PointCloudColliderComponent):
			try:
				geom = self._scene.collision_system._get_geometry(entity)
			except Exception:
				return None
			if geom is None:
				return None
			poly = None
			cells = getattr(geom, "cells", None)
			if cells is not None:
				from MotionStudio.core.collision.octomap_from_points import vis_polydata_from_cells

				try:
					poly = vis_polydata_from_cells(
						cells,
						float(getattr(geom, "resolution_mm", 10.0) or 10.0),
						max_cells=collider.vis_cell_limit(),
					)
				except Exception:
					poly = None
			if poly is None:
				poly = geom.vis_poly if geom.vis_poly is not None else geom.poly
			if poly is None:
				return None
			try:
				return pv.wrap(poly)
			except Exception:
				return poly
		mesh = entity.get_component(MeshComponent)
		use_mesh_component = bool(getattr(collider, "collider_from_mesh_component", True))
		try:
			pv_mesh: Optional[pv.DataSet] = None
			if use_mesh_component:
				if mesh is None:
					return None
				if mesh.shape == "cube":
					return pv.Cube(center=(0.0, 0.0, 0.0), x_length=1.0, y_length=1.0, z_length=1.0)
				if mesh.shape == "sphere":
					return pv.Sphere(radius=0.5, center=(0.0, 0.0, 0.0))
				if mesh.shape == "custom":
					vis_path = (
						mesh.effective_custom_path()
						if hasattr(mesh, "effective_custom_path")
						else mesh.custom_path
					)
					if vis_path:
						abs_path = resolve_mesh_path_for_read(self._scene.project_root, vis_path)
						return self._normalize_dataset_for_collision_vis(pv.read(abs_path) if abs_path else None)
				return None
			collider_path = str(getattr(collider, "collider_mesh_path", "") or "").strip()
			if not collider_path:
				return None
			abs_path = resolve_mesh_path_for_read(self._scene.project_root, collider_path)
			pv_mesh = self._normalize_dataset_for_collision_vis(pv.read(abs_path) if abs_path else None)
			return self._apply_collider_scale_vis(pv_mesh, collider)
		except Exception:
			return None

	def _normalize_dataset_for_collision_vis(self, dataset) -> Optional[pv.DataSet]:
		"""Flatten nested MultiBlock trees for collider visualization."""
		if dataset is None:
			return None
		try:
			if isinstance(dataset, pv.MultiBlock):
				blocks = self._collect_leaf_blocks(dataset)
				if not blocks:
					return None
				merged: Optional[pv.DataSet] = None
				for block in blocks:
					try:
						surface = block.extract_surface()
					except Exception:
						surface = block
					try:
						surface = surface.triangulate()
					except Exception:
						pass
					if merged is None:
						merged = surface
					else:
						merged = merged.merge(surface)
				return merged
		except Exception:
			return None
		return dataset

	def _apply_collider_scale_vis(self, dataset: Optional[pv.DataSet], collider: ColliderComponent) -> Optional[pv.DataSet]:
		"""Apply collider-local uniform scaling to wireframe visualization geometry."""
		if dataset is None:
			return None
		try:
			scale = float(getattr(collider, "scale", 1.0) or 1.0)
		except Exception:
			scale = 1.0
		if scale <= 0.0:
			scale = 1.0
		if abs(scale - 1.0) < 1e-12:
			return dataset
		try:
			return dataset.scale([scale, scale, scale], inplace=False)
		except Exception:
			return dataset

	# --- Utilities ---
	@staticmethod
	def _actor_key(actor: vtk.vtkActor) -> int:
		# Use the underlying VTK address so picking works even if the Python wrapper differs.
		try:
			s = actor.GetAddressAsString("")  # e.g. "Addr=0x00000123ABCDEF00"
			if "0x" in s:
				return int(s.split("0x", 1)[1], 16)
		except Exception:
			pass
		# Fallback
		return id(actor)

	def _remove_actor(self, entity_id: str) -> None:
		self._entity_mesh_state.pop(entity_id, None)
		self._entity_uses_material_colors.pop(entity_id, None)
		actor = self._id_to_actor.pop(entity_id, None)
		if actor is None:
			return
		removed = False
		try:
			# Prefer no mid-restore render (play-stop storms many removes).
			result = self._plotter.remove_actor(
				actor, reset_camera=False, render=False
			)
			removed = True if result is None else bool(result)
		except TypeError:
			try:
				result = self._plotter.remove_actor(actor, reset_camera=False)
				removed = True if result is None else bool(result)
			except Exception:
				removed = False
		except Exception:
			removed = False
		if not removed:
			# Mapping already dropped; pull the orphan out of the VTK renderer
			# so a subsequent add_mesh cannot leave a duplicated solid.
			try:
				ren = getattr(self._plotter, "renderer", None)
				if ren is not None:
					ren.RemoveActor(actor)
			except Exception:
				pass
		try:
			self._actor_to_id.pop(self._actor_key(actor), None)
		except Exception:
			pass

	def _remove_selection_outline(self, entity_id: str) -> None:
		actor = self._selection_outline_by_id.pop(entity_id, None)
		self._selection_outline_pipeline_by_id.pop(entity_id, None)
		if actor is None:
			return
		try:
			self._plotter.remove_actor(actor, reset_camera=False)
		except Exception:
			try:
				self._plotter.remove_actor(actor)
			except Exception:
				pass

	def _clear_selection_outline(self) -> None:
		for eid in list(self._selection_outline_by_id.keys()):
			self._remove_selection_outline(eid)

	def _update_selection_outline(self, entity_id: str) -> None:
		actor = self._id_to_actor.get(entity_id)
		if actor is None:
			return
		try:
			renderer = getattr(self._plotter, "renderer", None)
			camera = renderer.GetActiveCamera() if renderer is not None else None
			if camera is None:
				return

			# Build silhouette from the actor's mapper input
			mapper = actor.GetMapper()
			if mapper is None:
				return
			input_data = mapper.GetInput()
			if input_data is None:
				return

			geom = vtk.vtkGeometryFilter()
			geom.SetInputData(input_data)

			sil = vtk.vtkPolyDataSilhouette()
			sil.SetInputConnection(geom.GetOutputPort())
			sil.SetCamera(camera)

			sil_mapper = vtk.vtkPolyDataMapper()
			sil_mapper.SetInputConnection(sil.GetOutputPort())

			out_actor = vtk.vtkActor()
			out_actor.SetMapper(sil_mapper)
			out_actor.SetPickable(False)
			r, g, b = self._selection_highlight_rgb(entity_id)
			out_actor.GetProperty().SetColor(r, g, b)
			out_actor.GetProperty().SetLineWidth(3.0)

			# Match transforms using UserMatrix to avoid conflicts
			out_actor.SetUserTransform(None)
			out_actor.SetUserMatrix(actor.GetUserMatrix())

			self._remove_selection_outline(entity_id)
			self._selection_outline_pipeline_by_id[entity_id] = (geom, sil, sil_mapper, out_actor)
			self._selection_outline_by_id[entity_id] = out_actor
			self._plotter.add_actor(out_actor, pickable=False, reset_camera=False)
		except Exception:
			# If silhouette pipeline fails (e.g. missing polydata), silently skip.
			return
	
	def _remove_selection_bbox(self, entity_id: str) -> None:
		actor = self._selection_bbox_by_id.pop(entity_id, None)
		if actor is None:
			return
		try:
			self._plotter.remove_actor(actor, reset_camera=False)
		except Exception:
			try:
				self._plotter.remove_actor(actor)
			except Exception:
				pass

	def _clear_selection_bbox(self) -> None:
		for eid in list(self._selection_bbox_by_id.keys()):
			self._remove_selection_bbox(eid)

	def _update_selection_bbox(self, entity_id: str) -> None:
		actor = self._id_to_actor.get(entity_id)
		if actor is None:
			return
		try:
			mapper = actor.GetMapper()
			if mapper is None:
				return
			input_data = mapper.GetInput()
			if input_data is None:
				return
			
			# Calculate bounding box in local space
			bounds = input_data.GetBounds()
			if bounds is None or len(bounds) < 6:
				return
			
			x_min, x_max = bounds[0], bounds[1]
			y_min, y_max = bounds[2], bounds[3]
			z_min, z_max = bounds[4], bounds[5]
			
			# Create a wireframe box
			bbox_source = vtk.vtkCubeSource()
			bbox_source.SetBounds(x_min, x_max, y_min, y_max, z_min, z_max)
			bbox_source.Update()
			
			bbox_mapper = vtk.vtkPolyDataMapper()
			bbox_mapper.SetInputConnection(bbox_source.GetOutputPort())
			
			bbox_actor = vtk.vtkActor()
			bbox_actor.SetMapper(bbox_mapper)
			bbox_actor.SetPickable(False)
			r, g, b = self._selection_highlight_rgb(entity_id)
			bbox_actor.GetProperty().SetColor(r, g, b)
			bbox_actor.GetProperty().SetRepresentationToWireframe()
			bbox_actor.GetProperty().SetLineWidth(3.0)
			bbox_actor.GetProperty().LightingOff()
			
			# Match transforms using UserMatrix
			bbox_actor.SetUserTransform(None)
			bbox_actor.SetUserMatrix(actor.GetUserMatrix())
			
			self._remove_selection_bbox(entity_id)
			self._selection_bbox_by_id[entity_id] = bbox_actor
			self._plotter.add_actor(bbox_actor, pickable=False, reset_camera=False)
		except Exception:
			# If bbox pipeline fails, silently skip.
			return



from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from MotionStudio.utils.mesh_assets import _unique_path

DEFAULT_DECIMATE_RATIO = 0.2
MIN_DECIMATE_RATIO = 0.01
MAX_DECIMATE_RATIO = 1.0


@dataclass(frozen=True)
class DecimateResult:
	"""Baked LOD STL plus face counts for the Inspector summary."""

	dest: Path
	faces_before: int
	faces_after: int


def clamp_decimate_ratio(ratio: float) -> float:
	"""Clamp a keep-fraction to the Inspector range."""
	try:
		value = float(ratio)
	except (TypeError, ValueError):
		value = DEFAULT_DECIMATE_RATIO
	return max(MIN_DECIMATE_RATIO, min(MAX_DECIMATE_RATIO, value))


def decimate_mesh_to_stl(source: Path, dest_dir: Path, ratio: float) -> DecimateResult:
	"""
	Bake a quadric-collapse LOD as a binary STL.

	``ratio`` is the fraction of faces to **keep** (Blender Collapse analogue).
	Coordinates are left in engine millimetres. The source file is not overwritten;
	the dest name is ``<stem>_lod.stl`` with a numeric suffix on collision.
	"""
	try:
		import pyvista as pv  # type: ignore
	except Exception as exc:
		raise OSError(
			"Mesh decimate requires PyVista / VTK. Install dependencies: "
			"'pip install pyvista vtk'."
		) from exc

	source = Path(source)
	if not source.is_file():
		raise FileNotFoundError(f"Mesh file not found: {source}")

	keep = clamp_decimate_ratio(ratio)
	try:
		dataset = pv.read(str(source))
	except Exception as exc:
		raise OSError(f"Failed to read mesh for decimate: {source}") from exc
	if dataset is None:
		raise OSError(f"Failed to read mesh for decimate: {source}")

	surface = _to_triangle_surface(dataset)
	faces_before = int(getattr(surface, "n_cells", 0) or 0)
	if faces_before <= 0:
		raise OSError(f"Mesh has no triangles to decimate: {source}")

	reduction = max(0.0, min(0.99, 1.0 - keep))
	if reduction <= 1e-6:
		reduced = surface
	else:
		try:
			reduced = surface.decimate(target_reduction=reduction)
		except Exception as exc:
			raise OSError(f"Quadric decimation failed: {source}") from exc
	faces_after = int(getattr(reduced, "n_cells", 0) or 0)
	if faces_after <= 0:
		raise OSError(f"Decimate produced no triangles: {source}")

	stem = source.stem
	if not stem.lower().endswith("_lod"):
		stem = f"{stem}_lod"
	dest = _unique_path(Path(dest_dir), stem, ".stl")
	try:
		reduced.save(str(dest), binary=True)
	except TypeError:
		reduced.save(str(dest))
	except Exception as exc:
		raise OSError(f"Failed to write decimated STL: {dest}") from exc
	if not dest.is_file() or dest.stat().st_size <= 0:
		raise OSError(f"Failed to write decimated STL: {dest}")
	return DecimateResult(dest=dest, faces_before=faces_before, faces_after=faces_after)


def _to_triangle_surface(dataset):
	"""Flatten MultiBlock / volume datasets to a triangulated surface."""
	import pyvista as pv  # type: ignore

	mesh = dataset
	try:
		if isinstance(mesh, pv.MultiBlock):
			mesh = mesh.combine()
	except Exception:
		pass
	try:
		mesh = mesh.extract_surface(algorithm="dataset_surface")
	except TypeError:
		try:
			mesh = mesh.extract_surface()
		except Exception:
			pass
	except Exception:
		pass
	try:
		mesh = mesh.triangulate()
	except Exception as exc:
		raise OSError("Failed to triangulate mesh for decimate.") from exc
	return mesh

from __future__ import annotations

from typing import Annotated, Literal

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import ColorField, FilePath, Group, Order, Range, ReadOnly, Tooltip, inspector_button
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.utils.mesh_assets import MESH_FILE_FILTER
from MotionStudio.utils.mesh_decimate import DEFAULT_DECIMATE_RATIO, MIN_DECIMATE_RATIO, MAX_DECIMATE_RATIO
from PyQt6.QtGui import QVector3D, QColor
import time
import numpy as np


@register_component
class MeshComponent(Component):
	type_name = "Mesh"
	category = "Rendering"
	description = (
		"<p><b>Mesh</b></p>"
		"<p>Draws a primitive or imported 3D model on this entity. Geometry follows the "
		"entity Transform. Scene units are millimetres (1 unit = 1 mm).</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Set <b>shape</b> to cube or sphere for a primitive, or <b>custom</b> to load a file.</li>"
		"<li>Browse <b>custom_path</b> for STL, OBJ, FBX, DAE, glTF, GLB, or STEP/STP. STEP files are converted to STL on import. External files are copied into the project's <code>models/</code> folder.</li>"
		"<li>Enable <b>source_material</b> to use imported colours when available; otherwise the uniform <b>color</b> is used.</li>"
		"<li>Open <b>Decimate</b> to bake a lower-poly STL (quadric collapse) next to the original. Turn on <b>use_decimated_mesh</b> to display the LOD; turn it off to show the detailed file again.</li>"
		"<li>Add a <b>Collider</b> on the same entity if this mesh should participate in collision checks.</li>"
		"</ul>"
	)

	shape: Annotated[Literal["cube", "sphere", "custom"], Tooltip("Primitive shape or custom mesh")]
	custom_path: Annotated[str, FilePath(MESH_FILE_FILTER), Tooltip("Project-relative mesh path; external files are copied into the project's models/ folder. STEP/STP is converted to STL on import.")]
	source_material: Annotated[bool, Tooltip("Use imported source material colors (when available) instead of custom unicolor")]
	color: Annotated[QColor, ColorField(), Tooltip("Material color")]
	use_decimated_mesh: Annotated[
		bool,
		Group("Decimate"),
		Order(0),
		Tooltip("When on, the viewport and collision use the baked LOD. When off, the original custom_path is used. Run Decimate first."),
	]
	decimate_ratio: Annotated[
		float,
		Range(MIN_DECIMATE_RATIO, MAX_DECIMATE_RATIO, step=0.01, decimals=2),
		Group("Decimate"),
		Order(1),
		Tooltip("Fraction of faces to keep (Blender Collapse analogue). 0.2 keeps 20%."),
	]
	decimated_path: Annotated[
		str,
		Group("Decimate"),
		Order(2),
		ReadOnly(),
		FilePath(MESH_FILE_FILTER),
		Tooltip("Baked lower-poly STL written by Decimate. Used only when Use Decimated Mesh is on."),
	]

	def __init__(
		self,
		shape: str = "cube",
		custom_path: str = "",
		source_material: bool = False,
		color: QColor | None = None,
		decimate_ratio: float = DEFAULT_DECIMATE_RATIO,
		use_decimated_mesh: bool = False,
		decimated_path: str = "",
	) -> None:
		# shape: "cube" | "sphere" | "custom"
		self.shape = shape
		self.custom_path = custom_path
		self.source_material = bool(source_material)
		self.color = color or QColor(200, 200, 200)
		self.decimate_ratio = float(decimate_ratio)
		self.use_decimated_mesh = bool(use_decimated_mesh)
		self.decimated_path = str(decimated_path or "")

		self._last_time = time.time()
		self._check = False

	def can_decimate(self) -> bool:
		"""True when this mesh is a custom file that can be baked to an LOD STL."""
		return str(self.shape) == "custom" and bool(str(self.custom_path or "").strip())

	def effective_custom_path(self) -> str:
		"""Path used for viewport / collision: LOD when enabled and present, else custom_path."""
		if bool(self.use_decimated_mesh):
			lod = str(self.decimated_path or "").strip()
			if lod:
				return lod
		return str(self.custom_path or "")

	@inspector_button(
		"Decimate",
		tooltip=(
			"Bake a lower-poly STL (VTK quadric collapse) from custom_path. "
			"The original file is kept. Turn on Use Decimated Mesh to display the LOD. "
			"Path Generation CAD vertex ids become stale while the LOD is shown."
		),
		group="Decimate",
		order=10,
	)
	def decimate(self):
		"""Bake an LOD STL onto decimated_path (undoable)."""
		from pathlib import Path

		from PyQt6.QtWidgets import QMessageBox

		from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read
		from MotionStudio.utils.mesh_decimate import clamp_decimate_ratio, decimate_mesh_to_stl

		if not self.can_decimate():
			QMessageBox.warning(
				None,
				"Decimate",
				"Decimate requires a custom mesh file (not cube or sphere).",
			)
			return False, "decimate requires a custom mesh file"

		entity = self.entity
		scene = entity.scene if entity is not None else None
		project_root = scene.project_root if scene is not None else None
		abs_path = resolve_mesh_path_for_read(project_root, self.custom_path)
		if not abs_path or not Path(abs_path).is_file():
			QMessageBox.warning(None, "Decimate", f"Mesh file not found:\n{self.custom_path}")
			return False, "mesh file not found"

		source = Path(abs_path)
		if project_root is not None:
			out_dir = Path(project_root) / "models"
		else:
			out_dir = source.parent
		ratio = clamp_decimate_ratio(self.decimate_ratio)

		def _run():
			return decimate_mesh_to_stl(source, out_dir, ratio)

		def _apply(result) -> None:
			stored = str(result.dest)
			if project_root is not None:
				try:
					stored = result.dest.resolve().relative_to(Path(project_root).resolve()).as_posix()
				except ValueError:
					stored = str(result.dest)
			self._commit_decimated_path(stored)
			QMessageBox.information(
				None,
				"Decimate",
				(
					f"Wrote {stored} ({result.faces_before} → {result.faces_after} faces).\n\n"
					"Use Decimated Mesh is on. Turn it off to show the original file. "
					"While the LOD is shown, Vertex / edge / face picks and Path Generation "
					"CAD vertex ids on this mesh are stale. Custom Segments that store "
					"positions are unchanged."
				),
			)

		loading = scene.loading_controller if scene is not None else None
		if loading is None:
			try:
				_apply(_run())
			except (FileNotFoundError, OSError) as exc:
				QMessageBox.warning(None, "Decimate", str(exc))
				return False, str(exc)
			return True, "decimated"

		def _on_error(exc: Exception) -> None:
			QMessageBox.warning(None, "Decimate", str(exc))

		if not loading.run("Decimating mesh...", _run, _apply, on_error=_on_error):
			QMessageBox.warning(None, "Decimate", "Another load operation is already in progress.")
			return False, "another load operation is already in progress"
		return True, "decimating"

	def _commit_decimated_path(self, stored_path: str) -> None:
		"""Store the LOD path and enable Use Decimated Mesh (undoable)."""
		old_path = str(self.decimated_path or "")
		old_use = bool(self.use_decimated_mesh)
		need_path = stored_path != old_path
		need_use = not old_use
		if not need_path and not need_use:
			return
		entity = self.entity
		scene = entity.scene if entity is not None else None
		stack = _editor_undo_stack()
		if scene is not None and entity is not None and stack is not None:
			from MotionStudio.core.undo.commands import PropertyChangeCommand

			stack.beginMacro("Mesh.Decimate")
			try:
				if need_path:
					stack.push(
						PropertyChangeCommand(
							scene,
							entity.id,
							self.type_name,
							"decimated_path",
							old_path,
							stored_path,
							text="Mesh.decimated_path",
						)
					)
				if need_use:
					stack.push(
						PropertyChangeCommand(
							scene,
							entity.id,
							self.type_name,
							"use_decimated_mesh",
							old_use,
							True,
							text="Mesh.use_decimated_mesh",
						)
					)
			finally:
				stack.endMacro()
			return
		self.decimated_path = stored_path
		self.use_decimated_mesh = True

	def update(self, delta_time: float):
		pass


def _editor_undo_stack():
	"""Best-effort QUndoStack from the editor main window."""
	try:
		from PyQt6.QtWidgets import QApplication

		app = QApplication.instance()
		if app is None:
			return None
		for widget in app.topLevelWidgets():
			stack = getattr(widget, "_undo_stack", None)
			if stack is not None:
				return stack
	except Exception:
		return None
	return None



"""Wire format for the TCP command server.

Requests (one UTF-8 line, ``\\n`` terminated)::

	RUN,<entity_name>,<component_type_name>,<function_name>
	EDIT,<entity_name>,<component_type_name>,<property_name>,<value>
	GET,<entity_name>,<component_type_name>,<property_name>
	WAIT,<seconds>
	OPEN,<project_folder_path>

Response (one UTF-8 JSON object per line, ``\\n`` terminated)::

	{"status": "PASS", "return": ""}                       succeeded, nothing to report
	{"status": "PASS", "return": "150,0,25"}               succeeded with a return value
	{"status": "FAIL", "return": "entity not found: Cube"} failed, with the reason

Both keys are always present, so every verb answers the same shape and a client
can read ``status`` without inspecting the payload first.

Splitting is bounded so only the leading fields are structural: a ``RUN`` or
``GET`` line splits into four fields and an ``EDIT`` line into five, which lets
a value carry commas (``EDIT,Cube,Transform,position,10,20,30``).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional, Tuple

RUN_OP = "RUN"
EDIT_OP = "EDIT"
GET_OP = "GET"
WAIT_OP = "WAIT"
OPEN_OP = "OPEN"
RESPONSE_TERMINATOR = "\n"

# ``status`` values. PASS means the action's intent succeeded, not merely that
# the command was understood.
STATUS_PASS = "PASS"
STATUS_FAIL = "FAIL"
# Response object keys.
STATUS_KEY = "status"
RETURN_KEY = "return"

_USAGE = {
	RUN_OP: "expected RUN,<entity>,<component>,<function>",
	EDIT_OP: "expected EDIT,<entity>,<component>,<property>,<value>",
	GET_OP: "expected GET,<entity>,<component>,<property>",
	WAIT_OP: "expected WAIT,<seconds>",
	OPEN_OP: "expected OPEN,<project folder path>",
}

_FOUR_FIELD_OPS = {RUN_OP, GET_OP}


@dataclass(frozen=True)
class RemoteCommand:
	"""A parsed request line.

	``member`` is the button name for ``RUN`` and the property name for
	``EDIT`` / ``GET``; ``value`` is the ``EDIT`` payload, the ``WAIT``
	duration in seconds, or the ``OPEN`` project folder path.
	"""

	op: str
	entity: str
	component: str
	member: str
	value: Optional[str] = None

	def describe(self) -> str:
		if self.op == WAIT_OP:
			return f"{WAIT_OP} {self.value}s"
		if self.op == OPEN_OP:
			return f"{OPEN_OP} {self.value}"
		suffix = f" = {self.value}" if self.value is not None else ""
		return f"{self.op} {self.entity}.{self.component}.{self.member}{suffix}"


def parse_command(line: str) -> Tuple[Optional[RemoteCommand], str]:
	"""Parse one request line.

	Returns ``(command, "")`` on success or ``(None, reason)`` on a malformed
	line. The verb is case-insensitive and every field except the ``EDIT``
	value is stripped.
	"""
	text = str(line or "").strip()
	if not text:
		return None, "empty command"

	op = text.split(",", 1)[0].strip().upper()
	if op not in _USAGE:
		return None, f"unknown command: {text.split(',', 1)[0].strip()}"

	if op == WAIT_OP:
		return _parse_wait(text)
	if op == OPEN_OP:
		return _parse_open(text)

	field_count = 4 if op in _FOUR_FIELD_OPS else 5
	parts = text.split(",", field_count - 1)
	if len(parts) < field_count:
		return None, _USAGE[op]

	entity = parts[1].strip()
	component = parts[2].strip()
	member = parts[3].strip()
	# Keep the value verbatim apart from surrounding whitespace so vectors,
	# colors, and paths survive intact.
	value = parts[4].strip() if op == EDIT_OP else None

	if not entity:
		return None, "entity name is empty"
	if not component:
		return None, "component name is empty"
	if not member:
		if op == RUN_OP:
			return None, "function name is empty"
		return None, "property name is empty"

	return RemoteCommand(op=op, entity=entity, component=component, member=member, value=value), ""


def _parse_wait(text: str) -> Tuple[Optional[RemoteCommand], str]:
	parts = text.split(",", 1)
	if len(parts) < 2 or not str(parts[1]).strip():
		return None, _USAGE[WAIT_OP]
	raw = str(parts[1]).strip()
	try:
		seconds = float(raw)
	except ValueError:
		return None, "WAIT duration must be a number of seconds"
	if seconds != seconds or seconds < 0.0:
		return None, "WAIT duration must be >= 0"
	if seconds == float("inf"):
		return None, "WAIT duration must be finite"
	return RemoteCommand(op=WAIT_OP, entity="", component="", member="", value=raw), ""


def _strip_path_quotes(text: str) -> str:
	raw = str(text or "").strip()
	if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ("\"", "'"):
		return raw[1:-1].strip()
	return raw


def _parse_open(text: str) -> Tuple[Optional[RemoteCommand], str]:
	parts = text.split(",", 1)
	if len(parts) < 2 or not str(parts[1]).strip():
		return None, _USAGE[OPEN_OP]
	raw = _strip_path_quotes(parts[1])
	if not raw:
		return None, _USAGE[OPEN_OP]
	return RemoteCommand(op=OPEN_OP, entity="", component="", member="", value=raw), ""


def format_request(
	op: str,
	entity: str,
	component: str,
	member: str,
	value: Optional[str] = None,
) -> str:
	"""Build one request line matching :func:`parse_command`.

	``EDIT`` always emits a fifth field so a blank value is ``EDIT,e,c,p,``
	rather than a four-field line the parser would reject.
	"""
	verb = str(op or "").strip().upper()
	if verb == WAIT_OP:
		payload = "" if value is None else str(value)
		return f"{WAIT_OP},{payload}"
	if verb == OPEN_OP:
		payload = "" if value is None else str(value)
		return f"{OPEN_OP},{payload}"
	if verb == EDIT_OP:
		payload = "" if value is None else str(value)
		return f"{verb},{entity},{component},{member},{payload}"
	return f"{verb},{entity},{component},{member}"


def sanitize_output(value: object) -> str:
	"""Flatten a value into the ``return`` field of a response.

	``None`` becomes an empty string (per protocol); everything else is
	stringified with newlines collapsed. JSON would escape a newline rather than
	break framing, but collapsing keeps the mirrored ``logs.txt`` line readable.
	"""
	if value is None:
		return ""
	text = str(value)
	text = text.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
	return " ".join(text.split())


def interpret_button_result(result: object) -> Tuple[bool, object]:
	"""Map an ``@inspector_button`` return value to ``(ok, output)``.

	``PASS`` is reserved for a fulfilled action:

	- ``None`` / ``True`` → success, empty ``return``
	- ``False`` → failure
	- ``(bool, payload)`` → that flag and payload
	- anything else → success carrying that payload

	Async buttons (Connect, Plan Motion, …) return ``True`` to mean *started*;
	the waiter then replies only after the worker reports success or failure.
	"""
	if isinstance(result, tuple) and len(result) == 2 and isinstance(result[0], bool):
		return bool(result[0]), result[1]
	if result is False:
		return False, None
	if result is True:
		return True, None
	return True, result


def format_response(ok: bool, output: object = None) -> str:
	"""Build one JSON reply line: ``{"status": ..., "return": ...}``.

	Both keys are always emitted -- an empty ``return`` is ``""`` rather than a
	missing key -- so every reply has the same shape regardless of verb.
	``ensure_ascii=False`` keeps non-ASCII status text (em dashes, units) legible
	on a wire that is already UTF-8.
	"""
	payload = {
		STATUS_KEY: STATUS_PASS if ok else STATUS_FAIL,
		RETURN_KEY: sanitize_output(output),
	}
	return json.dumps(payload, ensure_ascii=False) + RESPONSE_TERMINATOR

from __future__ import annotations

from html import unescape
import re
from typing import TYPE_CHECKING, List, Optional

from PyQt6.QtCore import QSize, Qt, QTimer
from PyQt6.QtGui import QVector3D, QUndoStack
from PyQt6.QtWidgets import (
	QCheckBox,
	QComboBox,
	QDoubleSpinBox,
	QFileDialog,
	QFormLayout,
	QGroupBox,
	QHBoxLayout,
	QLabel,
	QLineEdit,
	QMenu,
	QMessageBox,
	QPushButton,
	QScrollArea,
	QSizePolicy,
	QSpinBox,
	QStyle,
	QToolButton,
	QVBoxLayout,
	QWidget,
	QColorDialog,
)
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.selection import SelectionModel
from MotionStudio.core.scene.scene import Scene
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.point_cloud_component import PointCloudComponent
from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
from MotionStudio.ui.inspector.path_generation_section import PathGenerationSection
from MotionStudio.ui.widgets.vector3_editor import Vector3Editor
from MotionStudio.core.ecs.component import components_category_menu_tree
from MotionStudio.core.undo.commands import (
	AddComponentCommand,
	PropertyChangeCommand,
	RemoveComponentCommand,
)
from MotionStudio.ui.inspector.metadata import (
	ColorField,
	ConnectionStatus,
	FilePath,
	FolderPath,
	Header,
	Hidden,
	Range,
	ReadOnly,
	Tooltip,
	VertexPick,
)
from MotionStudio.ui.widgets.connection_status_badge import ConnectionStatusBadge
from MotionStudio.ui.inspector.group_popup import open_inspector_group_dock
from MotionStudio.ui.inspector.tcp_copy import (
	TCP_COPY_HOST_PROPERTY,
	field_is_tcp_writable,
	make_field_label,
	wrap_run_button,
)
from MotionStudio.ui.inspector.reflection import (
	FieldSpec,
	InspectorLayoutRow,
	clone_value,
	iter_editable_fields,
	iter_inspector_layout,
	is_literal_type,
	literal_choices,
	partition_inspector_layout,
)
from MotionStudio.ui.inspector.multi_values import (
	FieldValue,
	common_component_types,
	entity_name_field_value,
	field_value_for,
	find_component,
)
from MotionStudio.utils.mesh_assets import (
	has_source_material_sidecar,
	ingest_mesh_source,
	is_step_mesh,
)
from MotionStudio.core.remote.dispatcher import run_inspector_button
from MotionStudio.core.remote.protocol import format_response

if TYPE_CHECKING:
	from MotionStudio.ui.loading_controller import LoadingController


class InspectorPanel(QWidget):
	_ICON_TOOL_BUTTON_PX = 30

	def __init__(self, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._selection: Optional[SelectionModel] = None
		self.setMinimumWidth(360)
		self._scene: Optional[Scene] = None
		self._undo_stack: Optional[QUndoStack] = None
		self._loading: Optional["LoadingController"] = None
		self._command_logger = None
		self._vertex_pick_manager = None
		self._path_tool_manager = None
		self._active_pick_editor: Optional[Vector3Editor] = None
		self._defer_rebuild: bool = False
		self._pending_rebuild_entity_id: Optional[str] = None
		self._scroll = QScrollArea(self)
		self._scroll.setWidgetResizable(True)
		self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
		self._content = QWidget(self._scroll)
		self._scroll.setWidget(self._content)
		self._vbox = QVBoxLayout(self._content)
		self._vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
		# Feature index -> widget, used for auto-scroll when selecting a feature
		self._path_feature_widgets: dict[int, QWidget] = {}
		# PathGeneration Inspector UI lives in its own module (keeps this panel lean).
		self._path_section = PathGenerationSection(self)

		layout = QVBoxLayout(self)
		layout.setContentsMargins(0, 0, 0, 0)
		layout.addWidget(self._scroll)

	def bind_selection(self, selection: SelectionModel) -> None:
		if self._selection is not None:
			try:
				self._selection.current_entity_changed.disconnect(self._on_selection_changed)
			except Exception:
				pass
			try:
				self._selection.selection_changed.disconnect(self._on_selection_changed)
			except Exception:
				pass
			try:
				self._selection.current_feature_changed.disconnect(self._on_feature_selection_changed)
			except Exception:
				pass
		self._selection = selection
		selection.selection_changed.connect(self._on_selection_changed)
		selection.current_entity_changed.connect(self._on_selection_changed)
		try:
			selection.current_feature_changed.connect(self._on_feature_selection_changed)
		except Exception:
			pass
		try:
			selection.interaction_active_changed.connect(self._on_interaction_active_changed)
		except Exception:
			pass

	def bind_scene(self, scene: Scene) -> None:
		# Disconnect previous scene if any
		try:
			if self._scene is not None:
				self._scene.events.entity_changed.disconnect(self._on_scene_entity_changed)
		except Exception:
			pass
		self._scene = scene
		# Rebuild inspector when the currently selected entity changes (e.g. features added/removed)
		try:
			scene.events.entity_changed.connect(self._on_scene_entity_changed)
		except Exception:
			pass

	def bind_loading(self, loading: Optional["LoadingController"]) -> None:
		self._loading = loading

	def _on_scene_entity_changed(self, entity_id: str) -> None:
		if self._selection is None:
			return
		if entity_id not in self._selection.selected_ids():
			return
		# During gizmo drags we intentionally defer expensive rebuilds
		if self._defer_rebuild:
			self._pending_rebuild_entity_id = entity_id
			return
		self._rebuild_for_selection()

	def _on_interaction_active_changed(self, active: bool) -> None:
		self._defer_rebuild = bool(active)
		if not self._defer_rebuild and self._pending_rebuild_entity_id is not None:
			# Rebuild once after interaction ends
			if self._selection is not None and self._pending_rebuild_entity_id in self._selection.selected_ids():
				self._rebuild_for_selection()
			self._pending_rebuild_entity_id = None
	def bind_undo_stack(self, undo_stack: QUndoStack) -> None:
		self._undo_stack = undo_stack
		try:
			# Rebuild on undo/redo so widgets reflect current values
			undo_stack.indexChanged.connect(lambda _idx: self._rebuild_for_selection())
		except Exception:
			pass

	def bind_command_logger(self, logger) -> None:
		"""Write Inspector button clicks and TCP-style replies to ``logs.txt``."""
		self._command_logger = logger

	def bind_path_tool_manager(self, manager) -> None:
		self._path_tool_manager = manager

	def bind_vertex_pick_manager(self, manager) -> None:
		"""Bind the VertexPickToolManager used by VertexPick-annotated QVector3D fields."""
		self._vertex_pick_manager = manager
		try:
			manager.tool_active_changed.connect(self._on_vertex_pick_active_changed)
		except Exception:
			pass
		# Refresh inspector when entities are reparented
		try:
			scene.events.entity_reparented.connect(self._on_scene_reparented)
		except Exception:
			pass

	def _on_selection_changed(self, *_args) -> None:
		self._rebuild_for_selection()

	def _rebuild_for_selection(self) -> None:
		if self._selection is None:
			self._clear()
			return
		entities = self._selection.selected_entities()
		if len(entities) == 0:
			self._clear()
		elif len(entities) == 1:
			self._rebuild_for_entity(entities[0])
		else:
			self._rebuild_for_multi(entities)

	def _on_feature_selection_changed(self, _feature_idx) -> None:
		# Rebuild to update feature highlight styling.
		if self._selection is None:
			return
		self._rebuild_for_selection()
		# After rebuild, ensure selected feature is scrolled into view.
		try:
			idx = self._selection.current_feature_idx
			if idx is None:
				return
			w = self._path_feature_widgets.get(int(idx))
			if w is None:
				return
			QTimer.singleShot(0, lambda ww=w: self._scroll.ensureWidgetVisible(ww))
		except Exception:
			pass

	def _on_scene_reparented(self, child_id: str, _new_parent_id) -> None:
		if self._selection is not None and child_id in self._selection.selected_ids():
			self._rebuild_for_selection()

	def _clear(self) -> None:
		self._path_feature_widgets.clear()
		while self._vbox.count():
			item = self._vbox.takeAt(0)
			w = item.widget()
			if w is not None:
				w.deleteLater()

	def _rebuild_for_entity(self, entity: Optional[Entity]) -> None:
		self._clear()
		if entity is None:
			return
		# Entity group (name uses the same property-change command, targeting __entity__)
		gb_entity = QGroupBox("Entity", self._content)
		form_entity = QFormLayout(gb_entity)
		name_edit = QLineEdit(self._content)
		name_edit.setText(entity.name)
		name_edit.editingFinished.connect(lambda e=entity, w=name_edit: self._push_entity_field_change(e, "name", w.text()))
		form_entity.addRow("Name", name_edit)
		self._vbox.addWidget(gb_entity)

		# Auto-generate component UIs (Transform included, but not removable)
		for comp in entity.components:
			type_name = getattr(comp, "type_name", comp.__class__.__name__)
			gb = QGroupBox(type_name, self._content)
			form = QFormLayout(gb)
			self._add_remove_component_row(
				form,
				entity=entity,
				component=comp,
				type_name=type_name,
				emit_scene_change=True,
				removable=type_name not in ("Transform", "TransformComponent"),
			)
			if not self._component_is_collapsed(comp):
				if type_name == "PathGeneration":
					self._path_section.build(entity, comp, form)
				elif type_name == "RobotDescription":
					self._build_robot_description_ui(entity, comp, form)
				else:
					self._build_component_fields(entity, comp, form)
				if self._component_is_locked(comp):
					self._disable_form_rows_after_header(form)
			self._vbox.addWidget(gb)

		# Footer: full-width "Add Component" button
		add_btn = QPushButton("Add Component", self._content)
		add_btn.setToolTip("Add Component")
		add_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		add_btn.setMinimumHeight(28)
		add_btn.clicked.connect(lambda checked=False, e=entity, btn=add_btn: self._open_add_component_menu(e, btn))
		self._vbox.addWidget(add_btn)

		self._vbox.addStretch(1)

	def _rebuild_for_multi(self, entities: List[Entity]) -> None:
		self._clear()
		if not entities:
			return
		primary = self._selection.current if self._selection is not None else None
		header = QLabel(
			f"Selection ({len(entities)}) — primary: {primary.name if primary is not None else '-'}",
			self._content,
		)
		header.setWordWrap(True)
		self._vbox.addWidget(header)

		gb_entity = QGroupBox("Entity", self._content)
		form_entity = QFormLayout(gb_entity)
		name_fv = entity_name_field_value(entities)
		name_edit = QLineEdit(self._content)
		if name_fv.kind == "mixed":
			name_edit.clear()
			name_edit.setPlaceholderText("-")
		else:
			name_edit.setText(str(name_fv.value or ""))
		name_edit.editingFinished.connect(
			lambda ents=entities, w=name_edit: self._push_bulk_entity_field_change(ents, "name", w.text())
		)
		form_entity.addRow("Name", name_edit)
		self._vbox.addWidget(gb_entity)

		for comp_type in common_component_types(entities):
			prototype = find_component(entities[0], comp_type)
			if prototype is None:
				continue
			gb = QGroupBox(comp_type, self._content)
			form = QFormLayout(gb)
			self._add_remove_component_row_multi(
				form,
				entities,
				comp_type,
				prototype,
				removable=comp_type not in ("Transform", "TransformComponent"),
			)
			collapse_states = [
				self._component_is_collapsed(c)
				for e in entities
				for c in [find_component(e, comp_type)]
				if c is not None
			]
			all_collapsed = bool(collapse_states) and all(collapse_states)
			if not all_collapsed:
				self._build_component_fields_multi(entities, comp_type, prototype, form)
				# Disable fields when every selected instance of this type is locked.
				lock_states = [
					self._component_is_locked(c)
					for e in entities
					for c in [find_component(e, comp_type)]
					if c is not None
				]
				if lock_states and all(lock_states):
					self._disable_form_rows_after_header(form)
			self._vbox.addWidget(gb)

		add_btn = QPushButton("Add Component", self._content)
		add_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
		add_btn.setMinimumHeight(28)
		add_btn.clicked.connect(lambda _c=False, ents=entities, btn=add_btn: self._open_add_component_menu_multi(ents, btn))
		self._vbox.addWidget(add_btn)
		self._vbox.addStretch(1)

	@staticmethod
	def _format_component_info_tooltip(description: str) -> str:
		inner = str(description or "").strip()
		if not inner:
			return ""
		return (
			'<html><head/><body>'
			'<table border="0" cellspacing="0" cellpadding="2"><tr>'
			f'<td width="320">{inner}</td>'
			'</tr></table></body></html>'
		)

	@staticmethod
	def _plain_text_from_html(html: str) -> str:
		text = str(html or "")
		text = re.sub(r"(?i)<br\s*/?>", "\n", text)
		text = re.sub(r"(?i)</(p|li|h[1-6]|div|tr)>", "\n", text)
		text = re.sub(r"<[^>]+>", "", text)
		return " ".join(unescape(text).split())

	def _add_component_info_button(self, parent: QWidget, description: str) -> Optional[QToolButton]:
		tip = self._format_component_info_tooltip(description)
		if not tip:
			return None
		info_btn = QToolButton(parent)
		info_btn.setIcon(info_btn.style().standardIcon(QStyle.StandardPixmap.SP_MessageBoxInformation))
		info_btn.setIconSize(QSize(14, 14))
		info_btn.setAutoRaise(True)
		info_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
		info_btn.setCursor(Qt.CursorShape.WhatsThisCursor)
		info_btn.setToolTip(tip)
		info_btn.setToolTipDuration(60000)
		return info_btn

	@staticmethod
	def _component_is_locked(component) -> bool:
		return bool(getattr(component, "locked", False))

	@staticmethod
	def _component_is_collapsed(component) -> bool:
		return bool(getattr(component, "collapsed", False))

	@staticmethod
	def _is_header_toggle_field(field: str) -> bool:
		return str(field) in ("locked", "collapsed")

	def _make_component_collapse_button(
		self, parent: QWidget, *, collapsed: bool, mixed: bool = False
	) -> QToolButton:
		btn = QToolButton(parent)
		btn.setAutoRaise(True)
		btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
		arrow = (
			QStyle.StandardPixmap.SP_TitleBarUnshadeButton
			if collapsed and not mixed
			else QStyle.StandardPixmap.SP_TitleBarShadeButton
		)
		btn.setIcon(btn.style().standardIcon(arrow))
		btn.setIconSize(QSize(14, 14))
		if mixed:
			btn.setToolTip("Collapse state differs across selection — click to expand all")
		elif collapsed:
			btn.setToolTip("Expand component")
		else:
			btn.setToolTip("Collapse component")
		return btn

	def _make_component_lock_button(self, parent: QWidget, *, locked: bool, mixed: bool = False) -> QToolButton:
		btn = QToolButton(parent)
		btn.setCheckable(True)
		btn.setChecked(bool(locked) and not mixed)
		btn.setText("🔒" if (locked and not mixed) else "🔓")
		btn.setAutoRaise(True)
		btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
		if mixed:
			btn.setToolTip("Lock state differs across selection — click to unlock all")
		elif locked:
			btn.setToolTip("Unlock component (allow property edits)")
		else:
			btn.setToolTip("Lock component (block property edits)")
		return btn

	def _set_component_locked(self, entity: Entity, component, locked: bool) -> None:
		"""Toggle ``component.locked`` via undo and rebuild the Inspector."""
		if bool(getattr(component, "locked", False)) == bool(locked):
			return
		self._push_comp_field_change(entity, component, "locked", bool(locked))
		self._rebuild_for_entity(entity)

	def _set_components_locked_multi(self, entities: List[Entity], comp_type: str, locked: bool) -> None:
		targets = []
		for ent in entities:
			comp = find_component(ent, comp_type)
			if comp is None:
				continue
			if bool(getattr(comp, "locked", False)) == bool(locked):
				continue
			targets.append((ent, comp))
		if not targets:
			return
		if self._scene is not None and self._undo_stack is not None and len(targets) > 1:
			self._undo_stack.beginMacro(f"{'Lock' if locked else 'Unlock'} {comp_type} ({len(targets)} objects)")
		try:
			for ent, comp in targets:
				self._push_comp_field_change(ent, comp, "locked", bool(locked))
		finally:
			if self._scene is not None and self._undo_stack is not None and len(targets) > 1:
				self._undo_stack.endMacro()
		self._rebuild_for_selection()

	def _set_component_collapsed(self, entity: Entity, component, collapsed: bool) -> None:
		"""Toggle ``component.collapsed`` via undo and rebuild the Inspector."""
		if bool(getattr(component, "collapsed", False)) == bool(collapsed):
			return
		self._push_comp_field_change(entity, component, "collapsed", bool(collapsed))
		self._rebuild_for_entity(entity)

	def _set_components_collapsed_multi(self, entities: List[Entity], comp_type: str, collapsed: bool) -> None:
		targets = []
		for ent in entities:
			comp = find_component(ent, comp_type)
			if comp is None:
				continue
			if bool(getattr(comp, "collapsed", False)) == bool(collapsed):
				continue
			targets.append((ent, comp))
		if not targets:
			return
		if self._scene is not None and self._undo_stack is not None and len(targets) > 1:
			self._undo_stack.beginMacro(
				f"{'Collapse' if collapsed else 'Expand'} {comp_type} ({len(targets)} objects)"
			)
		try:
			for ent, comp in targets:
				self._push_comp_field_change(ent, comp, "collapsed", bool(collapsed))
		finally:
			if self._scene is not None and self._undo_stack is not None and len(targets) > 1:
				self._undo_stack.endMacro()
		self._rebuild_for_selection()

	@staticmethod
	def _align_form_label_top(form: QFormLayout, row: int) -> None:
		"""Top-align a QFormLayout label so it matches a tall field's LED/header."""
		try:
			item = form.itemAt(int(row), QFormLayout.ItemRole.LabelRole)
			lbl = item.widget() if item is not None else None
			if isinstance(lbl, QLabel):
				lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
		except Exception:
			pass

	def _disable_form_rows_after_header(self, form: QFormLayout) -> None:
		"""Disable all form rows except row 0 (collapse / info / lock / remove toolbar).

		Field labels and RUN-button hosts stay enabled so right-click can still
		copy GET / EDIT / RUN while the component is locked.
		"""
		for i in range(1, form.rowCount()):
			for role in (
				QFormLayout.ItemRole.LabelRole,
				QFormLayout.ItemRole.FieldRole,
				QFormLayout.ItemRole.SpanningRole,
			):
				if role == QFormLayout.ItemRole.LabelRole:
					continue
				item = form.itemAt(i, role)
				if item is None:
					continue
				w = item.widget()
				if w is None:
					continue
				if bool(w.property(TCP_COPY_HOST_PROPERTY)):
					continue
				try:
					w.setEnabled(False)
				except Exception:
					pass

	def _add_remove_component_row(
		self,
		form: QFormLayout,
		*,
		entity: Entity,
		component,
		type_name: str,
		emit_scene_change: bool,
		removable: bool = True,
	) -> None:
		"""
		Header toolbar: collapse, then info on the left; lock and optional remove on the right.
		"""
		row = QWidget(self._content)
		row_layout = QHBoxLayout(row)
		row_layout.setContentsMargins(0, 0, 0, 0)
		row_layout.setSpacing(2)
		collapsed = self._component_is_collapsed(component)
		collapse_btn = self._make_component_collapse_button(row, collapsed=collapsed)
		collapse_btn.clicked.connect(
			lambda _checked=False, e=entity, comp=component, was=collapsed: self._set_component_collapsed(
				e, comp, not was
			)
		)
		row_layout.addWidget(collapse_btn, 0, Qt.AlignmentFlag.AlignLeft)
		desc = str(getattr(component, "description", "") or "").strip()
		info_btn = self._add_component_info_button(row, desc)
		if info_btn is not None:
			row_layout.addWidget(info_btn, 0, Qt.AlignmentFlag.AlignLeft)
		row_layout.addStretch(1)
		locked = self._component_is_locked(component)
		lock_btn = self._make_component_lock_button(row, locked=locked)
		lock_btn.clicked.connect(
			lambda checked=False, e=entity, comp=component, b=lock_btn: self._set_component_locked(
				e, comp, bool(b.isChecked())
			)
		)
		row_layout.addWidget(lock_btn, 0, Qt.AlignmentFlag.AlignRight)
		if removable:
			rm_btn = QToolButton(row)
			rm_btn.setText("✕")
			rm_btn.setAutoRaise(True)
			if locked:
				rm_btn.setEnabled(False)
				rm_btn.setToolTip("Unlock the component before removing it")
			else:
				rm_btn.setToolTip(f"Remove {type_name} Component")
				rm_btn.clicked.connect(
					lambda _checked=False, e=entity, comp=component: self._remove_component(
						e, comp, emit_scene_change
					)
				)
			row_layout.addWidget(rm_btn, 0, Qt.AlignmentFlag.AlignRight)
		try:
			form.insertRow(0, row)
		except Exception:
			# Fallback: add as first row (will appear just under the title)
			form.addRow(row)

	def _remove_component(self, entity: Entity, component, emit_scene_change: bool) -> None:
		if self._component_is_locked(component):
			return
		if self._scene is None or self._undo_stack is None:
			# Fallback: direct removal
			try:
				entity.remove_component(component)
			finally:
				if emit_scene_change and self._scene is not None:
					self._scene.events.entity_changed.emit(entity.id)
					self._rebuild_for_entity(entity)
					return
		
		# Use undo command
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		comp_snapshot = component.to_dict()
		cmd = RemoveComponentCommand(self._scene, entity.id, comp_type, comp_snapshot)
		self._undo_stack.push(cmd)
		self._rebuild_for_entity(entity)

	def _build_component_fields_multi(
		self,
		entities: List[Entity],
		comp_type: str,
		prototype,
		form: QFormLayout,
	) -> None:
		rows = iter_inspector_layout(prototype)
		items, groups = partition_inspector_layout(rows)
		for kind, payload in items:
			if kind == "group":
				self._append_group_gear_row(
					form,
					str(payload),
					groups[str(payload)],
					entities=entities,
					comp_type=comp_type,
					prototype=prototype,
				)
			else:
				self._append_inspector_row_multi(form, payload, entities, comp_type, prototype)

	def _widget_for_field_multi(
		self,
		entities: List[Entity],
		comp_type: str,
		spec: FieldSpec,
		fv: FieldValue,
	) -> QWidget:
		typ = spec.typ
		mixed = fv.kind == "mixed"
		value = fv.value

		cs_meta = next((m for m in spec.metadata if isinstance(m, ConnectionStatus)), None)
		if cs_meta is not None:
			badge = ConnectionStatusBadge(self._content)
			badge.set_status("" if value is None else str(value), cs_meta, mixed=mixed)
			return badge

		if is_literal_type(typ) and not mixed:
			choices = literal_choices(typ)
			combo = QComboBox(self._content)
			for c in choices:
				combo.addItem(str(c), c)
			idx = combo.findData(value)
			if idx != -1:
				combo.setCurrentIndex(idx)
			combo.currentIndexChanged.connect(
				lambda _i, ents=entities, ct=comp_type, s=spec, c=combo: self._push_bulk_comp_field_change(
					ents, ct, s.name, c.currentData()
				)
			)
			return combo
		if is_literal_type(typ) and mixed:
			edit = QLineEdit(self._content)
			edit.setPlaceholderText("-")
			edit.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=edit, choices=literal_choices(typ): self._apply_literal_text_bulk(
					ents, ct, s.name, w.text(), choices
				)
			)
			return edit

		if typ is bool or (not mixed and isinstance(value, bool)):
			cb = QCheckBox(self._content)
			if mixed:
				cb.setTristate(True)
				cb.setCheckState(Qt.CheckState.PartiallyChecked)
			else:
				cb.setTristate(False)
				cb.setChecked(bool(value))
			cb.clicked.connect(
				lambda _checked=False, ents=entities, ct=comp_type, s=spec, c=cb, m=mixed: self._on_multi_bool_checkbox_clicked(
					ents, ct, s, c, mixed=m
				)
			)
			return cb

		if typ is int or (not mixed and isinstance(value, int)):
			if mixed:
				edit = QLineEdit(self._content)
				edit.setPlaceholderText("-")
				edit.editingFinished.connect(
					lambda ents=entities, ct=comp_type, s=spec, w=edit: self._apply_int_text_bulk(ents, ct, s.name, w.text())
				)
				return edit
			sb = QSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(int(rng.min), int(rng.max))
				sb.setSingleStep(int(rng.step))
			else:
				sb.setRange(-2_000_000_000, 2_000_000_000)
			sb.setValue(int(value))
			sb.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=sb: self._push_bulk_comp_field_change(ents, ct, s.name, int(w.value()))
			)
			return sb

		if typ is float or (not mixed and isinstance(value, float)):
			if mixed:
				edit = QLineEdit(self._content)
				edit.setPlaceholderText("-")
				edit.editingFinished.connect(
					lambda ents=entities, ct=comp_type, s=spec, w=edit: self._apply_float_text_bulk(ents, ct, s.name, w.text())
				)
				return edit
			sb = QDoubleSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(float(rng.min), float(rng.max))
				sb.setSingleStep(float(rng.step))
				if rng.decimals is not None:
					sb.setDecimals(int(rng.decimals))
			else:
				sb.setRange(-1e12, 1e12)
				sb.setSingleStep(0.1)
			sb.setValue(float(value))
			sb.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=sb: self._push_bulk_comp_field_change(ents, ct, s.name, float(w.value()))
			)
			return sb

		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if typ is _QVector3D or (not mixed and isinstance(value, _QVector3D)):
				editor = Vector3Editor(self._content, on_changed=lambda v, ents=entities, ct=comp_type, sn=spec.name: self._push_bulk_comp_field_change(ents, ct, sn, v))
				if mixed:
					editor.set_mixed(True)
				else:
					editor.set_value(value)
				return editor
		except Exception:
			pass

		try:
			from PyQt6.QtGui import QColor

			if typ is QColor or (not mixed and isinstance(value, QColor)) or any(isinstance(m, ColorField) for m in spec.metadata):
				btn = QPushButton(self._content)
				btn.setFixedHeight(22)
				if mixed:
					self._apply_color_button_style_mixed(btn)
				else:
					self._apply_color_button_style(btn, value)

				def _pick_color(_c=False, ents=entities, ct=comp_type, s=spec, b=btn):
					from PyQt6.QtGui import QColor as _QColor

					start = value if isinstance(value, _QColor) else _QColor(128, 128, 128)
					col = self._pick_qcolor(start, s.metadata)
					if col is not None and col.isValid():
						self._push_bulk_comp_field_change(ents, ct, s.name, col)
						self._apply_color_button_style(b, col)

				btn.clicked.connect(_pick_color)
				return btn
		except Exception:
			pass

		if any(isinstance(m, FilePath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			if mixed:
				edit.setPlaceholderText("-")
			else:
				edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FilePath)), FilePath())
			browse = QPushButton("Browse", row)
			browse.clicked.connect(
				lambda _c=False, ents=entities, ct=comp_type, s=spec, m=meta, w=edit: self._browse_path_bulk(ents, ct, s.name, m, w)
			)
			edit.editingFinished.connect(
				lambda ents=entities, ct=comp_type, s=spec, w=edit: self._push_bulk_comp_field_change(ents, ct, s.name, w.text())
			)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# Component refs, VertexPick: disabled in multi-select
		if any(isinstance(m, VertexPick) and m.enabled for m in spec.metadata):
			lbl = QLabel("-", self._content)
			lbl.setToolTip("Vertex pick requires a single selection")
			return lbl

		edit = QLineEdit(self._content)
		if mixed:
			edit.setPlaceholderText("-")
		else:
			edit.setText("" if value is None else str(value))
		edit.editingFinished.connect(
			lambda ents=entities, ct=comp_type, s=spec, w=edit: self._push_bulk_comp_field_change(ents, ct, s.name, w.text())
		)
		return edit

	def _apply_literal_text_bulk(self, entities, comp_type, field, text: str, choices) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		for c in choices:
			if str(c) == text:
				self._push_bulk_comp_field_change(entities, comp_type, field, c)
				return

	def _apply_int_text_bulk(self, entities, comp_type, field, text: str) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		try:
			self._push_bulk_comp_field_change(entities, comp_type, field, int(text))
		except ValueError:
			pass

	def _apply_float_text_bulk(self, entities, comp_type, field, text: str) -> None:
		text = text.strip()
		if not text or text == "-":
			return
		try:
			self._push_bulk_comp_field_change(entities, comp_type, field, float(text))
		except ValueError:
			pass

	def _pick_file_path(self, meta: FilePath, current: str) -> str:
		"""Open the browse dialog for a ``FilePath`` field, starting at ``current``."""
		start = str(current or "")
		if meta.save:
			file, _ = QFileDialog.getSaveFileName(self, meta.dialog_title, start, meta.filter)
		else:
			file, _ = QFileDialog.getOpenFileName(self, meta.dialog_title, start, meta.filter)
		return file

	def _browse_path_bulk(self, entities, comp_type, field, meta: FilePath, edit: QLineEdit) -> None:
		file = self._pick_file_path(meta, edit.text())
		if file:
			edit.setText(file)
			self._push_bulk_comp_field_change(entities, comp_type, field, file)

	def _add_remove_component_row_multi(
		self,
		form: QFormLayout,
		entities: List[Entity],
		comp_type: str,
		prototype,
		*,
		removable: bool = True,
	) -> None:
		row = QWidget(self._content)
		row_layout = QHBoxLayout(row)
		row_layout.setContentsMargins(0, 0, 0, 0)
		row_layout.setSpacing(2)
		collapse_states = []
		lock_states = []
		for ent in entities:
			comp = find_component(ent, comp_type)
			if comp is not None:
				collapse_states.append(self._component_is_collapsed(comp))
				lock_states.append(self._component_is_locked(comp))
		all_collapsed = bool(collapse_states) and all(collapse_states)
		collapse_mixed = bool(collapse_states) and (any(collapse_states) and not all_collapsed)
		collapse_btn = self._make_component_collapse_button(
			row, collapsed=all_collapsed, mixed=collapse_mixed
		)

		def _on_collapse_clicked(_checked=False, ents=entities, ct=comp_type, states=collapse_states):
			# Mixed or any collapsed → expand all; else collapse all.
			want_collapsed = not (any(states) if states else False)
			self._set_components_collapsed_multi(ents, ct, want_collapsed)

		collapse_btn.clicked.connect(_on_collapse_clicked)
		row_layout.addWidget(collapse_btn, 0, Qt.AlignmentFlag.AlignLeft)
		desc = str(getattr(prototype, "description", "") or "").strip()
		info_btn = self._add_component_info_button(row, desc)
		if info_btn is not None:
			row_layout.addWidget(info_btn, 0, Qt.AlignmentFlag.AlignLeft)
		row_layout.addStretch(1)
		all_locked = bool(lock_states) and all(lock_states)
		mixed = bool(lock_states) and (any(lock_states) and not all_locked)
		lock_btn = self._make_component_lock_button(row, locked=all_locked, mixed=mixed)

		def _on_lock_clicked(_checked=False, ents=entities, ct=comp_type, states=lock_states):
			# Mixed or any locked → unlock all; else lock all.
			want_locked = not (any(states) if states else False)
			self._set_components_locked_multi(ents, ct, want_locked)

		lock_btn.clicked.connect(_on_lock_clicked)
		row_layout.addWidget(lock_btn, 0, Qt.AlignmentFlag.AlignRight)
		if removable:
			rm_btn = QToolButton(row)
			rm_btn.setText("✕")
			rm_btn.setAutoRaise(True)
			any_locked = bool(lock_states) and any(lock_states)
			if any_locked:
				rm_btn.setEnabled(False)
				rm_btn.setToolTip("Unlock all selected components before removing")
			else:
				rm_btn.setToolTip(f"Remove {comp_type} from all selected entities")
				rm_btn.clicked.connect(
					lambda _c=False, ents=entities, ct=comp_type: self._remove_component_multi(ents, ct)
				)
			row_layout.addWidget(rm_btn, 0, Qt.AlignmentFlag.AlignRight)
		form.addRow(row)

	def _remove_component_multi(self, entities: List[Entity], comp_type: str) -> None:
		if self._scene is None or self._undo_stack is None:
			return
		targets = [(e, find_component(e, comp_type)) for e in entities]
		targets = [(e, c) for e, c in targets if c is not None]
		if not targets:
			return
		if any(self._component_is_locked(c) for _e, c in targets):
			return
		if len(targets) > 1:
			self._undo_stack.beginMacro(f"Remove {comp_type} ({len(targets)} objects)")
		try:
			for ent, comp in targets:
				snapshot = comp.to_dict()
				self._undo_stack.push(RemoveComponentCommand(self._scene, ent.id, comp_type, snapshot))
		finally:
			if len(targets) > 1:
				self._undo_stack.endMacro()
		self._rebuild_for_selection()

	def _invoke_inspector_button_multi(self, entities: List[Entity], comp_type: str, method, label: str) -> None:
		for ent in entities:
			comp = find_component(ent, comp_type)
			if comp is None:
				continue
			self._log_inspector_click(ent, comp, label)
			if self._component_is_locked(comp):
				self._log_inspector_reply(ent, comp, label, False, "component is locked")
				continue
			try:
				bound = getattr(comp, method.__name__)
			except Exception:
				continue
			self._run_logged_inspector_button(ent, bound, label, comp)
		if self._scene is not None:
			for ent in entities:
				self._scene.events.entity_changed.emit(ent.id)
		self._rebuild_for_selection()

	def _open_add_component_menu_multi(self, entities: List[Entity], anchor_widget: QWidget) -> None:
		menu = QMenu(anchor_widget)
		menu.setToolTipsVisible(True)

		def _on_add(comp_cls, tn: str) -> None:
			to_add = [e for e in entities if e.get_component(comp_cls) is None]
			if not to_add:
				QMessageBox.warning(self, "Add Component", f"All selected entities already have {tn}.")
				return
			if self._undo_stack is not None and self._scene is not None:
				if len(to_add) > 1:
					self._undo_stack.beginMacro(f"Add {tn} ({len(to_add)} objects)")
				try:
					for e in to_add:
						instance = comp_cls()  # type: ignore[call-arg]
						self._undo_stack.push(
							AddComponentCommand(self._scene, e.id, tn, instance.to_dict())
						)
				finally:
					if len(to_add) > 1:
						self._undo_stack.endMacro()
			self._rebuild_for_selection()

		self._populate_add_component_menu(menu, _on_add)
		menu.exec(anchor_widget.mapToGlobal(anchor_widget.rect().bottomRight()))

	def _push_bulk_entity_field_change(self, entities: List[Entity], field: str, new_value) -> None:
		if self._scene is None or self._undo_stack is None:
			for e in entities:
				setattr(e, field, new_value)
			return
		changes = []
		for e in entities:
			old = clone_value(getattr(e, field))
			if old != new_value:
				changes.append((e.id, old))
		if not changes:
			return
		label = f"Change Entity.{field} ({len(changes)} objects)"
		self._undo_stack.beginMacro(label)
		try:
			for entity_id, old in changes:
				self._undo_stack.push(
					PropertyChangeCommand(
						self._scene, entity_id, "__entity__", field, old, clone_value(new_value), text=f"Entity.{field}"
					)
				)
		finally:
			self._undo_stack.endMacro()

	def _on_multi_bool_checkbox_clicked(
		self,
		entities: List[Entity],
		comp_type: str,
		spec: FieldSpec,
		checkbox: QCheckBox,
		*,
		mixed: bool,
	) -> None:
		"""
		Bulk-edit bool fields from the inspector.

		Tristate is only used for mixed multi-selection. A click on the dash
		sets all targets to True. Uniform values use a normal two-state checkbox
		so one click toggles without passing through PartiallyChecked.
		"""
		state = checkbox.checkState()
		if mixed and state == Qt.CheckState.PartiallyChecked:
			checkbox.blockSignals(True)
			checkbox.setTristate(False)
			checkbox.setChecked(True)
			checkbox.blockSignals(False)
			new_value = True
		else:
			new_value = checkbox.isChecked()
		self._push_bulk_comp_field_change(entities, comp_type, spec.name, new_value)

	def _push_bulk_comp_field_change(
		self,
		entities: List[Entity],
		comp_type: str,
		field: str,
		new_value,
	) -> None:
		if self._scene is None or self._undo_stack is None:
			for e in entities:
				comp = find_component(e, comp_type)
				if comp is None:
					continue
				if not self._is_header_toggle_field(field) and self._component_is_locked(comp):
					continue
				setattr(comp, field, new_value)
			return
		changes = []
		for e in entities:
			comp = find_component(e, comp_type)
			if comp is None:
				continue
			if not self._is_header_toggle_field(field) and self._component_is_locked(comp):
				continue
			old = clone_value(getattr(comp, field, None))
			if old != new_value:
				changes.append((e.id, old))
		if not changes:
			return
		label = f"Change {comp_type}.{field} ({len(changes)} objects)"
		self._undo_stack.beginMacro(label)
		try:
			for entity_id, old in changes:
				self._undo_stack.push(
					PropertyChangeCommand(
						self._scene,
						entity_id,
						comp_type,
						field,
						old,
						clone_value(new_value),
						text=f"{comp_type}.{field}",
					)
				)
		finally:
			self._undo_stack.endMacro()

	def _push_entity_field_change(self, entity: Entity, field: str, new_value) -> None:
		if self._scene is None or self._undo_stack is None:
			# fallback
			setattr(entity, field, new_value)
			return
		old = clone_value(getattr(entity, field))
		if old == new_value:
			return
		cmd = PropertyChangeCommand(self._scene, entity.id, "__entity__", field, old, clone_value(new_value), text=f"Entity.{field}")
		self._undo_stack.push(cmd)

	def _build_component_fields(self, entity: Entity, component, form: QFormLayout) -> None:
		"""
		Build editor widgets for a component using typing.Annotated metadata.
		Fields and @inspector_button rows share one ``Order`` / ``order`` sort key.
		"""
		rows = iter_inspector_layout(component)
		items, groups = partition_inspector_layout(rows)
		for kind, payload in items:
			if kind == "group":
				self._append_group_gear_row(
					form,
					str(payload),
					groups[str(payload)],
					entity=entity,
					component=component,
				)
			else:
				self._append_inspector_row_single(form, payload, entity, component)

	def _append_section_header(self, form: QFormLayout, text: str) -> None:
		label = str(text or "").strip()
		if not label:
			return
		hdr = QLabel(label, self._content)
		font = hdr.font()
		font.setBold(True)
		hdr.setFont(font)
		form.addRow(hdr)

	def _append_header_if_present(self, form: QFormLayout, metadata: tuple) -> None:
		for m in metadata:
			if isinstance(m, Header):
				self._append_section_header(form, m.text)
				return

	def _append_inspector_rows_single(
		self,
		form: QFormLayout,
		rows: List[InspectorLayoutRow],
		entity: Entity,
		component,
	) -> None:
		for row in rows:
			self._append_inspector_row_single(form, row, entity, component)

	def _append_inspector_row_single(
		self,
		form: QFormLayout,
		row: InspectorLayoutRow,
		entity: Entity,
		component,
	) -> None:
		if row.kind == "field" and row.field_spec is not None:
			spec = row.field_spec
			self._append_header_if_present(form, spec.metadata)
			tooltip = next((m.text for m in spec.metadata if isinstance(m, Tooltip)), None)
			readonly = any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata)
			is_connection_status = any(isinstance(m, ConnectionStatus) for m in spec.metadata)
			if (
				isinstance(component, TransformComponent)
				and entity.get_component(UrdfLinkComponent) is not None
			):
				readonly = True
			locked = self._component_is_locked(component)
			w = self._widget_for_field(entity, component, spec)
			if tooltip and hasattr(w, "setToolTip"):
				w.setToolTip(tooltip)
			try:
				# ConnectionStatus is display-only; keep LED colors vivid unless locked.
				if is_connection_status:
					w.setEnabled(not locked)
				else:
					w.setEnabled(not readonly and not locked)
			except Exception:
				pass
			name_label = make_field_label(
				spec.name,
				self._content,
				panel=self,
				entity=entity,
				component=component,
				spec=spec,
				writable=field_is_tcp_writable(spec) and not readonly,
				help_tooltip=tooltip,
			)
			form.addRow(name_label, w)
			if is_connection_status:
				# Keep the form label at the top with the LED (not mid-field).
				self._align_form_label_top(form, form.rowCount() - 1)
		elif row.kind == "button" and row.button_spec is not None and row.button_method is not None:
			spec = row.button_spec
			method = row.button_method
			if spec.header:
				self._append_section_header(form, spec.header)
			btn = QPushButton(spec.label, self._content)
			btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
			btn.setEnabled(self._inspector_button_enabled(component, method))
			btn.clicked.connect(
				lambda _checked=False, e=entity, m=method, lbl=spec.label: self._invoke_inspector_button(e, m, lbl)
			)
			host = wrap_run_button(
				btn,
				self._content,
				entity=entity,
				component=component,
				button_label=spec.label,
				help_tooltip=spec.tooltip,
			)
			form.addRow(host)

	def _append_inspector_rows_multi(
		self,
		form: QFormLayout,
		rows: List[InspectorLayoutRow],
		entities: List[Entity],
		comp_type: str,
		prototype,
	) -> None:
		for row in rows:
			self._append_inspector_row_multi(form, row, entities, comp_type, prototype)

	def _append_inspector_row_multi(
		self,
		form: QFormLayout,
		row: InspectorLayoutRow,
		entities: List[Entity],
		comp_type: str,
		prototype,
	) -> None:
		if row.kind == "field" and row.field_spec is not None:
			spec = row.field_spec
			self._append_header_if_present(form, spec.metadata)
			fv = field_value_for(entities, comp_type, spec.name)
			readonly = any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata)
			is_connection_status = any(isinstance(m, ConnectionStatus) for m in spec.metadata)
			lock_states = [
				self._component_is_locked(c)
				for e in entities
				for c in [find_component(e, comp_type)]
				if c is not None
			]
			all_locked = bool(lock_states) and all(lock_states)
			w = self._widget_for_field_multi(entities, comp_type, spec, fv)
			tooltip = next((m.text for m in spec.metadata if isinstance(m, Tooltip)), None)
			if tooltip and hasattr(w, "setToolTip"):
				w.setToolTip(tooltip)
			try:
				if is_connection_status:
					w.setEnabled(not all_locked)
				else:
					w.setEnabled(not readonly and not all_locked)
			except Exception:
				pass
			form.addRow(spec.name, w)
			if is_connection_status:
				self._align_form_label_top(form, form.rowCount() - 1)
		elif row.kind == "button" and row.button_spec is not None and row.button_method is not None:
			spec = row.button_spec
			if spec.header:
				self._append_section_header(form, spec.header)
			btn = QPushButton(spec.label, self._content)
			if spec.tooltip:
				btn.setToolTip(spec.tooltip)
			lock_states = [
				self._component_is_locked(c)
				for e in entities
				for c in [find_component(e, comp_type)]
				if c is not None
			]
			can_run = True
			if getattr(row.button_method, "__name__", "") == "decimate":
				can_run = any(
					bool(getattr(c, "can_decimate", lambda: True)())
					for e in entities
					for c in [find_component(e, comp_type)]
					if c is not None
				)
			btn.setEnabled(can_run and not (bool(lock_states) and all(lock_states)))
			btn.clicked.connect(
				lambda _c=False, ents=entities, m=row.button_method, lbl=spec.label: self._invoke_inspector_button_multi(
					ents, comp_type, m, lbl
				)
			)
			form.addRow(btn)

	def _apply_bordered_tool_button_style(
		self, btn: QToolButton, *, size_px: int | None = None
	) -> None:
		from MotionStudio.ui.theme import mark_bordered_tool_button

		btn.setAutoRaise(False)
		# Theme-aware styling via app stylesheet (see MotionStudio.ui.theme).
		mark_bordered_tool_button(btn)
		if size_px is not None:
			btn.setFixedSize(size_px, size_px)
			btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

	def _make_bordered_icon_tool_button(
		self,
		parent: QWidget,
		icon: QStyle.StandardPixmap,
		tooltip: str,
		*,
		size_px: int | None = _ICON_TOOL_BUTTON_PX,
	) -> QToolButton:
		btn = QToolButton(parent)
		btn.setIcon(btn.style().standardIcon(icon))
		btn.setToolTip(tooltip)
		btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
		self._apply_bordered_tool_button_style(btn, size_px=size_px)
		return btn

	def _append_group_gear_row(
		self,
		form: QFormLayout,
		group_label: str,
		rows: List[InspectorLayoutRow],
		*,
		entity: Optional[Entity] = None,
		component=None,
		entities: Optional[List[Entity]] = None,
		comp_type: Optional[str] = None,
		prototype=None,
	) -> None:
		row_w = QWidget(self._content)
		h = QHBoxLayout(row_w)
		h.setContentsMargins(0, 0, 0, 0)
		h.addWidget(QLabel(group_label, row_w))
		gear = self._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_FileDialogDetailedView,
			f"Open {group_label}",
		)
		h.addWidget(gear)
		h.addStretch(1)
		locked = False
		if component is not None:
			locked = self._component_is_locked(component)
		elif entities and comp_type:
			states = [
				self._component_is_locked(c)
				for e in entities
				for c in [find_component(e, comp_type)]
				if c is not None
			]
			locked = bool(states) and all(states)
		gear.setEnabled(not locked)
		row_w.setEnabled(not locked)
		gear.clicked.connect(
			lambda _c=False, g=group_label, r=rows, ent=entity, comp=component, ents=entities, ct=comp_type, proto=prototype: open_inspector_group_dock(
				self,
				g,
				r,
				entity=ent,
				component=comp,
				entities=ents,
				comp_type=ct,
				prototype=proto,
			)
		)
		form.addRow(row_w)

	def _inspector_button_enabled(self, component, method) -> bool:
		if self._component_is_locked(component):
			return False
		if getattr(method, "__name__", "") == "decimate":
			can = getattr(component, "can_decimate", None)
			if callable(can) and not can():
				return False
		return True

	def _invoke_inspector_button(self, entity: Entity, method, label: str) -> None:
		"""Run a component @inspector_button method, refresh the inspector."""
		comp = getattr(method, "__self__", None)
		self._log_inspector_click(entity, comp, label)
		if comp is not None and self._component_is_locked(comp):
			self._log_inspector_reply(entity, comp, label, False, "component is locked")
			return
		self._run_logged_inspector_button(entity, method, label, comp)
		# Notify the scene so other panels / VTK actors refresh, then rebuild
		# this inspector so any field mutations done by the method appear.
		try:
			if self._scene is not None:
				self._scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass
		self._rebuild_for_entity(entity)

	def _inspector_button_subject(self, entity: Entity, component, label: str) -> str:
		type_name = ""
		if component is not None:
			type_name = str(getattr(component, "type_name", "") or "")
			if not type_name:
				type_name = component.__class__.__name__
		if not type_name:
			type_name = "Component"
		return f"{entity.name}.{type_name} {label}"

	def _log_inspector_click(self, entity: Entity, component, label: str) -> None:
		logger = self._command_logger
		if logger is None:
			return
		try:
			logger.log_event("inspector", f"{self._inspector_button_subject(entity, component, label)} clicked")
		except Exception:
			pass

	def _log_inspector_reply(self, entity: Entity, component, label: str, ok: bool, output) -> None:
		logger = self._command_logger
		if logger is None:
			return
		try:
			wire = format_response(ok, output).rstrip("\r\n")
			logger.log_event(
				"inspector",
				f"{self._inspector_button_subject(entity, component, label)} < {wire}",
			)
		except Exception:
			pass

	def _run_logged_inspector_button(self, entity: Entity, method, label: str, component) -> None:
		def _on_finished(ok: bool, output: str, e=entity, c=component, lbl=label) -> None:
			self._log_inspector_reply(e, c, lbl, ok, output)

		if self._scene is None:
			try:
				result = method()
			except Exception as ex:
				import traceback
				print(f"Inspector button '{label}' raised: {ex}", flush=True)
				traceback.print_exc()
				self._log_inspector_reply(entity, component, label, False, f"{label} raised: {ex}")
				return
			self._log_inspector_reply(entity, component, label, True, result)
			return
		run_inspector_button(
			self._scene,
			entity,
			method,
			on_finished=_on_finished,
			print_traceback=True,
			notify=False,
		)

	def _widget_for_field(self, entity: Entity, component, spec: FieldSpec) -> QWidget:
		typ = spec.typ
		value = spec.getter()

		cs_meta = next((m for m in spec.metadata if isinstance(m, ConnectionStatus)), None)
		if cs_meta is not None:
			badge = ConnectionStatusBadge(self._content)
			badge.set_status("" if value is None else str(value), cs_meta)
			return badge

		# Literal/Enum-like via typing.Literal
		if is_literal_type(typ):
			choices = literal_choices(typ)
			combo = QComboBox(self._content)
			for c in choices:
				combo.addItem(str(c), c)
			# set current
			idx = combo.findData(value)
			if idx != -1:
				combo.setCurrentIndex(idx)
			combo.currentIndexChanged.connect(
				lambda _i, e=entity, comp=component, s=spec, c=combo: self._push_comp_field_change(
					e, comp, s.name, c.currentData()
				)
			)
			return combo

		# Basic primitives
		if typ is bool or isinstance(value, bool):
			from PyQt6.QtWidgets import QCheckBox

			cb = QCheckBox(self._content)
			cb.setChecked(bool(value))
			cb.stateChanged.connect(lambda _st, e=entity, comp=component, s=spec, c=cb: self._push_comp_field_change(e, comp, s.name, bool(c.isChecked())))
			return cb

		if typ is int or isinstance(value, int):
			from PyQt6.QtWidgets import QSpinBox

			sb = QSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(int(rng.min), int(rng.max))
				sb.setSingleStep(int(rng.step))
			else:
				sb.setRange(-2_000_000_000, 2_000_000_000)
			sb.setValue(int(value))
			sb.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=sb: self._push_comp_field_change(e, comp, s.name, int(w.value())))
			return sb

		if typ is float or isinstance(value, float):
			

			sb = QDoubleSpinBox(self._content)
			rng = next((m for m in spec.metadata if isinstance(m, Range)), None)
			if rng is not None:
				sb.setRange(float(rng.min), float(rng.max))
				sb.setSingleStep(float(rng.step))
				if rng.decimals is not None:
					sb.setDecimals(int(rng.decimals))
			else:
				sb.setRange(-1e12, 1e12)
				sb.setSingleStep(0.1)
			sb.setValue(float(value))
			sb.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=sb: self._push_comp_field_change(e, comp, s.name, float(w.value())))
			return sb

		# QVector3D via existing Vector3Editor
		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if typ is _QVector3D or isinstance(value, _QVector3D):
				want_pick = any(isinstance(m, VertexPick) and m.enabled for m in spec.metadata)
				on_pick_cb = None
				if want_pick and self._vertex_pick_manager is not None:
					on_pick_cb = lambda e=entity, comp=component, s=spec: self._start_vertex_pick(e, comp, s)
				editor = Vector3Editor(
					self._content,
					initial=value,
					on_changed=lambda v, e=entity, comp=component, s=spec: self._push_comp_field_change(e, comp, s.name, v),
					on_pick=on_pick_cb,
				)
				try:
					editor.setProperty("ms_field_tag", f"{id(component)}::{spec.name}")
				except Exception:
					pass
				return editor
		except Exception:
			pass

		# QColor special case
		try:
			from PyQt6.QtGui import QColor

			if typ is QColor or isinstance(value, QColor) or any(isinstance(m, ColorField) for m in spec.metadata):
				btn = QPushButton(self._content)
				btn.setFixedHeight(22)
				self._apply_color_button_style(btn, value)
				def _pick_color(_checked=False, e=entity, comp=component, s=spec, b=btn):
					col = self._pick_qcolor(value, s.metadata)
					if col is not None and col.isValid():
						self._push_comp_field_change(e, comp, s.name, col)
						self._apply_color_button_style(b, col)
				btn.clicked.connect(_pick_color)
				return btn
		except Exception:
			pass

		# Component type reference (Optional[ComponentType])
		try:
			from typing import get_origin, get_args
			from MotionStudio.core.ecs.component import Component as ComponentBase
			from MotionStudio.ui.widgets.component_reference_widget import ComponentReferenceWidget
			
			# Check if type is Optional[ComponentType] or Union[ComponentType, None]
			origin = get_origin(typ)
			if origin is not None:
				args = get_args(typ)
				# Handle Optional (which is Union[T, None])
				import typing
				if origin is typing.Union:
					# Extract inner type (first non-None type)
					inner_type = None
					for arg in args:
						if arg is not type(None):
							inner_type = arg
							break
					
					if inner_type is not None:
						# Check if inner type is a Component subclass
						try:
							if issubclass(inner_type, ComponentBase):
								# This is a Component reference field
								# Value can be:
								# - Component instance (after resolution during load)
								# - entity_id string (during load, before resolution, or if resolution failed)
								# - None
								if isinstance(value, ComponentBase):
									# Already resolved to Component - extract entity_id
									entity_id = value.entity.id if value.entity is not None else None
								elif isinstance(value, str):
									# Still entity_id string (not yet resolved or resolution failed)
									entity_id = value
								else:
									# None
									entity_id = None
								
								if self._scene is None:
									# Fallback to string if no scene
									edit = QLineEdit(self._content)
									edit.setText("" if entity_id is None else str(entity_id))
									edit.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text() if w.text() else None))
									return edit
								
								# Create ComponentReferenceWidget
								# The callback needs to convert entity_id -> Component before setting the field
								def on_entity_selected_callback(selected_entity_id, e=entity, comp=component, s=spec, comp_type=inner_type):
									if selected_entity_id is None:
										# Clear reference
										self._push_comp_field_change(e, comp, s.name, None)
									else:
										# Convert entity_id -> Component
										target_entity = self._scene.find_by_id(selected_entity_id) if self._scene else None
										if target_entity is not None:
											target_component = target_entity.get_component(comp_type)
											if target_component is not None:
												self._push_comp_field_change(e, comp, s.name, target_component)
											else:
												# Entity doesn't have the component - clear
												self._push_comp_field_change(e, comp, s.name, None)
										else:
											# Entity doesn't exist - clear
											self._push_comp_field_change(e, comp, s.name, None)
								
								return ComponentReferenceWidget(
									component_type=inner_type,
									scene=self._scene,
									current_entity_id=entity_id,
									on_entity_selected=on_entity_selected_callback,
									selection=self._selection,
									parent=self._content
								)
						except TypeError:
							# Not a class type, skip
							pass
		except Exception:
			# If anything fails, fall through to default handling
			pass

		# FolderPath hint: lineedit + folder browse
		if any(isinstance(m, FolderPath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FolderPath)), FolderPath())
			browse = QPushButton("Browse", row)

			def _browse_folder(_checked=False, e=entity, comp=component, s=spec):
				folder = QFileDialog.getExistingDirectory(self, meta.dialog_title, edit.text() or "")
				if folder:
					edit.setText(folder)
					self._push_comp_field_change(e, comp, s.name, folder)

			browse.clicked.connect(_browse_folder)
			edit.editingFinished.connect(
				lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text())
			)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# FilePath hint: lineedit + browse
		if any(isinstance(m, FilePath) for m in spec.metadata):
			row = QWidget(self._content)
			hl = QHBoxLayout(row)
			hl.setContentsMargins(0, 0, 0, 0)
			edit = QLineEdit(row)
			edit.setText(str(value or ""))
			meta = next((m for m in spec.metadata if isinstance(m, FilePath)), FilePath())
			browse = QPushButton("Browse", row)

			def _is_ingest_path() -> bool:
				is_mesh_path = isinstance(component, MeshComponent) and spec.name == "custom_path"
				is_collider_path = isinstance(component, ColliderComponent) and spec.name == "collider_mesh_path"
				is_cloud_path = isinstance(component, PointCloudComponent) and spec.name == "file_path"
				return is_mesh_path or is_collider_path or is_cloud_path

			def _apply_ingested_path(e, comp, s, w, stored_path: str) -> None:
				try:
					w.setText(stored_path)
				except RuntimeError:
					pass
				old_path = str(getattr(comp, "custom_path", "") or "")
				self._push_comp_field_change(e, comp, s.name, stored_path)
				if isinstance(comp, MeshComponent) and s.name == "custom_path":
					if stored_path != old_path:
						self._push_comp_field_change(e, comp, "use_decimated_mesh", False)
						self._push_comp_field_change(e, comp, "decimated_path", "")
					if self._scene is not None:
						try:
							use_source = has_source_material_sidecar(self._scene.project_root, stored_path)
							self._push_comp_field_change(e, comp, "source_material", bool(use_source))
						except Exception:
							pass

			def _normalize_mesh_path_if_needed(raw: str) -> str:
				if not _is_ingest_path():
					return raw
				if self._scene is None:
					return raw
				if not raw.strip():
					return raw
				if self._scene.project_root is None and not is_step_mesh(raw):
					return raw
				return ingest_mesh_source(self._scene.project_root, raw)

			def _commit_ingested_path(e, comp, s, w, raw: str, *, warn_on_error: bool) -> None:
				if _is_ingest_path() and raw.strip() and is_step_mesh(raw) and self._loading is not None:
					project_root = self._scene.project_root if self._scene is not None else None

					def _background():
						return ingest_mesh_source(project_root, raw)

					def _apply(stored_path: str) -> None:
						_apply_ingested_path(e, comp, s, w, stored_path)

					def _on_error(exc: Exception) -> None:
						if warn_on_error:
							QMessageBox.warning(self, "Mesh", str(exc))

					if not self._loading.run(
						"Converting STEP to STL...",
						_background,
						_apply,
						on_error=_on_error,
					):
						QMessageBox.warning(
							self,
							"Mesh",
							"Another load operation is already in progress.",
						)
					return
				try:
					file = _normalize_mesh_path_if_needed(raw)
				except (FileNotFoundError, OSError) as ex:
					if warn_on_error:
						QMessageBox.warning(self, "Mesh", str(ex))
					return
				_apply_ingested_path(e, comp, s, w, file)

			def _browse(_checked=False, e=entity, comp=component, s=spec):
				file = self._pick_file_path(meta, edit.text())
				if file:
					_commit_ingested_path(e, comp, s, edit, file, warn_on_error=True)
			browse.clicked.connect(_browse)

			def _on_path_edit_finished(e=entity, comp=component, s=spec, w=edit):
				text = w.text()
				if _is_ingest_path() and text.strip() and is_step_mesh(text):
					_commit_ingested_path(e, comp, s, w, text, warn_on_error=True)
					return
				if _is_ingest_path() and text.strip():
					try:
						normalized = _normalize_mesh_path_if_needed(text)
						if normalized != text:
							w.setText(normalized)
							text = normalized
					except (FileNotFoundError, OSError):
						pass
				old_path = str(getattr(comp, "custom_path", "") or "")
				self._push_comp_field_change(e, comp, s.name, text)
				if isinstance(comp, MeshComponent) and s.name == "custom_path":
					if text != old_path:
						self._push_comp_field_change(e, comp, "use_decimated_mesh", False)
						self._push_comp_field_change(e, comp, "decimated_path", "")
					if self._scene is not None:
						try:
							use_source = has_source_material_sidecar(self._scene.project_root, text)
							self._push_comp_field_change(e, comp, "source_material", bool(use_source))
						except Exception:
							pass

			edit.editingFinished.connect(_on_path_edit_finished)
			hl.addWidget(edit, 1)
			hl.addWidget(browse, 0)
			return row

		# Default: string
		edit = QLineEdit(self._content)
		edit.setText("" if value is None else str(value))
		edit.editingFinished.connect(lambda e=entity, comp=component, s=spec, w=edit: self._push_comp_field_change(e, comp, s.name, w.text()))
		return edit

	def _center_dialog_on_window(self, dialog: QWidget) -> None:
		try:
			window = self.window()
			if window is None:
				return
			center = window.frameGeometry().center()
			dialog.move(center.x() - dialog.width() // 2, center.y() - dialog.height() // 2)
		except Exception:
			pass

	def _build_robot_description_ui(
		self, entity: Entity, comp: RobotDescriptionComponent, form: QFormLayout
	) -> None:
		import math

		self._build_component_fields(entity, comp, form)
		if not comp.actuated_joint_names:
			return
		form.addRow(QLabel("Joint positions (rad)", self._content))
		for jname in comp.actuated_joint_names:
			jrec = comp.get_joint_record(jname)
			lower = -math.pi
			upper = math.pi
			if jrec and jrec.get("limits"):
				lower = float(jrec["limits"].get("lower", lower))
				upper = float(jrec["limits"].get("upper", upper))
			spin = QDoubleSpinBox(self._content)
			spin.setDecimals(4)
			spin.setSingleStep(0.01)
			spin.setRange(lower, upper)
			spin.setValue(float(comp.joint_positions.get(jname, 0.0)))
			spin.valueChanged.connect(
				lambda val, c=comp, n=jname, ent=entity: self._on_robot_joint_changed(ent, c, n, val)
			)
			form.addRow(jname, spin)

	def _on_robot_joint_changed(
		self, entity: Entity, comp: RobotDescriptionComponent, joint_name: str, value: float
	) -> None:
		if self._component_is_locked(comp):
			return
		comp.joint_positions[joint_name] = float(value)
		try:
			scene = entity.scene if entity is not None else self._scene
			ik_sys = getattr(scene, "robot_ik_system", None) if scene is not None else None
			if ik_sys is not None:
				# FK + optional Target snap under IK suppress (see RobotIKSystem).
				ik_sys.apply_fk_from_joints(entity)
			else:
				from MotionStudio.core.robot.robot_kinematics import update_robot_fk

				update_robot_fk(comp)
				if self._scene is not None:
					self._scene.events.entity_changed.emit(entity.id)
		except Exception:
			pass

	def _start_vertex_pick(self, entity: Entity, component, spec: FieldSpec) -> None:
		"""Arm the vertex-pick tool for this Vec3 field. Re-clicking the button cancels."""
		mgr = self._vertex_pick_manager
		if mgr is None:
			return
		# Locate the editor widget that triggered this; mark it active.
		editor = self._find_field_editor(component, spec.name)
		# Toggle behaviour: clicking Pick again while armed cancels.
		if getattr(mgr, "is_active", False) and self._active_pick_editor is editor:
			mgr.cancel_pick()
			return
		# Reset prior editor's visual state if switching to another VertexPick field.
		if self._active_pick_editor is not None and self._active_pick_editor is not editor:
			try:
				self._active_pick_editor.set_pick_active(False)
			except Exception:
				pass

		def _on_picked(world_pos, e=entity, comp=component, s=spec):
			self._push_comp_field_change(e, comp, s.name, world_pos)

		# Arm/retarget the tool first. Highlight the button afterwards so a
		# tool_active_changed(False) from a full cancel (legacy / other callers)
		# cannot clear the button we just activated.
		mgr.start_pick(entity, component, spec.name, on_picked=_on_picked, label=spec.name)

		self._active_pick_editor = editor
		if editor is not None:
			try:
				editor.set_pick_active(True)
			except Exception:
				pass

	def _field_editor_search_root(self) -> QWidget:
		"""Search the main inspector and any open child windows (e.g. Group dialogs)."""
		return self.window() or self._content

	def _find_field_editor(self, component, field_name: str) -> Optional[Vector3Editor]:
		"""Find the Vector3Editor for (component, field_name) by its dynamic tag property."""
		target = f"{id(component)}::{field_name}"
		for w in self._field_editor_search_root().findChildren(Vector3Editor):
			if w.property("ms_field_tag") == target:
				return w
		return None

	def _sync_vector3_field_editors(self, component, field_name: str, value: QVector3D) -> None:
		"""Refresh every Vector3Editor for this field (inline inspector and Group dialogs)."""
		target = f"{id(component)}::{field_name}"
		for w in self._field_editor_search_root().findChildren(Vector3Editor):
			if w.property("ms_field_tag") != target:
				continue
			try:
				w.blockSignals(True)
				w.set_value(value)
			finally:
				w.blockSignals(False)

	def _on_vertex_pick_active_changed(self, active: bool) -> None:
		"""Clear active editor styling when the tool finishes or is cancelled."""
		if not active and self._active_pick_editor is not None:
			try:
				self._active_pick_editor.set_pick_active(False)
			except Exception:
				pass
			self._active_pick_editor = None

	def _push_comp_field_change(self, entity: Entity, component, field: str, new_value) -> None:
		# Locked components reject all field writes except header toggles (lock / collapse).
		if not self._is_header_toggle_field(field) and self._component_is_locked(component):
			return
		if self._scene is None or self._undo_stack is None:
			setattr(component, field, new_value)
			self._sync_field_editor_after_change(component, field, new_value)
			return
		comp_type = getattr(component, "type_name", component.__class__.__name__)
		# Tolerate fields that are declared via class annotation but not yet
		# initialised on the instance (e.g. user forgot to set it in __init__).
		old = clone_value(getattr(component, field, None))
		if old == new_value:
			return
		cmd = PropertyChangeCommand(self._scene, entity.id, comp_type, field, old, clone_value(new_value), text=f"{comp_type}.{field}")
		self._undo_stack.push(cmd)
		self._sync_field_editor_after_change(component, field, new_value)

	def _sync_field_editor_after_change(self, component, field: str, new_value) -> None:
		"""Keep Vector3 editors in sync when the component changes outside the widget (e.g. vertex pick)."""
		try:
			from PyQt6.QtGui import QVector3D as _QVector3D

			if isinstance(new_value, _QVector3D):
				self._sync_vector3_field_editors(component, field, new_value)
		except Exception:
			pass

	def _populate_add_component_menu(self, menu: QMenu, on_add) -> None:
		"""Fill ``menu`` with nested category submenus from component ``category`` paths."""
		tree = components_category_menu_tree(exclude={"Transform", "TransformComponent"})

		def _fill(parent_menu: QMenu, node: dict) -> None:
			for type_name, cls in node.get("components") or []:
				action = parent_menu.addAction(type_name)
				desc = str(getattr(cls, "description", "") or "").strip()
				if desc:
					action.setToolTip(self._format_component_info_tooltip(desc))
					action.setStatusTip(self._plain_text_from_html(desc))
				action.triggered.connect(
					lambda _checked=False, comp_cls=cls, tn=type_name: on_add(comp_cls, tn)
				)
			for name, child in (node.get("submenus") or {}).items():
				submenu = parent_menu.addMenu(name)
				_fill(submenu, child)

		_fill(menu, tree)

	def _open_add_component_menu(self, entity: Entity, anchor_widget: QWidget) -> None:
		menu = QMenu(anchor_widget)
		menu.setToolTipsVisible(True)

		def _on_add(comp_cls, type_name: str) -> None:
			existing = entity.get_component(comp_cls)
			if existing is not None:
				QMessageBox.warning(
					self,
					"Component Already Exists",
					f"The entity '{entity.name}' already has a {type_name} component.\n\n"
					"Only one component of each type can be added to an entity.",
				)
				return
			try:
				instance = comp_cls()  # type: ignore[call-arg]
				if self._scene is not None and self._undo_stack is not None:
					snapshot = instance.to_dict()
					cmd = AddComponentCommand(
						self._scene,
						entity.id,
						type_name,
						snapshot,
					)
					self._undo_stack.push(cmd)
				else:
					entity.add_component(instance)
				self._rebuild_for_entity(entity)
			except Exception as ex:
				import traceback
				print(f"Error adding component {type_name}: {ex}")
				traceback.print_exc()
				self._rebuild_for_entity(entity)

		self._populate_add_component_menu(menu, _on_add)
		menu.exec(anchor_widget.mapToGlobal(anchor_widget.rect().bottomRight()))

	def _on_mesh_shape_changed(self, entity: Entity, combo: QComboBox) -> None:
		data = combo.currentData()
		mesh = entity.get_component(MeshComponent)
		if mesh is None:
			return
		if isinstance(data, str) and data in ("cube", "sphere", "custom"):
			mesh.shape = data
			if self._scene is not None:
				self._scene.events.entity_changed.emit(entity.id)

	def _pick_qcolor(self, start, metadata) -> Optional[object]:
		"""Open a color dialog; honor ``ColorField(alpha=...)`` when present."""
		from PyQt6.QtGui import QColor as _QColor

		initial = start if isinstance(start, _QColor) else _QColor(128, 128, 128)
		want_alpha = any(
			isinstance(m, ColorField) and bool(getattr(m, "alpha", False)) for m in (metadata or ())
		)
		options = QColorDialog.ColorDialogOption(0)
		if want_alpha:
			options |= QColorDialog.ColorDialogOption.ShowAlphaChannel
		col = QColorDialog.getColor(initial, self, "Select Color", options)
		return col if col.isValid() else None

	def _apply_color_button_style(self, btn: QPushButton, color) -> None:
		try:
			# QColor expected; fallback if tuple/list provided
			r = int(color.red()) if hasattr(color, "red") else int(color[0])
			g = int(color.green()) if hasattr(color, "green") else int(color[1])
			b = int(color.blue()) if hasattr(color, "blue") else int(color[2])
			a = int(color.alpha()) if hasattr(color, "alpha") else (int(color[3]) if len(color) > 3 else 255)
		except Exception:
			r, g, b, a = 200, 200, 200, 255
		btn.setText("")
		btn.setStyleSheet(f"QPushButton {{ background-color: rgba({r},{g},{b},{a}); border: 1px solid #444; border-radius: 3px; }} QPushButton:pressed {{ border: 1px solid #666; }}")

	@staticmethod
	def _apply_color_button_style_mixed(btn: QPushButton) -> None:
		btn.setText("-")
		btn.setStyleSheet(
			"QPushButton { background-color: #555; color: #ccc; border: 1px solid #444; border-radius: 3px; }"
			"QPushButton:pressed { border: 1px solid #666; }"
		)



"""Optional ur_rtde adapter for Universal Robots controllers.

Connect / send-script / disconnect live here so the component can start
without ``ur_rtde`` installed. Callables raise ``UniversalRobotSdkError``
with a user-facing message when the package is missing or a call fails.

Handles are owned by the hardware worker thread only.
"""

from __future__ import annotations

import socket
from pathlib import Path
from typing import Any, Optional, Tuple


RTDE_PORT = 30004
SCRIPT_PORT = 30002
# Transient RTDE drops are common when a .script starts on 30002.
RECONNECT_ATTEMPTS = 3
RECONNECT_DELAY_S = 0.5


class UniversalRobotSdkError(RuntimeError):
	"""ur_rtde missing, connect failed, or script send failed."""


class UrRtdeSession:
	"""Paired control + receive interfaces for one controller session."""

	__slots__ = ("control", "receive", "ip_address")

	def __init__(
		self,
		control: Any,
		receive: Any,
		ip_address: str = "",
	) -> None:
		self.control = control
		self.receive = receive
		self.ip_address = str(ip_address or "")


def sdk_available() -> bool:
	return _load_sdk()[0] is not None


def sdk_missing_message() -> str:
	return "ur_rtde is not installed. pip install ur_rtde"


def connect_robot(ip_address: str, timeout_ms: int) -> UrRtdeSession:
	"""Open RTDE receive (worker-thread only).

	Does **not** open ``RTDEControlInterface``. That constructor uploads
	ur_rtde's own control script, which a later 30002 ``.script`` send
	replaces — the control handle then dies and often takes the receive
	link with it. Receive on 30004 is enough for ``isProgramRunning``,
	safety flags, and TCP/joint reads while exported programs run.
	"""
	_control_mod, receive_mod, err = _load_sdk()
	if receive_mod is None:
		raise UniversalRobotSdkError(err or sdk_missing_message())
	ip = str(ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	try:
		timeout = int(timeout_ms)
	except Exception:
		timeout = 10000
	timeout = max(1, timeout)
	_probe_rtde_port(ip, timeout)
	receive = _construct_receive(receive_mod, ip)
	return UrRtdeSession(None, receive, ip)


def disconnect_robot(session: Optional[UrRtdeSession]) -> None:
	if session is None:
		return
	for handle in (session.control, session.receive):
		if handle is None:
			continue
		try:
			if hasattr(handle, "disconnect"):
				handle.disconnect()
		except Exception:
			pass
	session.control = None
	session.receive = None


def send_script_file(session: Optional[UrRtdeSession], abs_script_path: str) -> None:
	"""Send a URScript file on the secondary interface (port 30002).

	Does **not** use ``sendCustomScriptFile``. That ur_rtde call blocks in
	native code until a control-script handshake a normal ``.script`` never
	sends, so status would stay on Running script after the robot finished.
	"""
	path = str(abs_script_path or "").strip()
	if not path:
		raise UniversalRobotSdkError("Script path is empty.")
	try:
		text = Path(path).read_text(encoding="utf-8")
	except OSError as exc:
		raise UniversalRobotSdkError(f"Could not read script: {exc}") from exc
	send_script_text(session, text)


def send_script_text(session: Optional[UrRtdeSession], script_text: str) -> None:
	"""Send URScript source on the secondary interface (port 30002)."""
	if session is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	ip = str(session.ip_address or "").strip()
	if not ip:
		raise UniversalRobotSdkError("IP address is empty.")
	text = str(script_text or "")
	if not text.strip():
		raise UniversalRobotSdkError("Script is empty.")
	if not text.endswith("\n"):
		text += "\n"
	try:
		sock = socket.create_connection((ip, SCRIPT_PORT), timeout=5.0)
		try:
			sock.sendall(text.encode("utf-8"))
		finally:
			sock.close()
	except OSError as exc:
		raise UniversalRobotSdkError(
			f"Could not send script to {ip}:{SCRIPT_PORT} (not in Remote Control, "
			f"or the controller is unreachable). ({exc})"
		) from exc
	# Starting a program on 30002 often flickers RTDE receive. Give the
	# controller a beat, then restore receive if it dropped.
	import time as _time

	_time.sleep(0.35)
	if not reconnect_receive(session, attempts=RECONNECT_ATTEMPTS):
		raise UniversalRobotSdkError(
			"Connection lost after sending the script (RTDE receive did not recover)."
		)


def send_movel(
	session: Optional[UrRtdeSession],
	pose_m_rotvec: Tuple[float, float, float, float, float, float],
	*,
	speed_m_s: float = 0.25,
	accel_m_s2: float = 1.2,
) -> None:
	"""Send a one-shot ``movel`` to ``p[x,y,z,rx,ry,rz]`` (metres, UR rotvec)."""
	x, y, z, rx, ry, rz = (float(v) for v in pose_m_rotvec)
	v = max(1e-4, float(speed_m_s))
	a = max(1e-4, float(accel_m_s2))
	text = (
		"def move_to_target():\n"
		f"    movel(p[{x:.6f}, {y:.6f}, {z:.6f}, {rx:.6f}, {ry:.6f}, {rz:.6f}], "
		f"a={a:.6f}, v={v:.6f})\n"
		"end\n"
		"move_to_target()\n"
	)
	send_script_text(session, text)


def send_halt(session: Optional[UrRtdeSession]) -> None:
	"""Replace the running program with ``halt`` so motion and scripts stop."""
	send_script_text(session, "halt\n")


def session_is_connected(
	session: Optional[UrRtdeSession],
	*,
	probe_host: bool = False,
) -> bool:
	"""True when the RTDE receive interface still reports a live link.

	``probe_host`` also opens a short TCP connection to the **RTDE** port
	(30004), never 30002. Connecting to the script port while a program is
	running can abort that program or steal the secondary-client slot.
	"""
	if session is None or session.receive is None:
		return False
	recv = session.receive
	try:
		if hasattr(recv, "isConnected") and not bool(recv.isConnected()):
			return False
	except Exception:
		return False
	if probe_host:
		ip = str(session.ip_address or "").strip()
		if ip and not _port_reachable(ip, RTDE_PORT, 0.25):
			return False
	return True


def reconnect_receive(
	session: Optional[UrRtdeSession],
	*,
	attempts: int = RECONNECT_ATTEMPTS,
	delay_s: float = RECONNECT_DELAY_S,
) -> bool:
	"""Re-open RTDE receive after a dropped link. Worker-thread only.

	Returns True if the session is (or became) connected. Does not open
	``RTDEControlInterface``. Sleeps ``delay_s`` between attempts.
	"""
	import time

	if session is None:
		return False
	if session_is_connected(session):
		return True
	_control_mod, receive_mod, err = _load_sdk()
	if receive_mod is None:
		return False
	ip = str(session.ip_address or "").strip()
	if not ip:
		return False
	n = max(1, int(attempts))
	wait = max(0.05, float(delay_s))
	last_exc = err
	for i in range(n):
		_close_receive(session)
		try:
			session.receive = _construct_receive(receive_mod, ip)
			if session_is_connected(session):
				if i > 0:
					print(
						f"UniversalRobot: RTDE receive reconnected on attempt {i + 1}/{n}.",
						flush=True,
					)
				return True
		except Exception as exc:
			last_exc = exc
			session.receive = None
		print(
			f"UniversalRobot: RTDE receive reconnect {i + 1}/{n} failed ({last_exc}).",
			flush=True,
		)
		if i + 1 < n:
			time.sleep(wait)
	return False


def _close_receive(session: UrRtdeSession) -> None:
	recv = session.receive
	session.receive = None
	if recv is None:
		return
	try:
		if hasattr(recv, "disconnect"):
			recv.disconnect()
	except Exception:
		pass


def is_program_running(session: Optional[UrRtdeSession]) -> bool:
	if session is None:
		return False
	for handle in (session.receive, session.control):
		if handle is None or not hasattr(handle, "isProgramRunning"):
			continue
		try:
			return bool(handle.isProgramRunning())
		except Exception:
			continue
	return False


def safety_fault_message(session: Optional[UrRtdeSession]) -> str:
	"""Empty unless protective or emergency stop is active."""
	if session is None:
		return ""
	recv = session.receive
	if recv is None:
		return ""
	try:
		if hasattr(recv, "isEmergencyStopped") and recv.isEmergencyStopped():
			return "Emergency stop."
	except Exception:
		pass
	try:
		if hasattr(recv, "isProtectiveStopped") and recv.isProtectiveStopped():
			return "Protective stop."
	except Exception:
		pass
	return ""


def get_tcp_pose(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""TCP pose in metres / rotation vector (ur_rtde ``getActualTCPPose``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		pose = session.receive.getActualTCPPose()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualTCPPose failed: {exc}") from exc
	return tuple(float(v) for v in pose)


def get_joints(session: Optional[UrRtdeSession]) -> Tuple[float, ...]:
	"""Actual joint positions in radians (ur_rtde ``getActualQ``)."""
	if session is None or session.receive is None:
		raise UniversalRobotSdkError("Robot is not connected.")
	try:
		q = session.receive.getActualQ()
	except Exception as exc:
		raise UniversalRobotSdkError(f"getActualQ failed: {exc}") from exc
	return tuple(float(v) for v in q)


def _probe_rtde_port(ip: str, timeout_ms: int) -> None:
	"""Fail fast if the controller RTDE port is unreachable."""
	try:
		sock = socket.create_connection((ip, RTDE_PORT), timeout=max(0.2, timeout_ms / 1000.0))
		sock.close()
	except OSError as exc:
		raise UniversalRobotSdkError(
			f"Cannot reach {ip}:{RTDE_PORT} (RTDE). Check IP, network, and that "
			f"Polyscope is running. ({exc})"
		) from exc


def _port_reachable(ip: str, port: int, timeout_s: float) -> bool:
	try:
		sock = socket.create_connection((ip, int(port)), timeout=max(0.1, float(timeout_s)))
		sock.close()
		return True
	except OSError:
		return False


def _construct_receive(receive_mod: Any, ip: str) -> Any:
	cls = receive_mod.RTDEReceiveInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(f"RTDE receive connect failed: {exc}") from exc
	try:
		if hasattr(handle, "isConnected") and not handle.isConnected():
			raise UniversalRobotSdkError("RTDE receive is not connected.")
	except UniversalRobotSdkError:
		disconnect_robot(UrRtdeSession(None, handle))
		raise
	except Exception:
		pass
	return handle


def _construct_control(control_mod: Any, ip: str) -> Any:
	cls = control_mod.RTDEControlInterface
	try:
		handle = cls(ip)
	except Exception as exc:
		raise UniversalRobotSdkError(
			f"RTDE control connect failed: {exc}. On e-Series the robot must be "
			f"in Remote Control."
		) from exc
	return handle


def _load_sdk() -> Tuple[Optional[Any], Optional[Any], str]:
	try:
		import rtde_control  # type: ignore
		import rtde_receive  # type: ignore
	except Exception as exc:
		return None, None, f"{sdk_missing_message()} ({exc})"
	if not hasattr(rtde_control, "RTDEControlInterface"):
		return None, None, "ur_rtde is installed but RTDEControlInterface is missing."
	if not hasattr(rtde_receive, "RTDEReceiveInterface"):
		return None, None, "ur_rtde is installed but RTDEReceiveInterface is missing."
	return rtde_control, rtde_receive, ""

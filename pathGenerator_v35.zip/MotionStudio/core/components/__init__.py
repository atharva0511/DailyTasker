"""
Core component implementations for the ECS system.

This package contains the standard components used in the engine.
All files ending with '_component.py' are automatically imported and registered.
"""

from __future__ import annotations

import importlib
from pathlib import Path

# Explicit imports for PyInstaller compatibility
# These ensure all components are included in the bundle when packaging
from .transform_component import TransformComponent
from .mesh_component import MeshComponent
from .path_component import PathComponent
from .test_component import TestComponent
from .tool_trace_component import ToolTraceComponent
from .collider_component import ColliderComponent
from .point_cloud_collider_component import PointCloudColliderComponent
from .robot_description_component import RobotDescriptionComponent
from .robot_ik_component import RobotIKComponent
from .lift_to_safety_component import LiftToSafetyComponent
from .urdf_link_component import UrdfLinkComponent
from .three_point_calibration import ThreePointCalibrationComponent
from .motion_planner_component import MotionPlannerComponent
from .gp_leak_path_generator_component import GPLeakPathGeneratorComponent
from .point_cloud_component import PointCloudComponent
from .measure_distance_component import MeasureDistanceComponent
from .measure_angle_component import MeasureAngleComponent
from .mechmind_scanner_component import MechmindScannerComponent
from .universal_robot_component import UniversalRobotComponent
from .robot import Robot
from .scanner import Scanner
from .scan_mission_component import ScanMissionComponent

# Get the directory containing this __init__.py file
_current_dir = Path(__file__).parent

# Automatically import all files ending with '_component.py'
# This allows new components to be automatically discovered
__all__ = [
	'TransformComponent', 'MeshComponent', 'PathComponent', 'TestComponent',
		'ToolTraceComponent', 'ColliderComponent', 'PointCloudColliderComponent',
		'RobotDescriptionComponent',
	'RobotIKComponent', 'LiftToSafetyComponent', 'UrdfLinkComponent',
	'ThreePointCalibrationComponent',
	'MotionPlannerComponent', 'GPLeakPathGeneratorComponent', 'PointCloudComponent',
	'MeasureDistanceComponent', 'MeasureAngleComponent',
	'MechmindScannerComponent', 'UniversalRobotComponent',
	'Robot', 'Scanner', 'ScanMissionComponent',
]

# Dynamic import for any additional components not explicitly listed above
for file_path in sorted(_current_dir.glob("*_component.py")):
	module_name = file_path.stem
	
	# Skip if already explicitly imported
	if module_name in [
		'transform_component', 'mesh_component', 'path_component', 'test_component',
		'tool_trace_component', 'collider_component',
		'point_cloud_collider_component', 'robot_description_component',
		'robot_ik_component', 'lift_to_safety_component', 'urdf_link_component',
		'motion_planner_component', 'gp_leak_path_generator_component',
		'point_cloud_component', 'measure_distance_component',
		'measure_angle_component', 'mechmind_scanner_component',
		'universal_robot_component', 'scan_mission_component',
	]:
		continue
	
	# Import the module (this will execute @register_component decorators)
	try:
		module = importlib.import_module(f".{module_name}", package=__name__)
		
		# Try to find the component class in the module
		# Convert module name to expected class name (e.g., "mesh_component" -> "MeshComponent")
		parts = module_name.replace("_component", "").split("_")
		expected_class_name = "".join(word.capitalize() for word in parts) + "Component"
		
		# Check if the class exists in the module and add it to __all__
		if hasattr(module, expected_class_name):
			component_class = getattr(module, expected_class_name)
			# Make it available at package level
			globals()[expected_class_name] = component_class
			__all__.append(expected_class_name)
	except Exception:
		# Skip modules that fail to import or don't have the expected class
		pass


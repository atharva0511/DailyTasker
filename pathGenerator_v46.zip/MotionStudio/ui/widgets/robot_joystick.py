"""Cartesian jog pads for a hardware Robot (base-frame TCP steps)."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Tuple

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QVector3D
from PyQt6.QtWidgets import (
	QDoubleSpinBox,
	QFormLayout,
	QGridLayout,
	QGroupBox,
	QHBoxLayout,
	QLabel,
	QPushButton,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.ui.widgets.vector3_editor import Vector3Editor

if TYPE_CHECKING:
	from MotionStudio.core.components.robot import Robot

_COLOR_X = "#E57373"
_COLOR_Y = "#66BB6A"
_COLOR_Z = "#64B5F6"
_BTN_W = 88
_BTN_H = 52
_TYPE_MOVE_DEBOUNCE_MS = 250
_POSE_EPS = 1e-4


class RobotJoystick(QWidget):
	"""Position/rotation editors, jog pads, and a shared millimetre-or-degree step."""

	def __init__(self, robot: "Robot", parent: QWidget | None = None) -> None:
		super().__init__(parent)
		self._robot = robot
		self._jog_buttons: List[QPushButton] = []
		self._applying = False

		root = QVBoxLayout(self)
		root.setContentsMargins(0, 0, 0, 0)
		root.setSpacing(12)

		self._pos = Vector3Editor(
			self,
			on_changed=self._on_position_typed,
			step=1.0,
			suffix=" mm",
		)
		self._pos.setToolTip("TCP position in the hardware robot base (mm). Edit commits a movel.")
		self._rot = Vector3Editor(
			self,
			on_changed=self._on_rotation_typed,
			step=1.0,
			suffix=" °",
		)
		self._rot.setToolTip(
			"TCP rotation vector in the hardware robot base (degrees). Edit commits a movel."
		)

		form = QFormLayout()
		form.setContentsMargins(0, 0, 0, 0)
		form.setSpacing(6)
		form.addRow("Position", self._pos)
		form.addRow("Rotation", self._rot)
		root.addLayout(form)

		root.addWidget(self._build_translation_pad())
		root.addWidget(self._build_rotation_pad())

		step_row = QHBoxLayout()
		step_row.setContentsMargins(0, 0, 0, 0)
		label = QLabel("Move step size", self)
		self._step = QDoubleSpinBox(self)
		self._step.setRange(0.1, 1000.0)
		self._step.setDecimals(2)
		self._step.setSingleStep(1.0)
		self._step.setValue(10.0)
		self._step.setSuffix("  mm / deg")
		self._step.setToolTip(
			"Added to Position (mm) or Rotation (deg) when a pad button is clicked, "
			"then a movel is sent to those fields."
		)
		self._step.setMinimumWidth(140)
		step_row.addWidget(label)
		step_row.addWidget(self._step, 1)
		root.addLayout(step_row)
		root.addStretch(1)

		self._type_move_timer = QTimer(self)
		self._type_move_timer.setSingleShot(True)
		self._type_move_timer.setInterval(_TYPE_MOVE_DEBOUNCE_MS)
		self._type_move_timer.timeout.connect(self._commit_and_move)

		self.sync_fields_from_robot()
		self.sync_enabled()

	def robot(self) -> "Robot":
		return self._robot

	def set_robot(self, robot: "Robot") -> None:
		self._robot = robot
		self.sync_fields_from_robot()
		self.sync_enabled()

	def step_size(self) -> float:
		return float(self._step.value())

	def sync_enabled(self) -> None:
		robot = self._robot
		locked = bool(getattr(robot, "locked", False))
		busy = bool(getattr(robot, "_busy", False))
		connected = bool(getattr(robot, "_was_connected", False))
		ok = connected and not busy and not locked
		for btn in self._jog_buttons:
			btn.setEnabled(ok)
		self._step.setEnabled(not locked)
		self._pos.setEnabled(not locked and not busy)
		self._rot.setEnabled(not locked and not busy)

	def sync_fields_from_robot(self) -> None:
		"""Copy ``target_position`` / ``target_rotation`` into the editors."""
		if self._applying:
			return
		if self._pos.has_editor_focus() or self._rot.has_editor_focus():
			return
		robot = self._robot
		pos = getattr(robot, "target_position", None)
		rot = getattr(robot, "target_rotation", None)
		if not isinstance(pos, QVector3D):
			pos = QVector3D()
		if not isinstance(rot, QVector3D):
			rot = QVector3D()
		self._pos.set_value(pos)
		self._rot.set_value(rot)

	def _pose_from_fields(self) -> Tuple[QVector3D, QVector3D]:
		return self._pos.value(), self._rot.value()

	def _on_position_typed(self, _value: QVector3D) -> None:
		self._schedule_typed_move()

	def _on_rotation_typed(self, _value: QVector3D) -> None:
		self._schedule_typed_move()

	def _schedule_typed_move(self) -> None:
		if self._applying:
			return
		pos, rot = self._pose_from_fields()
		robot = self._robot
		cur_pos = getattr(robot, "target_position", None)
		cur_rot = getattr(robot, "target_rotation", None)
		if not isinstance(cur_pos, QVector3D):
			cur_pos = QVector3D()
		if not isinstance(cur_rot, QVector3D):
			cur_rot = QVector3D()
		if _vec_close(pos, cur_pos) and _vec_close(rot, cur_rot):
			return
		self._type_move_timer.start()

	def _commit_and_move(self) -> None:
		robot = self._robot
		if bool(getattr(robot, "locked", False)):
			return
		if self._applying:
			return
		pos, rot = self._pose_from_fields()
		set_target = getattr(robot, "set_move_target", None)
		move = getattr(robot, "move_to_target", None)
		if not callable(set_target) or not callable(move):
			return
		self._applying = True
		try:
			set_target(pos, rot)
			if not bool(getattr(robot, "_was_connected", False)):
				return
			if bool(getattr(robot, "_busy", False)):
				return
			move()
		finally:
			self._applying = False
		self.sync_enabled()

	def _build_translation_pad(self) -> QGroupBox:
		box = QGroupBox("Translation", self)
		grid = QGridLayout(box)
		grid.setContentsMargins(8, 12, 8, 8)
		grid.setSpacing(8)
		grid.setAlignment(Qt.AlignmentFlag.AlignCenter)
		grid.addWidget(self._axis_button("▲\nZ+", "Z+", _COLOR_Z, "z", 1.0), 0, 1)
		grid.addWidget(self._axis_button("▼\nZ-", "Z-", _COLOR_Z, "z", -1.0), 0, 3)
		grid.addWidget(self._axis_button("▲\nX-", "X-", _COLOR_X, "x", -1.0), 1, 2)
		grid.addWidget(self._axis_button("◀  Y-", "Y-", _COLOR_Y, "y", -1.0), 2, 1)
		grid.addWidget(self._axis_button("Y+  ▶", "Y+", _COLOR_Y, "y", 1.0), 2, 3)
		grid.addWidget(self._axis_button("▼\nX+", "X+", _COLOR_X, "x", 1.0), 3, 2)
		return box

	def _build_rotation_pad(self) -> QGroupBox:
		box = QGroupBox("Rotation", self)
		grid = QGridLayout(box)
		grid.setContentsMargins(8, 12, 8, 8)
		grid.setSpacing(8)
		grid.setAlignment(Qt.AlignmentFlag.AlignCenter)
		grid.addWidget(self._axis_button("↺  RZ+", "RZ+", _COLOR_Z, "rz", 1.0), 0, 1)
		grid.addWidget(self._axis_button("RZ-  ↻", "RZ-", _COLOR_Z, "rz", -1.0), 0, 3)
		grid.addWidget(self._axis_button("▲\nRY-", "RY-", _COLOR_Y, "ry", -1.0), 1, 2)
		grid.addWidget(self._axis_button("◀  RX+", "RX+", _COLOR_X, "rx", 1.0), 2, 1)
		grid.addWidget(self._axis_button("RX-  ▶", "RX-", _COLOR_X, "rx", -1.0), 2, 3)
		grid.addWidget(self._axis_button("▼\nRY+", "RY+", _COLOR_Y, "ry", 1.0), 3, 2)
		return box

	def _axis_button(
		self,
		text: str,
		tooltip: str,
		color: str,
		axis: str,
		sign: float,
	) -> QPushButton:
		btn = QPushButton(text, self)
		btn.setToolTip(f"Add the move step to {tooltip}, then movel to the fields.")
		btn.setFixedSize(_BTN_W, _BTN_H)
		btn.setCursor(Qt.CursorShape.PointingHandCursor)
		btn.setStyleSheet(
			f"""
			QPushButton {{
				background-color: {color};
				color: #ffffff;
				border: none;
				border-radius: 10px;
				font-weight: 600;
				font-size: 12px;
			}}
			QPushButton:hover {{
				background-color: {color};
				border: 2px solid #ffffff;
			}}
			QPushButton:pressed {{
				padding-top: 2px;
			}}
			QPushButton:disabled {{
				background-color: #888888;
				color: #dddddd;
				border: none;
			}}
			"""
		)
		btn.clicked.connect(lambda _c=False, a=axis, s=sign: self._on_jog(a, s))
		self._jog_buttons.append(btn)
		return btn

	def _on_jog(self, axis: str, sign: float) -> None:
		self.sync_enabled()
		robot = self._robot
		if not bool(getattr(robot, "_was_connected", False)):
			return
		if bool(getattr(robot, "_busy", False)):
			return
		if bool(getattr(robot, "locked", False)):
			return
		step = sign * self.step_size()
		self._type_move_timer.stop()
		if axis in ("x", "y", "z"):
			vec = self._pos.value()
			if axis == "x":
				vec.setX(vec.x() + step)
			elif axis == "y":
				vec.setY(vec.y() + step)
			else:
				vec.setZ(vec.z() + step)
			self._pos.set_value(vec)
		else:
			vec = self._rot.value()
			if axis == "rx":
				vec.setX(vec.x() + step)
			elif axis == "ry":
				vec.setY(vec.y() + step)
			else:
				vec.setZ(vec.z() + step)
			self._rot.set_value(vec)
		self._commit_and_move()


def _vec_close(a: QVector3D, b: QVector3D, eps: float = _POSE_EPS) -> bool:
	return (
		abs(float(a.x()) - float(b.x())) <= eps
		and abs(float(a.y()) - float(b.y())) <= eps
		and abs(float(a.z()) - float(b.z())) <= eps
	)

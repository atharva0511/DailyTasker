"""Floating dockable Cartesian jog window for a hardware Robot."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from PyQt6.QtWidgets import (
	QDockWidget,
	QScrollArea,
	QSizePolicy,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.core.components.robot import Robot
from MotionStudio.ui.inspector.inspector_dock import (
	entity_display_name,
	open_or_focus_inspector_dock,
)
from MotionStudio.ui.widgets.robot_joystick import RobotJoystick

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector_panel import InspectorPanel


def _joystick_window_title(entity: "Entity", robot: Robot) -> str:
	name = entity_display_name(entity)
	ctype = str(getattr(robot, "type_name", robot.__class__.__name__) or "Robot")
	return f"{name} -> {ctype} -> Joystick"


def open_robot_joystick_dock(
	panel: "InspectorPanel",
	entity: "Entity",
	robot: Robot,
) -> None:
	"""Open (or focus) the Robot joystick as a floating dockable window."""
	key = ("robot_joystick", str(entity.id), str(getattr(robot, "type_name", "")))
	title = _joystick_window_title(entity, robot)

	def _make() -> RobotJoystickPanel:
		return RobotJoystickPanel(panel, entity, robot)

	open_or_focus_inspector_dock(
		panel,
		key,
		title,
		_make,
		store_attr="_robot_joystick_docks",
		width=440,
		height=680,
	)


class RobotJoystickPanel(QWidget):
	"""Jog pads hosted in a floating Inspector dock."""

	def __init__(
		self,
		panel: "InspectorPanel",
		entity: "Entity",
		robot: Robot,
	) -> None:
		# Parent None so this is not a child of the Inspector dock (blocks re-dock).
		super().__init__(None)
		self._panel = panel
		self._entity = entity
		self._robot = robot
		self._host_dock: Optional[QDockWidget] = None
		self._closing = False
		self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
		self.setMinimumSize(260, 180)

		root = QVBoxLayout(self)
		root.setContentsMargins(0, 0, 0, 0)
		root.setSpacing(0)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(True)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		body = QWidget(scroll)
		body_layout = QVBoxLayout(body)
		body_layout.setContentsMargins(12, 12, 12, 12)
		body_layout.setSpacing(8)
		self._pad = RobotJoystick(robot, body)
		body_layout.addWidget(self._pad, 1)
		scroll.setWidget(body)
		root.addWidget(scroll, 1)

		try:
			robot.add_job_listener(self._on_job)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_removed.connect(self._on_entity_removed)
				self._panel._scene.events.entity_changed.connect(self._on_entity_changed)
		except Exception:
			pass

	def bind_host_dock(self, dock: QDockWidget) -> None:
		self._host_dock = dock

	def _on_job(self, _kind: str, _success: bool, _message: str) -> None:
		self._pad.sync_enabled()
		self._pad.sync_fields_from_robot()

	def _on_entity_removed(self, entity_id: str) -> None:
		if self._entity.id == entity_id:
			self._close_host()

	def _on_entity_changed(self, entity_id: str) -> None:
		if self._entity.id != entity_id:
			return
		robot = self._entity.get_component(Robot)
		if robot is None:
			self._close_host()
			return
		if robot is not self._robot:
			try:
				self._robot.remove_job_listener(self._on_job)
			except Exception:
				pass
			self._robot = robot
			try:
				robot.add_job_listener(self._on_job)
			except Exception:
				pass
			self._pad.set_robot(robot)
			dock = self._host_dock
			if dock is not None:
				dock.setWindowTitle(_joystick_window_title(self._entity, robot))
		self._pad.sync_fields_from_robot()
		self._pad.sync_enabled()

	def _close_host(self) -> None:
		self._closing = True
		dock = self._host_dock
		if dock is not None:
			dock.close()
		else:
			self.close()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			self._robot.remove_job_listener(self._on_job)
		except Exception:
			pass
		try:
			if self._panel._scene is not None:
				self._panel._scene.events.entity_removed.disconnect(self._on_entity_removed)
				self._panel._scene.events.entity_changed.disconnect(self._on_entity_changed)
		except Exception:
			pass
		super().closeEvent(event)

from __future__ import annotations

from typing import Dict, List

from MotionStudio.core.robot.ik.ik_backend import IKBackend, IKSolveRequest, IKSolveResult


def make_ik_backend(name: str) -> IKBackend:
	"""Construct an IK backend by name."""
	key = (name or "").strip().lower()
	if key == "ikfast":
		from MotionStudio.core.robot.ik.ikfast_backend import IKFastIKBackend

		return IKFastIKBackend()
	if key == "pinocchio":
		from MotionStudio.core.robot.ik.pinocchio_backend import PinocchioIKBackend

		return PinocchioIKBackend()
	from MotionStudio.core.robot.ik.ikpy_backend import IKPyIKBackend

	return IKPyIKBackend()


def backend_fallback_chain(preferred_backend: str) -> List[str]:
	key = (preferred_backend or "").strip().lower()
	if key == "ikfast":
		return ["ikfast", "pinocchio", "ikpy"]
	if key in ("pinocchio", "ikpy"):
		return [key]
	return ["ikpy"]


def solve_request_with_fallback(
	preferred_backend: str,
	request: IKSolveRequest,
	backend_cache: Dict[str, IKBackend],
) -> IKSolveResult:
	last_result = IKSolveResult(False, {}, "No IK backend attempted.")
	for backend_name in backend_fallback_chain(preferred_backend):
		backend = backend_cache.get(backend_name)
		if backend is None:
			backend = make_ik_backend(backend_name)
			backend_cache[backend_name] = backend
		try:
			if not backend.is_available():
				last_result = IKSolveResult(False, {}, f"IK backend '{backend_name}' is not installed.")
				continue
			result = backend.solve(request)
		except Exception as exc:  # pragma: no cover - defensive
			last_result = IKSolveResult(False, {}, f"IK solve error ({backend_name}): {exc}")
			continue
		if result.success or result.joint_values:
			return result
		last_result = result
	return last_result

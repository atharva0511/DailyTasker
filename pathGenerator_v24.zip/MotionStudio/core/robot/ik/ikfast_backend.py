from __future__ import annotations

import inspect
import math
import os
from importlib import util as importlib_util
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult


def _rx(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((1.0, 0.0, 0.0), (0.0, c, -s), (0.0, s, c)), dtype=np.float64)


def _ry(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((c, 0.0, s), (0.0, 1.0, 0.0), (-s, 0.0, c)), dtype=np.float64)


def _rz(a: float) -> np.ndarray:
	c = math.cos(a)
	s = math.sin(a)
	return np.array(((c, -s, 0.0), (s, c, 0.0), (0.0, 0.0, 1.0)), dtype=np.float64)


def _axis_angle(axis: np.ndarray, theta: float) -> np.ndarray:
	ax = np.asarray(axis, dtype=np.float64)
	n = float(np.linalg.norm(ax))
	if n < 1e-12:
		return np.eye(3, dtype=np.float64)
	x, y, z = ax / n
	c = math.cos(theta)
	s = math.sin(theta)
	t = 1.0 - c
	return np.array(
		(
			(t * x * x + c, t * x * y - s * z, t * x * z + s * y),
			(t * y * x + s * z, t * y * y + c, t * y * z - s * x),
			(t * z * x - s * y, t * z * y + s * x, t * z * z + c),
		),
		dtype=np.float64,
	)


def _origin_transform(joint: Dict[str, Any]) -> np.ndarray:
	xyz = np.asarray(joint.get("origin_xyz_m", [0.0, 0.0, 0.0]), dtype=np.float64)
	rpy = np.asarray(joint.get("origin_rpy_rad", [0.0, 0.0, 0.0]), dtype=np.float64)
	m = np.eye(4, dtype=np.float64)
	# URDF convention: R = Rz(yaw) * Ry(pitch) * Rx(roll)
	m[:3, :3] = _rz(float(rpy[2])) @ _ry(float(rpy[1])) @ _rx(float(rpy[0]))
	m[:3, 3] = xyz
	return m


def _joint_path(
	joints: List[Dict[str, Any]], root_link: str, ee_link: str
) -> List[Dict[str, Any]]:
	by_child: Dict[str, Dict[str, Any]] = {str(j.get("child_link", "")): j for j in joints}
	path: List[Dict[str, Any]] = []
	cur = str(ee_link or "")
	guard = 0
	while cur and cur != root_link and cur in by_child:
		j = by_child[cur]
		path.append(j)
		cur = str(j.get("parent_link", ""))
		guard += 1
		if guard > 4096:
			break
	path.reverse()
	return path


def _forward_kinematics(request: IKSolveRequest, q_map: Dict[str, float]) -> Optional[np.ndarray]:
	path = _joint_path(request.joints, request.root_link, request.ee_link)
	if not path:
		return None
	t = np.eye(4, dtype=np.float64)
	for j in path:
		t = t @ _origin_transform(j)
		jname = str(j.get("name", ""))
		jtype = str(j.get("type", "fixed")).lower()
		if jtype in ("revolute", "continuous"):
			angle = float(q_map.get(jname, 0.0))
			axis = np.asarray(j.get("axis_xyz", [0.0, 0.0, 1.0]), dtype=np.float64)
			r = np.eye(4, dtype=np.float64)
			r[:3, :3] = _axis_angle(axis, angle)
			t = t @ r
		elif jtype == "prismatic":
			dist = float(q_map.get(jname, 0.0))
			axis = np.asarray(j.get("axis_xyz", [0.0, 0.0, 1.0]), dtype=np.float64)
			n = float(np.linalg.norm(axis))
			if n > 1e-12:
				tr = np.eye(4, dtype=np.float64)
				tr[:3, 3] = axis / n * dist
				t = t @ tr
	return t


class IKFastIKBackend:
	"""IK backend adapter for pre-generated IKFast Python modules."""

	def __init__(self) -> None:
		# solver_path -> (mtime, module, solve_func)
		self._cache: Dict[str, Tuple[float, Any, Callable[..., Any]]] = {}

	def is_available(self) -> bool:
		# Availability is request-specific (solver path + module contract),
		# so backend-level availability is always true.
		return True

	def invalidate_cache(self, urdf_path: str) -> None:
		# IKFast caches are keyed by solver module path, not URDF path.
		_ = urdf_path

	def _load_solver(self, solver_path: str) -> Optional[Tuple[Any, Callable[..., Any]]]:
		if not solver_path:
			return None
		path = os.path.abspath(solver_path)
		if not os.path.isfile(path):
			return None
		try:
			mtime = os.path.getmtime(path)
		except OSError:
			mtime = 0.0
		cached = self._cache.get(path)
		if cached is not None and cached[0] == mtime:
			return cached[1], cached[2]
		module_name = f"motionstudio_ikfast_{abs(hash(path))}"
		spec = importlib_util.spec_from_file_location(module_name, path)
		if spec is None or spec.loader is None:
			return None
		module = importlib_util.module_from_spec(spec)
		spec.loader.exec_module(module)
		solve_fn = getattr(module, "solve_ik", None) or getattr(module, "solve", None) or getattr(module, "get_ik", None)
		if not callable(solve_fn):
			return None
		self._cache[path] = (mtime, module, solve_fn)
		return module, solve_fn

	@staticmethod
	def _normalize_candidates(raw: Any, joint_names: List[str]) -> List[Dict[str, float]]:
		if raw is None:
			return []
		candidates = raw if isinstance(raw, (list, tuple)) else [raw]
		out: List[Dict[str, float]] = []
		for cand in candidates:
			if isinstance(cand, dict):
				mapped = {n: float(cand[n]) for n in joint_names if n in cand}
				if len(mapped) == len(joint_names):
					out.append(mapped)
				continue
			if isinstance(cand, np.ndarray):
				seq = cand.tolist()
			else:
				seq = list(cand) if isinstance(cand, (list, tuple)) else None
			if seq is None or len(seq) != len(joint_names):
				continue
			out.append({n: float(v) for n, v in zip(joint_names, seq)})
		return out

	@staticmethod
	def _pose_error(fk: np.ndarray, goal: np.ndarray) -> Tuple[float, float]:
		pos_err = float(np.linalg.norm(fk[:3, 3] - goal[:3, 3]))
		r_rel = fk[:3, :3].T @ goal[:3, :3]
		cos_angle = (np.trace(r_rel) - 1.0) * 0.5
		ang_err = float(math.acos(max(-1.0, min(1.0, cos_angle))))
		return pos_err, ang_err

	@staticmethod
	def _call_solver(module: Any, solve_fn: Callable[..., Any], request: IKSolveRequest) -> Any:
		goal = np.asarray(request.T_goal_base, dtype=np.float64)
		seed = np.asarray(request.q_seed, dtype=np.float64)
		joint_names = list(request.joint_names)
		eetrans = goal[:3, 3].tolist()
		eerot = goal[:3, :3].reshape(-1).tolist()
		# Prefer keyword-rich contract first; then common IKFast signatures.
		calls = (
			lambda: solve_fn(T_goal_base=goal, q_seed=seed, joint_names=joint_names),
			lambda: solve_fn(goal, seed, joint_names),
			lambda: solve_fn(goal),
			lambda: solve_fn(eetrans, eerot, []),
			lambda: solve_fn(eetrans, eerot),
		)
		last_exc: Optional[Exception] = None
		for attempt in calls:
			try:
				return attempt()
			except TypeError as exc:
				last_exc = exc
				continue
		if last_exc is not None:
			raise last_exc
		return None

	def solve(self, request: IKSolveRequest) -> IKSolveResult:
		solver_path = str(getattr(request, "ikfast_solver_path", "") or "")
		if not solver_path:
			return IKSolveResult(False, {}, "IKFast solver path is not configured.")
		loaded = self._load_solver(solver_path)
		if loaded is None:
			return IKSolveResult(False, {}, f"IKFast solver not found or invalid: {solver_path}")
		module, solve_fn = loaded
		try:
			raw = self._call_solver(module, solve_fn, request)
		except Exception as exc:
			return IKSolveResult(False, {}, f"IKFast solve failed: {exc}")
		candidates = self._normalize_candidates(raw, request.joint_names)
		if not candidates:
			return IKSolveResult(False, {}, "IKFast returned no valid candidate solutions.")

		best: Optional[Dict[str, float]] = None
		best_err = float("inf")
		best_pos = float("inf")
		best_ang = float("inf")
		for cand in candidates:
			fk = _forward_kinematics(request, cand)
			if fk is None:
				continue
			pos_err, ang_err = self._pose_error(fk, request.T_goal_base)
			score = pos_err + ang_err
			if score < best_err:
				best_err = score
				best_pos = pos_err
				best_ang = ang_err
				best = cand
		if best is None:
			return IKSolveResult(False, {}, "Could not evaluate IKFast candidates against FK.")
		success = best_pos < request.position_tolerance_m and best_ang < request.orientation_tolerance_rad
		msg = "" if success else f"Did not converge (pos_err={best_pos:.4g} m, ang_err={best_ang:.4g} rad)."
		return IKSolveResult(success, best, msg)

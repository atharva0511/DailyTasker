from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Protocol, runtime_checkable

import numpy as np


@dataclass
class IKSolveRequest:
	"""A single inverse-kinematics query, expressed entirely in plain data.

	The request is built on the main thread (reading entity transforms) and
	then handed to a worker thread, so it must not hold any Qt or ECS objects.

	Units follow the URDF / Pinocchio convention: translation in **metres**,
	joint angles in **radians**.
	"""

	robot_entity_id: str
	urdf_path: str
	joint_names: List[str]
	q_seed: np.ndarray
	T_goal_base: np.ndarray  # 4x4 SE3, target pose in the robot base frame (metres)
	ee_link: str
	position_tolerance_m: float = 1e-3
	orientation_tolerance_rad: float = 1e-2
	max_iterations: int = 100
	# Kinematic chain data, copied from RobotDescription so backends that build
	# their own model (e.g. IKPy) need not re-parse the URDF or resolve
	# package:// mesh URIs. Pinocchio ignores these and reads the URDF directly.
	root_link: str = ""
	joints: List[Dict[str, Any]] = field(default_factory=list)
	# Optional robot-specific IKFast solver module path (project-relative or absolute).
	ikfast_solver_path: str = ""


@dataclass
class IKSolveResult:
	"""Outcome of an :class:`IKSolveRequest`.

	``joint_values`` maps actuated joint name -> angle (radians) and is the
	canonical payload applied back onto ``RobotDescription.joint_positions``.
	"""

	success: bool
	joint_values: Dict[str, float] = field(default_factory=dict)
	message: str = ""


@runtime_checkable
class IKBackend(Protocol):
	"""Pluggable IK solver interface.

	Implementations must be safe to call from a worker thread and must not
	touch the scene graph; everything they need arrives in the request.
	"""

	def is_available(self) -> bool:
		"""True when the backend's dependencies are importable."""
		...

	def solve(self, request: IKSolveRequest) -> IKSolveResult:
		"""Solve a single IK query."""
		...

	def invalidate_cache(self, urdf_path: str) -> None:
		"""Drop any cached model state for the given URDF path."""
		...

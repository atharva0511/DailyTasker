from __future__ import annotations

import json
import shutil
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from PyQt6.QtGui import QColor

from MotionStudio.core.ecs.component import Component, get_component_class
from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.scene.scene import Scene
from MotionStudio.utils.ids import generate_uuid

PRESET_JSON_NAME = "preset.json"
PRESET_ASSETS_DIR = "assets"


def _serialize_color(color: QColor) -> List[int]:
	return [color.red(), color.green(), color.blue(), color.alpha()]


def _serialize_component(comp: Component) -> Dict[str, Any]:
	return {
		"type": getattr(comp, "type_name", comp.__class__.__name__),
		"data": comp.to_dict(),
	}


def _serialize_entity(entity: Entity, parent_id: Optional[str]) -> Dict[str, Any]:
	return {
		"id": entity.id,
		"name": entity.name,
		"parent_id": parent_id,
		"components": [_serialize_component(c) for c in entity.components],
	}


def save_scene(scene: Scene, path: str) -> None:
	"""
	Serialize the scene to JSON (.scn).
	"""
	flat: List[Dict[str, Any]] = []

	def visit(node: Entity, parent_id: Optional[str]) -> None:
		flat.append(_serialize_entity(node, parent_id))
		for child in node.children:
			visit(child, node.id)

	for root in scene.root_entities():
		visit(root, None)

	payload: Dict[str, Any] = {"entities": flat}
	try:
		payload["collision_matrix"] = scene.collision_system.matrix.to_dict()
	except Exception:
		pass
	try:
		payload["collision_backend"] = scene.collision_system.backend_id
	except Exception:
		pass

	with open(path, "w", encoding="utf-8") as f:
		json.dump(payload, f, indent=2)


def _iter_subtree(root: Entity):
	"""Yield ``root`` and all of its descendants in preorder."""
	yield root
	for child in root.children:
		yield from _iter_subtree(child)


def _collect_preset_assets(
	root: Entity, project_root: Optional[Path]
) -> Dict[str, Path]:
	"""
	Gather dependent files referenced by component path fields in the subtree.

	Walks every component on ``root`` and its descendants and inspects annotated
	fields: ``FilePath`` fields contribute a single file, ``FolderPath`` fields
	contribute every file beneath the directory. For each collected file a
	``<file>.materials.json`` sidecar is included when present.

	Returns a mapping of project-relative posix path -> absolute source path.
	Paths that resolve outside ``project_root`` (e.g. legacy absolute references)
	are skipped, since they cannot be restored at a project-relative location.
	"""
	assets: Dict[str, Path] = {}
	if project_root is None:
		return assets

	# Imported lazily to avoid a UI import at module load time (and any cycle).
	from MotionStudio.ui.inspector.metadata import FilePath, FolderPath
	from MotionStudio.ui.inspector.reflection import iter_editable_fields
	from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read

	proj = Path(project_root).resolve()

	def add_file(abs_path: Path) -> None:
		if not abs_path.is_file():
			return
		try:
			rel = abs_path.resolve().relative_to(proj)
		except ValueError:
			return
		assets[rel.as_posix()] = abs_path
		sidecar = abs_path.with_suffix(abs_path.suffix + ".materials.json")
		if sidecar.is_file():
			try:
				srel = sidecar.resolve().relative_to(proj)
				assets[srel.as_posix()] = sidecar
			except ValueError:
				pass

	for entity in _iter_subtree(root):
		for component in entity.components:
			try:
				specs = iter_editable_fields(component)
			except Exception:
				continue
			for spec in specs:
				is_file = any(isinstance(m, FilePath) for m in spec.metadata)
				is_folder = any(isinstance(m, FolderPath) for m in spec.metadata)
				if not (is_file or is_folder):
					continue
				try:
					value = spec.getter()
				except Exception:
					continue
				if not isinstance(value, str) or not value.strip():
					continue
				abs_str = resolve_mesh_path_for_read(proj, value)
				if not abs_str:
					continue
				abs_path = Path(abs_str)
				if is_file:
					add_file(abs_path)
				elif abs_path.is_dir():
					for f in abs_path.rglob("*"):
						if f.is_file():
							add_file(f)

	return assets


def save_entity_preset(
	root: Entity, path: str, project_root: Optional[Path] = None
) -> None:
	"""
	Serialize one entity and its entire child hierarchy to a self-contained ``.pre``.

	A ``.pre`` is a zip archive containing ``preset.json`` (the entity records,
	same shape as scene files; the root entry uses ``parent_id`` null) plus every
	dependent file under ``assets/<project-relative-path>``. When ``project_root``
	is provided, path-bearing component fields are scraped and bundled; otherwise
	only ``preset.json`` is written.
	"""
	flat: List[Dict[str, Any]] = []

	def visit(node: Entity, parent_id: Optional[str]) -> None:
		flat.append(_serialize_entity(node, parent_id))
		for child in node.children:
			visit(child, node.id)

	visit(root, None)
	out_path = Path(path)
	out_path.parent.mkdir(parents=True, exist_ok=True)

	assets: Dict[str, Path] = {}
	if project_root is not None:
		try:
			assets = _collect_preset_assets(root, project_root)
		except Exception:
			assets = {}

	preset_json = json.dumps({"entities": flat}, indent=2)
	with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
		zf.writestr(PRESET_JSON_NAME, preset_json)
		for relpath, abs_src in assets.items():
			try:
				zf.write(abs_src, f"{PRESET_ASSETS_DIR}/{relpath}")
			except OSError:
				pass


def read_preset_entities(path: str) -> Optional[List[Dict[str, Any]]]:
	"""
	Read the entity records from a ``.pre`` zip without extracting any assets.

	Used for lightweight validation/preview before instantiation. Returns the
	entities list, or ``None`` when the file is not a readable preset archive.
	"""
	p = Path(path)
	if not p.is_file() or not zipfile.is_zipfile(p):
		return None
	try:
		with zipfile.ZipFile(p, "r") as zf:
			raw = zf.read(PRESET_JSON_NAME).decode("utf-8")
		return json.loads(raw).get("entities", [])
	except Exception:
		return None


def _extract_preset_and_read(scene: Scene, path: str) -> List[Dict[str, Any]]:
	"""
	Open a ``.pre`` zip: extract bundled assets into the project and return entities.

	Each ``assets/<relpath>`` member is written to ``<project_root>/<relpath>``
	(parent dirs created, overwriting on conflict). A path-traversal guard skips
	any member that would resolve outside the project root. Returns the entity
	records read from ``preset.json`` (empty list on failure).
	"""
	p = Path(path)
	if not p.is_file() or not zipfile.is_zipfile(p):
		return []

	proj = scene.project_root
	proj_resolved = Path(proj).resolve() if proj is not None else None
	prefix = f"{PRESET_ASSETS_DIR}/"

	with zipfile.ZipFile(p, "r") as zf:
		if proj_resolved is not None:
			for name in zf.namelist():
				if not name.startswith(prefix) or name.endswith("/"):
					continue
				rel = name[len(prefix):]
				if not rel:
					continue
				dest = (proj_resolved / rel).resolve()
				try:
					dest.relative_to(proj_resolved)
				except ValueError:
					continue
				dest.parent.mkdir(parents=True, exist_ok=True)
				with zf.open(name) as src, open(dest, "wb") as out:
					shutil.copyfileobj(src, out)
		try:
			raw = zf.read(PRESET_JSON_NAME).decode("utf-8")
		except KeyError:
			return []

	try:
		return json.loads(raw).get("entities", [])
	except Exception:
		return []


def _remap_id_strings(obj: Any, old_to_new: Dict[str, str]) -> Any:
	"""Recursively replace entity id strings (for component refs and nested data)."""
	if isinstance(obj, dict):
		return {k: _remap_id_strings(v, old_to_new) for k, v in obj.items()}
	if isinstance(obj, list):
		return [_remap_id_strings(v, old_to_new) for v in obj]
	if isinstance(obj, str) and obj in old_to_new:
		return old_to_new[obj]
	return obj


def load_entity_preset(scene: Scene, path: str, attach_under: Optional[Entity]) -> List[Entity]:
	"""
	Load entities from a .pre file created by save_entity_preset.

	New entity ids are generated so the preset can be instantiated multiple times.
	The former root of the preset (parent_id was null in the file) is parented under
	``attach_under``, or becomes a scene root if ``attach_under`` is None.

	Returns the new root entity (first in preorder) as a single-element list, or [] on failure.
	"""
	entities_flat: List[Dict[str, Any]] = _extract_preset_and_read(scene, path)
	if not entities_flat:
		return []

	old_ids = [str(e.get("id", "")) for e in entities_flat]
	if any(not oid for oid in old_ids):
		return []
	old_to_new: Dict[str, str] = {oid: generate_uuid() for oid in old_ids}

	remapped: List[Dict[str, Any]] = []
	for entry in entities_flat:
		oid = str(entry.get("id", ""))
		remapped.append(
			{
				"id": old_to_new[oid],
				"name": entry.get("name", "Entity"),
				"parent_id": None
				if entry.get("parent_id") is None
				else old_to_new[str(entry["parent_id"])],
				"components": [
					{
						"type": c.get("type"),
						"data": _remap_id_strings(c.get("data", {}), old_to_new),
					}
					for c in entry.get("components", [])
				],
			}
		)

	id_to_entity: Dict[str, Entity] = {}
	pending_parents: List[tuple[Entity, Optional[str], bool]] = []

	for idx, entry in enumerate(remapped):
		ent = scene.create_entity(entry.get("name", "Entity"), None, entity_id=entry.get("id"))
		id_to_entity[ent.id] = ent
		for c in entry.get("components", []):
			type_name = c.get("type")
			comp_cls = get_component_class(type_name) if type_name else None
			if comp_cls is None:
				continue
			try:
				comp = comp_cls.from_dict(c.get("data", {}))
			except Exception:
				continue
			ent.add_component(comp)
		is_preset_root = idx < len(entities_flat) and entities_flat[idx].get("parent_id") is None
		pending_parents.append((ent, entry.get("parent_id"), is_preset_root))

	for ent, parent_id_new, is_preset_root in pending_parents:
		if is_preset_root:
			scene.reparent(ent, attach_under)
		else:
			parent = id_to_entity.get(parent_id_new) if parent_id_new else None
			scene.reparent(ent, parent)

	_resolve_component_references(scene, id_to_entity)

	for ent in id_to_entity.values():
		try:
			scene.events.entity_changed.emit(ent.id)
		except Exception:
			pass

	root_new_id = remapped[0]["id"]
	root_ent = id_to_entity.get(root_new_id)
	return [root_ent] if root_ent is not None else []


def load_scene_json(path: str) -> Dict[str, Any]:
	"""Read and parse a scene ``.scn`` file (safe to call from a worker thread)."""
	with open(path, "r", encoding="utf-8") as f:
		return json.load(f)


def apply_scene_data(scene: Scene, data: Dict[str, Any]) -> None:
	"""
	Clear the current scene and instantiate entities/components from parsed JSON.
	Must run on the main thread (mutates ``Scene`` and emits ECS events).
	"""
	entities_flat: List[Dict[str, Any]] = data.get("entities", [])

	# Clear existing
	for ent in list(scene.entities()):
		scene.delete_entity(ent)
	# Clear the collision matrix so stale disabled pairs from the previous scene
	# don't leak into the loaded scene. Entity ids from the loaded file will be
	# applied below.
	try:
		scene.collision_system.matrix.clear()
	except Exception:
		pass

	id_to_entity: Dict[str, Entity] = {}
	pending_parents: List[tuple[Entity, Optional[str]]] = []

	# Instantiate entities and components
	for entry in entities_flat:
		ent = scene.create_entity(entry.get("name", "Entity"), None, entity_id=entry.get("id"))
		id_to_entity[ent.id] = ent
		for c in entry.get("components", []):
			type_name = c.get("type")
			comp_cls = get_component_class(type_name) if type_name else None
			if comp_cls is None:
				continue
			comp = comp_cls.from_dict(c.get("data", {}))
			ent.add_component(comp)
		pending_parents.append((ent, entry.get("parent_id")))

	# Rebuild parenting
	for ent, parent_id in pending_parents:
		parent = id_to_entity.get(parent_id) if parent_id else None
		scene.reparent(ent, parent)

	# Phase 2: Resolve Component references (entity_id -> Component)
	# Now that all entities and components are loaded, we can resolve Component references
	_resolve_component_references(scene, id_to_entity)

	# Restore the collision enable-matrix after entities exist so purge-on-remove
	# semantics don't strip entries we just loaded.
	try:
		scene.collision_system.matrix.from_dict(data.get("collision_matrix", {}))
	except Exception:
		pass
	try:
		from MotionStudio.core.scene.collision_backends import normalize_backend_id

		scene.collision_system.set_backend_id(
			normalize_backend_id(data.get("collision_backend", "fcl"))
		)
	except Exception:
		pass

	# Notify listeners that entities are ready so visuals (meshes) can be created
	for ent in id_to_entity.values():
		try:
			scene.events.entity_changed.emit(ent.id)
		except Exception:
			pass

	_post_load_robot_kinematics(scene)
	_post_load_collision_matrix(scene)


def load_scene(scene: Scene, path: str) -> None:
	"""Load a scene file (parse + apply on the calling thread)."""
	apply_scene_data(scene, load_scene_json(path))


def _post_load_collision_matrix(scene: Scene) -> None:
	"""Prune collision matrix entries for groups with no registered colliders."""
	try:
		from MotionStudio.core.robot.collision_groups import registered_collision_group_names

		scene.collision_system.matrix.prune_orphan_groups(registered_collision_group_names(scene))
	except Exception:
		pass


def _post_load_robot_kinematics(scene: Scene) -> None:
	"""Resolve URDF link entity ids and apply FK after scene load."""
	try:
		from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
		from MotionStudio.core.robot.robot_kinematics import resolve_link_entity_ids, update_robot_fk

		for ent in scene.entities():
			rd = ent.get_component(RobotDescriptionComponent)
			if rd is None:
				continue
			resolve_link_entity_ids(rd)
			update_robot_fk(rd)
			if rd.package_folder.strip():
				try:
					from MotionStudio.core.robot.robot_mesh_sync import reload_robot_link_meshes

					reload_robot_link_meshes(rd)
				except Exception:
					pass
	except Exception:
		pass


def _resolve_component_references(scene: Scene, id_to_entity: Dict[str, Entity]) -> None:
	"""
	Resolve Component reference fields from entity_id strings to Component instances.
	This is called after all entities and components are loaded.
	"""
	from typing import get_origin, get_args
	from MotionStudio.core.ecs.component import Component
	from MotionStudio.ui.inspector.reflection import iter_editable_fields
	import typing
	
	for entity in scene.entities():
		for component in entity.components:
			# Use reflection to find Component reference fields
			for spec in iter_editable_fields(component):
				field_name = spec.name
				field_type = spec.typ
				
				# Check if this is a Component reference field (Optional[ComponentType])
				origin = get_origin(field_type) if hasattr(typing, 'get_origin') else None
				if origin is typing.Union:
					args = get_args(field_type)
					# Extract inner type (first non-None type)
					inner_type = None
					for arg in args:
						if arg is not type(None):
							inner_type = arg
							break
					
					if inner_type is not None:
						# Check if inner type is a Component subclass
						try:
							if issubclass(inner_type, Component):
								# This is a Component reference field
								# Get current value (should be entity_id string or None)
								current_value = spec.getter()
								
								# If it's a string (entity_id), resolve it to Component
								if isinstance(current_value, str):
									target_entity = id_to_entity.get(current_value)
									if target_entity is not None:
										# Find the component of the expected type on the target entity
										target_component = target_entity.get_component(inner_type)
										if target_component is not None:
											# Resolve: set the Component reference
											if spec.setter is not None:
												spec.setter(target_component)
										else:
											# Entity exists but doesn't have the component - set to None
											if spec.setter is not None:
												spec.setter(None)
									else:
										# Entity doesn't exist - set to None
										if spec.setter is not None:
											spec.setter(None)
								elif current_value is None:
									# Already None, leave as-is
									pass
								# If it's already a Component, leave it as-is
						except (TypeError, AttributeError):
							# Not a Component type, skip
							pass



from __future__ import annotations
import math
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Type, TypeVar
from PyQt6.QtGui import QVector3D, QQuaternion, QMatrix4x4


_F = TypeVar("_F", bound="Feature")

# Registry for polymorphic feature loading
_FEATURE_REGISTRY: Dict[str, Type["Feature"]] = {}

def register_feature(cls: Type[_F]) -> Type[_F]:
    _FEATURE_REGISTRY[cls.__name__] = cls
    return cls

def get_feature_class(name: str) -> Optional[Type["Feature"]]:
    return _FEATURE_REGISTRY.get(name)

class Waypoint:
    """Stores position and rotation for a single path point."""
    def __init__(self, position: QVector3D, rotation: QQuaternion):
        self.position = position
        self.rotation = rotation

    def to_dict(self) -> Dict[str, Any]:
        return {
            "position": [self.position.x(), self.position.y(), self.position.z()],
            "rotation": [self.rotation.scalar(), self.rotation.x(), self.rotation.y(), self.rotation.z()]
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Waypoint:
        pos = data.get("position", [0.0, 0.0, 0.0])
        rot = data.get("rotation", [1.0, 0.0, 0.0, 0.0])
        return cls(
            QVector3D(pos[0], pos[1], pos[2]),
            QQuaternion(rot[0], rot[1], rot[2], rot[3])
        )

class Feature(ABC):
    """Base class for a sequential path feature (Line, Arc, etc.)"""
    def __init__(self):
        self.waypoints: List[Waypoint] = []
        # Raw picked coordinates in the entity's LOCAL frame. Line = [start, end],
        # Arc = [start, end, mid]. Replaces the old vertex_ids indirection so
        # segments survive mesh edits and correctly follow reparented entities.
        self.local_points: List[QVector3D] = []
        self.axial_offset: float = 0.0
        self.radial_offset: float = 0.0
        self.speed_multiplier: float = 1.0
        self.cnt_radius: float = 0.0

    @abstractmethod
    def generate_waypoints(self, points: Any, global_offsets: Dict[str, float]) -> List[Waypoint]:
        """
        Calculates waypoints from the segment's stored raw ``local_points`` and
        parameters. The ``points`` / ``global_offsets`` arguments are kept for
        API stability with legacy callers (e.g. path_bridge, waypoint_gizmo,
        ConvertFeatureToCustomCommand) but are unused by segments that store
        their own coordinates directly.
        """
        pass

    def _base_dict(self) -> Dict[str, Any]:
        return {
            "local_points": [[p.x(), p.y(), p.z()] for p in self.local_points],
            "axial_offset": self.axial_offset,
            "radial_offset": self.radial_offset,
            "speed_multiplier": self.speed_multiplier,
            "cnt_radius": self.cnt_radius,
        }

    def _load_base_dict(self, data: Dict[str, Any]) -> None:
        raw_points = data.get("local_points")
        if raw_points is None:
            # Legacy scenes stored vertex indices into the mesh. We cannot
            # resolve them here (no mesh reference) so the segment loads empty
            # and its slot in the Inspector lets the user delete or rebuild it.
            if data.get("vertex_ids"):
                print(
                    "[Path] Warning: dropping legacy 'vertex_ids' on segment (no local_points found); "
                    "recreate the segment with the new tool.",
                    flush=True,
                )
            self.local_points = []
        else:
            self.local_points = [
                QVector3D(float(p[0]), float(p[1]), float(p[2])) for p in raw_points
            ]
        self.axial_offset = data.get("axial_offset", 0.0)
        self.radial_offset = data.get("radial_offset", 0.0)
        self.speed_multiplier = float(data.get("speed_multiplier", 1.0))
        self.cnt_radius = float(data.get("cnt_radius", 0.0))

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        return self._base_dict()

    @classmethod
    @abstractmethod
    def from_dict(cls: Type[_F], data: Dict[str, Any]) -> _F:
        pass


def _quat_from_axes(x_axis: QVector3D, y_axis: QVector3D, z_axis: QVector3D) -> QQuaternion:
    """
    Build a quaternion whose local axes (X,Y,Z) map to the given world-space axes.
    The axes are expected to be (approximately) orthonormal.
    """
    # QMatrix4x4 is row-major indexed by (row, col).
    m = QMatrix4x4(
        x_axis.x(), y_axis.x(), z_axis.x(), 0.0,
        x_axis.y(), y_axis.y(), z_axis.y(), 0.0,
        x_axis.z(), y_axis.z(), z_axis.z(), 0.0,
        0.0,      0.0,      0.0,      1.0,
    )
    return QQuaternion.fromRotationMatrix(m.normalMatrix())

def _find_circle_center(p0: QVector3D, p1: QVector3D, p2: QVector3D) -> tuple[Optional[QVector3D], float, Optional[QVector3D], Optional[QVector3D]]:
    """
    Finds the center and radius of a circle passing through 3 points.
    Returns (center, radius, u_axis, v_axis) where u, v are orthogonal in the circle plane.
    """
    v1 = p1 - p0
    v2 = p2 - p0
    normal = QVector3D.crossProduct(v1, v2)
    if normal.length() < 1e-6:
        return None, 0.0, None, None
    normal.normalize()

    # Perpendicular bisectors intersection
    # midpoints
    m1 = (p0 + p2) * 0.5
    m2 = (p2 + p1) * 0.5
    
    # bisector directions
    d1 = p2 - p0
    b1 = QVector3D.crossProduct(normal, d1).normalized()
    
    d2 = p1 - p2
    b2 = QVector3D.crossProduct(normal, d2).normalized()

    # Intersection of lines m1 + t*b1 and m2 + s*b2
    # s * (b2 x b1) = (m1 - m2) x b1
    denom = QVector3D.crossProduct(b2, b1)
    if denom.length() < 1e-6:
        return None, 0.0, None, None
        
    numerator = QVector3D.crossProduct((m1 - m2), b1)
    s = numerator.length() / denom.length()
    if QVector3D.dotProduct(numerator, denom) < 0:
        s = -s
    
    center = m2 + b2 * s
    radius = (p0 - center).length()
    
    u = (p0 - center).normalized()
    v = QVector3D.crossProduct(normal, u).normalized()
    
    return center, radius, u, v


@register_feature
class TwoPointLineFeature(Feature):
    def generate_waypoints(self, points: Any, global_offsets: Dict[str, float]) -> List[Waypoint]:
        if len(self.local_points) < 2:
            return []

        p0 = QVector3D(self.local_points[0])
        p1 = QVector3D(self.local_points[1])

        direction = (p1 - p0).normalized()
        # Axial offset: slide along direction
        # Radial offset: slide along a local "up" (simplified to world Z for now)
        axial = self.axial_offset
        radial = self.radial_offset
        
        up = QVector3D(0, 0, 1)
        if abs(QVector3D.dotProduct(direction, up)) > 0.99:
            up = QVector3D(0, 1, 0)
        side = QVector3D.crossProduct(up, direction).normalized()
        local_up = QVector3D.crossProduct(direction, side).normalized()
        
        offset_vec = direction * axial + local_up * radial
        
        # Orientation: X along path, Z as local up
        x_axis = direction.normalized()
        z_axis = local_up.normalized()
        y_axis = QVector3D.crossProduct(z_axis, x_axis).normalized()
        # Re-orthonormalize Z in case up wasn't perfectly orthogonal
        z_axis = QVector3D.crossProduct(x_axis, y_axis).normalized()
        rotation = _quat_from_axes(x_axis, y_axis, z_axis)
        
        self.waypoints = [
            Waypoint(p0 + offset_vec, rotation),
            Waypoint(p1 + offset_vec, rotation)
        ]
        return self.waypoints

    def to_dict(self) -> Dict[str, Any]:
        return self._base_dict()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> TwoPointLineFeature:
        inst = cls()
        inst._load_base_dict(data)
        return inst

@register_feature
class SinglePointFeature(Feature):
    """
    Single point feature that creates a waypoint at a picked vertex on the mesh.
    The waypoint's Z-axis is aligned with the surface normal (averaged from the
    vertex's adjacent faces).

    Position and normal are stored in the owning entity's LOCAL frame so the
    segment moves with the entity and correctly follows reparented hierarchies.
    """
    def __init__(self):
        super().__init__()
        self.local_position: QVector3D = QVector3D(0, 0, 0)
        self.local_normal: QVector3D = QVector3D(0, 0, 1)

    def generate_waypoints(self, points: Any, global_offsets: Dict[str, float]) -> List[Waypoint]:
        """
        Generate a single waypoint at the stored local position with Z-axis
        aligned to the stored local normal.
        """
        axial = self.axial_offset
        radial = self.radial_offset

        normal = self.local_normal.normalized()

        # For radial offset, we need a perpendicular direction. Use a default
        # "up" direction and project it onto the plane perpendicular to normal.
        default_up = QVector3D(0, 0, 1)
        if abs(QVector3D.dotProduct(normal, default_up)) > 0.99:
            default_up = QVector3D(0, 1, 0)

        radial_dir = QVector3D.crossProduct(normal, default_up).normalized()
        if radial_dir.length() < 1e-6:
            radial_dir = QVector3D(1, 0, 0)
            if abs(QVector3D.dotProduct(normal, radial_dir)) > 0.99:
                radial_dir = QVector3D(0, 1, 0)
            radial_dir = (radial_dir - normal * QVector3D.dotProduct(radial_dir, normal)).normalized()

        offset_vec = normal * axial + radial_dir * radial
        position = self.local_position + offset_vec

        # Orientation: Z along normal, X in the perpendicular plane.
        z_axis = normal.normalized()

        if abs(radial) > 1e-6:
            x_axis = radial_dir.normalized()
        else:
            x_axis = (default_up - normal * QVector3D.dotProduct(default_up, normal)).normalized()
            if x_axis.length() < 1e-6:
                x_axis = QVector3D(1, 0, 0)
                x_axis = (x_axis - normal * QVector3D.dotProduct(x_axis, normal)).normalized()

        y_axis = QVector3D.crossProduct(z_axis, x_axis).normalized()
        x_axis = QVector3D.crossProduct(y_axis, z_axis).normalized()

        rotation = _quat_from_axes(x_axis, y_axis, z_axis)

        self.waypoints = [Waypoint(position, rotation)]
        return self.waypoints

    def to_dict(self) -> Dict[str, Any]:
        d = self._base_dict()
        d["local_position"] = [self.local_position.x(), self.local_position.y(), self.local_position.z()]
        d["local_normal"] = [self.local_normal.x(), self.local_normal.y(), self.local_normal.z()]
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SinglePointFeature":
        inst = cls()
        inst._load_base_dict(data)
        # Prefer the new local_* keys; fall back to legacy world_* keys and
        # reinterpret them as local (see plan's backwards-compat notes).
        pos_data = data.get("local_position", data.get("world_position", [0.0, 0.0, 0.0]))
        normal_data = data.get("local_normal", data.get("world_normal", [0.0, 0.0, 1.0]))
        inst.local_position = QVector3D(float(pos_data[0]), float(pos_data[1]), float(pos_data[2]))
        inst.local_normal = QVector3D(float(normal_data[0]), float(normal_data[1]), float(normal_data[2]))
        if inst.local_normal.length() < 1e-6:
            inst.local_normal = QVector3D(0, 0, 1)
        inst.local_normal.normalize()
        return inst

@register_feature
class ThreePointArcFeature(Feature):
    def __init__(self):
        super().__init__()
        self.density_multiplier: float = 1.0
        self.radial_rotation: float = 0.0  # Rotation around radial vector (degrees)
        self.tangent_rotation: float = 0.0  # Rotation around tangent vector (degrees)

    def generate_waypoints(self, points: Any, global_offsets: Dict[str, float]) -> List[Waypoint]:
        if len(self.local_points) < 3:
            return []

        p0 = QVector3D(self.local_points[0])  # Start
        p1 = QVector3D(self.local_points[1])  # End
        p2 = QVector3D(self.local_points[2])  # Mid

        center, radius, u, v = _find_circle_center(p0, p1, p2)
        if center is None:
            # Fallback to linear if arc fails
            return []

        # Find angles of P0, P2, P1 in circle plane
        def get_angle(p):
            vec = (p - center)
            return math.atan2(QVector3D.dotProduct(vec, v), QVector3D.dotProduct(vec, u))

        a0 = get_angle(p0)
        a2 = get_angle(p2)
        a1 = get_angle(p1)

        # Choose CW vs CCW sweep such that the arc from a0 to a1 passes through a2.
        # This prevents "wrap around" where the sweep accidentally goes beyond a full revolution.
        two_pi = 2.0 * math.pi

        def _ccw_delta(fr: float, to: float) -> float:
            return (to - fr) % two_pi  # [0, 2pi)

        def _between_ccw(fr: float, mid: float, to: float) -> bool:
            d_mid = _ccw_delta(fr, mid)
            d_to = _ccw_delta(fr, to)
            return d_mid <= d_to + 1e-9

        span_ccw = _ccw_delta(a0, a1)          # [0, 2pi)
        span_cw = span_ccw - two_pi            # (-2pi, 0]

        # If start == end, a 3-point arc would be a full circle; avoid generating a wrap-around path.
        if abs(span_ccw) < 1e-9:
            return []

        # Pick the direction whose sweep contains the mid point.
        if _between_ccw(a0, a2, a1):
            span = span_ccw
        else:
            span = span_cw
        # Determine number of steps (simplified density)
        steps = max(2, int(10 * self.density_multiplier * (abs(span) / math.pi)))
        
        self.waypoints = []
        axial = self.axial_offset
        radial = self.radial_offset
        
        normal = QVector3D.crossProduct(u, v).normalized()

        for i in range(steps + 1):
            t = i / steps
            angle = a0 + t * span
            
            # Position on circle
            pos_circle = center + u * math.cos(angle) * radius + v * math.sin(angle) * radius
            
            # Local coordinate system at point
            # Tangent must follow traversal direction; if sweep is CW (negative), flip tangent.
            tangent = (-u * math.sin(angle) + v * math.cos(angle))
            if span < 0.0:
                tangent = -tangent
            tangent = tangent.normalized()
            # Radial is pointing away from center (or towards depending on offset sign)
            rad_dir = (pos_circle - center).normalized()
            
            # Apply offsets
            pos = pos_circle + normal * axial + rad_dir * radial
            
            # Orientation: X along tangent, Z along radial (outward)
            x_axis = tangent.normalized()
            z_axis = rad_dir.normalized()
            y_axis = QVector3D.crossProduct(z_axis, x_axis).normalized()
            # Re-orthonormalize Z to ensure a stable frame
            z_axis = QVector3D.crossProduct(x_axis, y_axis).normalized()
            
            # Start with base rotation (X=tangent, Z=radial)
            rotation = _quat_from_axes(x_axis, y_axis, z_axis)
            
            # Apply radial rotation around the radial axis (the line from center to waypoint)
            # The radial axis is rad_dir in world space, which is the Z-axis in the base local frame.
            # We want to rotate the entire frame around this axis.
            if abs(self.radial_rotation) > 1e-6:
                # Rotate around local Z-axis (which is rad_dir in world space)
                # This rotates X and Y around Z, keeping Z fixed
                radial_rot = QQuaternion.fromAxisAndAngle(QVector3D(0, 0, 1), self.radial_rotation)
                # Apply in local frame: rotation * radial_rot applies radial_rot in rotation's local frame
                rotation = rotation * radial_rot
            
            # Apply tangent rotation around the tangent axis (tangent to circle at waypoint)
            # The tangent axis is tangent in world space, which was the X-axis in the base local frame.
            # After radial rotation, the X-axis has changed, but we want to rotate around the
            # original tangent direction in world space.
            if abs(self.tangent_rotation) > 1e-6:
                # Rotate around the original tangent vector in world space
                # This rotates Y and Z around the original tangent, keeping tangent fixed
                tangent_rot = QQuaternion.fromAxisAndAngle(tangent, self.tangent_rotation)
                # Apply in world space: tangent_rot * rotation applies rotation first, then tangent_rot
                # This rotates the frame around the original tangent direction
                rotation = tangent_rot * rotation
            
            self.waypoints.append(Waypoint(pos, rotation))
            
        return self.waypoints

    def to_dict(self) -> Dict[str, Any]:
        d = self._base_dict()
        d["density_multiplier"] = self.density_multiplier
        d["radial_rotation"] = self.radial_rotation
        d["tangent_rotation"] = self.tangent_rotation
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ThreePointArcFeature:
        inst = cls()
        inst._load_base_dict(data)
        inst.density_multiplier = data.get("density_multiplier", 1.0)
        inst.radial_rotation = data.get("radial_rotation", 0.0)
        inst.tangent_rotation = data.get("tangent_rotation", 0.0)
        return inst

@register_feature
class CustomFeature(Feature):
    """
    Custom feature that stores waypoints directly without parametric generation.
    Created by converting existing features to allow direct waypoint editing.
    """
    def __init__(self):
        super().__init__()
        # Custom features store waypoints directly and don't use local_points
        # or offsets (they're free-form after conversion from a parametric segment).
        self.local_points = []
        self.axial_offset = 0.0
        self.radial_offset = 0.0
    
    def generate_waypoints(self, points: Any, global_offsets: Dict[str, float]) -> List[Waypoint]:
        """
        Returns stored waypoints directly (no generation needed).
        """
        return self.waypoints
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize custom feature with waypoints."""
        return {
            "waypoints": [wp.to_dict() for wp in self.waypoints],
            "speed_multiplier": self.speed_multiplier,
            "cnt_radius": self.cnt_radius,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CustomFeature":
        """Deserialize custom feature from waypoint data."""
        inst = cls()
        waypoints_data = data.get("waypoints", [])
        inst.waypoints = [Waypoint.from_dict(wp_data) for wp_data in waypoints_data]
        inst.speed_multiplier = float(data.get("speed_multiplier", 1.0))
        inst.cnt_radius = float(data.get("cnt_radius", 0.0))
        return inst


# User-facing segment type labels (path is built from ordered segments).
SEGMENT_DISPLAY_NAMES: Dict[str, str] = {
    "TwoPointLineFeature": "Two-Point Line Segment",
    "ThreePointArcFeature": "Three-Point Arc Segment",
    "SinglePointFeature": "Single-Point Segment",
    "CustomFeature": "Custom Segment",
}


def segment_display_name(segment: Feature) -> str:
    """Human-readable segment type label for Inspector and tooling."""
    key = segment.__class__.__name__
    return SEGMENT_DISPLAY_NAMES.get(key, key.replace("Feature", "Segment"))


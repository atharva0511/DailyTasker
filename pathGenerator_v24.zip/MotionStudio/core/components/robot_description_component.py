from __future__ import annotations

from typing import Annotated, Any, Dict, List, Optional

from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import FilePath,Group, FolderPath, ReadOnly, Tooltip, inspector_button


@register_component
class RobotDescriptionComponent(Component):
	"""
	Full URDF robot model on the robot root entity.

	Stores kinematic/inertial data for FK, IK, and dynamics. Joint angles are in radians.
	"""

	type_name = "RobotDescription"

	urdf_path: Annotated[str, FilePath("URDF (*.urdf);;All Files (*.*)"), Group("Robot Details"), ReadOnly(), Tooltip("Project-relative URDF path")]
	robot_name: Annotated[str, ReadOnly(), Tooltip("Robot name from URDF")]
	package_name: Annotated[
		str,
		ReadOnly(),
		Tooltip("ROS package name from package:// URIs (e.g. ur_description)"),
		Group("Robot Details"),
	]
	package_folder: Annotated[
		str,
		FolderPath(dialog_title="Select ROS package folder"),
		Tooltip(
			"Filesystem path to the ROS package root (the folder that contains meshes/). "
			"Used to resolve package:// paths from the URDF. Set this then click Reload Meshes."
		),
		Group("Robot Details"),
	]
	root_link: Annotated[str, ReadOnly(), Tooltip("Kinematic root link name"), Group("Robot Details")]
	tool_link: Annotated[str, ReadOnly(), Tooltip("Tool / TCP link name for IK"), Group("Robot Details")]
	ikfast_solver_path: Annotated[
		str,
		FilePath("Python Files (*.py);;All Files (*.*)"),
		Tooltip("Optional project-relative IKFast solver Python module path."),
		Group("Robot Details"),
	]

	def __init__(
		self,
		urdf_path: str = "",
		robot_name: str = "",
		package_name: str = "",
		package_folder: str = "",
		root_link: str = "base_link",
		tool_link: str = "tool0",
		ikfast_solver_path: str = "",
	) -> None:
		self.urdf_path = str(urdf_path or "")
		self.robot_name = str(robot_name or "")
		self.package_name = str(package_name or "")
		self.package_folder = str(package_folder or "")
		self.root_link = str(root_link or "base_link")
		self.tool_link = str(tool_link or "tool0")
		self.ikfast_solver_path = str(ikfast_solver_path or "")
		self._joint_positions: Dict[str, float] = {}
		self._links: List[Dict[str, Any]] = []
		self._joints: List[Dict[str, Any]] = []
		self._transmissions: List[Dict[str, Any]] = []
		self._actuated_joint_names: List[str] = []
		self._fk_updating = False
		# Set by RobotIKSystem while it applies an IK solution (it already runs
		# FK), so on_entity_changed must not re-run FK and fight the solver.
		self._ik_updating = False

	@property
	def joint_positions(self) -> Dict[str, float]:
		return self._joint_positions

	@joint_positions.setter
	def joint_positions(self, value: Dict[str, float]) -> None:
		self._joint_positions = dict(value) if value is not None else {}

	@property
	def links(self) -> List[Dict[str, Any]]:
		return self._links

	@links.setter
	def links(self, value: List[Dict[str, Any]]) -> None:
		self._links = list(value) if value is not None else []

	@property
	def joints(self) -> List[Dict[str, Any]]:
		return self._joints

	@joints.setter
	def joints(self, value: List[Dict[str, Any]]) -> None:
		self._joints = list(value) if value is not None else []

	@property
	def transmissions(self) -> List[Dict[str, Any]]:
		return self._transmissions

	@transmissions.setter
	def transmissions(self, value: List[Dict[str, Any]]) -> None:
		self._transmissions = list(value) if value is not None else []

	@property
	def actuated_joint_names(self) -> List[str]:
		return self._actuated_joint_names

	@actuated_joint_names.setter
	def actuated_joint_names(self, value: List[str]) -> None:
		self._actuated_joint_names = list(value) if value is not None else []

	def to_dict(self) -> Dict[str, Any]:
		return {
			"urdf_path": self.urdf_path,
			"robot_name": self.robot_name,
			"package_name": self.package_name,
			"package_folder": self.package_folder,
			"root_link": self.root_link,
			"tool_link": self.tool_link,
			"ikfast_solver_path": self.ikfast_solver_path,
			"joint_positions": dict(self._joint_positions),
			"links": list(self._links),
			"joints": list(self._joints),
			"transmissions": list(self._transmissions),
			"actuated_joint_names": list(self._actuated_joint_names),
		}

	@classmethod
	def from_dict(cls, data: Dict[str, Any]) -> "RobotDescriptionComponent":
		inst = cls(
			urdf_path=str(data.get("urdf_path", "")),
			robot_name=str(data.get("robot_name", "")),
			package_name=str(data.get("package_name", "")),
			package_folder=str(data.get("package_folder", "")),
			root_link=str(data.get("root_link", "base_link")),
			tool_link=str(data.get("tool_link", "tool0")),
			ikfast_solver_path=str(data.get("ikfast_solver_path", "")),
		)
		jp = data.get("joint_positions", {})
		if isinstance(jp, dict):
			inst._joint_positions = {str(k): float(v) for k, v in jp.items()}
		inst._links = list(data.get("links", []))
		inst._joints = list(data.get("joints", []))
		inst._transmissions = list(data.get("transmissions", []))
		inst._actuated_joint_names = list(data.get("actuated_joint_names", []))
		return inst

	def on_entity_changed(self) -> None:
		if self._fk_updating or self._ik_updating:
			return
		try:
			from MotionStudio.core.robot.robot_kinematics import update_robot_fk

			update_robot_fk(self)
		except Exception:
			pass

	def find_link_entity_id(self, link_name: str) -> Optional[str]:
		"""Resolve link entity id by name (walks robot subtree)."""
		entity = self.entity
		if entity is None:
			return None
		from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent

		def walk(e):
			ul = e.get_component(UrdfLinkComponent)
			if ul is not None and ul.link_name == link_name:
				return e.id
			for ch in e.children:
				found = walk(ch)
				if found:
					return found
			return None

		for child in entity.children:
			found = walk(child)
			if found:
				return found
		return walk(entity)

	def get_joint_record(self, joint_name: str) -> Optional[Dict[str, Any]]:
		for j in self.joints:
			if j.get("name") == joint_name:
				return j
		return None

	# @inspector_button("Reload Meshes", tooltip="Resolve package:// mesh paths and assign Mesh/Collider on all link entities")
	def reload_meshes(self) -> None:
		from MotionStudio.core.robot.robot_mesh_sync import reload_robot_link_meshes

		count = reload_robot_link_meshes(self)
		print(f"Reload Meshes: updated {count} link(s).", flush=True)

	@inspector_button("Reset Pose", tooltip="Set all actuated joints to zero and update FK")
	def reset_pose(self) -> None:
		for name in self.actuated_joint_names:
			self.joint_positions[name] = 0.0
		entity = self.entity
		scene = entity.scene if entity is not None else None
		ik_sys = getattr(scene, "robot_ik_system", None) if scene is not None else None
		if ik_sys is not None and entity is not None:
			# FK + optional Target snap under IK suppress (see RobotIKSystem).
			ik_sys.apply_fk_from_joints(entity)
			return
		from MotionStudio.core.robot.robot_kinematics import update_robot_fk

		update_robot_fk(self)

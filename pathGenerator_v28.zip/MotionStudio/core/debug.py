from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Callable, List, Optional, Sequence, Tuple, Union
import weakref

from PyQt6.QtGui import QColor, QQuaternion, QVector3D


Vec3Like = Union[QVector3D, Sequence[float]]
ColorLike = Union[QColor, Sequence[float]]


@dataclass(frozen=True)
class DebugLine:
	start: QVector3D
	end: QVector3D
	color_rgb: Tuple[float, float, float]
	width: float
	opacity: float = 1.0
	on_top: bool = True


@dataclass(frozen=True)
class DebugSphere:
	center: QVector3D
	radius: float
	color_rgb: Tuple[float, float, float]
	filled: bool
	opacity: float
	on_top: bool = True


@dataclass(frozen=True)
class DebugBoundingBox:
	center: QVector3D
	size: QVector3D
	color_rgb: Tuple[float, float, float]
	width: float
	opacity: float = 1.0
	on_top: bool = True


@dataclass(frozen=True)
class DebugAxes:
	origin: QVector3D
	length: float
	screen_space: bool
	rotation: Optional[Tuple[float, float, float, float]]
	width: float
	x_color_rgb: Tuple[float, float, float]
	y_color_rgb: Tuple[float, float, float]
	z_color_rgb: Tuple[float, float, float]
	on_top: bool = True


@dataclass(frozen=True)
class DebugPoint:
	position: QVector3D
	size: float
	screen_space: bool
	color_rgb: Tuple[float, float, float]
	opacity: float
	on_top: bool = True


@dataclass(frozen=True)
class DebugLabel:
	position: QVector3D
	text: str
	color_rgb: Tuple[float, float, float]
	font_size: int
	on_top: bool = True


@dataclass(frozen=True)
class DebugCone:
	base_center: QVector3D
	direction: QVector3D  # Normalized axis from base -> apex
	diameter: float       # ``size`` from the user; base circle diameter
	height: float         # Always 2 * diameter (enforced in Debug.draw_cone)
	color_rgb: Tuple[float, float, float]
	filled: bool
	opacity: float
	on_top: bool = True


@dataclass(frozen=True)
class DebugPolyline:
	points: Tuple[QVector3D, ...]
	color_rgb: Tuple[float, float, float]
	width: float
	closed: bool
	opacity: float = 1.0
	on_top: bool = True


class _DebugRuntime:
	def __init__(self) -> None:
		self._scene_ref: Optional[weakref.ReferenceType] = None
		self._request_render: Optional[Callable[[], None]] = None
		self._enabled: bool = True
		self._enabled_in_edit_mode: bool = True
		self._enabled_in_play_mode: bool = True
		self._lines: List[DebugLine] = []
		self._spheres: List[DebugSphere] = []
		self._boxes: List[DebugBoundingBox] = []
		self._axes: List[DebugAxes] = []
		self._points: List[DebugPoint] = []
		self._labels: List[DebugLabel] = []
		self._cones: List[DebugCone] = []
		self._polylines: List[DebugPolyline] = []
		self._in_render_pass: bool = False

	def begin_render_pass(self) -> None:
		self._in_render_pass = True

	def end_render_pass(self) -> None:
		self._in_render_pass = False

	def configure(self, *, scene=None, request_render: Optional[Callable[[], None]] = None) -> None:
		if scene is not None:
			self._scene_ref = weakref.ref(scene)
		self._request_render = request_render

	def set_enabled(self, enabled: bool) -> None:
		self._enabled = bool(enabled)
		if not self._enabled:
			self.clear()

	def set_mode_enabled(self, *, edit_mode: Optional[bool] = None, play_mode: Optional[bool] = None) -> None:
		if edit_mode is not None:
			self._enabled_in_edit_mode = bool(edit_mode)
		if play_mode is not None:
			self._enabled_in_play_mode = bool(play_mode)

	def enabled(self) -> bool:
		return self._enabled

	def enqueue_line(self, line: DebugLine) -> None:
		if not self._enabled:
			return
		self._lines.append(line)
		self._request_render_if_available()

	def enqueue_sphere(self, sphere: DebugSphere) -> None:
		if not self._enabled:
			return
		self._spheres.append(sphere)
		self._request_render_if_available()

	def enqueue_box(self, box: DebugBoundingBox) -> None:
		if not self._enabled:
			return
		self._boxes.append(box)
		self._request_render_if_available()

	def enqueue_axes(self, axes: DebugAxes) -> None:
		if not self._enabled:
			return
		self._axes.append(axes)
		self._request_render_if_available()

	def enqueue_point(self, point: DebugPoint) -> None:
		if not self._enabled:
			return
		self._points.append(point)
		self._request_render_if_available()

	def enqueue_label(self, label: DebugLabel) -> None:
		if not self._enabled:
			return
		self._labels.append(label)
		self._request_render_if_available()

	def enqueue_cone(self, cone: DebugCone) -> None:
		if not self._enabled:
			return
		self._cones.append(cone)
		self._request_render_if_available()

	def enqueue_polyline(self, polyline: DebugPolyline) -> None:
		if not self._enabled:
			return
		self._polylines.append(polyline)
		self._request_render_if_available()

	def clear(self) -> None:
		self._lines.clear()
		self._spheres.clear()
		self._boxes.clear()
		self._axes.clear()
		self._points.clear()
		self._labels.clear()
		self._cones.clear()
		self._polylines.clear()

	def consume_for_render(
		self,
	) -> Tuple[
		List[DebugLine],
		List[DebugSphere],
		List[DebugBoundingBox],
		List[DebugAxes],
		List[DebugPoint],
		List[DebugLabel],
		List[DebugCone],
		List[DebugPolyline],
	]:
		empty: Tuple[list, ...] = ([], [], [], [], [], [], [], [])
		if not self._enabled:
			self.clear()
			return empty  # type: ignore[return-value]
		scene = self._scene_ref() if self._scene_ref is not None else None
		is_playing = bool(getattr(getattr(scene, "_play_mode_manager", None), "is_playing", False))
		if (is_playing and not self._enabled_in_play_mode) or ((not is_playing) and not self._enabled_in_edit_mode):
			self.clear()
			return empty  # type: ignore[return-value]
		lines = self._lines
		spheres = self._spheres
		boxes = self._boxes
		axes_list = self._axes
		points = self._points
		labels = self._labels
		cones = self._cones
		polylines = self._polylines
		# one-frame semantics: draw calls must be re-issued each frame.
		self._lines = []
		self._spheres = []
		self._boxes = []
		self._axes = []
		self._points = []
		self._labels = []
		self._cones = []
		self._polylines = []
		return lines, spheres, boxes, axes_list, points, labels, cones, polylines

	def _request_render_if_available(self) -> None:
		if self._in_render_pass:
			return
		if self._request_render is None:
			return
		try:
			self._request_render()
		except Exception:
			pass


_runtime = _DebugRuntime()


def _vec3(v: Vec3Like) -> QVector3D:
	if isinstance(v, QVector3D):
		return QVector3D(v)
	if isinstance(v, Sequence) and len(v) >= 3:
		return QVector3D(float(v[0]), float(v[1]), float(v[2]))
	raise TypeError(f"Unsupported vector value: {v!r}")


def _quat_wxyz(q: Optional[QQuaternion]) -> Optional[Tuple[float, float, float, float]]:
	if q is None:
		return None
	return (
		float(q.scalar()),
		float(q.x()),
		float(q.y()),
		float(q.z()),
	)


def _rgb(c: ColorLike) -> Tuple[float, float, float]:
	if isinstance(c, QColor):
		r, g, b, _a = c.getRgbF()
		return float(r), float(g), float(b)
	if isinstance(c, Sequence) and len(c) >= 3:
		r = float(c[0])
		g = float(c[1])
		b = float(c[2])
		return max(0.0, min(1.0, r)), max(0.0, min(1.0, g)), max(0.0, min(1.0, b))
	raise TypeError(f"Unsupported color value: {c!r}")


class Debug:
	"""
	Unity-style debug helpers accessible from any component script.

	Usage:
	    from MotionStudio.core.debug import Debug
	    Debug.log("hello")
	    Debug.draw_line((0, 0, 0), (1, 0, 0))
	    Debug.draw_sphere((0, 0, 0), radius=0.05)
	"""

	@staticmethod
	def configure(*, scene=None, request_render: Optional[Callable[[], None]] = None) -> None:
		_runtime.configure(scene=scene, request_render=request_render)

	@staticmethod
	def set_enabled(enabled: bool) -> None:
		_runtime.set_enabled(enabled)

	@staticmethod
	def set_mode_enabled(*, edit_mode: Optional[bool] = None, play_mode: Optional[bool] = None) -> None:
		_runtime.set_mode_enabled(edit_mode=edit_mode, play_mode=play_mode)

	@staticmethod
	def is_enabled() -> bool:
		return _runtime.enabled()

	@staticmethod
	def clear() -> None:
		_runtime.clear()

	@staticmethod
	def log(message: object) -> None:
		ts = datetime.now().strftime("%H:%M:%S")
		print(f"[Debug {ts}] {message}", flush=True)

	@staticmethod
	def warning(message: object) -> None:
		ts = datetime.now().strftime("%H:%M:%S")
		print(f"[Debug {ts}] WARNING: {message}", flush=True)

	@staticmethod
	def error(message: object) -> None:
		ts = datetime.now().strftime("%H:%M:%S")
		print(f"[Debug {ts}] ERROR: {message}", flush=True)

	@staticmethod
	def draw_line(
		start: Vec3Like,
		end: Vec3Like,
		*,
		color: ColorLike = (1.0, 0.95, 0.2),
		width: float = 2.0,
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		_runtime.enqueue_line(
			DebugLine(
				start=_vec3(start),
				end=_vec3(end),
				color_rgb=_rgb(color),
				width=max(1.0, float(width)),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_ray(
		origin: Vec3Like,
		direction: Vec3Like,
		*,
		length: float = 1.0,
		color: ColorLike = (1.0, 0.95, 0.2),
		width: float = 2.0,
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		o = _vec3(origin)
		d = _vec3(direction)
		if d.lengthSquared() <= 1e-12:
			return
		d.normalize()
		end = o + d * float(length)
		Debug.draw_line(o, end, color=color, width=width, opacity=opacity, on_top=on_top)

	@staticmethod
	def draw_sphere(
		center: Vec3Like,
		*,
		radius: float = 0.05,
		color: ColorLike = (0.3, 0.85, 1.0),
		filled: bool = False,
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		_runtime.enqueue_sphere(
			DebugSphere(
				center=_vec3(center),
				radius=max(1e-4, float(radius)),
				color_rgb=_rgb(color),
				filled=bool(filled),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_bounding_box(
		center: Vec3Like,
		size: Vec3Like,
		*,
		color: ColorLike = (1.0, 0.95, 0.2),
		width: float = 2.0,
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		"""Draw an axis-aligned wireframe box. ``size`` is full width/height/depth."""
		s = _vec3(size)
		_runtime.enqueue_box(
			DebugBoundingBox(
				center=_vec3(center),
				size=QVector3D(max(1e-6, s.x()), max(1e-6, s.y()), max(1e-6, s.z())),
				color_rgb=_rgb(color),
				width=max(1.0, float(width)),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_axes(
		origin: Vec3Like,
		*,
		length: float = 1.0,
		screen_space: bool = False,
		rotation: Optional[QQuaternion] = None,
		width: float = 2.0,
		x_color: ColorLike = (1.0, 0.2, 0.2),
		y_color: ColorLike = (0.2, 1.0, 0.2),
		z_color: ColorLike = (0.2, 0.5, 1.0),
		on_top: bool = True,
	) -> None:
		"""
		Draw RGB XYZ axes from ``origin``. Optional ``rotation`` is local frame orientation.

		When ``screen_space`` is True, ``length`` is each axis arm length in **pixels**
		(constant on screen while orbiting). When False, ``length`` is world-space units.
		"""
		length_val = float(length)
		if screen_space:
			length_val = max(0.5, length_val)
		else:
			length_val = max(1e-6, length_val)
		_runtime.enqueue_axes(
			DebugAxes(
				origin=_vec3(origin),
				length=length_val,
				screen_space=bool(screen_space),
				rotation=_quat_wxyz(rotation),
				width=max(1.0, float(width)),
				x_color_rgb=_rgb(x_color),
				y_color_rgb=_rgb(y_color),
				z_color_rgb=_rgb(z_color),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_point(
		position: Vec3Like,
		*,
		size: float = 8.0,
		screen_space: bool = True,
		color: ColorLike = (1.0, 0.95, 0.2),
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		"""
		Draw a lightweight camera-facing filled disc.

		When ``screen_space`` is True (default), ``size`` is the disc **radius in pixels**
		(constant on screen while orbiting). When False, ``size`` is world-space radius.
		"""
		size_val = float(size)
		if screen_space:
			size_val = max(0.5, size_val)
		else:
			size_val = max(1e-4, size_val)
		_runtime.enqueue_point(
			DebugPoint(
				position=_vec3(position),
				size=size_val,
				screen_space=bool(screen_space),
				color_rgb=_rgb(color),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_label(
		position: Vec3Like,
		text: str,
		*,
		color: ColorLike = (1.0, 1.0, 1.0),
		font_size: int = 14,
		on_top: bool = True,
	) -> None:
		"""Draw billboard text at a 3D position (faces the camera each frame)."""
		_runtime.enqueue_label(
			DebugLabel(
				position=_vec3(position),
				text=str(text),
				color_rgb=_rgb(color),
				font_size=max(8, int(font_size)),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_cone(
		position: Vec3Like,
		direction: Vec3Like,
		*,
		size: float = 0.1,
		color: ColorLike = (0.3, 0.85, 1.0),
		filled: bool = True,
		opacity: float = 1.0,
		on_top: bool = True,
	) -> None:
		"""
		Draw a cone whose base circle is centered at ``position`` and whose axis is
		aligned along ``direction`` (apex pointing along +direction).

		``size`` is the base circle **diameter** in world units. Height is always
		locked at ``2 * size`` to keep cones visually consistent across call sites
		(useful for direction indicators / arrow heads).

		Behaves like :meth:`draw_sphere` for the shading options: ``filled=False``
		renders as wireframe, ``opacity`` is 0..1.
		"""
		d = _vec3(direction)
		if d.lengthSquared() <= 1e-12:
			return
		d.normalize()
		diameter = max(1e-6, float(size))
		_runtime.enqueue_cone(
			DebugCone(
				base_center=_vec3(position),
				direction=d,
				diameter=diameter,
				height=2.0 * diameter,
				color_rgb=_rgb(color),
				filled=bool(filled),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)

	@staticmethod
	def draw_polyline(
		points: Sequence[Vec3Like],
		*,
		color: ColorLike = (1.0, 0.95, 0.2),
		width: float = 2.0,
		opacity: float = 1.0,
		closed: bool = False,
		on_top: bool = True,
	) -> None:
		"""
		Draw a connected polyline through ``points`` (world space).

		``points`` may be any sequence of ``QVector3D`` or 3-number sequences.
		Needs at least two points (three if ``closed=True`` and you want a loop).
		When ``closed`` is True, an extra segment connects the last point back
		to the first. ``opacity`` is 0..1 (same as :meth:`draw_sphere`).
		"""
		if points is None:
			return
		parsed: List[QVector3D] = []
		for p in points:
			try:
				parsed.append(_vec3(p))
			except TypeError:
				continue
		if len(parsed) < 2:
			return
		_runtime.enqueue_polyline(
			DebugPolyline(
				points=tuple(parsed),
				color_rgb=_rgb(color),
				width=max(1.0, float(width)),
				closed=bool(closed),
				opacity=max(0.0, min(1.0, float(opacity))),
				on_top=bool(on_top),
			)
		)


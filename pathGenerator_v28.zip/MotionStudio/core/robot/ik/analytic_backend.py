"""Adapter for pre-generated ssik analytical IK modules."""

from __future__ import annotations

import math
import os
from importlib import util as importlib_util
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik._fk_verify import (
	forward_kinematics,
	joint_wrap_distance,
	pose_error,
)
from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult

# Cached call-style key per absolute solver path after the first successful call.
_CallStyle = str  # "ssik_max1" | "ssik_all" | "ssik_plain" | "ms_kwargs"


class AnalyticIKBackend:
	"""Adapter for pre-generated ssik analytical IK modules.

	Continuous teleop (default): requests the single nearest-to-seed branch via
	``max_solutions=1``, trusts ssik's FK closure, and skips multi-branch
	re-verification.

	Planner mode (``request.enumerate_all_solutions=True``): returns every
	branch, FK-verifies each against the request chain, and fills
	``IKSolveResult.all_solutions``.
	"""

	def __init__(self) -> None:
		# solver_path -> (mtime, module, solve_func)
		self._cache: Dict[str, Tuple[float, Any, Callable[..., Any]]] = {}
		# (solver_path, enumerate_all) -> call style that succeeded.
		# Keyed by mode so teleop's ``ssik_max1`` cache cannot starve planner
		# enumeration (which must use ``ssik_all`` / plain multi-solution calls).
		self._call_style: Dict[Tuple[str, bool], _CallStyle] = {}

	def is_available(self) -> bool:
		try:
			return importlib_util.find_spec("ssik") is not None
		except Exception:
			return False

	def invalidate_cache(self, urdf_path: str) -> None:
		# Analytic caches are keyed by solver module path, not URDF path.
		_ = urdf_path

	def _load_solver(self, solver_path: str) -> Optional[Tuple[str, Any, Callable[..., Any]]]:
		if not solver_path:
			return None
		path = os.path.abspath(solver_path)
		if not os.path.isfile(path):
			return None
		try:
			mtime = os.path.getmtime(path)
		except OSError:
			mtime = 0.0
		cached = self._cache.get(path)
		if cached is not None and cached[0] == mtime:
			return path, cached[1], cached[2]
		module_name = f"motionstudio_analytic_{abs(hash(path))}"
		spec = importlib_util.spec_from_file_location(module_name, path)
		if spec is None or spec.loader is None:
			return None
		module = importlib_util.module_from_spec(spec)
		spec.loader.exec_module(module)
		solve_fn = getattr(module, "solve", None) or getattr(module, "solve_ik", None)
		if not callable(solve_fn):
			return None
		self._cache[path] = (mtime, module, solve_fn)
		self._call_style.pop((path, True), None)
		self._call_style.pop((path, False), None)
		return path, module, solve_fn

	@staticmethod
	def _extract_q(item: Any) -> Optional[np.ndarray]:
		"""Normalize one solver return item into a 1-D joint vector."""
		if item is None:
			return None
		if hasattr(item, "q"):
			item = getattr(item, "q")
		if isinstance(item, dict):
			return None
		arr = np.asarray(item, dtype=np.float64).reshape(-1)
		if arr.size == 0:
			return None
		return arr

	@classmethod
	def _normalize_candidates(cls, raw: Any, joint_names: List[str]) -> List[Dict[str, float]]:
		if raw is None:
			return []
		candidates = raw if isinstance(raw, (list, tuple)) else [raw]
		out: List[Dict[str, float]] = []
		n = len(joint_names)
		for cand in candidates:
			if isinstance(cand, dict):
				mapped = {name: float(cand[name]) for name in joint_names if name in cand}
				if len(mapped) == n:
					out.append(mapped)
				continue
			q = cls._extract_q(cand)
			if q is None or q.size != n:
				continue
			out.append({name: float(v) for name, v in zip(joint_names, q.tolist())})
		return out

	def _call_solver(
		self,
		solver_path: str,
		solve_fn: Callable[..., Any],
		request: IKSolveRequest,
		*,
		enumerate_all: bool,
	) -> Any:
		from MotionStudio.core.robot.ik.ik_frames import project_to_se3

		# ssik measures full 4x4 Frobenius FK residual at ~1e-7; any residual
		# scale/shear in the goal (from scene matrices) yields an empty list
		# even when the same path is reachable on the physical arm / by ikpy.
		goal = project_to_se3(np.asarray(request.T_goal_base, dtype=np.float64))
		seed = np.asarray(request.q_seed, dtype=np.float64)
		joint_names = list(request.joint_names)

		def _ssik_max1() -> Any:
			return solve_fn(goal, q_seed=seed, max_solutions=1)

		def _ssik_all() -> Any:
			return solve_fn(goal, q_seed=seed)

		def _ssik_plain() -> Any:
			return solve_fn(goal)

		def _ms_kwargs() -> Any:
			return solve_fn(T_goal_base=goal, q_seed=seed, joint_names=joint_names)

		# Prefer styles that match the request mode; fall back through the rest.
		if enumerate_all:
			ordered: List[Tuple[_CallStyle, Callable[[], Any]]] = [
				("ssik_all", _ssik_all),
				("ssik_plain", _ssik_plain),
				("ms_kwargs", _ms_kwargs),
				("ssik_max1", _ssik_max1),
			]
		else:
			ordered = [
				("ssik_max1", _ssik_max1),
				("ssik_all", _ssik_all),
				("ssik_plain", _ssik_plain),
				("ms_kwargs", _ms_kwargs),
			]

		cache_key = (solver_path, bool(enumerate_all))
		cached_style = self._call_style.get(cache_key)
		if cached_style is not None:
			by_name = {name: fn for name, fn in ordered}
			fn = by_name.get(cached_style)
			if fn is not None:
				try:
					return fn()
				except TypeError:
					# Signature changed / wrong cache — rediscover below.
					self._call_style.pop(cache_key, None)

		last_exc: Optional[Exception] = None
		for style, fn in ordered:
			# Never cache/use max_solutions=1 while enumerating — that is what
			# made Plan Motion report "1 branch(es)" after teleop warmed the cache.
			if enumerate_all and style == "ssik_max1":
				continue
			try:
				raw = fn()
				self._call_style[cache_key] = style
				return raw
			except TypeError as exc:
				last_exc = exc
				continue
		if last_exc is not None:
			raise last_exc
		return None

	def _pick_nearest(
		self,
		candidates: List[Dict[str, float]],
		request: IKSolveRequest,
	) -> Optional[Dict[str, float]]:
		if not candidates:
			return None
		if len(candidates) == 1:
			return candidates[0]
		seed_map = {
			name: float(request.q_seed[i]) if i < len(request.q_seed) else 0.0
			for i, name in enumerate(request.joint_names)
		}
		best = candidates[0]
		best_dist = joint_wrap_distance(best, seed_map, request.joint_names)
		for cand in candidates[1:]:
			dist = joint_wrap_distance(cand, seed_map, request.joint_names)
			if dist < best_dist:
				best_dist = dist
				best = cand
		return best

	def _solve_teleop(self, request: IKSolveRequest, candidates: List[Dict[str, float]]) -> IKSolveResult:
		best = self._pick_nearest(candidates, request)
		if best is None:
			return IKSolveResult(False, {}, "Analytic solver returned no valid candidate solutions.")
		# Trust ssik's own FK closure for teleop. Re-checking with our Python FK
		# was rejecting valid solutions (e.g. with TCP offsets) so joints never
		# got applied while jogging — unlike ikpy, which still updated.
		return IKSolveResult(True, best, "", all_solutions=[])

	def _solve_enumerate(self, request: IKSolveRequest, candidates: List[Dict[str, float]]) -> IKSolveResult:
		seed_map = {
			name: float(request.q_seed[i]) if i < len(request.q_seed) else 0.0
			for i, name in enumerate(request.joint_names)
		}
		verified: List[Dict[str, float]] = []
		best: Optional[Dict[str, float]] = None
		best_seed_dist = float("inf")
		best_pose_err = float("inf")
		best_pos = float("inf")
		best_ang = float("inf")

		for cand in candidates:
			fk = forward_kinematics(request, cand)
			if fk is None:
				verified.append(cand)
				seed_dist = joint_wrap_distance(cand, seed_map, request.joint_names)
				if seed_dist < best_seed_dist:
					best_seed_dist = seed_dist
					best = cand
					best_pos = float("inf")
					best_ang = float("inf")
				continue
			pos_err, ang_err = pose_error(fk, request.T_goal_base)
			if pos_err > request.position_tolerance_m or ang_err > request.orientation_tolerance_rad:
				continue
			verified.append(cand)
			seed_dist = joint_wrap_distance(cand, seed_map, request.joint_names)
			pose_score = pos_err + ang_err
			if seed_dist < best_seed_dist or (
				math.isclose(seed_dist, best_seed_dist) and pose_score < best_pose_err
			):
				best_seed_dist = seed_dist
				best_pose_err = pose_score
				best_pos = pos_err
				best_ang = ang_err
				best = cand

		if best is None:
			return IKSolveResult(
				False,
				{},
				"Analytic solver candidates failed FK tolerance checks.",
				all_solutions=[],
			)

		success = (
			best_pos < request.position_tolerance_m and best_ang < request.orientation_tolerance_rad
		) if math.isfinite(best_pos) else True
		msg = (
			""
			if success
			else f"Did not converge (pos_err={best_pos:.4g} m, ang_err={best_ang:.4g} rad)."
		)
		return IKSolveResult(success, best, msg, all_solutions=list(verified))

	def solve(self, request: IKSolveRequest) -> IKSolveResult:
		solver_path = str(getattr(request, "analytic_solver_path", "") or "")
		if not solver_path:
			return IKSolveResult(False, {}, "Analytic solver path is not configured.")

		loaded = self._load_solver(solver_path)
		if loaded is None:
			return IKSolveResult(False, {}, f"Analytic solver not found or invalid: {solver_path}")
		abs_path, _module, solve_fn = loaded
		enumerate_all = bool(getattr(request, "enumerate_all_solutions", False))

		try:
			raw = self._call_solver(abs_path, solve_fn, request, enumerate_all=enumerate_all)
		except Exception as exc:
			return IKSolveResult(False, {}, f"Analytic solve failed: {exc}")

		candidates = self._normalize_candidates(raw, request.joint_names)
		if not candidates:
			return IKSolveResult(False, {}, "Analytic solver returned no valid candidate solutions.")

		if enumerate_all:
			return self._solve_enumerate(request, candidates)
		return self._solve_teleop(request, candidates)

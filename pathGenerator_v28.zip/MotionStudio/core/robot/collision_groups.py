from __future__ import annotations

from typing import TYPE_CHECKING, Dict, List, Set, Tuple

from MotionStudio.core.components.collider_component import ColliderComponent

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def collider_group_name(collider: ColliderComponent) -> str:
	"""Effective group name when grouping is active, else empty."""
	if not bool(getattr(collider, "use_collision_group", False)):
		return ""
	name = str(getattr(collider, "collision_group_name", "") or "").strip()
	return name


def is_grouped_collider(collider: ColliderComponent) -> bool:
	return bool(collider_group_name(collider))


def registered_collision_group_names(scene: "Scene") -> Set[str]:
	"""Group names present among indexed collider entities (not a full scene scan)."""
	names: Set[str] = set()
	for ent in scene.collision_system.collider_entities():
		col = ent.get_component(ColliderComponent)
		if col is None:
			continue
		gname = collider_group_name(col)
		if gname:
			names.add(gname)
	return names


def partition_colliders(
	entities: List["Entity"],
) -> Tuple[Dict[str, List["Entity"]], List["Entity"]]:
	"""Return (groups by name, ungrouped collider entities).

	``entities`` should already be collider participants (e.g.
	``CollisionSystem.collider_entities()``); non-colliders are skipped.
	"""
	groups: Dict[str, List["Entity"]] = {}
	ungrouped: List["Entity"] = []
	for ent in entities:
		col = ent.get_component(ColliderComponent)
		if col is None:
			continue
		gname = collider_group_name(col)
		if gname:
			groups.setdefault(gname, []).append(ent)
		else:
			ungrouped.append(ent)
	return groups, ungrouped


def apply_urdf_collision_group_defaults(scene: "Scene", robot_desc: "RobotDescriptionComponent") -> None:
	"""
	Disable internal collision checks between kinematically adjacent URDF link pairs.
	Only runs when the group's internal matrix has no entries yet.
	"""
	group = str(robot_desc.robot_name or "").strip()
	if not group:
		return
	matrix = scene.collision_system.matrix
	if matrix.has_group_internal_entries(group):
		return
	for joint in robot_desc.joints:
		parent_name = joint.get("parent_link", "")
		child_name = joint.get("child_link", "")
		if not parent_name or not child_name:
			continue
		parent_id = robot_desc.find_link_entity_id(parent_name)
		child_id = robot_desc.find_link_entity_id(child_name)
		if parent_id and child_id:
			matrix.set_internal_enabled(group, parent_id, child_id, enabled=False)


def ensure_link_collider_group_fields(collider: ColliderComponent, group_name: str) -> None:
	"""Apply standard URDF link collider grouping fields."""
	collider.use_collision_group = True
	collider.collision_group_name = str(group_name or "")

"""Snapshot FCL collision world for off-scene planner validity checks.

Pose recipe matches live ``CollisionSystem._pair_collides`` +
``FclCollisionBackend.pair_intersects`` exactly:

1. Polydata from ``CollisionSystem._get_polydata`` (local verts).
2. World pose as a 4x4 (articulated: ``T_world_base @ FK(q) @ T_link_local``).
3. ``decompose_qmatrix_affine`` → bake scale into verts, FCL ``Transform(R, t)``.

So a failing ``q`` after ``apply_solution`` must agree with live Physics.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple

import numpy as np

from MotionStudio.core.robot.frame_math import joint_local_transform, multiply_transforms

# Print first N state-validity samples in detail, then a rolling summary.
_VALIDITY_TIMING_FIRST_N = 3
_VALIDITY_TIMING_SUMMARY_EVERY = 500

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import (
		RobotDescriptionComponent,
	)
	from MotionStudio.core.scene.scene import Scene


@dataclass
class _MeshBody:
	"""Triangle mesh in **local** polydata space; posed in world at query time."""

	body_id: str
	link_name: str  # "" for fully static world bodies
	vertices: np.ndarray  # (N,3) float64 — local, same as live polydata_to_triangles
	triangles: np.ndarray  # (M,3) int32
	# Static: full world matrix frozen at snapshot (scale applied at query).
	T_world: np.ndarray = field(default_factory=lambda: np.eye(4, dtype=np.float64))
	# Articulated: world_pose(q) = T_world_base @ FK(link) @ T_link_local
	# T_link_local is the full relative 4x4 inv(W_link) @ W_ent at snapshot.
	T_link_local: np.ndarray = field(default_factory=lambda: np.eye(4, dtype=np.float64))
	entity_id: str = ""


@dataclass
class PlanningCollisionWorld:
	"""Thread-safe collision oracle built on the main thread, queried on a worker.

	Production RRT/OMPL sampling calls :meth:`is_state_valid` only — no viewport
	posing, no ``processEvents``, no Qt signals on the hot path.
	"""

	joint_names: List[str]
	joints: List[Dict[str, Any]]
	root_link: str
	# Full affine world pose of the FK root (includes placement scale).
	T_world_base: np.ndarray = field(default_factory=lambda: np.eye(4, dtype=np.float64))
	robot_bodies: List[_MeshBody] = field(default_factory=list)
	static_bodies: List[_MeshBody] = field(default_factory=list)
	enabled_pairs: List[Tuple[str, str]] = field(default_factory=list)
	# (body_id, scale_key) -> BVHModel — same cache strategy as live FCL.
	_bvh_cache: Dict[Tuple[str, Tuple[float, float, float]], Any] = field(
		default_factory=dict, repr=False
	)
	# Profiler (worker-thread safe; single planner worker owns the world).
	_validity_count: int = field(default=0, repr=False)
	_validity_total_s: float = field(default=0.0, repr=False)
	_validity_fk_s: float = field(default=0.0, repr=False)
	_validity_pose_s: float = field(default=0.0, repr=False)
	_validity_fcl_s: float = field(default=0.0, repr=False)
	# Samples rejected by imove workspace proximity (before FCL); per transition.
	_workspace_reject_count: int = field(default=0, repr=False)
	# Cumulative across the whole plan (not cleared by reset_validity_timing).
	_workspace_reject_total: int = field(default=0, repr=False)
	_limits_cache: Optional[List[Tuple[float, float]]] = field(default=None, repr=False)
	uses_live_viewport: bool = field(default=False, repr=False)

	def joint_limits(self) -> List[Tuple[float, float]]:
		if self._limits_cache is not None:
			return self._limits_cache
		by_name = {str(j.get("name", "")): j for j in self.joints}
		out: List[Tuple[float, float]] = []
		for name in self.joint_names:
			j = by_name.get(name, {})
			jtype = str(j.get("type", "revolute")).lower()
			limits = j.get("limits") or {}
			if jtype == "continuous":
				out.append((-float(np.pi), float(np.pi)))
				continue
			lo = float(limits.get("lower", -np.pi)) if limits else -float(np.pi)
			hi = float(limits.get("upper", np.pi)) if limits else float(np.pi)
			if hi < lo:
				lo, hi = hi, lo
			out.append((lo, hi))
		self._limits_cache = out
		return out

	def normalize_q(self, q: np.ndarray) -> np.ndarray:
		q = np.asarray(q, dtype=np.float64).reshape(-1).copy()
		by_name = {str(j.get("name", "")): j for j in self.joints}
		for i, name in enumerate(self.joint_names):
			if i >= q.size:
				break
			j = by_name.get(name, {})
			if str(j.get("type", "revolute")).lower() != "continuous":
				continue
			x = float(q[i])
			q[i] = float((x + np.pi) % (2.0 * np.pi) - np.pi)
		return q

	def within_limits(self, q: np.ndarray) -> bool:
		q = self.normalize_q(q)
		limits = self.joint_limits()
		if q.size != len(limits):
			return False
		for i, (lo, hi) in enumerate(limits):
			if q[i] < lo - 1e-9 or q[i] > hi + 1e-9:
				return False
		return True

	def forward_kinematics_base_mm(self, q: np.ndarray) -> Dict[str, np.ndarray]:
		"""Link name → 4x4 pose in robot **base/root** frame (translation mm)."""
		q = np.asarray(q, dtype=np.float64).reshape(-1)
		q_map = {
			name: float(q[i]) if i < q.size else 0.0
			for i, name in enumerate(self.joint_names)
		}
		children: Dict[str, List[Dict[str, Any]]] = {}
		for j in self.joints:
			parent = str(j.get("parent_link", ""))
			children.setdefault(parent, []).append(j)

		poses: Dict[str, np.ndarray] = {self.root_link: np.eye(4, dtype=np.float64)}

		def dfs(link_name: str) -> None:
			T_parent = poses[link_name]
			for j in children.get(link_name, []):
				child = str(j.get("child_link", ""))
				if not child:
					continue
				jname = str(j.get("name", ""))
				origin_xyz = tuple(j.get("origin_xyz_m", [0, 0, 0])[:3])
				origin_rpy = tuple(j.get("origin_rpy_rad", [0, 0, 0])[:3])
				axis = tuple(j.get("axis_xyz", [0, 0, 1])[:3])
				jt = str(j.get("type", "fixed"))
				qv = float(q_map.get(jname, 0.0))
				T_local = joint_local_transform(jt, origin_xyz, origin_rpy, axis, qv)
				poses[child] = multiply_transforms(T_parent, T_local)
				dfs(child)

		dfs(self.root_link)
		return poses

	@staticmethod
	def _decompose_world(T_world: np.ndarray):
		"""Same decompose as live FCL — pure numpy (no QMatrix4x4 on hot path)."""
		from MotionStudio.core.scene.collision_backends import decompose_affine_matrix

		return decompose_affine_matrix(T_world)

	def reset_validity_timing(self) -> None:
		"""Clear per-transition ``is_state_valid`` timing (call before each RRT).

		Does not clear ``_workspace_reject_total`` (plan-wide accumulation).
		"""
		self._validity_count = 0
		self._validity_total_s = 0.0
		self._validity_fk_s = 0.0
		self._validity_pose_s = 0.0
		self._validity_fcl_s = 0.0
		self._workspace_reject_count = 0

	def note_workspace_reject(self) -> None:
		"""Record one sample rejected by the imove workspace proximity sphere."""
		self._workspace_reject_count = int(self._workspace_reject_count) + 1
		self._workspace_reject_total = int(self._workspace_reject_total) + 1

	def validity_timing_summary(self) -> str:
		n = int(self._validity_count)
		ws = int(self._workspace_reject_count)
		ws_total = int(self._workspace_reject_total)
		if n <= 0:
			return (
				f"validity checks: 0  "
				f"workspace_rejects={ws} (plan_total={ws_total})"
			)
		avg_ms = 1000.0 * self._validity_total_s / float(n)
		return (
			f"validity checks: {n}  avg={avg_ms:.3f} ms/sample  "
			f"fk={1000.0 * self._validity_fk_s / n:.3f}  "
			f"pose={1000.0 * self._validity_pose_s / n:.3f}  "
			f"fcl={1000.0 * self._validity_fcl_s / n:.3f}  "
			f"workspace_rejects={ws} (plan_total={ws_total})  "
			f"pairs={len(self.enabled_pairs)}  "
			f"thread={threading.current_thread().name}  "
			f"live_viewport={self.uses_live_viewport}"
		)

	def _get_bvh(self, body: _MeshBody, scale: np.ndarray) -> Any:
		import fcl

		scale_key = (float(scale[0]), float(scale[1]), float(scale[2]))
		cache_key = (body.body_id, scale_key)
		cached = self._bvh_cache.get(cache_key)
		if cached is not None:
			return cached
		if body.vertices.size == 0 or body.triangles.size == 0:
			return None
		verts = np.asarray(body.vertices, dtype=np.float64)
		if not np.allclose(scale, 1.0):
			verts = verts * scale.reshape(1, 3)
		model = fcl.BVHModel()
		model.beginModel(len(body.triangles), len(body.vertices))
		model.addSubModel(
			np.ascontiguousarray(verts, dtype=np.float64),
			np.ascontiguousarray(body.triangles, dtype=np.int32),
		)
		model.endModel()
		self._bvh_cache[cache_key] = model
		return model

	def collision_summary(self) -> str:
		try:
			import fcl  # noqa: F401

			fcl_ok = True
		except Exception:
			fcl_ok = False
		n_attached = sum(
			1
			for b in self.robot_bodies
			if b.link_name and not np.allclose(b.T_link_local, np.eye(4))
		)
		return (
			f"robot_links={len(self.robot_bodies)} "
			f"attached={n_attached} "
			f"world_colliders={len(self.static_bodies)} "
			f"pairs={len(self.enabled_pairs)} "
			f"fcl={'yes' if fcl_ok else 'NO'}"
		)

	def collision_checking_active(self) -> bool:
		if not self.enabled_pairs:
			return False
		try:
			import fcl  # noqa: F401

			return True
		except Exception:
			return False

	def _body_pose_world(
		self, body: _MeshBody, poses_base: Dict[str, np.ndarray]
	) -> Optional[np.ndarray]:
		"""Full world 4x4 matching live ``_world_transform`` after FK at ``q``."""
		if body.link_name:
			T_link = poses_base.get(body.link_name)
			if T_link is None:
				return None
			return self.T_world_base @ T_link @ body.T_link_local
		return body.T_world

	def _collision_object(self, body: _MeshBody, poses_base: Dict[str, np.ndarray]):
		"""Build FCL object with the same bake as ``FclCollisionBackend.pair_intersects``."""
		import fcl

		T = self._body_pose_world(body, poses_base)
		if T is None:
			return None
		rot, trans, scale = self._decompose_world(T)
		bvh = self._get_bvh(body, scale)
		if bvh is None:
			return None
		return fcl.CollisionObject(
			bvh,
			fcl.Transform(
				np.ascontiguousarray(rot, dtype=np.float64),
				np.ascontiguousarray(trans, dtype=np.float64),
			),
		)

	def find_colliding_pair(
		self,
		q: np.ndarray,
		*,
		_timings: Optional[Dict[str, float]] = None,
	) -> Optional[Tuple[str, str]]:
		"""Return ``(body_id_a, body_id_b)`` for the first colliding enabled pair."""
		q = self.normalize_q(q)
		if not self.within_limits(q) or not self.enabled_pairs:
			return None
		try:
			import fcl
		except Exception:
			return None

		t0 = time.perf_counter()
		poses = self.forward_kinematics_base_mm(q)
		t1 = time.perf_counter()
		body_by_id = {b.body_id: b for b in (*self.robot_bodies, *self.static_bodies)}
		obj_cache: Dict[str, Any] = {}
		pose_s = 0.0

		def collision_object(body_id: str):
			nonlocal pose_s
			if body_id in obj_cache:
				return obj_cache[body_id]
			body = body_by_id.get(body_id)
			if body is None:
				return None
			tp = time.perf_counter()
			obj = self._collision_object(body, poses)
			pose_s += time.perf_counter() - tp
			obj_cache[body_id] = obj
			return obj

		request = fcl.CollisionRequest(num_max_contacts=1, enable_contact=False)
		t_fcl0 = time.perf_counter()
		hit: Optional[Tuple[str, str]] = None
		for a_id, b_id in self.enabled_pairs:
			oa = collision_object(a_id)
			ob = collision_object(b_id)
			if oa is None or ob is None:
				continue
			result = fcl.CollisionResult()
			try:
				ret = fcl.collide(oa, ob, request, result)
			except Exception:
				continue
			if bool(ret) or result.is_collision:
				hit = (a_id, b_id)
				break
		t_fcl1 = time.perf_counter()
		if _timings is not None:
			_timings["fk_s"] = t1 - t0
			_timings["pose_s"] = pose_s
			# FCL window includes pose build; report collide-only as residual.
			_timings["fcl_s"] = max(0.0, (t_fcl1 - t_fcl0) - pose_s)
		return hit

	def is_state_valid(self, q: np.ndarray) -> bool:
		"""Return True if ``q`` is within limits and collision-free.

		Prints per-sample timing for the first few RRT checks (and a rolling
		average) so Plan Motion console output shows hot-path cost without
		viewport / Qt event-loop involvement.
		"""
		t0 = time.perf_counter()
		q = self.normalize_q(q)
		if not self.within_limits(q):
			self._record_validity_sample(time.perf_counter() - t0, {}, valid=False)
			return False
		if not self.enabled_pairs:
			self._record_validity_sample(time.perf_counter() - t0, {}, valid=True)
			return True
		timings: Dict[str, float] = {}
		hit = self.find_colliding_pair(q, _timings=timings)
		self._record_validity_sample(time.perf_counter() - t0, timings, valid=hit is None)
		return hit is None

	def _record_validity_sample(
		self,
		total_s: float,
		timings: Dict[str, float],
		*,
		valid: bool,
	) -> None:
		self._validity_count += 1
		self._validity_total_s += float(total_s)
		self._validity_fk_s += float(timings.get("fk_s", 0.0))
		self._validity_pose_s += float(timings.get("pose_s", 0.0))
		self._validity_fcl_s += float(timings.get("fcl_s", 0.0))
		n = self._validity_count
		if n > _VALIDITY_TIMING_FIRST_N and (n % _VALIDITY_TIMING_SUMMARY_EVERY) != 0:
			return
		fk_ms = 1000.0 * float(timings.get("fk_s", 0.0))
		pose_ms = 1000.0 * float(timings.get("pose_s", 0.0))
		fcl_ms = 1000.0 * float(timings.get("fcl_s", 0.0))
		total_ms = 1000.0 * float(total_s)
		avg_ms = 1000.0 * self._validity_total_s / float(n)
		kind = "sample" if n <= _VALIDITY_TIMING_FIRST_N else "summary"
		print(
			f"[RRT validity] {kind} #{n}: {total_ms:.3f} ms  "
			f"(FK={fk_ms:.3f} pose/BVH={pose_ms:.3f} FCL={fcl_ms:.3f})  "
			f"avg={avg_ms:.3f} ms  valid={valid}  "
			f"pairs={len(self.enabled_pairs)}  "
			f"thread={threading.current_thread().name}  "
			f"live_viewport={self.uses_live_viewport}",
			flush=True,
		)

	def _wrap_mask(self) -> np.ndarray:
		"""True for continuous / near-full-range joints (shortest-arc edge lerp)."""
		dof = len(self.joint_names)
		mask = np.zeros(dof, dtype=bool)
		limits = self.joint_limits()
		by_name = {str(j.get("name", "")): j for j in self.joints}
		for i, name in enumerate(self.joint_names):
			j = by_name.get(name, {})
			if str(j.get("type", "revolute")).lower() == "continuous":
				mask[i] = True
				continue
			if i < len(limits):
				lo, hi = limits[i]
				if float(hi - lo) >= (2.0 * np.pi - 1e-6):
					mask[i] = True
		return mask

	@staticmethod
	def _joint_delta_wrapped(qa: np.ndarray, qb: np.ndarray, wrap_mask: np.ndarray) -> np.ndarray:
		d = np.asarray(qb, dtype=np.float64).reshape(-1) - np.asarray(
			qa, dtype=np.float64
		).reshape(-1)
		out = d.copy()
		for i, wrap in enumerate(wrap_mask):
			if wrap and i < out.size:
				x = float(out[i])
				out[i] = float((x + np.pi) % (2.0 * np.pi) - np.pi)
		return out

	def first_invalid_on_segment(
		self,
		q_a: np.ndarray,
		q_b: np.ndarray,
		*,
		resolution_rad: float = 0.05,
	) -> Tuple[bool, Optional[np.ndarray], str]:
		"""Check C-space edge; return ``(ok, failing_q, detail)``.

		Uses wrap-aware interpolation on continuous joints (same metric as imove RRT).
		"""
		qa = np.asarray(q_a, dtype=np.float64).reshape(-1)
		qb = np.asarray(q_b, dtype=np.float64).reshape(-1)
		if qa.size != qb.size:
			return False, qa, "DOF mismatch"

		if not self.is_state_valid(qa):
			pair = self.find_colliding_pair(qa)
			extra = f" pair={pair}" if pair else ""
			return False, qa.copy(), f"start sample in collision{extra}"
		if not self.is_state_valid(qb):
			pair = self.find_colliding_pair(qb)
			extra = f" pair={pair}" if pair else ""
			return False, qb.copy(), f"end sample in collision{extra}"

		wrap_mask = self._wrap_mask()
		delta = self._joint_delta_wrapped(qa, qb, wrap_mask)
		dist = float(np.linalg.norm(delta))
		if dist < 1e-12:
			return True, None, ""
		step = max(1e-4, float(resolution_rad))
		# At least one interior sample so thin obstacles between free endpoints
		# cannot slip through when dist <= step (matches imove RRT).
		n = max(2, int(np.ceil(dist / step)))
		for i in range(1, n):
			alpha = float(i) / float(n)
			q = qa + alpha * delta
			if not self.is_state_valid(q):
				pair = self.find_colliding_pair(q)
				extra = f" pair={pair}" if pair else ""
				return (
					False,
					q.copy(),
					f"mid-edge collision at α={alpha:.3f}{extra}",
				)
		return True, None, ""

	def is_segment_valid(
		self,
		q_a: np.ndarray,
		q_b: np.ndarray,
		*,
		resolution_rad: float = 0.05,
	) -> bool:
		ok, _q, _detail = self.first_invalid_on_segment(
			q_a, q_b, resolution_rad=resolution_rad
		)
		return ok

	def planning_world_matrix(self, body: _MeshBody, q: np.ndarray) -> Optional[np.ndarray]:
		"""World 4x4 the planner would use for ``body`` at ``q`` (for tests / verify)."""
		poses = self.forward_kinematics_base_mm(self.normalize_q(q))
		return self._body_pose_world(body, poses)


def _qmatrix_to_numpy(m) -> np.ndarray:
	out = np.eye(4, dtype=np.float64)
	for r in range(4):
		for c in range(4):
			out[r, c] = float(m[r, c])
	return out


def all_matrix_pairs(
	groups: Dict[str, List[Any]],
	ungrouped: List[Any],
	matrix: Any,
) -> List[Tuple[Any, Any]]:
	from MotionStudio.core.scene.collision_system import CollisionSystem

	return list(CollisionSystem.iter_matrix_enabled_pairs(groups, ungrouped, matrix))


def robot_involved_matrix_pairs(
	groups: Dict[str, List[Any]],
	ungrouped: List[Any],
	matrix: Any,
	robot_entity_ids: set,
) -> List[Tuple[Any, Any]]:
	out: List[Tuple[Any, Any]] = []
	for ent_a, ent_b in all_matrix_pairs(groups, ungrouped, matrix):
		if str(ent_a.id) in robot_entity_ids or str(ent_b.id) in robot_entity_ids:
			out.append((ent_a, ent_b))
	return out


def _nearest_urdf_link_name(
	ent: Any,
	link_id_to_name: Dict[str, str],
	robot_ent: Any,
	root_link: str,
) -> Optional[str]:
	cur = ent
	guard = 0
	while cur is not None and guard < 4096:
		cid = str(cur.id)
		if cid in link_id_to_name:
			return link_id_to_name[cid]
		if robot_ent is not None and cid == str(robot_ent.id):
			return str(root_link)
		cur = cur.parent
		guard += 1
	return None


def build_planning_collision_world(
	scene: "Scene",
	robot: "RobotDescriptionComponent",
) -> PlanningCollisionWorld:
	"""Capture the scene using live collision polydata + relative transforms."""
	from MotionStudio.core.components.collider_component import ColliderComponent
	from MotionStudio.core.components.urdf_link_component import UrdfLinkComponent
	from MotionStudio.core.robot.collision_groups import partition_colliders
	from MotionStudio.core.scene.collision_backends import polydata_to_triangles

	cs = scene.collision_system
	robot_ent = robot.entity
	empty = PlanningCollisionWorld(
		joint_names=list(robot.actuated_joint_names),
		joints=[dict(j) for j in robot.joints],
		root_link=str(robot.root_link),
	)
	if robot_ent is None:
		return empty

	base_ent = robot_ent
	root_id = robot.find_link_entity_id(robot.root_link)
	if root_id:
		found = scene.find_by_id(root_id)
		if found is not None:
			base_ent = found

	# Full affine base (same chain as live ``_world_transform``).
	T_world_base = _qmatrix_to_numpy(cs._world_transform(base_ent))

	link_entities: Dict[str, Any] = {}
	link_names = [
		str(rec.get("name", ""))
		for rec in robot.links
		if str(rec.get("name", ""))
	]
	if not link_names:
		def walk(e) -> None:
			ul = e.get_component(UrdfLinkComponent)
			if ul is not None:
				link_entities[str(ul.link_name)] = e
			for ch in e.children:
				walk(ch)

		walk(robot_ent)
	else:
		for link_name in link_names:
			lid = robot.find_link_entity_id(link_name)
			if not lid:
				continue
			lent = scene.find_by_id(lid)
			if lent is not None:
				link_entities[link_name] = lent

	link_id_to_name = {str(e.id): name for name, e in link_entities.items()}

	robot_bodies: List[_MeshBody] = []
	entity_to_body: Dict[str, str] = {}

	# 1) URDF link colliders — local verts; pose = T_world_base @ FK(link).
	for link_name, ent in link_entities.items():
		if ent.get_component(ColliderComponent) is None:
			continue
		poly = cs._get_polydata(ent)
		if poly is None:
			continue
		verts, tris = polydata_to_triangles(poly)
		if len(verts) == 0 or len(tris) == 0:
			continue
		bid = f"robot:{link_name}"
		robot_bodies.append(
			_MeshBody(
				body_id=bid,
				link_name=link_name,
				vertices=np.asarray(verts, dtype=np.float64),
				triangles=tris,
				T_link_local=np.eye(4, dtype=np.float64),
				entity_id=str(ent.id),
			)
		)
		entity_to_body[str(ent.id)] = bid

	# 2) Attached colliders under links — full relative 4x4 from live world matrices.
	for ent in cs.collider_entities():
		eid = str(ent.id)
		if eid in entity_to_body:
			continue
		link_name = _nearest_urdf_link_name(
			ent, link_id_to_name, robot_ent, str(robot.root_link)
		)
		if not link_name:
			continue
		link_ent = link_entities.get(link_name)
		if link_ent is None or str(link_ent.id) == eid:
			continue
		poly = cs._get_polydata(ent)
		if poly is None:
			continue
		verts, tris = polydata_to_triangles(poly)
		if len(verts) == 0 or len(tris) == 0:
			continue
		W_link = _qmatrix_to_numpy(cs._world_transform(link_ent))
		W_ent = _qmatrix_to_numpy(cs._world_transform(ent))
		try:
			T_link_local = np.linalg.inv(W_link) @ W_ent
		except Exception:
			T_link_local = np.eye(4, dtype=np.float64)
		bid = f"attached:{eid}"
		robot_bodies.append(
			_MeshBody(
				body_id=bid,
				link_name=str(link_name),
				vertices=np.asarray(verts, dtype=np.float64),
				triangles=tris,
				T_link_local=T_link_local,
				entity_id=eid,
			)
		)
		entity_to_body[eid] = bid

	# 3) All matrix pairs; snapshot remaining as static world bodies.
	groups, ungrouped = partition_colliders(cs.collider_entities())
	matrix_pairs = all_matrix_pairs(groups, ungrouped, cs.matrix)

	static_bodies: List[_MeshBody] = []
	enabled_pairs: List[Tuple[str, str]] = []
	seen_pairs: Set[Tuple[str, str]] = set()

	for ent_a, ent_b in matrix_pairs:
		id_a = str(ent_a.id)
		id_b = str(ent_b.id)

		for ent, eid in ((ent_a, id_a), (ent_b, id_b)):
			if eid in entity_to_body:
				continue
			poly = cs._get_polydata(ent)
			if poly is None:
				continue
			verts, tris = polydata_to_triangles(poly)
			if len(verts) == 0 or len(tris) == 0:
				continue
			# Freeze full world matrix (scale baked at query via decompose).
			T_world = _qmatrix_to_numpy(cs._world_transform(ent))
			bid = f"world:{eid}"
			static_bodies.append(
				_MeshBody(
					body_id=bid,
					link_name="",
					vertices=np.asarray(verts, dtype=np.float64),
					triangles=tris,
					T_world=T_world,
					entity_id=eid,
				)
			)
			entity_to_body[eid] = bid

		bid_a = entity_to_body.get(id_a)
		bid_b = entity_to_body.get(id_b)
		if not bid_a or not bid_b:
			continue
		key = (bid_a, bid_b) if bid_a <= bid_b else (bid_b, bid_a)
		if key in seen_pairs:
			continue
		seen_pairs.add(key)
		enabled_pairs.append(key)

	return PlanningCollisionWorld(
		joint_names=list(robot.actuated_joint_names),
		joints=[dict(j) for j in robot.joints],
		root_link=str(robot.root_link),
		T_world_base=T_world_base,
		robot_bodies=robot_bodies,
		static_bodies=static_bodies,
		enabled_pairs=enabled_pairs,
	)

"""imove motion-planner backend (numpy RRT-Connect / Informed RRT* transitions)."""

from __future__ import annotations

from typing import Callable, List, Optional

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.planning.imove.rrt_connect import (
	plan_joint_transition as plan_rrt_connect,
)
from MotionStudio.core.robot.planning.imove.rrt_star import (
	plan_joint_transition as plan_rrt_star,
)
from MotionStudio.core.robot.planning.imove.workspace_limit import (
	job_aabb_sphere_from_waypoints,
)
from MotionStudio.core.robot.planning.plan_pipeline import plan_segments_with_transitions
from MotionStudio.core.robot.planning.planner_backend import PlanRequest, PlanResult

TransitionFn = Callable[..., tuple]


def _normalize_imove_algorithm(name: str) -> str:
	key = (name or "").strip().lower().replace(" ", "").replace("_", "").replace("-", "")
	if key in ("rrtconnect", "connect"):
		return "rrt_connect"
	if key in ("rrt*", "rrtstar", "informedrrt*", "informedrrtstar"):
		return "rrt_star"
	return "rrt_star"


def _transition_fn_for(algorithm: str) -> TransitionFn:
	if _normalize_imove_algorithm(algorithm) == "rrt_connect":
		return plan_rrt_connect
	return plan_rrt_star


def _bind_transition_fn(
	algorithm: str,
	goal_bias: float,
	*,
	workspace_center_m: Optional[np.ndarray],
	workspace_radius_m: Optional[float],
	tool_link: str,
	T_ee_tcp: np.ndarray,
) -> TransitionFn:
	"""Wrap the selected planner so pipeline calls forward imove knobs."""
	base = _transition_fn_for(algorithm)
	bias = float(max(0.0, min(1.0, goal_bias)))
	center = (
		None
		if workspace_center_m is None
		else np.asarray(workspace_center_m, dtype=np.float64).reshape(3)
	)
	radius = None if workspace_radius_m is None else float(workspace_radius_m)
	link = str(tool_link or "")
	T_off = np.asarray(T_ee_tcp, dtype=np.float64)

	def _fn(
		q_from: np.ndarray,
		q_to: np.ndarray,
		collision_world,
		*,
		time_limit_s: float,
		simplify: bool,
		resolution_rad: float = 0.05,
	) -> tuple[Optional[List[np.ndarray]], str]:
		return base(
			q_from,
			q_to,
			collision_world,
			time_limit_s=time_limit_s,
			simplify=simplify,
			resolution_rad=resolution_rad,
			goal_bias=bias,
			workspace_center_m=center,
			workspace_radius_m=radius,
			tool_link=link,
			T_ee_tcp=T_off,
		)

	return _fn


class ImoveMotionPlannerBackend:
	"""imove planner: continuous IK on segments, selectable RRT transitions.

	Always available (numpy only). Transition algorithm comes from
	``PlanRequest.imove_algorithm`` (``RRT-Connect`` or ``RRT*`` / Informed RRT*).
	Process IK exhausts start IK branches with full segment re-traces
	(sudden-jump gate); inter-segment gaps are left to the selected planner.
	"""

	def is_available(self) -> bool:
		return True

	def invalidate_cache(self, key: str) -> None:
		_ = key

	def plan(self, request: PlanRequest) -> PlanResult:
		ik = AnalyticIKBackend()
		if not ik.is_available():
			return PlanResult(False, "ssik is not available for analytic IK.")

		algo = str(getattr(request, "imove_algorithm", "RRT*") or "RRT*")
		goal_bias = float(getattr(request, "imove_goal_bias", 0.15))
		diameter = float(getattr(request, "imove_workspace_bound_diameter", 2.0))
		center, radius = job_aabb_sphere_from_waypoints(
			list(getattr(request, "waypoint_segments_m_rad", None) or []),
			diameter,
		)
		T_ee_tcp = np.asarray(
			getattr(request, "T_ee_tcp", None), dtype=np.float64
		)
		if T_ee_tcp.shape != (4, 4):
			T_ee_tcp = np.eye(4, dtype=np.float64)

		return plan_segments_with_transitions(
			request,
			backend_name="imove",
			transition_fn=_bind_transition_fn(
				algo,
				goal_bias,
				workspace_center_m=center,
				workspace_radius_m=radius,
				tool_link=str(getattr(request, "tool_link", "") or ""),
				T_ee_tcp=T_ee_tcp,
			),
			ik=ik,
		)

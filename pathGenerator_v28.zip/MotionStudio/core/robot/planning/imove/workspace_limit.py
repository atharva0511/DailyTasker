"""Cartesian workspace proximity sphere for imove RRT sampling.

Rejects configurations whose TCP FK lands outside a job-centered sphere
*before* BVH/FCL collision checks. The base sphere circumscribes the job
waypoint AABB (diameter = multiplier × AABB diagonal); per-transition the
radius expands so start/goal TCP stay valid.
"""

from __future__ import annotations

from typing import Any, Callable, List, Optional, Sequence, Tuple

import numpy as np

from MotionStudio.core.robot.frame_math import METER_TO_MM
from MotionStudio.core.robot.ik.ik_frames import project_to_se3

IsValidFn = Callable[[np.ndarray], bool]

_MIN_DIAG_M = 1e-3
_ENDPOINT_EPS_M = 1e-6


def job_aabb_sphere_from_waypoints(
	segments_m_rad: Sequence[Sequence[tuple]],
	diameter_mult: float,
) -> Tuple[np.ndarray, float]:
	"""Job AABB sphere in robot-base metres.

	``diameter_mult`` of 1.0 → sphere diameter equals the AABB diagonal.
	Returns ``(center_m, radius_m)``.
	"""
	pts: List[np.ndarray] = []
	for seg in segments_m_rad or ():
		for pose in seg or ():
			if pose is None or len(pose) < 3:
				continue
			pts.append(
				np.array(
					[float(pose[0]), float(pose[1]), float(pose[2])],
					dtype=np.float64,
				)
			)
	mult = float(max(1.0, min(5.0, diameter_mult)))
	if not pts:
		return np.zeros(3, dtype=np.float64), 0.5 * mult * _MIN_DIAG_M

	stack = np.vstack(pts)
	lo = stack.min(axis=0)
	hi = stack.max(axis=0)
	center = 0.5 * (lo + hi)
	diag = float(np.linalg.norm(hi - lo))
	diag = max(diag, _MIN_DIAG_M)
	radius = 0.5 * mult * diag
	return center.astype(np.float64), float(radius)


def tcp_position_base_m(
	collision_world: Any,
	q: np.ndarray,
	tool_link: str,
	T_ee_tcp: Optional[np.ndarray] = None,
) -> Optional[np.ndarray]:
	"""TCP xyz in robot-base metres via collision-world FK (no FCL).

	``forward_kinematics_base_mm`` returns link poses with translation in mm.
	``T_ee_tcp`` is tool_link→TCP in metres (identity if unset).
	"""
	if collision_world is None or not tool_link:
		return None
	fk = getattr(collision_world, "forward_kinematics_base_mm", None)
	if not callable(fk):
		return None
	poses = fk(np.asarray(q, dtype=np.float64).reshape(-1))
	if not isinstance(poses, dict):
		return None
	T_tool = poses.get(str(tool_link))
	if T_tool is None:
		return None
	T_tool = np.asarray(T_tool, dtype=np.float64)
	T_off = project_to_se3(
		T_ee_tcp if T_ee_tcp is not None else np.eye(4, dtype=np.float64)
	)
	# Tool pose is mm; scale TCP offset translation to mm before multiply.
	T_off_mm = np.asarray(T_off, dtype=np.float64).copy()
	T_off_mm[0, 3] *= METER_TO_MM
	T_off_mm[1, 3] *= METER_TO_MM
	T_off_mm[2, 3] *= METER_TO_MM
	T_tcp = T_tool @ T_off_mm
	return np.array(
		[
			float(T_tcp[0, 3]) / METER_TO_MM,
			float(T_tcp[1, 3]) / METER_TO_MM,
			float(T_tcp[2, 3]) / METER_TO_MM,
		],
		dtype=np.float64,
	)


def expand_radius_for_endpoints(
	center_m: np.ndarray,
	radius_m: float,
	*,
	collision_world: Any,
	q_start: np.ndarray,
	q_goal: np.ndarray,
	tool_link: str,
	T_ee_tcp: Optional[np.ndarray] = None,
) -> float:
	"""Grow radius so start/goal TCP lie inside the sphere."""
	r = float(max(0.0, radius_m))
	c = np.asarray(center_m, dtype=np.float64).reshape(3)
	for q in (q_start, q_goal):
		p = tcp_position_base_m(collision_world, q, tool_link, T_ee_tcp)
		if p is None:
			continue
		d = float(np.linalg.norm(p - c))
		if d + _ENDPOINT_EPS_M > r:
			r = d + _ENDPOINT_EPS_M
	return r


def make_workspace_is_valid(
	base_is_valid: IsValidFn,
	*,
	collision_world: Any,
	center_m: np.ndarray,
	radius_m: float,
	tool_link: str,
	T_ee_tcp: Optional[np.ndarray] = None,
) -> IsValidFn:
	"""Wrap validity: TCP proximity first, then ``base_is_valid`` (limits/FCL)."""
	c = np.asarray(center_m, dtype=np.float64).reshape(3)
	r = float(max(0.0, radius_m))
	r2 = r * r
	link = str(tool_link or "")

	def is_valid(q: np.ndarray) -> bool:
		if link and collision_world is not None and r2 > 0.0:
			p = tcp_position_base_m(collision_world, q, link, T_ee_tcp)
			if p is not None:
				d2 = float(np.dot(p - c, p - c))
				if d2 > r2 + 1e-12:
					note = getattr(collision_world, "note_workspace_reject", None)
					if callable(note):
						note()
					return False
		return bool(base_is_valid(q))

	return is_valid

"""Informed RRT* for joint-space transitions (imove).

Asymptotically optimal single-tree planner. Once a feasible path exists,
sampling concentrates in the informed hyper-ellipsoid of states that can
improve the C-space path length (Gammell et al.). Uses the same wrap-aware
metrics and edge validity checks as the legacy RRT-Connect module.
"""

from __future__ import annotations

import math
import time
from typing import List, Optional, Sequence, Tuple

import numpy as np

from MotionStudio.core.robot.planning.imove.rrt_connect import (
	_DEFAULT_LINE_BIAS,
	_EDGE_RESOLUTION_RAD,
	_clamp_to_limits,
	_joint_delta,
	_path_length,
	_sample_near_line,
	_sample_uniform,
	_segment_collision_free,
	_simplify_path,
	_split_plan_simplify_deadlines,
	_steer,
	_wrap_mask,
	IsValidFn,
	Limits,
	TransitionResult,
)

# Rewire / near-neighbour radius scale (unit-ball volume factor is approximate).
_RRT_STAR_GAMMA_SCALE = 1.5
_NEAR_RADIUS_STEP_MULT = 2.5


def _unit_ball_volume(dim: int) -> float:
	"""Volume of the unit ball in ``dim`` dimensions."""
	d = max(1, int(dim))
	return float(math.pi ** (d / 2.0) / math.gamma(d / 2.0 + 1.0))


def _near_radius(n: int, dof: int, range_norm: float, step_size: float) -> float:
	"""RRT* connection radius growing as ``(log n / n)^(1/d)``."""
	n = max(2, int(n))
	d = max(1, int(dof))
	# Free-space measure ≈ joint-box volume; use range_norm^d as a scale proxy.
	measure = max(range_norm**d, 1e-9)
	gamma = (
		_RRT_STAR_GAMMA_SCALE
		* (1.0 + 1.0 / d) ** (1.0 / d)
		* (measure / max(_unit_ball_volume(d), 1e-12)) ** (1.0 / d)
	)
	r = gamma * (math.log(n) / n) ** (1.0 / d)
	return float(min(max(r, step_size), _NEAR_RADIUS_STEP_MULT * step_size))


def _nearest(nodes: List[np.ndarray], q: np.ndarray, wrap_mask: np.ndarray) -> int:
	best_i = 0
	best_d = float("inf")
	for i, n in enumerate(nodes):
		d = float(np.linalg.norm(_joint_delta(n, q, wrap_mask)))
		if d < best_d:
			best_d = d
			best_i = i
	return best_i


def _near_indices(
	nodes: List[np.ndarray],
	q: np.ndarray,
	radius: float,
	wrap_mask: np.ndarray,
) -> List[int]:
	r2 = float(radius) * float(radius)
	out: List[int] = []
	for i, n in enumerate(nodes):
		d = float(np.linalg.norm(_joint_delta(n, q, wrap_mask)))
		if d * d <= r2 + 1e-18:
			out.append(i)
	return out


def _sample_informed(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	c_best: float,
	limits: Limits,
	wrap_mask: np.ndarray,
	rng: np.random.Generator,
) -> np.ndarray:
	"""Sample uniformly in the informed prolate hyperspheroid (C-space).

	Works in the unfolded short-arc frame: ``x = 0`` at start,
	``x_goal = wrap_delta(start, goal)``. Points outside the joint box are
	rejected a few times before falling back to a uniform sample.
	"""
	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	x_goal = _joint_delta(q_start, q_goal, wrap_mask)
	c_min = float(np.linalg.norm(x_goal))
	dof = int(q_start.size)
	if not math.isfinite(c_best) or c_best < c_min - 1e-12 or c_min < 1e-12:
		return _sample_uniform(limits[:dof], rng)

	# Ellipsoid transverse radii.
	transverse = 0.5 * math.sqrt(max(c_best * c_best - c_min * c_min, 0.0))
	if transverse < 1e-12:
		# Degenerate: sample on the start–goal segment.
		alpha = float(rng.random())
		return _clamp_to_limits(q_start + alpha * x_goal, limits)

	a1 = 0.5 * c_best
	diag = np.full(dof, transverse, dtype=np.float64)
	diag[0] = a1

	# Orthonormal basis with first column = a = x_goal / ||x_goal||.
	a = x_goal / c_min
	filler = rng.normal(size=(dof, dof))
	filler[:, 0] = a
	q_mat, _ = np.linalg.qr(filler)
	if float(np.dot(q_mat[:, 0], a)) < 0.0:
		q_mat[:, 0] *= -1.0
	c_center = 0.5 * x_goal

	for _ in range(16):
		# Uniform in unit ball via normal / radius trick.
		g = rng.normal(size=dof)
		nrm = float(np.linalg.norm(g))
		if nrm < 1e-12:
			continue
		g /= nrm
		rad = float(rng.random() ** (1.0 / dof))
		x_ball = g * rad
		x_ellipse = (q_mat @ (diag * x_ball)) + c_center
		q = _clamp_to_limits(q_start + x_ellipse, limits)
		# Keep samples that still lie inside the informed set in unfolded space.
		c_via = float(np.linalg.norm(_joint_delta(q_start, q, wrap_mask))) + float(
			np.linalg.norm(_joint_delta(q, q_goal, wrap_mask))
		)
		if c_via <= c_best + 1e-6:
			return q
	return _sample_uniform(limits[:dof], rng)


def _propagate_cost(
	nodes: List[np.ndarray],
	parents: List[int],
	costs: List[float],
	children: List[List[int]],
	root: int,
	wrap_mask: np.ndarray,
) -> None:
	"""Update path costs for ``root``'s descendants after a rewire."""
	stack = [root]
	while stack:
		u = stack.pop()
		for v in children[u]:
			costs[v] = float(costs[u]) + float(
				np.linalg.norm(_joint_delta(nodes[u], nodes[v], wrap_mask))
			)
			stack.append(v)


def _reconstruct(nodes: List[np.ndarray], parents: List[int], idx: int) -> List[np.ndarray]:
	path: List[np.ndarray] = []
	cur = idx
	guard = 0
	while cur >= 0 and guard < len(nodes) + 2:
		path.append(nodes[cur].copy())
		cur = parents[cur]
		guard += 1
	path.reverse()
	return path


def rrt_star(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	limits: Limits,
	is_valid: IsValidFn,
	*,
	time_limit_s: float = 2.0,
	step_size: Optional[float] = None,
	goal_bias: float = 0.10,
	line_bias: float = _DEFAULT_LINE_BIAS,
	simplify: bool = True,
	seed: Optional[int] = None,
	resolution: Optional[float] = None,
) -> TransitionResult:
	"""Informed RRT* in a box-bounded configuration space.

	Runs for the full time budget, continuously rewiring to minimize wrap-aware
	C-space path length. After the first solution, samples preferentially inside
	the informed ellipsoid. Returns ``(path, "")`` or ``(None, reason)``.
	"""
	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	q_goal = np.asarray(q_goal, dtype=np.float64).reshape(-1)
	dof = int(q_start.size)
	if q_goal.size != dof or len(limits) < dof:
		return None, "start/goal DOF mismatch or missing joint limits"

	wrap_mask = _wrap_mask(limits, dof)
	ranges = np.array([hi - lo for lo, hi in limits[:dof]], dtype=np.float64)
	range_norm = float(np.linalg.norm(np.maximum(ranges, 1e-6)))
	if step_size is None:
		step_size = 0.1 * range_norm
	step_size = float(max(1e-4, step_size))
	if resolution is None:
		resolution = float(_EDGE_RESOLUTION_RAD)
	resolution = float(max(1e-4, resolution))
	goal_bias = float(max(0.0, min(1.0, goal_bias)))
	line_bias = float(max(0.0, min(1.0 - goal_bias, line_bias)))

	q_start = _clamp_to_limits(q_start, limits)
	q_goal = _clamp_to_limits(q_goal, limits)

	start_ok = bool(is_valid(q_start))
	goal_ok = bool(is_valid(q_goal))
	if not start_ok and not goal_ok:
		return None, "transition start and goal configs are in collision (or out of limits)"
	if not start_ok:
		return None, "transition start config (end of prior segment) is in collision"
	if not goal_ok:
		return None, "transition goal config (start of next segment) is in collision"

	if float(np.linalg.norm(_joint_delta(q_start, q_goal, wrap_mask))) < 1e-9:
		return [q_start.copy(), q_goal.copy()], ""

	plan_deadline, simplify_deadline = _split_plan_simplify_deadlines(
		time_limit_s, simplify=simplify
	)
	rng = np.random.default_rng(seed)

	# Fast path: free C-space chord.
	if _segment_collision_free(
		q_start, q_goal, is_valid, resolution=resolution, wrap_mask=wrap_mask
	):
		path = [q_start.copy(), q_goal.copy()]
		if simplify:
			path = _simplify_path(
				path,
				is_valid,
				resolution=resolution,
				wrap_mask=wrap_mask,
				rng=rng,
				deadline=simplify_deadline,
			)
		return path, ""

	nodes: List[np.ndarray] = [q_start.copy()]
	parents: List[int] = [-1]
	costs: List[float] = [0.0]
	children: List[List[int]] = [[]]

	best_goal_idx: Optional[int] = None
	c_best = float("inf")
	c_min = float(np.linalg.norm(_joint_delta(q_start, q_goal, wrap_mask)))

	while time.perf_counter() < plan_deadline:
		# --- sample ---
		r = float(rng.random())
		if math.isfinite(c_best) and c_best < float("inf"):
			# Informed sampling once a solution exists (keep a little exploration).
			if r < 0.05:
				q_rand = q_goal.copy()
			elif r < 0.05 + line_bias:
				q_rand = _sample_near_line(
					q_start, q_goal, limits[:dof], wrap_mask, rng
				)
			else:
				q_rand = _sample_informed(
					q_start, q_goal, c_best, limits, wrap_mask, rng
				)
		else:
			if r < goal_bias:
				q_rand = q_goal.copy()
			elif r < goal_bias + line_bias:
				q_rand = _sample_near_line(
					q_start, q_goal, limits[:dof], wrap_mask, rng
				)
			else:
				q_rand = _sample_uniform(limits[:dof], rng)

		# --- nearest + steer ---
		n_i = _nearest(nodes, q_rand, wrap_mask)
		q_near = nodes[n_i]
		q_new = _steer(q_near, q_rand, step_size, wrap_mask)
		q_new = _clamp_to_limits(q_new, limits)
		if not _segment_collision_free(
			q_near, q_new, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			continue

		# Skip duplicates.
		if float(np.linalg.norm(_joint_delta(q_near, q_new, wrap_mask))) < 1e-12:
			continue

		radius = _near_radius(len(nodes), dof, range_norm, step_size)
		near = _near_indices(nodes, q_new, radius, wrap_mask)
		if n_i not in near:
			near.append(n_i)

		# --- choose parent ---
		best_parent = n_i
		best_cost = float(costs[n_i]) + float(
			np.linalg.norm(_joint_delta(q_near, q_new, wrap_mask))
		)
		for i in near:
			c = float(costs[i]) + float(
				np.linalg.norm(_joint_delta(nodes[i], q_new, wrap_mask))
			)
			if c + 1e-12 >= best_cost:
				continue
			if not _segment_collision_free(
				nodes[i], q_new, is_valid, resolution=resolution, wrap_mask=wrap_mask
			):
				continue
			best_parent = i
			best_cost = c

		# --- insert ---
		new_i = len(nodes)
		nodes.append(q_new.copy())
		parents.append(best_parent)
		costs.append(best_cost)
		children.append([])
		children[best_parent].append(new_i)

		# --- rewire ---
		for i in near:
			if i == best_parent or i == new_i:
				continue
			c = float(best_cost) + float(
				np.linalg.norm(_joint_delta(q_new, nodes[i], wrap_mask))
			)
			if c + 1e-12 >= float(costs[i]):
				continue
			if not _segment_collision_free(
				q_new, nodes[i], is_valid, resolution=resolution, wrap_mask=wrap_mask
			):
				continue
			old_p = parents[i]
			if old_p >= 0 and i in children[old_p]:
				children[old_p].remove(i)
			parents[i] = new_i
			children[new_i].append(i)
			costs[i] = c
			_propagate_cost(nodes, parents, costs, children, i, wrap_mask)

		# --- try connect / improve goal ---
		d_goal = float(np.linalg.norm(_joint_delta(q_new, q_goal, wrap_mask)))
		if d_goal <= step_size * 1.01 and _segment_collision_free(
			q_new, q_goal, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			c_goal = float(best_cost) + d_goal
			if c_goal + 1e-12 < c_best:
				# Attach / refresh goal node.
				if best_goal_idx is not None and best_goal_idx < len(nodes):
					# Reuse existing goal vertex if present.
					g_i = best_goal_idx
					old_p = parents[g_i]
					if old_p >= 0 and g_i in children[old_p]:
						children[old_p].remove(g_i)
					parents[g_i] = new_i
					children[new_i].append(g_i)
					nodes[g_i] = q_goal.copy()
					costs[g_i] = c_goal
				else:
					g_i = len(nodes)
					nodes.append(q_goal.copy())
					parents.append(new_i)
					costs.append(c_goal)
					children.append([])
					children[new_i].append(g_i)
					best_goal_idx = g_i
				c_best = c_goal
				# Keep c_best at least c_min (numerical).
				c_best = max(c_best, c_min)

	if best_goal_idx is None:
		return (
			None,
			f"Informed RRT* timed out after {time_limit_s:.2f}s "
			f"(no feasible C-space path; try raising planning_time_limit_s)",
		)

	path = _reconstruct(nodes, parents, best_goal_idx)
	path[0] = q_start.copy()
	path[-1] = q_goal.copy()
	if simplify:
		path = _simplify_path(
			path,
			is_valid,
			resolution=resolution,
			wrap_mask=wrap_mask,
			rng=rng,
			deadline=simplify_deadline,
		)
	# Ensure endpoints.
	if path:
		path[0] = q_start.copy()
		path[-1] = q_goal.copy()
	return path, ""


def plan_joint_transition(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	collision_world,
	*,
	time_limit_s: float,
	simplify: bool,
	resolution_rad: float = _EDGE_RESOLUTION_RAD,
	goal_bias: float = 0.15,
	workspace_center_m: Optional[np.ndarray] = None,
	workspace_radius_m: Optional[float] = None,
	tool_link: str = "",
	T_ee_tcp: Optional[np.ndarray] = None,
) -> TransitionResult:
	"""Adapter matching the shared pipeline transition_fn contract (Informed RRT*)."""
	from MotionStudio.core.robot.planning.imove.workspace_limit import (
		expand_radius_for_endpoints,
		make_workspace_is_valid,
	)

	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	dof = int(q_start.size)
	reset = getattr(collision_world, "reset_validity_timing", None)
	if callable(reset):
		reset()
	if collision_world is not None:
		limits = collision_world.joint_limits()

		def is_valid(q: np.ndarray) -> bool:
			return bool(collision_world.is_state_valid(q))
	else:
		limits = [(-float(np.pi), float(np.pi)) for _ in range(dof)]

		def is_valid(q: np.ndarray) -> bool:
			return True

	if (
		workspace_center_m is not None
		and workspace_radius_m is not None
		and tool_link
		and collision_world is not None
	):
		radius = expand_radius_for_endpoints(
			workspace_center_m,
			float(workspace_radius_m),
			collision_world=collision_world,
			q_start=q_start,
			q_goal=q_goal,
			tool_link=tool_link,
			T_ee_tcp=T_ee_tcp,
		)
		is_valid = make_workspace_is_valid(
			is_valid,
			collision_world=collision_world,
			center_m=workspace_center_m,
			radius_m=radius,
			tool_link=tool_link,
			T_ee_tcp=T_ee_tcp,
		)

	t0 = time.perf_counter()
	path, reason = rrt_star(
		q_start,
		q_goal,
		limits,
		is_valid,
		time_limit_s=time_limit_s,
		simplify=simplify,
		resolution=float(resolution_rad),
		goal_bias=float(goal_bias),
	)
	elapsed = time.perf_counter() - t0
	summary = getattr(collision_world, "validity_timing_summary", None)
	if callable(summary):
		print(
			f"[RRT* validity] transition done in {elapsed:.3f}s — {summary()}",
			flush=True,
		)
	return path, reason

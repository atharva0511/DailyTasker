"""Numpy RRT-Connect for joint-space transitions (imove)."""

from __future__ import annotations

import math
import time
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np

IsValidFn = Callable[[np.ndarray], bool]
Limits = Sequence[Tuple[float, float]]
TransitionResult = Tuple[Optional[List[np.ndarray]], str]

# Collect up to this many successful RRT paths, then pick the shortest after
# shortcutting. Extra attempts only run while time budget remains.
_MAX_SUCCESSFUL_ATTEMPTS = 3
_DEFAULT_LINE_BIAS = 0.15
# Random C-space prune: pick non-adjacent qi,qj; drop intermediates if chord free.
_SHORTCUT_MAX_ITER = 100
_PARTIAL_SHORTCUT_MAX_ITER = 40
# Fraction of the transition time budget reserved for simplify (when enabled).
# Without this, RRT* often exhausts the deadline and shortcutting never runs.
_SIMPLIFY_TIME_FRACTION = 0.25
_SIMPLIFY_MIN_BUDGET_S = 0.5
# Absolute C-space edge sample spacing (L2 rad). Must stay fine enough that
# shortcutting cannot "tunnel" through thin colliders between discrete checks.
# Previously ``0.02 * range_norm`` (~0.3 rad on 6-DOF) made this common.
_EDGE_RESOLUTION_RAD = 0.05


def _split_plan_simplify_deadlines(
	time_limit_s: float,
	*,
	simplify: bool,
) -> Tuple[float, float]:
	"""Return ``(plan_deadline, simplify_deadline)`` from ``perf_counter``.

	When ``simplify`` is True, reserves a slice of the budget so random path
	pruning always gets wall-clock time after a solution is found.
	"""
	now = time.perf_counter()
	total = max(0.05, float(time_limit_s))
	if not simplify:
		deadline = now + total
		return deadline, deadline
	reserve = max(_SIMPLIFY_MIN_BUDGET_S, _SIMPLIFY_TIME_FRACTION * total)
	reserve = min(reserve, max(0.05, total - 0.05))
	plan_deadline = now + (total - reserve)
	simplify_deadline = now + total
	return plan_deadline, simplify_deadline


def _wrap_pi(x: float) -> float:
	"""Wrap angle to (-pi, pi]."""
	return float((x + math.pi) % (2.0 * math.pi) - math.pi)


def _wrap_mask(limits: Limits, dof: int) -> np.ndarray:
	"""True for joints that should use shortest-angle metric (near-full rotation)."""
	mask = np.zeros(dof, dtype=bool)
	for i in range(min(dof, len(limits))):
		lo, hi = limits[i]
		if float(hi - lo) >= (2.0 * math.pi - 1e-6):
			mask[i] = True
	return mask


def _joint_delta(
	q_from: np.ndarray,
	q_to: np.ndarray,
	wrap_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
	"""Joint delta; wrap continuous / full-range axes to the short arc."""
	d = np.asarray(q_to, dtype=np.float64).reshape(-1) - np.asarray(
		q_from, dtype=np.float64
	).reshape(-1)
	if wrap_mask is None:
		return np.array([_wrap_pi(float(v)) for v in d], dtype=np.float64)
	out = d.copy()
	for i, wrap in enumerate(wrap_mask):
		if wrap and i < out.size:
			out[i] = _wrap_pi(float(out[i]))
	return out


def _path_length(path: List[np.ndarray], wrap_mask: np.ndarray) -> float:
	"""Wrap-aware L2 path length in joint space."""
	if len(path) < 2:
		return 0.0
	total = 0.0
	for i in range(len(path) - 1):
		total += float(np.linalg.norm(_joint_delta(path[i], path[i + 1], wrap_mask)))
	return total


def _clamp_to_limits(q: np.ndarray, limits: Limits) -> np.ndarray:
	out = np.asarray(q, dtype=np.float64).reshape(-1).copy()
	for i, (lo, hi) in enumerate(limits):
		if i >= out.size:
			break
		# Continuous-style full rotation: wrap into [lo, hi] when span >= ~2pi
		span = float(hi - lo)
		if span >= (2.0 * math.pi - 1e-6):
			# Map into [lo, lo+2pi)
			two_pi = 2.0 * math.pi
			x = float(out[i])
			x = (x - lo) % two_pi + lo
			if x > hi:
				x -= two_pi
			out[i] = float(min(max(x, lo), hi))
		else:
			out[i] = float(min(max(out[i], lo), hi))
	return out


def _sample_uniform(limits: Limits, rng: np.random.Generator) -> np.ndarray:
	lo = np.array([p[0] for p in limits], dtype=np.float64)
	hi = np.array([p[1] for p in limits], dtype=np.float64)
	return rng.uniform(lo, hi)


def _sample_near_line(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	limits: Limits,
	wrap_mask: np.ndarray,
	rng: np.random.Generator,
	*,
	noise_frac: float = 0.05,
) -> np.ndarray:
	"""Sample near the wrapped C-space chord from start to goal."""
	delta = _joint_delta(q_start, q_goal, wrap_mask)
	alpha = float(rng.random())
	q = np.asarray(q_start, dtype=np.float64).reshape(-1) + alpha * delta
	lo = np.array([p[0] for p in limits], dtype=np.float64)
	hi = np.array([p[1] for p in limits], dtype=np.float64)
	span = np.maximum(hi - lo, 1e-6)
	noise = rng.normal(0.0, noise_frac, size=q.shape) * span
	return _clamp_to_limits(q + noise, limits)


def _steer(
	q_from: np.ndarray,
	q_to: np.ndarray,
	step_size: float,
	wrap_mask: np.ndarray,
) -> np.ndarray:
	delta = _joint_delta(q_from, q_to, wrap_mask)
	dist = float(np.linalg.norm(delta))
	if dist <= step_size or dist < 1e-12:
		return np.asarray(q_to, dtype=np.float64).reshape(-1).copy()
	return np.asarray(q_from, dtype=np.float64).reshape(-1) + (step_size / dist) * delta


def _segment_collision_free(
	q_a: np.ndarray,
	q_b: np.ndarray,
	is_valid: IsValidFn,
	*,
	resolution: float,
	wrap_mask: np.ndarray,
) -> bool:
	"""Check interpolated edge along C-space straight (wrapped where needed).

	Uses at least one interior sample on every non-trivial edge so a thin
	obstacle between free endpoints cannot be missed when ``dist <= resolution``.
	"""
	delta = _joint_delta(q_a, q_b, wrap_mask)
	dist = float(np.linalg.norm(delta))
	if dist < 1e-12:
		return bool(is_valid(q_b))
	n = max(2, int(np.ceil(dist / max(resolution, 1e-6))))
	qa = np.asarray(q_a, dtype=np.float64).reshape(-1)
	for i in range(1, n + 1):
		alpha = float(i) / float(n)
		q = qa + alpha * delta
		if not is_valid(q):
			return False
	return True


def _nearest(nodes: List[np.ndarray], q: np.ndarray, wrap_mask: np.ndarray) -> int:
	best_i = 0
	best_d = float("inf")
	for i, n in enumerate(nodes):
		d = float(np.linalg.norm(_joint_delta(n, q, wrap_mask)))
		if d < best_d:
			best_d = d
			best_i = i
	return best_i


def _reconstruct(
	nodes: List[np.ndarray],
	parents: List[int],
	idx: int,
) -> List[np.ndarray]:
	path: List[np.ndarray] = []
	cur = idx
	guard = 0
	while cur >= 0 and guard < len(nodes) + 2:
		path.append(nodes[cur].copy())
		cur = parents[cur]
		guard += 1
	path.reverse()
	return path


def _shortcut(
	path: List[np.ndarray],
	is_valid: IsValidFn,
	*,
	resolution: float,
	wrap_mask: np.ndarray,
) -> List[np.ndarray]:
	"""Deterministic greedy farthest-vertex shortcut (single pass)."""
	if len(path) <= 2:
		return path
	out = [path[0].copy()]
	i = 0
	while i < len(path) - 1:
		j = len(path) - 1
		advanced = False
		while j > i + 1:
			if _segment_collision_free(
				path[i], path[j], is_valid, resolution=resolution, wrap_mask=wrap_mask
			):
				out.append(path[j].copy())
				i = j
				advanced = True
				break
			j -= 1
		if not advanced:
			out.append(path[i + 1].copy())
			i += 1
	cleaned: List[np.ndarray] = [out[0]]
	for q in out[1:]:
		if float(np.linalg.norm(_joint_delta(cleaned[-1], q, wrap_mask))) > 1e-9:
			cleaned.append(q)
	return cleaned


def _shortcut_iterative(
	path: List[np.ndarray],
	is_valid: IsValidFn,
	*,
	resolution: float,
	wrap_mask: np.ndarray,
	rng: np.random.Generator,
	max_iterations: int = _SHORTCUT_MAX_ITER,
	deadline: Optional[float] = None,
) -> List[np.ndarray]:
	"""Random C-space path pruning / shortcutting.

	For each iteration, pick non-adjacent waypoints ``qi``, ``qj``, interpolate
	the direct wrap-aware chord, and delete intermediates if the edge is valid.
	"""
	if len(path) <= 2:
		return path
	cur = [p.copy() for p in path]
	for _ in range(max(1, int(max_iterations))):
		if deadline is not None and time.perf_counter() >= deadline:
			break
		n = len(cur)
		if n <= 2:
			break
		# Non-adjacent: j >= i + 2 so there is at least one node to prune.
		i = int(rng.integers(0, n - 2))
		j = int(rng.integers(i + 2, n))
		# Accept whenever the direct chord is collision-free (prunes detours).
		if not _segment_collision_free(
			cur[i], cur[j], is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			continue
		cur = cur[: i + 1] + cur[j:]
	# Final cleanup of near-duplicates.
	cleaned: List[np.ndarray] = [cur[0]]
	for q in cur[1:]:
		if float(np.linalg.norm(_joint_delta(cleaned[-1], q, wrap_mask))) > 1e-9:
			cleaned.append(q)
	return cleaned


def _partial_shortcut(
	path: List[np.ndarray],
	is_valid: IsValidFn,
	*,
	resolution: float,
	wrap_mask: np.ndarray,
	rng: np.random.Generator,
	max_iterations: int = _PARTIAL_SHORTCUT_MAX_ITER,
	deadline: Optional[float] = None,
) -> List[np.ndarray]:
	"""OMPL-style partial shortcut: try chords, else a random Steiner midpoint.

	When the direct chord between ``i`` and ``j`` is blocked or not shorter,
	insert a random point near the midpoint of the wrap-aware chord and accept
	``i → mid → j`` if both edges are free and the replacement is shorter.
	"""
	if len(path) <= 2:
		return path
	cur = [p.copy() for p in path]
	for _ in range(max(1, int(max_iterations))):
		if deadline is not None and time.perf_counter() >= deadline:
			break
		n = len(cur)
		if n <= 2:
			break
		i = int(rng.integers(0, n - 1))
		j = int(rng.integers(i + 1, n))
		if j <= i + 1:
			continue
		sub_len = 0.0
		for k in range(i, j):
			sub_len += float(np.linalg.norm(_joint_delta(cur[k], cur[k + 1], wrap_mask)))
		qa = cur[i]
		qb = cur[j]
		delta = _joint_delta(qa, qb, wrap_mask)
		chord = float(np.linalg.norm(delta))
		if chord < 1e-12:
			continue

		# Prefer a free direct chord when it shortens the sub-path.
		if chord < sub_len - 1e-12 and _segment_collision_free(
			qa, qb, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			cur = cur[: i + 1] + cur[j:]
			continue

		# Steiner midpoint: offset perpendicular-ish noise in joint space.
		alpha = float(rng.uniform(0.25, 0.75))
		mid = np.asarray(qa, dtype=np.float64).reshape(-1) + alpha * delta
		# Small isotropic noise relative to chord length.
		noise_scale = 0.15 * chord
		if noise_scale > 1e-9:
			mid = mid + rng.normal(0.0, noise_scale, size=mid.shape)
		# Keep mid near the chord box (no joint-limit clamp here — is_valid covers it).
		via_len = float(np.linalg.norm(_joint_delta(qa, mid, wrap_mask))) + float(
			np.linalg.norm(_joint_delta(mid, qb, wrap_mask))
		)
		if via_len >= sub_len - 1e-12:
			continue
		if not _segment_collision_free(
			qa, mid, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			continue
		if not _segment_collision_free(
			mid, qb, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			continue
		cur = cur[: i + 1] + [mid.copy()] + cur[j:]

	cleaned: List[np.ndarray] = [cur[0]]
	for q in cur[1:]:
		if float(np.linalg.norm(_joint_delta(cleaned[-1], q, wrap_mask))) > 1e-9:
			cleaned.append(q)
	return cleaned


def _simplify_path(
	path: List[np.ndarray],
	is_valid: IsValidFn,
	*,
	resolution: float,
	wrap_mask: np.ndarray,
	rng: np.random.Generator,
	deadline: Optional[float] = None,
	max_iterations: int = _SHORTCUT_MAX_ITER,
) -> List[np.ndarray]:
	"""Greedy prune → ~100-iter random C-space shortcut → partial/Steiner.

	If ``deadline`` has already expired (common after RRT* fills the plan
	budget), a minimum simplify window is granted so pruning still runs.
	"""
	if deadline is not None and time.perf_counter() >= deadline:
		deadline = time.perf_counter() + _SIMPLIFY_MIN_BUDGET_S
	out = _shortcut(path, is_valid, resolution=resolution, wrap_mask=wrap_mask)
	out = _shortcut_iterative(
		out,
		is_valid,
		resolution=resolution,
		wrap_mask=wrap_mask,
		rng=rng,
		max_iterations=max_iterations,
		deadline=deadline,
	)
	return _partial_shortcut(
		out,
		is_valid,
		resolution=resolution,
		wrap_mask=wrap_mask,
		rng=rng,
		deadline=deadline,
	)


def _rrt_connect_once(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	limits: Limits,
	is_valid: IsValidFn,
	*,
	deadline: float,
	step_size: float,
	goal_bias: float,
	line_bias: float,
	wrap_mask: np.ndarray,
	resolution: float,
	rng: np.random.Generator,
) -> TransitionResult:
	"""Single bidirectional RRT-Connect attempt (no shortcutting)."""
	dof = int(q_start.size)
	nodes_a: List[np.ndarray] = [q_start.copy()]
	parents_a: List[int] = [-1]
	nodes_b: List[np.ndarray] = [q_goal.copy()]
	parents_b: List[int] = [-1]

	def extend(
		nodes: List[np.ndarray],
		parents: List[int],
		q_target: np.ndarray,
	) -> Tuple[str, int]:
		ni = _nearest(nodes, q_target, wrap_mask)
		q_near = nodes[ni]
		q_new = _steer(q_near, q_target, step_size, wrap_mask)
		q_new = _clamp_to_limits(q_new, limits)
		if not _segment_collision_free(
			q_near, q_new, is_valid, resolution=resolution, wrap_mask=wrap_mask
		):
			return "trapped", ni
		nodes.append(q_new)
		parents.append(ni)
		new_i = len(nodes) - 1
		if float(np.linalg.norm(_joint_delta(q_new, q_target, wrap_mask))) <= step_size * 1.01:
			return "reached", new_i
		return "advanced", new_i

	def connect(
		nodes: List[np.ndarray],
		parents: List[int],
		q_target: np.ndarray,
	) -> Tuple[str, int]:
		status = "advanced"
		idx = -1
		while status == "advanced":
			if time.perf_counter() >= deadline:
				return "trapped", idx
			status, idx = extend(nodes, parents, q_target)
		return status, idx

	swap = False
	while time.perf_counter() < deadline:
		r = float(rng.random())
		if r < goal_bias:
			q_rand = nodes_b[0].copy() if not swap else nodes_a[0].copy()
		elif r < goal_bias + line_bias:
			q_rand = _sample_near_line(
				q_start, q_goal, limits[:dof], wrap_mask, rng
			)
		else:
			q_rand = _sample_uniform(limits[:dof], rng)

		if not swap:
			status_a, idx_a = extend(nodes_a, parents_a, q_rand)
			if status_a == "trapped":
				continue
			status_b, idx_b = connect(nodes_b, parents_b, nodes_a[idx_a])
			if status_b == "reached":
				path_a = _reconstruct(nodes_a, parents_a, idx_a)
				path_b = _reconstruct(nodes_b, parents_b, idx_b)
				path_b.reverse()
				merged = path_a + path_b[1:]
				merged[0] = q_start.copy()
				merged[-1] = q_goal.copy()
				return merged, ""
		else:
			status_b, idx_b = extend(nodes_b, parents_b, q_rand)
			if status_b == "trapped":
				continue
			status_a, idx_a = connect(nodes_a, parents_a, nodes_b[idx_b])
			if status_a == "reached":
				path_a = _reconstruct(nodes_a, parents_a, idx_a)
				path_b = _reconstruct(nodes_b, parents_b, idx_b)
				path_b.reverse()
				merged = path_a + path_b[1:]
				merged[0] = q_start.copy()
				merged[-1] = q_goal.copy()
				return merged, ""

		if len(nodes_a) > len(nodes_b):
			swap = True
		elif len(nodes_b) > len(nodes_a):
			swap = False
		else:
			swap = not swap

	return None, "timed out"


def rrt_connect(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	limits: Limits,
	is_valid: IsValidFn,
	*,
	time_limit_s: float = 2.0,
	step_size: Optional[float] = None,
	goal_bias: float = 0.3,
	line_bias: float = _DEFAULT_LINE_BIAS,
	simplify: bool = True,
	seed: Optional[int] = None,
	max_successful_attempts: int = _MAX_SUCCESSFUL_ATTEMPTS,
	resolution: Optional[float] = None,
) -> TransitionResult:
	"""Bidirectional RRT-Connect in a box-bounded configuration space.

	Uses the full time budget for multiple independent attempts, then keeps the
	shortest path after greedy + iterative shortcutting.

	Returns ``(path, "")`` on success or ``(None, reason)`` on failure.
	Full-range joints use shortest-angle metrics; limited joints use Euclidean.
	``resolution`` is absolute C-space edge sample spacing (rad L2).
	"""
	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	q_goal = np.asarray(q_goal, dtype=np.float64).reshape(-1)
	dof = int(q_start.size)
	if q_goal.size != dof or len(limits) < dof:
		return None, "start/goal DOF mismatch or missing joint limits"

	wrap_mask = _wrap_mask(limits, dof)
	ranges = np.array([hi - lo for lo, hi in limits[:dof]], dtype=np.float64)
	range_norm = float(np.linalg.norm(np.maximum(ranges, 1e-6)))
	if step_size is None:
		step_size = 0.1 * range_norm
	step_size = float(max(1e-4, step_size))
	# Absolute spacing (not a fraction of the joint box). Exposed as
	# MotionPlanner.rrt_edge_resolution_rad; default matches densify.
	if resolution is None:
		resolution = float(_EDGE_RESOLUTION_RAD)
	resolution = float(max(1e-4, resolution))
	goal_bias = float(max(0.0, min(1.0, goal_bias)))
	line_bias = float(max(0.0, min(1.0 - goal_bias, line_bias)))

	q_start = _clamp_to_limits(q_start, limits)
	q_goal = _clamp_to_limits(q_goal, limits)

	start_ok = bool(is_valid(q_start))
	goal_ok = bool(is_valid(q_goal))
	if not start_ok and not goal_ok:
		return None, "transition start and goal configs are in collision (or out of limits)"
	if not start_ok:
		return None, "transition start config (end of prior segment) is in collision"
	if not goal_ok:
		return None, "transition goal config (start of next segment) is in collision"

	if float(np.linalg.norm(_joint_delta(q_start, q_goal, wrap_mask))) < 1e-9:
		return [q_start.copy(), q_goal.copy()], ""

	plan_deadline, simplify_deadline = _split_plan_simplify_deadlines(
		time_limit_s, simplify=simplify
	)
	rng = np.random.default_rng(seed)

	# Fast path: C-space line is free (common when segments are nearby in joint space).
	if _segment_collision_free(
		q_start, q_goal, is_valid, resolution=resolution, wrap_mask=wrap_mask
	):
		path = [q_start.copy(), q_goal.copy()]
		if simplify:
			path = _simplify_path(
				path,
				is_valid,
				resolution=resolution,
				wrap_mask=wrap_mask,
				rng=rng,
				deadline=simplify_deadline,
			)
		return path, ""

	candidates: List[List[np.ndarray]] = []
	last_reason = "timed out"
	max_ok = max(1, int(max_successful_attempts))

	while time.perf_counter() < plan_deadline and len(candidates) < max_ok:
		# Fresh RNG stream per attempt for diversity.
		attempt_seed = int(rng.integers(0, 2**31 - 1))
		attempt_rng = np.random.default_rng(attempt_seed)
		path, reason = _rrt_connect_once(
			q_start,
			q_goal,
			limits,
			is_valid,
			deadline=plan_deadline,
			step_size=step_size,
			goal_bias=goal_bias,
			line_bias=line_bias,
			wrap_mask=wrap_mask,
			resolution=resolution,
			rng=attempt_rng,
		)
		if path is not None:
			candidates.append(path)
		else:
			last_reason = reason or "timed out"

	if not candidates:
		return (
			None,
			f"RRT-Connect timed out after {time_limit_s:.2f}s "
			f"(C-space path between segment ends is not a free straight line; "
			f"try raising planning_time_limit_s)",
		)

	# Shortcut every candidate and keep the shortest wrap-aware path.
	best: Optional[List[np.ndarray]] = None
	best_len = float("inf")
	for raw in candidates:
		if simplify:
			improved = _simplify_path(
				raw,
				is_valid,
				resolution=resolution,
				wrap_mask=wrap_mask,
				rng=rng,
				deadline=simplify_deadline,
			)
		else:
			improved = raw
		length = _path_length(improved, wrap_mask)
		if length < best_len:
			best_len = length
			best = improved

	if best is None:
		return None, last_reason
	return best, ""


def plan_joint_transition(
	q_start: np.ndarray,
	q_goal: np.ndarray,
	collision_world,
	*,
	time_limit_s: float,
	simplify: bool,
	resolution_rad: float = _EDGE_RESOLUTION_RAD,
	goal_bias: float = 0.15,
	workspace_center_m: Optional[np.ndarray] = None,
	workspace_radius_m: Optional[float] = None,
	tool_link: str = "",
	T_ee_tcp: Optional[np.ndarray] = None,
) -> TransitionResult:
	"""Adapter matching the shared pipeline transition_fn contract (RRT-Connect)."""
	from MotionStudio.core.robot.planning.imove.workspace_limit import (
		expand_radius_for_endpoints,
		make_workspace_is_valid,
	)

	q_start = np.asarray(q_start, dtype=np.float64).reshape(-1)
	dof = int(q_start.size)
	reset = getattr(collision_world, "reset_validity_timing", None)
	if callable(reset):
		reset()
	if collision_world is not None:
		limits = collision_world.joint_limits()

		def is_valid(q: np.ndarray) -> bool:
			return bool(collision_world.is_state_valid(q))
	else:
		limits = [(-float(np.pi), float(np.pi)) for _ in range(dof)]

		def is_valid(q: np.ndarray) -> bool:
			return True

	if (
		workspace_center_m is not None
		and workspace_radius_m is not None
		and tool_link
		and collision_world is not None
	):
		radius = expand_radius_for_endpoints(
			workspace_center_m,
			float(workspace_radius_m),
			collision_world=collision_world,
			q_start=q_start,
			q_goal=q_goal,
			tool_link=tool_link,
			T_ee_tcp=T_ee_tcp,
		)
		is_valid = make_workspace_is_valid(
			is_valid,
			collision_world=collision_world,
			center_m=workspace_center_m,
			radius_m=radius,
			tool_link=tool_link,
			T_ee_tcp=T_ee_tcp,
		)

	t0 = time.perf_counter()
	path, reason = rrt_connect(
		q_start,
		q_goal,
		limits,
		is_valid,
		time_limit_s=time_limit_s,
		simplify=simplify,
		resolution=float(resolution_rad),
		goal_bias=float(goal_bias),
	)
	elapsed = time.perf_counter() - t0
	summary = getattr(collision_world, "validity_timing_summary", None)
	if callable(summary):
		print(
			f"[RRT-Connect validity] transition done in {elapsed:.3f}s — {summary()}",
			flush=True,
		)
	return path, reason

"""Motion planner backend protocol and plain-data request/result DTOs."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

import numpy as np

from MotionStudio.core.robot.planning.trajectory import JointTrajectory


@dataclass
class PlanRequest:
	"""A motion-planning query expressed entirely in plain data.

	Built on the main thread and handed to a worker — must not hold Qt/ECS
	objects. Cartesian path poses use URDF units: metres + radians.
	"""

	job_entity_id: str
	robot_entity_id: str
	urdf_path: str
	root_link: str
	tool_link: str
	joint_names: List[str]
	q_seed: np.ndarray
	joints: List[Dict[str, Any]] = field(default_factory=list)
	# Robot-frame waypoint segments: each pose is (x,y,z,rx,ry,rz) metres + rad XYZ Euler.
	waypoint_segments_m_rad: List[List[tuple]] = field(default_factory=list)
	segment_speed_multipliers: List[float] = field(default_factory=list)
	path_speed_m_s: float = 0.25
	path_acceleration_m_s2: float = 1.2
	analytic_solver_path: str = ""
	backend: str = "ompl"
	planning_time_limit_s: float = 60.0
	process_sample_spacing_m: float = 0.01
	simplify_path: bool = True
	# C-space edge sample spacing (rad L2) for RRT validity / densify.
	rrt_edge_resolution_rad: float = 0.05
	# imove only: "RRT-Connect" or "RRT*" (Informed RRT*).
	imove_algorithm: str = "RRT*"
	# imove only: probability of sampling the goal each RRT iteration.
	imove_goal_bias: float = 0.15
	# imove only: workspace sphere diameter as a multiple of the job AABB diagonal.
	imove_workspace_bound_diameter: float = 2.0
	# Reject sudden config changes between consecutive process samples (0 = off).
	max_joint_jump_rad: float = 2.0
	transition_joint_speed_rad_s: float = 1.0
	# 4x4 SE3 tool_link -> TCP offset in metres (identity if no TCP).
	T_ee_tcp: np.ndarray = field(default_factory=lambda: np.eye(4, dtype=np.float64))
	# Opaque collision oracle. Production uses ``PlanningCollisionWorld``
	# (main-thread snapshot of CollisionMatrix + transforms; FCL on the worker).
	# ``LiveViewportCollisionOracle`` remains available for diagnostics/tests only.
	collision_world: Any = None
	position_tolerance_m: float = 1e-3
	orientation_tolerance_rad: float = 1e-2


@dataclass
class PlanResult:
	"""Outcome of a :class:`PlanRequest`."""

	success: bool
	message: str = ""
	trajectory: JointTrajectory = field(default_factory=JointTrajectory)
	# On failure: joint vector to pose on the robot for debugging (actuated order).
	failure_q: Optional[np.ndarray] = None
	# Collision oracle used during planning (offline snapshot by default).
	collision_world: Any = None


@runtime_checkable
class MotionPlannerBackend(Protocol):
	"""Pluggable motion-planner interface (OMPL now, CuRobo later).

	Implementations must be safe to call from a worker thread and must not
	touch the scene graph.
	"""

	def is_available(self) -> bool:
		"""True when the backend's dependencies are importable."""
		...

	def plan(self, request: PlanRequest) -> PlanResult:
		"""Plan a joint-space trajectory for the request."""
		...

	def invalidate_cache(self, key: str) -> None:
		"""Drop any cached model state for the given key (e.g. URDF path)."""
		...

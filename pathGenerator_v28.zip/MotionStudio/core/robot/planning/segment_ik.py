"""Continuous seeded IK along densified Cartesian path segments.

Step 1 of the imove pipeline: verify each process segment by trying analytic
start IK branches in order; on mid-segment failure, re-trace the whole segment
from the next start branch until branches are exhausted.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

from MotionStudio.core.robot.ik.analytic_backend import AnalyticIKBackend
from MotionStudio.core.robot.ik.ik_backend import IKSolveRequest, IKSolveResult
from MotionStudio.core.robot.ik.ik_frames import project_to_se3
from MotionStudio.core.robot.ik._fk_verify import joint_wrap_distance
from MotionStudio.core.robot.planning.path_sampling import densify_segment, pose6_to_matrix
from MotionStudio.core.robot.planning.planner_backend import PlanRequest
from MotionStudio.core.robot.planning.trajectory import (
	JointSample,
	assign_times_cartesian_speed,
	joint_distance,
	wrap_mask_from_joints,
)


def _q_from_joint_map(joint_names: List[str], values: Dict[str, float]) -> np.ndarray:
	return np.array([float(values.get(n, 0.0)) for n in joint_names], dtype=np.float64)


def _goal_ee_from_tcp_pose(T_tcp_base: np.ndarray, T_ee_tcp: np.ndarray) -> np.ndarray:
	"""Aim tool_link so TCP reaches T_tcp_base: T_ee = T_tcp @ inv(T_ee_tcp)."""
	T_ee_tcp = project_to_se3(T_ee_tcp)
	return project_to_se3(T_tcp_base @ np.linalg.inv(T_ee_tcp))


def _ik_once(
	ik: AnalyticIKBackend,
	request_template: PlanRequest,
	T_goal: np.ndarray,
	q_seed: np.ndarray,
	*,
	enumerate_all: bool,
) -> IKSolveResult:
	req = IKSolveRequest(
		robot_entity_id=request_template.robot_entity_id,
		urdf_path=request_template.urdf_path,
		joint_names=list(request_template.joint_names),
		q_seed=np.asarray(q_seed, dtype=np.float64),
		T_goal_base=project_to_se3(T_goal),
		ee_link=request_template.tool_link,
		position_tolerance_m=float(request_template.position_tolerance_m),
		orientation_tolerance_rad=float(request_template.orientation_tolerance_rad),
		root_link=request_template.root_link,
		joints=[dict(j) for j in request_template.joints],
		analytic_solver_path=request_template.analytic_solver_path,
		enumerate_all_solutions=enumerate_all,
	)
	return ik.solve(req)


def _edge_resolution(request: PlanRequest) -> float:
	return max(1e-4, float(getattr(request, "rrt_edge_resolution_rad", 0.05)))


def _edge_valid(collision_world, q_prev: np.ndarray, q_next: np.ndarray, *, resolution_rad: float) -> bool:
	"""True when the C-space edge from ``q_prev`` to ``q_next`` is collision-free."""
	if collision_world is None:
		return True
	if hasattr(collision_world, "first_invalid_on_segment"):
		ok, _fail_q, _detail = collision_world.first_invalid_on_segment(
			q_prev, q_next, resolution_rad=resolution_rad
		)
		return bool(ok)
	if hasattr(collision_world, "is_segment_valid"):
		return bool(
			collision_world.is_segment_valid(
				q_prev, q_next, resolution_rad=resolution_rad
			)
		)
	# Point-only fallback when the oracle has no edge check.
	return bool(collision_world.is_state_valid(q_next))


def _candidate_point_ok(collision_world, q: np.ndarray) -> bool:
	if collision_world is None:
		return True
	return bool(collision_world.is_state_valid(q))


def _candidate_point_and_edge_ok(
	collision_world,
	q_prev: np.ndarray,
	q: np.ndarray,
	*,
	resolution_rad: float,
) -> bool:
	if not _candidate_point_ok(collision_world, q):
		return False
	return _edge_valid(collision_world, q_prev, q, resolution_rad=resolution_rad)


def _pick_edge_collision_free(
	candidates: List[Dict[str, float]],
	seed_map: Dict[str, float],
	joint_names: List[str],
	collision_world,
	prev_q: np.ndarray,
	*,
	require_edge: bool = True,
	resolution_rad: float = 0.05,
) -> Tuple[Optional[Dict[str, float]], Optional[np.ndarray], int]:
	"""Pick nearest-to-seed candidate that passes collision filters.

	When ``require_edge`` is True, the candidate must be point-valid and the
	C-space edge from ``prev_q`` must be clear. When False, only the point is
	checked (inter-segment entry — RRT owns the connection).

	Returns ``(picked_dict_or_None, blocked_q, n_candidates)``.
	``blocked_q`` is the nearest-to-seed kinematic candidate that failed collision
	(for viewport pose-at-failure), or None when no candidates existed.
	"""
	if not candidates:
		return None, None, 0
	ordered = sorted(
		candidates,
		key=lambda c: joint_wrap_distance(c, seed_map, joint_names),
	)
	blocked_q: Optional[np.ndarray] = None
	for cand in ordered:
		q = _q_from_joint_map(joint_names, cand)
		ok = (
			_candidate_point_and_edge_ok(
				collision_world, prev_q, q, resolution_rad=resolution_rad
			)
			if require_edge
			else _candidate_point_ok(collision_world, q)
		)
		if ok:
			return cand, blocked_q, len(ordered)
		if blocked_q is None:
			blocked_q = q.copy()
	return None, blocked_q, len(ordered)


def _collect_ik_candidates(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	T_tcp_base: np.ndarray,
	q_seed: np.ndarray,
) -> Tuple[List[Dict[str, float]], str]:
	"""Enumerate analytic branches for a TCP pose (nearest-first ordering later).

	Always uses ``enumerate_all=True`` so planning never inherits a teleop
	``max_solutions=1`` call style.
	"""
	T_goal = _goal_ee_from_tcp_pose(T_tcp_base, request.T_ee_tcp)
	result = _ik_once(ik, request, T_goal, q_seed, enumerate_all=True)
	cands: List[Dict[str, float]] = []
	if result.all_solutions:
		cands.extend(list(result.all_solutions))
	if result.success and result.joint_values and result.joint_values not in cands:
		cands.insert(0, result.joint_values)
	return cands, (result.message or "")


def solve_pose_continuous(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	T_tcp_base: np.ndarray,
	q_seed: np.ndarray,
	*,
	require_edge_from_seed: bool = True,
) -> Tuple[Optional[np.ndarray], str, Optional[np.ndarray]]:
	"""Solve IK for one TCP pose with seed continuity + collision filtering.

	When ``require_edge_from_seed`` is True (intra-segment continuity), candidates
	must also have a collision-free C-space edge from ``q_seed``. When False
	(inter-segment entry), only the goal config must be collision-free — the
	transition planner (RRT) connects from the previous segment end.

	Returns ``(q_or_None, message, blocked_q)``. ``blocked_q`` is set when kinematic
	candidates existed but all were blocked by collision (for failure posing).
	"""
	joint_names = list(request.joint_names)
	seed_map = {n: float(q_seed[i]) if i < len(q_seed) else 0.0 for i, n in enumerate(joint_names)}
	cw = request.collision_world
	prev_q = np.asarray(q_seed, dtype=np.float64).reshape(-1)
	res = _edge_resolution(request)

	cands, ik_msg = _collect_ik_candidates(ik, request, T_tcp_base, q_seed)
	if not cands:
		return None, ik_msg or "no kinematic solution reaches this pose", None

	# Fast path: try nearest seed solution first without full sort work if sole cand.
	picked, blocked_q, n_cands = _pick_edge_collision_free(
		cands,
		seed_map,
		joint_names,
		cw,
		prev_q,
		require_edge=require_edge_from_seed,
		resolution_rad=res,
	)
	if picked is not None:
		return _q_from_joint_map(joint_names, picked), "", None

	pair_extra = ""
	if cw is not None and blocked_q is not None and hasattr(cw, "find_colliding_pair"):
		try:
			pair = cw.find_colliding_pair(blocked_q)
			if pair is not None:
				pair_extra = f" pair={pair}"
		except Exception:
			pass
	if require_edge_from_seed:
		detail = (
			f"{n_cands} branch(es) found, all blocked by collision when connecting "
			f"from the previous sample{pair_extra}"
		)
	else:
		detail = (
			f"{n_cands} branch(es) found, all blocked by collision at this pose"
			f"{pair_extra}"
		)
	return None, detail, blocked_q


def _enumerate_start_qs(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	T_tcp_base: np.ndarray,
	q_seed: np.ndarray,
	*,
	require_edge: bool,
) -> Tuple[List[np.ndarray], str, Optional[np.ndarray]]:
	"""Valid start configs for sample 0, nearest-to-seed first."""
	joint_names = list(request.joint_names)
	seed_map = {n: float(q_seed[i]) if i < len(q_seed) else 0.0 for i, n in enumerate(joint_names)}
	cw = request.collision_world
	prev_q = np.asarray(q_seed, dtype=np.float64).reshape(-1)
	res = _edge_resolution(request)

	cands, ik_msg = _collect_ik_candidates(ik, request, T_tcp_base, q_seed)
	if not cands:
		return [], ik_msg or "no kinematic solution reaches this pose", None

	ordered = sorted(
		cands,
		key=lambda c: joint_wrap_distance(c, seed_map, joint_names),
	)
	starts: List[np.ndarray] = []
	blocked_q: Optional[np.ndarray] = None
	for cand in ordered:
		q = _q_from_joint_map(joint_names, cand)
		ok = (
			_candidate_point_and_edge_ok(
				cw, prev_q, q, resolution_rad=res
			)
			if require_edge
			else _candidate_point_ok(cw, q)
		)
		if ok:
			# Deduplicate near-identical starts.
			if any(float(np.linalg.norm(q - s)) < 1e-6 for s in starts):
				continue
			starts.append(q.copy())
		elif blocked_q is None:
			blocked_q = q.copy()
	if not starts:
		return [], (
			f"{len(ordered)} branch(es) found, all blocked by collision "
			f"{'when connecting from the previous sample' if require_edge else 'at this pose'}"
		), blocked_q
	return starts, "", blocked_q


def _trace_segment_from_start(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	poses: List[tuple],
	cart_lengths: List[float],
	q0: np.ndarray,
	*,
	wrap_mask: np.ndarray,
	max_jump: float,
) -> Tuple[Optional[List[np.ndarray]], Optional[np.ndarray], str, int]:
	"""Walk samples 1…N from fixed ``q0``. Returns (q_list, fail_q, err, fail_sample)."""
	q_list: List[np.ndarray] = [np.asarray(q0, dtype=np.float64).reshape(-1).copy()]
	q_cur = q_list[0]
	for i in range(1, len(poses)):
		T_tcp = pose6_to_matrix(poses[i])
		q_next, err, blocked_q = solve_pose_continuous(
			ik,
			request,
			T_tcp,
			q_cur,
			require_edge_from_seed=True,
		)
		if q_next is None:
			return None, (blocked_q if blocked_q is not None else q_cur), err, i

		if max_jump > 0.0:
			jump = joint_distance(q_cur, q_next, wrap_mask)
			if jump > max_jump + 1e-9:
				return (
					None,
					q_next.copy(),
					(
						f"sudden config change ‖Δq‖={jump:.3f} rad "
						f"exceeds max_joint_jump_rad={max_jump:.3f}"
					),
					i,
				)

		q_list.append(q_next)
		q_cur = q_next
	return q_list, None, "", -1


def trace_segment_ik(
	ik: AnalyticIKBackend,
	request: PlanRequest,
	segment_waypoints: List[tuple],
	segment_index: int,
	q_seed: np.ndarray,
	t0: float,
) -> Tuple[Optional[List[JointSample]], np.ndarray, str]:
	"""Densify one segment; exhaust start IK branches with full re-traces."""
	if not segment_waypoints:
		return [], np.asarray(q_seed, dtype=np.float64), ""

	poses, cart_lengths = densify_segment(
		segment_waypoints, request.process_sample_spacing_m
	)
	if not poses:
		return [], np.asarray(q_seed, dtype=np.float64), ""

	joint_names = list(request.joint_names)
	wrap_mask = wrap_mask_from_joints(joint_names, request.joints)
	max_jump = float(getattr(request, "max_joint_jump_rad", 2.0))
	# Sample 0 is always point-only: RRT owns current-pose → first waypoint and
	# inter-segment gaps. Seed only biases which start branch is tried first.
	T0 = pose6_to_matrix(poses[0])
	starts, start_err, start_blocked = _enumerate_start_qs(
		ik,
		request,
		T0,
		np.asarray(q_seed, dtype=np.float64),
		require_edge=False,
	)
	if not starts:
		pose_q = start_blocked if start_blocked is not None else np.asarray(q_seed)
		return None, np.asarray(pose_q, dtype=np.float64), (
			f"Process IK failed on segment {segment_index} sample 0: {start_err}"
		)

	last_err = ""
	last_fail_q = starts[0]
	last_fail_i = 0
	n_starts = len(starts)

	for bi, q0 in enumerate(starts):
		if len(poses) == 1:
			q_list = [q0.copy()]
			fail_q = None
			err = ""
			fail_i = -1
		else:
			q_list, fail_q, err, fail_i = _trace_segment_from_start(
				ik,
				request,
				poses,
				cart_lengths,
				q0,
				wrap_mask=wrap_mask,
				max_jump=max_jump,
			)
		if q_list is not None:
			lengths_used: List[float] = []
			for i in range(1, len(poses)):
				if i - 1 < len(cart_lengths):
					lengths_used.append(cart_lengths[i - 1])
				else:
					lengths_used.append(
						float(
							np.linalg.norm(
								np.array(poses[i][:3]) - np.array(poses[i - 1][:3])
							)
						)
					)
			mult = 1.0
			if segment_index < len(request.segment_speed_multipliers):
				mult = max(1e-6, float(request.segment_speed_multipliers[segment_index]))
			speed = max(1e-6, float(request.path_speed_m_s) * mult)
			samples, _t_end = assign_times_cartesian_speed(
				q_list,
				lengths_used,
				kind="process",
				segment_index=segment_index,
				t0=t0,
				linear_speed_m_s=speed,
			)
			return samples, q_list[-1], ""

		last_err = err
		last_fail_i = fail_i
		if fail_q is not None:
			last_fail_q = fail_q

	return None, np.asarray(last_fail_q, dtype=np.float64), (
		f"Process IK failed on segment {segment_index} sample {last_fail_i}: {last_err} "
		f"(exhausted {n_starts} start IK branch(es))"
	)

"""Motion planner backend factory — no silent fallback between planners."""

from __future__ import annotations

from typing import Dict

from MotionStudio.core.robot.planning.planner_backend import (
	MotionPlannerBackend,
	PlanRequest,
	PlanResult,
)


class MotionPlannerError(RuntimeError):
	"""Raised when the selected motion-planner backend cannot be used."""


def make_planner_backend(name: str) -> MotionPlannerBackend:
	"""Construct a planner backend by name.

	Supported: ``ompl`` (default), ``imove`` (numpy RRT-Connect / Informed RRT*). Unknown names
	raise :class:`MotionPlannerError` (no silent remap).
	"""
	key = (name or "").strip().lower()
	if key == "ompl":
		from MotionStudio.core.robot.planning.ompl_backend import OmplMotionPlannerBackend

		return OmplMotionPlannerBackend()
	if key == "imove":
		from MotionStudio.core.robot.planning.imove import ImoveMotionPlannerBackend

		return ImoveMotionPlannerBackend()
	raise MotionPlannerError(
		f"Unknown motion planner backend '{name}'. Supported backends: ompl, imove."
	)


def plan_with_backend(
	backend_name: str,
	request: PlanRequest,
	backend_cache: Dict[str, MotionPlannerBackend],
) -> PlanResult:
	"""Run planning with exactly one backend — never falls back to another."""
	key = (backend_name or "").strip().lower()
	backend = backend_cache.get(key)
	if backend is None:
		backend = make_planner_backend(key)
		backend_cache[key] = backend

	if not backend.is_available():
		raise MotionPlannerError(
			f"Motion planner backend '{key}' is not available (dependency not installed)."
		)

	result = backend.plan(request)
	msg_l = (result.message or "").lower()
	if not result.success and (
		"not installed" in msg_l
		or ("not available" in msg_l and "ssik" in msg_l)
		or "analytic solver path is required" in msg_l
	):
		raise MotionPlannerError(result.message or f"Motion planner '{key}' failed.")
	return result

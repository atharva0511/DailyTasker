from __future__ import annotations

import math
from typing import List, Optional, Tuple

from PyQt6.QtCore import QPoint, QRect, QSize, Qt, QTimer
from PyQt6.QtGui import QColor, QFont, QFontMetrics, QMouseEvent, QPainter, QPen
from PyQt6.QtWidgets import QDialog, QScrollArea, QSizePolicy, QVBoxLayout, QWidget

from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.scene.scene import Scene
from MotionStudio.ui.inspector.inspector_dialog_utils import add_close_button_row

_CELL_SIZE = 20
_HEADER_PAD = 6
_DIAGONAL_DEG = 45.0


def _diagonal_label_extents(label_width: float) -> Tuple[float, float]:
	rad = math.radians(_DIAGONAL_DEG)
	return label_width * math.cos(rad), label_width * math.sin(rad)


class _GroupInternalMatrixGrid(QWidget):
	"""Triangular matrix for entity pairs within one collision group."""

	def __init__(self, scene: Scene, group_name: str, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._scene = scene
		self._group_name = group_name
		self._entities: List[Tuple[str, str]] = []
		self._hover_cell: Optional[Tuple[int, int]] = None
		self.setMouseTracking(True)
		self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
		self._refresh_entities()

		scene.events.entity_added.connect(self._on_scene_changed)
		scene.events.entity_removed.connect(self._on_scene_changed)
		scene.events.entity_changed.connect(self._on_scene_changed)

	def _refresh_entities(self) -> None:
		from MotionStudio.core.robot.collision_groups import collider_group_name

		items: List[Tuple[str, str]] = []
		for ent in self._scene.collision_system.collider_entities():
			col = ent.get_component(ColliderComponent)
			if col is None:
				continue
			if collider_group_name(col) != self._group_name:
				continue
			items.append((ent.id, ent.name))
		items.sort(key=lambda t: (t[1].lower(), t[0]))
		self._entities = items
		hint = self.sizeHint()
		self.setMinimumSize(hint)
		self.setFixedSize(hint)
		self.updateGeometry()
		self.update()

	def _longest_label_width(self) -> int:
		fm = QFontMetrics(self.font())
		if not self._entities:
			return 60
		return max(fm.horizontalAdvance(name) for _, name in self._entities) + 8

	def _header_height(self) -> int:
		_, rise = _diagonal_label_extents(float(self._longest_label_width()))
		return int(rise) + QFontMetrics(self.font()).ascent() + _HEADER_PAD

	def _right_header_overhang(self) -> int:
		n = len(self._entities)
		if n == 0:
			return 0
		run, _ = _diagonal_label_extents(float(self._longest_label_width()))
		return max(0, int(math.ceil(run - (_CELL_SIZE // 2))) + _HEADER_PAD)

	def _grid_origin(self) -> Tuple[int, int]:
		return (_HEADER_PAD + self._longest_label_width(), _HEADER_PAD + self._header_height())

	def sizeHint(self) -> QSize:
		n = len(self._entities)
		if n == 0:
			return QSize(280, 120)
		ox, oy = self._grid_origin()
		w = ox + n * _CELL_SIZE + self._right_header_overhang()
		h = oy + n * _CELL_SIZE + _HEADER_PAD
		return QSize(max(w, 200), max(h, 100))

	def minimumSizeHint(self) -> QSize:
		return self.sizeHint()

	def _cell_at(self, pos: QPoint) -> Optional[Tuple[int, int]]:
		n = len(self._entities)
		if n == 0:
			return None
		ox, oy = self._grid_origin()
		x = pos.x() - ox
		y = pos.y() - oy
		if x < 0 or y < 0:
			return None
		col = x // _CELL_SIZE
		row = y // _CELL_SIZE
		if row < 0 or col < 0 or row >= n or col >= n:
			return None
		if col > row or col == row:
			return None
		return (int(row), int(col))

	def mousePressEvent(self, event: QMouseEvent) -> None:
		if event.button() != Qt.MouseButton.LeftButton:
			return
		cell = self._cell_at(event.position().toPoint())
		if cell is None:
			return
		row, col = cell
		a_id = self._entities[row][0]
		b_id = self._entities[col][0]
		matrix = self._scene.collision_system.matrix
		new_enabled = not matrix.is_internal_enabled(self._group_name, a_id, b_id)
		matrix.set_internal_enabled(self._group_name, a_id, b_id, new_enabled)
		try:
			self._scene.collision_system.check_all()
		except Exception:
			pass
		self.update()

	def mouseMoveEvent(self, event: QMouseEvent) -> None:
		self._hover_cell = self._cell_at(event.position().toPoint())
		self.update()

	def leaveEvent(self, event) -> None:  # type: ignore[override]
		self._hover_cell = None
		self.update()
		super().leaveEvent(event)

	def _on_scene_changed(self, *_: object) -> None:
		self._refresh_entities()

	def paintEvent(self, _event) -> None:  # type: ignore[override]
		painter = QPainter(self)
		painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
		painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

		n = len(self._entities)
		ox, oy = self._grid_origin()
		fg = self.palette().color(self.foregroundRole())
		grid_color = QColor(fg)
		grid_color.setAlpha(90)
		text_pen = QPen(fg)
		grid_pen = QPen(grid_color)

		if n == 0:
			painter.setPen(text_pen)
			painter.drawText(
				self.rect(),
				int(Qt.AlignmentFlag.AlignCenter),
				f"No colliders in group '{self._group_name}'.",
			)
			painter.end()
			return

		label_x_right = ox - 4
		for row in range(n):
			name = self._entities[row][1]
			rect = QRect(_HEADER_PAD, oy + row * _CELL_SIZE, self._longest_label_width(), _CELL_SIZE)
			painter.setPen(text_pen)
			painter.drawText(rect, int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight), name)

		painter.save()
		painter.setPen(text_pen)
		for col in range(n):
			name = self._entities[col][1]
			cx = ox + col * _CELL_SIZE + _CELL_SIZE // 2
			cy = oy
			painter.save()
			painter.translate(cx, cy - 2)
			painter.rotate(-_DIAGONAL_DEG)
			painter.drawText(0, 0, name)
			painter.restore()
		painter.restore()

		matrix = self._scene.collision_system.matrix
		painter.setPen(grid_pen)
		for row in range(n):
			for col in range(row + 1):
				cell_rect = QRect(ox + col * _CELL_SIZE, oy + row * _CELL_SIZE, _CELL_SIZE, _CELL_SIZE)
				if self._hover_cell is not None:
					hr, hc = self._hover_cell
					if (row == hr and col <= hc) or (col == hc and row >= hr):
						hover_col = QColor(fg)
						hover_col.setAlpha(28)
						painter.fillRect(cell_rect, hover_col)
				painter.drawRect(cell_rect)
				if col == row:
					diag_col = QColor(fg)
					diag_col.setAlpha(36)
					painter.fillRect(cell_rect.adjusted(1, 1, -1, -1), diag_col)
					continue
				enabled = matrix.is_internal_enabled(
					self._group_name, self._entities[row][0], self._entities[col][0]
				)
				if enabled:
					self._draw_check(painter, cell_rect, fg)
		painter.end()

	@staticmethod
	def _draw_check(painter: QPainter, rect: QRect, color: QColor) -> None:
		pen = QPen(color)
		pen.setWidth(2)
		pen.setCapStyle(Qt.PenCapStyle.RoundCap)
		pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
		painter.save()
		painter.setPen(pen)
		left = rect.left() + 4
		mid_x = rect.left() + rect.width() // 2 - 1
		right = rect.right() - 3
		top = rect.top() + rect.height() // 2
		mid_y = rect.bottom() - 4
		bot_y = rect.top() + 4
		painter.drawLine(left, top, mid_x, mid_y)
		painter.drawLine(mid_x, mid_y, right, bot_y)
		painter.restore()


class CollisionGroupMatrixDialog(QDialog):
	"""Popup sub-matrix for intra-group collider pair toggles."""

	def __init__(self, scene: Scene, group_name: str, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._scene = scene
		self._group_name = group_name
		self._refresh_pending = False
		self._closing = False
		self.setWindowTitle(f"Collision Group: {group_name}")
		self.setModal(False)
		self.setMinimumSize(400, 280)
		self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)

		root = QVBoxLayout(self)
		root.setContentsMargins(12, 12, 12, 12)
		root.setSpacing(8)

		scroll = QScrollArea(self)
		scroll.setWidgetResizable(False)
		scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

		self._grid = _GroupInternalMatrixGrid(scene, group_name, scroll)
		scroll.setWidget(self._grid)
		root.addWidget(scroll, 1)

		add_close_button_row(self, root)

		scene.events.entity_changed.connect(self._on_entity_changed)
		scene.events.entity_removed.connect(self._on_entity_removed)

		self.adjustSize()
		self._center_on_parent(parent)
		self.show()
		self.raise_()
		self.activateWindow()

	def _center_on_parent(self, parent: Optional[QWidget]) -> None:
		try:
			window = parent.window() if parent is not None else None
			if window is None:
				return
			parent_geo = window.frameGeometry()
			dialog_geo = self.frameGeometry()
			dialog_geo.moveCenter(parent_geo.center())
			self.move(dialog_geo.topLeft())
		except Exception:
			pass

	def _schedule_refresh(self) -> None:
		if self._refresh_pending or self._closing:
			return
		self._refresh_pending = True
		QTimer.singleShot(0, self._do_refresh)

	def _do_refresh(self) -> None:
		self._refresh_pending = False
		if self._closing:
			return
		self._grid._refresh_entities()
		self._grid.update()

	def _on_entity_changed(self, _entity_id: str) -> None:
		self._schedule_refresh()

	def _on_entity_removed(self, _entity_id: str) -> None:
		self._schedule_refresh()

	def closeEvent(self, event) -> None:  # noqa: N802
		self._closing = True
		try:
			self._scene.events.entity_changed.disconnect(self._on_entity_changed)
		except Exception:
			pass
		try:
			self._scene.events.entity_removed.disconnect(self._on_entity_removed)
		except Exception:
			pass
		super().closeEvent(event)

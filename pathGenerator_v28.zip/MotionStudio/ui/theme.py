"""Application UI theme helpers (pyqtdarktheme / qdarktheme)."""

from __future__ import annotations

_CURRENT = "dark"

# Properties set on custom Inspector widgets so they follow the app stylesheet
# instead of hardcoded per-widget dark QSS.
BORDERED_TOOL_BUTTON_PROP = "msBorderedToolButton"
COMPONENT_REF_INPUT_PROP = "msComponentRefInput"
COMPONENT_REF_TYPE_LABEL_PROP = "msComponentRefTypeLabel"

_TOOLTIP_DARK = (
	"QToolTip { background-color: #333; color: #fff; border: 1px solid #555; }"
)
_TOOLTIP_LIGHT = (
	"QToolTip { background-color: #ffffe1; color: #000; border: 1px solid #aaa; }"
)

_BORDERED_TOOL_BUTTON_DARK = f"""
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"] {{
	border: 1px solid #666;
	border-radius: 4px;
	padding: 2px;
	background-color: #444;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:hover {{
	background-color: #555;
	border-color: #888;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:pressed {{
	background-color: #333;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:disabled {{
	background-color: #333;
	border-color: #444;
	color: #666;
}}
"""

_BORDERED_TOOL_BUTTON_LIGHT = f"""
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"] {{
	border: 1px solid #b0b0b0;
	border-radius: 4px;
	padding: 2px;
	background-color: #f5f5f5;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:hover {{
	background-color: #e8e8e8;
	border-color: #888;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:pressed {{
	background-color: #d8d8d8;
}}
QToolButton[{BORDERED_TOOL_BUTTON_PROP}="true"]:disabled {{
	background-color: #eeeeee;
	border-color: #ccc;
	color: #999;
}}
"""

_COMPONENT_REF_DARK = f"""
QLabel[{COMPONENT_REF_TYPE_LABEL_PROP}="true"] {{
	color: #888;
	font-size: 10pt;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"] {{
	background-color: #2b2b2b;
	color: #ddd;
	border: 1px solid #555;
	border-radius: 2px;
	padding: 4px 8px;
	text-align: left;
	min-height: 22px;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"]:hover {{
	border-color: #777;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"]:pressed {{
	background-color: #333;
}}
"""

_COMPONENT_REF_LIGHT = f"""
QLabel[{COMPONENT_REF_TYPE_LABEL_PROP}="true"] {{
	color: #666;
	font-size: 10pt;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"] {{
	background-color: #ffffff;
	color: #222;
	border: 1px solid #b0b0b0;
	border-radius: 2px;
	padding: 4px 8px;
	text-align: left;
	min-height: 22px;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"]:hover {{
	border-color: #888;
	background-color: #f8f8f8;
}}
QPushButton[{COMPONENT_REF_INPUT_PROP}="true"]:pressed {{
	background-color: #eeeeee;
}}
"""

# Shared Play / Pause / Stop button chrome (semantic colors work on both themes).
_PLAY_BUTTONS_QSS = """
QPushButton#play_button {
	background-color: #4a7c4a;
	color: white;
}
QPushButton#play_button:hover {
	background-color: #5a8c5a;
}
QPushButton#play_button:disabled {
	background-color: #6a8a6a;
	color: #ddd;
}
QPushButton#stop_button {
	background-color: #7c4a4a;
	color: white;
}
QPushButton#stop_button:hover {
	background-color: #8c5a5a;
}
QPushButton#stop_button:disabled {
	background-color: #8a6a6a;
	color: #ddd;
}
QPushButton#pause_button {
	background-color: #7c7c4a;
	color: white;
}
QPushButton#pause_button:hover {
	background-color: #8c8c5a;
}
QPushButton#pause_button:disabled {
	background-color: #8a8a6a;
	color: #ddd;
}
"""

_PLAY_RIBBON_DARK = {
	"default": """
QWidget, QToolBar {
	background-color: #2b2b2b;
	border-bottom: 1px solid #555;
}
QPushButton {
	background-color: #3c3c3c;
	color: white;
	border: 1px solid #555;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #4a4a4a; }
QPushButton:pressed { background-color: #2a2a2a; }
QPushButton:disabled {
	background-color: #2a2a2a;
	border: 1px solid #444;
	color: #888;
}
""" + _PLAY_BUTTONS_QSS,
	"active": """
QWidget, QToolBar {
	background-color: #2b4a2b;
	border-bottom: 1px solid #4a7c4a;
}
QPushButton {
	background-color: #3c5c3c;
	color: white;
	border: 1px solid #4a7c4a;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #4a6c4a; }
QPushButton:pressed { background-color: #2a4a2a; }
QPushButton:disabled {
	background-color: #2a4a2a;
	border: 1px solid #3a5c3a;
	color: #aaa;
}
""" + _PLAY_BUTTONS_QSS,
	"paused": """
QWidget, QToolBar {
	background-color: #4a4a2b;
	border-bottom: 1px solid #7c7c4a;
}
QPushButton {
	background-color: #5c5c3c;
	color: white;
	border: 1px solid #7c7c4a;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #6c6c4a; }
QPushButton:pressed { background-color: #4a4a2a; }
QPushButton:disabled {
	background-color: #4a4a2a;
	border: 1px solid #5c5c3a;
	color: #aaa;
}
""" + _PLAY_BUTTONS_QSS,
}

_PLAY_RIBBON_LIGHT = {
	"default": """
QWidget, QToolBar {
	background-color: #f0f0f0;
	border-bottom: 1px solid #c0c0c0;
}
QPushButton {
	background-color: #ffffff;
	color: #222;
	border: 1px solid #b0b0b0;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #e8e8e8; }
QPushButton:pressed { background-color: #dcdcdc; }
QPushButton:disabled {
	background-color: #f5f5f5;
	border: 1px solid #d0d0d0;
	color: #999;
}
""" + _PLAY_BUTTONS_QSS,
	"active": """
QWidget, QToolBar {
	background-color: #e3f0e3;
	border-bottom: 1px solid #7aaa7a;
}
QPushButton {
	background-color: #ffffff;
	color: #222;
	border: 1px solid #8aba8a;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #edf6ed; }
QPushButton:pressed { background-color: #d8ebd8; }
QPushButton:disabled {
	background-color: #f0f5f0;
	border: 1px solid #c0d0c0;
	color: #999;
}
""" + _PLAY_BUTTONS_QSS,
	"paused": """
QWidget, QToolBar {
	background-color: #f5f0d8;
	border-bottom: 1px solid #c0b060;
}
QPushButton {
	background-color: #ffffff;
	color: #222;
	border: 1px solid #c0b070;
	padding: 6px 12px;
	border-radius: 4px;
	min-width: 80px;
	font-size: 11pt;
}
QPushButton:hover { background-color: #faf6e8; }
QPushButton:pressed { background-color: #ebe4c8; }
QPushButton:disabled {
	background-color: #f7f4e8;
	border: 1px solid #d0c8a0;
	color: #999;
}
""" + _PLAY_BUTTONS_QSS,
}


def current_theme() -> str:
	"""Return ``\"dark\"`` or ``\"light\"``."""
	return _CURRENT


def is_dark_theme() -> bool:
	return _CURRENT == "dark"


def _additional_qss(theme: str) -> str:
	dark = theme == "dark"
	parts = [
		_TOOLTIP_DARK if dark else _TOOLTIP_LIGHT,
		_BORDERED_TOOL_BUTTON_DARK if dark else _BORDERED_TOOL_BUTTON_LIGHT,
		_COMPONENT_REF_DARK if dark else _COMPONENT_REF_LIGHT,
	]
	return "\n".join(parts)


def apply_theme(theme: str = "dark") -> None:
	"""Apply qdarktheme ``dark`` or ``light`` (default dark)."""
	global _CURRENT
	import qdarktheme

	resolved = "dark" if str(theme).lower() != "light" else "light"
	_CURRENT = resolved
	qdarktheme.setup_theme(resolved, additional_qss=_additional_qss(resolved))


def set_dark_theme(enabled: bool) -> None:
	"""Enable dark theme when True; light theme when False."""
	apply_theme("dark" if enabled else "light")


def play_ribbon_stylesheet(mode: str = "default") -> str:
	"""QSS for the Play Mode ribbon bar (``default`` / ``active`` / ``paused``)."""
	state = str(mode or "default").lower()
	if state not in ("default", "active", "paused"):
		state = "default"
	if is_dark_theme():
		return _PLAY_RIBBON_DARK[state]
	return _PLAY_RIBBON_LIGHT[state]


def _mark_themed_widget(widget, prop_name: str) -> None:
	"""Tag a widget for theme ``additional_qss`` and clear local stylesheets."""
	widget.setProperty(prop_name, True)
	widget.setStyleSheet("")
	style = widget.style()
	if style is not None:
		style.unpolish(widget)
		style.polish(widget)
	widget.update()


def mark_bordered_tool_button(btn) -> None:
	"""Tag a QToolButton so the theme stylesheet styles it (no local QSS)."""
	_mark_themed_widget(btn, BORDERED_TOOL_BUTTON_PROP)


def mark_component_reference_widgets(*, type_label, input_button) -> None:
	"""Tag ComponentReferenceWidget bits for theme-aware styling."""
	_mark_themed_widget(type_label, COMPONENT_REF_TYPE_LABEL_PROP)
	_mark_themed_widget(input_button, COMPONENT_REF_INPUT_PROP)

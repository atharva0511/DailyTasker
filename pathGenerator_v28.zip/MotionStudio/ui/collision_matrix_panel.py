from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Literal, Optional, Tuple

from PyQt6.QtCore import QPoint, QRect, QSize, Qt
from PyQt6.QtGui import QColor, QFont, QFontMetrics, QMouseEvent, QPainter, QPen
from PyQt6.QtWidgets import (
	QComboBox,
	QHBoxLayout,
	QLabel,
	QPushButton,
	QScrollArea,
	QSizePolicy,
	QVBoxLayout,
	QWidget,
)

from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.robot.collision_groups import collider_group_name
from MotionStudio.core.scene.collision_backends import CollisionBackendId
from MotionStudio.core.scene.collision_system import GlobalMatrixEntry
from MotionStudio.core.scene.scene import Scene
from MotionStudio.ui.collision_group_matrix_dialog import CollisionGroupMatrixDialog

_CELL_SIZE = 20
_HEADER_PAD = 6
_DIAGONAL_DEG = 45.0


def _diagonal_label_extents(label_width: float) -> Tuple[float, float]:
	"""Horizontal / vertical reach of a label drawn at -45° from its baseline origin."""
	rad = math.radians(_DIAGONAL_DEG)
	return label_width * math.cos(rad), label_width * math.sin(rad)


@dataclass
class _GroupAxis:
	kind: Literal["group"]
	group_name: str
	display_name: str
	member_count: int


@dataclass
class _EntityAxis:
	kind: Literal["entity"]
	entity_id: str
	display_name: str


_MatrixAxis = _GroupAxis | _EntityAxis


def _build_global_axes(scene: Scene) -> List[_MatrixAxis]:
	group_counts: dict[str, int] = {}
	ungrouped: List[Tuple[str, str]] = []
	for ent in scene.collision_system.collider_entities():
		col = ent.get_component(ColliderComponent)
		if col is None:
			continue
		gname = collider_group_name(col)
		if gname:
			group_counts[gname] = group_counts.get(gname, 0) + 1
		else:
			ungrouped.append((ent.id, ent.name))

	axes: List[_MatrixAxis] = []
	for gname in sorted(group_counts.keys(), key=str.lower):
		axes.append(
			_GroupAxis(
				kind="group",
				group_name=gname,
				display_name=gname,
				member_count=group_counts[gname],
			)
		)
	for eid, name in sorted(ungrouped, key=lambda t: (t[1].lower(), t[0])):
		axes.append(_EntityAxis(kind="entity", entity_id=eid, display_name=name))
	return axes


def _axis_to_global_entry(axis: _MatrixAxis) -> GlobalMatrixEntry:
	if isinstance(axis, _GroupAxis):
		return ("group", axis.group_name)
	return ("entity", axis.entity_id)


def _axis_label(axis: _MatrixAxis) -> str:
	if isinstance(axis, _GroupAxis):
		return f"{axis.display_name} ({axis.member_count})"
	return axis.display_name


class _GlobalCollisionMatrixGrid(QWidget):
	"""
	Global Physics matrix: one row per collision group and per ungrouped collider.
	"""

	def __init__(self, scene: Scene, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._scene = scene
		self._axes: List[_MatrixAxis] = []
		self._hover_cell: Optional[Tuple[int, int]] = None
		self.setMouseTracking(True)
		self.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
		self._refresh_axes()

		scene.events.entity_added.connect(self._on_scene_changed)
		scene.events.entity_removed.connect(self._on_scene_changed)
		scene.events.entity_changed.connect(self._on_scene_changed)

	def group_names(self) -> List[str]:
		return [a.group_name for a in self._axes if isinstance(a, _GroupAxis)]

	def _refresh_axes(self) -> None:
		self._axes = _build_global_axes(self._scene)
		hint = self.sizeHint()
		self.setMinimumSize(hint)
		self.updateGeometry()
		self.update()

	def _longest_label_width(self) -> int:
		fm = QFontMetrics(self.font())
		if not self._axes:
			return 60
		return max(fm.horizontalAdvance(_axis_label(a)) for a in self._axes) + 8

	def _header_height(self) -> int:
		_, rise = _diagonal_label_extents(float(self._longest_label_width()))
		# Extra room for glyph ascent above the rotated baseline.
		return int(rise) + QFontMetrics(self.font()).ascent() + _HEADER_PAD

	def _right_header_overhang(self) -> int:
		"""Extra width past the last column so -45° headers are not clipped."""
		n = len(self._axes)
		if n == 0:
			return 0
		run, _ = _diagonal_label_extents(float(self._longest_label_width()))
		# Labels start at column centers; the last one extends past the grid edge.
		return max(0, int(math.ceil(run - (_CELL_SIZE // 2))) + _HEADER_PAD)

	def _grid_origin(self) -> Tuple[int, int]:
		return (_HEADER_PAD + self._longest_label_width(), _HEADER_PAD + self._header_height())

	def sizeHint(self) -> QSize:
		n = len(self._axes)
		if n == 0:
			return QSize(280, 120)
		ox, oy = self._grid_origin()
		w = ox + n * _CELL_SIZE + self._right_header_overhang()
		h = oy + n * _CELL_SIZE + _HEADER_PAD
		return QSize(max(w, 200), max(h, 100))

	def minimumSizeHint(self) -> QSize:
		return self.sizeHint()

	def _cell_at(self, pos: QPoint) -> Optional[Tuple[int, int]]:
		n = len(self._axes)
		if n == 0:
			return None
		ox, oy = self._grid_origin()
		x = pos.x() - ox
		y = pos.y() - oy
		if x < 0 or y < 0:
			return None
		col = x // _CELL_SIZE
		row = y // _CELL_SIZE
		if row < 0 or col < 0 or row >= n or col >= n:
			return None
		if col > row or col == row:
			return None
		return (int(row), int(col))

	def mousePressEvent(self, event: QMouseEvent) -> None:
		if event.button() != Qt.MouseButton.LeftButton:
			return
		cell = self._cell_at(event.position().toPoint())
		if cell is None:
			return
		row, col = cell
		entry_a = _axis_to_global_entry(self._axes[row])
		entry_b = _axis_to_global_entry(self._axes[col])
		matrix = self._scene.collision_system.matrix
		new_enabled = not matrix.is_global_enabled(entry_a, entry_b)
		matrix.set_global_enabled(entry_a, entry_b, new_enabled)
		try:
			self._scene.collision_system.check_all()
		except Exception:
			pass
		self.update()

	def mouseMoveEvent(self, event: QMouseEvent) -> None:
		self._hover_cell = self._cell_at(event.position().toPoint())
		self.update()

	def leaveEvent(self, event) -> None:  # type: ignore[override]
		self._hover_cell = None
		self.update()
		super().leaveEvent(event)

	def _on_scene_changed(self, *_: object) -> None:
		self._refresh_axes()

	def paintEvent(self, _event) -> None:  # type: ignore[override]
		painter = QPainter(self)
		painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
		painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

		n = len(self._axes)
		ox, oy = self._grid_origin()
		fg = self.palette().color(self.foregroundRole())
		grid_color = QColor(fg)
		grid_color.setAlpha(90)
		text_pen = QPen(fg)
		grid_pen = QPen(grid_color)

		if n == 0:
			painter.setPen(text_pen)
			painter.drawText(
				self.rect(),
				int(Qt.AlignmentFlag.AlignCenter),
				"No entities with Collider component.\nAdd a Collider to at least two entities to configure pair checks.",
			)
			painter.end()
			return

		for row in range(n):
			label = _axis_label(self._axes[row])
			rect = QRect(_HEADER_PAD, oy + row * _CELL_SIZE, self._longest_label_width(), _CELL_SIZE)
			painter.setPen(text_pen)
			painter.drawText(rect, int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight), label)

		painter.save()
		painter.setPen(text_pen)
		for col in range(n):
			label = _axis_label(self._axes[col])
			cx = ox + col * _CELL_SIZE + _CELL_SIZE // 2
			cy = oy
			painter.save()
			painter.translate(cx, cy - 2)
			painter.rotate(-_DIAGONAL_DEG)
			painter.drawText(0, 0, label)
			painter.restore()
		painter.restore()

		matrix = self._scene.collision_system.matrix
		painter.setPen(grid_pen)
		for row in range(n):
			for col in range(row + 1):
				cell_rect = QRect(ox + col * _CELL_SIZE, oy + row * _CELL_SIZE, _CELL_SIZE, _CELL_SIZE)
				if self._hover_cell is not None:
					hr, hc = self._hover_cell
					if (row == hr and col <= hc) or (col == hc and row >= hr):
						hover_col = QColor(fg)
						hover_col.setAlpha(28)
						painter.fillRect(cell_rect, hover_col)
				painter.drawRect(cell_rect)
				if col == row:
					diag_col = QColor(fg)
					diag_col.setAlpha(36)
					painter.fillRect(cell_rect.adjusted(1, 1, -1, -1), diag_col)
					continue
				entry_a = _axis_to_global_entry(self._axes[row])
				entry_b = _axis_to_global_entry(self._axes[col])
				if matrix.is_global_enabled(entry_a, entry_b):
					self._draw_check(painter, cell_rect, fg)
		painter.end()

	@staticmethod
	def _draw_check(painter: QPainter, rect: QRect, color: QColor) -> None:
		pen = QPen(color)
		pen.setWidth(2)
		pen.setCapStyle(Qt.PenCapStyle.RoundCap)
		pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
		painter.save()
		painter.setPen(pen)
		left = rect.left() + 4
		mid_x = rect.left() + rect.width() // 2 - 1
		right = rect.right() - 3
		top = rect.top() + rect.height() // 2
		mid_y = rect.bottom() - 4
		bot_y = rect.top() + 4
		painter.drawLine(left, top, mid_x, mid_y)
		painter.drawLine(mid_x, mid_y, right, bot_y)
		painter.restore()


class CollisionMatrixPanel(QWidget):
	"""
	Dockable Physics window: global collision matrix plus per-group sub-matrix buttons.
	"""

	def __init__(self, scene: Scene, parent: Optional[QWidget] = None) -> None:
		super().__init__(parent)
		self._scene = scene
		self._group_dialogs: dict[str, CollisionGroupMatrixDialog] = {}

		self._grid = _GlobalCollisionMatrixGrid(scene)

		self._group_buttons_host = QWidget()
		self._group_buttons_layout = QVBoxLayout(self._group_buttons_host)
		self._group_buttons_layout.setContentsMargins(0, 8, 0, 0)
		self._group_buttons_layout.setSpacing(4)

		self._scroll_content = QWidget()
		scroll_layout = QVBoxLayout(self._scroll_content)
		scroll_layout.setContentsMargins(0, 0, 0, 0)
		scroll_layout.setSpacing(8)
		scroll_layout.addWidget(self._grid, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
		scroll_layout.addWidget(self._group_buttons_host, 0, Qt.AlignmentFlag.AlignLeft)

		self._scroll = QScrollArea(self)
		self._scroll.setWidget(self._scroll_content)
		# Resizable shell, but content minimum size tracks the matrix so it
		# scrolls instead of compressing / overlapping children.
		self._scroll.setWidgetResizable(True)
		self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
		self._scroll.setFrameShape(QScrollArea.Shape.NoFrame)
		self._scroll.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)

		self._backend_combo = QComboBox(self)
		self._backend_combo.addItem("FCL", "fcl")
		self._backend_combo.addItem("VTK Collision Filter", "vtk")
		self._sync_backend_combo_from_scene()
		self._backend_combo.currentIndexChanged.connect(self._on_backend_changed)

		backend_row = QWidget(self)
		backend_layout = QHBoxLayout(backend_row)
		backend_layout.setContentsMargins(0, 0, 0, 4)
		backend_layout.addWidget(QLabel("Collision detection system:", backend_row))
		backend_layout.addWidget(self._backend_combo, 1)

		layout = QVBoxLayout(self)
		layout.setContentsMargins(4, 4, 4, 4)
		layout.addWidget(backend_row)
		layout.addWidget(self._scroll, 1)

		f = QFont(self._grid.font())
		f.setPointSizeF(max(f.pointSizeF(), 9.0))
		self._grid.setFont(f)
		# Font change affects label metrics / sizeHint — refresh bounds.
		self._grid._refresh_axes()

		scene.events.entity_changed.connect(self._on_scene_changed)
		scene.events.entity_added.connect(self._on_scene_changed)
		scene.events.entity_removed.connect(self._on_scene_changed)

		self._rebuild_group_buttons()
		self._sync_scroll_content_size()

	def showEvent(self, event) -> None:  # type: ignore[override]
		super().showEvent(event)
		# Dock may report a 0 viewport size during construction; sync once visible.
		self._sync_scroll_content_size()

	def _sync_backend_combo_from_scene(self) -> None:
		current = self._scene.collision_system.backend_id
		idx = self._backend_combo.findData(current)
		if idx < 0:
			idx = 0
		block = self._backend_combo.blockSignals(True)
		self._backend_combo.setCurrentIndex(idx)
		self._backend_combo.blockSignals(block)

	def _on_backend_changed(self, _index: int) -> None:
		data = self._backend_combo.currentData()
		if not isinstance(data, str):
			return
		backend_id: CollisionBackendId = "fcl" if data == "fcl" else "vtk"
		self._scene.collision_system.set_backend_id(backend_id)
		try:
			self._scene.collision_system.check_all()
		except Exception:
			pass

	def resizeEvent(self, event) -> None:  # type: ignore[override]
		super().resizeEvent(event)
		self._sync_scroll_content_size()

	def _sync_scroll_content_size(self) -> None:
		"""Lock matrix size and stack group buttons below it (no overlap)."""
		grid_hint = self._grid.sizeHint()
		self._grid.setFixedSize(grid_hint)

		lay = self._scroll_content.layout()
		if lay is not None:
			lay.invalidate()
			lay.activate()

		buttons_hint = self._group_buttons_host.sizeHint()
		margins = lay.contentsMargins() if lay is not None else self._scroll_content.contentsMargins()
		spacing = lay.spacing() if lay is not None else 0
		content_w = max(grid_hint.width(), buttons_hint.width()) + margins.left() + margins.right()
		content_h = (
			grid_hint.height()
			+ buttons_hint.height()
			+ margins.top()
			+ margins.bottom()
			+ max(0, spacing)
		)

		# Minimum size forces scrollbars when the dock is smaller than the matrix.
		self._scroll_content.setMinimumSize(content_w, content_h)
		if lay is not None:
			lay.activate()

	def _on_scene_changed(self, *_: object) -> None:
		self._grid._refresh_axes()
		self._rebuild_group_buttons()
		self._sync_backend_combo_from_scene()

	def _rebuild_group_buttons(self) -> None:
		while self._group_buttons_layout.count():
			item = self._group_buttons_layout.takeAt(0)
			w = item.widget()
			if w is not None:
				w.deleteLater()

		group_names = self._grid.group_names()
		if not group_names:
			self._sync_scroll_content_size()
			return

		for gname in group_names:
			count = 0
			for ent in self._scene.collision_system.collider_entities():
				col = ent.get_component(ColliderComponent)
				if col is not None and collider_group_name(col) == gname:
					count += 1
			btn = QPushButton(f"{gname} ({count} links)", self._group_buttons_host)
			btn.setToolTip(f"Open internal collision matrix for group '{gname}'")
			btn.setSizePolicy(
				QSizePolicy.Policy.Expanding,
				QSizePolicy.Policy.Fixed,
			)
			btn.clicked.connect(
				lambda _checked=False, gn=gname: self._open_group_dialog(gn)
			)
			self._group_buttons_layout.addWidget(btn)
		self._sync_scroll_content_size()

	def _open_group_dialog(self, group_name: str) -> None:
		existing = self._group_dialogs.get(group_name)
		if existing is not None:
			try:
				existing.raise_()
				existing.activateWindow()
				return
			except RuntimeError:
				self._group_dialogs.pop(group_name, None)
		dlg = CollisionGroupMatrixDialog(self._scene, group_name, self)
		self._group_dialogs[group_name] = dlg
		dlg.destroyed.connect(lambda _obj=None, gn=group_name: self._group_dialogs.pop(gn, None))

"""Process-wide crash logging: Python ``faulthandler`` and the VTK error log.

Native crashes (access violations inside VTK / numpy / Qt) are invisible in the
console of a frozen build. ``faulthandler`` prints the Python stack of every
thread into ``imove-crash.log`` when the process faults, which identifies the
Python call that triggered the native crash.
"""

from __future__ import annotations

import faulthandler
import os
import sys
import time
from pathlib import Path
from typing import IO, Callable, Optional

_CRASH_FILE: Optional[IO[str]] = None
_VTK_LOG_INSTALLED = False
_HANG_TIMEOUT_S = 10.0
_HEARTBEAT_MS = 1000
_heartbeat_timer = None


def log_dir() -> Path:
	"""``%LOCALAPPDATA%/iMOVE/logs``, falling back to ``logs`` next to the exe / cwd."""
	candidates = []
	local = os.environ.get("LOCALAPPDATA")
	if local:
		candidates.append(Path(local) / "iMOVE" / "logs")
	if getattr(sys, "frozen", False):
		candidates.append(Path(sys.executable).parent / "logs")
	candidates.append(Path.cwd() / "logs")
	for path in candidates:
		try:
			path.mkdir(parents=True, exist_ok=True)
			return path
		except OSError:
			continue
	return Path.cwd()


_CONSOLE_LOG_MAX_BYTES = 10 * 1024 * 1024
_CONSOLE_FILE: Optional[IO[str]] = None


def redirect_std_streams_to_log() -> Optional[Path]:
	"""Send ``print`` output to ``imove-console.log`` when there is no console.

	Windowed builds start with ``sys.stdout`` / ``sys.stderr`` set to ``None``.
	A file never blocks the writer the way a console in QuickEdit/selection mode
	does (which froze the GUI thread inside ``WriteConsoleW``). The previous run's
	log is kept as ``imove-console.log.1`` once it exceeds 10 MB. Idempotent.
	"""
	global _CONSOLE_FILE
	if _CONSOLE_FILE is not None:
		return Path(_CONSOLE_FILE.name)
	if sys.stdout is not None and sys.stderr is not None:
		return None
	path = log_dir() / "imove-console.log"
	try:
		if path.exists() and path.stat().st_size > _CONSOLE_LOG_MAX_BYTES:
			path.replace(path.with_name(path.name + ".1"))
	except OSError:
		pass
	try:
		_CONSOLE_FILE = open(path, "a", encoding="utf-8", errors="replace", buffering=1)
	except OSError:
		return None
	_CONSOLE_FILE.write(f"\n===== iMOVE start {time.strftime('%Y-%m-%d %H:%M:%S')} pid={os.getpid()} =====\n")
	if sys.stdout is None:
		sys.stdout = _CONSOLE_FILE
	if sys.stderr is None:
		sys.stderr = _CONSOLE_FILE
	return path


def install_crash_logging() -> Optional[Path]:
	"""Enable ``faulthandler`` into ``imove-crash.log`` (append). Idempotent."""
	global _CRASH_FILE
	if _CRASH_FILE is not None:
		return Path(_CRASH_FILE.name)
	path = log_dir() / "imove-crash.log"
	try:
		# The handle must stay open for the process lifetime: faulthandler writes
		# to its file descriptor from the signal handler.
		_CRASH_FILE = open(path, "a", encoding="utf-8", buffering=1)
		_CRASH_FILE.write(
			f"\n===== iMOVE start {time.strftime('%Y-%m-%d %H:%M:%S')} pid={os.getpid()} =====\n"
		)
		_CRASH_FILE.flush()
		faulthandler.enable(file=_CRASH_FILE, all_threads=True)
	except Exception as exc:
		_CRASH_FILE = None
		try:
			faulthandler.enable(all_threads=True)
		except Exception:
			pass
		print(f"Crash log unavailable ({exc!r}); faulthandler writes to stderr", file=sys.stderr)
		return None
	print(f"Crash log: {path}", flush=True)
	return path


def install_hang_watchdog(
	timeout_s: float = _HANG_TIMEOUT_S,
	on_heartbeat: Optional[Callable[[], None]] = None,
) -> bool:
	"""Dump all thread stacks to ``imove-crash.log`` when the GUI thread stalls.

	A ``QTimer`` on the GUI thread re-arms ``faulthandler.dump_traceback_later``
	every second. If the event loop blocks for ``timeout_s`` (Windows "Not
	Responding"), faulthandler's own C thread writes every Python stack without
	needing the GIL, and repeats every ``timeout_s`` while the stall lasts.
	Requires a ``QApplication`` and ``install_crash_logging``. Idempotent.
	"""
	global _heartbeat_timer
	if _heartbeat_timer is not None:
		return True
	if _CRASH_FILE is None:
		return False
	try:
		from PyQt6.QtCore import QCoreApplication, QTimer

		app = QCoreApplication.instance()
		if app is None:
			return False

		def heartbeat() -> None:
			faulthandler.dump_traceback_later(timeout_s, repeat=True, file=_CRASH_FILE)
			if on_heartbeat is not None:
				try:
					on_heartbeat()
				except Exception:
					pass

		timer = QTimer(app)
		timer.setInterval(_HEARTBEAT_MS)
		timer.timeout.connect(heartbeat)
		timer.start()
		app.aboutToQuit.connect(faulthandler.cancel_dump_traceback_later)
		heartbeat()
		_heartbeat_timer = timer
		return True
	except Exception as exc:
		print(f"Hang watchdog unavailable: {exc!r}", file=sys.stderr)
		return False


def install_vtk_error_log() -> Optional[Path]:
	"""Route VTK warnings/errors to ``vtk.log`` instead of a popup / lost stderr. Idempotent."""
	global _VTK_LOG_INSTALLED
	if _VTK_LOG_INSTALLED:
		return None
	try:
		import vtk  # type: ignore

		path = log_dir() / "vtk.log"
		window = vtk.vtkFileOutputWindow()
		window.SetFileName(str(path))
		window.SetAppend(True)
		window.SetFlush(True)
		vtk.vtkOutputWindow.SetInstance(window)
		_VTK_LOG_INSTALLED = True
		return path
	except Exception as exc:
		print(f"VTK error log unavailable: {exc!r}", file=sys.stderr)
		return None

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, List, Literal, Optional, Tuple


_INSPECTOR_BUTTON_ATTR = "_ms_inspector_button"


@dataclass(frozen=True)
class Range:
	min: float
	max: float
	step: float = 1.0
	decimals: Optional[int] = None  # for float widgets


@dataclass(frozen=True)
class Tooltip:
	text: str


@dataclass(frozen=True)
class Header:
	text: str


@dataclass(frozen=True)
class Group:
	"""
	Inspector group label. Fields sharing the same label open in their own
	floating dockable window (title: Entity -> Component -> Group).
	"""

	label: str


@dataclass(frozen=True)
class Order:
	"""
	Inspector row sort key for an annotated field.

	Lower values render first. Fields without ``Order`` default to ``0``.
	Fields with the same value keep class declaration order (base classes
	first, then derived).
	"""

	value: int = 0


@dataclass(frozen=True)
class ReadOnly:
	enabled: bool = True


@dataclass(frozen=True)
class ConnectionStatus:
	"""
	Marker for a ``str`` connection/state field.

	Renders as a read-only LED + text badge in the Inspector:
	green when the value is in ``connected``, amber when in ``busy``,
	red otherwise. Each hardware lists its own busy strings so status
	wording stays local to the component.
	"""

	connected: Tuple[str, ...] = ("Connected",)
	busy: Tuple[str, ...] = ()

	def classify(self, text: str) -> Literal["connected", "busy", "other"]:
		t = str(text or "")
		if t in self.connected:
			return "connected"
		if t in self.busy:
			return "busy"
		return "other"


@dataclass(frozen=True)
class Multiline:
	enabled: bool = True


@dataclass(frozen=True)
class FilePath:
	"""
	Editor hint for file path fields.
	"""

	filter: str = "All Files (*.*)"
	dialog_title: str = "Select File"


@dataclass(frozen=True)
class FolderPath:
	"""
	Editor hint for directory path fields (folder picker).
	"""

	dialog_title: str = "Select Folder"


@dataclass(frozen=True)
class ColorField:
	"""Inspector color-picker hint. ``alpha=True`` shows the alpha channel."""

	enabled: bool = True
	alpha: bool = False


@dataclass(frozen=True)
class Hidden:
	"""
	Metadata marker to hide a field from the Inspector UI and serialization.
	"""
	enabled: bool = True


@dataclass(frozen=True)
class VertexPick:
	"""
	Marker for QVector3D fields. Adds a 'Pick' button before the X/Y/Z spinboxes;
	clicking it puts the scene into vertex selection mode and writes the picked
	vertex's world position into the field.
	"""
	enabled: bool = True


@dataclass(frozen=True)
class _InspectorButtonSpec:
	"""Internal descriptor attached to a method by @inspector_button."""
	label: str
	tooltip: Optional[str]
	order: int
	group: Optional[str] = None


def inspector_button(
	label: Optional[str] = None,
	*,
	tooltip: Optional[str] = None,
	order: int = 0,
	group: Optional[str] = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
	"""
	Decorator that marks a Component method to be rendered as a button in the
	Inspector. The decorated method is invoked with no arguments (other than
	`self`) when the button is clicked.

	Usage:

	    @inspector_button("Reset Position", tooltip="Snap target back to origin")
	    def reset_position(self) -> None:
	        ...

	    @inspector_button("Export...", group="Export Robot Program")
	    def export_robot_program(self) -> None:
	        ...

	Args:
	    label:   Button label. Defaults to the method name (title-cased).
	    tooltip: Optional hover tooltip text.
	    order:   Sort key; lower values render first. Same-order buttons keep
	             declaration order.
	    group:   Optional ``Group`` label. When set, the button is shown inside
	             that group's gear dialog with fields sharing the same label.
	"""

	def _decorate(func: Callable[..., Any]) -> Callable[..., Any]:
		resolved_label = label if label is not None else _humanize(func.__name__)
		setattr(
			func,
			_INSPECTOR_BUTTON_ATTR,
			_InspectorButtonSpec(
				label=resolved_label,
				tooltip=tooltip,
				order=int(order),
				group=str(group) if group else None,
			),
		)
		return func

	return _decorate


def _humanize(name: str) -> str:
	# my_method -> "My Method"
	parts = [p for p in name.split("_") if p]
	return " ".join(p[:1].upper() + p[1:] for p in parts) if parts else name


def collect_inspector_buttons(
	component: Any,
) -> dict[str, Tuple[_InspectorButtonSpec, Callable[[], Any]]]:
	"""Map method name -> (button spec, bound method) for every @inspector_button."""
	cls = component.__class__
	seen: dict[str, _InspectorButtonSpec] = {}
	for base in reversed(cls.__mro__):
		for attr_name, attr_value in base.__dict__.items():
			spec = getattr(attr_value, _INSPECTOR_BUTTON_ATTR, None)
			if isinstance(spec, _InspectorButtonSpec):
				seen[attr_name] = spec
	out: dict[str, Tuple[_InspectorButtonSpec, Callable[[], Any]]] = {}
	for attr_name, spec in seen.items():
		method = getattr(component, attr_name, None)
		if callable(method):
			out[attr_name] = (spec, method)
	return out


def iter_inspector_buttons(component: Any) -> List[Tuple[_InspectorButtonSpec, Callable[[], Any]]]:
	"""Return (spec, bound_callable) pairs sorted by ``order`` then unified declaration order."""
	from MotionStudio.ui.inspector.reflection import iter_inspector_layout

	return [
		(row.button_spec, row.button_method)
		for row in iter_inspector_layout(component)
		if row.kind == "button" and row.button_spec is not None and row.button_method is not None
	]



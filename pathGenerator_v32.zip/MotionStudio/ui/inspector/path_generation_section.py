from __future__ import annotations

from typing import TYPE_CHECKING, Any

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
	QDoubleSpinBox,
	QFormLayout,
	QHBoxLayout,
	QLabel,
	QLineEdit,
	QPushButton,
	QSizePolicy,
	QStyle,
	QWidget,
)

from MotionStudio.core.ecs.entity import Entity
from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.feature import (
	TwoPointLineFeature,
	ThreePointArcFeature,
	SinglePointFeature,
	CustomFeature,
	segment_display_name,
)
from MotionStudio.core.undo.commands import ConvertToCustomFeatureCommand
from MotionStudio.ui.inspector.path_segment_settings_dialog import open_path_segment_settings_dock
from MotionStudio.ui.inspector.path_toolbox_dialog import open_path_toolbox_dock
from MotionStudio.ui.inspector.path_program_settings_dialog import open_path_program_settings_dock
from MotionStudio.ui.inspector.reflection import clone_value
from MotionStudio.ui.widgets.clickable_group_box import ClickableGroupBox

if TYPE_CHECKING:
	from MotionStudio.ui.inspector_panel import InspectorPanel


class PathGenerationSection:
	"""
	Builds the PathGeneration (``PathComponent``) portion of the Inspector.

	This lives outside :class:`InspectorPanel` to keep the panel focused on the
	generic, metadata-driven component UI. It holds a back-reference to the panel
	and reuses the panel's shared helpers (undo push, icon buttons, group gear
	rows, rebuilds) and shared state (scene, selection, undo stack, tool manager,
	feature-widget map).
	"""

	def __init__(self, panel: "InspectorPanel") -> None:
		self._panel = panel

	# ------------------------------------------------------------------ build
	def build(self, entity: Entity, comp: PathComponent, form: QFormLayout) -> None:
		panel = self._panel
		self._append_toolbox_row(form, entity)
		self._append_program_settings_row(form, entity, comp)
		form.addRow(QLabel("Path Segments: ", panel._content))

		for i, segment in enumerate(comp.segments):
			title = f"{i + 1}: {segment_display_name(segment)}"
			seg_gb = ClickableGroupBox(title, panel._content)
			try:
				seg_gb.clicked.connect(
					lambda _checked=False, idx=i: panel._selection.set_current_feature(idx)
					if panel._selection is not None
					else None
				)
			except Exception:
				pass
			panel._path_feature_widgets[i] = seg_gb

			selected_idx = panel._selection.current_feature_idx if panel._selection is not None else None
			if selected_idx == i:
				seg_gb.setStyleSheet(
					"QGroupBox { border: 2px solid #66ff66; border-radius: 6px; margin-top: 6px; } "
					"QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px 0 3px; }"
				)
			else:
				seg_gb.setStyleSheet(
					"QGroupBox { border: 1px solid #444; border-radius: 6px; margin-top: 6px; } "
					"QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px 0 3px; }"
				)
			seg_form = QFormLayout(seg_gb)

			self._append_segment_settings_row(seg_form, entity, comp, i, segment, parent=seg_gb)

			form.addRow(seg_gb)

		# Metadata-driven Group gear row (export_format / robot / Export... button).
		from MotionStudio.ui.inspector.reflection import iter_inspector_layout, partition_inspector_layout

		items, groups = partition_inspector_layout(iter_inspector_layout(comp))
		export_label = "Export Robot Program"
		if export_label in groups:
			panel._append_group_gear_row(
				form,
				export_label,
				groups[export_label],
				entity=entity,
				component=comp,
			)

	# ------------------------------------------------- program-level settings
	def append_program_settings_fields(
		self,
		form: QFormLayout,
		entity: Entity,
		comp: PathComponent,
	) -> None:
		panel = self._panel
		parent = form.parentWidget()

		speed_sb = QDoubleSpinBox(parent)
		speed_sb.setRange(0.001, 10.0)
		speed_sb.setDecimals(4)
		speed_sb.setSingleStep(0.05)
		speed_sb.setSuffix(" m/s")
		speed_sb.setValue(comp.speed)
		speed_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=speed_sb: panel._push_comp_field_change(e, c, "speed", float(w.value()))
		)
		form.addRow("Speed", speed_sb)

		accel_sb = QDoubleSpinBox(parent)
		accel_sb.setRange(0.001, 50.0)
		accel_sb.setDecimals(4)
		accel_sb.setSingleStep(0.1)
		accel_sb.setSuffix(" m/s²")
		accel_sb.setValue(comp.acceleration)
		accel_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=accel_sb: panel._push_comp_field_change(
				e, c, "acceleration", float(w.value())
			)
		)
		form.addRow("Acceleration", accel_sb)

		default_cnt_sb = QDoubleSpinBox(parent)
		default_cnt_sb.setRange(0.0, 10.0)
		default_cnt_sb.setDecimals(6)
		default_cnt_sb.setSingleStep(0.001)
		default_cnt_sb.setSuffix(" m")
		default_cnt_sb.setValue(comp.default_cnt_radius)
		default_cnt_sb.editingFinished.connect(
			lambda e=entity, c=comp, w=default_cnt_sb: panel._push_comp_field_change(
				e, c, "default_cnt_radius", float(w.value())
			)
		)
		form.addRow("Default CNT Radius", default_cnt_sb)

	def _append_program_settings_row(self, form: QFormLayout, entity: Entity, comp: PathComponent) -> None:
		panel = self._panel
		btn = QPushButton("Path Program Settings", panel._content)
		btn.setToolTip("Open path program settings (speed, acceleration, default CNT radius)")
		btn.clicked.connect(
			lambda _c=False, ent=entity, c=comp: open_path_program_settings_dock(panel, ent, c)
		)
		form.addRow(btn)

	# ------------------------------------------------- segment-level settings
	def append_segment_settings_fields(
		self,
		form: QFormLayout,
		entity: Entity,
		segment_idx: int,
		segment,
	) -> None:
		"""Segment fields shown inside Segment Settings dialog."""
		parent = form.parentWidget()

		name_edit = QLineEdit(parent)
		name_edit.setText(str(getattr(segment, "name", "") or ""))
		name_edit.setPlaceholderText("Optional display name")
		name_edit.setToolTip(
			"Label shown on this segment's group box in the Inspector. "
			"Leave empty to use the segment type (e.g. Custom Segment)."
		)
		name_edit.editingFinished.connect(
			lambda e=entity, idx=segment_idx, w=name_edit: self._push_feature_field_change(
				e, idx, "name", w.text()
			)
		)
		form.addRow("Name", name_edit)

		speed_mult_sb = QDoubleSpinBox(parent)
		speed_mult_sb.setRange(0.01, 100.0)
		speed_mult_sb.setDecimals(3)
		speed_mult_sb.setSingleStep(0.1)
		speed_mult_sb.setValue(segment.speed_multiplier)
		speed_mult_sb.editingFinished.connect(
			lambda e=entity, idx=segment_idx, field="speed_multiplier", w=speed_mult_sb: self._push_feature_field_change(
				e, idx, field, float(w.value())
			)
		)
		form.addRow("Speed Multiplier", speed_mult_sb)

		cnt_sb = QDoubleSpinBox(parent)
		cnt_sb.setRange(0.0, 10.0)
		cnt_sb.setDecimals(6)
		cnt_sb.setSingleStep(0.001)
		cnt_sb.setSuffix(" m")
		cnt_sb.setValue(segment.cnt_radius)
		cnt_sb.editingFinished.connect(
			lambda e=entity, idx=segment_idx, field="cnt_radius", w=cnt_sb: self._push_feature_field_change(
				e, idx, field, float(w.value())
			)
		)
		form.addRow("CNT Radius", cnt_sb)

		if isinstance(segment, CustomFeature):
			wp_count_label = QLabel(f"{len(segment.waypoints)} waypoints", parent)
			form.addRow("Waypoints", wp_count_label)
			self._append_flip_sequence_button(form, entity, segment_idx, parent=parent)
			self._append_apply_fixed_rotation_button(form, entity, segment_idx, parent=parent)
			return

		if isinstance(segment, SinglePointFeature):
			return

		if isinstance(segment, TwoPointLineFeature):
			self._append_flip_sequence_button(form, entity, segment_idx, parent=parent)
			return

		if isinstance(segment, ThreePointArcFeature):
			axial_sb = QDoubleSpinBox(parent)
			axial_sb.setRange(-1000.0, 1000.0)
			axial_sb.setSingleStep(0.5)
			axial_sb.setDecimals(3)
			axial_sb.setValue(segment.axial_offset)
			axial_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="axial_offset", w=axial_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Axial Offset", axial_sb)

			radial_sb = QDoubleSpinBox(parent)
			radial_sb.setRange(-1000.0, 1000.0)
			radial_sb.setSingleStep(0.5)
			radial_sb.setDecimals(3)
			radial_sb.setValue(segment.radial_offset)
			radial_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="radial_offset", w=radial_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Radial Offset", radial_sb)

			dense_sb = QDoubleSpinBox(parent)
			dense_sb.setRange(0.01, 100.0)
			dense_sb.setValue(segment.density_multiplier)
			dense_sb.setSingleStep(0.1)
			dense_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="density_multiplier", w=dense_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Density Multiplier", dense_sb)

			radial_rot_sb = QDoubleSpinBox(parent)
			radial_rot_sb.setRange(-360.0, 360.0)
			radial_rot_sb.setValue(segment.radial_rotation)
			radial_rot_sb.setSingleStep(1.0)
			radial_rot_sb.setDecimals(1)
			radial_rot_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="radial_rotation", w=radial_rot_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Radial Rotation (deg)", radial_rot_sb)

			tangent_rot_sb = QDoubleSpinBox(parent)
			tangent_rot_sb.setRange(-360.0, 360.0)
			tangent_rot_sb.setValue(segment.tangent_rotation)
			tangent_rot_sb.setSingleStep(1.0)
			tangent_rot_sb.setDecimals(1)
			tangent_rot_sb.editingFinished.connect(
				lambda e=entity, idx=segment_idx, field="tangent_rotation", w=tangent_rot_sb: self._push_feature_field_change(
					e, idx, field, float(w.value())
				)
			)
			form.addRow("Tangent Rotation (deg)", tangent_rot_sb)
			self._append_flip_sequence_button(form, entity, segment_idx, parent=parent)

	def _append_toolbox_row(self, form: QFormLayout, entity: Entity) -> None:
		panel = self._panel
		btn = QPushButton("Path Segment Toolbox", panel._content)
		btn.setToolTip("Open path segment toolbox")
		if panel._path_tool_manager is not None:
			btn.clicked.connect(
				lambda _c=False, ent=entity: open_path_toolbox_dock(
					panel, ent, panel._path_tool_manager
				)
			)
		else:
			btn.setEnabled(False)
		form.addRow(btn)

	def _append_segment_settings_row(
		self,
		form: QFormLayout,
		entity: Entity,
		comp: PathComponent,
		segment_idx: int,
		segment,
		*,
		parent: QWidget,
	) -> None:
		panel = self._panel
		row_w = QWidget(parent)
		h = QHBoxLayout(row_w)
		h.setContentsMargins(0, 0, 0, 0)
		h.setSpacing(4)
		h.addWidget(QLabel("Segment Settings", row_w))
		gear = panel._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_FileDialogDetailedView,
			"Open Segment Settings",
		)
		h.addWidget(gear)
		h.addStretch(1)
		gear.clicked.connect(
			lambda _c=False, ent=entity, idx=segment_idx, seg=segment: open_path_segment_settings_dock(
				panel, ent, idx, seg
			)
		)

		if not isinstance(segment, CustomFeature):
			edit_btn = QPushButton("Edit", row_w)
			edit_btn.setToolTip(
				"Convert this segment to a custom segment. Waypoints become directly editable via gizmos."
			)
			edit_btn.setFixedSize(panel._ICON_TOOL_BUTTON_PX, panel._ICON_TOOL_BUTTON_PX)
			edit_btn.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
			edit_btn.setStyleSheet("font-size: 10px; padding: 0px;")
			edit_btn.clicked.connect(
				lambda _checked=False, e=entity, idx=segment_idx: self._convert_feature_to_custom(e, idx)
			)
			h.addWidget(edit_btn, 0, Qt.AlignmentFlag.AlignRight)

		move_up_btn = panel._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_ArrowUp,
			"Move segment up",
		)
		move_up_btn.setEnabled(segment_idx > 0)
		move_up_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._reorder_path_feature(e, idx, -1)
		)
		h.addWidget(move_up_btn, 0, Qt.AlignmentFlag.AlignRight)

		move_down_btn = panel._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_ArrowDown,
			"Move segment down",
		)
		move_down_btn.setEnabled(segment_idx < len(comp.segments) - 1)
		move_down_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._reorder_path_feature(e, idx, 1)
		)
		h.addWidget(move_down_btn, 0, Qt.AlignmentFlag.AlignRight)

		rm_seg_btn = panel._make_bordered_icon_tool_button(
			row_w,
			QStyle.StandardPixmap.SP_TrashIcon,
			"Remove segment",
		)
		rm_seg_btn.clicked.connect(
			lambda _checked=False, e=entity, idx=segment_idx: self._remove_path_feature(e, idx)
		)
		h.addWidget(rm_seg_btn, 0, Qt.AlignmentFlag.AlignRight)

		form.addRow(row_w)

	def _append_flip_sequence_button(
		self,
		form: QFormLayout,
		entity: Entity,
		segment_idx: int,
		*,
		parent: QWidget,
	) -> None:
		btn = QPushButton("Flip Sequence", parent)
		btn.setToolTip(
			"Invert waypoint order / travel direction for this segment "
			"(swaps line or arc start/end and regenerates waypoints; "
			"reverses custom waypoint list)."
		)
		btn.clicked.connect(
			lambda _c=False, e=entity, idx=segment_idx: self._flip_segment_sequence(e, idx)
		)
		form.addRow(btn)

	def _append_apply_fixed_rotation_button(
		self,
		form: QFormLayout,
		entity: Entity,
		segment_idx: int,
		*,
		parent: QWidget,
	) -> None:
		btn = QPushButton("Apply Fixed Rotation", parent)
		btn.setToolTip(
			"Copy the rotation of the first waypoint onto every waypoint in this "
			"custom segment, so all poses share a constant orientation while "
			"keeping their positions."
		)
		btn.clicked.connect(
			lambda _c=False, e=entity, idx=segment_idx: self._apply_fixed_rotation(e, idx)
		)
		form.addRow(btn)

	def _mutate_segment_with_snapshot(
		self,
		entity: Entity,
		feature_idx: int,
		*,
		undo_text: str,
		mutator,
	) -> None:
		"""Snapshot a segment, run ``mutator(feature)``, push undo if it changed."""
		panel = self._panel
		path_comp = entity.get_component(PathComponent)
		if path_comp is None or feature_idx < 0 or feature_idx >= len(path_comp.features):
			return
		feature = path_comp.features[feature_idx]
		feature_type = feature.__class__.__name__
		old_data = feature.to_dict()
		if not mutator(feature):
			return
		new_data = feature.to_dict()
		if old_data == new_data:
			return

		if panel._scene is None or panel._undo_stack is None:
			if panel._scene is not None:
				panel._scene.events.entity_changed.emit(entity.id)
			return

		# Restore pre-mutation state so redo applies the new snapshot cleanly.
		from MotionStudio.core.components.feature import get_feature_class
		from MotionStudio.core.undo.commands import PathFeatureSnapshotCommand

		f_cls = get_feature_class(feature_type)
		if f_cls is not None:
			path_comp.features[feature_idx] = f_cls.from_dict(old_data)

		cmd = PathFeatureSnapshotCommand(
			panel._scene,
			entity.id,
			feature_idx,
			feature_type,
			old_data,
			new_data,
			text=undo_text,
		)
		panel._undo_stack.push(cmd)

	def _flip_segment_sequence(self, entity: Entity, feature_idx: int) -> None:
		self._mutate_segment_with_snapshot(
			entity,
			feature_idx,
			undo_text=f"Flip Segment[{feature_idx}] Sequence",
			mutator=lambda feature: feature.flip_sequence(),
		)

	def _apply_fixed_rotation(self, entity: Entity, feature_idx: int) -> None:
		self._mutate_segment_with_snapshot(
			entity,
			feature_idx,
			undo_text=f"Apply Fixed Rotation Segment[{feature_idx}]",
			mutator=lambda feature: feature.apply_fixed_rotation(),
		)

	# --------------------------------------------------------- segment edits
	def _push_feature_field_change(self, entity: Entity, feature_idx: int, field: str, new_value: Any) -> None:
		panel = self._panel
		if panel._scene is None or panel._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp and len(path_comp.features) > feature_idx:
				setattr(path_comp.features[feature_idx], field, new_value)
				if panel._scene is not None:
					panel._scene.events.entity_changed.emit(entity.id)
			return

		path_comp = entity.get_component(PathComponent)
		if not path_comp or len(path_comp.features) <= feature_idx:
			return

		old = clone_value(getattr(path_comp.features[feature_idx], field))
		if old == new_value:
			return

		from MotionStudio.core.undo.commands import PathFeaturePropertyChangeCommand
		cmd = PathFeaturePropertyChangeCommand(panel._scene, entity.id, feature_idx, field, old, clone_value(new_value))
		panel._undo_stack.push(cmd)

	def _remove_path_feature(self, entity: Entity, feature_idx: int) -> None:
		panel = self._panel
		if panel._scene is None or panel._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp and len(path_comp.features) > feature_idx:
				path_comp.features.pop(feature_idx)
				if panel._scene:
					panel._scene.events.entity_changed.emit(entity.id)
				panel._rebuild_for_entity(entity)
			return

		from MotionStudio.core.undo.commands import RemovePathFeatureCommand
		cmd = RemovePathFeatureCommand(panel._scene, entity.id, feature_idx)
		panel._undo_stack.push(cmd)
		panel._rebuild_for_entity(entity)

	def _reorder_path_feature(self, entity: Entity, feature_idx: int, direction: int) -> None:
		"""Reorder a path segment up (-1) or down (+1)."""
		panel = self._panel
		if panel._scene is None or panel._undo_stack is None:
			# fallback
			path_comp = entity.get_component(PathComponent)
			if path_comp:
				new_idx = feature_idx + direction
				if 0 <= new_idx < len(path_comp.features):
					path_comp.features[feature_idx], path_comp.features[new_idx] = path_comp.features[new_idx], path_comp.features[feature_idx]
					# Update selection if this feature was selected
					if panel._selection and panel._selection.current_feature_idx == feature_idx:
						panel._selection.set_current_feature(new_idx)
					elif panel._selection and panel._selection.current_feature_idx == new_idx:
						panel._selection.set_current_feature(feature_idx)
					if panel._scene:
						panel._scene.events.entity_changed.emit(entity.id)
					panel._rebuild_for_entity(entity)
			return

		from MotionStudio.core.undo.commands import ReorderPathFeatureCommand
		cmd = ReorderPathFeatureCommand(panel._scene, entity.id, feature_idx, direction)
		panel._undo_stack.push(cmd)

		# Update selection index after reorder
		path_comp = entity.get_component(PathComponent)
		if path_comp and panel._selection:
			new_idx = feature_idx + direction
			if 0 <= new_idx < len(path_comp.features):
				if panel._selection.current_feature_idx == feature_idx:
					panel._selection.set_current_feature(new_idx)
				elif panel._selection.current_feature_idx == new_idx:
					panel._selection.set_current_feature(feature_idx)

		panel._rebuild_for_entity(entity)

	def _convert_feature_to_custom(self, entity: Entity, feature_idx: int) -> None:
		"""Convert a parametric feature to a custom editable feature."""
		panel = self._panel
		path_comp = entity.get_component(PathComponent)
		if path_comp is None:
			return
		if feature_idx < 0 or feature_idx >= len(path_comp.features):
			return

		feature = path_comp.features[feature_idx]
		if isinstance(feature, CustomFeature):
			return  # Already custom

		# Use command for undo/redo
		cmd = ConvertToCustomFeatureCommand(panel._scene, entity.id, feature_idx)
		if panel._undo_stack is not None:
			panel._undo_stack.push(cmd)
		else:
			cmd.redo()

		# Rebuild UI to reflect changes
		panel._rebuild_for_entity(entity)

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Set, Tuple, TYPE_CHECKING

import pyvista as pv  # type: ignore
import vtk  # type: ignore

from PyQt6.QtGui import QMatrix4x4, QVector3D

from MotionStudio.core.components.collider_component import ColliderComponent
from MotionStudio.core.components.mesh_component import MeshComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.transform.matrix import qmatrix_from_prs
from MotionStudio.core.robot.collision_groups import partition_colliders
from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def _canonical_pair(a: str, b: str) -> Tuple[str, str]:
	"""Return a canonical ordered pair so (a, b) and (b, a) map to the same key."""
	return (a, b) if a <= b else (b, a)


GlobalMatrixEntry = Tuple[Literal["group"], str] | Tuple[Literal["entity"], str]


def _global_key(entry: GlobalMatrixEntry) -> str:
	kind, value = entry
	return f"{kind}:{value}"


def _parse_global_key(key: str) -> Optional[GlobalMatrixEntry]:
	if key.startswith("group:"):
		name = key[6:]
		return ("group", name) if name else None
	if key.startswith("entity:"):
		eid = key[7:]
		return ("entity", eid) if eid else None
	return None


def _canonical_global_pair(a: GlobalMatrixEntry, b: GlobalMatrixEntry) -> Tuple[str, str]:
	ka, kb = _global_key(a), _global_key(b)
	return (ka, kb) if ka <= kb else (kb, ka)


class CollisionMatrix:
	"""
	Symmetric pair-enable matrix keyed by canonical (min_id, max_id) tuples.

	Default behavior: every pair is enabled. Only disabled pairs are stored so the
	matrix footprint stays compact even as scenes grow.
	"""

	def __init__(self) -> None:
		self._disabled: Set[Tuple[str, str]] = set()
		self._group_disabled: Dict[str, Set[Tuple[str, str]]] = {}
		self._global_disabled: Set[Tuple[str, str]] = set()

	def is_enabled(self, a: str, b: str) -> bool:
		if a == b:
			return False
		return _canonical_pair(a, b) not in self._disabled

	def set_enabled(self, a: str, b: str, enabled: bool) -> None:
		if a == b:
			return
		key = _canonical_pair(a, b)
		if enabled:
			self._disabled.discard(key)
		else:
			self._disabled.add(key)

	def is_internal_enabled(self, group_name: str, a: str, b: str) -> bool:
		if a == b:
			return False
		bucket = self._group_disabled.get(group_name)
		if not bucket:
			return True
		return _canonical_pair(a, b) not in bucket

	def set_internal_enabled(self, group_name: str, a: str, b: str, enabled: bool) -> None:
		if a == b or not group_name:
			return
		key = _canonical_pair(a, b)
		bucket = self._group_disabled.setdefault(group_name, set())
		if enabled:
			bucket.discard(key)
			if not bucket:
				self._group_disabled.pop(group_name, None)
		else:
			bucket.add(key)

	def has_group_internal_entries(self, group_name: str) -> bool:
		bucket = self._group_disabled.get(group_name)
		return bool(bucket)

	def is_global_enabled(self, a: GlobalMatrixEntry, b: GlobalMatrixEntry) -> bool:
		if a == b:
			return False
		return _canonical_global_pair(a, b) not in self._global_disabled

	def set_global_enabled(self, a: GlobalMatrixEntry, b: GlobalMatrixEntry, enabled: bool) -> None:
		if a == b:
			return
		key = _canonical_global_pair(a, b)
		if enabled:
			self._global_disabled.discard(key)
		else:
			self._global_disabled.add(key)

	def remove_entity(self, entity_id: str) -> None:
		"""Purge any stored pair that involves the given entity id."""
		self._disabled = {
			(a, b) for (a, b) in self._disabled if a != entity_id and b != entity_id
		}
		for group_name in list(self._group_disabled.keys()):
			bucket = self._group_disabled[group_name]
			bucket = {(a, b) for (a, b) in bucket if a != entity_id and b != entity_id}
			if bucket:
				self._group_disabled[group_name] = bucket
			else:
				self._group_disabled.pop(group_name, None)
		entity_key = f"entity:{entity_id}"
		self._global_disabled = {
			(ka, kb)
			for (ka, kb) in self._global_disabled
			if ka != entity_key and kb != entity_key
		}

	def prune_orphan_groups(self, registered_group_names: Set[str]) -> None:
		"""Drop group/internal and global entries for groups with no active colliders."""
		for name in list(self._group_disabled.keys()):
			if name not in registered_group_names:
				self._group_disabled.pop(name, None)
		prefix = "group:"
		self._global_disabled = {
			(ka, kb)
			for (ka, kb) in self._global_disabled
			if not (
				(ka.startswith(prefix) and ka[len(prefix) :] not in registered_group_names)
				or (kb.startswith(prefix) and kb[len(prefix) :] not in registered_group_names)
			)
		}

	def clear(self) -> None:
		self._disabled.clear()
		self._group_disabled.clear()
		self._global_disabled.clear()

	def to_dict(self) -> Dict[str, Any]:
		group_payload: Dict[str, List[List[str]]] = {}
		for name in sorted(self._group_disabled.keys()):
			bucket = self._group_disabled[name]
			group_payload[name] = [[a, b] for (a, b) in sorted(bucket)]
		return {
			"disabled": [[a, b] for (a, b) in sorted(self._disabled)],
			"group_disabled": group_payload,
			"global_disabled": [[ka, kb] for (ka, kb) in sorted(self._global_disabled)],
		}

	def from_dict(self, data: Dict[str, Any]) -> None:
		self._disabled.clear()
		self._group_disabled.clear()
		self._global_disabled.clear()
		if not isinstance(data, dict):
			return
		for pair in data.get("disabled", []) or []:
			try:
				a, b = str(pair[0]), str(pair[1])
			except Exception:
				continue
			if a and b and a != b:
				self._disabled.add(_canonical_pair(a, b))
		group_data = data.get("group_disabled", {})
		if isinstance(group_data, dict):
			for group_name, pairs in group_data.items():
				gname = str(group_name)
				if not gname:
					continue
				bucket: Set[Tuple[str, str]] = set()
				for pair in pairs or []:
					try:
						a, b = str(pair[0]), str(pair[1])
					except Exception:
						continue
					if a and b and a != b:
						bucket.add(_canonical_pair(a, b))
				if bucket:
					self._group_disabled[gname] = bucket
		for pair in data.get("global_disabled", []) or []:
			try:
				ka, kb = str(pair[0]), str(pair[1])
			except Exception:
				continue
			if ka and kb and ka != kb:
				self._global_disabled.add((ka, kb) if ka <= kb else (kb, ka))


class CollisionSystem:
	"""
	Scene-wide collision manager.

	Iterates over all entities with a ``ColliderComponent`` and performs n(n-1)/2
	pair checks (self-pairs excluded) subject to the ``CollisionMatrix``. Always
	updates ``ColliderComponent.collided`` to reflect the entity's current
	collision state and emits ``scene.events.entity_collision_changed`` whenever
	the flag flips. ``ColliderComponent.repaint_on_collision`` is a renderer-only
	hint: it does not affect when the flag is updated or when the signal fires.

	- Play mode: call :meth:`check_all` each tick from ``PlayModeManager``.
	- Edit mode: ``check_all`` is invoked automatically on
	  ``entity_transform_changed`` (n(n-1)/2 is cheap for typical scene sizes and
	  the AABB pre-reject keeps the expensive VTK filter off the hot path).
	"""

	def __init__(self, scene: "Scene") -> None:
		self._scene = scene
		self.matrix = CollisionMatrix()
		# Cached polydata per entity (keyed by a cheap state hash so we only
		# rebuild when the mesh definition changes).
		self._poly_cache: Dict[str, Tuple[Any, vtk.vtkPolyData]] = {}
		# Pair-keyed pool of collision filters. Each filter owns two OBBTrees
		# built from its current polydata inputs; we only swap SetTransform()
		# between frames, which VTK treats as a transform-only update and
		# leaves the trees intact. This is the Python equivalent of a per-
		# entity OBBTree cache: trees are built once per pair and reused
		# until one side's mesh geometry changes.
		self._filter_pool: Dict[
			Tuple[str, str],
			Tuple[vtk.vtkPolyData, vtk.vtkPolyData, vtk.vtkCollisionDetectionFilter,
				vtk.vtkTransform, vtk.vtkTransform],
		] = {}
		self._in_sweep: bool = False

		events = scene.events
		events.entity_removed.connect(self._on_entity_removed)
		events.entity_transform_changed.connect(self._on_entity_transform_changed)
		events.entity_changed.connect(self._on_entity_changed)

	# ------------------------------------------------------------------ public API

	def collider_entities(self) -> List["Entity"]:
		return [e for e in self._scene.entities() if e.get_component(ColliderComponent) is not None]

	def check_all(self) -> None:
		"""Run every enabled pair check (group-aware) and update collision state."""
		if self._in_sweep:
			return
		self._in_sweep = True
		try:
			entities = self.collider_entities()
			if len(entities) < 2:
				for e in entities:
					self._set_entity_collided(e, False)
				return

			is_colliding: Dict[str, bool] = {e.id: False for e in entities}
			groups, ungrouped = partition_colliders(entities)
			matrix = self.matrix

			def try_pair(ent_a: "Entity", ent_b: "Entity") -> None:
				if is_colliding[ent_a.id] and is_colliding[ent_b.id]:
					return
				if self._pair_collides(ent_a, ent_b):
					is_colliding[ent_a.id] = True
					is_colliding[ent_b.id] = True

			# Internal checks within each collision group.
			for group_name, members in groups.items():
				n = len(members)
				for i in range(n):
					ent_a = members[i]
					for j in range(i + 1, n):
						ent_b = members[j]
						if not matrix.is_internal_enabled(group_name, ent_a.id, ent_b.id):
							continue
						try_pair(ent_a, ent_b)

			# Ungrouped ↔ ungrouped (legacy entity matrix).
			n_u = len(ungrouped)
			for i in range(n_u):
				ent_a = ungrouped[i]
				for j in range(i + 1, n_u):
					ent_b = ungrouped[j]
					if not matrix.is_enabled(ent_a.id, ent_b.id):
						continue
					try_pair(ent_a, ent_b)

			group_entry: GlobalMatrixEntry
			entity_entry: GlobalMatrixEntry

			# Group ↔ ungrouped.
			for group_name, members in groups.items():
				group_entry = ("group", group_name)
				for ent_u in ungrouped:
					entity_entry = ("entity", ent_u.id)
					if not matrix.is_global_enabled(group_entry, entity_entry):
						continue
					for ent_g in members:
						try_pair(ent_g, ent_u)

			# Group ↔ group.
			group_names = sorted(groups.keys())
			for gi in range(len(group_names)):
				gname_a = group_names[gi]
				entry_a: GlobalMatrixEntry = ("group", gname_a)
				for gj in range(gi + 1, len(group_names)):
					gname_b = group_names[gj]
					entry_b: GlobalMatrixEntry = ("group", gname_b)
					if not matrix.is_global_enabled(entry_a, entry_b):
						continue
					for ent_a in groups[gname_a]:
						for ent_b in groups[gname_b]:
							try_pair(ent_a, ent_b)

			for ent in entities:
				self._set_entity_collided(ent, is_colliding[ent.id])
		finally:
			self._in_sweep = False

	def check_entity(self, entity_id: str) -> None:
		"""Re-check pairs involving ``entity_id`` and refresh affected entities.

		Only the moving entity and its direct partners can change collision state,
		so we run the full sweep (O(n^2) pair checks is negligible at typical
		scene sizes, and the AABB reject keeps the filter mostly idle).
		"""
		self.check_all()

	def invalidate_entity_cache(self, entity_id: str) -> None:
		self._poly_cache.pop(entity_id, None)
		self._evict_filters_for(entity_id)

	# ------------------------------------------------------------------ filter pool

	def _evict_filters_for(self, entity_id: str) -> None:
		"""Drop any pooled filter that references this entity so its OBBTree is
		rebuilt from the fresh polydata next time the pair is checked."""
		if not self._filter_pool:
			return
		stale = [key for key in self._filter_pool if entity_id in key]
		for key in stale:
			self._filter_pool.pop(key, None)

	def _get_or_create_filter(
		self,
		ent_a_id: str,
		ent_b_id: str,
		poly_a: vtk.vtkPolyData,
		poly_b: vtk.vtkPolyData,
	) -> Tuple[vtk.vtkCollisionDetectionFilter, vtk.vtkTransform, vtk.vtkTransform, bool]:
		"""Fetch-or-create a filter for this pair.

		Returns ``(filter, transform_a, transform_b, swapped)``. ``swapped`` is
		True when the canonical key ordered (b, a) instead of (a, b); the caller
		must feed the transforms accordingly.
		"""
		key = _canonical_pair(ent_a_id, ent_b_id)
		swapped = key != (ent_a_id, ent_b_id)
		cached = self._filter_pool.get(key)
		if cached is not None:
			cached_poly_0, cached_poly_1, flt, tr0, tr1 = cached
			# Identity check: if the polydata pointers still match, the trees
			# inside the filter are still valid. Otherwise rebuild.
			expected_0 = poly_b if swapped else poly_a
			expected_1 = poly_a if swapped else poly_b
			if cached_poly_0 is expected_0 and cached_poly_1 is expected_1:
				return flt, tr0, tr1, swapped
			# Stale entry; fall through to rebuild.
			self._filter_pool.pop(key, None)

		flt = vtk.vtkCollisionDetectionFilter()
		flt.SetCollisionModeToFirstContact()
		tr0 = vtk.vtkTransform()
		tr1 = vtk.vtkTransform()
		# Identity transforms must be set before SetInputData so the first
		# Update() uses sensible values.
		flt.SetTransform(0, tr0)
		flt.SetTransform(1, tr1)
		poly_0 = poly_b if swapped else poly_a
		poly_1 = poly_a if swapped else poly_b
		flt.SetInputData(0, poly_0)
		flt.SetInputData(1, poly_1)
		self._filter_pool[key] = (poly_0, poly_1, flt, tr0, tr1)
		return flt, tr0, tr1, swapped

	# -------------------------------------------------------- collision helpers

	def _set_entity_collided(self, entity: "Entity", collided: bool) -> None:
		collider = entity.get_component(ColliderComponent)
		if collider is None:
			return
		# Always reflect the actual collision state on the flag, regardless of
		# ``repaint_on_collision``. Custom components can poll the flag (or
		# listen to ``entity_collision_changed``) even when visual recoloring
		# is disabled. The renderer separately consults ``repaint_on_collision``
		# to decide whether to apply the red overlay.
		new_value = bool(collided)
		if bool(getattr(collider, "collided", False)) == new_value:
			return
		# Bypass the Component __setattr__ auto-emit of entity_changed (which
		# would trigger a full mesh rebuild) and emit the lightweight
		# entity_collision_changed signal instead.
		try:
			object.__setattr__(collider, "collided", new_value)
		except Exception:
			collider.collided = new_value
		try:
			self._scene.events.entity_collision_changed.emit(entity.id)
		except Exception:
			pass

	def _pair_collides(self, ent_a: "Entity", ent_b: "Entity") -> bool:
		poly_a = self._get_polydata(ent_a)
		poly_b = self._get_polydata(ent_b)
		if poly_a is None or poly_b is None:
			return False
		xform_a = self._world_transform(ent_a)
		xform_b = self._world_transform(ent_b)
		# Quick AABB reject against world-space bounds to skip the expensive
		# VTK collision filter when the boxes don't overlap.
		if not self._bounds_overlap(poly_a, xform_a, poly_b, xform_b):
			return False
		try:
			flt, tr0, tr1, swapped = self._get_or_create_filter(
				ent_a.id, ent_b.id, poly_a, poly_b
			)
			# Map transforms to the filter's canonical slot order.
			xform_0 = xform_b if swapped else xform_a
			xform_1 = xform_a if swapped else xform_b
			self._update_vtk_transform(tr0, xform_0)
			self._update_vtk_transform(tr1, xform_1)
			flt.Update()
			return flt.GetNumberOfContacts() > 0
		except Exception:
			# Fall back to positive (AABB already overlapped) if the VTK pipeline fails.
			return True

	# -------------------------------------------------------- mesh / transforms

	def _get_polydata(self, entity: "Entity") -> Optional[vtk.vtkPolyData]:
		mesh = entity.get_component(MeshComponent)
		collider = entity.get_component(ColliderComponent)
		if collider is None:
			return None
		use_mesh_component = bool(getattr(collider, "collider_from_mesh_component", True))
		collider_scale = 1.0
		if not use_mesh_component:
			try:
				collider_scale = float(getattr(collider, "scale", 1.0) or 1.0)
			except Exception:
				collider_scale = 1.0
		state_key = (
			"use_mesh_component",
			use_mesh_component,
			"collider_scale",
			collider_scale,
			"mesh_shape",
			getattr(mesh, "shape", None),
			"mesh_path",
			getattr(mesh, "custom_path", ""),
			"collider_path",
			getattr(collider, "collider_mesh_path", ""),
		)
		cached = self._poly_cache.get(entity.id)
		if cached is not None and cached[0] == state_key:
			return cached[1]

		pv_mesh: Optional[pv.DataSet] = None
		try:
			if use_mesh_component:
				if mesh is None:
					pv_mesh = None
				elif mesh.shape == "cube":
					pv_mesh = pv.Cube(center=(0.0, 0.0, 0.0), x_length=1.0, y_length=1.0, z_length=1.0)
				elif mesh.shape == "sphere":
					pv_mesh = pv.Sphere(radius=0.5, center=(0.0, 0.0, 0.0))
				elif mesh.shape == "custom":
					if mesh.custom_path:
						root = entity.scene.project_root if entity.scene else None
						abs_path = resolve_mesh_path_for_read(root, mesh.custom_path)
						pv_mesh = self._normalize_dataset_for_collision(pv.read(abs_path) if abs_path else None)
			else:
				collider_path = str(getattr(collider, "collider_mesh_path", "") or "").strip()
				if collider_path:
					root = entity.scene.project_root if entity.scene else None
					abs_path = resolve_mesh_path_for_read(root, collider_path)
					pv_mesh = self._normalize_dataset_for_collision(pv.read(abs_path) if abs_path else None)
					pv_mesh = self._apply_collider_scale(pv_mesh, collider)
		except Exception:
			pv_mesh = None

		if pv_mesh is None:
			self._poly_cache.pop(entity.id, None)
			return None

		try:
			surface = pv_mesh.extract_surface()
			poly = surface.GetOutput() if hasattr(surface, "GetOutput") else surface
		except Exception:
			return None

		if poly is None:
			return None
		self._poly_cache[entity.id] = (state_key, poly)
		return poly

	def _normalize_dataset_for_collision(self, dataset) -> Optional[pv.DataSet]:
		"""Flatten MultiBlock inputs into one dataset for surface extraction."""
		if dataset is None:
			return None
		try:
			if isinstance(dataset, pv.MultiBlock):
				blocks = self._collect_leaf_blocks(dataset)
				if not blocks:
					return None
				merged: Optional[pv.DataSet] = None
				for block in blocks:
					try:
						surface = block.extract_surface()
					except Exception:
						surface = block
					try:
						surface = surface.triangulate()
					except Exception:
						pass
					if merged is None:
						merged = surface
					else:
						merged = merged.merge(surface)
				return merged
		except Exception:
			return None
		return dataset

	def _apply_collider_scale(self, dataset: Optional[pv.DataSet], collider: ColliderComponent) -> Optional[pv.DataSet]:
		"""Apply collider-local uniform scaling to source geometry."""
		if dataset is None:
			return None
		try:
			scale = float(getattr(collider, "scale", 1.0) or 1.0)
		except Exception:
			scale = 1.0
		if scale <= 0.0:
			scale = 1.0
		if abs(scale - 1.0) < 1e-12:
			return dataset
		try:
			return dataset.scale([scale, scale, scale], inplace=False)
		except Exception:
			return dataset

	def _collect_leaf_blocks(self, dataset) -> List[pv.DataSet]:
		"""Collect all non-MultiBlock leaf datasets in traversal order."""
		leaves: List[pv.DataSet] = []
		try:
			if isinstance(dataset, pv.MultiBlock):
				for block in dataset:
					leaves.extend(self._collect_leaf_blocks(block))
			elif dataset is not None:
				leaves.append(dataset)
		except Exception:
			pass
		return leaves

	def _world_transform(self, entity: "Entity") -> QMatrix4x4:
		stack: List[QMatrix4x4] = []
		curr = entity
		while curr is not None:
			t = curr.get_component(TransformComponent)
			if t is None:
				stack.append(QMatrix4x4())
			else:
				stack.append(qmatrix_from_prs(t.position, t.rotation_quat, t.scale3d))
			curr = curr.parent
		world = QMatrix4x4()
		for m in reversed(stack):
			world = world * m
		return world

	@staticmethod
	def _update_vtk_transform(t: vtk.vtkTransform, m: QMatrix4x4) -> None:
		"""In-place update of an existing vtkTransform from a QMatrix4x4.

		Calling ``SetMatrix`` bumps the transform's MTime, which is what
		``vtkCollisionDetectionFilter`` keys on to invalidate collision results
		for the next ``Update()`` without touching the OBBTrees.
		"""
		mtx = vtk.vtkMatrix4x4()
		for r in range(4):
			for c in range(4):
				mtx.SetElement(r, c, float(m[r, c]))
		t.SetMatrix(mtx)

	@staticmethod
	def _world_bounds(
		poly: vtk.vtkPolyData, xform: QMatrix4x4
	) -> Tuple[float, float, float, float, float, float]:
		xmin, xmax, ymin, ymax, zmin, zmax = poly.GetBounds()
		corners = (
			(xmin, ymin, zmin), (xmin, ymin, zmax),
			(xmin, ymax, zmin), (xmin, ymax, zmax),
			(xmax, ymin, zmin), (xmax, ymin, zmax),
			(xmax, ymax, zmin), (xmax, ymax, zmax),
		)
		xs: List[float] = []
		ys: List[float] = []
		zs: List[float] = []
		for cx, cy, cz in corners:
			mapped = xform.map(QVector3D(float(cx), float(cy), float(cz)))
			xs.append(mapped.x())
			ys.append(mapped.y())
			zs.append(mapped.z())
		return (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))

	@staticmethod
	def _bounds_overlap(
		poly_a: vtk.vtkPolyData, xform_a: QMatrix4x4,
		poly_b: vtk.vtkPolyData, xform_b: QMatrix4x4,
	) -> bool:
		try:
			ba = CollisionSystem._world_bounds(poly_a, xform_a)
			bb = CollisionSystem._world_bounds(poly_b, xform_b)
		except Exception:
			return True
		return not (
			ba[1] < bb[0] or ba[0] > bb[1] or
			ba[3] < bb[2] or ba[2] > bb[3] or
			ba[5] < bb[4] or ba[4] > bb[5]
		)

	# --------------------------------------------------------------- scene events

	def _on_entity_removed(self, entity_id: str) -> None:
		self._poly_cache.pop(entity_id, None)
		self._evict_filters_for(entity_id)
		self.matrix.remove_entity(entity_id)
		# Another entity may have lost its sole collision partner; re-sweep.
		self.check_all()

	def _on_entity_transform_changed(self, entity_id: str) -> None:
		# Transform-only edits leave cached polydata and OBBTrees intact; we
		# only need to re-run the pair sweep (which swaps vtkTransforms into
		# the pooled filters without rebuilding trees).
		self.check_entity(entity_id)

	def _on_entity_changed(self, entity_id: str) -> None:
		# Mesh shape / path may have changed; drop the cached polydata AND any
		# pooled filter whose OBBTrees were built from the old polydata. They
		# will be lazily rebuilt on the next collision query for this entity.
		self._poly_cache.pop(entity_id, None)
		self._evict_filters_for(entity_id)

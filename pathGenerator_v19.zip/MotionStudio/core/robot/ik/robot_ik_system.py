from __future__ import annotations

import time
from typing import TYPE_CHECKING, Dict, List, Optional

import numpy as np
from PyQt6.QtCore import QMutex, QMutexLocker, QThread, QWaitCondition, pyqtSignal

from MotionStudio.core.robot.ik.ik_backend import IKBackend, IKSolveRequest, IKSolveResult
from MotionStudio.core.robot.ik.ik_frames import goal_in_base_frame, relative_offset_m

if TYPE_CHECKING:
	from MotionStudio.core.components.robot_description_component import RobotDescriptionComponent
	from MotionStudio.core.components.robot_ik_component import RobotIKComponent
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.core.scene.scene import Scene


def make_ik_backend(name: str) -> IKBackend:
	"""Construct an IK backend by name. Extend here for future backends (cuRobo).

	Unknown names fall back to IKPy (pure-Python, broadest platform support) so
	a stale ``backend`` value never breaks the system.
	"""
	key = (name or "").strip().lower()
	if key == "pinocchio":
		from MotionStudio.core.robot.ik.pinocchio_backend import PinocchioIKBackend

		return PinocchioIKBackend()
	from MotionStudio.core.robot.ik.ikpy_backend import IKPyIKBackend

	return IKPyIKBackend()


class _IKWorker(QThread):
	"""Background solver loop.

	Holds one pending request per robot (latest-wins) so a fast gizmo drag only
	ever resolves the most recent goal. Results are delivered on the main thread
	through the queued ``solved`` signal.
	"""

	solved = pyqtSignal(str, object)  # robot_entity_id, IKSolveResult

	def __init__(self) -> None:
		super().__init__()
		self._mutex = QMutex()
		self._wait = QWaitCondition()
		# robot_entity_id -> (backend_name, request); latest-wins per robot.
		self._pending: Dict[str, tuple[str, IKSolveRequest]] = {}
		self._stop = False
		self._backends: Dict[str, IKBackend] = {}

	def submit(self, backend_name: str, request: IKSolveRequest) -> None:
		with QMutexLocker(self._mutex):
			self._pending[request.robot_entity_id] = (backend_name, request)
			self._wait.wakeOne()

	def stop(self) -> None:
		with QMutexLocker(self._mutex):
			self._stop = True
			self._wait.wakeOne()
		self.wait(2000)

	def run(self) -> None:  # noqa: D401 - QThread entry point
		while True:
			with QMutexLocker(self._mutex):
				while not self._pending and not self._stop:
					self._wait.wait(self._mutex)
				if self._stop:
					return
				_robot_id, (backend_name, request) = self._pending.popitem()

			backend = self._backends.get(backend_name)
			if backend is None:
				backend = make_ik_backend(backend_name)
				self._backends[backend_name] = backend

			try:
				result = backend.solve(request)
			except Exception as exc:  # pragma: no cover - defensive
				result = IKSolveResult(False, {}, f"IK solve error: {exc}")

			self.solved.emit(request.robot_entity_id, result)


class RobotIKSystem:
	"""Scene service that drives IK from target/base transform changes.

	Mirrors the ownership pattern of ``CollisionSystem``: created by ``Scene``
	and reachable via ``scene.robot_ik_system``.
	"""

	def __init__(self, scene: "Scene") -> None:
		self._scene = scene
		self._applying_ik = False
		self._last_submit: Dict[str, float] = {}
		self._worker = _IKWorker()
		self._worker.solved.connect(self._on_ik_solved)
		self._worker.start()

		events = scene.events
		events.entity_transform_changed.connect(self._on_transform_changed)

	# ------------------------------------------------------------------ helpers

	def _ik_components(self) -> List["RobotIKComponent"]:
		from MotionStudio.core.components.robot_ik_component import RobotIKComponent

		out: List["RobotIKComponent"] = []
		for ent in self._scene.entities():
			comp = ent.get_component(RobotIKComponent)
			if comp is not None:
				out.append(comp)
		return out

	@staticmethod
	def _is_self_or_ancestor(candidate_id: str, entity: Optional["Entity"]) -> bool:
		cur = entity
		while cur is not None:
			if cur.id == candidate_id:
				return True
			cur = cur.parent
		return False

	def _resolve_transform_ref(
		self, ik: "RobotIKComponent", attr: str
	) -> Optional["Entity"]:
		"""Resolve a ``TransformComponent`` reference field to its Entity,
		tolerating both a resolved component and an unresolved ``entity_id`` string.

		The reference resolver only runs on scene load, so paths like
		``Scene.duplicate_entity`` (to_dict/from_dict round-trip) can leave the
		field as a raw id string. When that happens, rebind it to the actual
		component so later access and re-serialization stay consistent.
		"""
		from MotionStudio.core.components.transform_component import TransformComponent

		value = getattr(ik, attr, None)
		if value is None:
			return None
		ent = getattr(value, "entity", None)
		if ent is not None:
			return ent
		if isinstance(value, str):
			resolved = self._scene.find_by_id(value)
			if resolved is not None:
				comp = resolved.get_component(TransformComponent)
				if comp is not None:
					setattr(ik, attr, comp)  # rebind string id -> component
					return resolved
		return None

	def _target_entity(self, ik: "RobotIKComponent") -> Optional["Entity"]:
		return self._resolve_transform_ref(ik, "target")

	def _affects(self, ik: "RobotIKComponent", changed_id: str) -> bool:
		robot_ent = ik.entity
		if robot_ent is None:
			return False
		target_ent = self._target_entity(ik)
		if target_ent is None:
			return False
		if self._is_self_or_ancestor(changed_id, target_ent) or self._is_self_or_ancestor(
			changed_id, robot_ent
		):
			return True
		# Re-solve if the user re-positions the TCP entity (changes the offset),
		# unless it's just a descendant of the robot already covered above.
		tcp_ent = self._resolve_transform_ref(ik, "tcp")
		if tcp_ent is not None and self._is_self_or_ancestor(changed_id, tcp_ent):
			return True
		return False

	# ------------------------------------------------------------------ events

	def _on_transform_changed(self, changed_id: str) -> None:
		if self._applying_ik:
			return
		for ik in self._ik_components():
			if not getattr(ik, "enabled", False):
				continue
			if self._affects(ik, changed_id):
				self._enqueue(ik)

	def _enqueue(self, ik: "RobotIKComponent") -> None:
		request = self.build_request(ik)
		if request is None:
			return
		# Throttle to the component's solve rate; the worker also drops stale
		# requests, but this avoids spamming the queue during fast drags.
		hz = max(1.0, float(getattr(ik, "solve_hz", 20.0)))
		now = time.monotonic()
		robot_id = request.robot_entity_id
		last = self._last_submit.get(robot_id, 0.0)
		if (now - last) < (1.0 / hz):
			# Still update the pending goal so the latest target is honoured.
			self._worker.submit(str(getattr(ik, "backend", "pinocchio")), request)
			return
		self._last_submit[robot_id] = now
		self._worker.submit(str(getattr(ik, "backend", "pinocchio")), request)

	def build_request(self, ik: "RobotIKComponent") -> Optional[IKSolveRequest]:
		"""Build an IK request from live scene state (call on the main thread)."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.utils.mesh_assets import resolve_mesh_path_for_read

		robot_ent = ik.entity
		if robot_ent is None:
			return None
		target_ent = self._target_entity(ik)
		if target_ent is None:
			return None
		rd = robot_ent.get_component(RobotDescriptionComponent)
		if rd is None or not rd.urdf_path:
			return None

		project_root = self._scene.project_root
		abs_urdf = resolve_mesh_path_for_read(project_root, rd.urdf_path)
		if not abs_urdf:
			return None

		base_ent = self._resolve_base_entity(rd, robot_ent)
		try:
			t_goal = goal_in_base_frame(base_ent, target_ent)
		except Exception:
			return None

		# Custom Tool Control Point: solve so the TCP entity (not the raw tool
		# link) reaches the target. We capture the rigid offset T_ee_tcp between
		# the tool-link frame and the TCP, then aim the solver's ee frame at
		# T_goal * inv(T_ee_tcp) so that ee * T_ee_tcp == target.
		tcp_ent = self._resolve_transform_ref(ik, "tcp")
		if tcp_ent is not None:
			ee_id = rd.find_link_entity_id(rd.tool_link)
			ee_ent = self._scene.find_by_id(ee_id) if ee_id else None
			if ee_ent is not None:
				try:
					t_ee_tcp = relative_offset_m(ee_ent, tcp_ent)
					t_goal = t_goal @ np.linalg.inv(t_ee_tcp)
				except Exception:
					pass

		joint_names = list(rd.actuated_joint_names)
		q_seed = np.array(
			[float(rd.joint_positions.get(n, 0.0)) for n in joint_names],
			dtype=np.float64,
		)
		return IKSolveRequest(
			robot_entity_id=robot_ent.id,
			urdf_path=str(abs_urdf),
			joint_names=joint_names,
			q_seed=q_seed,
			T_goal_base=t_goal,
			ee_link=rd.tool_link,
			position_tolerance_m=float(getattr(ik, "position_tolerance_m", 1e-3)),
			orientation_tolerance_rad=float(getattr(ik, "orientation_tolerance_rad", 1e-2)),
			max_iterations=int(getattr(ik, "max_iterations", 100)),
			root_link=str(rd.root_link),
			joints=[dict(j) for j in rd.joints],
		)

	def _resolve_base_entity(
		self, rd: "RobotDescriptionComponent", robot_ent: "Entity"
	) -> "Entity":
		"""Return the entity whose frame matches the URDF root link."""
		root_id = rd.find_link_entity_id(rd.root_link)
		if root_id:
			base = self._scene.find_by_id(root_id)
			if base is not None:
				return base
		return robot_ent

	# ------------------------------------------------------------------ apply

	def _on_ik_solved(self, robot_entity_id: str, result: IKSolveResult) -> None:
		if not result.success and not result.joint_values:
			return
		self.apply_solution(robot_entity_id, result.joint_values)

	def apply_solution(self, robot_entity_id: str, joint_values: Dict[str, float]) -> None:
		"""Write a solved configuration onto the robot and refresh FK (main thread)."""
		from MotionStudio.core.components.robot_description_component import (
			RobotDescriptionComponent,
		)
		from MotionStudio.core.robot.robot_kinematics import update_robot_fk

		robot_ent = self._scene.find_by_id(robot_entity_id)
		if robot_ent is None:
			return
		rd = robot_ent.get_component(RobotDescriptionComponent)
		if rd is None or not joint_values:
			return

		self._applying_ik = True
		rd._ik_updating = True
		try:
			for name, value in joint_values.items():
				if name in rd.joint_positions or name in rd.actuated_joint_names:
					rd.joint_positions[name] = float(value)
			update_robot_fk(rd)
		finally:
			rd._ik_updating = False
			self._applying_ik = False

	# ------------------------------------------------------------------ teardown

	def shutdown(self) -> None:
		try:
			self._worker.stop()
		except Exception:
			pass

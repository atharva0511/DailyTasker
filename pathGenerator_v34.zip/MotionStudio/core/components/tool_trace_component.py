from __future__ import annotations

from typing import Annotated, List, Optional, Tuple

from PyQt6.QtGui import QQuaternion, QVector3D

from MotionStudio.core.components.path_component import PathComponent
from MotionStudio.core.components.transform_component import TransformComponent
from MotionStudio.core.ecs.component import Component, register_component
from MotionStudio.ui.inspector.metadata import Order, Range, Tooltip, inspector_button


@register_component
class ToolTraceComponent(Component):
	type_name = "ToolTrace"
	category = "Simulation"
	description = (
		"<p><b>Tool Trace</b></p>"
		"<p>Moves this entity along a PathGeneration waypoint sequence so you can "
		"preview a tool / TCP trace. Playback is an edit-mode play routine "
		"(<b>Simulate</b>), not Play Mode.</p>"
		"<p><b>How to use</b></p>"
		"<ul>"
		"<li>Assign <b>path</b> to the Job entity that owns PathGeneration.</li>"
		"<li>Set <b>speed</b> (units per second along the waypoint list).</li>"
		"<li>Click <b>Simulate</b>. The entity interpolates through world waypoint poses for one pass, then stops.</li>"
		"<li>For planned joint playback on a robot, use <b>MotionPlanner</b> instead of this component.</li>"
		"</ul>"
	)

	speed: Annotated[
		float,
		Order(10),
		Range(0.1, 10000.0, step=0.1, decimals=2),
		Tooltip("Distance per second along the waypoint list (scene units)"),
	] = 5.0

	path: Annotated[
		Optional[PathComponent],
		Order(20),
		Tooltip("PathGeneration whose world waypoints to follow"),
	] = None

	def __init__(self) -> None:
		self.path = None
		self.speed = 5.0
		self._waypoint_transforms: List[Tuple[float, float, float, float, float, float]] = []
		self._current_waypoint_index = 0
		self._start_rot = QQuaternion.fromEulerAngles(0.0, 0.0, 0.0)
		self._start_pos = QVector3D(0.0, 0.0, 0.0)
		self._trace_handle = None
		self._trace_listeners: list = []

	def add_trace_listener(self, callback) -> None:
		if callback not in self._trace_listeners:
			self._trace_listeners.append(callback)

	def remove_trace_listener(self, callback) -> None:
		try:
			self._trace_listeners.remove(callback)
		except ValueError:
			pass

	def _notify_trace_done(self, success: bool, message: str = "") -> None:
		for callback in list(self._trace_listeners):
			try:
				callback(bool(success), str(message or ""))
			except Exception:
				pass

	def get_waypoint_transforms(self) -> List[Tuple[float, float, float, float, float, float]]:
		if self.path is None:
			return []
		return self.path.get_world_waypoint_transforms()

	@inspector_button(
		"Simulate",
		tooltip="Walk this entity along the path waypoints once (edit-mode play routine)",
		order=100,
	)
	def simulate_trace(self):
		if self._trace_handle is not None and self._trace_handle.is_running:
			return False, "simulate is already running"
		if self.entity is None:
			return False, "no entity"
		scene = self.entity.scene
		pm = getattr(scene, "play_mode_manager", None) if scene is not None else None
		if pm is not None and getattr(pm, "is_playing", False):
			return False, "refused while Play Mode is active"
		transform = self.entity.get_component(TransformComponent)
		if transform is None:
			return False, "entity has no Transform"
		waypoints = self.get_waypoint_transforms()
		if not waypoints:
			return False, "path has no waypoints"
		self._waypoint_transforms = list(waypoints)
		self._current_waypoint_index = 0
		self._start_pos = QVector3D(transform.position)
		self._start_rot = QQuaternion(transform.rotation_quat)
		self._trace_handle = self.start_play_routine(self._trace_loop, name="simulate_trace")
		if self._trace_handle is None or not self._trace_handle.is_running:
			return False, "simulate did not start"
		return True

	@inspector_button(
		"Stop simulate",
		tooltip="Stop the tool-trace play routine",
		order=110,
	)
	def stop_simulate_trace(self) -> None:
		running = self._trace_handle is not None and self._trace_handle.is_running
		if running:
			self._trace_handle.stop()
			self._trace_handle = None
			self._notify_trace_done(False, "simulate cancelled")

	def _finish_trace(self, success: bool, message: str = "") -> None:
		self._trace_handle = None
		self._notify_trace_done(success, message)

	def _trace_loop(self, delta_time: float) -> bool:
		if self.entity is None:
			self._finish_trace(False, "no entity")
			return False
		transform = self.entity.get_component(TransformComponent)
		if transform is None:
			self._finish_trace(False, "entity has no Transform")
			return False
		waypoints = self._waypoint_transforms
		if not waypoints:
			self._finish_trace(False, "path has no waypoints")
			return False
		if self._current_waypoint_index >= len(waypoints):
			self._finish_trace(True, "")
			return False

		wp = waypoints[self._current_waypoint_index]
		target_pos = QVector3D(float(wp[0]), float(wp[1]), float(wp[2]))
		seg_len = (target_pos - self._start_pos).length()
		if seg_len <= 1e-6:
			self._advance_waypoint(transform)
			if self._current_waypoint_index >= len(waypoints):
				self._finish_trace(True, "")
				return False
			return True

		traveled = (transform.position - self._start_pos).length()
		t = min(1.0, traveled / seg_len)
		target_rot = QQuaternion.fromEulerAngles(float(wp[3]), float(wp[4]), float(wp[5]))
		offset = target_pos - transform.position
		if offset.length() <= 1e-9:
			dir_vec = QVector3D(0.0, 0.0, 0.0)
		else:
			dir_vec = QVector3D(offset)
			dir_vec.normalize()
		step = float(delta_time) * float(self.speed)
		transform.position = transform.position + dir_vec * step
		transform.rotation_quat = QQuaternion.slerp(self._start_rot, target_rot, t)
		if (transform.position - target_pos).length() < max(step, 1e-6):
			self._advance_waypoint(transform)
			if self._current_waypoint_index >= len(waypoints):
				self._finish_trace(True, "")
				return False
		return True

	def _advance_waypoint(self, transform: TransformComponent) -> None:
		self._current_waypoint_index += 1
		self._start_pos = QVector3D(transform.position)
		self._start_rot = QQuaternion(transform.rotation_quat)

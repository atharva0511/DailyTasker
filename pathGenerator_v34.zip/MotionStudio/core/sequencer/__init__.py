"""Package marker for sequencer persistence and playback."""

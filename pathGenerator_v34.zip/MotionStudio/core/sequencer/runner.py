"""Run sequencer steps on a worker thread via ``RemoteCommandDispatcher.execute``."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, List, Optional, Sequence, Tuple

from PyQt6.QtCore import QObject, pyqtSignal

from MotionStudio.core.remote.protocol import format_response, parse_command

if TYPE_CHECKING:
	from MotionStudio.core.logging.command_logger import CommandLogger
	from MotionStudio.core.remote.dispatcher import RemoteCommandDispatcher

# ``logs.txt`` action for every sequencer request / reply.
_LOG_ACTION = "sequencer"

# (row_index, command_line, continue_on_fail)
StepSpec = Tuple[int, str, bool]


class SequencerRunner(QObject):
	"""Parse each line and call ``dispatcher.execute`` from a daemon thread.

	Must not run ``execute`` on the Qt main thread: that waits on ``job.done``
	while ``_run_job`` also needs the main thread. Signals are queued to the
	thread that owns this object (the UI thread when parented to the dock).
	"""

	stepStarted = pyqtSignal(int)
	stepFinished = pyqtSignal(int, bool, str)
	runFinished = pyqtSignal(str)

	def __init__(self, parent: Optional[QObject] = None) -> None:
		super().__init__(parent)
		self._stop = threading.Event()
		self._thread: Optional[threading.Thread] = None
		self._running = False

	@property
	def is_running(self) -> bool:
		return self._running

	def start(
		self,
		dispatcher: "RemoteCommandDispatcher",
		timeout_s: float,
		steps: Sequence[StepSpec],
		command_logger: Optional["CommandLogger"] = None,
	) -> bool:
		"""Begin a run. Returns False if a run is already in progress."""
		if self._running:
			return False
		self._stop.clear()
		self._running = True
		copied: List[StepSpec] = list(steps)
		thread = threading.Thread(
			target=self._run,
			args=(dispatcher, float(timeout_s), copied, command_logger),
			name="SequencerRunner",
			daemon=True,
		)
		self._thread = thread
		thread.start()
		return True

	def request_stop(self) -> None:
		"""Prevent the next step. An in-flight ``WAIT`` is cancelled; other commands are not."""
		self._stop.set()

	def _run(
		self,
		dispatcher: "RemoteCommandDispatcher",
		timeout_s: float,
		steps: List[StepSpec],
		command_logger: Optional["CommandLogger"],
	) -> None:
		reason = "completed"
		try:
			for row_index, line, continue_on_fail in steps:
				if self._stop.is_set():
					reason = "stopped"
					break
				text = str(line or "").strip()
				if not text:
					continue
				self.stepStarted.emit(row_index)
				self._log(command_logger, f"{row_index + 1} > {text}")
				command, error = parse_command(text)
				if command is None:
					ok, output = False, error
				else:
					ok, output = dispatcher.execute(
						command, timeout_s, stop_event=self._stop
					)
				response = format_response(ok, output)
				self._log(command_logger, f"{row_index + 1} < {response.rstrip()}")
				self.stepFinished.emit(row_index, bool(ok), str(output or ""))
				if not ok and not continue_on_fail:
					reason = "failed"
					break
				if self._stop.is_set():
					reason = "stopped"
					break
		except Exception as exc:
			reason = f"error: {exc}"
		finally:
			self._running = False
			self._thread = None
			self.runFinished.emit(reason)

	@staticmethod
	def _log(logger: Optional["CommandLogger"], description: str) -> None:
		if logger is None:
			return
		try:
			logger.log_event(_LOG_ACTION, description)
		except Exception:
			pass

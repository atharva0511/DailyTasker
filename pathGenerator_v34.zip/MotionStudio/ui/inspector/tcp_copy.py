"""Right-click copy of TCP GET / EDIT / RUN commands from Inspector rows.

The menus live on field *labels* (and a thin host around Inspector buttons) so
left-click still edits or runs. Values for ``EDIT`` are formatted at click time
through :func:`format_field_value`, matching what a later ``GET`` would return.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QCursor
from PyQt6.QtWidgets import (
	QApplication,
	QHBoxLayout,
	QLabel,
	QMenu,
	QPushButton,
	QSizePolicy,
	QWidget,
)

from MotionStudio.core.remote.protocol import EDIT_OP, GET_OP, RUN_OP, format_request
from MotionStudio.ui.inspector.metadata import ConnectionStatus, ReadOnly

if TYPE_CHECKING:
	from MotionStudio.core.ecs.entity import Entity
	from MotionStudio.ui.inspector.reflection import FieldSpec
	from MotionStudio.ui.inspector_panel import InspectorPanel

# Qt dynamic property: lock-disable skips this host so a disabled RUN button
# still forwards right-click to a parent that can open the copy menu.
TCP_COPY_HOST_PROPERTY = "msTcpCopyHost"

_FIELD_HINT = "Right-click to copy GET / EDIT TCP command"
_BUTTON_HINT = "Right-click to copy RUN TCP command"


def entity_command_name(entity: "Entity") -> str:
	"""Name the protocol accepts: Inspector name, or UUID if the name is blank."""
	name = str(getattr(entity, "name", "") or "").strip()
	return name if name else str(entity.id)


def component_command_name(component) -> str:
	return str(getattr(component, "type_name", component.__class__.__name__))


def append_tcp_hint(existing: Optional[str], hint: str) -> str:
	text = str(existing or "").strip()
	if not text:
		return hint
	if hint in text:
		return text
	return f"{text}\n{hint}"


def field_is_tcp_writable(spec: "FieldSpec") -> bool:
	"""Same gates TCP ``EDIT`` uses: not ReadOnly / ConnectionStatus, has a setter."""
	if spec.setter is None:
		return False
	if any(isinstance(m, ReadOnly) and m.enabled for m in spec.metadata):
		return False
	if any(isinstance(m, ConnectionStatus) for m in spec.metadata):
		return False
	return True


def populate_field_copy_menu(
	menu: QMenu,
	panel: "InspectorPanel",
	entity: "Entity",
	component,
	spec: "FieldSpec",
	writable: bool,
	*,
	source: QWidget,
) -> None:
	get_cmd = format_request(
		GET_OP,
		entity_command_name(entity),
		component_command_name(component),
		spec.name,
	)
	menu.addAction("Copy GET command", lambda c=get_cmd, src=source: copy_tcp_command(c, src))
	if writable:
		menu.addAction(
			"Copy EDIT command",
			lambda e=entity, c=component, s=spec, p=panel, src=source: _copy_edit(p, e, c, s, src),
		)


def copy_tcp_command(text: str, source: Optional[QWidget] = None) -> None:
	"""Put ``text`` on the clipboard and flash the main-window status bar."""
	command = str(text or "")
	if not command:
		return
	clip = QApplication.clipboard()
	if clip is not None:
		clip.setText(command)
	_flash_status(source, f"Copied {command}")


def _flash_status(source: Optional[QWidget], message: str) -> None:
	from PyQt6.QtWidgets import QMainWindow

	widget: Optional[QWidget] = source
	while widget is not None:
		if isinstance(widget, QMainWindow):
			try:
				widget.statusBar().showMessage(message, 4000)
				return
			except Exception:
				break
		widget = widget.parentWidget()
	app = QApplication.instance()
	window = app.activeWindow() if app is not None else None
	if isinstance(window, QMainWindow):
		try:
			window.statusBar().showMessage(message, 4000)
		except Exception:
			pass


def _install_menu(widget: QWidget, build_menu: Callable[[QWidget], QMenu]) -> None:
	widget.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

	def _show(pos, w=widget, builder=build_menu) -> None:
		menu = builder(w)
		if menu is None or menu.isEmpty():
			return
		# ``pos`` is widget-local; map so the menu appears on the cursor.
		menu.exec(w.mapToGlobal(pos) if pos is not None else QCursor.pos())

	widget.customContextMenuRequested.connect(_show)


def make_field_label(
	text: str,
	parent: QWidget,
	*,
	panel: "InspectorPanel",
	entity: "Entity",
	component,
	spec: "FieldSpec",
	writable: bool,
	help_tooltip: Optional[str] = None,
) -> QLabel:
	"""Form label with a GET (and optional EDIT) copy menu."""
	label = QLabel(text, parent)
	label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
	label.setToolTip(append_tcp_hint(help_tooltip, _FIELD_HINT))

	def _build(_w: QWidget) -> QMenu:
		menu = QMenu(_w)
		populate_field_copy_menu(menu, panel, entity, component, spec, writable, source=_w)
		return menu

	_install_menu(label, _build)
	return label


def _copy_edit(
	panel: "InspectorPanel",
	entity: "Entity",
	component,
	spec: "FieldSpec",
	source: QWidget,
) -> None:
	from MotionStudio.core.remote.value_parser import format_field_value

	try:
		raw = spec.getter()
	except Exception as exc:
		_flash_status(source, f"Could not read {spec.name}: {exc}")
		return
	scene = getattr(panel, "_scene", None)
	text, error = format_field_value(spec, raw, scene)
	if error:
		_flash_status(source, error)
		return
	copy_tcp_command(
		format_request(
			EDIT_OP,
			entity_command_name(entity),
			component_command_name(component),
			spec.name,
			text,
		),
		source,
	)


def wrap_run_button(
	btn: QPushButton,
	parent: QWidget,
	*,
	entity: "Entity",
	component,
	button_label: str,
	help_tooltip: Optional[str] = None,
) -> QWidget:
	"""Host a RUN button so right-click still copies when the button is disabled."""
	hinted = append_tcp_hint(help_tooltip, _BUTTON_HINT)
	btn.setToolTip(hinted)

	host = QWidget(parent)
	host.setProperty(TCP_COPY_HOST_PROPERTY, True)
	host.setToolTip(hinted)
	host.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
	layout = QHBoxLayout(host)
	layout.setContentsMargins(0, 0, 0, 0)
	layout.setSpacing(0)
	layout.addWidget(btn)

	command = format_request(
		RUN_OP,
		entity_command_name(entity),
		component_command_name(component),
		button_label,
	)

	def _build(_w: QWidget) -> QMenu:
		menu = QMenu(_w)
		menu.addAction("Copy RUN command", lambda c=command, src=_w: copy_tcp_command(c, src))
		return menu

	# Enabled button consumes the right-click; disabled button forwards to host.
	_install_menu(btn, _build)
	_install_menu(host, _build)
	return host

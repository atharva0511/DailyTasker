"""Send a TCP command to Motion Studio and print the response.

Replies are one JSON object per line: ``{"status": "PASS"|"FAIL", "return": "..."}``.
With a command argument the exit code is 0 for PASS and 1 for FAIL.

Usage:
    python tcp_test.py "RUN,entity1,ThreePointCalibration,Align"
    python tcp_test.py --port 5555 "RUN,Job,MotionPlanner,Plan Motion"
    python tcp_test.py                # interactive: type commands, blank line quits
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
import time

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 5555


def read_line(sock: socket.socket) -> str:
	"""Read one newline-terminated response."""
	buffer = bytearray()
	while not buffer.endswith(b"\n"):
		chunk = sock.recv(4096)
		if not chunk:
			break
		buffer.extend(chunk)
	return buffer.decode("utf-8", errors="replace").rstrip("\r\n")


def send(sock: socket.socket, command: str) -> bool:
	"""Send one command, print the decoded reply, and report whether it passed."""
	started = time.perf_counter()
	sock.sendall((command.strip() + "\n").encode("utf-8"))
	reply = read_line(sock)
	elapsed = time.perf_counter() - started

	try:
		payload = json.loads(reply)
		status = str(payload.get("status", "?"))
		returned = str(payload.get("return", ""))
	except (ValueError, AttributeError):
		# Not JSON: show it raw rather than hiding whatever the server sent.
		print(f"< {reply}    [{elapsed:.2f}s]  (unparsable reply)")
		return False

	detail = f"  {returned}" if returned else ""
	print(f"< {status}{detail}    [{elapsed:.2f}s]")
	return status == "PASS"


def main() -> int:
	parser = argparse.ArgumentParser(description="Motion Studio TCP command client")
	parser.add_argument("command", nargs="?", help="e.g. RUN,entity1,ThreePointCalibration,Align")
	parser.add_argument("--host", default=DEFAULT_HOST)
	parser.add_argument("--port", type=int, default=DEFAULT_PORT)
	parser.add_argument("--timeout", type=float, default=600.0, help="socket read timeout (s)")
	args = parser.parse_args()

	try:
		sock = socket.create_connection((args.host, args.port), timeout=10)
	except OSError as exc:
		print(f"Could not connect to {args.host}:{args.port} -- {exc}")
		return 1
	sock.settimeout(args.timeout)

	print(f"Connected to {args.host}:{args.port}")
	try:
		if args.command:
			# Exit code follows the command's status, so shell scripts can branch on it.
			return 0 if send(sock, args.command) else 1

		print("Type a command (blank line to quit).")
		while True:
			try:
				line = input("> ").strip()
			except (EOFError, KeyboardInterrupt):
				break
			if not line:
				break
			send(sock, line)
	except socket.timeout:
		print(f"No response within {args.timeout:.0f}s")
		return 1
	except OSError as exc:
		print(f"Connection failed: {exc}")
		return 1
	finally:
		sock.close()
	return 0


if __name__ == "__main__":
	sys.exit(main())